#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when flagged. Always exits 0.
const fs = require('fs');
const path = require('path');
const lib = require('./lib');

const MAX_PATHS = 16;
const LABEL_CAP = 5;
const INSTR_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];
const INSTR_NAMES = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];

function patchPaths(cmd) {
  const out = [];
  if (typeof cmd !== 'string') return out;
  for (const line of cmd.split(/\r?\n/)) {
    const m = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/.exec(line);
    if (m) {
      const p = m[1].trim();
      if (p && !out.includes(p)) out.push(p);
    }
  }
  return out;
}

function isInstructionFile(p) {
  const base = path.basename(p).toLowerCase();
  if (INSTR_NAMES.includes(base)) return true;
  const ext = path.extname(base);
  const stem = base.slice(0, base.length - ext.length);
  if (!lib.PROSE_EXT.includes(ext) && INSTR_STEMS.includes(stem)) return true;
  if (INSTR_STEMS.includes(base)) return true;
  return false;
}

function isUnder(child, parent) {
  const rel = path.relative(parent, child);
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function shouldSkip(abs) {
  const parts = abs.split(/[\\/]+/);
  if (parts.includes('node_modules') || parts.includes('.git')) return true;
  let root = lib.pluginRoot();
  try { root = fs.realpathSync(root); } catch (e) { /* keep */ }
  let real = abs;
  try { real = fs.realpathSync(abs); } catch (e) { /* keep */ }
  if (isUnder(abs, path.resolve(lib.pluginRoot())) || isUnder(real, root)) return true;
  return false;
}

function scoreFile(abs, level, sid) {
  const base = path.basename(abs);
  const ext = path.extname(abs).toLowerCase();
  if (ext === '.pdf' || ext === '.rtf') {
    lib.addLedger(sid, { kind: 'binary', base });
    return null;
  }
  if (!lib.PROSE_EXT.includes(ext)) return null;
  let st;
  try { st = fs.statSync(abs); } catch (e) {
    lib.addLedger(sid, { kind: 'failed', base, reason: 'file could not be read (not found)' });
    return null;
  }
  if (!st.isFile()) return null;
  const archive = lib.ARCHIVE_EXT.includes(ext);
  const cap = archive ? lib.ARCHIVE_CAP : lib.PLAIN_CAP;
  if (st.size > cap) {
    lib.addLedger(sid, { kind: 'skipped', base, capKB: cap / 1024 });
    return null;
  }
  const r = lib.runDetector(['--', abs], { timeout: archive ? 15000 : 8000 });
  const fail = (reason) => { lib.addLedger(sid, { kind: 'failed', base, reason }); return null; };
  switch (r.kind) {
    case 'nopython': return fail('Python was not found');
    case 'nodetector': return fail('the bundled detector was not found');
    case 'timeout': return fail('the detector timed out');
    case 'unusable': return fail('the detector printed text that is not a structured report');
    case 'noscore': return fail('the report has no numeric score');
    case 'failed':
    case 'noresult': return fail('the detector produced no output or exited without a usable result');
    default: break;
  }
  const m = r.report._metrics;
  const score = Math.round(m.ai_tell_score);
  const band = String(m.ai_tell_band);
  const labels = lib.findings(r.report).map((f) => f.label);
  const threshold = lib.THRESHOLD[level];
  const flagged = score > threshold;
  const truncated = m.truncated === true;
  lib.addLedger(sid, { kind: 'scored', base, score, band, labels: labels.slice(0, LABEL_CAP), flagged, truncated });
  if (!flagged) return null;
  const cov = truncated ? ', first ' + lib.SCAN_WINDOW.toLocaleString('en-US') + ' characters only' : '';
  return 'prosecheck: ' + base + ' ' + lib.hookPhrase(band) + ' (score ' + score + ', band ' + band + cov + '). Flagged: ' +
    labels.slice(0, LABEL_CAP).join('; ') + '. Please fix the flagged spans, keeping sentence-length variation.';
}

try {
  const p = lib.readStdinJson();
  const level = lib.currentLevel();
  if (level === 'full' || level === 'strict') {
    const tool = p.tool_name;
    const ti = p.tool_input && typeof p.tool_input === 'object' ? p.tool_input : {};
    let paths = [];
    if (tool === 'Write' || tool === 'Edit' || tool === 'MultiEdit') {
      if (typeof ti.file_path === 'string') paths = [ti.file_path];
    } else if (tool === 'NotebookEdit') {
      if (typeof ti.notebook_path === 'string') paths = [ti.notebook_path];
      else if (typeof ti.file_path === 'string') paths = [ti.file_path];
    } else if (tool === 'apply_patch') {
      paths = patchPaths(ti.command);
      if (!paths.length && typeof ti.patch === 'string') paths = patchPaths(ti.patch);
    }
    paths = paths.map((s) => s.trim()).filter(Boolean).slice(0, MAX_PATHS);
    const cwd = typeof p.cwd === 'string' && p.cwd ? p.cwd : process.cwd();
    const sid = typeof p.session_id === 'string' ? p.session_id : '';
    const lines = [];
    for (const raw of paths) {
      try {
        const abs = path.isAbsolute(raw) ? raw : path.resolve(cwd, raw);
        if (shouldSkip(abs) || isInstructionFile(abs)) continue;
        const l = scoreFile(abs, level, sid);
        if (l) lines.push(l);
      } catch (e) { /* next file */ }
    }
    if (lines.length) {
      process.stdout.write(JSON.stringify({
        hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
      }));
    }
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
