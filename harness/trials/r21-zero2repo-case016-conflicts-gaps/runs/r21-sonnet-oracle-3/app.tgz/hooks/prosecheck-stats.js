'use strict';
// stats subcommand: session token figures and own-prose score. Module used by the tracker.
const fs = require('fs');
const path = require('path');
const lib = require('./lib');

function newestTranscript(dir) {
  let best = null;
  function walk(d, depth) {
    let ents = [];
    try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    for (const e of ents) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { if (depth < 4) walk(p, depth + 1); }
      else if (e.isFile() && e.name.endsWith('.jsonl')) {
        try {
          const m = fs.statSync(p).mtimeMs;
          if (!best || m > best.m) best = { p, m };
        } catch (err) { /* skip */ }
      }
    }
  }
  walk(dir, 0);
  return best ? best.p : null;
}

function stats(transcriptPath) {
  const level = lib.currentLevel();
  let tp = null;
  if (transcriptPath && typeof transcriptPath === 'string') tp = transcriptPath;
  else tp = newestTranscript(path.join(lib.configDir(), 'projects'));
  let raw = null;
  if (tp) { try { raw = fs.readFileSync(tp, 'utf8'); } catch (e) { raw = null; } }
  if (raw === null) {
    return 'prosecheck stats: no readable session transcript was found.\nlevel: ' + level;
  }
  const byId = new Map();
  let anon = 0;
  const texts = [];
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    let o;
    try { o = JSON.parse(line); } catch (e) { continue; }
    if (!o || o.type !== 'assistant' || !o.message || typeof o.message !== 'object') continue;
    const m = o.message;
    const u = m.usage || {};
    const id = typeof m.id === 'string' && m.id ? m.id : '#anon' + (anon++);
    const rec = byId.get(id) || { out: 0, cache: 0, texts: [] };
    const out = Number(u.output_tokens) || 0;
    const cache = Number(u.cache_read_input_tokens) || 0;
    rec.out = Math.max(rec.out, out);
    rec.cache = Math.max(rec.cache, cache);
    if (Array.isArray(m.content)) {
      for (const c of m.content) {
        if (c && c.type === 'text' && typeof c.text === 'string') texts.push(c.text);
      }
    } else if (typeof m.content === 'string') texts.push(m.content);
    byId.set(id, rec);
  }
  let out = 0, cache = 0;
  for (const r of byId.values()) { out += r.out; cache += r.cache; }
  const lines = [];
  lines.push('prosecheck session stats');
  lines.push('level: ' + level);
  lines.push('assistant turns: ' + byId.size);
  lines.push('output tokens: ' + out);
  lines.push('cache-read input tokens: ' + cache);
  let prose = texts.join('\n\n').replace(/^[ \t]*(```|~~~)[^\n]*\n[\s\S]*?(?:\n[ \t]*\1[ \t]*(?=\n|$)|$)/gm, '');
  prose = prose.slice(-40000);
  const trimmed = prose.trim();
  if (trimmed.length > 200) {
    const r = lib.runDetector([], { input: prose, timeout: 15000 });
    if (r.kind === 'ok') lines.push('session prose ai_tell_score: ' + r.report._metrics.ai_tell_score);
  }
  return lines.join('\n');
}

module.exports = { stats, newestTranscript };

if (require.main === module) {
  try {
    const p = lib.readStdinJson();
    process.stdout.write(stats(p.transcript_path) + '\n');
  } catch (e) { /* never fail */ }
  process.exit(0);
}
