#!/usr/bin/env node
'use strict';
// Session-start hook: emits the writing contract (plain text). Always exits 0.
const lib = require('./lib');
try {
  lib.readStdinJson();
  lib.pruneLedgers();
  const first = lib.storedLevel() === null && !require('fs').existsSync(lib.flagPath());
  const level = lib.currentLevel();
  if (level !== 'off') {
    if (first || lib.storedLevel() === null) lib.storeLevel(level);
    let out = '';
    if (first) out += lib.welcomeText() + '\n';
    out += lib.contractFor(level);
    process.stdout.write(out);
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
