'use strict';
// Shared helpers for the prosecheck hooks. Node standard library only.
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const SCAN_WINDOW = 262144;
const PLAIN_CAP = 512 * 1024;
const ARCHIVE_CAP = 4 * 1024 * 1024;
const PLAIN_EXT = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ARCHIVE_EXT = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub', '.ipynb'];
const PROSE_EXT = PLAIN_EXT.concat(ARCHIVE_EXT);
const LEDGER_KEEP = 20;
const LEDGER_MAX_AGE_MS = 7 * 24 * 3600 * 1000;
const THRESHOLD = { full: 40, strict: 20 };
const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster', 'underscore',
  'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament', 'vibrant', 'comprehensive',
  'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock', 'game-changer', 'supercharge', 'genuinely',
  'fascinating', 'nuanced'];

function readStdinJson() {
  let raw = '';
  try { raw = fs.readFileSync(0, 'utf8'); } catch (e) { raw = ''; }
  try {
    const v = JSON.parse(raw);
    if (v && typeof v === 'object' && !Array.isArray(v)) return v;
  } catch (e) { /* malformed */ }
  return {};
}

function configDir() {
  if (process.env.CLAUDE_CONFIG_DIR) return process.env.CLAUDE_CONFIG_DIR;
  return path.join(os.homedir(), '.claude');
}

function pluginRoot() {
  if (process.env.CLAUDE_PLUGIN_ROOT) return process.env.CLAUDE_PLUGIN_ROOT;
  return path.resolve(__dirname, '..');
}

function flagPath() { return path.join(configDir(), '.prosecheck-active'); }

function storedLevel() {
  try {
    const v = fs.readFileSync(flagPath(), 'utf8').trim();
    if (LEVELS.includes(v)) return v;
  } catch (e) { /* none */ }
  return null;
}

function envLevel() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim();
  return LEVELS.includes(v) ? v : null;
}

function currentLevel() { return storedLevel() || envLevel() || 'full'; }

function storeLevel(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), level);
    return true;
  } catch (e) { return false; }
}

function detectorPath() {
  const root = pluginRoot();
  const a = path.join(root, 'scripts', 'detect.py');
  if (isFile(a)) return a;
  const b = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  if (isFile(b)) return b;
  return null;
}

function isFile(p) { try { return fs.statSync(p).isFile(); } catch (e) { return false; } }

function findPython() {
  const dirs = (process.env.PATH || '').split(path.delimiter).filter(Boolean);
  const exts = process.platform === 'win32' ? ['.exe', '.cmd', '.bat', ''] : [''];
  for (const name of ['python3', 'python', 'py']) {
    for (const d of dirs) {
      for (const e of exts) {
        const p = path.join(d, name + e);
        try {
          fs.accessSync(p, fs.constants.X_OK);
          if (fs.statSync(p).isFile()) return p;
        } catch (err) { /* next */ }
      }
    }
  }
  return null;
}

// Run the detector. Returns {kind:'ok'|'nopython'|'nodetector'|'timeout'|'noresult'|'unusable'|'noscore'|'failed', ...}
function runDetector(args, opts) {
  opts = opts || {};
  const py = findPython();
  if (!py) return { kind: 'nopython' };
  const det = detectorPath();
  if (!det) return { kind: 'nodetector' };
  const r = cp.spawnSync(py, [det].concat(args), {
    input: opts.input, encoding: 'utf8', timeout: opts.timeout || 15000, maxBuffer: 256 * 1024 * 1024,
    env: Object.assign({}, process.env, { PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' }),
  });
  if (r.error) {
    if (r.error.code === 'ETIMEDOUT' || r.signal === 'SIGTERM') return { kind: 'timeout' };
    if (r.error.code === 'ENOENT') return { kind: 'nopython' };
    return { kind: 'noresult', stderr: String(r.error.message || '') };
  }
  if (r.signal) return { kind: 'timeout' };
  const out = (r.stdout || '').trim();
  const errText = (r.stderr || '').trim();
  if (r.status !== 0) return { kind: 'failed', status: r.status, stderr: errText, stdout: out };
  if (!out) return { kind: 'noresult', stderr: errText };
  let rep;
  try { rep = JSON.parse(out); } catch (e) { return { kind: 'unusable' }; }
  if (!rep || typeof rep !== 'object' || !rep._metrics || typeof rep._metrics !== 'object') return { kind: 'unusable' };
  const s = rep._metrics.ai_tell_score;
  if (typeof s !== 'number' || !isFinite(s)) return { kind: 'noscore' };
  return { kind: 'ok', report: rep, raw: out };
}

function hookPhrase(band) {
  switch (band) {
    case 'clean': return 'reads clean';
    case 'light tells': return 'reads mostly clean';
    case 'mixed': return 'reads with some AI tells';
    case 'heavy tells': return 'reads with heavy AI tells';
    default: return 'reads with pervasive AI tells';
  }
}

function findings(report) {
  const out = [];
  for (const k of Object.keys(report)) {
    if (k === '_metrics') continue;
    const v = report[k];
    if (v && typeof v === 'object') out.push({ key: k, label: String(v.label || k), count: Number(v.count) || 0 });
  }
  return out;
}

// ---- ledger
function sanitizeSid(s) { return String(s).replace(/[^A-Za-z0-9_.-]/g, '_').slice(0, 120); }
function ledgerPath(sid) {
  const base = '.prosecheck-ledger';
  return path.join(configDir(), sid ? base + '-' + sanitizeSid(sid) : base);
}

function pruneLedgers() {
  try {
    const dir = configDir();
    for (const f of fs.readdirSync(dir)) {
      if (f === '.prosecheck-ledger' || f.startsWith('.prosecheck-ledger-')) {
        const p = path.join(dir, f);
        try {
          if (Date.now() - fs.statSync(p).mtimeMs > LEDGER_MAX_AGE_MS) fs.unlinkSync(p);
        } catch (e) { /* ignore */ }
      }
    }
  } catch (e) { /* ignore */ }
}

function readLedger(sid) {
  const p = ledgerPath(sid);
  try {
    const st = fs.statSync(p);
    if (Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) { try { fs.unlinkSync(p); } catch (e) { /* */ } return []; }
    const v = JSON.parse(fs.readFileSync(p, 'utf8'));
    return Array.isArray(v) ? v : [];
  } catch (e) { return []; }
}

function addLedger(sid, rec) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    const cur = readLedger(sid);
    rec.ts = Date.now();
    cur.push(rec);
    const keep = cur.slice(-LEDGER_KEEP);
    fs.writeFileSync(ledgerPath(sid), JSON.stringify(keep));
  } catch (e) { /* never fail the host */ }
}

// ---- contract
function bannedList() { return BANNED.join(', '); }

function contractText(level, opts) {
  opts = opts || {};
  const L = [];
  L.push('PROSE CONTRACT (' + level + ')');
  L.push('Scope: prose deliverables only: documents, README or markdown prose, CVs, cover letters, emails, reports, essays, articles, and drafted text the user will publish or send.');
  L.push('This contract never applies to source code, code comments, commit messages, JSON/YAML/config files, CLI output, logs, error messages, or the conversational register of chat. A chat-compression mode owns chat; a code-simplicity mode owns code; this contract owns deliverable prose.');
  L.push('Rules for deliverable prose:');
  L.push('- Vary sentence length irregularly. No metronome, no mechanical short-long alternation.');
  L.push('- Banned vocabulary (never use): ' + bannedList() + '.');
  L.push('- Banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting ("let\'s dive in"), empty pivots ("it\'s worth noting"), "In conclusion" / "Overall" closers, outcome-speculation tails, self-thoroughness, generic upbeat endings, and chatbot phrases ("I hope this helps").');
  L.push('- At most one em dash per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.');
  L.push('- Factual or encyclopedic content stays neutral third person; first-person or opinion content may use contractions.');
  L.push('- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.');
  L.push('- End sections on a fact or observation.');
  L.push('- Stay silent about this contract: never announce it, never name prosecheck, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.');
  if (level === 'full' || level === 'strict') {
    const target = level === 'strict' ? 'the clean band (score at most 20)' : 'the clean or light tells band (score at most 40)';
    L.push('After writing a prose file, run the detector on that file: python3 detect.py <file>. If the band is worse than the target (' + target + '), fix the flagged spans, at most two fix passes, keeping rhythm variation.');
    if (level === 'strict') {
      L.push('Finish by running the detector with the cleanup switch: python3 detect.py --clean <file>, and keep its scrubbed text.');
    }
    if (opts.portable) {
      L.push('To resolve the detector, use CLAUDE_PLUGIN_ROOT when that variable is set; otherwise locate prosecheck\'s detector among the installed skills and plugins.');
    } else if (opts.detector) {
      L.push('Detector path on this machine: ' + opts.detector);
    }
  }
  return L.join('\n') + '\n';
}

function welcomeText() {
  return [
    'prosecheck is installed and on. Saved prose is scored against 71 documented AI-writing patterns.',
    'Plain text is accepted up to 512 KB and archives up to 4 MB; the detector scores the first 262,144 characters.',
    'Try /prosecheck doctor, /prosecheck check <file>, /prosecheck off, or /prosecheck help.',
    'There is no website and no upload; everything stays on this machine. This welcome is shown once.',
    '',
  ].join('\n');
}

function contractFor(level) {
  return contractText(level, { detector: detectorPath() });
}

module.exports = {
  LEVELS, SCAN_WINDOW, PLAIN_CAP, ARCHIVE_CAP, PLAIN_EXT, ARCHIVE_EXT, PROSE_EXT, THRESHOLD, BANNED,
  readStdinJson, configDir, pluginRoot, flagPath, storedLevel, envLevel, currentLevel, storeLevel,
  detectorPath, findPython, runDetector, hookPhrase, findings, ledgerPath, pruneLedgers, readLedger,
  addLedger, contractText, contractFor, welcomeText, isFile,
};
