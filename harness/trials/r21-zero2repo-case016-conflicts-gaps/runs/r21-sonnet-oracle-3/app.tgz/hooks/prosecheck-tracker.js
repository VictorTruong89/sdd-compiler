#!/usr/bin/env node
'use strict';
// Prompt-submit hook and /prosecheck command router. Always exits 0.
const fs = require('fs');
const path = require('path');
const lib = require('./lib');
const statsMod = require('./prosecheck-stats');

const SUBS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];
const CHECK_LABEL_CAP = 8;
const SHOW_LABEL_CAP = 5;
const KB = (n) => String(n);

function helpReply(level) {
  return [
    'prosecheck level: ' + level,
    'Code, commits, config, and chat are never touched; only prose deliverables follow the contract.',
    '/prosecheck lite - turn on the writing contract without scoring saved files',
    '/prosecheck full - contract plus the saved-file guard, threshold 40 (default)',
    '/prosecheck strict - guard with a lower threshold, 20, and the cleanup scrub',
    '/prosecheck off - disable the contract and the guard',
    '/prosecheck on - re-enable (back to the default level)',
    '/prosecheck status - show the current level',
    '/prosecheck show - list the files scored in this session',
    '/prosecheck check <file> - score one file, report only; it will never rewrite the file',
    '/prosecheck doctor - run a health check of the install',
    '/prosecheck stats - session token figures and the score of the session prose',
    '/prosecheck init - export the contract to ./AGENTS.md for agents other than Claude Code',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function cleanPathArg(arg) {
  let s = (arg || '').trim();
  if (s.startsWith('@')) s = s.slice(1);
  if (s.length >= 2 && (s[0] === '"' || s[0] === "'") && s[s.length - 1] === s[0]) s = s.slice(1, -1);
  if (s.startsWith('@')) s = s.slice(1);
  return s.trim();
}

function checkReply(arg, cwd) {
  const p = cleanPathArg(arg);
  if (!p) return 'prosecheck check: give a file path, for example: /prosecheck check notes.md (report only).';
  const abs = path.isAbsolute(p) ? p : path.resolve(cwd, p);
  const base = path.basename(abs);
  let st;
  try { st = fs.statSync(abs); } catch (e) { return 'cannot read ' + p; }
  if (!st.isFile()) return p + ': not a file';
  const ext = path.extname(abs).toLowerCase();
  if (ext === '.pdf' || ext === '.rtf') return base + ': no readable text';
  const archive = lib.ARCHIVE_EXT.includes(ext);
  const cap = archive ? lib.ARCHIVE_CAP : lib.PLAIN_CAP;
  if (st.size > cap) return base + ' is over ' + KB(cap / 1024) + ' KB and was not scored.';
  const r = lib.runDetector(['--', abs], { timeout: archive ? 15000 : 8000 });
  switch (r.kind) {
    case 'nopython': return 'detector unavailable: Python was not found, so nothing can be scored.';
    case 'nodetector': return 'detector unavailable: the bundled detector is missing.';
    case 'timeout': return base + ' failed: the scan timed out.';
    case 'noresult': return base + ': no report was produced.';
    case 'unusable': case 'noscore': return 'no report: the scan printed something that is not a report.';
    case 'failed': {
      let msg = r.stderr || '';
      return base + ' failed' + (msg ? ': ' + msg : ' to scan.');
    }
    default: break;
  }
  const rep = r.report;
  const m = rep._metrics;
  const score = Math.round(m.ai_tell_score);
  const lines = [];
  lines.push(base + ' - ' + lib.hookPhrase(m.ai_tell_band) + ' (score ' + score + '/100, band: ' + m.ai_tell_band + ')');
  let c = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && m.confidence_reason) c += ' - ' + m.confidence_reason;
  lines.push(c);
  if (m.truncated === true) lines.push('coverage: first ' + lib.SCAN_WINDOW.toLocaleString('en-US') + ' characters only');
  const f = lib.findings(rep);
  if (!f.length) lines.push('tells: none');
  else lines.push('tells: ' + f.slice(0, CHECK_LABEL_CAP).map((x) => x.label + ' (x' + x.count + ')').join('; '));
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

function doctorReply(form) {
  const level = lib.currentLevel();
  const lines = [];
  lines.push('prosecheck health check');
  const modeOk = level !== 'off';
  lines.push(modeOk ? '[OK] mode: ' + level : '[--] mode: ' + level + ' (switched off; enable with /prosecheck on)');
  const det = lib.detectorPath();
  lines.push(det ? '[OK] detector: bundled script present' : '[FAIL] detector: bundled script not found in the plugin tree');
  let pyOk = false;
  let pyLine;
  const py = lib.findPython();
  if (!py) {
    pyLine = '[FAIL] python not found: prose is still shaped by the contract, but saved files will not be re-scored until Python is available';
  } else if (!det) {
    pyLine = '[FAIL] python: found, but there is no bundled script to run';
  } else {
    const r = lib.runDetector([], { input: 'This is a short sample sentence for the health check. It is only here to confirm a score comes back.', timeout: 15000 });
    if (r.kind === 'ok') { pyOk = true; pyLine = '[OK] python: ran the bundled script and got a numeric score'; }
    else if (r.kind === 'nopython') pyLine = '[FAIL] python not found: prose is still shaped by the contract, but saved files will not be re-scored until Python is available';
    else pyLine = '[FAIL] python: ran, but the result was not a numeric score (' + r.kind + ')';
  }
  lines.push(pyLine);
  let setOk = false;
  try {
    fs.mkdirSync(lib.configDir(), { recursive: true });
    const t = path.join(lib.configDir(), '.prosecheck-write-test-' + process.pid);
    fs.writeFileSync(t, 'x');
    fs.unlinkSync(t);
    setOk = true;
  } catch (e) { setOk = false; }
  lines.push(setOk ? '[OK] settings folder is writable' : '[FAIL] settings folder is not writable');
  const others = !!det && pyOk && setOk;
  let closer;
  if (others && modeOk) {
    closer = 'All checks passed: prosecheck is active. Plain text up to 512 KB and archives up to 4 MB are scored, covering the first 262,144 characters; ' + form + ' show lists files that were only partly scanned or skipped.';
  } else if (!others) {
    closer = 'Please fix the failed checks, then run /prosecheck doctor again.';
  } else {
    closer = 'The install is healthy, but prosecheck is off: saving files triggers no scoring in this mode. Run ' + form + ' on to turn it back on so files are scored again.';
  }
  lines.push(closer);
  return lines.join('\n');
}

function showReply(sid) {
  const rows = lib.readLedger(sid);
  if (!rows.length) {
    return 'prosecheck: nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const out = ['prosecheck: files checked this session, newest first'];
  for (const r of rows.slice().reverse()) {
    let body;
    if (r.kind === 'scored') {
      body = lib.hookPhrase(r.band) + ' (score ' + r.score + '/' + r.band +
        (r.truncated ? ', first ' + lib.SCAN_WINDOW.toLocaleString('en-US') + ' characters only' : '') + ')';
      const labels = Array.isArray(r.labels) ? r.labels.slice(0, SHOW_LABEL_CAP) : [];
      if (labels.length) body += ' - ' + (r.flagged ? 'flagged' : 'under the threshold') + ': ' + labels.join('; ');
    } else if (r.kind === 'skipped') {
      body = 'not scored: file exceeds the ' + KB(r.capKB) + ' KB limit';
    } else if (r.kind === 'binary') {
      body = 'binary file, not re-scored';
    } else {
      body = 'not scored: ' + String(r.reason || 'the check failed').replace(/\d+\s*KB/gi, 'size limit');
    }
    out.push('  ' + r.base + ' - ' + body);
  }
  return out.join('\n');
}

function initReply(form) {
  const level = lib.currentLevel();
  if (level === 'off') {
    return 'prosecheck is switched off, so nothing was written. Run ' + form + ' on to allow the export.';
  }
  const lines = [];
  const cwd = process.cwd();
  const agents = path.join(cwd, 'AGENTS.md');
  const BEGIN = '<!-- prosecheck:begin -->';
  const END = '<!-- prosecheck:end -->';
  const section = BEGIN + '\n## Prose contract (prosecheck)\n\n' + lib.contractText(level, { portable: true }) + END + '\n';
  let existing = null;
  let readFail = false;
  try {
    if (fs.existsSync(agents)) existing = fs.readFileSync(agents, 'utf8');
  } catch (e) { readFail = true; }
  if (readFail) {
    lines.push('cannot read AGENTS.md, so the contract was not written there.');
  } else if (existing !== null && (existing.includes(BEGIN) || existing.includes('## Prose contract (prosecheck)'))) {
    lines.push('The contract is already present in AGENTS.md; the file was not changed.');
  } else {
    try {
      let add = section;
      if (existing !== null && existing.length) {
        add = (existing.endsWith('\n\n') ? '' : existing.endsWith('\n') ? '\n' : '\n\n') + section;
        fs.appendFileSync(agents, add);
      } else {
        fs.writeFileSync(agents, add);
      }
      lines.push('Wrote the ' + level + ' writing contract to AGENTS.md.');
    } catch (e) {
      lines.push('cannot write AGENTS.md, so the contract was not exported.');
    }
  }
  const rule = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(rule)) {
    lines.push('The Cursor rule prosecheck.mdc is already there; it was left as it was.');
  } else {
    try {
      let src = path.join(lib.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
      const data = fs.readFileSync(src);
      fs.mkdirSync(path.dirname(rule), { recursive: true });
      fs.writeFileSync(rule, data);
      lines.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      lines.push('cannot write .cursor/rules/prosecheck.mdc, so the Cursor rule was not created.');
      try { if (fs.existsSync(rule)) fs.unlinkSync(rule); } catch (e2) { /* */ }
    }
  }
  return lines.join('\n');
}

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }));
}

try {
  const p = lib.readStdinJson();
  const prompt = typeof p.prompt === 'string' ? p.prompt : '';
  const sid = typeof p.session_id === 'string' ? p.session_id : '';
  const trimmed = prompt.trim();
  const lower = trimmed.toLowerCase();
  const m = /^(\/prosecheck(?::prosecheck)?)(?:\s+([\s\S]*))?$/i.exec(trimmed);
  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    lib.storeLevel('off');
    block('prosecheck is off. Prose is no longer shaped or scored; use /prosecheck on to switch it back on.');
  } else if (m) {
    const typed = m[1].toLowerCase().startsWith('/prosecheck:') ? '/prosecheck:prosecheck' : '/prosecheck';
    const rest = (m[2] || '').trim();
    const sp = /^(\S+)(?:\s+([\s\S]*))?$/.exec(rest);
    const sub = sp ? sp[1].toLowerCase() : 'help';
    const arg = sp && sp[2] ? sp[2].trim() : '';
    const cwd = typeof p.cwd === 'string' && p.cwd ? p.cwd : process.cwd();
    if (!SUBS.includes(sub)) {
      block('prosecheck: unknown subcommand "' + sp[1] + '". Valid subcommands: ' + SUBS.join(', ') + '.');
    } else if (sub === 'help') {
      block(helpReply(lib.currentLevel()));
    } else if (sub === 'lite' || sub === 'full' || sub === 'strict') {
      lib.storeLevel(sub);
      block('prosecheck level set: ' + sub);
    } else if (sub === 'off') {
      lib.storeLevel('off');
      block('prosecheck is off.');
    } else if (sub === 'on') {
      lib.storeLevel('full');
      block('prosecheck is on (full).');
    } else if (sub === 'status') {
      block('prosecheck level: ' + lib.currentLevel());
    } else if (sub === 'show') {
      lib.pruneLedgers();
      block(showReply(sid));
    } else if (sub === 'check') {
      block(checkReply(arg, cwd));
    } else if (sub === 'doctor') {
      block(doctorReply(typed));
    } else if (sub === 'stats') {
      block(statsMod.stats(p.transcript_path));
    } else if (sub === 'init') {
      block(initReply(typed));
    }
  } else {
    const level = lib.currentLevel();
    if (level !== 'off') {
      process.stdout.write(JSON.stringify({
        hookSpecificOutput: {
          hookEventName: 'UserPromptSubmit',
          additionalContext: 'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.',
        },
      }));
    }
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
