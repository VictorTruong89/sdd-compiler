---
name: prosecheck
description: Rewrite flagged prose so it reads less like AI-generated text. Use when asked to "prosecheck this" or "humanize this".
---
Run `python3 scripts/detect.py <file>` from the plugin root, then rewrite the flagged spans in plain, varied prose.
Keep numbers, units, dates, names, citations, and quotes exactly. Never invent facts. Prose only, never code.
A score describes writing; it never names an author.
