#!/usr/bin/env python3
"""prosecheck detector: a local, deterministic AI-writing pattern scanner.

Standard library only (Python 3.9+). No network, no model, no randomness in
the default scan. Usage:

    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
    python3 scripts/detect.py --help

Spec anchors are given as `# spec: N-xxxxxx` comments next to the code that
satisfies them. See NOTES.md for every decision taken where the spec was open
or contradictory.
"""

import codecs
import io
import json
import math
import os
import random
import re
import sys
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

# spec: N-000245 N-000246 N-000247 N-000248 N-000249 N-000250 N-000251 N-000252 N-000253
WINDOW = 262144                     # scan window in characters (N-000292)
PLAIN_CAP = 512 * 1024              # plain text cap in bytes (binary KB)
ZIP_CAP = 4 * 1024 * 1024           # zip / notebook cap in bytes
PLAIN_EXTS = {".md", ".mdx", ".markdown", ".txt", ".text", ".rst", ".tex", ".org", ".adoc"}
ZIP_EXTS = {".docx", ".docm", ".pptx", ".pptm", ".xlsx", ".xlsm", ".odt", ".odp", ".ods", ".epub"}
NOTEBOOK_EXTS = {".ipynb"}
PROSE_EXTS = PLAIN_EXTS | ZIP_EXTS | NOTEBOOK_EXTS
NO_TEXT_EXTS = {".pdf", ".rtf"}

BANDS = [(20, "clean"), (40, "light tells"), (60, "mixed"), (80, "heavy tells"), (100, "pervasive tells")]

# ---------------------------------------------------------------------------
# Catalogue (spec: N-000128 .. N-000130, FP-01 numbering 1..71)
# ---------------------------------------------------------------------------
TITLES = {
    1: "AI vocabulary", 2: "model-dialect vocabulary", 3: "promotional language",
    4: "hyphenated word-pair overuse", 5: "“simple yet X” cliche", 6: "stacked adjective chains",
    7: "rule of three overuse", 8: "synonym cycling", 9: "generic character naming in fiction",
    10: "significance inflation", 11: "notability name-dropping", 12: "vague attributions",
    13: "article titles as proper nouns", 14: "conservation / ecosystem padding", 15: "false ranges",
    16: "superficial -ing tail clauses", 17: "negative parallelisms and tailing negations",
    18: "“Not X, just Y” framing", 19: "filler phrases", 20: "empty pivot phrases",
    21: "outcome speculation tails", 22: "persuasive authority tropes", 23: "editorial interjections",
    24: "self-thoroughness phrases", 25: "question-answer rhetorical pattern",
    26: "“concrete evidence” defense phrase", 27: "compulsive intro hooks",
    28: "meandering intro", 29: "prompt echo", 30: "diff-anchored writing",
    31: "signposting and announcements", 32: "cataloguing lead-ins", 33: "inline-header vertical lists",
    34: "mid-essay bullet injection", 35: "fragmented headers", 36: "formulaic challenges sections",
    37: "transition cluster overuse", 38: "compulsive conclusion phrases", 39: "generic positive conclusions",
    40: "sentence-length monotony", 41: "mechanical sentence-length alternation", 42: "opener repetition",
    43: "avoidance of fragments and run-ons", 44: "uniform paragraph length",
    45: "identical paragraph structure", 46: "semicolon and parenthesis underuse", 47: "chatbot artifacts",
    48: "sycophantic tone", 49: "RLHF helpful-assistant register", 50: "knowledge-cutoff disclaimers",
    51: "copula avoidance", 52: "passive voice and subjectless fragments", 53: "two-way passive-voice drift",
    54: "hedge stacking", 55: "contraction absence", 56: "boldface overuse", 57: "emojis",
    58: "em-dash overuse", 59: "title case in headings", 60: "curly quotation marks",
    61: "hyphen-for-en-dash in numeric ranges", 62: "invisible or zero-width characters",
    63: "placeholder text", 64: "chatbot reference-markup leak", 65: "AI tracking parameters",
    66: "homoglyph or mixed-script lookalikes", 67: "non-standard spaces", 68: "trailing or stray whitespace",
    69: "canonical marketing-slop phrases", 70: "decorative horizontal rules", 71: "degenerate repetition",
}
# Numbers with no detector (spec: FP-01 "Normal behavior").
NO_DETECTOR = {7, 9, 28, 29, 43, 45, 49, 52, 53}
# Writing advice: reported, weight zero (FP-01; 17 per Interface Contract N-000750).
ADVICE = {4, 17, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
# Decisive families (FP-01 N-000135).
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
# Rhythm kinds (FP-01 N-000140).
RHYTHM = {40, 41, 44, 55}
# Families counted for the short-document floor (FP-01 N-000138).
SHORT_DOC_FAMILIES = set(range(1, 40)) | set(range(47, 52)) | {69}

GUARD_LABEL_CAP = 5
CHECK_LABEL_CAP = 8
SHOW_LABEL_CAP = 5


def band_for(score):
    for top, name in BANDS:
        if score <= top:
            return name
    return BANDS[-1][1]


# ---------------------------------------------------------------------------
# Input reading and extraction (FP-02)
# ---------------------------------------------------------------------------
class InputError(Exception):
    def __init__(self, message, code=1):
        Exception.__init__(self, message)
        self.message = message
        self.code = code


def decode_text(data):
    """Decode plain text: UTF-8 (optional BOM) or UTF-16 with a BOM. spec: N-000241 N-000254

    CRLF line endings become LF (carriage-return/line-feed adds no finding, N-000220).
    """
    if data.startswith(codecs.BOM_UTF8):
        text = data[len(codecs.BOM_UTF8):].decode("utf-8", errors="replace")
    elif data.startswith(codecs.BOM_UTF16_LE):
        text = data[2:].decode("utf-16-le", errors="replace")
    elif data.startswith(codecs.BOM_UTF16_BE):
        text = data[2:].decode("utf-16-be", errors="replace")
    else:
        text = data.decode("utf-8", errors="replace")
    return text.replace("\r\n", "\n")


def _local(tag):
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def _xml_root(raw):
    try:
        return ET.fromstring(raw)
    except ET.ParseError:
        return None


def _docx_text(zf):
    # spec: N-000256 visible paragraph text of the main document
    root = _xml_root(zf.read("word/document.xml"))
    if root is None:
        return ""
    paras = []
    for el in root.iter():
        if _local(el.tag) != "p":
            continue
        buf = []
        for sub in el.iter():
            name = _local(sub.tag)
            if name == "t" and sub.text:
                buf.append(sub.text)
            elif name == "tab":
                buf.append("\t")
            elif name in ("br", "cr"):
                buf.append("\n")
        paras.append("".join(buf))
    return "\n".join(paras)


def _pptx_text(zf):
    # spec: N-000257 slides in slide order
    names = [n for n in zf.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)]
    names.sort(key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
    out = []
    for name in names:
        root = _xml_root(zf.read(name))
        if root is None:
            continue
        for el in root.iter():
            if _local(el.tag) == "p":
                buf = [s.text for s in el.iter() if _local(s.tag) == "t" and s.text]
                if buf:
                    out.append("".join(buf))
    return "\n".join(out)


def _xlsx_text(zf):
    # spec: N-000258 .. N-000263 cell text sheet by sheet, shared strings by index
    shared = []
    if "xl/sharedStrings.xml" in zf.namelist():
        root = _xml_root(zf.read("xl/sharedStrings.xml"))
        if root is not None:
            for si in root:
                if _local(si.tag) == "si":
                    shared.append("".join(t.text or "" for t in si.iter() if _local(t.tag) == "t"))
    rels = {}
    if "xl/_rels/workbook.xml.rels" in zf.namelist():
        root = _xml_root(zf.read("xl/_rels/workbook.xml.rels"))
        if root is not None:
            for el in root.iter():
                if _local(el.tag) == "Relationship":
                    rels[el.get("Id")] = el.get("Target")
    sheet_paths = []
    if "xl/workbook.xml" in zf.namelist():
        root = _xml_root(zf.read("xl/workbook.xml"))
        if root is not None:
            for el in root.iter():
                if _local(el.tag) == "sheet":
                    rid = None
                    for k, v in el.attrib.items():
                        if _local(k) == "id":
                            rid = v
                    target = rels.get(rid, "")
                    if target:
                        target = target.lstrip("/")
                        if not target.startswith("xl/"):
                            target = "xl/" + target
                        sheet_paths.append(target)
    if not sheet_paths:
        sheet_paths = sorted(n for n in zf.namelist() if re.match(r"xl/worksheets/sheet\d+\.xml$", n))
    out = []
    for path in sheet_paths:
        if path not in zf.namelist():
            continue
        root = _xml_root(zf.read(path))
        if root is None:
            continue
        for c in root.iter():
            if _local(c.tag) != "c":
                continue
            ctype = c.get("t", "n")
            value = None
            if ctype == "s":
                v = c.find("{*}v")
                if v is not None and v.text and v.text.strip().isdigit():
                    idx = int(v.text.strip())
                    if idx < len(shared):
                        value = shared[idx]
            elif ctype == "inlineStr":
                value = "".join(t.text or "" for t in c.iter() if _local(t.tag) == "t")
            elif ctype == "str":
                v = c.find("{*}v")
                value = v.text if v is not None else None
            if value:
                out.append(value)
    return "\n".join(out)


def _odf_text(zf):
    # spec: N-000264 .. N-000266 visible text of content.xml; spaces, tabs, line breaks kept
    root = _xml_root(zf.read("content.xml"))
    if root is None:
        return ""
    paras = []

    def walk(el, buf):
        name = _local(el.tag)
        if name == "s":
            try:
                n = int(el.get("{urn:oasis:names:tc:opendocument:xmlns:text:1.0}c", "1"))
            except ValueError:
                n = 1
            buf.append(" " * n)
        elif name == "tab":
            buf.append("\t")
        elif name == "line-break":
            buf.append("\n")
        elif name in ("p", "h"):
            inner = []
            if el.text:
                inner.append(el.text)
            for child in el:
                walk(child, inner)
                if child.tail:
                    inner.append(child.tail)
            paras.append("".join(inner))
            return
        else:
            if el.text:
                buf.append(el.text)
            for child in el:
                walk(child, buf)
                if child.tail:
                    buf.append(child.tail)

    body = None
    for el in root.iter():
        if _local(el.tag) == "body":
            body = el
            break
    walk(body if body is not None else root, [])
    return "\n".join(p for p in paras)


class _EpubHTML(HTMLParser):
    BLOCK = {"p", "div", "br", "li", "h1", "h2", "h3", "h4", "h5", "h6", "tr", "section", "blockquote"}
    SKIP = {"script", "style", "nav", "head", "title"}

    def __init__(self):
        HTMLParser.__init__(self)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in self.SKIP and self.skip:
            self.skip -= 1
        elif tag in self.BLOCK:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def _epub_text(zf):
    # spec: N-000267 .. N-000270 chapter XHTML; navigation, style, script excluded
    chapters = []
    for name in sorted(zf.namelist()):
        low = name.lower()
        if not low.endswith((".xhtml", ".html", ".htm")):
            continue
        base = low.rsplit("/", 1)[-1]
        if "nav" in base or "toc" in base:
            continue
        chapters.append(name)
    out = []
    for name in chapters:
        parser = _EpubHTML()
        try:
            parser.feed(zf.read(name).decode("utf-8", errors="replace"))
            parser.close()
        except Exception:  # noqa: BLE001 - a bad chapter must not drop the book
            continue
        text = "".join(parser.parts)
        text = re.sub(r"[ \t\r\f\v]+", " ", text)
        text = re.sub(r" *\n *", "\n", text)
        text = re.sub(r"\n{2,}", "\n\n", text).strip()
        if text:
            out.append(text)
    return "\n\n".join(out)


def _notebook_text(data):
    # spec: N-000271 .. N-000272 markdown cells only; invalid JSON yields empty prose
    try:
        nb = json.loads(data.decode("utf-8-sig", errors="replace"))
    except ValueError:
        return ""
    cells = nb.get("cells") if isinstance(nb, dict) else None
    if not isinstance(cells, list):
        return ""
    out = []
    for cell in cells:
        if not isinstance(cell, dict) or cell.get("cell_type") != "markdown":
            continue
        src = cell.get("source", "")
        if isinstance(src, list):
            if not all(isinstance(s, str) for s in src):
                continue
            src = "".join(src)
        if not isinstance(src, str):
            continue
        if src.strip():
            out.append(src.strip("\n"))
    return "\n".join(out)


def extract_source(path):
    """Return extracted prose for `path` (None means standard input). spec: FP-02."""
    if path is None:
        try:
            data = sys.stdin.buffer.read()
        except (OSError, ValueError) as exc:
            raise InputError("cannot read input: standard input: %s" % exc)
        return decode_text(data)
    ext = os.path.splitext(path)[1].lower()
    if ext in NO_TEXT_EXTS:
        return ""
    try:
        with open(path, "rb") as fh:
            data = fh.read()
    except OSError as exc:
        raise InputError("cannot read input: %s" % (exc.strerror or exc))
    if ext in ZIP_EXTS:
        try:
            zf = zipfile.ZipFile(io.BytesIO(data))
        except zipfile.BadZipFile:
            raise InputError("cannot read input: %s is not a readable zip archive" % os.path.basename(path))
        with zf:
            try:
                if ext in (".docx", ".docm"):
                    text = _docx_text(zf)
                elif ext in (".pptx", ".pptm"):
                    text = _pptx_text(zf)
                elif ext in (".xlsx", ".xlsm"):
                    text = _xlsx_text(zf)
                elif ext in (".odt", ".odp", ".ods"):
                    text = _odf_text(zf)
                else:
                    text = _epub_text(zf)
            except (KeyError, zipfile.BadZipFile, ValueError):
                text = ""
        return text.strip()
    if ext in NOTEBOOK_EXTS:
        return _notebook_text(data).strip()
    return decode_text(data)


# ---------------------------------------------------------------------------
# Character layer (FP-01 rules 62, 66, 67; FP-03 cleanup)
# ---------------------------------------------------------------------------
SPACELESS_SCRIPTS = re.compile("[\u0e00-\u0e7f\u0e80-\u0eff\u1000-\u109f\u1780-\u17ff\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]")
JOINING_SCRIPTS = re.compile("[\u0590-\u05ff\u0600-\u06ff\u0900-\u0dff\u1000-\u109f\u1780-\u17ff]")
RTL_SCRIPTS = re.compile("[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufefc]")
EMOJI_LIKE = re.compile("[\U0001F000-\U0001FAFF☀-➿⬀-⯿⌀-⏿]")
CJK_IDEO = re.compile("[㐀-䶿一-鿿豈-﫿\U00020000-\U0002fa1f]")

# Lookalike letters from other scripts -> ASCII (FP-01 rule 66, FP-03 folding).
CONFUSABLES = {}
for _src, _dst in [
    ("а", "a"), ("с", "c"), ("е", "e"), ("һ", "h"), ("і", "i"), ("ј", "j"),
    ("ԁ", "d"), ("ɡ", "g"), ("о", "o"), ("р", "p"), ("ѕ", "s"), ("у", "y"),
    ("х", "x"), ("ԝ", "w"), ("ν", "v"), ("ο", "o"), ("ρ", "p"), ("υ", "u"),
    ("ɑ", "a"), ("ѵ", "v"), ("ո", "n"), ("ս", "u"), ("օ", "o"),
    ("А", "A"), ("В", "B"), ("С", "C"), ("Е", "E"), ("Н", "H"), ("І", "I"),
    ("Ј", "J"), ("К", "K"), ("М", "M"), ("О", "O"), ("Р", "P"), ("Ѕ", "S"),
    ("Т", "T"), ("Х", "X"), ("Υ", "Y"), ("Ζ", "Z"), ("Α", "A"), ("Β", "B"),
    ("Ε", "E"), ("Η", "H"), ("Ι", "I"), ("Κ", "K"), ("Μ", "M"), ("Ν", "N"),
    ("Ο", "O"), ("Ρ", "P"), ("Τ", "T"), ("Χ", "X"), ("Ս", "U"),
]:
    CONFUSABLES[_src] = _dst


def _is_invisible_candidate(cp, ch):
    if ch in "\t\n\r":
        return False
    if cp < 0x20 or 0x7F <= cp <= 0x9F:
        return True
    if 0xE0000 <= cp <= 0xE0FFF:
        return True
    if 0xFE00 <= cp <= 0xFE0F:
        return True
    if cp in (0x034F, 0x115F, 0x1160, 0x3164, 0xFFA0, 0x17B4, 0x17B5):
        return True
    if 0x180B <= cp <= 0x180F:
        return True
    cat = unicodedata.category(ch)
    return cat == "Cf"


def invisible_indices(s):
    """Indices of invisible characters that cleanup removes. spec: N-000303 .. N-000305"""
    rtl_doc = bool(RTL_SCRIPTS.search(s))
    removed = set()
    n = len(s)
    for i, ch in enumerate(s):
        cp = ord(ch)
        if not _is_invisible_candidate(cp, ch):
            continue
        prev = s[i - 1] if i > 0 else ""
        nxt = s[i + 1] if i + 1 < n else ""
        keep = False
        if 0xE0020 <= cp <= 0xE007F:
            j = i - 1
            while j >= 0 and 0xE0020 <= ord(s[j]) <= 0xE007F:
                j -= 1
            keep = j >= 0 and ord(s[j]) == 0x1F3F4
        elif 0xE0100 <= cp <= 0xE01EF:
            keep = bool(prev) and bool(CJK_IDEO.match(prev))
        elif 0xFE00 <= cp <= 0xFE0F:
            keep = (bool(prev) and bool(EMOJI_LIKE.match(prev) or CJK_IDEO.match(prev)
                                        or unicodedata.category(prev) in ("So", "Sm"))) \
                or nxt == "⃣"
        elif cp == 0x200B:
            keep = bool(SPACELESS_SCRIPTS.match(prev)) or bool(SPACELESS_SCRIPTS.match(nxt))
        elif cp in (0x200C, 0x200D):
            keep = bool(JOINING_SCRIPTS.match(prev) or JOINING_SCRIPTS.match(nxt)
                        or EMOJI_LIKE.match(prev) or EMOJI_LIKE.match(nxt)
                        or unicodedata.category(prev) in ("So", "Sm")
                        or unicodedata.category(nxt) in ("So", "Sm"))
        elif cp == 0x00AD:
            keep = prev.isalpha() and nxt.isalpha()
        elif cp in (0x200E, 0x200F, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E, 0x2066, 0x2067, 0x2068, 0x2069, 0x061C):
            keep = rtl_doc
        elif 0x180B <= cp <= 0x180F:
            keep = bool(prev) and 0x1800 <= ord(prev) <= 0x18AF
        elif cp in (0x17B4, 0x17B5):
            keep = bool(SPACELESS_SCRIPTS.match(prev) or re.match("[ក-៿]", prev)
                        or re.match("[ក-៿]", nxt))
        if not keep:
            removed.add(i)
    return removed


def nbsp_kept(s, i):
    """No-break spaces that hold something together are kept. spec: N-000306 .. N-000309"""
    prev = s[i - 1] if i > 0 else ""
    nxt = s[i + 1] if i + 1 < len(s) else ""
    if prev.isdigit() or nxt.isdigit():
        return True
    if nxt and nxt in ":;!?»›%€":
        return True
    if prev and prev in "«‹":
        return True
    return False


def nonstandard_space_indices(s):
    out = set()
    for i, ch in enumerate(s):
        if ch == " ":
            continue
        if unicodedata.category(ch) == "Zs":
            if ch in ("\u00a0", "\u202f") and nbsp_kept(s, i):
                continue
            out.add(i)
    return out



_TOKEN_RE = re.compile(r"\S+")


def homoglyph_tokens(s):
    """Tokens that mix ASCII Latin letters with lookalikes and no other non-ASCII letter. spec: N-000177"""
    hits = []
    for m in _TOKEN_RE.finditer(s):
        tok = m.group(0)
        latin = conf = other = False
        for ch in tok:
            if ch.isascii():
                if ch.isalpha():
                    latin = True
            elif ch in CONFUSABLES:
                conf = True
            elif ch.isalpha():
                other = True
        if latin and conf and not other:
            hits.append(m)
    return hits


def fold_homoglyphs(s):
    pieces = []
    last = 0
    for m in homoglyph_tokens(s):
        pieces.append(s[last:m.start()])
        pieces.append("".join(CONFUSABLES.get(c, c) for c in m.group(0)))
        last = m.end()
    pieces.append(s[last:])
    return "".join(pieces)


def trailing_ws_count(s):
    """Lines with trailing spaces/tabs, plus end-of-text and leading whitespace. spec: N-000180 .. N-000181"""
    if not s:
        return 0
    count = 0
    for line in s.split("\n"):
        if line.endswith((" ", "\t")):
            count += 1
    if s.endswith("\n\n"):
        count += 1
    if s[0] in " \t\n\r\f\v":
        count += 1
    return count


def cleanup_text(s):
    """Deterministic cleanup for FP-03. spec: N-000301 .. N-000331"""
    gone = invisible_indices(s)
    s = "".join(ch for i, ch in enumerate(s) if i not in gone)
    spaces = nonstandard_space_indices(s)
    out = []
    for i, ch in enumerate(s):
        if i in spaces:
            out.append(" ")
        elif unicodedata.category(ch) in ("Zl", "Zp"):
            out.append("\n")
        else:
            out.append(ch)
    s = "".join(out)
    s = fold_homoglyphs(s)
    ends_nl = s.endswith("\n")
    lines = [line.rstrip(" \t") for line in s.split("\n")]
    body = "\n".join(lines).lstrip("\n").rstrip()
    if ends_nl and body:
        body += "\n"
    return body


# ---------------------------------------------------------------------------
# Markdown masking: code, quotes, tables, badges, front matter (FP-01 N-000149)
# ---------------------------------------------------------------------------
_FENCE_OPEN = re.compile(r"^ {0,3}(`{3,}|~{3,})")
_BLOCKQUOTE = re.compile(r"^\s*>")
_TABLE_ROW = re.compile(r"^\s*\|.*\|\s*$")
_BADGE = re.compile(r"^\s*(\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$")
_INLINE_CODE = re.compile(r"(`+)(?!`)(.+?)(?<!`)\1(?!`)")


def mask_prose(text):
    lines = text.split("\n")
    keep = [True] * len(lines)
    # YAML front matter at the very start
    if lines and lines[0].strip() == "---":
        for j in range(1, len(lines)):
            if lines[j].strip() in ("---", "..."):
                for k in range(0, j + 1):
                    keep[k] = False
                break
    # fenced code blocks
    i = 0
    while i < len(lines):
        m = _FENCE_OPEN.match(lines[i])
        if m and (keep[i]):
            fence = m.group(1)
            ch, flen = fence[0], len(fence)
            close_re = re.compile(r"^ {0,3}" + re.escape(ch) + "{%d,}\\s*$" % flen)
            j = i + 1
            while j < len(lines) and not close_re.match(lines[j]):
                j += 1
            for k in range(i, min(j, len(lines) - 1) + 1):
                keep[k] = False
            i = j + 1
            continue
        i += 1
    # blockquote runs of 2+, table rows, badge lines
    i = 0
    while i < len(lines):
        if keep[i] and _BLOCKQUOTE.match(lines[i]):
            j = i
            while j < len(lines) and _BLOCKQUOTE.match(lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    keep[k] = False
            i = j
            continue
        i += 1
    for i, line in enumerate(lines):
        if keep[i] and (_TABLE_ROW.match(line) or _BADGE.match(line)):
            keep[i] = False
    out = []
    for i, line in enumerate(lines):
        if not keep[i]:
            out.append("")
            continue
        out.append(_INLINE_CODE.sub(lambda m: " " * len(m.group(0)), line))
    return "\n".join(out)


# ---------------------------------------------------------------------------
# Helpers for pattern checks
# ---------------------------------------------------------------------------
WORD_RE = re.compile(r"(?:[^\W_]|['\-])+")
SENT_SPLIT = re.compile(r"(?<=[.!?…])\s+")


def words_of(text):
    return [w for w in WORD_RE.findall(text) if any(c.isalnum() for c in w)]


def excerpt(text, start, end):
    a = max(0, start - 30)
    b = min(len(text), end + 30)
    snippet = re.sub(r"\s+", " ", text[a:b]).strip()
    if len(snippet) > 100:
        snippet = snippet[:97] + "..."
    if a > 0:
        snippet = "..." + snippet
    if b < len(text):
        snippet = snippet + "..."
    return snippet


def inflect(word):
    """Regex for a word and its common inflections (FP-01 family rules)."""
    w = re.escape(word)
    if word.endswith("e"):
        stem = re.escape(word[:-1])
        return stem + r"(?:e|es|ed|ing)?"
    if word.endswith("y"):
        stem = re.escape(word[:-1])
        return stem + r"(?:y|ies|ied|ying)?"
    return w + r"(?:s|es|ed|ing)?"


def phrase_re(phrase):
    parts = [re.escape(p) for p in phrase.split(" ")]
    return r"\s+".join(parts)


def alt(items, inflected=False):
    pats = []
    for it in items:
        if inflected and " " not in it:
            pats.append(inflect(it))
        else:
            pats.append(phrase_re(it))
    return r"\b(?:" + "|".join(pats) + r")\b"


class Finding(object):
    __slots__ = ("num", "slug", "label", "count", "samples")

    def __init__(self, num, slug, count, samples, label=None):
        self.num = num
        self.slug = slug
        self.label = label or TITLES[num]
        self.count = count
        self.samples = samples[:3]


def rx_finds(text, pattern, flags=re.I):
    ms = list(re.finditer(pattern, text, flags))
    return ms, [excerpt(text, m.start(), m.end()) for m in ms[:3]]


# ---------------------------------------------------------------------------
# Pattern lists
# ---------------------------------------------------------------------------
AI_VOCAB = ["additionally", "align with", "crucial", "delve", "tapestry", "pivotal", "vibrant", "meticulous",
            "testament", "underscore", "intricate", "intricacies", "interplay", "garner", "bolster", "foster",
            "showcase", "emphasize", "enduring", "enhance", "leverage", "utilize", "facilitate", "encompass",
            "harness", "holistic", "paradigm", "transformative", "unprecedented", "myriad", "plethora", "robust",
            "seamless", "navigate", "embark", "craft", "landscape", "journey", "realm", "multifaceted",
            "elevate", "empower", "unlock", "landscape"]
AI_VOCAB_RE = r"\b(?:" + "|".join(
    [phrase_re(w) if " " in w else inflect(w) for w in AI_VOCAB]) + r"|capture\s+the\s+(?:essence|spirit|imagination|heart|magic))\b"

DIALECT_PATTERNS = [
    r"\bgenuinely\b", r"\bfascinating\b", r"\bnuanced\b", r"\bthoughtfully\b", r"\brefreshingly\b",
    r"\bstrikingly\b", r"\bcompellingly\b", r"\bquietly\s+(?:powerful|profound|radical)\b",
    r"\bdeeply\s+(?:human|personal|felt|unsettling)\b", r"\bresonates\s+deeply\b",
    r"\bgame[\s-]changer\b", r"\bgame[\s-]changing\b", r"\bsupercharg(?:e|es|ed|ing)\b",
    r"\bskyrocket(?:s|ed|ing)?\b", r"\bturbocharg(?:e|es|ed|ing)\b", r"\brevolutioniz(?:e|es|ed|ing)\b",
    r"\bdouble\s+down\s+on\b", r"\bdive\s+deep(?:er)?\s+into\b",
    r"\bunlock\s+(?:the\s+)?(?:power|potential|value)\b", r"\btake\s+[^.!?\n]{1,40}?\s+to\s+the\s+next\s+level\b",
]

PROMO = ["nestled", "breathtaking", "must-visit", "stunning", "picturesque", "charming", "idyllic",
         "vibrant community", "rich cultural heritage", "in the heart of", "world-class", "top-tier",
         "unparalleled", "premier", "esteemed organization", "valuable asset", "passion for excellence",
         "proven track record", "results-oriented", "wealth of experience", "dynamic team",
         "fast-paced environment", "deeply passionate", "perfectly situated", "close-knit team",
         "tight-knit team", "uniquely positioned to"]
PROMO_IMPERATIVES = ("install", "join", "grab", "download", "try", "discover", "experience", "escape",
                     "transform", "reclaim", "unlock", "elevate", "boost", "say", "imagine", "explore", "meet",
                     "introducing", "upgrade", "claim", "unleash", "supercharge", "level", "stop", "start")

SIG_INFL = [
    r"\b(?:stands?|serves?|stood|served)\s+as\s+an?\s+(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b",
    r"\b(?:underscores?|underscored|underscoring|highlights?|highlighted|highlighting)\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b",
    r"\breflects\s+a\s+broader\s+(?:trend|shift|pattern)\b",
    r"\bmarks\s+a\s+(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)\b",
    r"\bsymbolizes\b",
    r"\bsets\s+the\s+stage\s+for\b",
    r"\bleft\s+an\s+indelible\s+mark\b",
    r"\bplays\s+a\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b",
    r"\b(?:has|have)\s+(?:shaped|sparked)\b", r"\bhas\s+come\s+to\s+(?:define|symbolize)\b",
]
VAGUE_ATTR = [
    r"\bexperts?\s+(?:argue|believe|say|claim|note|suggest)\b", r"\bindustry\s+(?:reports|observers|analysts)\b",
    r"\bobservers\s+(?:have\s+)?(?:cited|noted)\b", r"\bsome\s+critics\s+argue\b",
    r"\bresearchers\s+have\s+found\b", r"\bstudies\s+suggest\b", r"\bit\s+is\s+widely\s+believed\b",
]
CONSERVATION = [
    r"\bplays\s+a\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b",
    r"\bconservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)\b",
    r"\bserves\s+as\s+an\s+indicator\s+species\b", r"\bcontributes\s+to\s+biodiversity\b",
]
FALSE_RANGE = [
    r"\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]*?\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b",
    r"\bfrom\s+(?:the\s+)?humble\b[^.!?\n]*?\bto\s+(?:the\s+)?(?:mighty|towering|grand|sprawling)\b",
]
ING_TAILS = (r",\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|"
             r"cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|"
             r"indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b")
PARALLEL = [
    r"\bit['’]s\s+not\s+(?:just|merely)\s+(?:about|an?)\b",
    r"\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b",
    r"\bdoesn['’]t\s+just\b[^,.\n]{0,40}?\bit\b",
]
TAIL_NEG = r",\s+no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b"
NOT_X_JUST_Y = [
    r"\b(?:no|not)\s+\w+,\s+(?:just|only|simply)\s+\w+",
    r"\b(?:not|isn['’]t|aren['’]t|wasn['’]t|weren['’]t)\s+(?:just|merely)\s+(?:a|an|the)\s+\w+\s*[,—-]\s*(?:it['’]s|it\s+is|it\s+was|they['’]re|they\s+are|they\s+were|that['’]s|but)\b",
]
EMPTY_PIVOT = [
    r"\bit['’]s\s+worth\s+(?:noting|mentioning)\s+that\b", r"\bit\s+bears\s+(?:noting|mentioning)\s+that\b",
    r"\bone\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is\b", r"\bit\s+is\s+interesting\s+to\s+note\s+that\b",
    r"\ba\s+key\s+consideration\s+is\b", r"\ba\s+point\s+to\s+highlight\s+is\b",
]
OUTCOME_TAILS = (r",\s+(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about|"
                 r"with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for|"
                 r"signaling\s+a\s+shift\s+toward)\b")
INTRO_HOOKS = [
    r"\bin\s+today['’]s\s+(?:\w+\s+){0,2}?(?:world|landscape|environment|market)\b",
    r"\bin\s+a\s+world\s+where\b", r"\bin\s+an\s+era\s+of\b", r"\bin\s+recent\s+years,",
    r"\bmore\s+than\s+ever\s+before\b", r"\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b",
    r"\b(?:great|exciting|big)\s+news\s*[!:]", r"\bever\s+(?:wanted|wondered|dreamed|wished)\b[^?\n]{0,80}\?",
    r"\bin\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world\b",
]
CHALLENGES = [
    r"\bdespite\s+(?:these|its|the)\s+(?:challenges|obstacles)\b",
    r"\bchallenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)\b", r"\bcontinues\s+to\s+thrive\b",
    r"\btypical\s+of\s+(?:emerging|urban|modern)\b", r"\bfaces\s+(?:several|many|numerous)\s+challenges\b",
]
CONCLUSION_GENERIC = [
    r"\bthe\s+future\s+looks\s+bright\b", r"\bexciting\s+times\s+lie\s+ahead\b",
    r"\bjourney\s+toward\s+excellence\b", r"\bstep\s+in\s+the\s+right\s+direction\b",
    r"\b(?:the\s+)?(?:outlook|future)(?:\s+for\s+[^.!?\n]{1,40})?\s+(?:is|looks|remains)\s+bright\b",
    r"\bwell[\s-]positioned\s+for\s+(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)\b",
]
FILLER = [r"\bin\s+order\s+to\b", r"\bdue\s+to\s+the\s+fact\s+that\b", r"\bat\s+this\s+point\s+in\s+time\b",
          r"\bin\s+the\s+event\s+that\b", r"\bhas\s+the\s+ability\s+to\b",
          r"\bit\s+is\s+important\s+to\s+note\s+that\b", r"\bit\s+should\s+be\s+mentioned\s+that\b",
          r"\bneedless\s+to\s+say\b"]
PERSUASIVE = [r"\bhere['’]s\s+the\s+thing\b", r"\bmake\s+no\s+mistake\b", r"\bthe\s+truth\s+is\b",
              r"\blet['’]s\s+be\s+honest\b", r"\bthe\s+simple\s+fact\s+is\b", r"\bat\s+its\s+core\b",
              r"\bwhat\s+really\s+matters\b", r"\bmore\s+than\s+anything\b", r"\bat\s+the\s+end\s+of\s+the\s+day\b",
              r"\bthe\s+bottom\s+line\s+is\b", r"\bin\s+reality\b", r"\bfundamentally,",
              r"\bthe\s+real\s+question\s+is\b", r"\bthe\s+heart\s+of\s+the\s+matter\b",
              r"\bthe\s+deeper\s+issue\b", r"\bwhen\s+you\s+get\s+down\s+to\s+it\b",
              r"\bwhen\s+all\s+is\s+said\s+and\s+done\b"]
SELF_THOROUGH = [
    r"\bthis\s+(?:comprehensive|in-depth|complete)\s+(?:guide|overview|analysis)\b",
    r"\bthis\s+in-depth\s+(?:look|examination)\b", r"\ba\s+thorough\s+examination\s+of\b",
    r"\beverything\s+you\s+need\s+to\s+know\s+about\b", r"\bthis\s+complete\s+(?:guide|overview)\b",
]
CHATBOT = [
    r"\bI\s+hope\s+this\s+helps\b", r"\bCertainly!", r"\bOf\s+course!", r"\blet\s+me\s+know\s+if\s+you\b",
    r"\bwould\s+you\s+like\s+me\s+to\b", r"\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b",
    r"\bhappy\s+to\s+help[.!]", r"\bhere\s+(?:is|are|['’]s)\s+(?:a|an|the)\s+(?:overview|summary|rundown|recap|brief)\b",
    r"\bhere\s+are\s+(?:some|a\s+few|two|three)\s+(?:options|drafts|versions|variations)\b",
    r"\bhere\s+(?:['’]s|is)\s+a\s+few\s+(?:options|drafts|versions|variations)\b",
    r"\bhere\s+is\s+(?:a\s+draft|the\s+(?:draft|first\s+pass|revised\s+version\s+of)|your)\b",
    r"\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b", r"\bI\s+hope\s+(?:this\s+email\s+)?finds\s+you\s+well\b",
    r"\bas\s+an\s+(?:AI|LLM|AI\s+assistant|AI\s+language\s+model|large\s+language\s+model|language\s+model)\b",
    r"\bto\s+(?:answer|address)\s+your\s+question\b", r"\bin\s+response\s+to\s+your\s+question\b",
    r"\byour\s+question\s+(?:about|regarding|concerning)\b", r"\bas\s+you\s+(?:requested|asked),\s+here\b",
]
SYCOPHANCY = [
    r"\byou(?:['’]re|\s+are)\s+absolutely\s+right\b",
    r"\b(?:great|excellent|fantastic|wonderful|brilliant)\s+(?:question|point)\s*[!.,]",
    r"\bwhat\s+a\s+(?:thoughtful|great|wonderful|fantastic)\s+question\b",
    r"\bthat['’]s\s+a\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\b",
]
CUTOFF = [
    r"\bas\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)\b", r"\bup\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)\b",
    r"\bwhile\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+(?:extensively|widely)\s+documented)\b",
    r"\bbased\s+on\s+(?:the\s+)?available\s+information\b", r"\bas\s+of\s+my\s+(?:knowledge\s+)?cutoff\b",
    r"\bmaintains\s+a\s+low\s+profile\b", r"\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b",
]
COPULA = [
    r"\b(?:serves|stands|functions|acts)\s+as\s+(?:a|an|the)\b", r"\brepresents\s+(?:a|the)\b",
    r"\bmarks\s+(?:a|the)\b", r"\bboasts\b",
    r"\bfeatures\s+(?:a|an|the|\d+|several|many|numerous|various)\b", r"\boffers\s+a\b", r"\brefers\s+to\b",
]
HEDGES = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems?\s+(?:to|like)|"
                    r"appears?\s+to|somewhat|relatively|fairly|kind\s+of|sort\s+of)\b")
DIALECT_HITS_NEEDED = 2

INLINE_HEADER = re.compile(r"^\s*(?:[-*+]\s+|\d+[.)]\s+)?(?:\*\*[^*\n]{1,80}:\*\*|\*\*[^*\n]{1,80}\*\*:)", re.M)
HEADING = re.compile(r"^(#{1,6})\s+(.+?)\s*#*\s*$", re.M)
TRANSITIONS = re.compile(r"(?:^|(?<=[.!?])\s+)(Additionally|Furthermore|Moreover|However|Nevertheless|"
                         r"Consequently|Subsequently|Notably)\b", re.M)
CONCLUSIONS = re.compile(r"^\s*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|"
                         r"in essence|ultimately)\b[,:]?", re.I | re.M)
PLACEHOLDERS = [
    r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![\(\[])",
    r"\[[^\]\n]{0,60}\b(?:name|company|client|place|source)\b[^\]\n]{0,40}\](?![\(\[])",
    r"\[[A-Z][A-Z ]{2,}\](?![\(\[])", r"\{\{[^}\n]*\}\}", r"\bx{3,}\b", r"\blorem\s+ipsum\b",
]
CHAT_MARKUP = r"\bcite(?:turn|start|nav)\w*|\boai_citation\w*|\bcontentReference\w*|\bnavlist\w*|【\d+†[^】]*】"
UTM = re.compile(r"utm_source=(?:chatgpt\.com|chat\.openai\.com|perplexity\.ai|claude\.ai|gemini\.google\.com|"
                 r"copilot\.microsoft\.com|poe\.com)(?![\w.-])", re.I)
MARKETING_SLOP = [
    r"\bunlocking\s+(?:your\s+|full\s+)?(?:full\s+)?potential\b", r"\bnavigating\s+the\s+complexities\b",
    r"\ba\s+testament\s+to\s+the\s+(?:power|importance)\s+of\b", r"\bstaying\s+ahead\s+of\s+the\s+curve\b",
    r"\bturning\s+challenges\s+into\s+opportunities\b", r"\btaking\s+[^.!?\n]{1,30}?\s+to\s+the\s+next\s+level\b",
    r"\bharnessing\s+the\s+power\s+of\b", r"\bpaving\s+the\s+way\s+for\b", r"\bsaying\s+goodbye\s+to\b",
    r"\bimagining\s+a\s+world\s+where\b", r"\bgame-changing\s+solution\b",
]
HYPHEN_PAIRS = [
    "cutting-edge", "state-of-the-art", "next-generation", "best-in-class", "user-centric", "data-driven",
    "results-driven", "detail-oriented", "forward-thinking", "value-driven", "customer-centric", "high-impact",
]
EMOJI_RE = re.compile("[\U0001F000-\U0001FAFF☀-⛿✀-➿]")
EM_DASH = "—"
CURLY = re.compile("[“”‘’]")
YEAR_RANGE = re.compile(r"\b(1[0-9]{3}|20[0-9]{2})-(1[0-9]{3}|20[0-9]{2})\b")
MAJOR_SKIP = {"a", "an", "the", "and", "but", "or", "nor", "for", "so", "yet", "of", "in", "on", "at", "to",
              "by", "up", "as", "from", "with", "into", "onto", "off", "per", "via", "vs", "over", "nor"}
SYNONYMS = [
    ["protagonist", "main character", "central figure", "hero", "heroine"],
    ["company", "firm", "organization", "enterprise", "business"],
    ["author", "writer", "novelist", "scribe"],
    ["report", "study", "analysis", "investigation", "examination"],
    ["technology", "tool", "system", "platform", "solution"],
    ["technique", "method", "approach", "strategy", "tactic"],
    ["challenge", "obstacle", "difficulty", "hurdle", "barrier"],
    ["benefit", "advantage", "upside", "strength"],
]
ADJ_SUFFIX = re.compile(r"(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$", re.I)
STOCK_ADJ = {"vibrant", "sleek", "bold", "dynamic", "innovative", "seamless", "robust", "powerful", "elegant",
             "stunning", "premium", "modern", "smart", "rich", "fresh", "exciting"}
FIRST_PERSON = re.compile(r"\b(?:I|me|my|mine|we|us|our|ours)\b")
CONTRACTABLE_OUT = re.compile(r"\b(?:do not|does not|did not|is not|are not|was not|were not|cannot|will not|"
                              r"would not|should not|could not|have not|has not|I am|I will|I have|we are|"
                              r"we will|we have|they are|you are|it is|that is|there is|I would|we would)\b",
                              re.I)
CONTRACTED = re.compile(r"\b(?:don['’]t|doesn['’]t|didn['’]t|isn['’]t|aren['’]t|"
                        r"wasn['’]t|weren['’]t|can['’]t|won['’]t|wouldn['’]t|"
                        r"shouldn['’]t|couldn['’]t|haven['’]t|hasn['’]t|I['’]m|"
                        r"I['’]ll|I['’]ve|we['’]re|we['’]ll|we['’]ve|they['’]re|"
                        r"you['’]re|it['’]s|that['’]s|there['’]s)\b", re.I)
QA_RE = re.compile(r"(?:^|(?<=[.!?\n])\s+)((?:is|are|can|do|does|did|will|would|should|could|has|have|was|were)\b[^?.!\n]{0,80}\?)\s+(yes|no|absolutely|never|maybe|probably|always)[.!]", re.I)
SEMI = ";"


# ---------------------------------------------------------------------------
# Scoring model
# ---------------------------------------------------------------------------
def _sentences(text):
    out = []
    for para in re.split(r"\n\s*\n", text):
        for sent in SENT_SPLIT.split(para.strip()):
            if words_of(sent):
                out.append(sent.strip())
    return out


def _paragraphs(text):
    return [p.strip() for p in re.split(r"\n\s*\n", text) if p.strip()]


def _cv(values):
    if len(values) < 2:
        return None
    mean = sum(values) / float(len(values))
    if mean == 0:
        return None
    var = sum((v - mean) ** 2 for v in values) / float(len(values))
    return math.sqrt(var) / mean


def run_checks(prose, win):
    """Return list of Finding. `prose` is the masked window; `win` the raw window."""
    F = []

    def add(num, slug, pattern, flags=re.I, label=None, text=None):
        ms, samples = rx_finds(prose if text is None else text, pattern, flags)
        if ms:
            F.append(Finding(num, slug, len(ms), samples, label))
        return len(ms)

    def add_count(num, slug, count, samples, label=None):
        if count:
            F.append(Finding(num, slug, count, samples, label))

    # 1 AI vocabulary
    add(1, "ai_vocabulary", AI_VOCAB_RE)
    # 2 model dialect (needs two hits)
    dialect = []
    for p in DIALECT_PATTERNS:
        dialect.extend(re.finditer(p, prose, re.I))
    if len(dialect) >= DIALECT_HITS_NEEDED:
        add_count(2, "model_dialect", len(dialect), [excerpt(prose, m.start(), m.end()) for m in dialect[:3]])
    # 3 promotional language
    promo = [m for m in re.finditer(alt(PROMO), prose, re.I)]
    sents = _sentences(prose)
    imperative_sents = [s for s in sents if s.split(" ", 1)[0].lower().strip(".,!") in PROMO_IMPERATIVES]
    if len(imperative_sents) >= 3:
        promo_samples = [s[:90] for s in imperative_sents[:3]]
        add_count(3, "promotional", len(promo) + len(imperative_sents),
                  [excerpt(prose, m.start(), m.end()) for m in promo[:3]] or promo_samples)
    elif promo:
        add_count(3, "promotional", len(promo), [excerpt(prose, m.start(), m.end()) for m in promo[:3]])
    # 4 hyphenated pairs (advice)
    add(4, "hyphenated_pairs", alt(HYPHEN_PAIRS))
    # 5 simple yet
    add(5, "simple_yet", r"\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b")
    # 6 stacked adjective chains
    chains = []
    for m in re.finditer(r"\b((?:[A-Za-z][A-Za-z-]*,\s+){3,}(?:(?:and|or)\s+)?[A-Za-z][A-Za-z-]*)\b", prose):
        ws = [w.lower() for w in re.findall(r"[A-Za-z][A-Za-z-]*", m.group(1))]
        if any(ADJ_SUFFIX.search(w) or w in STOCK_ADJ for w in ws):
            chains.append(m)
    if chains:
        add_count(6, "stacked_adjectives", len(chains), [excerpt(prose, m.start(), m.end()) for m in chains[:3]])
    # 7 rule of three: no detector (no-detector number)
    # 8 synonym cycling
    cyc_hits = 0
    cyc_samples = []
    for cluster in SYNONYMS:
        found = []
        for member in cluster:
            ms = list(re.finditer(r"\b" + phrase_re(member) + r"s?\b", prose, re.I))
            if ms:
                found.append(ms)
        # three or more distinct members of one cluster are needed to fire
        if len(found) >= 3:
            for ms in found:
                cyc_hits += len(ms)
                cyc_samples.append(excerpt(prose, ms[0].start(), ms[0].end()))
    if cyc_hits > 0:
        add_count(8, "synonym_cycling", cyc_hits, cyc_samples)
    # 10 significance inflation
    add(10, "significance_inflation", "|".join("(?:%s)" % p for p in SIG_INFL))
    # 11 notability name-dropping
    add(11, "notability", r"\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+[^.!?\n]*?(?-i:[A-Z][\w&.]+)(?:,\s*|\s+and\s+)(?-i:[A-Z][\w&.]+)", re.I)
    add(11, "notability_presence", r"\b(?:strong|active|growing)\s+(?:online|digital|social[\s-]media)\s+presence\b|"
        r"\b(?:widely|extensively)\s+covered\b|\bindependent\s+coverage\b|\b[\d,.]+\s+followers\b", re.I)
    # 12 vague attributions
    add(12, "vague_attributions", "|".join("(?:%s)" % p for p in VAGUE_ATTR))
    # 13 article titles as proper nouns (decisive)
    add(13, "article_title_noun", r"\b(?-i:The\s+(?:List|Index|Compilation|Collection|Catalogue|Guide|Overview))\s+of\s+[^.!?\n]{2,80}?\s+(?:is|was)\s+(?:a|an|the)\b", re.I)
    # 14 conservation padding
    add(14, "conservation_padding", "|".join("(?:%s)" % p for p in CONSERVATION))
    # 15 false ranges
    add(15, "false_ranges", "|".join("(?:%s)" % p for p in FALSE_RANGE))
    # 16 superficial -ing tails
    add(16, "ing_tails", ING_TAILS)
    # 17 negative parallelisms (advice) and tailing negations (advice)
    add(17, "negative_parallelism", "|".join("(?:%s)" % p for p in PARALLEL))
    add(17, "tailing_negation", TAIL_NEG)
    # 18 Not X, just Y
    add(18, "not_x_just_y", "|".join("(?:%s)" % p for p in NOT_X_JUST_Y))
    # 19 filler (advice)
    add(19, "filler", "|".join("(?:%s)" % p for p in FILLER))
    # 20 empty pivots
    add(20, "empty_pivot", "|".join("(?:%s)" % p for p in EMPTY_PIVOT))
    # 21 outcome-speculation tails
    add(21, "outcome_tails", OUTCOME_TAILS)
    # 22 persuasive authority tropes (advice)
    add(22, "persuasive_tropes", "|".join("(?:%s)" % p for p in PERSUASIVE))
    # 23 editorial interjections
    add(23, "editorial_interjections", r"\bit(?:['’]s|\s+is)\s+important\s+to\s+(?:remember|note|understand|recognize)\b|"
        r"\bone\s+must\s+note\s+that\b|\bit\s+is\s+worth\s+pointing\s+out\b|\bit\s+cannot\s+be\s+overstated\s+that\b|"
        r"\bit\s+must\s+be\s+emphasized\s+that\b")
    # 24 self-thoroughness
    add(24, "self_thoroughness", "|".join("(?:%s)" % p for p in SELF_THOROUGH))
    # 25 question-answer rhetoric
    qa = list(QA_RE.finditer(prose))
    if qa:
        add_count(25, "question_answer", len(qa), [excerpt(prose, m.start(), m.end()) for m in qa[:3]])
    # 26 concrete evidence
    add(26, "concrete_evidence", r"\bwithout\s+concrete\s+(?:evidence|proof)\b|\bdo\s+you\s+have\s+concrete\s+evidence\b|"
        r"\bi\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples)\s+to\b|\babsent\s+concrete\s+proof\b|"
        r"\bprovide\s+concrete\s+evidence\b")
    # 27 compulsive intro hooks
    add(27, "intro_hooks", "|".join("(?:%s)" % p for p in INTRO_HOOKS))
    # 30 diff-anchored writing
    add(30, "diff_anchored", r"\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b|"
        r"\b(?:the|this)\s+(?:latest\s+|new\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b|"
        r"\bhas\s+been\s+(?:updated|refactored|improved|enhanced|changed)\s+to\b|\bhave\s+been\s+(?:updated|refactored|improved|enhanced|changed)\s+to\b|"
        r"\bwasn['’]t\s+there\s+before\b|\bweren['’]t\s+there\s+before\b|"
        r"\bwe['’]ve\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b|"
        r"\bwe\s+have\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b")
    # 31 signposting
    add(31, "signposting", r"\blet['’]s\s+(?:dive|delve|explore)\b|\blet['’]s\s+break\s+(?:this|it)\s+down\b|"
        r"\bhere['’]s\s+what\s+you\s+need\s+to\s+know\b|\bwithout\s+further\s+ado\b|\bnow\s+let['’]s\s+look\s+at\b|"
        r"\bbuckle\s+up\b|\bstay\s+with\s+me\b|\b(?:are\s+you\s+)?ready\s+to\s+dive\s+in\b")
    # 32 cataloguing lead-ins
    add(32, "cataloguing", r"\b(?:used|uses|employs|employed|relied\s+on|utilizes)\s+(?:several|various|a\s+number\s+of|multiple|different|many|numerous)\s+\w+|"
        r"(?:^|(?<=[.!?]\s))These\s+(?:\w+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help)\s+(?:information|insight|understanding|details|data)\b|"
        r"\b(?:is|are|was|were|remains|becomes)\s+(?:the\s+|a\s+)?(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b")
    # 33 inline-header vertical lists
    ih = list(INLINE_HEADER.finditer(prose))
    if ih:
        add_count(33, "inline_headers", len(ih), [excerpt(prose, m.start(), m.end()) for m in ih[:3]])
    # 34 mid-essay bullet injection
    paras = _paragraphs(prose)
    has_heading = bool(HEADING.search(prose))
    list_paras = [p for p in paras if all(re.match(r"^\s*(?:[-*+]|\d+[.)])\s+", ln) for ln in p.split("\n") if ln.strip())]
    prose_paras = [p for p in paras if p not in list_paras]
    if not has_heading and list_paras and len(prose_paras) >= 2:
        add_count(34, "bullet_injection", len(list_paras), [list_paras[0][:90]])
    # 35 fragmented headers
    frag = []
    lines = prose.split("\n")
    for idx, line in enumerate(lines):
        hm = re.match(r"^#{1,6}\s+(.+)$", line)
        if not hm:
            continue
        nxt = None
        for later in lines[idx + 1:]:
            if later.strip():
                nxt = later.strip()
                break
        if nxt is None or re.match(r"^(?:#|[-*+|>]|\d+[.)]\s)", nxt):
            continue
        if len(nxt.split()) <= 4:
            htoks = set(w.lower() for w in re.findall(r"[A-Za-z]{3,}", hm.group(1)))
            if any(w.lower() in htoks for w in re.findall(r"[A-Za-z]{3,}", nxt)):
                frag.append(line.strip() + " / " + nxt)
    if frag:
        add_count(35, "fragmented_headers", len(frag), frag[:3])
    # 36 formulaic challenges
    add(36, "formulaic_challenges", "|".join("(?:%s)" % p for p in CHALLENGES))
    # 37 transition clusters (two or more per paragraph)
    tc = 0
    tc_samples = []
    for p in paras:
        ms = list(TRANSITIONS.finditer(p))
        if len(ms) >= 2:
            tc += 1
            tc_samples.append(excerpt(p, ms[0].start(), ms[1].end()))
    if tc:
        add_count(37, "transition_clusters", tc, tc_samples)
    # 38 compulsive conclusion openers
    add(38, "conclusion_openers", CONCLUSIONS.pattern, re.I | re.M)
    # 39 generic positive conclusions
    add(39, "generic_conclusions", "|".join("(?:%s)" % p for p in CONCLUSION_GENERIC))
    # 40 sentence-length monotony
    sent_lengths = [len(words_of(s)) for s in sents]
    if len(sent_lengths) >= 3:
        cv = _cv(sent_lengths)
        if cv is not None and cv < 0.35:
            add_count(40, "sentence_monotony", len(sent_lengths), [s[:90] for s in sents[:3]])
    # 41 mechanical alternation (advice)
    alt_runs = 0
    for i in range(0, len(sent_lengths) - 5):
        seg = sent_lengths[i:i + 6]
        diffs = [seg[k + 1] - seg[k] for k in range(5)]
        if all(diffs[k] * diffs[k + 1] < 0 for k in range(4)) and min(abs(d) for d in diffs) >= 0.5 * (sum(seg) / 6.0):
            alt_runs += 1
    if alt_runs:
        add_count(41, "mechanical_alternation", alt_runs, [])
    # 42 opener repetition (advice)
    rep = 0
    for p in paras:
        ss = _sentences(p)
        if len(ss) < 3:
            continue
        counts = {}
        for s in ss:
            tok = re.findall(r"[A-Za-z']+", s)[:2]
            if len(tok) == 2:
                key = " ".join(t.lower() for t in tok)
                counts[key] = counts.get(key, 0) + 1
        rep += sum(1 for v in counts.values() if v >= 3)
    if rep:
        add_count(42, "opener_repetition", rep, [])
    # 44 uniform paragraph length
    body_paras = [p for p in paras if not p.startswith("#") and not re.match(r"^\s*(?:[-*+]|\d+[.)])\s", p)]
    if len(body_paras) >= 4:
        pl = [len(words_of(p)) for p in body_paras]
        cv = _cv(pl)
        if cv is not None and cv < 0.4:
            add_count(44, "uniform_paragraphs", len(body_paras), [body_paras[0][:90]])
    # 46 semicolon and parenthesis underuse (advice), long documents only
    total_words = len(words_of(prose))
    if total_words >= 300 and SEMI not in prose and prose.count("(") <= 1:
        add_count(46, "semicolon_underuse", 1, [])
    # 47 chatbot artifacts (decisive)
    add(47, "chatbot_artifacts", "|".join("(?:%s)" % p for p in CHATBOT))
    # 48 sycophancy (decisive)
    add(48, "sycophancy", "|".join("(?:%s)" % p for p in SYCOPHANCY), re.I)
    # 50 knowledge-cutoff disclaimers (decisive)
    add(50, "knowledge_cutoff", "|".join("(?:%s)" % p for p in CUTOFF))
    # 51 copula avoidance
    add(51, "copula_avoidance", "|".join("(?:%s)" % p for p in COPULA))
    # 54 hedge stacking (advice)
    hs = 0
    for s in sents:
        if len(HEDGES.findall(s.lower())) >= 2:
            hs += 1
    if hs:
        add_count(54, "hedge_stacking", hs, [s[:90] for s in sents if len(HEDGES.findall(s.lower())) >= 2][:3])
    # 55 contraction absence (advice): first-person writing with written-out forms
    fp = len(FIRST_PERSON.findall(prose))
    if total_words and fp / float(total_words) >= 0.03:
        out_forms = len(CONTRACTABLE_OUT.findall(prose))
        con_forms = len(CONTRACTED.findall(prose))
        if out_forms >= 3 and out_forms > 2 * con_forms:
            add_count(55, "contraction_absence", out_forms, [])
    # 56 boldface overuse
    bold = list(re.finditer(r"\*\*[^*\n]+\*\*", prose))
    if bold:
        add_count(56, "boldface", len(bold), [excerpt(prose, m.start(), m.end()) for m in bold[:3]])
    # 57 emojis
    em = list(EMOJI_RE.finditer(prose))
    if em:
        add_count(57, "emojis", len(em), [excerpt(prose, m.start(), m.end()) for m in em[:3]])
    # 58 em-dash overuse (advice): two or more em dashes in one paragraph
    ed = sum(1 for p in paras if p.count(EM_DASH) >= 2)
    if ed:
        add_count(58, "em_dash", ed, [])
    # 59 title case headings
    tcase = []
    for m in HEADING.finditer(prose):
        title = m.group(2).strip()
        words = re.findall(r"[A-Za-z][A-Za-z'-]*", title)
        if len(words) < 3 or not title[0].isalpha() or title.isupper():
            continue
        major = [w for w in words if w.lower() not in MAJOR_SKIP]
        if len(major) >= 2 and all(w[0].isupper() for w in major):
            tcase.append(m)
    if tcase:
        add_count(59, "title_case_headings", len(tcase), [excerpt(prose, m.start(), m.end()) for m in tcase[:3]])
    # 60 curly quotes (advice)
    cq = CURLY.findall(prose)
    if cq:
        add_count(60, "curly_quotes", len(cq), [])
    # 61 hyphen for en dash in year ranges (advice)
    yr = [m for m in YEAR_RANGE.finditer(prose) if int(m.group(2)) > int(m.group(1))]
    if yr:
        add_count(61, "hyphen_year_ranges", len(yr), [excerpt(prose, m.start(), m.end()) for m in yr[:3]])
    # 62 invisible characters (decisive, counted on the raw window)
    inv = invisible_indices(win)
    if inv:
        add_count(62, "invisible_characters", len(inv), [])
    # 63 placeholder text (decisive)
    add(63, "placeholder_text", "|".join("(?:%s)" % p for p in PLACEHOLDERS))
    # 64 chat reference markup (decisive)
    add(64, "chat_markup", CHAT_MARKUP)
    # 65 AI tracking parameters (decisive)
    utm = list(UTM.finditer(prose))
    if utm:
        add_count(65, "ai_tracking_params", len(utm), [excerpt(prose, m.start(), m.end()) for m in utm[:3]])
    # 66 homoglyphs (decisive, counted on raw window)
    hg = homoglyph_tokens(win)
    if hg:
        add_count(66, "homoglyphs", len(hg), [excerpt(win, m.start(), m.end()) for m in hg[:3]])
    # 67 non-standard spaces
    ns = nonstandard_space_indices(win)
    if ns:
        add_count(67, "nonstandard_spaces", len(ns), [])
    # 68 trailing whitespace (advice)
    tw = trailing_ws_count(win)
    if tw:
        add_count(68, "trailing_whitespace", tw, [])
    # 69 canonical marketing slop
    add(69, "marketing_slop", "|".join("(?:%s)" % p for p in MARKETING_SLOP))
    # 70 decorative horizontal rules
    hr = [ln for ln in lines if re.match(r"^\s{0,3}(?:(?:-\s*){3,}|(?:\*\s*){3,}|(?:_\s*){3,})$", ln)]
    if len(hr) >= 3 and len(lines) >= 24:
        add_count(70, "horizontal_rules", len(hr), [])
    # 71 degenerate repetition
    toks = [w.lower() for w in re.findall(r"[^\W_]+", prose)]
    if len(toks) >= 6:
        grams = [tuple(toks[i:i + 6]) for i in range(len(toks) - 5)]
        seen = {}
        for g in grams:
            seen[g] = seen.get(g, 0) + 1
        repeated_positions = sum(1 for g in grams if seen[g] > 1)
        if repeated_positions and repeated_positions / float(len(grams)) >= 0.2:
            add_count(71, "degenerate_repetition", repeated_positions, [" ".join(grams[0])])
    return F


def score_document(prose, win, total_chars_truncated):
    """Turn findings into score, band, confidence (FP-01)."""
    findings = run_checks(prose, win)
    words = words_of(prose)
    nwords = len(words)
    families = set(f.num for f in findings if f.num not in ADVICE)
    fam_hits = {}
    for f in findings:
        if f.num in families:
            fam_hits[f.num] = fam_hits.get(f.num, 0) + f.count
    # base points per family (weight zero for advice, handled above)
    raw = 0
    for num in families:
        c = fam_hits.get(num, 1)
        raw += 6 + 3 * min(c - 1, 6)
    score = min(100, raw)
    n = len(families)
    decisive = families & DECISIVE
    if nwords < 40:
        conf = "none"
    elif nwords < 120 or (nwords < 300 and n == 1):
        conf = "low"
    elif nwords < 300:
        conf = "moderate"
    else:
        conf = "high"
    rank = {"none": 0, "low": 1, "moderate": 2, "high": 3}
    single_decisive_ok = len(decisive) == 1 and rank[conf] > rank["low"]
    if n == 0:
        score = 0
    elif n == 1 and not (families <= decisive and single_decisive_ok):
        score = min(score, 40)
        if families == {40}:
            score = min(score, 20)
    elif families <= RHYTHM:
        score = min(score, 40)
    floors = []
    if nwords < 120:
        short_count = len(families & SHORT_DOC_FAMILIES)
        if short_count >= 3:
            floors.append(45)
        elif short_count >= 2:
            floors.append(25)
    if nwords >= 400:
        if n >= 6:
            floors.append(45)
        elif n >= 5:
            floors.append(25)
    if len(decisive) >= 2:
        floors.append(65)
    elif single_decisive_ok:
        floors.append(45)
    if floors:
        score = max(score, max(floors))
    score = int(max(0, min(100, score)))
    if conf == "none":
        reason = "fewer than 40 words; the score is not meaningful"
    elif conf == "low":
        reason = "short text (%d words); treat the score as a rough hint" % nwords
    elif conf == "moderate":
        reason = "under 300 words; the score is a triage hint"
    else:
        reason = ""
    return findings, score, conf, reason, nwords


def interval(prose, win, seed=1729):
    """Bootstrap-style low/high interval over sentence subsets (--ci)."""
    sents = _sentences(prose)
    if len(sents) < 4:
        return None, "too few sentences for an interval (need at least 4)"
    rng = random.Random(seed)
    iters = 40 if len(prose) <= 60000 else 8
    k = max(2, (len(sents) + 1) // 2)
    vals = []
    for _ in range(iters):
        pick = sorted(rng.sample(range(len(sents)), k))
        sub = " ".join(sents[i] for i in pick)
        _, sc, _, _, _ = score_document(sub, sub, False)
        vals.append(sc)
    vals.sort()
    lo = vals[int(0.05 * (len(vals) - 1))]
    hi = vals[int(math.ceil(0.95 * (len(vals) - 1)))]
    _, point, _, _, _ = score_document(prose, win, False)
    lo = min(lo, point)
    hi = max(hi, point)
    return [lo, hi], "resampled over sentences (%d resamples, seed %d); the point score is unchanged" % (iters, seed)


def build_report(text, want_ci=False):
    truncated = len(text) > WINDOW
    win = text[:WINDOW]
    prose = mask_prose(win)
    findings, score, conf, reason, nwords = score_document(prose, win, truncated)
    report = {}
    for f in findings:
        if f.num == 17:
            slug = "negative_parallelism" if f.slug == "negative_parallelism" else "tailing_negation"
            key = "17_" + slug
        else:
            key = "%d_%s" % (f.num, f.slug)
        report[key] = {"label": f.label, "count": f.count, "samples": f.samples}
    inv = len(invisible_indices(win))
    ns = len(nonstandard_space_indices(win))
    hg = len(homoglyph_tokens(win))
    metrics = {
        "scanned_chars": len(win),
        "truncated": bool(truncated),
        "ai_tell_score": score,
        "ai_tell_band": band_for(score),
        "confidence": conf,
        "confidence_reason": reason,
        "patterns_flagged": len(findings),
        "invisible_chars": inv,
        "nonstandard_spaces": ns,
        "homoglyphs": hg,
    }
    if want_ci:
        ci, note = interval(prose, win)
        metrics["score_ci"] = ci
        metrics["score_ci_note"] = note
    report["_metrics"] = metrics
    return report


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------
USAGE_FIRST = "usage: detect.py [--clean] [--ci] [--] [FILE]"
USAGE = (USAGE_FIRST + "\n"
         "\n"
         "Score prose for AI-writing patterns. Prints a JSON report, or with --clean\n"
         "prints scrubbed text. Reads FILE, or standard input when no FILE is given.\n"
         "\n"
         "  --clean   cleanup: print scrubbed text instead of the report\n"
         "  --ci      add a low/high interval on the score (needs at least 4 sentences)\n"
         "  --        end option parsing, so FILE may begin with a dash\n"
         "  -h, --help  show this message\n"
         "\n"
         "Only the first 262,144 characters of extracted prose are scanned.\n")


def _emit(stream, text):
    stream.buffer.write(text.encode("utf-8"))
    stream.buffer.flush()


def _error(message, code):
    line = json.dumps({"error": message}, ensure_ascii=False)
    try:
        _emit(sys.stderr, line + "\n")
    except Exception:  # noqa: BLE001
        pass
    return code


def main(argv):
    clean = ci = False
    operands = []
    end = False
    want_help = False
    for arg in argv:
        if end:
            operands.append(arg)
            continue
        if arg == "--":
            end = True
            continue
        if arg in ("--help", "-h"):
            want_help = True
            continue
        if arg == "--clean":
            clean = True
            continue
        if arg == "--ci":
            ci = True
            continue
        if arg.startswith("-") and arg != "-":
            return _error("unknown option '%s'; see --help" % arg, 2)
        operands.append(arg)
    if want_help:
        _emit(sys.stdout, USAGE)
        return 0
    if len(operands) > 1:
        _emit(sys.stderr, "detect.py: several files given; only the first (%s) is scanned\n" % operands[0])
    target = None
    if operands and operands[0] != "-":
        target = operands[0]
    try:
        text = extract_source(target)
    except InputError as exc:
        return _error(exc.message, exc.code)
    if text.strip() == "":
        return _error("empty input", 1)
    if clean:
        _emit(sys.stdout, cleanup_text(text))
        return 0
    report = build_report(text, want_ci=ci)
    _emit(sys.stdout, json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    return 0


if __name__ == "__main__":
    try:
        sys.setrecursionlimit(10000)
        code = main(sys.argv[1:])
    except BrokenPipeError:
        code = 0
    sys.exit(code)
