"""Tests for scripts/detect.py (run with: python3 -m unittest discover -s tests -v).

Standard library only. Each test names the spec ids it checks in its docstring.
"""

import importlib.util
import io
import json
import os
import subprocess
import sys

sys.dont_write_bytecode = True
import tempfile
import unittest
import zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DETECT = os.path.join(ROOT, "scripts", "detect.py")

spec = importlib.util.spec_from_file_location("detect", DETECT)
detect = importlib.util.module_from_spec(spec)
spec.loader.exec_module(detect)


def run(args, stdin=b""):
    proc = subprocess.run([sys.executable, DETECT] + args, input=stdin,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return proc.returncode, proc.stdout.decode("utf-8"), proc.stderr.decode("utf-8")


class DetectorBase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, name, data):
        path = os.path.join(self.tmp.name, name)
        mode = "wb" if isinstance(data, bytes) else "w"
        with open(path, mode, **({} if mode == "wb" else {"encoding": "utf-8"})) as fh:
            fh.write(data)
        return path


class ReportShape(DetectorBase):
    AI_TEXT = (
        "In today's fast-paced world, it's worth noting that our robust, seamless, and innovative "
        "solution serves as a testament to the power of collaboration. Additionally, the team will "
        "delve into the intricate landscape of modern tools, showcasing a vibrant tapestry of ideas. "
        "Furthermore, this comprehensive guide explores how we leverage cutting-edge methods. "
        "Moreover, the results are genuinely fascinating and nuanced. Certainly! Here is a summary. "
        "I hope this helps! Let me know if you need anything else."
    )

    def test_report_members_and_types(self):
        """N-000744..N-000773: keys, label, count, samples and metrics members."""
        path = self.write("draft.md", self.AI_TEXT)
        code, out, err = run([path])
        self.assertEqual(code, 0, err)
        report = json.loads(out)
        metrics = report["_metrics"]
        for key in ["scanned_chars", "truncated", "ai_tell_score", "ai_tell_band", "confidence",
                    "confidence_reason", "patterns_flagged", "invisible_chars", "nonstandard_spaces",
                    "homoglyphs"]:
            self.assertIn(key, metrics)
        self.assertIn("1_ai_vocabulary", report)
        finding = report["1_ai_vocabulary"]
        self.assertIsInstance(finding["label"], str)
        self.assertGreater(finding["count"], 0)
        self.assertLessEqual(len(finding["samples"]), 3)
        self.assertEqual(metrics["patterns_flagged"], len(report) - 1)
        self.assertNotIn("score_ci", metrics)

    def test_labels_unique_per_catalogue_number(self):
        """N-000757: two different catalogue numbers never carry the same label."""
        labels = list(detect.TITLES.values())
        self.assertEqual(len(labels), len(set(labels)))

    def test_no_detector_numbers_never_appear(self):
        """N-000125..N-000126: numbers 7, 9, 28, 29, 43, 45, 49, 52, 53 never appear."""
        text = " ".join(["Delve into the realm. Genuinely, it is nuanced."] * 5)
        report = detect.build_report(text)
        for num in detect.NO_DETECTOR:
            self.assertFalse(any(k.startswith("%d_" % num) for k in report), num)

    def test_ci_present_only_with_flag(self):
        """N-000770..N-000773: score_ci only with --ci; null when too few sentences."""
        path = self.write("short.md", "One sentence only.")
        code, out, _ = run(["--ci", path])
        self.assertEqual(code, 0)
        metrics = json.loads(out)["_metrics"]
        self.assertIsNone(metrics["score_ci"])
        self.assertIn("score_ci_note", metrics)
        path = self.write("long.md", self.AI_TEXT)
        code, out, _ = run(["--ci", path])
        ci = json.loads(out)["_metrics"]["score_ci"]
        self.assertLessEqual(ci[0], ci[1])

    def test_bands(self):
        """N-000115: five bands by score."""
        expect = {0: "clean", 20: "clean", 21: "light tells", 40: "light tells", 41: "mixed",
                  60: "mixed", 61: "heavy tells", 80: "heavy tells", 81: "pervasive tells", 100: "pervasive tells"}
        for score, band in expect.items():
            self.assertEqual(detect.band_for(score), band)

    def test_clean_prose_scores_clean(self):
        """N-000105 .. N-000115: plain factual prose has no findings and a clean band."""
        text = ("The bridge opened in 1932. Engineers measured the steel twice before the first truck "
                "crossed. Traffic grew slowly over the next decade, and the county paid for repairs.")
        report = detect.build_report(text)
        self.assertEqual(report["_metrics"]["ai_tell_score"], 0)
        self.assertEqual(report["_metrics"]["ai_tell_band"], "clean")

    def test_single_family_cap(self):
        """N-000131..N-000134: one score-moving family scores at most 40 (not decisive)."""
        text = ("We will delve into the question. The garden grows slowly in late spring, "
                "while cold rain keeps the paths quiet. Nobody minds, since the bees return "
                "every afternoon to the old apple tree near the gate.")
        report = detect.build_report(text)
        families = [k for k in report if k != "_metrics" and not k.startswith(("62_", "63_"))]
        self.assertEqual(families, ["1_ai_vocabulary"])
        self.assertLessEqual(report["_metrics"]["ai_tell_score"], 40)

    def test_two_decisive_families_floor_65(self):
        """N-000135..N-000137: two distinct decisive families raise the score to at least 65."""
        text = ("I hope this helps! Certainly! The 🚀 launch is here. As of my last training, "
                "the product is new. " * 2)
        report = detect.build_report(text)
        self.assertGreaterEqual(report["_metrics"]["ai_tell_score"], 65)

    def test_confidence_levels(self):
        """N-000145..N-000148: confidence none below 40 words, low below 120, moderate below 300."""
        self.assertEqual(detect.build_report("Short text here.")["_metrics"]["confidence"], "none")
        many = " ".join(["word%d" % (i % 37) for i in range(150)]) + "."
        self.assertEqual(detect.build_report(many)["_metrics"]["confidence"], "low")
        big = " ".join(["plain%d" % (i % 53) for i in range(400)]) + "."
        self.assertEqual(detect.build_report(big)["_metrics"]["confidence"], "high")

    def test_window_and_truncation(self):
        """N-000236..N-000240: text longer than 262,144 characters is scored on the window."""
        long_text = "a" * (detect.WINDOW + 10)
        report = detect.build_report(long_text)
        self.assertTrue(report["_metrics"]["truncated"])
        self.assertEqual(report["_metrics"]["scanned_chars"], detect.WINDOW)
        exact = "a" * detect.WINDOW
        report = detect.build_report(exact)
        self.assertFalse(report["_metrics"]["truncated"])

    def test_invisible_past_window_not_counted(self):
        """N-000294: an invisible character placed only past the window is not a finding."""
        text = "a" * detect.WINDOW + "​"
        report = detect.build_report(text)
        self.assertEqual(report["_metrics"]["invisible_chars"], 0)
        self.assertNotIn("62_invisible_characters", report)


class ErrorsAndStreams(DetectorBase):
    def test_help_to_stdout_first_line(self):
        """N-000640..N-000642, N-000740: --help and -h print usage to stdout and exit 0."""
        for flag in ("--help", "-h"):
            code, out, err = run([flag])
            self.assertEqual(code, 0)
            self.assertEqual(out.splitlines()[0], "usage: detect.py [--clean] [--ci] [--] [FILE]")

    def test_empty_input(self):
        """N-000704..N-000707: empty extracted prose -> exit 1, 'empty input', no stdout."""
        code, out, err = run([], stdin=b"   \n\t")
        self.assertEqual(code, 1)
        self.assertEqual(out, "")
        self.assertEqual(json.loads(err.strip().splitlines()[-1]), {"error": "empty input"})
        self.assertNotIn("Traceback", err)

    def test_unreadable_path(self):
        """N-000708..N-000711: unreadable path -> exit 1, 'cannot read input:'."""
        code, out, err = run([os.path.join(self.tmp.name, "missing.md")])
        self.assertEqual(code, 1)
        self.assertTrue(json.loads(err.strip().splitlines()[-1])["error"].startswith("cannot read input:"))

    def test_bad_zip(self):
        """N-000286, N-000708..N-000711: archive extension, bytes not a zip -> cannot read."""
        path = self.write("bad.docx", b"not a zip")
        code, out, err = run([path])
        self.assertEqual(code, 1)
        self.assertTrue(json.loads(err.strip().splitlines()[-1])["error"].startswith("cannot read input:"))

    def test_unknown_option(self):
        """N-000712..N-000715: unknown option -> exit 2 naming the option and --help."""
        code, out, err = run(["--bogus"])
        self.assertEqual(code, 2)
        error = json.loads(err.strip().splitlines()[-1])["error"]
        self.assertIn("unknown option", error)
        self.assertIn("--bogus", error)
        self.assertIn("--help", error)

    def test_double_dash_allows_dash_names(self):
        """N-000231, N-000732..N-000739: -- ends option parsing."""
        path = self.write("-odd.md", "Plain text here for the dash file name test.")
        code, out, _ = run(["--", path])
        self.assertEqual(code, 0)

    def test_two_files_scan_first(self):
        """N-000719..N-000721, N-000783..N-000787: first file scanned, notice on stderr."""
        a = self.write("first.md", "Plain text one for the test file.")
        b = self.write("second.md", "Plain text two for the test file.")
        code, out, err = run([a, b])
        self.assertEqual(code, 0)
        self.assertIn(a, err)
        self.assertEqual(out.strip()[0], "{")
        self.assertEqual(json.loads(out)["_metrics"]["scanned_chars"], len("Plain text one for the test file."))

    def test_stdout_is_utf8(self):
        """N-000716, N-000717: report decodes as UTF-8."""
        code, out, _ = run([], stdin="Café naïve résumé. ✓".encode("utf-8"))
        self.assertEqual(code, 0)
        json.loads(out)


class Extraction(DetectorBase):
    def test_docx(self):
        """N-000256: visible paragraph text of .docx, without markup."""
        doc = ('<?xml version="1.0"?><w:document xmlns:w="http://x"><w:body>'
               '<w:p><w:r><w:t>First paragraph.</w:t></w:r></w:p>'
               '<w:p><w:r><w:t>Second &amp; last.</w:t></w:r></w:p></w:body></w:document>')
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w") as zf:
            zf.writestr("word/document.xml", doc)
        path = self.write("a.docx", buf.getvalue())
        code, out, _ = run(["--clean", path])
        self.assertEqual(code, 0)
        self.assertEqual(out, "First paragraph.\nSecond & last.")
        self.assertNotIn("<", out)

    def test_ipynb_markdown_only(self):
        """N-000271..N-000272, N-000288: only markdown cells extracted."""
        nb = {"cells": [{"cell_type": "markdown", "source": ["# Title\n", "Prose here."]},
                        {"cell_type": "code", "source": ["print('code')"]}]}
        path = self.write("n.ipynb", json.dumps(nb))
        code, out, _ = run(["--clean", path])
        self.assertEqual(code, 0)
        self.assertIn("Prose here.", out)
        self.assertNotIn("print", out)

    def test_invalid_notebook_is_empty(self):
        """N-000288..N-000290: invalid JSON notebook -> empty input."""
        path = self.write("bad.ipynb", "{not json")
        code, out, err = run([path])
        self.assertEqual(code, 1)
        self.assertEqual(json.loads(err.strip().splitlines()[-1]), {"error": "empty input"})

    def test_pdf_is_empty(self):
        """N-000282..N-000285: pdf and rtf have no extracted prose."""
        path = self.write("x.pdf", b"%PDF-1.4 something")
        code, out, err = run([path])
        self.assertEqual(code, 1)

    def test_utf16_bom(self):
        """N-000241: UTF-16 with a byte-order mark decodes as text."""
        data = "Hello there, plain text in UTF-16.".encode("utf-16")
        path = self.write("u16.txt", data)
        code, out, _ = run(["--clean", path])
        self.assertEqual(code, 0)
        self.assertEqual(out.strip(), "Hello there, plain text in UTF-16.")


class MaskingAndFamilies(unittest.TestCase):
    def test_fenced_code_is_not_scored(self):
        """N-000149: fenced code blocks generate no findings."""
        text = "Plain prose here.\n\n```\nDelve into the tapestry of realm robust landscape.\n```\n"
        self.assertNotIn("1_ai_vocabulary", detect.build_report(text))

    def test_inline_code_is_not_scored(self):
        """N-000149: inline code spans generate no findings."""
        text = "Use `delve` as a variable name in the plain sentence here."
        self.assertNotIn("1_ai_vocabulary", detect.build_report(text))

    def test_front_matter_is_not_scored(self):
        """N-000149: YAML front matter generates no findings."""
        text = "---\ntitle: delve tapestry\n---\nPlain prose only in the body.\n"
        self.assertNotIn("1_ai_vocabulary", detect.build_report(text))

    def test_model_dialect_needs_two_hits(self):
        """N-000153: model-dialect vocabulary needs two hits."""
        self.assertNotIn("2_model_dialect", detect.build_report("This is genuinely fine."))
        self.assertIn("2_model_dialect", detect.build_report("This is genuinely fine and nuanced."))

    def test_ai_vocabulary_inflections(self):
        """N-000152: inflected forms of listed words fire the family."""
        report = detect.build_report("They leveraged the tools and were delving into the landscapes.")
        self.assertIn("1_ai_vocabulary", report)
        self.assertGreaterEqual(report["1_ai_vocabulary"]["count"], 3)

    def test_comprehensive_is_context_only(self):
        """N-000362: comprehensive and boast are not bare-word findings."""
        report = detect.build_report("A comprehensive plan. The product will boast a camera.")
        self.assertNotIn("1_ai_vocabulary", report)

    def test_seventeen_forms(self):
        """N-000123..N-000127, N-000750: both forms of 17 are writing advice (weight zero)."""
        report = detect.build_report("It's not just about speed, it's about trust. Plain words here.")
        self.assertIn("17_negative_parallelism", report)
        self.assertEqual(report["_metrics"]["ai_tell_score"], 0)
        report = detect.build_report("The shed holds tools, and the crew works hard, no guessing, no waste.")
        self.assertIn("17_tailing_negation", report)
        self.assertEqual(report["_metrics"]["ai_tell_score"], 0)

    def test_writing_advice_does_not_move_score(self):
        """N-000119..N-000122: a document scores the same without writing-advice phrasing."""
        base = "The bridge opened in 1932. Engineers measured the steel twice before the first truck crossed."
        with_advice = ("The bridge opened in 1932. Engineers measured the “steel” twice before the "
                       "first truck crossed, during 2001-2005.")
        a = detect.build_report(base)
        b = detect.build_report(with_advice)
        self.assertEqual(a["_metrics"]["ai_tell_score"], b["_metrics"]["ai_tell_score"])
        moving = lambda r: sorted(k for k in r if k != "_metrics" and int(k.split("_")[0]) not in detect.ADVICE)
        self.assertEqual(moving(a), moving(b))

    def test_decisive_floor_needs_confidence(self):
        """N-000134..N-000137: single decisive family at low confidence does not get the 45 floor."""
        report = detect.build_report("I hope this helps!")
        self.assertLess(report["_metrics"]["ai_tell_score"], 45)

    def test_rhythm_only_scores_at_most_40(self):
        """N-000140..N-000144: sentence-length monotony only scores clean (at most 20)."""
        text = ("The red fox runs fast. A grey wolf waits near. Tall trees hold snow. "
                "Cold wind moves dust. Old men fish here. Bright moons rise late.")
        report = detect.build_report(text)
        self.assertEqual(list(k for k in report if k != "_metrics"), ["40_sentence_monotony"])
        self.assertLessEqual(report["_metrics"]["ai_tell_score"], 20)

    def test_code_extension_scanned_as_plain(self):
        """N-000295..N-000298: source files are read as plain text."""
        code, out, _ = run([], stdin=b"Plain text.")
        self.assertEqual(code, 0)

    def test_homoglyph_detection_and_fold(self):
        """N-000177, N-000310..N-000311: mixed-script token counted and folded by cleanup."""
        mixed = "hеllo world"  # Cyrillic e inside a Latin word
        report = detect.build_report(mixed)
        self.assertEqual(report["_metrics"]["homoglyphs"], 1)
        self.assertEqual(detect.cleanup_text(mixed), "hello world")
        natural = "Привет мир"
        self.assertEqual(detect.build_report(natural)["_metrics"]["homoglyphs"], 0)
        self.assertEqual(detect.cleanup_text(natural), natural)


class CleanupContract(DetectorBase):
    def test_N_000305_rescan_reports_zero_invisible_hits(self):
        """N-000305: after cleanup, a rescan reports zero invisible-character hits."""
        messy = "A​B‌C﻿D⁠E\U000e0041F️G­H‪I thing."
        clean = detect.cleanup_text(messy)
        self.assertEqual(detect.build_report(clean)["_metrics"]["invisible_chars"], 0)
        self.assertEqual(detect.build_report(messy)["_metrics"]["invisible_chars"] > 0, True)

    def test_N_000309_rescan_reports_zero_nonstandard_space_hits(self):
        """N-000309: after cleanup, a rescan reports zero non-standard-space hits."""
        messy = "Left word and em space and　ideographic end."
        clean = detect.cleanup_text(messy)
        self.assertEqual(detect.build_report(clean)["_metrics"]["nonstandard_spaces"], 0)

    def test_nbsp_holding_digits_is_kept(self):
        """N-000306..N-000308: no-break space between digits is kept."""
        text = "Costs 10 000 euros."
        self.assertIn(" ", detect.cleanup_text(text))

    def test_trailing_whitespace_trimmed(self):
        """N-000312..N-000315, N-000330: trailing spaces removed; one final newline restored."""
        out = detect.cleanup_text("First line  \nSecond line\t\n\n\n")
        self.assertEqual(out, "First line\nSecond line\n")

    def test_zwj_inside_emoji_kept(self):
        """N-000303..N-000305: zero-width joiner between emoji is kept."""
        family = "\U0001F468‍\U0001F469"
        self.assertEqual(detect.cleanup_text(family), family)

    def test_cleanup_outputs_text_not_report(self):
        """N-000301..N-000302: cleanup prints text, not a report."""
        path = self.write("c.md", "Hello​ world  \n")
        code, out, _ = run(["--clean", path])
        self.assertEqual(code, 0)
        self.assertEqual(out, "Hello world\n")


if __name__ == "__main__":
    unittest.main()
