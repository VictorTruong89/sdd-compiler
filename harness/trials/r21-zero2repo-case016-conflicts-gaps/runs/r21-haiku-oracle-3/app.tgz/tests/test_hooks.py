"""Tests for the Node.js plugin hooks (run with: python3 -m unittest discover -s tests -v).

Each hook is spawned as a real process with a temporary CLAUDE_CONFIG_DIR.
Requires `node` on PATH; the detector needs `python3` on PATH.
"""

import json
import os
import re
import shutil
import subprocess
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
HOOKS = os.path.join(ROOT, "hooks")

BANNED = ["delve", "tapestry", "pivotal", "crucial", "leverage", "robust", "seamless", "foster",
          "underscore", "showcase", "landscape", "journey", "realm", "multifaceted", "holistic",
          "testament", "vibrant", "comprehensive", "plethora", "myriad", "boast", "elevate", "empower",
          "unlock", "game-changer", "supercharge", "genuinely", "fascinating", "nuanced"]


def words(text):
    """Standalone word tokens (punctuation removed)."""
    return re.findall(r"[A-Za-z0-9][A-Za-z0-9_\-]*", text)


class Env(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix="pc-test-")
        self.cfg = os.path.join(self.tmp, "config")
        self.work = os.path.join(self.tmp, "work")
        os.makedirs(self.work)
        self.env = dict(os.environ)
        self.env["CLAUDE_CONFIG_DIR"] = self.cfg
        self.env.pop("PROSECHECK_DEFAULT_MODE", None)
        self.env.pop("CLAUDE_PLUGIN_ROOT", None)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def hook(self, name, payload=None, raw=None, env=None):
        data = raw if raw is not None else json.dumps(payload or {})
        proc = subprocess.run(["node", os.path.join(HOOKS, name)], input=data.encode("utf-8"),
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              env=env or self.env, cwd=self.work, timeout=60)
        self.assertEqual(proc.returncode, 0, proc.stderr.decode("utf-8"))
        return proc.stdout.decode("utf-8")

    def prompt(self, text, sid="sess-1", extra=None, env=None):
        payload = {"prompt": text, "session_id": sid, "cwd": self.work}
        payload.update(extra or {})
        out = self.hook("prosecheck-tracker.js", payload, env=env)
        return json.loads(out) if out.strip() else None

    def reason(self, text, **kw):
        out = self.prompt(text, **kw)
        self.assertIsNotNone(out, "no output for " + text)
        self.assertEqual(out["decision"], "block")
        return out["reason"]

    def set_level(self, level):
        self.reason("/prosecheck " + level)

    def contract(self, env=None):
        return self.hook("prosecheck-activate.js", {}, env=env)


class SessionStart(Env):
    def test_welcome_once_then_contract(self):
        """N-000370..N-000379, N-000795..N-000801: welcome on first start only."""
        first = self.contract()
        for fact in ["71", "512 KB", "4 MB", "262,144", "/prosecheck doctor", "/prosecheck check",
                     "/prosecheck off", "/prosecheck help", "no website", "shown once"]:
            self.assertIn(fact.lower(), first.lower())
        second = self.contract()
        self.assertNotIn("shown once", second)
        self.assertIn("Prose contract", second)

    def test_stored_flag_created(self):
        """N-000379: first start stores the default level."""
        self.contract()
        with open(os.path.join(self.cfg, ".prosecheck-active")) as fh:
            self.assertEqual(fh.read().strip(), "full")

    def test_off_emits_nothing(self):
        """N-000335..N-000337, N-000791: off -> empty output."""
        self.set_level("off")
        self.assertEqual(self.contract().strip(), "")

    def test_garbage_stored_value_ignored(self):
        """N-000389..N-000391: invalid stored value is ignored; default full applies."""
        os.makedirs(self.cfg)
        with open(os.path.join(self.cfg, ".prosecheck-active"), "w") as fh:
            fh.write("bogus")
        self.assertIn("level: full", self.contract())

    def test_environment_level(self):
        """N-000701: PROSECHECK_DEFAULT_MODE supplies the level."""
        env = dict(self.env, PROSECHECK_DEFAULT_MODE="lite")
        self.assertIn("level: lite", self.contract(env=env))

    def test_malformed_input_still_succeeds(self):
        """N-000386..N-000388: malformed JSON treated as empty object."""
        out = self.hook("prosecheck-activate.js", raw="{not json")
        self.assertIn("Prose contract", out)


class ContractShape(Env):
    def live(self, level):
        self.set_level(level)
        return self.contract()

    def test_lite_has_no_threshold_or_step(self):
        """N-000810, N-000335..N-000337: lite carries neither the 40 target nor 'light tells'."""
        text = self.live("lite")
        self.assertIsNone(re.search(r"(?<![\w.])40(?![\w.])", text))
        self.assertNotIn("light tells", text)
        self.assertNotIn("--clean", text)

    def test_full_target_and_no_cleanup_switch(self):
        """N-000805, N-000806: full shows target 40 and band; no --clean."""
        text = self.live("full")
        self.assertIsNotNone(re.search(r"(?<![\w.])40(?![\w.])", text))
        self.assertTrue("clean" in text or "light tells" in text)
        self.assertNotIn("--clean", text)

    def test_strict_target_and_clean_switch(self):
        """N-000807..N-000809: strict shows 20, band clean and the --clean finish."""
        text = self.live("strict")
        self.assertIsNotNone(re.search(r"(?<![\w.])20(?![\w.])", text))
        self.assertIn("--clean", text)

    def test_banned_words_all_present(self):
        """N-000803: every banned word appears as a standalone word."""
        text = self.live("full")
        for word in BANNED:
            self.assertIsNotNone(re.search(r"(?<![\w-])" + re.escape(word) + r"(?![\w-])", text), word)

    def test_source_code_sentence_has_never_or_not(self):
        """N-000804: every 'source code' mention has never/not earlier in its sentence."""
        text = self.live("full")
        for m in re.finditer(r"source[ -]code", text, re.I):
            start = max(text.rfind(".", 0, m.start()), text.rfind("!", 0, m.start()),
                         text.rfind("?", 0, m.start()), text.rfind("\n", 0, m.start()))
            sentence = text[start + 1:m.start()]
            self.assertRegex(sentence, r"\b(never|not)\b", sentence)

    def test_subagent_envelope(self):
        """N-000816..N-000818: subagent returns the same contract in the envelope."""
        self.set_level("full")
        out = json.loads(self.hook("prosecheck-subagent.js", {}))
        self.assertEqual(out["hookSpecificOutput"]["hookEventName"], "SubagentStart")
        self.assertIn("Prose contract", out["hookSpecificOutput"]["additionalContext"])

    def test_subagent_off_empty(self):
        """N-000815: off -> empty subagent output."""
        self.set_level("off")
        self.assertEqual(self.hook("prosecheck-subagent.js", {}).strip(), "")


class PromptRouter(Env):
    def test_ordinary_prompt_reminder(self):
        """N-000380..N-000383, N-000891..N-000892: reminder names the live level."""
        out = self.prompt("write a blog post")
        ctx = out["hookSpecificOutput"]["additionalContext"]
        self.assertIn("full", ctx)
        self.assertEqual(out["hookSpecificOutput"]["hookEventName"], "UserPromptSubmit")

    def test_stop_phrases_only_as_entire_prompt(self):
        """N-000885..N-000887, N-000475: entire-prompt stop phrases store off."""
        self.assertIn("off", self.reason("Stop Prosecheck"))
        self.assertIsNone(self.prompt("please stop prosecheck now"))
        with open(os.path.join(self.cfg, ".prosecheck-active")) as fh:
            self.assertEqual(fh.read().strip(), "off")

    def test_levels_store_and_confirm(self):
        """N-000471..N-000475, N-000904..N-000908: lite/full/strict store; on stores full."""
        for level in ["lite", "strict", "full"]:
            self.set_level(level)
            with open(os.path.join(self.cfg, ".prosecheck-active")) as fh:
                self.assertEqual(fh.read().strip(), level)
        self.reason("/prosecheck off")
        reply = self.reason("/prosecheck on")
        self.assertIn("on", words(reply))
        self.assertIn("full", words(reply))

    def test_unknown_word_keeps_level(self):
        """N-000882..N-000884, N-000574: unknown word reported, level unchanged."""
        self.set_level("strict")
        reply = self.reason("/prosecheck wibble")
        self.assertIn("unknown", reply.lower())
        self.assertIn("wibble", reply)
        for word in ["lite", "full", "strict", "off", "on", "status", "show", "check", "doctor", "stats", "init", "help"]:
            self.assertIn(word, words(reply))
        self.assertIn("strict", words(self.reason("/prosecheck status")))

    def test_namespaced_form_same_router(self):
        """N-000870..N-000872, N-000657: namespaced form behaves the same."""
        self.assertIn("full", self.reason("/prosecheck:prosecheck status"))

    def test_status_one_line(self):
        """N-000937..N-000941: status names one stored level."""
        reply = self.reason("/prosecheck status")
        self.assertEqual(len(reply.splitlines()), 1)

    def test_help_contract(self):
        """N-000910..N-000934: help lists every command with the required words."""
        reply = self.reason("/prosecheck help")
        lines = [l for l in reply.splitlines() if l.strip()]
        self.assertNotIn("40", words(lines[0]))
        self.assertIn("full", words(lines[0]))
        self.assertNotIn("lite", words(lines[0]))
        for word in ["code", "commits", "config", "chat", "never"]:
            self.assertIn(word, words(reply.lower()))
        self.assertIn("prosecheck this", reply)
        self.assertIn("humanize this", reply)
        self.assertFalse(any(l.startswith("/prosecheck help") for l in lines))
        expected = {"lite": ["contract", "scoring"], "full": ["contract", "guard", "40", "(default)"],
                    "strict": ["guard", "20", "scrub"], "off": ["disable"], "on": ["re-enable"],
                    "check": ["score", "rewrite"], "doctor": ["health"], "stats": ["token", "prose"],
                    "init": ["AGENTS.md", "contract"]}
        for cmd, wanted in expected.items():
            matches = [l for l in lines if re.search(r"/prosecheck " + cmd + r"\b", l)]
            self.assertTrue(matches, cmd)
            for w in wanted:
                self.assertTrue(any(w in m for m in matches), (cmd, w))
        self.assertEqual(len([l for l in lines if "/prosecheck lite" in l]), 1)

    def test_bare_is_help(self):
        """N-000468..N-000470: bare /prosecheck is help."""
        self.assertEqual(self.reason("/prosecheck"), self.reason("/prosecheck help"))

    def test_command_prompt_blocked_and_not_context(self):
        """N-000575..N-000577: command prompts use block decision."""
        out = self.prompt("/prosecheck status")
        self.assertIn("decision", out)
        self.assertNotIn("hookSpecificOutput", out)

    def test_off_ordinary_prompt_empty(self):
        """N-000888..N-000890: off -> empty output for ordinary prompts."""
        self.set_level("off")
        self.assertIsNone(self.prompt("write a post"))

    def test_show_empty_and_session_separation(self):
        """N-001035..N-001041, N-000853..N-000854: empty ledger text; sessions separate."""
        reply = self.reason("/prosecheck show", sid="empty-sess")
        self.assertIn("nothing scored yet", reply)
        self.assertIn(".docx", reply)
        self.assertIn(".pdf", reply)
        self.assertIsNone(re.search(r"\b\d{1,3}\b", reply))

    def test_doctor_four_ok_lines(self):
        """N-000995..N-001002, N-001017..N-001022: healthy install shows four [OK] lines."""
        reply = self.reason("/prosecheck:prosecheck doctor")
        lines = [l for l in reply.splitlines() if l.strip()]
        self.assertEqual(len([l for l in lines if "[OK]" in l]), 4)
        closer = lines[-1]
        self.assertIn("512 KB", closer)
        self.assertIn("4 MB", closer)
        self.assertIn("262,144", closer)
        self.assertIn("/prosecheck:prosecheck show", closer)
        self.assertNotIn("/prosecheck doctor", closer)

    def test_doctor_off_closer(self):
        """N-001003..N-001007, N-001026..N-001028: off mode closer names on, no fault."""
        self.set_level("off")
        reply = self.reason("/prosecheck doctor")
        lines = [l for l in reply.splitlines() if l.strip()]
        mode = [l for l in lines if l.startswith("mode:")][0]
        self.assertNotIn("[OK]", mode)
        self.assertIn("/prosecheck on", mode)
        self.assertIn("/prosecheck on", lines[-1])
        self.assertIn("scored", lines[-1])
        self.assertNotIn("/prosecheck doctor", lines[-1])
        self.assertNotIn("not re-scored", lines[-1])

    def test_doctor_python_absent(self):
        """N-001009..N-001014: python absent -> python line says not found and not re-scored."""
        bin_dir = os.path.join(self.tmp, "nopy")
        os.makedirs(bin_dir)
        node = shutil.which("node")
        os.symlink(node, os.path.join(bin_dir, "node"))
        env = dict(self.env, PATH=bin_dir)
        self.set_level("full")
        out = json.loads(self.hook("prosecheck-tracker.js", {"prompt": "/prosecheck doctor", "session_id": "x"}, env=env))
        lines = [l for l in out["reason"].splitlines() if l.strip()]
        py = [l for l in lines if "python" in l.lower()]
        self.assertEqual(len(py), 1)
        self.assertIn("python not found", py[0])
        self.assertIn("not re-scored", py[0])
        self.assertIn("prose", py[0])
        self.assertIn("/prosecheck doctor", lines[-1])
        self.assertIn("fix", lines[-1].lower())

    def test_check_replies(self):
        """N-000963..N-000992: check reply shapes for missing, directory, pdf, empty, scored."""
        sample = os.path.join(self.work, "sample.md")
        with open(sample, "w", encoding="utf-8") as fh:
            fh.write("Plain prose here.\n")
        scored = self.reason("/prosecheck check sample.md")
        self.assertIn("(score", scored)
        self.assertIn("report only", scored)
        self.assertIn("tells:", scored)
        missing = self.reason("/prosecheck check nothere.md")
        self.assertIn("cannot read", missing)
        self.assertIn("nothere.md", missing)
        os.makedirs(os.path.join(self.work, "adir"))
        self.assertIn("not a file", self.reason("/prosecheck check adir"))
        with open(os.path.join(self.work, "a.pdf"), "wb") as fh:
            fh.write(b"%PDF")
        self.assertIn("no readable text", self.reason("/prosecheck check a.pdf"))
        with open(os.path.join(self.work, "blank.md"), "w") as fh:
            fh.write("   \n")
        reply = self.reason("/prosecheck check blank.md")
        self.assertIn("failed", reply)
        self.assertNotIn("no report", reply)
        self.assertNotIn("was written by", scored)

    def test_check_no_path_and_quotes(self):
        """N-000957..N-000960, N-000975..N-000976: no path -> no score, no unknown; quotes and @ stripped."""
        reply = self.reason("/prosecheck check")
        self.assertNotIn("unknown", reply.lower())
        with open(os.path.join(self.work, "q.md"), "w") as fh:
            fh.write("Plain prose here.\n")
        self.assertIn("q.md - ", self.reason('/prosecheck check @"q.md"'))

    def test_init_writes_once_and_respects_levels(self):
        """N-000529..N-000542, N-001065..N-001102: init writes AGENTS.md once; off writes nothing."""
        self.set_level("off")
        reply = self.reason("/prosecheck init")
        self.assertIn("switched off", reply)
        self.assertIn("/prosecheck on", reply)
        self.assertFalse(os.path.exists(os.path.join(self.work, "AGENTS.md")))
        self.set_level("full")
        self.reason("/prosecheck init")
        self.reason("/prosecheck init")
        with open(os.path.join(self.work, "AGENTS.md"), encoding="utf-8") as fh:
            text = fh.read()
        self.assertEqual(text.count("prosecheck:contract:start"), 1)
        self.assertIn("CLAUDE_PLUGIN_ROOT", text)
        self.assertNotIn(self.work, text)
        self.assertNotIn(os.path.expanduser("~"), text)
        self.assertTrue(os.path.exists(os.path.join(self.work, ".cursor", "rules", "prosecheck.mdc")))

    def test_init_lite_export(self):
        """N-001075..N-001084: lite export has no skills/plugins/threshold/light tells."""
        self.set_level("lite")
        self.reason("/prosecheck init")
        with open(os.path.join(self.work, "AGENTS.md"), encoding="utf-8") as fh:
            text = fh.read()
        self.assertNotIn("skills", text)
        self.assertNotIn("plugins", text)
        self.assertNotIn("CLAUDE_PLUGIN_ROOT", text)
        self.assertNotIn("light tells", text)
        self.assertIsNone(re.search(r"(?<![\w.])40(?![\w.])", text))

    def test_cursor_rule_globs_and_body(self):
        """N-001088..N-001096: cursor rule globs are prose only; body has banned list."""
        with open(os.path.join(ROOT, ".cursor", "rules", "prosecheck.mdc"), encoding="utf-8") as fh:
            text = fh.read()
        front = text.split("---")[1]
        for g in ["*.md", "*.mdx", "*.markdown", "*.txt", "*.rst", "*.tex", "*.org", "*.adoc"]:
            self.assertIn(g, front)
        for g in ["*.py", "*.js", "*.ts", "*.json"]:
            self.assertNotIn(g, front)
        self.assertIn("prose deliverables only", text)
        self.assertNotIn("detect", text.lower())
        self.assertNotIn("light tells", text)
        self.assertIn("delve", text)


class Stats(Env):
    def test_stats_counts(self):
        """N-001103..N-001119: transcript totals, level, and own-prose score."""
        path = os.path.join(self.work, "t.jsonl")
        rows = [{"type": "user", "message": {"content": "hi"}}]
        text = ("This sentence is plain prose for the transcript. It is long enough that the slice "
                "passes the minimum size. " * 6)
        rows.append({"type": "assistant", "message": {"id": "m1", "content": [{"type": "text", "text": text}],
                     "usage": {"output_tokens": 120, "cache_read_input_tokens": 900}}})
        rows.append({"type": "assistant", "message": {"id": "m2", "content": [{"type": "text", "text": "Short."}],
                     "usage": {"output_tokens": 30, "cache_read_input_tokens": 100}}})
        with open(path, "w") as fh:
            fh.write("\n".join(json.dumps(r) for r in rows))
        reply = self.reason("/prosecheck stats", extra={"transcript_path": path})
        self.assertIn("assistant turns: 2", reply)
        self.assertIn("output tokens: 150", reply)
        self.assertIn("cache-read input tokens: 1000", reply)
        self.assertIn("level: full", reply)
        self.assertIn("session prose ai_tell_score:", reply)

    def test_stats_missing(self):
        """N-001120..N-001121: unreadable transcript -> no count lines."""
        reply = self.reason("/prosecheck stats", extra={"transcript_path": os.path.join(self.work, "none.jsonl")})
        self.assertNotIn("assistant turns:", reply)
        self.assertNotIn("output tokens:", reply)


class Guard(Env):
    def write(self, name, text):
        path = os.path.join(self.work, name)
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(text)
        return path

    def test_clean_file_no_output(self):
        """N-000416..N-000417: unflagged file -> no output."""
        self.write("clean.md", "The bridge opened in 1932. Engineers measured the steel twice.")
        out = self.hook("prosecheck-guard.js", {"tool_name": "Write", "tool_input": {"file_path": "clean.md"},
                                                "session_id": "g1", "cwd": self.work})
        self.assertEqual(out.strip(), "")

    def test_flagged_file_envelope(self):
        """N-000412..N-000415, N-000823..N-000832: flagged file nudges with the required fields."""
        self.write("draft.md", "Additionally, the team will delve into the landscape. Furthermore, "
                               "robust tapestry. Moreover, genuinely fascinating and nuanced. Certainly!")
        out = json.loads(self.hook("prosecheck-guard.js", {"tool_name": "Write",
                                                           "tool_input": {"file_path": "draft.md"},
                                                           "session_id": "g2", "cwd": self.work}))
        ctx = out["hookSpecificOutput"]["additionalContext"]
        self.assertIn("prosecheck: draft.md", ctx)
        self.assertIn("(score", ctx)
        self.assertIn("Flagged:", ctx)
        self.assertIn("fix", ctx.lower())

    def test_skips_instruction_and_binary(self):
        """N-000421..N-000428, N-000455..N-000456: instruction files skip ledger; pdf recorded as binary."""
        self.write("CLAUDE.md", "delve delve delve")
        self.write("x.pdf", "%PDF")
        for name in ["CLAUDE.md", "x.pdf"]:
            self.hook("prosecheck-guard.js", {"tool_name": "Write", "tool_input": {"file_path": name},
                                              "session_id": "g3", "cwd": self.work})
        ledger = os.path.join(self.cfg, ".prosecheck-ledger-g3")
        with open(ledger) as fh:
            recs = json.load(fh)
        self.assertEqual([r["base"] for r in recs], ["x.pdf"])
        self.assertEqual(recs[0]["kind"], "binary")

    def test_off_and_lite_silent(self):
        """N-000402..N-000403: off/lite do not score."""
        self.write("d.md", "Additionally, the team will delve into the landscape. Furthermore, robust tapestry.")
        self.set_level("lite")
        out = self.hook("prosecheck-guard.js", {"tool_name": "Write", "tool_input": {"file_path": "d.md"},
                                                "session_id": "g4", "cwd": self.work})
        self.assertEqual(out.strip(), "")

    def test_apply_patch_names_paths(self):
        """N-000395..N-000401, N-000833..N-000835: apply_patch lines name paths; one nudge per flagged file."""
        self.write("p.md", "Additionally, the team will delve into the landscape. Furthermore, robust tapestry. "
                           "Moreover, genuinely fascinating and nuanced. Certainly!")
        patch = "*** Begin Patch\n*** Update File: p.md\n@@\n-x\n+y\n*** End Patch"
        out = json.loads(self.hook("prosecheck-guard.js", {"tool_name": "apply_patch",
                                                           "tool_input": {"command": patch},
                                                           "session_id": "g5", "cwd": self.work}))
        self.assertIn("prosecheck: p.md", out["hookSpecificOutput"]["additionalContext"])

    def test_show_lists_guard_rows(self):
        """N-000518..N-000528, N-001042..N-001051: show lists guard rows with the phrase and score."""
        self.write("e.md", "Additionally, the team will delve into the landscape. Furthermore, robust tapestry.")
        self.hook("prosecheck-guard.js", {"tool_name": "Write", "tool_input": {"file_path": "e.md"},
                                          "session_id": "g6", "cwd": self.work})
        reply = self.reason("/prosecheck show", sid="g6")
        self.assertIn("e.md - reads", reply)
        self.assertIn("(score", reply)


if __name__ == "__main__":
    unittest.main()
