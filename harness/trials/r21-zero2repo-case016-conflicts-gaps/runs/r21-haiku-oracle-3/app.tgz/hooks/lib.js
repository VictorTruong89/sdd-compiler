'use strict';
// Shared logic for the prosecheck plugin hooks. Node.js standard library only.
// Every hook entry point calls into this file and always exits 0.

const fs = require('fs');
const path = require('path');
const os = require('os');
const cp = require('child_process');

// ---------------------------------------------------------------------------
// Constants (spec anchors: FP-04, FP-05, FP-06, Interface Contract)
// ---------------------------------------------------------------------------
const LEVELS = ['lite', 'full', 'strict', 'off'];
const FLAG_NAME = '.prosecheck-active';
const LEDGER_PREFIX = '.prosecheck-ledger';
const LEDGER_KEEP = 50;            // Interface Contract N-000729 (PRD says 20; see NOTES.md)
const LEDGER_MAX_AGE_MS = 24 * 60 * 60 * 1000; // Interface Contract N-000702 (see NOTES.md)
const PLAIN_CAP = 512 * 1024;      // bytes
const ARCHIVE_CAP = 4 * 1024 * 1024;
const PLAIN_TIMEOUT_MS = 8000;
const ARCHIVE_TIMEOUT_MS = 15000;
const WINDOW_TEXT = '262,144';
const GUARD_LABEL_CAP = 5;
const CHECK_LABEL_CAP = 8;
const SHOW_LABEL_CAP = 5;
const APPLY_PATCH_CAP = 10;        // Interface Contract N-000834
const STATS_SLICE = 40000;
const STATS_MIN_CHARS = 500;       // Interface Contract N-001117

const PLAIN_EXTS = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ZIP_EXTS = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'];
const NOTEBOOK_EXTS = ['.ipynb'];
const PROSE_EXTS = new Set(PLAIN_EXTS.concat(ZIP_EXTS, NOTEBOOK_EXTS));
const ARCHIVE_LIKE = new Set(ZIP_EXTS.concat(NOTEBOOK_EXTS));
const NO_TEXT_EXTS = new Set(['.pdf', '.rtf']);

const INSTRUCTION_EXACT = new Set(['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md']);
const INSTRUCTION_STEMS = new Set(['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory']);

const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster',
  'underscore', 'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament',
  'vibrant', 'comprehensive', 'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock',
  'game-changer', 'supercharge', 'genuinely', 'fascinating', 'nuanced'];

const PHRASE = {
  'clean': 'reads clean',
  'light tells': 'reads mostly clean',
  'mixed': 'reads with some AI tells',
  'heavy tells': 'reads with heavy AI tells',
  'pervasive tells': 'reads with pervasive AI tells',
};

const START_MARK = '<!-- prosecheck:contract:start -->';
const END_MARK = '<!-- prosecheck:contract:end -->';

const SUBCOMMANDS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];

// ---------------------------------------------------------------------------
// Paths and host environment (Interface Contract: Host environment)
// ---------------------------------------------------------------------------
function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}

function pluginRoot() {
  return process.env.CLAUDE_PLUGIN_ROOT || path.resolve(__dirname, '..');
}

function detectorPath() {
  const root = pluginRoot();
  const candidates = [path.join(root, 'scripts', 'detect.py'), path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py')];
  for (const p of candidates) {
    if (fs.existsSync(p)) return p;
  }
  return null;
}

function flagPath() {
  return path.join(configDir(), FLAG_NAME);
}

function validLevel(v) {
  const w = String(v || '').trim().toLowerCase();
  return LEVELS.indexOf(w) >= 0 ? w : null;
}

function storedLevel() {
  try {
    return validLevel(fs.readFileSync(flagPath(), 'utf8'));
  } catch (e) {
    return null;
  }
}

function writeStored(level) {
  fs.mkdirSync(configDir(), { recursive: true });
  fs.writeFileSync(flagPath(), level);
}

function envLevel() {
  return validLevel(process.env.PROSECHECK_DEFAULT_MODE);
}

// Environment wins when it names a valid level; otherwise the stored level; otherwise full.
function effectiveLevel() {
  return envLevel() || storedLevel() || 'full';
}

// ---------------------------------------------------------------------------
// Stdin, stdout and detector process
// ---------------------------------------------------------------------------
function readPayload() {
  let raw = '';
  try {
    raw = fs.readFileSync(0, 'utf8');
  } catch (e) {
    raw = '';
  }
  try {
    const o = JSON.parse(raw);
    return o && typeof o === 'object' && !Array.isArray(o) ? o : {};
  } catch (e) {
    return {};
  }
}

function emitJSON(obj) {
  process.stdout.write(JSON.stringify(obj) + '\n');
}

function runDetector(args, input, timeoutMs) {
  const det = detectorPath() || path.join(pluginRoot(), 'scripts', 'detect.py');
  for (const py of ['python3', 'python', 'py']) {
    const r = cp.spawnSync(py, [det].concat(args), {
      input: input || '',
      encoding: 'utf8',
      timeout: timeoutMs,
      maxBuffer: 64 * 1024 * 1024,
      windowsHide: true,
    });
    if (r.error) {
      if (r.error.code === 'ENOENT') continue;
      if (r.error.code === 'ETIMEDOUT') return { launched: true, timedOut: true, status: null, stdout: '', stderr: '' };
      return { launched: true, timedOut: false, status: -1, stdout: '', stderr: String(r.error.message) };
    }
    if (r.signal) {
      return { launched: true, timedOut: true, status: null, stdout: '', stderr: '' };
    }
    return { launched: true, timedOut: false, status: r.status, stdout: r.stdout || '', stderr: r.stderr || '' };
  }
  return { launched: false, timedOut: false, status: null, stdout: '', stderr: '' };
}

function parseReport(stdout) {
  let o;
  try {
    o = JSON.parse(stdout);
  } catch (e) {
    return null;
  }
  if (!o || typeof o !== 'object' || !o._metrics || typeof o._metrics !== 'object') return null;
  const sc = o._metrics.ai_tell_score;
  if (typeof sc !== 'number' || !Number.isFinite(sc)) return null;
  return o;
}

function errorFromStderr(stderr) {
  const lines = String(stderr || '').split('\n').map((s) => s.trim()).filter(Boolean);
  for (let i = lines.length - 1; i >= 0; i--) {
    try {
      const o = JSON.parse(lines[i]);
      if (o && typeof o.error === 'string') return o.error;
    } catch (e) {
      // not JSON; keep looking
    }
  }
  return lines.length ? lines[lines.length - 1] : '';
}

// Scan one file. Returns {kind:'scored', report} or {kind:'failed', reason}.
// The five failure kinds stay distinguishable (FP-05 N-000449 .. N-000454).
function scanFile(abs) {
  const ext = path.extname(abs).toLowerCase();
  const budget = ARCHIVE_LIKE.has(ext) ? ARCHIVE_TIMEOUT_MS : PLAIN_TIMEOUT_MS;
  const r = runDetector(['--', abs], '', budget);
  if (!r.launched) return { kind: 'failed', reason: 'Python not found on PATH' };
  if (r.timedOut) return { kind: 'failed', reason: 'the detector timed out' };
  if (r.status === 0) {
    if (!r.stdout.trim()) return { kind: 'failed', reason: 'detector produced no usable result' };
    const rep = parseReport(r.stdout);
    if (rep) return { kind: 'scored', report: rep };
    try {
      JSON.parse(r.stdout);
      return { kind: 'failed', reason: 'report has no numeric score' };
    } catch (e) {
      return { kind: 'failed', reason: 'detector output was not a structured report' };
    }
  }
  const msg = errorFromStderr(r.stderr);
  if (/^empty input/.test(msg)) return { kind: 'failed', reason: 'no extracted prose (empty input)' };
  if (/^cannot read/.test(msg)) return { kind: 'failed', reason: 'cannot read the file' };
  return { kind: 'failed', reason: 'detector produced no usable result' + (msg ? ' (' + msg + ')' : '') };
}

// ---------------------------------------------------------------------------
// Ledger (FP-05, Interface Contract "Plugin config and ledger")
// ---------------------------------------------------------------------------
function ledgerFile(sid) {
  const safe = String(sid || '').replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 120);
  return path.join(configDir(), safe ? LEDGER_PREFIX + '-' + safe : LEDGER_PREFIX);
}

function readLedger(sid) {
  try {
    const a = JSON.parse(fs.readFileSync(ledgerFile(sid), 'utf8'));
    return Array.isArray(a) ? a : [];
  } catch (e) {
    return [];
  }
}

function appendLedger(sid, rec) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    const a = readLedger(sid);
    a.push(Object.assign({ time: Date.now() }, rec));
    while (a.length > LEDGER_KEEP) a.shift();
    fs.writeFileSync(ledgerFile(sid), JSON.stringify(a));
  } catch (e) {
    // the ledger is best effort; the hook must not fail
  }
}

function cleanupLedgers() {
  let names;
  try {
    names = fs.readdirSync(configDir());
  } catch (e) {
    return;
  }
  const now = Date.now();
  for (const name of names) {
    if (name !== LEDGER_PREFIX && !name.startsWith(LEDGER_PREFIX + '-')) continue;
    const p = path.join(configDir(), name);
    try {
      const st = fs.statSync(p);
      if (st.isFile() && now - st.mtimeMs > LEDGER_MAX_AGE_MS) fs.unlinkSync(p);
    } catch (e) {
      // ignore
    }
  }
}

// ---------------------------------------------------------------------------
// Writing contract text (FP-04, Interface Contract hooks/prosecheck-activate.js)
// ---------------------------------------------------------------------------
function bannedLine() {
  return 'Do not use these words as standalone words: ' + BANNED.join(', ') + '.';
}

function contractBody(level, opts) {
  opts = opts || {};
  const L = [];
  L.push('## Prose contract (prosecheck, level: ' + level + ')');
  L.push('');
  L.push('This contract covers prose deliverables only: documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and drafted text the user will publish or send. It never applies to source code. It does not touch code comments, commit messages, JSON, YAML or other config, CLI output, logs, error messages, or the conversational register of chat; other modes own those.');
  L.push('');
  L.push('Rules for prose deliverables:');
  L.push('- Vary sentence length irregularly. Avoid a metronome and mechanical short-long alternation.');
  L.push('- ' + bannedLine());
  L.push('- Avoid these moves: rule-of-three flourishes; "it\'s not just X, it\'s Y"; hedge stacking; signposting such as "let\'s dive in"; empty pivots such as "it\'s worth noting"; "In conclusion" or "Overall" closers; outcome-speculation tails; self-thoroughness phrases; generic upbeat endings; chatbot phrases such as "I hope this helps".');
  L.push('- Use at most one em dash per paragraph.');
  L.push('- No bold for emphasis inside prose sentences. No emojis in prose.');
  L.push('- Factual or encyclopedic content stays neutral and in the third person. First-person or opinion content may use contractions.');
  L.push('- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.');
  L.push('- End sections on a fact or an observation.');
  L.push('- Stay silent: never announce this contract, never name prosecheck, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.');
  if (level === 'full' || level === 'strict') {
    L.push('');
    L.push('Checking prose files:');
    if (opts.portable) {
      L.push('- Detector location: use the directory in CLAUDE_PLUGIN_ROOT when that variable is set (scripts/detect.py under it); otherwise locate scripts/detect.py in your installed skills or plugins.');
    }
    const cmd = opts.portable ? 'python3 scripts/detect.py -- <file>' : 'python3 "' + (opts.detector || path.join(pluginRoot(), 'scripts', 'detect.py')) + '" -- <file>';
    L.push('- After writing or saving a prose file, run `' + cmd + '` on it.');
    if (level === 'full') {
      L.push('- Target: a score of 40 or lower, which is the band clean or light tells. If the band is worse, fix the flagged spans. Make at most two fix passes and keep the rhythm variation.');
    } else {
      const clean = opts.portable ? 'python3 scripts/detect.py --clean -- <file>' : 'python3 "' + (opts.detector || path.join(pluginRoot(), 'scripts', 'detect.py')) + '" --clean -- <file>';
      L.push('- Target: a score of 20 or lower, which is the band clean. If the band is worse, fix the flagged spans. Make at most two fix passes and keep the rhythm variation.');
      L.push('- Finish plain-text files through the cleanup switch: run `' + clean + '` and keep its output as the final text. Never write cleaned output over a .docx, .epub, .odt, or .ipynb file.');
    }
  }
  return L.join('\n');
}

function welcomeText(level) {
  return [
    'prosecheck is installed and on (level: ' + level + ').',
    'Saved prose files are scored against 71 patterns. Plain text is accepted up to 512 KB and archives up to 4 MB; the detector scores the first 262,144 characters.',
    'Useful commands: /prosecheck doctor, /prosecheck check, /prosecheck off, /prosecheck help.',
    'There is no website and no upload: analysis stays on this machine.',
    'This welcome is shown once.',
  ].join('\n');
}

function exportSection(level) {
  return START_MARK + '\n' + contractBody(level, { portable: true }) + '\n' + END_MARK + '\n';
}

// ---------------------------------------------------------------------------
// Hook entry points
// ---------------------------------------------------------------------------
function cleanupCall() {
  cleanupLedgers();
}

function activateMain() {
  cleanupCall();
  const firstRun = !fs.existsSync(flagPath());
  const stored = storedLevel();
  if (firstRun || stored === null) {
    try {
      writeStored('full');
    } catch (e) {
      // cannot store; the effective level still applies
    }
  }
  const eff = effectiveLevel();
  if (eff === 'off') return '';
  const body = contractBody(eff, { portable: false, detector: detectorPath() });
  return firstRun ? welcomeText(eff) + '\n\n' + body + '\n' : body + '\n';
}

function subagentMain() {
  const eff = effectiveLevel();
  if (eff === 'off') return null;
  return {
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: contractBody(eff, { portable: false, detector: detectorPath() }),
    },
  };
}

// ---------------------------------------------------------------------------
// Post-tool-use guard (FP-05)
// ---------------------------------------------------------------------------
function isUnder(child, parent) {
  const rel = path.relative(parent, child);
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function skipForLocation(abs) {
  const parts = abs.split(/[\\/]+/);
  if (parts.indexOf('node_modules') >= 0 || parts.indexOf('.git') >= 0) return true;
  return isUnder(abs, pluginRoot());
}

function isInstructionName(base) {
  const lower = base.toLowerCase();
  if (INSTRUCTION_EXACT.has(lower)) return true;
  const ext = path.extname(lower);
  const stem = ext ? lower.slice(0, -ext.length) : lower;
  return INSTRUCTION_STEMS.has(stem) && !PROSE_EXTS.has(ext);
}

function phraseFor(band) {
  return PHRASE[band] || PHRASE.clean;
}

function scoreOne(abs, sid, threshold) {
  const base = path.basename(abs);
  const ext = path.extname(abs).toLowerCase();
  if (skipForLocation(abs)) return null;
  if (isInstructionName(base)) return null;
  if (!PROSE_EXTS.has(ext) && !NO_TEXT_EXTS.has(ext)) return null;
  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    appendLedger(sid, { base, kind: 'failed', reason: 'unreadable file' });
    return null;
  }
  if (!st.isFile()) return null;
  if (NO_TEXT_EXTS.has(ext)) {
    appendLedger(sid, { base, kind: 'binary' });
    return null;
  }
  const cap = ARCHIVE_LIKE.has(ext) ? ARCHIVE_CAP : PLAIN_CAP;
  if (st.size > cap) {
    appendLedger(sid, { base, kind: 'skip', capKb: cap / 1024 });
    return null;
  }
  const res = scanFile(abs);
  if (res.kind !== 'scored') {
    appendLedger(sid, { base, kind: 'failed', reason: res.reason });
    return null;
  }
  const m = res.report._metrics;
  const labels = Object.keys(res.report).filter((k) => k !== '_metrics').map((k) => res.report[k].label);
  const flagged = m.ai_tell_score > threshold;
  const phrase = phraseFor(m.ai_tell_band);
  appendLedger(sid, {
    base, kind: 'scored', phrase, score: m.ai_tell_score, band: m.ai_tell_band,
    labels: labels.slice(0, GUARD_LABEL_CAP), flagged, truncated: !!m.truncated,
  });
  if (!flagged) return null;
  const cov = m.truncated ? ', first ' + WINDOW_TEXT + ' characters only' : '';
  const shown = labels.slice(0, GUARD_LABEL_CAP).join('; ') || 'none';
  return 'prosecheck: ' + base + ' ' + phrase + ' (score ' + m.ai_tell_score + ', band ' + m.ai_tell_band + cov + '). Flagged: ' + shown + '. Please fix the flagged spans.';
}

function guardMain(payload) {
  const eff = effectiveLevel();
  if (eff === 'off' || eff === 'lite') return null;
  const threshold = eff === 'strict' ? 20 : 40;
  const sid = typeof payload.session_id === 'string' ? payload.session_id : '';
  const ti = payload.tool_input && typeof payload.tool_input === 'object' ? payload.tool_input : {};
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const raw = [];
  for (const k of ['file_path', 'notebook_path']) {
    if (typeof ti[k] === 'string' && ti[k].trim()) raw.push(ti[k].trim());
  }
  if (typeof ti.command === 'string') {
    const re = /^\*\*\* (?:Add File|Update File|Move to):\s*(.+?)\s*$/gm;
    let m;
    while ((m = re.exec(ti.command)) !== null) raw.push(m[1]);
  }
  const seen = new Set();
  const paths = [];
  for (const p of raw) {
    const abs = path.resolve(cwd, p);
    if (!seen.has(abs)) {
      seen.add(abs);
      paths.push(abs);
    }
  }
  const lines = [];
  for (const abs of paths.slice(0, APPLY_PATCH_CAP)) {
    const line = scoreOne(abs, sid, threshold);
    if (line) lines.push(line);
  }
  if (!lines.length) return null;
  return { hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') } };
}

// ---------------------------------------------------------------------------
// Operator commands (FP-06, Interface Contract /prosecheck)
// ---------------------------------------------------------------------------
function helpReply(eff) {
  return [
    'prosecheck: the live level is ' + eff + '.',
    'Commands (the /prosecheck:prosecheck spelling works the same):',
    '/prosecheck lite - writing contract only, no scoring: the contract is placed in sessions; saved files are not checked.',
    '/prosecheck full - default. Writing contract plus the saved-file guard with threshold 40 (default).',
    '/prosecheck strict - the guard with threshold 20, plus the cleanup scrub for finished plain text.',
    '/prosecheck off - disable: no contract and no scoring until turned back on.',
    '/prosecheck on - re-enable at full.',
    '/prosecheck status - report the current level in one line.',
    '/prosecheck show - list the scored files of this session, newest first.',
    '/prosecheck check <file> - score one file (report only); it does not rewrite the file.',
    '/prosecheck doctor - health check of the install.',
    '/prosecheck stats - token use for this session and the score of its own prose.',
    '/prosecheck init - export the contract to AGENTS.md (and the Cursor rule) for other agents.',
    'code, commits, config, and chat are always left alone; never apply the contract to them.',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function unknownReply(word) {
  return 'Unknown prosecheck word "' + word + '". Valid words: ' + SUBCOMMANDS.join(', ') + '.';
}

function rowBody(r) {
  if (r.kind === 'scored') {
    let s = r.phrase + ' (score ' + r.score + '/' + r.band + (r.truncated ? ', first ' + WINDOW_TEXT + ' characters only' : '') + ')';
    if (r.labels && r.labels.length) {
      s += ' - ' + (r.flagged ? 'flagged' : 'under threshold') + ': ' + r.labels.slice(0, SHOW_LABEL_CAP).join('; ');
    }
    return s;
  }
  if (r.kind === 'skip') return 'not scored: file is over the ' + r.capKb + ' KB limit';
  if (r.kind === 'binary') return 'not re-scored (binary format, no readable text)';
  return 'not scored: ' + (r.reason || 'unknown reason');
}

function showReply(sid) {
  const recs = readLedger(sid).slice().reverse();
  if (!recs.length) {
    return 'Status: nothing scored yet. No file has been scored in this session; rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const rows = recs.map((r) => String(r.base) + ' - ' + rowBody(r));
  return ['Files checked in this session, newest first:'].concat(rows).join('\n');
}

function checkReply(arg, payload) {
  let s = String(arg || '').trim();
  if (s.charAt(0) === '@') s = s.slice(1);
  if (s.length >= 2 && (s[0] === '"' || s[0] === "'") && s[s.length - 1] === s[0]) s = s.slice(1, -1);
  s = s.trim();
  if (!s) return 'Usage: /prosecheck check <file path>. Give the path of one file; it is scored and not rewritten.';
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const abs = path.resolve(cwd, s);
  const base = path.basename(abs);
  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    return s + ' - cannot read: no file at that path.';
  }
  if (!st.isFile()) return base + ' - not a file.';
  const ext = path.extname(abs).toLowerCase();
  if (NO_TEXT_EXTS.has(ext)) return base + ' - no readable text in ' + ext + ' format.';
  const archive = ARCHIVE_LIKE.has(ext);
  const cap = archive ? ARCHIVE_CAP : PLAIN_CAP;
  if (st.size > cap) return base + ' - over ' + (cap / 1024) + ' KB; not scored.';
  const r = runDetector(['--', abs], '', archive ? ARCHIVE_TIMEOUT_MS : PLAIN_TIMEOUT_MS);
  if (!r.launched) return base + ' - detector unavailable: Python could not be launched.';
  if (r.timedOut) return base + ' - failed: the detector timed out.';
  if (r.status !== 0) {
    const msg = errorFromStderr(r.stderr);
    return base + ' - failed: ' + (msg || 'the detector exited without a result') + '.';
  }
  if (!r.stdout.trim()) return base + ' - no report.';
  const rep = parseReport(r.stdout);
  if (!rep) return 'no report: the detector output was not a structured report.';
  const m = rep._metrics;
  const lines = [];
  lines.push(base + ' - ' + phraseFor(m.ai_tell_band) + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')');
  let conf = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && m.confidence_reason) conf += ' - ' + m.confidence_reason;
  lines.push(conf);
  if (m.truncated) lines.push('coverage: first ' + WINDOW_TEXT + ' characters only');
  const tells = Object.keys(rep).filter((k) => k !== '_metrics').slice(0, CHECK_LABEL_CAP)
    .map((k) => rep[k].label + ' (x' + rep[k].count + ')');
  lines.push(tells.length ? 'tells: ' + tells.join('; ') : 'tells: none');
  lines.push('This is a report only; the file was not rewritten.');
  return lines.join('\n');
}

function doctorReply(eff, form) {
  const modeOk = eff !== 'off';
  const modeLine = modeOk
    ? 'mode: ' + eff + ' [OK]'
    : 'mode: off - not a fault of the install; run /prosecheck on to turn it back on.';

  const det = detectorPath();
  const detOk = !!det;
  const detLine = detOk
    ? 'detector: bundled detector found in the plugin tree [OK]'
    : 'detector: bundled detector is missing from the plugin tree';

  const probe = runDetector([], 'Sample prose for a health check of the install.', PLAIN_TIMEOUT_MS);
  let pyOk = false;
  let pyLine;
  if (!probe.launched) {
    pyLine = 'python: python not found on PATH; saved files are not re-scored until Python is available, and the writing contract still applies to new prose.';
  } else if (!probe.timedOut && probe.status === 0 && parseReport(probe.stdout)) {
    pyOk = true;
    pyLine = 'python: the interpreter ran the bundled detector and got a numeric score [OK]';
  } else {
    pyLine = 'python: the interpreter ran but the detector result is not a numeric score.';
  }

  let setOk = false;
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    const probeFile = path.join(configDir(), '.prosecheck-write-test-' + process.pid);
    fs.writeFileSync(probeFile, 'ok');
    fs.unlinkSync(probeFile);
    setOk = true;
  } catch (e) {
    setOk = false;
  }
  const setLine = setOk ? 'settings: settings folder is writable [OK]' : 'settings: settings folder is not writable';

  const allChecks = detOk && pyOk && setOk;
  let closer;
  if (!allChecks) {
    closer = 'Fix the faulty checks above, then run /prosecheck doctor again.';
  } else if (modeOk) {
    closer = 'Tool is active. Plain text is accepted up to 512 KB, archives and notebooks up to 4 MB, and the scan covers the first ' + WINDOW_TEXT + ' characters. To see files that were only partly scanned or skipped, run ' + form + ' show.';
  } else {
    closer = 'Install is healthy. Saved files are not scored while the tool is off; run ' + form + ' on to turn it back on.';
  }
  return ['prosecheck health report', modeLine, detLine, pyLine, setLine, closer].join('\n');
}

function statsReply(transcript, eff) {
  const file = typeof transcript === 'string' && transcript ? transcript : newestTranscript();
  let text = null;
  if (file) {
    try {
      text = fs.readFileSync(file, 'utf8');
    } catch (e) {
      text = null;
    }
  }
  if (text === null) {
    return 'stats: no readable transcript was found for this session. level: ' + eff;
  }
  const byId = new Map();
  let rowNo = 0;
  for (const line of text.split('\n')) {
    const t = line.trim();
    if (!t) continue;
    let o;
    try {
      o = JSON.parse(t);
    } catch (e) {
      continue;
    }
    if (!o || o.type !== 'assistant' || !o.message || typeof o.message !== 'object') continue;
    rowNo++;
    const msg = o.message;
    const id = String(msg.id || o.uuid || 'row' + rowNo);
    const usage = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    const entry = byId.get(id) || { out: 0, cache: 0, text: '' };
    entry.out = Math.max(entry.out, Number(usage.output_tokens) || 0);
    entry.cache = Math.max(entry.cache, Number(usage.cache_read_input_tokens) || 0);
    let txt = '';
    if (Array.isArray(msg.content)) {
      for (const c of msg.content) {
        if (c && c.type === 'text' && typeof c.text === 'string') txt += (txt ? '\n' : '') + c.text;
      }
    } else if (typeof msg.content === 'string') {
      txt = msg.content;
    }
    if (txt) entry.text = txt;
    byId.set(id, entry);
  }
  let outTok = 0;
  let cacheTok = 0;
  const parts = [];
  for (const e of byId.values()) {
    outTok += e.out;
    cacheTok += e.cache;
    if (e.text) parts.push(e.text);
  }
  const prose = parts.join('\n\n').replace(/```[\s\S]*?```/g, '');
  const slice = prose.slice(-STATS_SLICE).trim();
  const lines = [
    'assistant turns: ' + byId.size,
    'output tokens: ' + outTok,
    'cache-read input tokens: ' + cacheTok,
    'level: ' + eff,
  ];
  if (slice.length > STATS_MIN_CHARS) {
    const r = runDetector([], slice, PLAIN_TIMEOUT_MS);
    const rep = r.launched && r.status === 0 ? parseReport(r.stdout) : null;
    if (rep) lines.push('session prose ai_tell_score: ' + rep._metrics.ai_tell_score);
  }
  return lines.join('\n');
}

function newestTranscript() {
  const root = path.join(configDir(), 'projects');
  let best = null;
  let bestT = -1;
  const walk = (dir, depth) => {
    if (depth > 6) return;
    let ents;
    try {
      ents = fs.readdirSync(dir, { withFileTypes: true });
    } catch (e) {
      return;
    }
    for (const e of ents) {
      const p = path.join(dir, e.name);
      if (e.isDirectory()) {
        walk(p, depth + 1);
      } else if (e.isFile() && e.name.endsWith('.jsonl')) {
        try {
          const m = fs.statSync(p).mtimeMs;
          if (m > bestT) {
            bestT = m;
            best = p;
          }
        } catch (err) {
          // ignore
        }
      }
    }
  };
  walk(root, 0);
  return best;
}

function initReply(eff, form, cwd) {
  if (eff === 'off') {
    return 'prosecheck is switched off, so no files were written (not AGENTS.md, not the Cursor rule). Run ' + form + ' on to allow the export.';
  }
  const out = [];
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = '';
  let readFailed = false;
  try {
    existing = fs.readFileSync(agents, 'utf8');
  } catch (e) {
    if (e.code !== 'ENOENT') readFailed = true;
    existing = '';
  }
  if (readFailed) {
    out.push('AGENTS.md: cannot read it, so no contract was written.');
  } else if (existing.indexOf(START_MARK) >= 0) {
    out.push('AGENTS.md already contains the prosecheck contract; it was left unchanged.');
  } else {
    const head = existing ? (existing.endsWith('\n') ? existing : existing + '\n') + '\n' : '';
    try {
      fs.writeFileSync(agents, head + exportSection(eff));
      out.push('Wrote the writing contract to AGENTS.md.');
    } catch (e) {
      out.push('AGENTS.md: cannot write it, so no contract was written.');
    }
  }
  const ruleSrc = path.join(pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
  const ruleDst = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(ruleDst)) {
    out.push('.cursor/rules/prosecheck.mdc already exists; it was left unchanged.');
  } else {
    try {
      const data = fs.readFileSync(ruleSrc);
      fs.mkdirSync(path.dirname(ruleDst), { recursive: true });
      fs.writeFileSync(ruleDst, data);
      out.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      out.push('cannot write .cursor/rules/prosecheck.mdc: the shipped rule could not be copied.');
    }
  }
  return out.join('\n');
}

function setLevelReply(level, form) {
  writeStored(level);
  if (level === 'lite') return 'prosecheck level set to lite: the writing contract is on; saved files are not scored.';
  if (level === 'full') return 'prosecheck level set to full: the writing contract is on and saved prose is scored (threshold 40).';
  if (level === 'strict') return 'prosecheck level set to strict: the writing contract is on; saved prose is scored with threshold 20 and the cleanup scrub is offered.';
  return 'prosecheck is off. The contract is not placed and saved files are not scored. Run ' + form + ' on to turn it back on.';
}

// Route a prompt. Returns {block: reason} | {context: text} | null.
function routePrompt(payload) {
  const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
  const sid = typeof payload.session_id === 'string' ? payload.session_id : '';
  const trimmed = prompt.trim();
  const lower = trimmed.toLowerCase();
  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    writeStored('off');
    return { block: 'prosecheck is off (stop phrase received). Run /prosecheck on to turn it back on.' };
  }
  const m = /^\/prosecheck(:prosecheck)?(?=\s|$)/i.exec(trimmed);
  if (m) {
    const form = m[0].toLowerCase();
    const rest = trimmed.slice(m[0].length).trim();
    const parts = rest.split(/\s+/);
    const sub = (parts[0] || '').toLowerCase();
    const arg = rest.slice((parts[0] || '').length).trim();
    const eff = effectiveLevel();
    let reply;
    switch (sub) {
      case '':
      case 'help':
        reply = helpReply(eff);
        break;
      case 'lite':
      case 'full':
      case 'strict':
      case 'off':
        reply = setLevelReply(sub, form);
        break;
      case 'on':
        writeStored('full');
        reply = 'prosecheck is on at level full.';
        break;
      case 'status':
        reply = 'prosecheck level: ' + eff;
        break;
      case 'show':
        reply = showReply(sid);
        break;
      case 'check':
        reply = checkReply(arg, payload);
        break;
      case 'doctor':
        reply = doctorReply(eff, form);
        break;
      case 'stats':
        reply = statsReply(payload.transcript_path, eff);
        break;
      case 'init':
        reply = initReply(eff, form, typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd());
        break;
      default:
        reply = unknownReply(parts[0]);
    }
    return { block: reply };
  }
  const eff = effectiveLevel();
  if (eff === 'off') return null;
  return {
    context: 'prosecheck level: ' + eff + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.',
  };
}

function promptMain(payload) {
  const r = routePrompt(payload);
  if (!r) return null;
  if (r.block !== undefined) return { decision: 'block', reason: r.block };
  return { hookSpecificOutput: { hookEventName: 'UserPromptSubmit', additionalContext: r.context } };
}

module.exports = {
  activateMain,
  subagentMain,
  guardMain,
  promptMain,
  statsReply,
  readPayload,
  emitJSON,
  effectiveLevel,
  configDir,
  pluginRoot,
  detectorPath,
  contractBody,
  exportSection,
  routePrompt,
  initReply,
  doctorReply,
  checkReply,
  showReply,
  helpReply,
  BANNED,
  START_MARK,
  END_MARK,
  SUBCOMMANDS,
  welcomeText,
};
