#!/usr/bin/env node
'use strict';
// stats hook: prints token figures and the own-prose score for a transcript.
// Input: JSON on stdin with optional transcript_path. Same reply as "/prosecheck stats".
const lib = require('./lib');
try {
  const payload = lib.readPayload();
  process.stdout.write(lib.statsReply(payload.transcript_path, lib.effectiveLevel()) + '\n');
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
