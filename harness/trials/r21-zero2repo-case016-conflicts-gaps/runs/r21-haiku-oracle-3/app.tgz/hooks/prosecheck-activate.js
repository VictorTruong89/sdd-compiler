#!/usr/bin/env node
'use strict';
// session-start hook: places the writing contract (and the first-run welcome).
const lib = require('./lib');
try {
  lib.readPayload();
  const text = lib.activateMain();
  if (text) process.stdout.write(text);
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
