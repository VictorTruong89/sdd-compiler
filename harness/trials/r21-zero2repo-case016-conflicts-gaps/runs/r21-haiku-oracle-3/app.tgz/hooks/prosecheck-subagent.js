#!/usr/bin/env node
'use strict';
// subagent-start hook: returns the same writing contract inside the host's JSON envelope.
const lib = require('./lib');
try {
  lib.readPayload();
  const out = lib.subagentMain();
  if (out) lib.emitJSON(out);
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
