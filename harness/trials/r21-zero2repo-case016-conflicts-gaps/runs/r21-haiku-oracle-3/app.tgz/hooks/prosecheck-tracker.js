#!/usr/bin/env node
'use strict';
// prompt-submit hook: /prosecheck command router, stop phrases, and the live-level reminder.
const lib = require('./lib');
try {
  const payload = lib.readPayload();
  const out = lib.promptMain(payload);
  if (out) lib.emitJSON(out);
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
