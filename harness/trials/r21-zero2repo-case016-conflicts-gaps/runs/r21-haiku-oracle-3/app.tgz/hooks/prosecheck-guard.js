#!/usr/bin/env node
'use strict';
// post-tool-use hook: scores a just-saved prose file and nudges when it is flagged.
const lib = require('./lib');
try {
  const payload = lib.readPayload();
  const out = lib.guardMain(payload);
  if (out) lib.emitJSON(out);
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
