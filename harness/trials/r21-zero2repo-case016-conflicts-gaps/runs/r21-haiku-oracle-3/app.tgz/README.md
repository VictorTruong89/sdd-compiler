# prosecheck

A local detector for AI-writing patterns. It is a command-line tool and an agent plugin. There is no website, no account, and no hosted version. Nothing you write is uploaded, and no text leaves the machine.

- **Detector**: `python3 scripts/detect.py [--clean] [--ci] [--] [FILE]` scores prose (a file or standard input) on a 0–100 scale, in one of five bands, and prints a JSON report. `--clean` prints scrubbed text instead.
- **Plugin hooks** (Node.js, `hooks/`): session start places the writing contract, prompt submit routes the `/prosecheck` commands, subagent start passes the contract on, and post-tool-use scores a just-saved prose file and nudges when it is flagged.
- **Commands**: `/prosecheck` (or `/prosecheck:prosecheck`) with `lite`, `full`, `strict`, `off`, `on`, `status`, `show`, `check`, `doctor`, `stats`, `init`, `help`.

## Requirements

- Python 3.9 or newer (standard library only; no packages to install).
- Node.js for the hooks. No runtime dependencies.
- CPU-only, Linux, macOS, or Windows. No network access is used.

There is no build step. Run the detector from this directory:

```
python3 scripts/detect.py draft.md
python3 scripts/detect.py --clean draft.md > scrubbed.md
cat draft.md | python3 scripts/detect.py
```

Run the test suite:

```
python3 -m unittest discover -s tests -v
```

## Configuration

| Variable | Purpose |
|---|---|
| `CLAUDE_CONFIG_DIR` | Where the level flag (`.prosecheck-active`) and session ledgers are kept. Default: `~/.claude`. |
| `CLAUDE_PLUGIN_ROOT` | Plugin root. Default: the directory that contains `hooks/`. |
| `PROSECHECK_DEFAULT_MODE` | One of `lite`, `full`, `strict`, `off`. When set to a valid word it is used as the level. |

## Layout

```
scripts/detect.py          detector (stdlib only)
hooks/lib.js               shared hook logic
hooks/prosecheck-*.js      session-start, prompt-submit, subagent-start, post-tool-use, stats
hooks/hooks.json           host hook registration
commands/prosecheck.md     /prosecheck menu document (install/ has a copy)
.cursor/rules/prosecheck.mdc  Cursor rule for prose files (copied by /prosecheck init)
.claude-plugin/plugin.json plugin manifest
tests/                     unit and hook tests
spec/                      the specification (not modified)
NOTES.md                   decisions on spec conflicts and gaps
SPEC_COVERAGE.md           status of every spec checklist id
```

## Scope and limits

- The detector scores English prose. Code, configuration, commit messages, and chat register are out of scope for the contract and the guard.
- Only the first 262,144 characters of extracted prose are scanned.
- Plain text is accepted up to 512 KB and zip-based documents and notebooks up to 4 MB, measured as file size on disk.
- The twenty supported formats are: `.md`, `.mdx`, `.markdown`, `.txt`, `.text`, `.rst`, `.tex`, `.org`, `.adoc`, `.docx`, `.docm`, `.pptx`, `.pptm`, `.xlsx`, `.xlsm`, `.odt`, `.odp`, `.ods`, `.epub`, `.ipynb`. PDF and RTF are not read.

## Not authorship

A score, a band, and a hook phrase describe writing. They do not name a person or a model as the author. The score is a triage heuristic on the writing in front of the detector, not an authorship classifier. It must not be used to accuse anyone.

## Privacy

The plugin stores a one-word mode flag and a per-session ledger of file base names, scores, and up to five pattern labels. It never stores document text or full paths. Ledgers older than one day are removed at session start.
