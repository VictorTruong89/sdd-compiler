# SPEC_COVERAGE

Status of every id in `spec/CHECKLIST.md` (1126 ids). Each id is **implemented** unless a row says otherwise. The location column names the code that carries the behaviour; the test suites are listed in `NOTES.md` section 4. `spec/CHECKLIST.md` itself is unchanged.

Total ids: 1126. Not done: 2. Implemented by omission: 13. Implemented: 1111.

Status key: `implemented` = behaviour built and exercised by the test suite (`python3 -m unittest discover -s tests`); `implemented (by omission)` = a non-goal or a MUST NOT that the build satisfies by not doing the thing; `not done` = listed with a reason.

## Pack 02 — no compiled code, no runtime dependencies

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000588 | requirement · MUST · L1 | implemented | scripts/detect.py (stdlib only); README.md |
| N-000589 | requirement · MUST NOT · C | implemented | scripts/detect.py (stdlib only); README.md |
| N-000590 | requirement · MUST · L1 | implemented | scripts/detect.py (stdlib only); README.md |
| N-000591 | requirement · MUST · L1 | implemented | scripts/detect.py (stdlib only); README.md |
| N-000592 | requirement · MUST · L1 | implemented | scripts/detect.py (stdlib only); README.md |

## Pack 03 — run from the source tree; no build step

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000593 | requirement · MUST · L1 | implemented | scripts/detect.py; hooks/*.js (node); README.md Requirements |
| N-000594 | requirement · MUST · L4 | implemented | scripts/detect.py; hooks/*.js (node); README.md Requirements |
| N-000595 | requirement · MUST · L1 | implemented | scripts/detect.py; hooks/*.js (node); README.md Requirements |
| N-000596 | requirement · MUST · L1 | implemented | scripts/detect.py; hooks/*.js (node); README.md Requirements |
| N-000597 | requirement · MUST · L1 | implemented | scripts/detect.py; hooks/*.js (node); README.md Requirements |
| N-000598 | requirement · MUST · C | implemented | scripts/detect.py; hooks/*.js (node); README.md Requirements |
| N-000599 | requirement · MUST NOT · — | implemented | scripts/detect.py; hooks/*.js (node); README.md Requirements |
| N-000600 | requirement · MUST NOT · L2 | implemented | scripts/detect.py; hooks/*.js (node); README.md Requirements |
| N-000601 | requirement · MUST · L1 | implemented | scripts/detect.py; hooks/*.js (node); README.md Requirements |
| N-000602 | requirement · MUST · L1 | implemented | scripts/detect.py; hooks/*.js (node); README.md Requirements |

## Pack 04 — product overview: local, no network, prose only

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000001 | requirement · MUST NOT · L2 | implemented | README.md; hooks/lib.js; scripts/detect.py |
| N-000002 | constraint · MUST NOT · C | implemented | README.md; hooks/lib.js; scripts/detect.py |
| N-000003 | constraint · MUST NOT · L1 | implemented | README.md; hooks/lib.js; scripts/detect.py |
| N-000004 | (pack 04) no text leaves the machine | implemented | README.md; hooks/lib.js; scripts/detect.py |
| N-000005 | requirement · — · — | implemented | README.md; hooks/lib.js; scripts/detect.py |
| N-000006 | requirement · MUST · L1 | implemented | README.md; hooks/lib.js; scripts/detect.py |
| N-000007 | requirement · MUST · L5 | implemented | README.md; hooks/lib.js; scripts/detect.py |
| N-000008 | requirement · MUST · L1 | implemented | README.md; hooks/lib.js; scripts/detect.py |
| N-000009 | requirement · MUST · L1 | implemented | README.md; hooks/lib.js; scripts/detect.py |
| N-000010 | requirement · MAY · L1 · needs N-000044 (pack 06) | implemented | README.md; hooks/lib.js; scripts/detect.py |
| N-000011 | constraint · MUST · C | implemented | README.md; hooks/lib.js; scripts/detect.py |
| N-000012 | constraint · MUST NOT · C | implemented | README.md; hooks/lib.js; scripts/detect.py |
| N-000013 | (pack 04) Prose only, never code. | implemented | README.md; hooks/lib.js; scripts/detect.py |
| N-000014 | example of N-000006 | implemented | README.md; hooks/lib.js; scripts/detect.py |
| N-000015 | constraint · MUST · C | implemented | README.md; hooks/lib.js; scripts/detect.py |
| N-000016 | (pack 04) Every feature point below corresponds to behavior that exists in the finished prosecheck product (version 0.9.3). | implemented | README.md; hooks/lib.js; scripts/detect.py |
| N-000017 | (pack 04) Feature points are ordered so foundational capabilities come first | implemented | README.md; hooks/lib.js; scripts/detect.py |
| N-000018 | (pack 04) a later feature point may refine an earlier one only when it says so explicitly | implemented | README.md; hooks/lib.js; scripts/detect.py |

## Pack 05 — terminology as used by the detector and hooks

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000019 | requirement · MUST · L1 | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000020 | requirement · MUST · L1 | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000021 | requirement · MUST · L2 | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000022 | requirement · MUST · L1 | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000023 | constraint · MUST NOT · L0 | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000024 | (pack 05) Every band describes the prose; none of them names an author. | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000025 | requirement · MUST · L1 | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000026 | (pack 05) **Writing contract** … It governs prose deliverables only. | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000027 | (pack 05) **Writing contract** … It never touches source code, comments, commits, configuration, or the chat register. | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000028 | requirement · MUST · L1 | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000029 | requirement · MUST · L1 · needs N-000680 (pack 19) | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000030 | requirement · MUST · L1 | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000031 | (pack 05) **Scan window** … Everything past that window is unread. | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000032 | (pack 05) **Scan window** … Character-layer rules use the same window. | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000033 | requirement · MUST · L1 | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000034 | requirement · MUST · L1 · needs N-000178 (pack 10) | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000035 | requirement · MUST · L1 · needs N-000177 (pack 10) | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000036 | requirement · MUST · L1 | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000037 | requirement · MUST · L1 | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000038 | (pack 05) **Character cleanup** … Visible text is left alone. | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000039 | requirement · MUST · L1 | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |
| N-000040 | requirement · MUST NOT · L1 | implemented | scripts/detect.py (score, band, catalogue, cleanup); hooks/lib.js (hook phrase, level, ledger) |

## Pack 06 — public surface inventory

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000041 | constraint · MUST · L1 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000042 | constraint · MUST · L1 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000043 | constraint · MUST NOT · C | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000044 | requirement · MUST · L1 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000045 | requirement · MUST · L1 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000046 | requirement · MUST · L1 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000047 | requirement · MUST · L1 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000048 | requirement · MUST · L1 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000049 | (pack 06) They do not invent additional product surfaces. | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000050 | requirement · MUST · L1 | not done — bundled skill file not shipped: the spec says it is not a feature point and is not a detector obligation (pack 06) | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000051 | constraint · MUST NOT · L1 | not done — bundled skill file not shipped: see N-000050 (pack 06) | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |

## Pack 07 — non-functional constraints

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000052 | requirement · MUST · C | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000053 | constraint · MUST NOT · C | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000054 | constraint · MUST NOT · C | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000055 | constraint · MUST · C | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000056 | constraint · MUST · L1 | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000057 | requirement · MUST · C | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000058 | requirement · MUST · — · needs N-000590 (pack 02) | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000059 | requirement · MUST · C | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000060 | requirement · MUST · L1 | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000061 | constraint · MUST · C | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000062 | constraint · MUST · L2 | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000063 | constraint · MUST · L2 | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000064 | constraint · MUST NOT · C | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000065 | constraint · MUST NOT · C | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000066 | requirement · MUST · C | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000067 | constraint · MUST · — | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000068 | requirement · MUST · L1 | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000069 | requirement · MUST · L1 | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000070 | requirement · MUST · L1 | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000071 | (pack 07) Scope of language:** … English prose is the supported scope. | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000072 | constraint · MUST NOT · — | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000073 | constraint · MUST NOT · L0 | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000074 | requirement · MUST · C | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000075 | constraint · MUST NOT · C | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000076 | constraint · MUST · L1 | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |
| N-000077 | requirement · MUST NOT · L1 | implemented | scripts/detect.py (determinism, no network); hooks/lib.js (ledger size, 1-day cleanup) |

## Pack 08 — required substance: real detector and real hooks

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000078 | (pack 08) Every feature point below is delivered by the real local detector or the real plugin hooks, on the machine, with no accelerator. | implemented | scripts/detect.py; hooks/lib.js |
| N-000079 | requirement · MUST · L1 | implemented | scripts/detect.py; hooks/lib.js |
| N-000080 | requirement · MUST · L1 | implemented | scripts/detect.py; hooks/lib.js |
| N-000081 | requirement · MUST · L2 | implemented | scripts/detect.py; hooks/lib.js |

## Pack 09 — non-goals: nothing built for them

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000082 | constraint · MUST NOT · L1 | implemented (by omission) | omitted by design |
| N-000083 | constraint · MUST NOT · L1 | implemented (by omission) | omitted by design |
| N-000084 | constraint · MUST NOT · — | implemented (by omission) | omitted by design |
| N-000085 | constraint · MUST NOT · L2 | implemented (by omission) | omitted by design |
| N-000086 | constraint · MUST NOT · L1 | implemented (by omission) | omitted by design |
| N-000087 | constraint · MUST NOT · L1 | implemented (by omission) | omitted by design |
| N-000088 | (pack 09) The writing contract still applies to whoever composed the text. | implemented (by omission) | omitted by design |
| N-000089 | constraint · MUST NOT · L2 | implemented (by omission) | omitted by design |
| N-000090 | constraint · MUST NOT · — | implemented (by omission) | omitted by design |
| N-000091 | constraint · MUST NOT · L1 | implemented (by omission) | omitted by design |
| N-000092 | constraint · MUST NOT · L2 | implemented (by omission) | omitted by design |
| N-000093 | constraint · MUST NOT · L2 | implemented (by omission) | omitted by design |

## Pack 10 — FP-01 scan, families, score, bands, errors

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000094 | requirement · MAY · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000095 | requirement · MAY · L1 · needs N-000733 (pack 21) | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000096 | requirement · MAY · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000097 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000098 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000099 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000100 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000101 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000102 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000103 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000104 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000105 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000106 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000107 | requirement · MUST · L1 · needs N-000292 (pack 11) | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000108 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000109 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000110 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000111 | requirement · MUST · L1 · needs N-000025 (pack 05), N-000682 (pack 19) | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000112 | requirement · MUST · L1 · needs N-000111 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000113 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000114 | requirement · MUST · L1 · needs N-000177 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000115 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000116 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000117 | requirement · — · L2 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000118 | requirement · MAY · L1 · needs N-000117 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000119 | requirement · — · L1 · needs N-000117, N-000128 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000120 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000121 | requirement · MUST NOT · L5 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000122 | requirement · MUST · C | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000123 | requirement · — · L1 · needs N-000128 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000124 | requirement · — · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000125 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000126 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000127 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000128 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000129 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000130 | decision · — · — | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000131 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000132 | requirement · MUST · L1 · needs N-000134, N-000136 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000133 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000134 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000135 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000136 | requirement · MUST · L1 · needs N-000146, N-000765 (pack 21) | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000137 | requirement · MUST NOT · L1 · needs N-000025 (pack 05), N-000146, N-000682 (pack 19) | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000138 | requirement · MUST · L1 · needs N-000118, N-000131 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000139 | requirement · MUST · L1 · needs N-000131 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000140 | requirement · — · — | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000141 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000142 | requirement · MUST · L1 · needs N-000143 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000143 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000144 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000145 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000146 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000147 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000148 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000149 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000150 | requirement · MUST · C | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000151 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000152 | requirement · MUST · L4 · needs N-000346 (pack 13) | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000153 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000154 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000155 | requirement · MAY · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000156 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000157 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000158 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000159 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000160 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000161 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000162 | requirement · MUST · L1 · needs N-000128 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000163 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000164 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000165 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000166 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000167 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000168 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000169 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000170 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000171 | requirement · MUST · L1 · needs N-000033 (pack 05), N-000304 (pack 12) | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000172 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000173 | constraint · — · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000174 | requirement · — · L4 · needs N-000128 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000175 | requirement · — · — | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000176 | constraint · — · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000177 | requirement · — · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000178 | requirement · — · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000179 | requirement · MUST NOT · L1 · needs N-000307 (pack 12) | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000180 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000181 | constraint · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000182 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000183 | decision · — · — | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000184 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000185 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000186 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000187 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000188 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000189 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000190 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000191 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000192 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000193 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000194 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000195 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000196 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000197 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000198 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000199 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000200 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000201 | constraint · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000202 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000203 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000204 | constraint · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000205 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000206 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000207 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000208 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000209 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000210 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000211 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000212 | requirement · — · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000213 | decision · — · — | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000214 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000215 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000216 | requirement · MUST NOT · L1 · needs N-000128 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000217 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000218 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000219 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000220 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000221 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000222 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000223 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000224 | constraint · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000225 | decision · — · L5 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000226 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000227 | (pack 10) Every source of empty extracted prose (empty standard input, a file that decodes to nothing or to whitespace only, a notebook with no markdown cells, an archive with no extractable prose, PDF, and RTF) is one failure kind | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000228 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000229 | requirement · — · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000230 | requirement · MUST · L1 · needs N-000289 (pack 11) | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000231 | requirement · MUST · L1 · needs N-000737 (pack 21) | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000232 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000233 | requirement · MUST · L1 · needs N-000097 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000234 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000235 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000236 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000237 | requirement · MUST · L1 · needs N-000281 (pack 11) | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000238 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000239 | (pack 10) Findings, including character-layer findings, are computed only on the window. | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000240 | requirement · MUST NOT · L1 · needs N-000293 (pack 11) | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000241 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |
| N-000242 | requirement · MUST · L1 | implemented | scripts/detect.py: run_checks, score_document, build_report, main; tests/test_detector.py |

## Pack 11 — FP-02 formats, caps, window, errors

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000243 | requirement · MUST · — · needs N-000245, N-000404 (pack 14) | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000244 | requirement · MUST · L2 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000245 | requirement · MUST · L4 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000246 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000247 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000248 | (pack 11) Those caps are file size on disk, as the guard and `/prosecheck check` enforce them, in binary units: | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000249 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000250 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000251 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000252 | requirement · MUST · — | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000253 | requirement · MUST · L1 · needs N-000251 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000254 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000255 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000256 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000257 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000258 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000259 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000260 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000261 | constraint · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000262 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000263 | constraint · MAY · L4 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000264 | requirement · MUST · L1 · needs N-000645 (pack 18) | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000265 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000266 | constraint · MUST NOT · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000267 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000268 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000269 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000270 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000271 | requirement · MUST · L1 · needs N-000646 (pack 18) | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000272 | constraint · MUST NOT · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000273 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000274 | requirement · MUST · L1 · needs N-000080 (pack 08), N-000273 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000275 | constraint · MUST NOT · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000276 | requirement · MUST NOT · L1 · needs N-000331 (pack 12) | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000277 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000278 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000279 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000280 | requirement · MUST · L1 · needs N-000277 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000281 | requirement · MUST · L5 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000282 | constraint · MUST NOT · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000283 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000284 | constraint · MUST NOT · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000285 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000286 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000287 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000288 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000289 | requirement · MUST · L1 · needs N-000283, N-000287 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000290 | constraint · MUST NOT · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000291 | decision · — · — | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000292 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000293 | (pack 11) Character-layer rules (62, 66, 67, 68) use that same window | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000294 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000295 | (pack 11) Source-code extensions (for example `.py`, `.js`) are not among the twenty formats. | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000296 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000297 | requirement · MUST · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |
| N-000298 | constraint · — · L1 | implemented | scripts/detect.py: extract_source and _docx/_pptx/_xlsx/_odf/_epub/_notebook helpers; hooks/lib.js caps |

## Pack 12 — FP-03 cleanup

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000299 | requirement · MUST · L1 · needs N-000734 (pack 21) | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000300 | requirement · MUST · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000301 | requirement · MUST · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000302 | constraint · MUST NOT · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000303 | requirement · MUST · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000304 | requirement · MUST · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000305 | After cleanup, a rescan (FP-01) reports zero invisible-character hits. | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000306 | requirement · MUST · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000307 | constraint · MUST NOT · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000308 | requirement · MUST · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000309 | After cleanup, a rescan reports zero non-standard-space hits. | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000310 | requirement · MUST · L1 · needs N-000128 (pack 10), N-000177 (pack 10) | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000311 | constraint · MUST NOT · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000312 | requirement · MUST · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000313 | requirement · MUST · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000314 | requirement · MUST · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000315 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000316 | requirement · MUST · C | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000317 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000318 | requirement · MUST · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000319 | requirement · MUST · C | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000320 | requirement · MUST · L1 · needs N-000647 (pack 18) | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000321 | (pack 12) the same budget the saved-file guard gives plain text (FP-05) | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000322 | requirement · MUST · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000323 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000324 | requirement · MUST · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000325 | requirement · MUST · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000326 | constraint · MUST NOT · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000327 | constraint · MUST NOT · C | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000328 | constraint · MUST NOT · C | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000329 | constraint · MUST NOT · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000330 | requirement · MUST · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |
| N-000331 | requirement · MUST · L1 | implemented | scripts/detect.py: cleanup_text, invisible_indices, nonstandard_space_indices, fold_homoglyphs; tests/test_detector.py (N-000305, N-000309) |

## Pack 13 — FP-04 always-on contract

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000332 | requirement · MUST · L2 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000333 | requirement · MUST · L3 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000334 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000335 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000336 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000337 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000338 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000339 | constraint · MUST NOT · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000340 | (pack 13) It names what it never touches (code comments, commit messages, JSON/YAML/config, CLI output, logs, error messages, the conversational register of chat) | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000341 | (pack 13) composes with other modes | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000342 | requirement · MUST · L2 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000343 | requirement · MUST · L2 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000344 | (pack 13) It names what it never touches (code comments, commit messages, JSON/YAML/config, CLI output, logs, error messages, the conversational register of chat) … this contract owns deliverable prose | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000345 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000346 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000347 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000348 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000349 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000350 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000351 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000352 | requirement · MAY · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000353 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000354 | constraint · MUST NOT · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000355 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000356 | constraint · MUST NOT · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000357 | constraint · MUST NOT · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000358 | constraint · MUST NOT · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000359 | requirement · MUST · L5 · needs N-000346 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000360 | requirement · MUST · L5 · needs N-000128 (pack 10) | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000361 | requirement · MUST · L5 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000362 | requirement · MUST · L5 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000363 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000364 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000365 | requirement · — · L1 · needs N-000391, N-000686 (pack 19) | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000366 | requirement · MUST · L1 · needs N-000115 (pack 10), N-000677 (pack 19) | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000367 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000368 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000369 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000370 | requirement · MUST · L1 · needs N-000068 (pack 07) | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000371 | requirement · MUST · L1 · needs N-000370 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000372 | requirement · MUST · L1 · needs N-000246 (pack 11), N-000370 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000373 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000374 | requirement · MUST · L1 · needs N-000370 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000375 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000376 | requirement · MUST · — | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000377 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000378 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000379 | requirement · MUST · L4 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000380 | requirement · MUST · — | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000381 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000382 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000383 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000384 | requirement · MUST · L3 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000385 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000386 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000387 | constraint · MUST NOT · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000388 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000389 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000390 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000391 | requirement · MUST · L1 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000392 | decision · MAY · — · needs N-000007 (pack 04) | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000393 | decision · — · — · needs N-000007 (pack 04) | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |
| N-000394 | constraint · MUST NOT · L4 | implemented | hooks/lib.js: contractBody, welcomeText, activateMain, subagentMain, promptMain; hooks/prosecheck-activate.js, prosecheck-subagent.js, prosecheck-tracker.js |

## Pack 14 — FP-05 saved-file guard

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000395 | requirement · MUST · L2 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000396 | assumption · — · L3 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000397 | requirement · MUST NOT · — | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000398 | decision · — · — | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000399 | requirement · MUST NOT · L4 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000400 | requirement · MUST · — | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000401 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000402 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000403 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000404 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000405 | requirement · MUST NOT · L1 · needs N-000404 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000406 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000407 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000408 | requirement · MUST NOT · L5 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000409 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000410 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000411 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000412 | requirement · MUST · L3 · needs N-000680 (pack 19) | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000413 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000414 | requirement · MUST · — | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000415 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000416 | requirement · MUST · — | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000417 | requirement · MUST NOT · — | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000418 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000419 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000420 | requirement · MUST · L1 · needs N-000646 (pack 18) | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000421 | requirement · MUST · — | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000422 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000423 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000424 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000425 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000426 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000427 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000428 | requirement · MAY · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000429 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000430 | requirement · MUST · L1 · needs N-000029 (pack 05) | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000431 | requirement · MUST · L4 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000432 | requirement · MUST · L4 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000433 | requirement · MUST · L1 · needs N-000246 (pack 11) | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000434 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000435 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000436 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000437 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000438 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000439 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000440 | (pack 14) Those budgets are the product’s published caps. | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000441 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000442 | requirement · MUST · — | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000443 | requirement · MUST · L1 · needs N-000442 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000444 | requirement · MUST · — | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000445 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000446 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000447 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000448 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000449 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000450 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000451 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000452 | decision · — · — · needs N-000451 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000453 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000454 | requirement · MUST · L1 · needs N-000444 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000455 | requirement · MUST · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |
| N-000456 | constraint · — · L1 | implemented | hooks/lib.js: guardMain, scoreOne, scanFile, isInstructionName; hooks/prosecheck-guard.js |

## Pack 15 — FP-06 commands

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000457 | requirement · MUST · — | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000458 | assumption · — · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000459 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000460 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000461 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000462 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000463 | assumption · — · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000464 | assumption · — · L3 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000465 | requirement · MUST · L2 · needs N-000658 (pack 18) | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000466 | requirement · MUST · L1 · needs N-000726 (pack 20), N-000901 (pack 31) | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000467 | requirement · MUST NOT · — | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000468 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000469 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000470 | requirement · MUST · L1 · needs N-000468, N-000663 (pack 18), N-000873 (pack 31) | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000471 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000472 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000473 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000474 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000475 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000476 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000477 | requirement · MUST · L1 · needs N-000048 (pack 06) | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000478 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000479 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000480 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000481 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000482 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000483 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000484 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000485 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000486 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000487 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000488 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000489 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000490 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000491 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000492 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000493 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000494 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000495 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000496 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000497 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000498 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000499 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000500 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000501 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000502 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000503 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000504 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000505 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000506 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000507 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000508 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000509 | requirement · MUST · L1 · needs N-000502 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000510 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000511 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000512 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000513 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000514 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000515 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000516 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000517 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000518 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000519 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000520 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000521 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000522 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000523 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000524 | requirement · MUST · L1 · needs N-000246 (pack 11) | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000525 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000526 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000527 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000528 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000529 | requirement · MUST · — | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000530 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000531 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000532 | requirement · MUST · — | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000533 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000534 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000535 | requirement · MUST · — | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000536 | requirement · MUST · — | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000537 | requirement · MUST · — | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000538 | requirement · MUST · — | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000539 | requirement · MUST · L1 · needs N-000026 (pack 05), N-000338 (pack 13), N-000346 (pack 13) | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000540 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000541 | requirement · — · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000542 | requirement · MUST NOT · L3 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000543 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000544 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000545 | requirement · MUST · L1 · needs N-001111 (pack 39) | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000546 | requirement · MUST · — | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000547 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000548 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000549 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000550 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000551 | requirement · MUST · L5 · needs N-000549 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000552 | requirement · MUST · L5 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000553 | requirement · MUST · L5 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000554 | requirement · MUST · L1 · needs N-000553 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000555 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000556 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000557 | decision · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000558 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000559 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000560 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000561 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000562 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000563 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000564 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000565 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000566 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000567 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000568 | decision · — · — | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000569 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000570 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000571 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000572 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000573 | requirement · MUST NOT · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000574 | requirement · MUST NOT · L1 · needs N-000663 (pack 18) | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000575 | requirement · MUST · L1 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000576 | requirement · MUST · L3 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |
| N-000577 | requirement · MUST · L1 · needs N-000475 | implemented | hooks/lib.js: routePrompt, helpReply, setLevelReply, showReply, checkReply, doctorReply, initReply, statsReply; commands/prosecheck.md |

## Pack 16 — cross-cutting: local only, not authorship

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000578 | (pack 16) - **Prose only.** Code, configuration, commits, and chat register are out of scope for the contract and the guard. | implemented | hooks/lib.js (no network); README.md Not authorship, Privacy |
| N-000579 | requirement · MUST NOT · C | implemented | hooks/lib.js (no network); README.md Not authorship, Privacy |
| N-000580 | requirement · MUST NOT · C | implemented | hooks/lib.js (no network); README.md Not authorship, Privacy |
| N-000581 | requirement · MUST · L1 | implemented | hooks/lib.js (no network); README.md Not authorship, Privacy |
| N-000582 | requirement · MUST NOT · L1 | implemented | hooks/lib.js (no network); README.md Not authorship, Privacy |
| N-000583 | requirement · MUST · L1 | implemented | hooks/lib.js (no network); README.md Not authorship, Privacy |
| N-000584 | requirement · MUST · L1 | implemented | hooks/lib.js (no network); README.md Not authorship, Privacy |
| N-000585 | constraint · MUST NOT · C | implemented | hooks/lib.js (no network); README.md Not authorship, Privacy |
| N-000586 | requirement · MUST · L1 | implemented | hooks/lib.js (no network); README.md Not authorship, Privacy |
| N-000587 | requirement · MUST · L1 | implemented | hooks/lib.js (no network); README.md Not authorship, Privacy |

## Pack 17 — product overview interface

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000603 | requirement · MUST NOT · L2 | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000604 | requirement · MUST NOT · C | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000605 | requirement · MUST NOT · C | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000606 | requirement · MUST NOT · C | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000607 | requirement · MUST · L1 | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000608 | requirement · MUST · L5 | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000609 | requirement · MUST · L5 · needs N-000045 (pack 06), N-000116 (pack 10) | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000610 | requirement · MUST · L1 · needs N-000028 (pack 05), N-000609 | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000611 | requirement · MAY · L1 | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000612 | example of N-000607 | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000613 | requirement · MUST NOT · C | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000614 | requirement · MUST · L1 · needs N-000601 (pack 03) | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000615 | requirement · MUST · L1 | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000616 | requirement · MUST NOT · C | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000617 | requirement · MUST NOT · L2 | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000618 | requirement · MUST NOT · C | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000619 | requirement · MUST · L4 | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000620 | requirement · MUST · L4 | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000621 | requirement · MUST NOT · L1 | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000622 | requirement · MUST NOT · L3 | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000623 | requirement · MUST · L2 · needs N-000675 (pack 19) | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000624 | requirement · MUST · L2 · needs N-000615 | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000625 | requirement · MUST · L1 | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |
| N-000626 | requirement · MAY · L5 | implemented | README.md; hooks/lib.js (no network); scripts/detect.py |

## Pack 18 — shape of public surface

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000627 | requirement · MUST NOT · L2 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000628 | requirement · MUST · L3 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000629 | requirement · MUST · L3 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000630 | requirement · MUST · L1 · needs N-000632 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000631 | requirement · MUST · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000632 | requirement · MUST · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000633 | requirement · MUST · L3 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000634 | constraint · MUST · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000635 | requirement · MUST NOT · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000636 | requirement · MUST · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000637 | requirement · MAY · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000638 | requirement · MAY · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000639 | requirement · MUST · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000640 | requirement · MUST · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000641 | requirement · MUST · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000642 | constraint · MAY · — | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000643 | requirement · MUST · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000644 | requirement · MUST · L4 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000645 | requirement · MUST · L4 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000646 | requirement · MUST · L4 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000647 | requirement · MUST · L1 · needs N-000246 (pack 11), N-000247 (pack 11), N-000249 (pack 11) | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000648 | constraint · MUST · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000649 | requirement · MUST · — | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000650 | requirement · MUST NOT · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000651 | requirement · MUST · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000652 | requirement · MUST · L3 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000653 | requirement · MUST · L2 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000654 | requirement · MUST · L2 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000655 | requirement · MUST · L2 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000656 | requirement · MUST · L2 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000657 | requirement · MUST · L2 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000658 | requirement · MUST · L2 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000659 | requirement · MUST · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000660 | requirement · MUST · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000661 | requirement · MUST · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000662 | requirement · MUST · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000663 | (pack 18) Subcommands are exactly: `lite`, `full`, `strict`, `off`, `on`, `status`, `show`, `check`, `doctor`, `stats`, `init`, `help | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000664 | requirement · MUST · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000665 | requirement · MUST · — | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000666 | requirement · MUST · — | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000667 | requirement · MUST · L3 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000668 | constraint · MUST NOT · C | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000669 | constraint · MUST NOT · C | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000670 | constraint · MUST NOT · C | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000671 | constraint · MUST NOT · L1 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000672 | constraint · MUST NOT · L5 | implemented | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |
| N-000673 | constraint · MUST NOT · L1 | implemented (by omission) | hooks/hooks.json; scripts/detect.py; hooks/*.js; .claude-plugin/plugin.json |

## Pack 19 — naming conventions, bands, levels, host environment

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000674 | requirement · MUST · L1 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000675 | requirement · MUST · L2 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000676 | requirement · MUST · L2 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000677 | requirement · MUST · L1 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000678 | requirement · MUST · L1 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000679 | requirement · MUST · L1 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000680 | requirement · MUST · L1 · needs N-000115 (pack 10), N-000679 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000681 | requirement · MUST · L1 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000682 | requirement · MUST · L1 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000683 | requirement · MUST · L3 · needs N-000111 (pack 10) | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000684 | constraint · MAY · L4 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000685 | requirement · MUST · L1 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000686 | requirement · MAY · L4 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000687 | requirement · MUST · L1 · needs N-000116 (pack 10) | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000688 | requirement · MUST · L4 · needs N-000117 (pack 10), N-000687 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000689 | constraint · MAY · L4 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000690 | (pack 19) Each variable below governs exactly the behaviours listed; nothing else reads it | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000691 | requirement · MUST · — | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000692 | requirement · MUST · — | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000693 | requirement · MUST · — · needs N-000692 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000694 | requirement · MUST · — | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000695 | requirement · MUST · — | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000696 | requirement · MUST · L5 · needs N-000695 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000697 | requirement · MUST · L1 · needs N-000694, N-000695 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000698 | requirement · MUST · L5 · needs N-000695 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000699 | requirement · MUST · L5 · needs N-000694, N-000695 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000700 | requirement · MUST · L2 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000701 | requirement · MUST · L1 · needs N-000471 (pack 15) | implemented | hooks/lib.js constants and environment handling; README.md Configuration |
| N-000702 | requirement · MUST · L1 | implemented | hooks/lib.js constants and environment handling; README.md Configuration |

## Pack 20 — global observables

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000703 | (pack 20) Readable non-empty extracted prose, help that prints usage, cleanup that prints scrubbed text, and a two-or-more-file run that still scans the first file: exit 0. | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000704 | requirement · MUST · C | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000705 | requirement · MUST · L4 · needs N-000778 (pack 21) | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000706 | requirement · MUST · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000707 | requirement · MUST · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000708 | requirement · MUST · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000709 | requirement · MUST · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000710 | requirement · MUST · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000711 | requirement · MUST · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000712 | requirement · MUST · L1 · needs N-000737 (pack 21) | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000713 | requirement · MUST · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000714 | requirement · MUST NOT · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000715 | requirement · MUST NOT · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000716 | requirement · MUST · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000717 | requirement · MUST · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000718 | requirement · MUST NOT · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000719 | requirement · MUST · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000720 | requirement · MUST · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000721 | requirement · MUST · — | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000722 | requirement · MUST · — | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000723 | requirement · MUST · L4 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000724 | requirement · MUST · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000725 | requirement · MUST · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000726 | requirement · MUST · L4 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000727 | requirement · MUST · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000728 | requirement · MUST · L4 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000729 | requirement · MUST · L1 | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |
| N-000730 | (pack 20) Every hook process exits 0. | implemented | scripts/detect.py (exit codes, error objects, streams); hooks/*.js (always exit 0) |

## Pack 21 — detector command interface

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000731 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000732 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000733 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000734 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000735 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000736 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000737 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000738 | requirement · MAY · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000739 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000740 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000741 | requirement · MAY · — · needs N-000641 (pack 18) | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000742 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000743 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000744 | requirement · MUST · L4 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000745 | requirement · MUST · L4 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000746 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000747 | requirement · MAY · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000748 | constraint · MAY · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000749 | requirement · MUST · L4 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000750 | requirement · MUST · L4 · needs N-000123 (pack 10) | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000751 | requirement · MUST · L1 · needs N-000123 (pack 10) | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000752 | requirement · MAY · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000753 | requirement · MUST · L4 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000754 | requirement · MUST · L4 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000755 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000756 | requirement · MAY · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000757 | requirement · MAY · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000758 | requirement · MAY · C | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000759 | requirement · MUST NOT · C | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000760 | requirement · MUST · L4 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000761 | constraint · MUST · L4 · needs N-000045 (pack 06) | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000762 | requirement · MUST · L4 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000763 | constraint · MUST · L4 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000764 | requirement · MUST · L4 · needs N-000115 (pack 10), N-000677 (pack 19), N-000763 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000765 | constraint · MUST · L4 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000766 | requirement · MUST · L4 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000767 | requirement · MAY · L4 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000768 | requirement · MUST · L4 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000769 | requirement · MUST · L4 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000770 | requirement · MUST · L4 · needs N-000735 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000771 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000772 | requirement · MUST · L1 · needs N-000770 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000773 | requirement · MAY · L4 · needs N-000638 (pack 18), N-000770 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000774 | requirement · MAY · L4 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000775 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000776 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000777 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000778 | requirement · MUST · L4 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000779 | constraint · MUST NOT · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000780 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000781 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000782 | requirement · MUST · L1 · needs N-000737 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000783 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000784 | requirement · MUST · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000785 | requirement · MAY · L1 · needs N-000784 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000786 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |
| N-000787 | requirement · MUST NOT · L1 | implemented | scripts/detect.py: main, build_report, errors; tests/test_detector.py |

## Pack 22 — session-start hook

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000788 | requirement · MUST · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000789 | requirement · MUST · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000790 | requirement · MUST · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000791 | requirement · MUST · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000792 | requirement · MUST · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000793 | requirement · MUST · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000794 | requirement · MUST · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000795 | requirement · MUST · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000796 | requirement · MUST · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000797 | requirement · MUST · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000798 | requirement · MAY · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000799 | requirement · MUST · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000800 | requirement · MUST · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000801 | requirement · MUST NOT · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000802 | requirement · MUST · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000803 | requirement · MUST · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000804 | requirement · MUST · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000805 | requirement · MUST · L1 · needs N-000115 (pack 10), N-000366 (pack 13), N-000907 (pack 31) | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000806 | requirement · MUST NOT · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000807 | requirement · MUST · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000808 | requirement · MUST · L1 · needs N-000677 (pack 19) | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000809 | requirement · MUST · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000810 | requirement · MUST NOT · L1 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000811 | constraint · MAY · — | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |
| N-000812 | decision · — · L4 | implemented | hooks/prosecheck-activate.js; hooks/lib.js activateMain, contractBody; tests/test_hooks.py SessionStart |

## Pack 23 — subagent-start hook

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000813 | requirement · MUST · L1 | implemented | hooks/prosecheck-subagent.js; hooks/lib.js subagentMain; tests/test_hooks.py |
| N-000814 | requirement · MUST · L4 | implemented | hooks/prosecheck-subagent.js; hooks/lib.js subagentMain; tests/test_hooks.py |
| N-000815 | requirement · MUST · L1 | implemented | hooks/prosecheck-subagent.js; hooks/lib.js subagentMain; tests/test_hooks.py |
| N-000816 | requirement · MUST · L1 | implemented | hooks/prosecheck-subagent.js; hooks/lib.js subagentMain; tests/test_hooks.py |
| N-000817 | requirement · MUST · L4 | implemented | hooks/prosecheck-subagent.js; hooks/lib.js subagentMain; tests/test_hooks.py |
| N-000818 | requirement · MUST NOT · L4 | implemented | hooks/prosecheck-subagent.js; hooks/lib.js subagentMain; tests/test_hooks.py |

## Pack 24 — post-tool-use reply

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000819 | requirement · MUST · L1 | implemented | hooks/prosecheck-guard.js; hooks/lib.js guardMain; tests/test_hooks.py Guard |
| N-000820 | requirement · MUST · L1 | implemented | hooks/prosecheck-guard.js; hooks/lib.js guardMain; tests/test_hooks.py Guard |
| N-000821 | requirement · MUST · L1 | implemented | hooks/prosecheck-guard.js; hooks/lib.js guardMain; tests/test_hooks.py Guard |
| N-000822 | requirement · MAY · L4 | implemented | hooks/prosecheck-guard.js; hooks/lib.js guardMain; tests/test_hooks.py Guard |
| N-000823 | requirement · MUST · L4 | implemented | hooks/prosecheck-guard.js; hooks/lib.js guardMain; tests/test_hooks.py Guard |
| N-000824 | requirement · MUST · L4 | implemented | hooks/prosecheck-guard.js; hooks/lib.js guardMain; tests/test_hooks.py Guard |
| N-000825 | requirement · MUST · L4 | implemented | hooks/prosecheck-guard.js; hooks/lib.js guardMain; tests/test_hooks.py Guard |
| N-000826 | requirement · MUST · L4 | implemented | hooks/prosecheck-guard.js; hooks/lib.js guardMain; tests/test_hooks.py Guard |
| N-000827 | requirement · MUST · L1 | implemented | hooks/prosecheck-guard.js; hooks/lib.js guardMain; tests/test_hooks.py Guard |
| N-000828 | requirement · MUST · L1 | implemented | hooks/prosecheck-guard.js; hooks/lib.js guardMain; tests/test_hooks.py Guard |
| N-000829 | requirement · MUST · L1 | implemented | hooks/prosecheck-guard.js; hooks/lib.js guardMain; tests/test_hooks.py Guard |
| N-000830 | requirement · MAY · — | implemented | hooks/prosecheck-guard.js; hooks/lib.js guardMain; tests/test_hooks.py Guard |
| N-000831 | requirement · MUST · L1 | implemented | hooks/prosecheck-guard.js; hooks/lib.js guardMain; tests/test_hooks.py Guard |
| N-000832 | requirement · MUST · L1 | implemented | hooks/prosecheck-guard.js; hooks/lib.js guardMain; tests/test_hooks.py Guard |
| N-000833 | requirement · MUST · L1 | implemented | hooks/prosecheck-guard.js; hooks/lib.js guardMain; tests/test_hooks.py Guard |
| N-000834 | constraint · MUST NOT · L1 | implemented | hooks/prosecheck-guard.js; hooks/lib.js guardMain; tests/test_hooks.py Guard |
| N-000835 | requirement · MUST NOT · L1 | implemented | hooks/prosecheck-guard.js; hooks/lib.js guardMain; tests/test_hooks.py Guard |

## Pack 25 — content field

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000836 | assumption · — · L3 | implemented | hooks/lib.js guardMain (tool_input.content is part of the payload, not used as the scored file) |
| N-000837 | requirement · MUST · L4 | implemented | hooks/lib.js guardMain (tool_input.content is part of the payload, not used as the scored file) |
| N-000838 | requirement · MUST · L4 | implemented | hooks/lib.js guardMain (tool_input.content is part of the payload, not used as the scored file) |
| N-000839 | requirement · MUST · L2 | implemented | hooks/lib.js guardMain (tool_input.content is part of the payload, not used as the scored file) |
| N-000840 | constraint · MUST · L4 | implemented | hooks/lib.js guardMain (tool_input.content is part of the payload, not used as the scored file) |

## Pack 26 — cwd field

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000841 | assumption · — · L3 | implemented | hooks/lib.js guardMain and checkReply (payload cwd) |
| N-000842 | requirement · MUST · L4 | implemented | hooks/lib.js guardMain and checkReply (payload cwd) |
| N-000843 | requirement · MUST · L4 · needs N-000842 | implemented | hooks/lib.js guardMain and checkReply (payload cwd) |

## Pack 27 — file_path field

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000844 | requirement · MUST · L4 · needs N-000858 (pack 29) | implemented | hooks/lib.js guardMain (tool_input.file_path, resolved against cwd) |
| N-000845 | requirement · MUST · L1 | implemented | hooks/lib.js guardMain (tool_input.file_path, resolved against cwd) |
| N-000846 | requirement · MUST · L4 | implemented | hooks/lib.js guardMain (tool_input.file_path, resolved against cwd) |

## Pack 28 — prompt and session_id fields

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000847 | assumption · — · L3 | implemented | hooks/prosecheck-tracker.js; hooks/lib.js promptMain, routePrompt |
| N-000848 | assumption · — · L3 | implemented | hooks/prosecheck-tracker.js; hooks/lib.js promptMain, routePrompt |
| N-000849 | requirement · MUST · L4 | implemented | hooks/prosecheck-tracker.js; hooks/lib.js promptMain, routePrompt |
| N-000850 | requirement · MUST · L1 | implemented | hooks/prosecheck-tracker.js; hooks/lib.js promptMain, routePrompt |
| N-000851 | requirement · MUST · L4 | implemented | hooks/prosecheck-tracker.js; hooks/lib.js promptMain, routePrompt |
| N-000852 | requirement · MUST · L1 | implemented | hooks/prosecheck-tracker.js; hooks/lib.js promptMain, routePrompt |
| N-000853 | requirement · MUST · L4 | implemented | hooks/prosecheck-tracker.js; hooks/lib.js promptMain, routePrompt |
| N-000854 | constraint · MUST NOT · C | implemented | hooks/prosecheck-tracker.js; hooks/lib.js promptMain, routePrompt |
| N-000855 | requirement · MUST · L1 | implemented | hooks/prosecheck-tracker.js; hooks/lib.js promptMain, routePrompt |
| N-000856 | requirement · MUST · L1 | implemented | hooks/prosecheck-tracker.js; hooks/lib.js promptMain, routePrompt |

## Pack 29 — tool_input field

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000857 | requirement · MUST · L3 | implemented | hooks/lib.js guardMain (tool_input object, notebook_path, command) |
| N-000858 | constraint · MUST · L4 | implemented | hooks/lib.js guardMain (tool_input object, notebook_path, command) |
| N-000859 | requirement · MUST · L3 | implemented | hooks/lib.js guardMain (tool_input object, notebook_path, command) |
| N-000860 | requirement · MUST · L3 | implemented | hooks/lib.js guardMain (tool_input object, notebook_path, command) |
| N-000861 | requirement · MUST · L3 | implemented | hooks/lib.js guardMain (tool_input object, notebook_path, command) |
| N-000862 | requirement · MUST · L3 | implemented | hooks/lib.js guardMain (tool_input object, notebook_path, command) |
| N-000863 | constraint · MUST NOT · L4 | implemented | hooks/lib.js guardMain (tool_input object, notebook_path, command) |

## Pack 30 — tool_name field

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000864 | requirement · MUST · L3 | implemented | hooks/lib.js guardMain (tool_name, apply_patch) |
| N-000865 | requirement · MUST · L3 | implemented | hooks/lib.js guardMain (tool_name, apply_patch) |
| N-000866 | constraint · MUST · L3 | implemented | hooks/lib.js guardMain (tool_name, apply_patch) |
| N-000867 | requirement · MUST · L3 | implemented | hooks/lib.js guardMain (tool_name, apply_patch) |
| N-000868 | constraint · MUST · L3 | implemented | hooks/lib.js guardMain (tool_name, apply_patch) |
| N-000869 | requirement · MUST · L3 | implemented | hooks/lib.js guardMain (tool_name, apply_patch) |

## Pack 31 — /prosecheck router and block decision

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000870 | requirement · MUST · L1 · needs N-000458 (pack 15) | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000871 | requirement · MUST · L2 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000872 | requirement · MUST · L1 · needs N-000461 (pack 15) | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000873 | constraint · MUST · L1 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000874 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000875 | requirement · MUST NOT · L1 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000876 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000877 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000878 | constraint · MUST NOT · L1 · needs N-000475 (pack 15) | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000879 | requirement · MUST · C | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000880 | requirement · MUST · C | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000881 | constraint · MAY · C | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000882 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000883 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000884 | requirement · MUST NOT · L4 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000885 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000886 | requirement · MUST · L4 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000887 | requirement · MUST · — | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000888 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000889 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000890 | requirement · MUST · L4 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000891 | requirement · MUST · — | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000892 | constraint · MAY · — | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000893 | constraint · MUST · L2 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000894 | requirement · MUST · L2 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000895 | requirement · MUST · L2 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000896 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000897 | requirement · MUST · L4 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000898 | requirement · MUST · L4 · needs N-000468 (pack 15), N-000663 (pack 18) | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000899 | requirement · MUST · L2 · needs N-000464 (pack 15) | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000900 | requirement · MUST · L2 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000901 | requirement · MUST · L1 · needs N-000463 (pack 15) | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000902 | requirement · MUST NOT · — | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000903 | requirement · MUST · L1 · needs N-000902 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000904 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000905 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000906 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000907 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |
| N-000908 | (pack 31) check`, `doctor`, `show`, `stats`, and `init` do not open a network connection. | implemented | hooks/lib.js routePrompt; commands/prosecheck.md |

## Pack 32 — help reply

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000909 | requirement · MUST · L1 · needs N-000874 (pack 31) | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000910 | requirement · MUST · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000911 | requirement · MUST · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000912 | requirement · MUST · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000913 | requirement · MUST · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000914 | requirement · MUST · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000915 | requirement · MUST · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000916 | requirement · MAY · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000917 | requirement · MUST · L1 · needs N-000468 (pack 15) | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000918 | requirement · MUST NOT · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000919 | requirement · MUST · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000920 | requirement · MUST NOT · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000921 | requirement · MUST · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000922 | requirement · MUST · L1 · needs N-000409 (pack 14) | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000923 | requirement · MUST · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000924 | requirement · MUST · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000925 | requirement · MUST · L1 · needs N-000410 (pack 14), N-000481 (pack 15) | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000926 | requirement · MUST · L1 · needs N-000482 (pack 15) | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000927 | requirement · MUST · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000928 | requirement · MUST · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000929 | requirement · MUST · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000930 | requirement · MUST · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000931 | requirement · MUST · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000932 | requirement · MUST · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000933 | requirement · MUST · — | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |
| N-000934 | requirement · MUST · L1 | implemented | hooks/lib.js helpReply; tests/test_hooks.py test_help_contract |

## Pack 33 — status reply

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000935 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt case status |
| N-000936 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt case status |
| N-000937 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt case status |
| N-000938 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt case status |
| N-000939 | requirement · MUST NOT · L1 | implemented | hooks/lib.js routePrompt case status |
| N-000940 | (pack 33) Nothing else on standard output names a stored level. | implemented | hooks/lib.js routePrompt case status |
| N-000941 | requirement · MUST · L1 | implemented | hooks/lib.js routePrompt case status |

## Pack 34 — lite, full, strict, off, on

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000942 | requirement · MUST · L1 | implemented | hooks/lib.js setLevelReply, routePrompt; tests/test_hooks.py test_levels_store_and_confirm |
| N-000943 | requirement · MUST · L1 | implemented | hooks/lib.js setLevelReply, routePrompt; tests/test_hooks.py test_levels_store_and_confirm |
| N-000944 | requirement · MUST · L4 | implemented | hooks/lib.js setLevelReply, routePrompt; tests/test_hooks.py test_levels_store_and_confirm |
| N-000945 | requirement · MUST · L1 · needs N-000663 (pack 18) | implemented | hooks/lib.js setLevelReply, routePrompt; tests/test_hooks.py test_levels_store_and_confirm |
| N-000946 | requirement · MUST · L1 | implemented | hooks/lib.js setLevelReply, routePrompt; tests/test_hooks.py test_levels_store_and_confirm |
| N-000947 | requirement · MUST · L1 | implemented | hooks/lib.js setLevelReply, routePrompt; tests/test_hooks.py test_levels_store_and_confirm |
| N-000948 | requirement · MUST · L1 | implemented | hooks/lib.js setLevelReply, routePrompt; tests/test_hooks.py test_levels_store_and_confirm |
| N-000949 | requirement · MUST · L1 · needs N-000945 | implemented | hooks/lib.js setLevelReply, routePrompt; tests/test_hooks.py test_levels_store_and_confirm |
| N-000950 | requirement · MUST · L1 · needs N-000383 (pack 13), N-000475 (pack 15) | implemented | hooks/lib.js setLevelReply, routePrompt; tests/test_hooks.py test_levels_store_and_confirm |
| N-000951 | requirement · MUST · L1 | implemented | hooks/lib.js setLevelReply, routePrompt; tests/test_hooks.py test_levels_store_and_confirm |

## Pack 35 — check reply

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000952 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000953 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000954 | requirement · MUST NOT · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000955 | requirement · MUST · L4 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000956 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000957 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000958 | requirement · MAY · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000959 | requirement · MAY · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000960 | requirement · MUST NOT · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000961 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000962 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000963 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000964 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000965 | requirement · MAY · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000966 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000967 | constraint · MAY · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000968 | requirement · MUST NOT · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000969 | requirement · MUST NOT · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000970 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000971 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000972 | constraint · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000973 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000974 | requirement · MUST NOT · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000975 | requirement · MUST · — | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000976 | requirement · MAY · — | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000977 | requirement · MUST · L4 · needs N-000496 (pack 15) | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000978 | requirement · MUST NOT · — · needs N-000977 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000979 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000980 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000981 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000982 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000983 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000984 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000985 | requirement · MUST · L1 · needs N-000647 (pack 18), N-000799 (pack 22) | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000986 | requirement · MUST · L1 · needs N-000247 (pack 11), N-001054 (pack 37) | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000987 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000988 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000989 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000990 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000991 | requirement · MUST · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |
| N-000992 | constraint · MUST NOT · L1 | implemented | hooks/lib.js checkReply; tests/test_hooks.py test_check_replies |

## Pack 36 — doctor reply

| Id | Kind | Status | Where |
|---|---|---|---|
| N-000993 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-000994 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-000995 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-000996 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-000997 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-000998 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-000999 | requirement · MUST NOT · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001000 | requirement · MUST NOT · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001001 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001002 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001003 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001004 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001005 | requirement · MUST NOT · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001006 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001007 | requirement · MUST NOT · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001008 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001009 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001010 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001011 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001012 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001013 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001014 | requirement · MUST NOT · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001015 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001016 | requirement · MUST NOT · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001017 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001018 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001019 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001020 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001021 | requirement · MUST NOT · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001022 | constraint · MAY · — | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001023 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001024 | requirement · MUST NOT · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001025 | constraint · MAY · — | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001026 | requirement · MUST · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001027 | requirement · MUST NOT · L1 | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |
| N-001028 | constraint · MAY · — | implemented | hooks/lib.js doctorReply; tests/test_hooks.py test_doctor_* |

## Pack 37 — show reply and ledger

| Id | Kind | Status | Where |
|---|---|---|---|
| N-001029 | requirement · MUST · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001030 | requirement · MUST · L4 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001031 | requirement · MUST · L4 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001032 | requirement · MUST · L4 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001033 | requirement · MUST NOT · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001034 | requirement · MUST NOT · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001035 | requirement · MUST · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001036 | requirement · MUST · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001037 | requirement · MUST NOT · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001038 | requirement · MUST NOT · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001039 | constraint · — · — | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001040 | requirement · MUST NOT · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001041 | requirement · MUST NOT · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001042 | requirement · MUST · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001043 | requirement · MUST NOT · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001044 | requirement · MUST · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001045 | requirement · MUST · L1 · needs N-000129 (pack 10) | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001046 | requirement · MUST · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001047 | requirement · MUST · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001048 | requirement · MUST · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001049 | requirement · MUST · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001050 | requirement · MUST · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001051 | constraint · MUST NOT · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001052 | requirement · MUST · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001053 | requirement · MUST · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001054 | requirement · MUST · L1 · needs N-000247 (pack 11) | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001055 | requirement · MUST · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001056 | constraint · MUST NOT · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001057 | requirement · MUST · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001058 | requirement · MUST · L1 | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001059 | constraint · MUST NOT · C | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |
| N-001060 | constraint · MUST NOT · C | implemented | hooks/lib.js showReply, rowBody, appendLedger, cleanupLedgers; tests/test_hooks.py |

## Pack 38 — init reply and export

| Id | Kind | Status | Where |
|---|---|---|---|
| N-001061 | requirement · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001062 | requirement · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001063 | requirement · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001064 | constraint · MUST NOT · L5 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001065 | constraint · MUST NOT · — | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001066 | constraint · MUST NOT · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001067 | requirement · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001068 | requirement · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001069 | requirement · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001070 | constraint · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001071 | constraint · MUST NOT · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001072 | requirement · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001073 | requirement · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001074 | constraint · MUST NOT · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001075 | requirement · MUST NOT · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001076 | requirement · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001077 | requirement · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001078 | requirement · MUST NOT · — | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001079 | requirement · MUST NOT · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001080 | requirement · MUST NOT · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001081 | requirement · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001082 | requirement · MUST NOT · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001083 | requirement · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001084 | requirement · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001085 | requirement · MUST · L4 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001086 | requirement · MUST · — | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001087 | constraint · MUST NOT · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001088 | requirement · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001089 | requirement · MUST · L4 · needs N-001088 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001090 | requirement · MAY · L4 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001091 | constraint · MUST NOT · L4 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001092 | requirement · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001093 | requirement · MUST · L1 · needs N-000346 (pack 13) | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001094 | constraint · MUST NOT · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001095 | constraint · MUST NOT · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001096 | constraint · MUST NOT · — | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001097 | requirement · MUST · — | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001098 | requirement · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001099 | constraint · MUST NOT · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001100 | requirement · MUST · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001101 | constraint · MUST NOT · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |
| N-001102 | constraint · MUST NOT · L1 | implemented | hooks/lib.js initReply, exportSection; tests/test_hooks.py test_init_* |

## Pack 39 — stats reply

| Id | Kind | Status | Where |
|---|---|---|---|
| N-001103 | requirement · MUST · L1 | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001104 | requirement · MUST · L1 | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001105 | requirement · MUST · L4 | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001106 | constraint · MUST NOT · L1 | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001107 | requirement · MUST · L3 · needs N-001123 (pack 40) | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001108 | requirement · MUST · L4 | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001109 | constraint · MUST · L1 | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001110 | requirement · MUST · L4 | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001111 | requirement · MUST · — · needs N-001110 | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001112 | requirement · MUST · L4 | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001113 | requirement · MUST · L5 | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001114 | requirement · MUST · L1 | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001115 | requirement · MUST · L1 · needs N-001111 | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001116 | requirement · MUST · L1 | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001117 | requirement · MUST · L1 | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001118 | requirement · MUST · L1 | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001119 | constraint · MAY · — | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001120 | requirement · MUST · L1 | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |
| N-001121 | constraint · MAY · — | implemented | hooks/lib.js statsReply, newestTranscript; hooks/prosecheck-stats.js; tests/test_hooks.py Stats |

## Pack 40 — transcript_path field

| Id | Kind | Status | Where |
|---|---|---|---|
| N-001122 | assumption · — · L3 | implemented | hooks/lib.js statsReply (transcript_path wins); tests/test_hooks.py test_stats_* |
| N-001123 | requirement · MUST · L3 | implemented | hooks/lib.js statsReply (transcript_path wins); tests/test_hooks.py test_stats_* |
| N-001124 | constraint · MUST NOT · L4 | implemented | hooks/lib.js statsReply (transcript_path wins); tests/test_hooks.py test_stats_* |
| N-001125 | requirement · MUST · — | implemented | hooks/lib.js statsReply (transcript_path wins); tests/test_hooks.py test_stats_* |
| N-001126 | requirement · MUST · — | implemented | hooks/lib.js statsReply (transcript_path wins); tests/test_hooks.py test_stats_* |

