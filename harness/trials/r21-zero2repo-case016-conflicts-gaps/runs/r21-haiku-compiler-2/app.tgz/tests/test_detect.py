"""Tests for scripts/detect.py. Run: python3 -m unittest discover -s /app/tests -v"""
import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
DETECT = os.path.join(ROOT, 'scripts', 'detect.py')
sys.path.insert(0, os.path.join(ROOT, 'scripts'))
import detect  # noqa: E402


def run(args, stdin=b''):
    proc = subprocess.run([sys.executable, DETECT] + args, input=stdin, capture_output=True)
    return proc.returncode, proc.stdout, proc.stderr


def report_for_text(text):
    rc, out, err = run([], text.encode('utf-8'))
    assert rc == 0, err
    return json.loads(out.decode('utf-8'))


class TempDir(object):
    def __enter__(self):
        self.dir = tempfile.mkdtemp(prefix='pc-test-')
        return self.dir

    def __exit__(self, *exc):
        import shutil
        shutil.rmtree(self.dir, ignore_errors=True)


class CharacterLayer(unittest.TestCase):
    # spec: N-000305 (AC) After cleanup, a rescan (FP-01) reports zero invisible-character hits.
    def test_AC_N_000305_cleanup_leaves_zero_invisible_hits(self):
        raw = 'Visible​ text‍ here, plus⁠ more﻿ words. co­dex\n'
        with TempDir() as d:
            path = os.path.join(d, 'a.txt')
            with open(path, 'w', encoding='utf-8') as fh:
                fh.write(raw)
            rc, out, _ = run(['--clean', path])
            self.assertEqual(rc, 0)
            scrubbed = out.decode('utf-8')
            self.assertNotIn('​', scrubbed)
            self.assertIn('co\xaddex', scrubbed, 'soft hyphen between letters is kept')
            path2 = os.path.join(d, 'b.txt')
            with open(path2, 'w', encoding='utf-8') as fh:
                fh.write(scrubbed)
            rep = json.loads(run([path2])[1].decode('utf-8'))
            self.assertEqual(rep['_metrics']['invisible_chars'], 0)

    # spec: N-000309 (AC) After cleanup, a rescan reports zero non-standard-space hits.
    def test_AC_N_000309_cleanup_leaves_zero_nonstandard_spaces(self):
        raw = 'Spaces here and　there too.   \nNext line\n'
        with TempDir() as d:
            path = os.path.join(d, 'a.txt')
            with open(path, 'w', encoding='utf-8') as fh:
                fh.write(raw)
            scrubbed = run(['--clean', path])[1].decode('utf-8')
            path2 = os.path.join(d, 'b.txt')
            with open(path2, 'w', encoding='utf-8') as fh:
                fh.write(scrubbed)
            rep = json.loads(run([path2])[1].decode('utf-8'))
            self.assertEqual(rep['_metrics']['nonstandard_spaces'], 0)

    def test_cleanup_folds_mixed_script_word_but_not_pure_cyrillic(self):
        fixed = detect.fold_homoglyphs('a аpple фирма')
        self.assertEqual(fixed, 'a apple фирма')

    def test_no_break_space_between_digits_is_kept(self):
        text, _, _ = detect.scrub_characters('5 km and more')
        self.assertIn('5 km', text)
        self.assertNotIn(' more', text.replace('and more', 'and more'))

    def test_trailing_whitespace_removed_by_cleanup(self):
        cleaned = detect.clean_for_output('Line one.  \nLine two\t\n\n\n')
        self.assertEqual(cleaned, 'Line one.\nLine two\n')

    def test_invisible_past_window_is_not_a_finding(self):
        prose = ('word ' * 60000) + ('x' * 1) + ('​' * 10)
        self.assertGreater(len(prose), detect.WINDOW)
        with TempDir() as d:
            path = os.path.join(d, 'a.txt')
            with open(path, 'w', encoding='utf-8') as fh:
                fh.write(prose)
            rep = json.loads(run([path])[1].decode('utf-8'))
            self.assertEqual(rep['_metrics']['invisible_chars'], 0)
            self.assertTrue(rep['_metrics']['truncated'])
            self.assertEqual(rep['_metrics']['scanned_chars'], detect.WINDOW)


class Report(unittest.TestCase):
    def test_metrics_always_present_and_bands_named(self):
        rep = report_for_text('This is a short plain sentence about a walk in the park today.')
        m = rep['_metrics']
        for key in ('scanned_chars', 'truncated', 'ai_tell_score', 'ai_tell_band', 'confidence',
                    'confidence_reason', 'patterns_flagged', 'invisible_chars', 'nonstandard_spaces',
                    'homoglyphs'):
            self.assertIn(key, m)
        self.assertIn(m['ai_tell_band'], {'clean', 'light tells', 'mixed', 'heavy tells', 'pervasive tells'})

    def test_band_ranges(self):
        self.assertEqual(detect.band_for(0), 'clean')
        self.assertEqual(detect.band_for(20), 'clean')
        self.assertEqual(detect.band_for(21), 'light tells')
        self.assertEqual(detect.band_for(41), 'mixed')
        self.assertEqual(detect.band_for(61), 'heavy tells')
        self.assertEqual(detect.band_for(81), 'pervasive tells')

    def test_finding_keys_and_labels_are_well_formed(self):
        text = ('Additionally, companies must leverage tools. Furthermore, managers should emphasize trust. '
                'Moreover, teams need goals. However, many leaders struggle. It is not just about cost, it is about culture. '
                'The tapestry of work is vibrant. Certainly! I hope this helps. Let me know if you need more.')
        rep = report_for_text(text)
        labels = {}
        for key, value in rep.items():
            if key == '_metrics':
                continue
            num, _slug = key.split('_', 1)
            self.assertTrue(num.isdigit())
            self.assertGreater(value['count'], 0)
            self.assertLessEqual(len(value['samples']), 3)
            labels.setdefault(value['label'], set()).add(num)
        for label, nums in labels.items():
            self.assertEqual(len(nums), 1, 'two catalogue numbers share label %r' % label)

    def test_writing_advice_alone_scores_zero(self):
        # Em dashes in one paragraph and curly quotes are writing advice (weight zero).
        text = ('The author said “hello”—and then—left the room—quietly. '
                'Another paragraph of ordinary plain words follows here for the report.')
        rep = report_for_text(text)
        self.assertEqual(rep['_metrics']['ai_tell_score'], 0)

    def test_single_family_scores_at_most_forty(self):
        text = ('We delve into it. We delve into more. We delve again and again. We delve here. '
                'We delve there. We delve often. The rest is short and plain text for a quick test.')
        rep = report_for_text(text)
        self.assertLessEqual(rep['_metrics']['ai_tell_score'], 40)

    def test_confidence_none_below_forty_words(self):
        rep = report_for_text('Short text here.')
        self.assertEqual(rep['_metrics']['confidence'], 'none')
        self.assertTrue(rep['_metrics']['confidence_reason'])

    def test_ci_present_only_with_flag(self):
        text = 'One sentence. Two sentence here. Three is here too. Four is the last one of the set.'
        self.assertNotIn('score_ci', report_for_text(text)['_metrics'])
        rc, out, _ = run(['--ci'], text.encode('utf-8'))
        m = json.loads(out.decode('utf-8'))['_metrics']
        self.assertIn('score_ci', m)
        self.assertIsNotNone(m['score_ci'])
        self.assertLessEqual(m['score_ci'][0], m['score_ci'][1])

    def test_ci_null_with_few_sentences(self):
        rc, out, _ = run(['--ci'], b'Just one sentence here.')
        m = json.loads(out.decode('utf-8'))['_metrics']
        self.assertIsNone(m['score_ci'])

    def test_fenced_code_generates_no_findings(self):
        text = 'Intro text.\n\n```\nAdditionally, we delve into the tapestry robust seamless\n```\n\nEnd text.'
        rep = report_for_text(text)
        self.assertNotIn('1_ai_vocabulary', rep)


class ErrorsAndCli(unittest.TestCase):
    def test_help_prints_usage_to_stdout_and_exits_zero(self):
        rc, out, _ = run(['--help'])
        self.assertEqual(rc, 0)
        self.assertEqual(out.decode('utf-8').splitlines()[0], 'usage: detect.py [--clean] [--ci] [--] [FILE]')

    def test_unknown_option_exit_two_with_json_error(self):
        rc, out, err = run(['--nope'])
        self.assertEqual(rc, 2)
        self.assertEqual(out, b'')
        last = err.decode('utf-8').strip().splitlines()[-1]
        obj = json.loads(last)
        self.assertIn('unknown option', obj['error'])
        self.assertIn('--nope', obj['error'])
        self.assertIn('--help', obj['error'])
        self.assertNotIn('Traceback', err.decode('utf-8'))

    def test_empty_input_exit_one(self):
        rc, out, err = run([], b'   \n\t ')
        self.assertEqual(rc, 1)
        self.assertEqual(out, b'')
        self.assertEqual(json.loads(err.decode('utf-8').strip().splitlines()[-1]), {'error': 'empty input'})

    def test_unreadable_path_exit_one(self):
        rc, out, err = run(['/definitely/not/here.md'])
        self.assertEqual(rc, 1)
        self.assertTrue(json.loads(err.decode('utf-8').strip().splitlines()[-1])['error'].startswith('cannot read input:'))

    def test_double_dash_allows_dash_filename(self):
        with TempDir() as d:
            path = os.path.join(d, '-dash.txt')
            with open(path, 'w', encoding='utf-8') as fh:
                fh.write('A plain sentence that is long enough to read as a short report body here.')
            rc, out, _ = run(['--', path])
            self.assertEqual(rc, 0)

    def test_two_operands_scan_first_and_notice_on_stderr(self):
        with TempDir() as d:
            a = os.path.join(d, 'a.txt')
            b = os.path.join(d, 'b.txt')
            for p in (a, b):
                with open(p, 'w', encoding='utf-8') as fh:
                    fh.write('Plain text that is simply a test file.')
            rc, out, err = run([a, b])
            self.assertEqual(rc, 0)
            self.assertIn('_metrics', json.loads(out.decode('utf-8')))
            self.assertIn(a, err.decode('utf-8'))

    def test_pdf_is_empty_input(self):
        with TempDir() as d:
            path = os.path.join(d, 'x.pdf')
            with open(path, 'wb') as fh:
                fh.write(b'%PDF-1.4 not really')
            rc, out, err = run([path])
            self.assertEqual(rc, 1)

    def test_bad_zip_for_docx_is_cannot_read(self):
        with TempDir() as d:
            path = os.path.join(d, 'x.docx')
            with open(path, 'wb') as fh:
                fh.write(b'not a zip at all')
            rc, out, err = run([path])
            self.assertEqual(rc, 1)
            self.assertTrue(json.loads(err.decode('utf-8').strip().splitlines()[-1])['error'].startswith('cannot read input:'))

    def test_utf16_with_bom_decodes(self):
        data = 'A plain utf-16 sentence with enough words to decode cleanly here.'.encode('utf-16')
        rc, out, _ = run([], data)
        self.assertEqual(rc, 0)

    def test_notebook_only_markdown_cells(self):
        nb = {'cells': [{'cell_type': 'code', 'source': ['print("hi")']},
                        {'cell_type': 'markdown', 'source': ['A markdown note about the plan.']}]}
        with TempDir() as d:
            path = os.path.join(d, 'n.ipynb')
            with open(path, 'w', encoding='utf-8') as fh:
                json.dump(nb, fh)
            rc, out, _ = run(['--clean', path])
            self.assertEqual(rc, 0)
            self.assertEqual(out.decode('utf-8'), 'A markdown note about the plan.')

    def test_docx_extraction_has_no_markup(self):
        xml = ('<?xml version="1.0" encoding="UTF-8"?>'
               '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
               '<w:body><w:p><w:r><w:t>First paragraph of the memo.</w:t></w:r></w:p>'
               '<w:p><w:r><w:t>Second paragraph.</w:t></w:r></w:p></w:body></w:document>')
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w') as zf:
            zf.writestr('word/document.xml', xml)
        with TempDir() as d:
            path = os.path.join(d, 'm.docx')
            with open(path, 'wb') as fh:
                fh.write(buf.getvalue())
            rc, out, _ = run(['--clean', path])
            self.assertEqual(rc, 0)
            text = out.decode('utf-8')
            self.assertEqual(text, 'First paragraph of the memo.\nSecond paragraph.')
            self.assertNotIn('<', text)

    def test_cleanup_output_is_text_not_report(self):
        rc, out, _ = run(['--clean'], b'Plain line one.\n')
        self.assertEqual(rc, 0)
        self.assertEqual(out, b'Plain line one.\n')


if __name__ == '__main__':
    unittest.main()
