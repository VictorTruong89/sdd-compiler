"""Tests for the Node hooks and the /prosecheck router.

Run: python3 -m unittest discover -s /app/tests -v
Requires node on PATH. Each test uses a private CLAUDE_CONFIG_DIR.
"""
import getpass
import json
import os
import re
import shutil
import subprocess
import tempfile
import unittest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
HOOKS = os.path.join(ROOT, 'hooks')
with open(os.path.join(os.path.dirname(__file__), 'fixtures_memo.txt'), encoding='utf-8') as _fh:
    PROSE_SAMPLE = _fh.read()


class Env(object):
    def __init__(self):
        self.cfg = tempfile.mkdtemp(prefix='pc-cfg-')
        self.proj = tempfile.mkdtemp(prefix='pc-proj-')
        self.env = dict(os.environ)
        self.env['CLAUDE_CONFIG_DIR'] = self.cfg
        self.env.pop('PROSECHECK_DEFAULT_MODE', None)
        self.env.pop('CLAUDE_PLUGIN_ROOT', None)

    def close(self):
        shutil.rmtree(self.cfg, ignore_errors=True)
        shutil.rmtree(self.proj, ignore_errors=True)

    def hook(self, name, payload):
        data = json.dumps(payload) if not isinstance(payload, str) else payload
        proc = subprocess.run(['node', os.path.join(HOOKS, name)], input=data.encode('utf-8'),
                              capture_output=True, env=self.env, cwd=self.proj)
        self.last_rc = proc.returncode
        return proc.stdout.decode('utf-8')

    def command(self, prompt, **extra):
        payload = {'prompt': prompt, 'session_id': 's1', 'cwd': self.proj}
        payload.update(extra)
        out = self.hook('prosecheck-tracker.js', payload).strip()
        return json.loads(out) if out else None

    def reason(self, prompt, **extra):
        obj = self.command(prompt, **extra)
        self.assertion_obj = obj
        return obj['reason'] if obj and obj.get('decision') == 'block' else None

    def level(self):
        return self.env_read()

    def env_read(self):
        try:
            with open(os.path.join(self.cfg, '.prosecheck-active'), encoding='utf-8') as fh:
                return fh.read().strip()
        except OSError:
            return None


class ContractLevels(unittest.TestCase):
    def setUp(self):
        self.e = Env()
        self.addCleanup(self.e.close)

    def activate(self, level):
        self.e.command('/prosecheck ' + level)
        return self.e.hook('prosecheck-activate.js', {})

    def test_full_contract_has_target_and_no_clean_switch(self):
        text = self.activate('full')
        self.assertRegex(text, r'\b40\b')
        self.assertRegex(text, r'\bclean\b|light tells')
        self.assertNotIn('--clean', text)

    def test_strict_contract_asks_for_clean_switch(self):
        text = self.activate('strict')
        self.assertRegex(text, r'\b20\b')
        self.assertIn('--clean', text)
        self.assertRegex(re.sub(r'--clean', '', text), r'\bclean\b')

    def test_lite_contract_has_no_scoring_target(self):
        text = self.activate('lite')
        self.assertNotRegex(text, r'\b40\b')
        self.assertNotIn('light tells', text)
        for word in ('skills', 'plugins', 'CLAUDE_PLUGIN_ROOT'):
            self.assertNotIn(word, text)

    def test_banned_words_standalone_in_contract(self):
        text = self.activate('full')
        for word in ('delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster',
                     'underscore', 'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic',
                     'testament', 'vibrant', 'comprehensive', 'plethora', 'myriad', 'boast', 'elevate',
                     'empower', 'unlock', 'game-changer', 'supercharge', 'genuinely', 'fascinating', 'nuanced'):
            self.assertRegex(text, r'(?<![\w-])' + re.escape(word) + r'(?![\w-])', word)

    def test_source_code_sentences_say_never_or_not_first(self):
        text = self.activate('full')
        for sentence in re.split(r'(?<=[.!?])\s+|\n', text):
            if re.search(r'source[ -]code', sentence, re.I):
                self.assertRegex(sentence, r'\b(never|not)\b', sentence)
                idx = re.search(r'source[ -]code', sentence, re.I).start()
                self.assertRegex(sentence[:idx], r'\b(never|not)\b', sentence)

    def test_exported_contract_is_portable(self):
        self.e.command('/prosecheck full')
        self.e.command('/prosecheck:prosecheck init', cwd=self.e.proj)
        with open(os.path.join(self.e.proj, 'AGENTS.md'), encoding='utf-8') as fh:
            text = fh.read()
        self.assertNotIn(ROOT, text)
        self.assertNotIn(getpass.getuser(), text)


class Commands(unittest.TestCase):
    def setUp(self):
        self.e = Env()
        self.addCleanup(self.e.close)

    def test_bare_command_is_help_and_namespaced_form_matches(self):
        a = self.e.reason('/prosecheck')
        b = self.e.reason('/prosecheck:prosecheck')
        self.assertEqual(a, b)
        self.assertTrue(a.splitlines()[0].startswith('prosecheck level:'))
        self.assertNotIn('\n/prosecheck:prosecheck help', a)

    def test_help_lists_every_command_on_its_own_line(self):
        reply = self.e.reason('/prosecheck help')
        for word in ('lite', 'full', 'strict', 'status', 'show', 'check', 'doctor', 'stats', 'init'):
            self.assertRegex(reply, r'/prosecheck ' + word + r'\b')
        self.assertRegex(reply, r'/prosecheck off \| on')
        self.assertIn('prosecheck this', reply)
        self.assertIn('humanize this', reply)

    def test_level_words_store_and_status_reports(self):
        self.e.reason('/prosecheck strict')
        self.assertEqual(self.e.level(), 'strict')
        self.assertIn('strict', self.e.reason('/prosecheck status'))
        self.e.reason('/prosecheck off')
        self.assertEqual(self.e.level(), 'off')
        self.e.reason('/prosecheck on')
        self.assertEqual(self.e.level(), 'full')

    def test_unknown_word_changes_nothing(self):
        self.e.reason('/prosecheck lite')
        reply = self.e.reason('/prosecheck zzz')
        self.assertIn('unknown', reply.lower())
        self.assertIn('zzz', reply)
        self.assertEqual(self.e.level(), 'lite')

    def test_stop_phrases_only_as_entire_prompt(self):
        self.e.reason('/prosecheck full')
        self.assertIsNotNone(self.e.reason('stop prosecheck'))
        self.assertEqual(self.e.level(), 'off')
        self.e.reason('/prosecheck full')
        ordinary = self.e.command('please stop prosecheck now')
        self.assertIsNotNone(ordinary)
        self.assertNotIn('decision', ordinary)
        self.assertEqual(self.e.level(), 'full')

    def test_ordinary_prompt_reminder_names_level_and_off_is_silent(self):
        out = self.e.command('write an essay about rivers')
        self.assertIn('full', out['hookSpecificOutput']['additionalContext'])
        self.e.reason('/prosecheck off')
        self.assertIsNone(self.e.command('write an essay about rivers'))

    def test_doctor_shape_four_ok_lines(self):
        reply = self.e.reason('/prosecheck doctor')
        lines = [ln for ln in reply.split('\n') if ln.strip()]
        self.assertGreaterEqual(len(lines), 6)
        self.assertNotIn('[OK]', lines[0])
        self.assertNotIn('[OK]', lines[-1])
        ok = [ln for ln in lines[1:-1] if '[OK]' in ln]
        self.assertEqual(len(ok), 4, reply)
        self.assertIn('/prosecheck:prosecheck show', self.e.reason('/prosecheck:prosecheck doctor'))
        self.assertIn('512 KB', lines[-1])
        self.assertIn('4 MB', lines[-1])
        self.assertIn('262,144', lines[-1])
        self.assertNotIn('/prosecheck doctor', lines[-1])

    def test_doctor_off_mode_points_at_on(self):
        self.e.reason('/prosecheck off')
        reply = self.e.reason('/prosecheck doctor')
        lines = [ln for ln in reply.split('\n') if ln.strip()]
        self.assertEqual(len([ln for ln in lines[1:-1] if '[OK]' in ln]), 3)
        self.assertIn('/prosecheck on', lines[-1])
        self.assertIn('scored', lines[-1])
        self.assertNotIn('/prosecheck doctor', lines[-1])

    def test_check_scores_without_rewriting_and_strips_at_and_quotes(self):
        path = os.path.join(self.e.proj, 'memo.md')
        with open(path, 'w', encoding='utf-8') as fh:
            fh.write(PROSE_SAMPLE)
        with open(path, 'rb') as fh:
            before = fh.read()
        reply = self.e.reason('/prosecheck check @"memo.md"', cwd=self.e.proj)
        self.assertIn('memo.md', reply)
        self.assertRegex(reply, r'score \d+/100')
        self.assertIn('report only', reply)
        with open(path, 'rb') as fh:
            self.assertEqual(fh.read(), before)

    def test_check_directory_and_pdf_and_missing(self):
        self.assertIn('not a file', self.e.reason('/prosecheck check .', cwd=self.e.proj))
        pdf = os.path.join(self.e.proj, 'x.pdf')
        with open(pdf, 'wb') as fh:
            fh.write(b'%PDF')
        self.assertIn('no readable text', self.e.reason('/prosecheck check x.pdf', cwd=self.e.proj))
        self.assertIn('cannot read', self.e.reason('/prosecheck check nope.md', cwd=self.e.proj))

    def test_init_off_writes_nothing_and_init_is_idempotent(self):
        self.e.reason('/prosecheck off')
        reply = self.e.reason('/prosecheck init', cwd=self.e.proj)
        self.assertIn('switched off', reply)
        self.assertIn('/prosecheck on', reply)
        self.assertFalse(os.path.exists(os.path.join(self.e.proj, 'AGENTS.md')))
        self.e.reason('/prosecheck full')
        self.e.reason('/prosecheck init', cwd=self.e.proj)
        again = self.e.reason('/prosecheck init', cwd=self.e.proj)
        self.assertIn('already', again)
        self.assertIn('AGENTS.md', again)
        with open(os.path.join(self.e.proj, 'AGENTS.md'), encoding='utf-8') as fh:
            text = fh.read()
        self.assertEqual(text.count('## Prose writing contract'), 1)

    def test_session_start_welcome_once_then_contract(self):
        first = self.e.hook('prosecheck-activate.js', {})
        self.assertIn('71', first)
        self.assertIn('/prosecheck doctor', first)
        second = self.e.hook('prosecheck-activate.js', {})
        self.assertNotIn('shown once', second)
        self.assertIn('## Prose writing contract', second)

    def test_malformed_input_exits_zero(self):
        out = self.e.hook('prosecheck-guard.js', 'not json{')
        self.assertEqual(self.e.last_rc, 0)
        self.assertEqual(out, '')


class Guard(unittest.TestCase):
    def setUp(self):
        self.e = Env()
        self.addCleanup(self.e.close)
        self.path = os.path.join(self.e.proj, 'memo.md')
        with open(self.path, 'w', encoding='utf-8') as fh:
            fh.write(PROSE_SAMPLE)

    def guard(self, tool='Write', file_path='memo.md', **extra):
        payload = {'tool_name': tool, 'tool_input': {'file_path': file_path},
                   'cwd': self.e.proj, 'session_id': 'g1'}
        payload.update(extra)
        out = self.e.hook('prosecheck-guard.js', payload).strip()
        return json.loads(out) if out else None

    def test_flagged_file_gets_nudge_with_phrase_score_band_and_labels(self):
        obj = self.guard()
        ctx = obj['hookSpecificOutput']['additionalContext']
        self.assertIn('memo.md', ctx)
        self.assertRegex(ctx, r'reads (clean|mostly clean|with some AI tells|with heavy AI tells|with pervasive AI tells)')
        self.assertRegex(ctx, r'score \d+')
        self.assertIn('Flagged:', ctx)
        self.assertIn('fix', ctx.lower())

    def test_level_off_and_lite_are_silent(self):
        self.e.reason('/prosecheck lite')
        self.assertIsNone(self.guard())
        self.e.reason('/prosecheck off')
        self.assertIsNone(self.guard())

    def test_strict_lowers_threshold_to_twenty(self):
        # Scores 26: above the strict threshold (20), below the full threshold (40).
        mid = os.path.join(self.e.proj, 'mid.md')
        with open(mid, 'w', encoding='utf-8') as fh:
            fh.write('We need to talk about the budget. Additionally, the team wants a clear plan. '
                     'Furthermore, the schedule is tight. Moreover, the vendors are slow. However, we can '
                     'still ship on time if we cut scope.\n\nThe report covers costs, risks, and next steps '
                     'for the quarter ahead, and it names owners for each item.\n')
        self.e.reason('/prosecheck full')
        self.assertIsNone(self.guard(file_path='mid.md'))
        self.e.reason('/prosecheck strict')
        obj = self.guard(file_path='mid.md')
        self.assertIsNotNone(obj)
        self.assertIn('light tells', obj['hookSpecificOutput']['additionalContext'])

    def test_skipped_paths_and_instruction_files(self):
        nm = os.path.join(self.e.proj, 'node_modules', 'pkg')
        os.makedirs(nm)
        with open(os.path.join(nm, 'a.md'), 'w', encoding='utf-8') as fh:
            fh.write(PROSE_SAMPLE)
        self.assertIsNone(self.guard(file_path='node_modules/pkg/a.md'))
        with open(os.path.join(self.e.proj, 'CLAUDE.md'), 'w', encoding='utf-8') as fh:
            fh.write(PROSE_SAMPLE)
        self.assertIsNone(self.guard(file_path='CLAUDE.md'))
        ledger = os.path.join(self.e.cfg, '.prosecheck-ledger-g1')
        if os.path.exists(ledger):
            with open(ledger, encoding='utf-8') as fh:
                self.assertNotIn('CLAUDE.md', fh.read())

    def test_source_code_is_not_scored(self):
        with open(os.path.join(self.e.proj, 'x.py'), 'w', encoding='utf-8') as fh:
            fh.write(PROSE_SAMPLE)
        self.assertIsNone(self.guard(file_path='x.py'))

    def test_apply_patch_names_files_and_scores_them(self):
        body = '*** Begin Patch\n*** Update File: memo.md\n@@\n-a\n+b\n*** End Patch\n'
        obj = self.guard(tool='apply_patch', tool_input={'command': body})
        self.assertIsNotNone(obj)
        self.assertIn('memo.md', obj['hookSpecificOutput']['additionalContext'])

    def test_show_lists_newest_first_and_binary_row(self):
        self.guard()
        with open(os.path.join(self.e.proj, 'x.pdf'), 'wb') as fh:
            fh.write(b'%PDF')
        self.guard(file_path='x.pdf')
        reply = self.e.reason('/prosecheck show', session_id='g1')
        self.assertIn('x.pdf - not re-scored', reply)
        self.assertIn('memo.md - reads', reply)
        other = self.e.reason('/prosecheck show', session_id='other')
        self.assertIn('nothing scored yet', other)
        self.assertIn('.docx', other)
        self.assertIn('.pdf', other)


if __name__ == '__main__':
    unittest.main()
