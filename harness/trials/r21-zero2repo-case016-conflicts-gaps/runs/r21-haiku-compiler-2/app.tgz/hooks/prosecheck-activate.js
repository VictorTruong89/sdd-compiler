#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract in context (PRD FP-04).
// Plain-text output. Stored level off: empty output. Always exits 0.
// spec: Interface Contract hooks/prosecheck-activate.js (N-000788..N-000812)

const common = require('./lib/common');
const { contractText, welcomeText } = require('./lib/contract');

function main() {
  common.readHostJson(); // malformed input is treated as an empty object
  const isFresh = !common.flagExists();
  if (isFresh) {
    try {
      common.writeLevel(common.effectiveLevel());
    } catch (err) {
      // an unwritable settings folder must not fail the session
    }
  }
  common.pruneLedgers();
  const level = common.effectiveLevel();
  if (level === 'off') return;
  const parts = [];
  if (isFresh) parts.push(welcomeText());
  parts.push(contractText(level));
  process.stdout.write(parts.join('\n\n') + '\n');
}

try {
  main();
} catch (err) {
  // never fail the host session
}
process.exitCode = 0;
