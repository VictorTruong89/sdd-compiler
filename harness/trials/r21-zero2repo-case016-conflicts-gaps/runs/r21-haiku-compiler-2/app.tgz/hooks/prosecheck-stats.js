#!/usr/bin/env node
'use strict';
// Stats: session token figures and an own-prose score (PRD FP-06; Interface Contract stats).
// Used by the prompt-submit router. Run directly, it reads a host JSON object on
// standard input and prints the reply as plain text. Always exits 0.
// spec: Interface Contract stats (N-001103..N-001121), transcript_path (N-001122..N-001126)

const fs = require('fs');
const path = require('path');
const common = require('./lib/common');

const PROSE_SLICE_CHARS = 40000;
const PROSE_MIN_CHARS = 200; // PRD FP-06: score printed only when the trimmed slice is longer than 200

function newestTranscript(dir) {
  let best = null;
  const walk = (folder, depth) => {
    if (depth > 6) return;
    let names = [];
    try {
      names = fs.readdirSync(folder);
    } catch (err) {
      return;
    }
    for (const name of names) {
      const full = path.join(folder, name);
      let stat;
      try {
        stat = fs.statSync(full);
      } catch (err) {
        continue;
      }
      if (stat.isDirectory()) walk(full, depth + 1);
      else if (name.endsWith('.jsonl') && (!best || stat.mtimeMs > best.mtime)) best = { file: full, mtime: stat.mtimeMs };
    }
  };
  walk(path.join(dir, 'projects'), 0);
  return best ? best.file : null;
}

function readTranscript(file) {
  let raw;
  try {
    raw = fs.readFileSync(file, 'utf8');
  } catch (err) {
    return null;
  }
  const seen = new Set();
  let turns = 0;
  let outputTokens = 0;
  let cacheRead = 0;
  const texts = [];
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    let row;
    try {
      row = JSON.parse(line);
    } catch (err) {
      continue;
    }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const id = typeof msg.id === 'string' ? msg.id : null;
    if (id) {
      if (seen.has(id)) continue;
      seen.add(id);
    }
    turns += 1;
    const usage = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    outputTokens += Number(usage.output_tokens) || 0;
    cacheRead += Number(usage.cache_read_input_tokens) || 0;
    if (Array.isArray(msg.content)) {
      for (const part of msg.content) {
        if (part && part.type === 'text' && typeof part.text === 'string') texts.push(part.text);
      }
    }
  }
  return { turns, outputTokens, cacheRead, texts };
}

function proseScore(texts) {
  let joined = texts.join('\n');
  joined = joined.replace(/```[\s\S]*?```/g, '').replace(/~~~[\s\S]*?~~~/g, '');
  const slice = joined.slice(-PROSE_SLICE_CHARS).trim();
  if (slice.length <= PROSE_MIN_CHARS) return null;
  const res = common.runDetector([], slice, 15000);
  if (res.kind !== 'ok') return null;
  return res.report._metrics.ai_tell_score;
}

function statsReply(transcriptPath, level) {
  let file = null;
  if (typeof transcriptPath === 'string' && transcriptPath.trim()) {
    file = transcriptPath.trim();
  } else {
    file = newestTranscript(common.configDir());
  }
  const lines = [];
  const data = file ? readTranscript(file) : null;
  if (!data) {
    return 'stats: no readable transcript was found, so no turn or token figures are shown. level: ' + level;
  }
  lines.push('level: ' + level);
  lines.push('assistant turns: ' + data.turns);
  lines.push('output tokens: ' + data.outputTokens);
  lines.push('cache-read input tokens: ' + data.cacheRead);
  const score = proseScore(data.texts);
  if (score !== null) lines.push('session prose ai_tell_score: ' + score);
  return lines.join('\n');
}

module.exports = { statsReply, readTranscript, newestTranscript };

if (require.main === module) {
  const payload = common.readHostJson();
  try {
    process.stdout.write(statsReply(payload.transcript_path, common.effectiveLevel()) + '\n');
  } catch (err) {
    // never fail
  }
  process.exitCode = 0;
}
