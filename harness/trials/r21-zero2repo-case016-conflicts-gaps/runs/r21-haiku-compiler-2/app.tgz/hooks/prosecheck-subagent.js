#!/usr/bin/env node
'use strict';
// Subagent-start hook: returns the same writing contract inside the host's
// subagent envelope (PRD FP-04). Stored level off: empty output. Always exits 0.
// spec: Interface Contract hooks/prosecheck-subagent.js (N-000813..N-000818)

const common = require('./lib/common');
const { contractText } = require('./lib/contract');

function main() {
  common.readHostJson();
  const level = common.effectiveLevel();
  if (level === 'off') return;
  const envelope = {
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: contractText(level),
    },
  };
  process.stdout.write(JSON.stringify(envelope) + '\n');
}

try {
  main();
} catch (err) {
  // never fail the host
}
process.exitCode = 0;
