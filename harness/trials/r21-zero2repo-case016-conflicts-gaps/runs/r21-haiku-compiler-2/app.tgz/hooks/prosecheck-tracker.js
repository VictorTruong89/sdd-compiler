#!/usr/bin/env node
'use strict';
// Prompt-submit hook: the /prosecheck command router and the per-prompt reminder
// (PRD FP-04, FP-06). Commands are blocked and answered with the reply as the
// block reason. Always exits 0.
// spec: Interface Contract prompt (N-000847..N-000856), /prosecheck (N-000870..N-000908),
//       PRD FP-04 prompt reminder (N-000380..N-000383), stop phrases (N-000471..N-000475).

const common = require('./lib/common');
const replies = require('./lib/commands');
const { statsReply } = require('./prosecheck-stats');

const STOP_PHRASE = /^(stop prosecheck|prosecheck off)$/i;
const COMMAND = /^\/prosecheck(:prosecheck)?(?=\s|$)\s*([\s\S]*)$/i;

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason: reason }) + '\n');
}

function reminder(level) {
  const envelope = {
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: 'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; ' +
        'code, config, and commits are untouched.',
    },
  };
  process.stdout.write(JSON.stringify(envelope) + '\n');
}

function route(prompt, payload) {
  const trimmed = prompt.trim();
  if (STOP_PHRASE.test(trimmed)) {
    common.writeLevel('off');
    block('prosecheck is off. Saved files are not scored until you run /prosecheck on.');
    return;
  }
  const m = COMMAND.exec(trimmed);
  if (!m) {
    const level = common.effectiveLevel();
    if (level !== 'off') reminder(level);
    return;
  }
  const form = m[1] ? '/prosecheck:prosecheck' : '/prosecheck';
  const rest = (m[2] || '').trim();
  const typedWord = rest.split(/\s+/)[0] || '';
  const sub = typedWord.toLowerCase() || 'help';
  const arg = rest.slice(typedWord.length).trim();
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const sid = typeof payload.session_id === 'string' ? payload.session_id : '';
  const level = common.effectiveLevel();

  let reply;
  switch (sub) {
    case 'help':
      reply = replies.helpReply(level);
      break;
    case 'lite':
    case 'full':
    case 'strict':
      common.writeLevel(sub);
      reply = 'prosecheck level set to ' + sub + '.';
      break;
    case 'off':
      common.writeLevel('off');
      reply = 'prosecheck is off. Saved files are not scored until you run ' + form + ' on.';
      break;
    case 'on':
      common.writeLevel('full');
      reply = 'prosecheck is on (full).';
      break;
    case 'status':
      reply = 'prosecheck level: ' + level;
      break;
    case 'show':
      reply = replies.showReply(sid);
      break;
    case 'check':
      reply = replies.checkReply(arg, cwd);
      break;
    case 'doctor':
      reply = replies.doctorReply(form, level);
      break;
    case 'stats':
      reply = statsReply(payload.transcript_path, level);
      break;
    case 'init':
      reply = replies.initReply(form, level, cwd);
      break;
    default:
      reply = replies.unknownReply(typedWord);
  }
  block(reply);
}

try {
  const payload = common.readHostJson();
  const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
  route(prompt, payload);
} catch (err) {
  // never fail the host session
}
process.exitCode = 0;
