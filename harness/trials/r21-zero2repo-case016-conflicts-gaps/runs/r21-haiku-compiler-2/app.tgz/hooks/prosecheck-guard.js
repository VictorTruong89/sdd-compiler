#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when flagged
// (PRD FP-05). Silent unless a file is flagged. Always exits 0.
// spec: PRD FP-05 (N-000395..N-000456), Interface Contract post-tool-use reply
//       (N-000819..N-000835), tool_input / file_path / cwd / tool_name fields.

const fs = require('fs');
const path = require('path');
const common = require('./lib/common');

const SUPPORTED_TOOLS = new Set(['Write', 'Edit', 'MultiEdit', 'NotebookEdit', 'apply_patch']);
const INSTRUCTION_NAMES = new Set(['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md']);
const INSTRUCTION_STEMS = new Set(['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory']);
const MAX_PATHS = 10; // at most ten paths of one payload are scored (Interface post-tool-use reply)
const MAX_LABELS = 5; // guard label cap (PRD FP-05)
const PLAIN_TIMEOUT_MS = 8000;
const ARCHIVE_TIMEOUT_MS = 15000;

/** Paths named by the payload, in order, without duplicates. */
function namedPaths(payload) {
  const tool = payload.tool_name;
  const input = payload.tool_input && typeof payload.tool_input === 'object' ? payload.tool_input : {};
  const out = [];
  if (tool === 'apply_patch') {
    const body = typeof input.command === 'string' ? input.command
      : (typeof input.patch === 'string' ? input.patch : '');
    const re = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/gm;
    let m;
    while ((m = re.exec(body)) !== null) {
      const p = m[1].trim();
      if (p) out.push(p);
    }
  } else if (tool === 'NotebookEdit') {
    const p = input.notebook_path || input.file_path;
    if (typeof p === 'string' && p.trim()) out.push(p.trim());
  } else {
    if (typeof input.file_path === 'string' && input.file_path.trim()) out.push(input.file_path.trim());
  }
  const seen = new Set();
  const unique = [];
  for (const p of out) {
    if (!seen.has(p)) {
      seen.add(p);
      unique.push(p);
    }
  }
  return unique;
}

function isSkipped(resolved, root) {
  const segments = resolved.split(/[\\/]/);
  if (segments.includes('node_modules') || segments.includes('.git')) return true;
  const rel = path.relative(root, resolved);
  if (rel && !rel.startsWith('..') && !path.isAbsolute(rel)) return true;
  const base = path.basename(resolved).toLowerCase();
  if (INSTRUCTION_NAMES.has(base)) return true;
  const ext = path.extname(base);
  const stem = base.slice(0, base.length - ext.length);
  if (INSTRUCTION_STEMS.has(stem) && !common.PLAIN_EXT.has(ext) && !common.ZIP_EXT.has(ext)
      && !common.NOTEBOOK_EXT.has(ext)) {
    return true;
  }
  return false;
}

function labelsOf(report) {
  const entries = Object.keys(report).filter((k) => k !== '_metrics');
  entries.sort((a, b) => parseInt(a, 10) - parseInt(b, 10));
  return entries.map((k) => report[k].label).filter((l) => typeof l === 'string').slice(0, MAX_LABELS);
}

function scoreOne(filePath, ext, sessionId, threshold, root) {
  const base = path.basename(filePath);
  const isBinary = common.BINARY_EXT.has(ext);
  if (isBinary) {
    common.appendLedger(sessionId, { base, kind: 'binary' });
    return null;
  }
  const isProse = common.PLAIN_EXT.has(ext) || common.ZIP_EXT.has(ext) || common.NOTEBOOK_EXT.has(ext);
  if (!isProse) return null;
  let stat;
  try {
    stat = fs.statSync(filePath);
  } catch (err) {
    common.appendLedger(sessionId, { base, kind: 'failed', reason: 'cannot read the file' });
    return null;
  }
  if (stat.isDirectory() || !stat.isFile()) return null;
  const archive = !common.PLAIN_EXT.has(ext);
  const capBytes = archive ? common.ARCHIVE_CAP_KB * 1024 : common.PLAIN_CAP_KB * 1024;
  const capKb = archive ? common.ARCHIVE_CAP_KB : common.PLAIN_CAP_KB;
  if (stat.size > capBytes) {
    common.appendLedger(sessionId, { base, kind: 'skip', limit_kb: capKb });
    return null;
  }
  const res = common.runDetector(['--', filePath], undefined, archive ? ARCHIVE_TIMEOUT_MS : PLAIN_TIMEOUT_MS);
  if (res.kind !== 'ok') {
    common.appendLedger(sessionId, { base, kind: 'failed', reason: common.failureReason(res) });
    return null;
  }
  const metrics = res.report._metrics;
  const score = metrics.ai_tell_score;
  const band = metrics.ai_tell_band;
  const labels = labelsOf(res.report);
  const flagged = score > threshold;
  const truncated = !!metrics.truncated;
  common.appendLedger(sessionId, {
    base, kind: 'scored', score, band, labels, flagged, truncated,
  });
  if (!flagged) return null;
  const cov = truncated ? ', first ' + common.WINDOW_TEXT + ' characters only' : '';
  return 'prosecheck: ' + base + ' ' + common.hookPhrase(band) + ' (score ' + score + ', band ' + band + cov +
    '). Flagged: ' + (labels.length ? labels.join('; ') : 'none listed') +
    '. Fix the flagged spans in this file.';
}

function main() {
  const payload = common.readHostJson();
  const level = common.effectiveLevel();
  if (level === 'off' || level === 'lite') return;
  if (!SUPPORTED_TOOLS.has(payload.tool_name)) return;
  const threshold = common.thresholdFor(level);
  const root = common.pluginRoot();
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const sessionId = typeof payload.session_id === 'string' ? payload.session_id : '';
  const lines = [];
  for (const named of namedPaths(payload).slice(0, MAX_PATHS)) {
    const resolved = path.isAbsolute(named) ? named : path.resolve(cwd, named);
    if (isSkipped(resolved, root)) continue;
    const ext = path.extname(resolved).toLowerCase();
    const line = scoreOne(resolved, ext, sessionId, threshold, root);
    if (line) lines.push(line);
  }
  if (lines.length) {
    const envelope = {
      hookSpecificOutput: {
        hookEventName: 'PostToolUse',
        additionalContext: lines.join('\n'),
      },
    };
    process.stdout.write(JSON.stringify(envelope) + '\n');
  }
}

try {
  main();
} catch (err) {
  // never fail the host session
}
process.exitCode = 0;
