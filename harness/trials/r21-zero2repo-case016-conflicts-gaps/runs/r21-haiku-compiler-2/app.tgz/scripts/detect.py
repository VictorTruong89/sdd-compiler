#!/usr/bin/env python3
"""prosecheck detector: a local, deterministic AI-writing pattern scanner.

Standard library only. Usage:

    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
    python3 scripts/detect.py --help

With no FILE the text is read from standard input (UTF-8). Without --clean
the report is one JSON object on standard output. With --clean the scrubbed
text is written to standard output instead. Failures write a single JSON
object {"error": ...} as the last line of standard error and exit non-zero.

spec: Interface Contract scripts/detect.py (packs 21, 20, 18) and PRD FP-01..FP-03
"""

import io
import json
import math
import os
import re
import sys
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

# spec: PRD FP-02 (caps and window); the window is measured on extracted prose
WINDOW = 262144
PLAIN_CAP_BYTES = 512 * 1024
ARCHIVE_CAP_BYTES = 4 * 1024 * 1024

PLAIN_EXT = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXT = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NOTEBOOK_EXT = {'.ipynb'}
BINARY_EXT = {'.pdf', '.rtf'}

USAGE_LINE = 'usage: detect.py [--clean] [--ci] [--] [FILE]'
USAGE = (
    USAGE_LINE + '\n'
    '\n'
    'Scan prose for AI-writing patterns. Reads FILE, or standard input when no\n'
    'FILE is given.\n'
    '\n'
    '  --clean   print the scrubbed text instead of the JSON report\n'
    '  --ci      add a low/high interval on the score when there are enough sentences\n'
    '  --        end option parsing (a FILE may then begin with a dash)\n'
    '  -h, --help  show this message\n'
    '\n'
    'Supported files: plain text, zip-based documents, and notebooks. PDF and RTF\n'
    'yield no prose. Only the first 262,144 characters of extracted prose are scanned.\n'
)

BANDS = [(20, 'clean'), (40, 'light tells'), (60, 'mixed'), (80, 'heavy tells'), (100, 'pervasive tells')]


class ProseError(Exception):
    """A failure with a fixed error kind and exit status."""

    def __init__(self, message, status=1):
        Exception.__init__(self, message)
        self.message = message
        self.status = status


# ---------------------------------------------------------------------------
# Extraction (FP-02)
# ---------------------------------------------------------------------------

def _local(tag):
    if not isinstance(tag, str):
        return ''
    return tag.rsplit('}', 1)[-1]


def _attr(elem, name):
    for key, value in elem.attrib.items():
        if _local(key) == name:
            return value
    return None


def _texts_of(elem, names):
    """Concatenate text of descendants whose local name is in names."""
    out = []
    for node in elem.iter():
        name = _local(node.tag)
        if name in names and node.text:
            out.append(node.text)
    return ''.join(out)


def _docx_text(root):
    paragraphs = []
    for para in root.iter():
        if _local(para.tag) != 'p':
            continue
        parts = []
        for node in para.iter():
            name = _local(node.tag)
            if name == 't' and node.text:
                parts.append(node.text)
            elif name == 'tab':
                parts.append('\t')
            elif name in ('br', 'cr'):
                parts.append('\n')
        paragraphs.append(''.join(parts))
    return '\n'.join(paragraphs)


def _pptx_text(zf):
    names = [n for n in zf.namelist() if re.match(r'^ppt/slides/slide\d+\.xml$', n)]
    names.sort(key=lambda n: int(re.search(r'(\d+)\.xml$', n).group(1)))
    slides = []
    for name in names:
        root = ET.fromstring(zf.read(name))
        paras = []
        for para in root.iter():
            if _local(para.tag) == 'p':
                paras.append(_texts_of(para, ('t',)))
        slides.append('\n'.join(paras))
    return '\n'.join(slides)


def _xlsx_text(zf):
    shared = []
    if 'xl/sharedStrings.xml' in zf.namelist():
        root = ET.fromstring(zf.read('xl/sharedStrings.xml'))
        for si in root:
            if _local(si.tag) == 'si':
                shared.append(_texts_of(si, ('t',)))
    names = [n for n in zf.namelist() if re.match(r'^xl/worksheets/sheet\d+\.xml$', n)]
    names.sort(key=lambda n: int(re.search(r'(\d+)\.xml$', n).group(1)))
    sheets = []
    for name in names:
        root = ET.fromstring(zf.read(name))
        cells = []
        for cell in root.iter():
            if _local(cell.tag) != 'c':
                continue
            kind = _attr(cell, 't')
            value = None
            if kind == 's':
                v = None
                for child in cell:
                    if _local(child.tag) == 'v':
                        v = child.text
                if v is not None and v.strip().isdigit() and int(v) < len(shared):
                    value = shared[int(v)]
                else:
                    value = ''
            elif kind == 'inlineStr':
                value = _texts_of(cell, ('t',))
            elif kind == 'str':
                v = None
                for child in cell:
                    if _local(child.tag) == 'v':
                        v = child.text
                value = v or ''
            if value:
                cells.append(value)
        sheets.append('\n'.join(cells))
    return '\n'.join(sheets)


_ODF_BLOCK = ('p', 'h')


def _odf_walk(elem, out):
    name = _local(elem.tag)
    if name in ('script', 'style'):
        return
    if name == 's':
        count = _attr(elem, 'c')
        try:
            n = int(count) if count else 1
        except ValueError:
            n = 1
        out.append(' ' * max(0, n))
    elif name == 'tab':
        out.append('\t')
    elif name == 'line-break':
        out.append('\n')
    elif elem.text:
        out.append(elem.text)
    for child in elem:
        _odf_walk(child, out)
        if child.tail:
            out.append(child.tail)
    if name in _ODF_BLOCK:
        out.append('\n')


def _odf_text(zf):
    try:
        root = ET.fromstring(zf.read('content.xml'))
    except ET.ParseError:
        return ''
    out = []
    body = None
    for node in root.iter():
        if _local(node.tag) == 'body':
            body = node
            break
    _odf_walk(body if body is not None else root, out)
    return ''.join(out)


class _HTMLText(HTMLParser):
    BLOCK = {'p', 'div', 'br', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'blockquote', 'section', 'pre'}
    SKIP = {'script', 'style', 'head', 'nav'}

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.parts.append('\n')

    def handle_endtag(self, tag):
        if tag in self.SKIP and self.skip:
            self.skip -= 1
        elif tag in self.BLOCK:
            self.parts.append('\n')

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def _epub_text(zf):
    chapters = []
    for name in zf.namelist():
        lower = name.lower()
        if not lower.endswith(('.xhtml', '.html', '.htm')):
            continue
        base = os.path.basename(lower)
        if 'nav' in base:
            continue
        parser = _HTMLText()
        try:
            parser.feed(zf.read(name).decode('utf-8', errors='replace'))
            parser.close()
        except Exception:  # a broken chapter contributes nothing
            continue
        chapters.append(''.join(parser.parts))
    return '\n'.join(chapters)


def _notebook_text(data):
    try:
        nb = json.loads(data.decode('utf-8', errors='replace'))
    except ValueError:
        return ''
    if not isinstance(nb, dict) or not isinstance(nb.get('cells'), list):
        return ''
    chunks = []
    for cell in nb['cells']:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source', '')
        if isinstance(src, list):
            if not all(isinstance(s, str) for s in src):
                return ''
            src = ''.join(src)
        elif not isinstance(src, str):
            return ''
        chunks.append(src)
    return '\n'.join(chunks)


def _decode_text(data):
    if data.startswith(b'\xff\xfe') or data.startswith(b'\xfe\xff'):
        return data.decode('utf-16', errors='replace')
    if data.startswith(b'\xef\xbb\xbf'):
        data = data[3:]
    return data.decode('utf-8', errors='replace')


# spec: N-000243..N-000298 (twenty formats, extraction rules)
def extract_prose(data, ext):
    """Return the extracted prose for the given bytes and lower-case extension."""
    if ext in BINARY_EXT:
        return ''
    if ext in ZIP_EXT:
        try:
            zf = zipfile.ZipFile(io.BytesIO(data))
        except zipfile.BadZipFile:
            raise ProseError('cannot read input: not a readable zip archive (%s)' % ext)
        with zf:
            try:
                if ext in ('.docx', '.docm'):
                    text = _docx_text(ET.fromstring(zf.read('word/document.xml')))
                elif ext in ('.pptx', '.pptm'):
                    text = _pptx_text(zf)
                elif ext in ('.xlsx', '.xlsm'):
                    text = _xlsx_text(zf)
                elif ext in ('.odt', '.odp', '.ods'):
                    text = _odf_text(zf)
                else:
                    text = _epub_text(zf)
            except (KeyError, ET.ParseError):
                text = ''
        return text.strip()
    if ext in NOTEBOOK_EXT:
        return _notebook_text(data).strip()
    return _decode_text(data)


# ---------------------------------------------------------------------------
# Character layer (FP-01 rules 62, 66, 67, 68; FP-03 cleanup)
# ---------------------------------------------------------------------------

ASCII_LETTERS = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ')

# Latin-looking letters of other scripts (Cyrillic, Greek, Armenian, ...).
HOMOGLYPHS = {
    'а': 'a', 'с': 'c', 'ԁ': 'd', 'е': 'e', 'һ': 'h',
    'і': 'i', 'ј': 'j', 'ո': 'n', 'о': 'o', 'р': 'p',
    'ѕ': 's', 'օ': 'u', 'ν': 'v', 'ԝ': 'w', 'х': 'x',
    'у': 'y', 'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E',
    'Н': 'H', 'І': 'I', 'Ј': 'J', 'К': 'K', 'М': 'M',
    'Ν': 'N', 'О': 'O', 'Р': 'P', 'Ѕ': 'S', 'Т': 'T',
    'Х': 'X', 'У': 'Y', 'Ζ': 'Z', 'Α': 'A', 'Β': 'B',
    'Ε': 'E', 'Η': 'H', 'Ι': 'I', 'Κ': 'K', 'Μ': 'M',
    'Ο': 'O', 'Ρ': 'P', 'Τ': 'T', 'Χ': 'X', 'Υ': 'Y',
    'ο': 'o',
}

# Zero-width or filler code points that are not category Cf.
_INVISIBLE_EXTRA = {0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x180B, 0x180C, 0x180D,
                    0x180E, 0x180F, 0x3164, 0xFFA0}
# Format characters that render visibly and are therefore not invisible.
_VISIBLE_CF = {0x0600, 0x0601, 0x0602, 0x0603, 0x0604, 0x0605, 0x06DD, 0x070F,
               0x08E2, 0x110BD, 0x110CD}

_RTL_RE = re.compile('[֐-ࣿיִ-﷿ﹰ-﻿]')
_LETTER_RUN = re.compile(r'[^\W\d_]+')
_NBSP_AFTER_OPEN = '«‹'
_NBSP_BEFORE = ':;!?»›%€'


def _is_invisible_cp(cp):
    if cp in (9, 10, 13):
        return False
    if cp < 0x20 or 0x7F <= cp <= 0x9F:
        return True
    if cp in _INVISIBLE_EXTRA:
        return True
    if 0xE0000 <= cp <= 0xE007F or 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF:
        return True
    if unicodedata.category(chr(cp)) == 'Cf':
        return cp not in _VISIBLE_CF
    return False


def _is_cjk(cp):
    return (0x3400 <= cp <= 0x4DBF or 0x4E00 <= cp <= 0x9FFF or 0xF900 <= cp <= 0xFAFF
            or 0x20000 <= cp <= 0x2FFFF)


def _is_symbol(cp):
    if 0x1F000 <= cp <= 0x1FAFF or 0x2600 <= cp <= 0x27BF or 0x2190 <= cp <= 0x21FF \
            or 0x2B00 <= cp <= 0x2BFF:
        return True
    return unicodedata.category(chr(cp)).startswith('So')


def _in(cp, lo, hi):
    return lo <= cp <= hi


_SPACELESS = [(0x0E00, 0x0EFF), (0x1000, 0x109F), (0x1780, 0x17FF), (0x3040, 0x30FF),
              (0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF)]
_JOINING = [(0x0590, 0x06FF), (0x0900, 0x0DFF), (0x1000, 0x109F), (0x1780, 0x17FF)]


def _cp_in_ranges(cp, ranges):
    for lo, hi in ranges:
        if lo <= cp <= hi:
            return True
    return False


def _invisible_is_kept(text, i, cp, rtl):
    """True when an invisible code point does a job in its position (FP-03)."""
    n = len(text)
    prev = ord(text[i - 1]) if i > 0 else -1
    nxt = ord(text[i + 1]) if i + 1 < n else -1
    if 0xE0000 <= cp <= 0xE007F:
        return prev == 0x1F3F4 or (0xE0020 <= prev <= 0xE007F)
    if 0xE0100 <= cp <= 0xE01EF:
        return prev >= 0 and _is_cjk(prev)
    if cp == 0x200B:
        return (prev >= 0 and _cp_in_ranges(prev, _SPACELESS)) or \
            (nxt >= 0 and _cp_in_ranges(nxt, _SPACELESS))
    if cp == 0x00AD:
        return prev >= 0 and nxt >= 0 and chr(prev).isalpha() and chr(nxt).isalpha()
    if cp in (0x200E, 0x200F, 0x061C) or 0x202A <= cp <= 0x202E or 0x2066 <= cp <= 0x2069:
        return rtl
    if 0x180B <= cp <= 0x180F:
        return prev >= 0 and _in(prev, 0x1800, 0x18AF)
    if cp in (0x17B4, 0x17B5):
        return (prev >= 0 and _in(prev, 0x1780, 0x17FF)) or (nxt >= 0 and _in(nxt, 0x1780, 0x17FF))
    if cp in (0x200C, 0x200D):
        for other in (prev, nxt):
            if other < 0:
                continue
            if _cp_in_ranges(other, _JOINING) or _is_symbol(other):
                return True
        return False
    if 0xFE00 <= cp <= 0xFE0F:
        if prev >= 0 and (_is_symbol(prev) or _is_cjk(prev)):
            return True
        return nxt == 0x20E3
    return False


def _nbsp_is_kept(text, i):
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if (prev and prev.isdigit()) or (nxt and nxt.isdigit()):
        return True
    if nxt and nxt in _NBSP_BEFORE:
        return True
    if prev and prev in _NBSP_AFTER_OPEN:
        return True
    return False


# spec: N-000303..N-000319 (cleanup rules), N-000171 (invisible characters), N-000177/N-000178 (character layer)
def scrub_characters(text):
    """Remove or normalise the character layer.

    Returns (text, invisible_removed, nonstandard_spaces_normalised).
    """
    rtl = bool(_RTL_RE.search(text))
    out = []
    invisible = 0
    spaces = 0
    for i, ch in enumerate(text):
        cp = ord(ch)
        if (32 <= cp < 127) or cp in (9, 10, 13):
            out.append(ch)
            continue
        if _is_invisible_cp(cp):
            if _invisible_is_kept(text, i, cp, rtl):
                out.append(ch)
            else:
                invisible += 1
            continue
        if cp in (0x2028, 0x2029):
            out.append('\n')
            continue
        if unicodedata.category(ch) == 'Zs' and cp != 0x20:
            if cp in (0xA0, 0x202F) and _nbsp_is_kept(text, i):
                out.append(ch)
                continue
            spaces += 1
            out.append(' ')
            continue
        out.append(ch)
    return ''.join(out), invisible, spaces


# spec: N-000177 (rule 66 homoglyph condition), N-000310/N-000311 (fold runs)
def homoglyph_runs(text):
    """Letter runs that mix ASCII Latin with Latin-looking lookalikes (rule 66)."""
    runs = []
    for m in _LETTER_RUN.finditer(text):
        word = m.group(0)
        if word.isascii():
            continue
        has_latin = False
        has_look = False
        other = False
        for ch in word:
            if ch in ASCII_LETTERS:
                has_latin = True
            elif ch in HOMOGLYPHS:
                has_look = True
            elif ord(ch) > 127:
                other = True
                break
        if has_latin and has_look and not other:
            runs.append(m.span())
    return runs


def fold_homoglyphs(text):
    spans = homoglyph_runs(text)
    if not spans:
        return text
    out = []
    pos = 0
    for start, end in spans:
        out.append(text[pos:start])
        out.append(''.join(HOMOGLYPHS.get(c, c) for c in text[start:end]))
        pos = end
    out.append(text[pos:])
    return ''.join(out)


def trailing_whitespace_hits(text):
    """Rule 68: spaces/tabs before a line end, trailing blank lines, leading whitespace."""
    hits = 0
    for line in text.split('\n'):
        if line.endswith((' ', '\t')):
            hits += 1
    if text.endswith('\n\n'):
        hits += 1
    if text[:1].isspace():
        hits += 1
    return hits


# spec: N-000312..N-000315 (trim), N-000316..N-000319 (cleanup agrees with detection), N-000322..N-000324
def clean_for_output(text):
    """Scrub the whole extracted prose for --clean (FP-03)."""
    text, _, _ = scrub_characters(text)
    text = fold_homoglyphs(text)
    text = text.replace('\r\n', '\n').replace('\r', '\n')
    ended_with_newline = text.endswith('\n')
    lines = [line.rstrip(' \t') for line in text.split('\n')]
    body = '\n'.join(lines)
    body = body.lstrip(' \t\n').rstrip()
    if ended_with_newline and body:
        body += '\n'
    return body


# ---------------------------------------------------------------------------
# Scan-text preparation (FP-01 generates no findings inside these)
# ---------------------------------------------------------------------------

_FENCE_OPEN = re.compile(r'^ {0,3}(`{3,}|~{3,})')
_FENCE_CLOSE = re.compile(r'^ {0,3}(`{3,}|~{3,})\s*$')
_TABLE_ROW = re.compile(r'^[ \t]*\|.*')
_BADGE_LINE = re.compile(r'^[ \t]*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$')
_INLINE_CODE = re.compile(r'`[^`\n]*`')


# spec: N-000149 (no findings inside fenced code, inline code, blockquotes, tables, badges, front matter)
def build_scan_text(text):
    lines = text.split('\n')
    if lines and lines[0].strip() == '---':
        for j in range(1, len(lines)):
            if lines[j].strip() == '---':
                for k in range(j + 1):
                    lines[k] = ''
                break
    out = []
    fence = None
    for ln in lines:
        if fence is None:
            m = _FENCE_OPEN.match(ln)
            if m:
                fence = (m.group(1)[0], len(m.group(1)))
                out.append('')
            else:
                out.append(ln)
        else:
            m = _FENCE_CLOSE.match(ln)
            if m and m.group(1)[0] == fence[0] and len(m.group(1)) >= fence[1]:
                fence = None
            out.append('')
    # blockquote runs of two or more lines, table rows, and badge lines
    i = 0
    while i < len(out):
        if out[i].lstrip().startswith('>'):
            j = i
            while j < len(out) and out[j].lstrip().startswith('>'):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    out[k] = ''
            i = j
            continue
        i += 1
    for k, ln in enumerate(out):
        if _TABLE_ROW.match(ln) and '|' in ln:
            out[k] = ''
        elif _BADGE_LINE.match(ln):
            out[k] = ''
    scan = '\n'.join(out)
    return _INLINE_CODE.sub(' ', scan)


_SENT_SPLIT = re.compile(r'(?<=[.!?])\s+|\n+')
_PARA_SPLIT = re.compile(r'\n\s*\n')
_WORD_RE = re.compile(r"[\w'\-]+")


def sentences_of(text):
    out = []
    for part in _SENT_SPLIT.split(text):
        p = part.strip()
        if p and re.search(r'[A-Za-z0-9]', p):
            out.append(p)
    return out


def paragraphs_of(text):
    return [p.strip() for p in _PARA_SPLIT.split(text) if p.strip()]


def words_of(text):
    return [w for w in _WORD_RE.findall(text) if any(c.isalnum() for c in w)]


def _cv(values):
    if len(values) < 2:
        return None
    mean = sum(values) / float(len(values))
    if mean <= 0:
        return None
    var = sum((v - mean) ** 2 for v in values) / float(len(values))
    return math.sqrt(var) / mean


class Context(object):
    """Pre-computed views of one scan window."""

    def __init__(self, text):
        self.text = text
        self.sents = sentences_of(text)
        self.paras = paragraphs_of(text)
        self.words = words_of(text)
        self.lines = text.split('\n')

    def snip(self, start, end, pad=40):
        seg = self.text[max(0, start - pad):min(len(self.text), end + pad)]
        seg = ' '.join(seg.split())
        if len(seg) > 110:
            seg = seg[:107] + '...'
        return seg


def _rx(*patterns, flags=re.I | re.M):
    compiled = [re.compile(p, flags) for p in patterns]

    def fn(c):
        spans = []
        for cre in compiled:
            for m in cre.finditer(c.text):
                spans.append((m.start(), m.end()))
        spans.sort()
        out = []
        last_end = -1
        for start, end in spans:
            if start < last_end:  # overlapping match of the same family: one occurrence
                continue
            last_end = end
            out.append(c.snip(start, end))
        return out
    return fn


def _infl(word):
    """Regex for a catalogue word and its inflected forms (FP-01 family rule)."""
    if ' ' in word:
        return r'\s+'.join(re.escape(p) for p in word.split(' '))
    if word.endswith('e'):
        return re.escape(word[:-1]) + r'(?:e|es|ed|ing)'
    return re.escape(word) + r'(?:s|es|ed|ing)?'


def _words_rx(words):
    return r'\b(?:' + '|'.join(_infl(w) for w in words) + r')\b'


AI_VOCAB = [
    'additionally', 'align with', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant',
    'meticulous', 'testament', 'underscore', 'intricate', 'intricacies', 'interplay',
    'garner', 'bolster', 'foster', 'showcase', 'emphasize', 'enduring', 'enhance',
    'leverage', 'utilize', 'facilitate', 'encompass', 'harness', 'holistic', 'paradigm',
    'transformative', 'unprecedented', 'myriad', 'plethora', 'robust', 'seamless',
    'navigate', 'embark', 'craft', 'landscape', 'journey', 'realm', 'multifaceted',
    'elevate', 'empower', 'unlock',
]
AI_VOCAB_RX = _words_rx(AI_VOCAB) + r'|capture the (?:essence|spirit|imagination|heart|magic)\b'

DIALECT_RX = [
    r'\bgenuinely\b', r'\bfascinating\b', r'\bnuanced\b', r'\bthoughtfully\b', r'\brefreshingly\b',
    r'\bstrikingly\b', r'\bcompellingly\b', r'\bquietly (?:powerful|profound|radical)\b',
    r'\bdeeply (?:human|personal|felt|unsettling)\b', r'\bresonates deeply\b',
    r'\bgame-chang(?:er|ers|ing|ed)\b', r'\bsupercharg(?:e|es|ed|ing)\b',
    r'\bskyrocket(?:s|ed|ing)?\b', r'\bturbocharg(?:e|es|ed|ing)\b',
    r'\brevolutioniz(?:e|es|ed|ing)\b', r'\bdouble down on\b', r'\bdive deep(?:er)? into\b',
    r'\bunlock(?:s|ed|ing)? the (?:power|potential|value)\b',
    r'\btake [^.!?\n]{1,40}?to the next level\b',
]

PROMO_RX = [
    r'\bnestled\b', r'\bbreathtaking\b', r'\bmust-visit\b', r'\bstunning\b', r'\bpicturesque\b',
    r'\bcharming\b', r'\bidyllic\b', r'\bvibrant community\b', r'\brich cultural heritage\b',
    r'\bin the heart of\b', r'\bworld-class\b', r'\btop-tier\b', r'\bunparalleled\b', r'\bpremier\b',
    r'\bleading\b', r'\besteemed organi[sz]ation\b', r'\bvaluable asset\b', r'\bpassion for excellence\b',
    r'\bproven track record\b', r'\bresults-oriented\b', r'\bwealth of experience\b',
    r'\bdynamic team\b', r'\bfast-paced environment\b', r'\bdeeply passionate\b',
    r'\bperfectly situated\b', r'\bclose-knit\b', r'\btight-knit\b',
    r'\bI am excited to (?:apply|bring)\b', r'\buniquely positioned to\b',
]
IMPERATIVE_OPENERS = re.compile(
    r'^(install|join|grab|download|try|discover|experience|escape|transform|reclaim|unlock|elevate|'
    r'boost|say|imagine|explore|meet|introducing|upgrade|claim|unleash|supercharge|level|stop|start)\b',
    re.I)

SYNONYM_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]

HYPHEN_PAIRS = [
    'world-class', 'top-tier', 'cutting-edge', 'game-changing', 'state-of-the-art',
    'best-in-class', 'results-driven', 'data-driven', 'user-friendly', 'high-quality',
    'next-generation', 'battle-tested', 'forward-thinking', 'award-winning',
    'fast-paced', 'long-lasting',
]

ADJ_SUFFIX = re.compile(r'(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$', re.I)
ADJ_STOCK = {'vibrant', 'robust', 'seamless', 'rich', 'dynamic', 'innovative', 'comprehensive',
             'transformative', 'elegant', 'powerful', 'cutting', 'stunning'}

HEDGES = ['may', 'might', 'could', 'possibly', 'potentially', 'arguably', 'perhaps',
          'somewhat', 'relatively', 'fairly']
HEDGE_PHRASES = [r'seems? (?:to|like)', r'appears? to', r'kind of', r'sort of']

TRANSITION_RX = re.compile(
    r'^(additionally|furthermore|moreover|however|nevertheless|consequently|subsequently|notably)\b', re.I)

SLOP_RX = [
    r'unlocking (?:its |their |your |the )?full potential', r'navigating the complexities',
    r'a testament to the (?:power|importance) of', r'staying ahead of the curve',
    r'turning challenges into opportunities', r'taking (?:it|something|this|your \w+) to the next level',
    r'harnessing the power of', r'paving the way for', r'saying goodbye to',
    r'imagining a world where',
]

_HEDGE_WORD = re.compile(r'\b(?:' + '|'.join(HEDGES) + r')\b|\b(?:' + '|'.join(HEDGE_PHRASES) + r')', re.I)

_EMOJI_RX = re.compile('[\U0001F000-\U0001FAFF☀-➿⬀-⯿]')
_CONTRACTED_RX = re.compile(
    r"\b\w+n't\b|\b(?:I'm|I've|I'll|I'd|we're|we've|we'll|it's|that's|there's|they're|you're|don't)\b", re.I)
_EXPANDED_RX = re.compile(
    r"\b(?:I am|I have|I will|I would|I had|we are|we have|we will|we would|do not|does not|did not|"
    r"is not|are not|was not|were not|cannot|will not|would not|should not|could not|that is|"
    r"it is|there is|they are|you are|let us|have not|has not)\b", re.I)
_FIRST_PERSON_RX = re.compile(r"\b(?:I|me|my|mine|we|us|our|ours)\b", re.I)


def _sent_match(c, pred):
    return [s[:110] for s in c.sents if pred(s)]


def f_ai_vocab(c):
    return _rx(AI_VOCAB_RX)(c)


def f_dialect(c):
    hits = _rx(*DIALECT_RX)(c)
    return hits if len(hits) >= 2 else []


def f_promo(c):
    hits = _rx(*PROMO_RX)(c)
    imperative = [s for s in c.sents if IMPERATIVE_OPENERS.match(s)]
    if len(imperative) >= 3:
        hits += [s[:110] for s in imperative]
    return hits


def f_hyphen_pairs(c):
    return _rx(*[r'\b' + re.escape(p) + r'\b' for p in HYPHEN_PAIRS])(c)


def f_simple_yet(c):
    return _rx(r'\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b')(c)


def f_stacked_adjectives(c):
    out = []
    for s in c.sents:
        for m in re.finditer(r'\b(\w[\w-]*(?:,\s*|,?\s+and\s+|,?\s+or\s+)\w[\w-]*(?:,\s*|,?\s+and\s+|,?\s+or\s+)\w[\w-]*(?:,\s*|,?\s+and\s+|,?\s+or\s+)\w[\w-]*)\b', s):
            items = re.findall(r'[\w-]+', m.group(1))
            if len(items) < 4:
                continue
            if any(ADJ_SUFFIX.search(w) or w.lower() in ADJ_STOCK for w in items):
                out.append(m.group(1)[:110])
    return out


def f_synonyms(c):
    out = []
    for cluster in SYNONYM_CLUSTERS:
        present = []
        for member in cluster:
            pat = r'\b' + re.escape(member) + r's?\b'
            found = list(re.finditer(pat, c.text, re.I))
            if found:
                present.append((member, found))
        if len(present) >= 3:
            for _, found in present:
                out += [c.snip(m.start(), m.end()) for m in found]
    return out


def f_significance(c):
    return _rx(
        r'\b(?:stands?|serves?|stood|served) as an? (?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b',
        r'\b(?:underscores?|underscored|underscoring|highlights?|highlighted|highlighting) (?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b',
        r'\breflects a broader (?:trend|shift|pattern)\b',
        r'\bmarks a (?:turning point|milestone|watershed|new chapter|new era)\b',
        r'\bsymboliz(?:es|ed|ing)\b', r'\bsets the stage for\b', r'\bleft an indelible mark\b',
        r'\bplays a (?:crucial|pivotal|vital|key|central|significant) role\b',
        r'\bhas (?:shaped|sparked)\b', r'\bhas come to (?:define|symbolize)\b',
    )(c)


def f_notability(c):
    return _rx(
        r'(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by) [^.!?\n]*?[A-Z][\w.]+(?:,\s+[A-Z][\w.]+)*,?\s+and\s+[A-Z][\w.]+',
        r'\b\d[\d,.]*\s*(?:k\s+|million\s+|thousand\s+)?followers\b',
        r'\b(?:strong|active)\s+(?:online|digital|social[- ]media)\s+presence\b',
        r'\bwidely (?:covered|cited|reported)\b', r'\bindependent coverage\b',
        flags=re.M,
    )(c)


def f_vague_attribution(c):
    return _rx(
        r'\bexperts? (?:argue|believe|say|claim|note|suggest)\b', r'\bindustry (?:reports|observers|analysts)\b',
        r'\bobservers have (?:cited|noted)\b', r'\bsome critics argue\b', r'\bresearchers have found\b',
        r'\bstudies suggest\b', r'\bit is widely believed\b',
    )(c)


def f_article_title(c):
    return _rx(r'\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of (?:\S+\s+){1,6}?(?:is|are) (?:a|an|the)\b',
               flags=re.M)(c)


def f_conservation(c):
    return _rx(
        r'\bplays a (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b',
        r'\bconservation efforts are (?:underway|ongoing|in place)\b',
        r'\bserves as an indicator species\b', r'\bcontributes to biodiversity\b',
    )(c)


def f_false_ranges(c):
    return _rx(
        r'\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]*\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b',
        r'\bfrom (?:the )?humble\b[^.!?\n]*\bto (?:the )?(?:mighty|towering|grand|sprawling)\b',
    )(c)


def f_ing_tails(c):
    return _rx(r',\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|'
               r'cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|'
               r'indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b')(c)


def f_parallelism(c):
    return _rx(
        r"\bit(?:'|’)s not (?:just|merely) (?:about|an?)\b",
        r'\bnot only\b[^.!?\n]{0,40}?\bbut\b',
        r"\bdoesn(?:'|’)t just\b[^,.\n]{0,40}?\bit\b",
    )(c)


def f_tailing_negation(c):
    return _rx(r',\s+no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b')(c)


def f_not_x_just_y(c):
    return _rx(
        r'\b(?:no|not) \w+, (?:just|only|simply) \w+',
        r'\b(?:not|isn(?:\'|’)t|aren(?:\'|’)t|wasn(?:\'|’)t|weren(?:\'|’)t) (?:just|merely) (?:a|an|the) \w+(?:,|\s*[—–-])\s*(?:it(?:\'|’)s|it is|it was|they(?:\'|’)re|they are|they were|that(?:\'|’)s|but)\b',
    )(c)


def f_filler(c):
    return _rx(r'\bin order to\b', r'\bdue to the fact that\b', r'\bat this point in time\b',
               r'\bin the event that\b', r'\bhas the ability to\b',
               r'\bit is important to note that\b', r'\bit should be mentioned that\b',
               r'\bneedless to say\b')(c)


def f_empty_pivot(c):
    return _rx(
        r"\bit(?:'|’)s worth (?:noting|mentioning) that\b", r'\bit bears (?:noting|mentioning) that\b',
        r'\bone thing to consider is\b', r'\bkeep in mind is\b', r'\bit is interesting to note that\b',
        r'\ba key consideration is\b', r'\ba point to highlight is\b',
    )(c)


def f_outcome_tails(c):
    return _rx(r',\s+(?:raising questions about|prompting reflection on|sparking debate about|'
               r'with broader implications for|reshaping our understanding of|paving the way for|'
               r'signaling a shift toward)\b')(c)


def f_persuasive(c):
    return _rx(r"\bhere(?:'|’)s the thing\b", r'\bmake no mistake\b', r'\bthe truth is\b',
               r"\blet(?:'|’)s be honest\b", r'\bthe simple fact is\b', r'\bat its core\b',
               r'\bwhat really matters\b', r'\bmore than anything\b', r'\bat the end of the day\b',
               r'\bthe bottom line is\b', r'\bin reality\b', r'"fundamentally,"|\bfundamentally,',
               r'\bthe real question is\b', r'\bthe heart of the matter\b', r'\bthe deeper issue\b',
               r'\bwhen you get down to it\b', r'\bwhen all is said and done\b')(c)


def f_interjections(c):
    return _rx(r"\bit(?:'|’)?s? (?:is )?important to (?:remember|note|understand|recognize)\b",
               r'\bone must note that\b', r'\bit is worth pointing out\b',
               r'\bit cannot be overstated that\b', r'\bit must be emphasized that\b')(c)


def f_self_thorough(c):
    return _rx(r'\bthis (?:comprehensive|in-depth|complete) (?:guide|overview|analysis|look|examination)\b',
               r'\bthis complete (?:guide|overview)\b', r'\ba thorough examination of\b',
               r'\beverything you need to know about\b')(c)


AUX = {'is', 'are', 'was', 'were', 'do', 'does', 'did', 'can', 'could', 'will', 'would', 'should',
       'has', 'have', 'had', 'may', 'might', 'must', 'shall'}
ANSWER_RX = re.compile(r'^(yes|no|absolutely|never|maybe|probably|always)[.!]$', re.I)


def f_qa(c):
    out = []
    sents = c.sents
    for i in range(len(sents) - 1):
        q = sents[i]
        if not q.endswith('?'):
            continue
        first = re.findall(r"[A-Za-z']+", q)
        if not first or first[0].lower() not in AUX:
            continue
        if len(q.split()) > 12:
            continue
        if ANSWER_RX.match(sents[i + 1]):
            out.append(q[:110])
    return out


def f_concrete_evidence(c):
    return _rx(r'\bwithout concrete (?:evidence|proof)\b', r'\bdo you have concrete evidence\b',
               r'\bI (?:would )?need concrete (?:evidence|examples) to\b', r'\babsent concrete proof\b',
               r'\bprovide concrete evidence\b')(c)


def f_intro_hooks(c):
    return _rx(r"\bin today(?:'|’)s (?:\w+\s+){0,2}?(?:world|landscape|environment|market)\b",
               r'\bin a world where\b', r'\bin an era of\b', r'\bin recent years,',
               r'\bmore than ever before\b', r'\bwe live in a (?:time|world) when\b',
               r'\b(?:great|exciting|big) news\s*[!:]', r'\bever (?:wanted|wondered|dreamed|wished to)\b[^?\n]*\?',
               r'\bin an increasingly (?:interconnected|digital|competitive|complex) world\b')(c)


def f_diff_anchored(c):
    return _rx(
        r'\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b',
        r'\b(?:the|this) (?:latest |new )?(?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b',
        r'\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b',
        r'\bpreviously\b[^.!?\n]*\bnow\b',
        r'\bwas(?:n\'t|n’t)? there before\b', r'\bwe(?:\'ve|’ve| have) (?:now )?(?:added|removed|replaced|refactored|migrated)\b',
    )(c)


def f_signposting(c):
    return _rx(r"\blet(?:'|’)s (?:dive|delve|explore)\b", r"\blet(?:'|’)s (?:break|break it) (?:this|it) down\b",
               r"\bhere(?:'|’)s what you need to know\b", r'\bwithout further ado\b',
               r'\bnow let(?:\'|’)s look at\b', r'\bbuckle up\b', r'\bstay with me\b',
               r'\bready to dive in\b')(c)


def f_cataloguing(c):
    return _rx(
        r'\b(?:used|uses|employs?|employed|relied on|utilizes) (?:several|various|a number of|multiple|different|many|numerous) \w+',
        r'\bThese (?:\w+ )?(?:provide|offer|give|reveal|show|allow|enable|help) (?:information|insight|understanding|details|data)\b',
        r'\b(?:is|are|was|were|remains|becomes) (?:the |a )?(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue) of\b',
        flags=re.M,
    )(c)


def f_inline_header(c):
    return _rx(r'^[ \t]*(?:[-*+]\s+|\d+\.\s+)?\*\*[^*\n]{1,80}:\*\*',
               r'^[ \t]*(?:[-*+]\s+)?\*\*[^*\n]{1,80}\*\*:', flags=re.M)(c)


_BULLET_LINE = re.compile(r'^[ \t]*(?:[-*+]|\d+[.)])\s+')
_HEADING_LINE = re.compile(r'^[ \t]{0,3}#{1,6}\s+\S')


def f_mid_essay_bullets(c):
    if any(_HEADING_LINE.match(ln) for ln in c.lines):
        return []
    bullet_paras = []
    prose = 0
    for para in c.paras:
        lines = [ln for ln in para.split('\n') if ln.strip()]
        if lines and all(_BULLET_LINE.match(ln) for ln in lines):
            bullet_paras.append(para[:110])
        else:
            prose += 1
    if bullet_paras and prose >= 2:
        return bullet_paras
    return []


def f_fragmented_headers(c):
    out = []
    lines = c.lines
    for i, ln in enumerate(lines):
        if not _HEADING_LINE.match(ln):
            continue
        heading_words = set(w.lower() for w in re.findall(r'[A-Za-z]{4,}', ln))
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if not nxt or nxt.startswith(('#', '|', '-', '*', '>')) or re.match(r'^\d+[.)]\s', nxt):
            continue
        words = re.findall(r'[A-Za-z]+', nxt)
        if not words or len(words) > 4:
            continue
        if heading_words & set(w.lower() for w in words):
            out.append(nxt[:110])
    return out


def f_transition_clusters(c):
    out = []
    for para in c.paras:
        starts = [s for s in sentences_of(para) if TRANSITION_RX.match(s)]
        if len(starts) >= 2:
            out += [s[:110] for s in starts]
    return out


def f_conclusions(c):
    return _rx(r'^[ \t]*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|ultimately)\b',
               flags=re.I | re.M)(c)


def f_generic_positive(c):
    return _rx(r'\bthe future looks bright\b', r'\bexciting times lie ahead\b', r'\bjourney toward excellence\b',
               r'\bstep in the right direction\b', r'\b(?:the )?(?:outlook|future)(?: for [^.!?\n]+)? (?:is|looks|remains) bright\b',
               r'\bwell[- ]positioned for (?:whatever comes next|the future|the road ahead)\b')(c)


def _sentence_lengths(c):
    return [len(words_of(s)) for s in c.sents if words_of(s)]


def f_sentence_monotony(c):
    lengths = _sentence_lengths(c)
    if len(lengths) < 3:
        return []
    cv = _cv(lengths)
    if cv is not None and cv < 0.35:
        return ['sentence lengths nearly identical (coefficient of variation %.2f)' % cv]
    return []


def f_alternation(c):
    lengths = _sentence_lengths(c)
    out = []
    n = len(lengths)
    for i in range(n - 5):
        window = lengths[i:i + 6]
        diffs = [window[k + 1] - window[k] for k in range(5)]
        if all(abs(d) >= 4 for d in diffs) and all(diffs[k] * diffs[k + 1] < 0 for k in range(4)):
            out.append('alternating sentence lengths %s' % '/'.join(str(x) for x in window))
            break
    return out


def f_opener_repetition(c):
    out = []
    for para in c.paras:
        sents = sentences_of(para)
        if len(sents) < 3:
            continue
        counts = {}
        for s in sents:
            pair = ' '.join(s.split()[:2]).lower()
            counts[pair] = counts.get(pair, 0) + 1
        for pair, k in counts.items():
            if k >= 3:
                out.append(pair)
    return out


def f_uniform_paragraphs(c):
    counts = [len(words_of(p)) for p in c.paras]
    counts = [k for k in counts if k > 0]
    if len(counts) < 4:
        return []
    cv = _cv(counts)
    if cv is not None and cv < 0.4:
        return ['paragraph lengths nearly identical (coefficient of variation %.2f)' % cv]
    return []


def f_semicolons(c):
    if len(c.words) < 300:
        return []
    parens = len(re.findall(r'\([^()\n]{1,200}\)', c.text))
    if ';' not in c.text and parens <= 1:
        return ['no semicolons and almost no parentheses in a long document']
    return []


def f_chatbot(c):
    return _rx(
        r'\bI hope this helps\b', r'\bCertainly!', r'\bOf course!', r'\blet me know if you\b',
        r'\bwould you like me to\b', r'\bfeel free to (?:ask|reach out)\b', r'\bhappy to help\.',
        r'\bhere (?:is|\'s|are) (?:a|an|the) (?:overview|summary|rundown|recap|brief)\b',
        r'\bhere (?:are|\'s a few|\'s some) (?:a few |some |two |three )?(?:options|drafts|versions|variations)\b',
        r'\bhere is (?:a|the) draft\b', r"\bhere(?:'|’)s a draft\b",
        r'\bdepending on the (?:vibe|tone|style)\b', r'\bI hope this email finds you well\b',
        r'\bas an (?:AI|LLM|AI assistant|AI language model|large language model|language model)\b',
        r'\bto answer your question\b', r'\bto address your question\b',
        r'\bin response to your question\b', r'\bin answer to your question\b',
        r'\byour question (?:about|regarding|concerning)\b', r'\bas (?:you )?(?:requested|asked), here\b',
        r'\bhere is (?:the )?(?:draft|first pass|revised version) (?:of|for your)\b',
        flags=re.M,
    )(c)


def f_sycophancy(c):
    return _rx(
        r"\byou(?:'re| are) absolutely right\b",
        r'\b(?:great|excellent|wonderful|fantastic|thoughtful) (?:question|point)\s*[!.,]',
        r'\bwhat a (?:thoughtful|great|wonderful|fantastic) question\b',
        r"\bthat(?:'|’)s a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b",
    )(c)


def f_cutoff(c):
    return _rx(
        r'\bas of my (?:last )?(?:training|knowledge)\b', r'\bup to my (?:last )?(?:training|knowledge)\b',
        r'\bwhile specific details are (?:limited|scarce|not extensively (?:documented|widely documented)|not widely documented)\b',
        r'\bbased on (?:the )?available information\b', r'\bas of my (?:knowledge )?cutoff\b',
        r'\bmaintains a low profile\b', r'\bkeeps (?:his|her|their) personal life private\b',
    )(c)


def f_copula(c):
    return _rx(
        r'\b(?:serves|stands|functions|acts) as\b', r'\brepresents an? \w+', r'\bmarks an? \w+',
        r'\bboasts\b', r'\bfeatures (?:an?|the|one|\d+|several|many)\b', r'\boffers an? \w+',
        r'\brefers to\b',
    )(c)


def f_hedge_stacking(c):
    out = []
    for s in c.sents:
        if len(_HEDGE_WORD.findall(s)) >= 2:
            out.append(s[:110])
    return out


def f_contractions(c):
    words = c.words
    if not words:
        return []
    first_person = len(_FIRST_PERSON_RX.findall(c.text))
    if first_person / float(len(words)) < 0.03:
        return []
    expanded = len(_EXPANDED_RX.findall(c.text))
    contracted = len(_CONTRACTED_RX.findall(c.text))
    if expanded >= 3 and expanded >= 0.75 * (expanded + contracted):
        return ['%d expanded forms, %d contractions' % (expanded, contracted)]
    return []


def f_bold(c):
    hits = [m for m in re.finditer(r'\*\*[^*\n]+\*\*', c.text)]
    if len(hits) < 2:
        return []
    return [c.snip(m.start(), m.end()) for m in hits]


def f_emoji(c):
    return [c.snip(m.start(), m.end()) for m in _EMOJI_RX.finditer(c.text)]


def f_em_dash(c):
    out = []
    for para in c.paras:
        if para.count('—') >= 2:
            out.append(para[:110])
    return out


_SMALL_WORDS = {'a', 'an', 'the', 'and', 'but', 'or', 'nor', 'for', 'so', 'yet', 'of', 'in', 'on',
                'at', 'to', 'by', 'with', 'from', 'as', 'into', 'via', 'per', 'vs', 'vs.'}


def f_title_case(c):
    out = []
    for ln in c.lines:
        m = re.match(r'^[ \t]{0,3}#{1,6}\s+(.+?)\s*#*\s*$', ln)
        if not m:
            continue
        title = m.group(1)
        words = title.split()
        if len(words) < 3 or not words[0][:1].isalpha() or title.isupper():
            continue
        major = [w for w in words if w.lower().strip('.,:;!?') not in _SMALL_WORDS]
        if len(major) < 2:
            continue
        if all(w[:1].isupper() for w in major):
            out.append(title[:110])
    return out


def f_curly_quotes(c):
    return _rx('[‘’“”]', flags=0)(c)


def f_challenges(c):
    return _rx(r'\bdespite (?:these|its|the) (?:challenges|obstacles)\b',
               r'\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b',
               r'\bcontinues to thrive\b', r'\btypical of (?:emerging|urban|modern)\b',
               r'\bfaces (?:several|many|numerous) challenges\b')(c)


def f_year_range(c):
    out = []
    for m in re.finditer(r'\b(1[5-9]\d\d|20\d\d)-(1[5-9]\d\d|20\d\d)\b', c.text):
        if int(m.group(1)) < int(m.group(2)):
            out.append(c.snip(m.start(), m.end()))
    return out


def f_placeholder(c):
    return _rx(
        r'\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]]*\](?![(\[])',
        r'\[[A-Z][A-Z0-9 _\-]{2,}\](?![(\[])',
        r'\{\{[^}]*\}\}',
        r'(?<![A-Za-z])x{3,}(?![A-Za-z])',
        r'\blorem ipsum\b',
        flags=re.I,
    )(c)


def f_chat_markup(c):
    return _rx(r'\bcite(?:turn|start|nav)\w*', r'\boai_citation\w*', r'\bcontentReference\w*',
               r'\bnavlist\w*', r'【\d+†[^】]*】')(c)


AI_UTM_HOSTS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai',
                'gemini.google.com', 'copilot.microsoft.com', 'poe.com'}


def f_utm(c):
    out = []
    for m in re.finditer(r'utm_source=([A-Za-z0-9.\-]+)', c.text):
        host = m.group(1).rstrip('.').lower()
        if host in AI_UTM_HOSTS:
            out.append(c.snip(m.start(), m.end()))
    return out


def f_trailing(c):
    return []


def f_slop(c):
    return _rx(*SLOP_RX)(c)


def f_rules(c):
    rules = [ln for ln in c.lines if re.match(r'^[ \t]{0,3}([-*_])(\s*\1){2,}\s*$', ln)]
    if len(rules) >= 3 and len(c.lines) >= 24:
        return [r.strip() for r in rules]
    return []


def f_degenerate(c):
    words = [w.lower() for w in c.words]
    n = len(words) - 5
    if n < 6:
        return []
    grams = [tuple(words[i:i + 6]) for i in range(n)]
    counts = {}
    for g in grams:
        counts[g] = counts.get(g, 0) + 1
    repeated = sum(1 for g in grams if counts[g] >= 2)
    if repeated and repeated / float(n) >= 0.2:
        worst = max(counts.items(), key=lambda kv: kv[1])
        return [' '.join(worst[0])]
    return []


# (number, slug, label, kind, function). kind: score, decisive, rhythm, advice.
FAMILIES = [
    (1, 'ai_vocabulary', 'AI vocabulary', 'score', f_ai_vocab),
    (2, 'model_dialect', 'model-dialect vocabulary', 'score', f_dialect),
    (3, 'promotional_language', 'promotional language', 'score', f_promo),
    (4, 'hyphenated_pairs', 'hyphenated word-pair overuse', 'advice', f_hyphen_pairs),
    (5, 'simple_yet', 'simple-yet cliche', 'score', f_simple_yet),
    (6, 'stacked_adjectives', 'stacked adjective chain', 'score', f_stacked_adjectives),
    (8, 'synonym_cycling', 'synonym cycling', 'score', f_synonyms),
    (10, 'significance_inflation', 'significance inflation', 'score', f_significance),
    (11, 'notability', 'notability name-dropping', 'score', f_notability),
    (12, 'vague_attribution', 'vague attribution', 'score', f_vague_attribution),
    (13, 'article_title', 'article title as proper noun', 'decisive', f_article_title),
    (14, 'conservation_padding', 'conservation padding', 'score', f_conservation),
    (15, 'false_range', 'false range', 'score', f_false_ranges),
    (16, 'ing_tail', 'superficial -ing tail clause', 'score', f_ing_tails),
    (17, 'negative_parallelism', 'negative parallelism', 'advice', f_parallelism),
    (17, 'tailing_negation', 'tailing negation', 'score', f_tailing_negation),
    (18, 'not_x_just_y', 'not X, just Y', 'score', f_not_x_just_y),
    (19, 'filler_phrases', 'filler phrase', 'advice', f_filler),
    (20, 'empty_pivot', 'empty pivot phrase', 'score', f_empty_pivot),
    (21, 'outcome_tail', 'outcome speculation tail', 'score', f_outcome_tails),
    (22, 'persuasive_trope', 'persuasive authority trope', 'advice', f_persuasive),
    (23, 'editorial_interjection', 'editorial interjection', 'score', f_interjections),
    (24, 'self_thoroughness', 'self-thoroughness phrase', 'score', f_self_thorough),
    (25, 'question_answer', 'question-answer rhetorical pattern', 'score', f_qa),
    (26, 'concrete_evidence', 'concrete-evidence defense phrase', 'score', f_concrete_evidence),
    (27, 'intro_hook', 'compulsive intro hook', 'score', f_intro_hooks),
    (30, 'diff_anchored', 'diff-anchored writing', 'score', f_diff_anchored),
    (31, 'signposting', 'signposting announcement', 'score', f_signposting),
    (32, 'cataloguing_leadin', 'cataloguing lead-in', 'score', f_cataloguing),
    (33, 'inline_header_list', 'inline-header vertical list', 'score', f_inline_header),
    (34, 'bullet_injection', 'mid-essay bullet injection', 'score', f_mid_essay_bullets),
    (35, 'fragmented_header', 'fragmented header', 'score', f_fragmented_headers),
    (36, 'formulaic_challenges', 'formulaic challenges section', 'score', f_challenges),
    (37, 'transition_cluster', 'transition cluster', 'score', f_transition_clusters),
    (38, 'compulsive_conclusion', 'compulsive conclusion phrase', 'score', f_conclusions),
    (39, 'generic_positive_ending', 'generic positive conclusion', 'score', f_generic_positive),
    (40, 'sentence_monotony', 'sentence-length monotony', 'rhythm', f_sentence_monotony),
    (41, 'mechanical_alternation', 'mechanical sentence-length alternation', 'advice', f_alternation),
    (42, 'opener_repetition', 'opener repetition', 'advice', f_opener_repetition),
    (44, 'uniform_paragraphs', 'uniform paragraph length', 'rhythm', f_uniform_paragraphs),
    (46, 'semicolon_underuse', 'semicolon and parenthesis underuse', 'advice', f_semicolons),
    (47, 'chatbot_artifact', 'chatbot artifact', 'decisive', f_chatbot),
    (48, 'sycophancy', 'sycophantic tone', 'decisive', f_sycophancy),
    (50, 'knowledge_cutoff', 'knowledge-cutoff disclaimer', 'decisive', f_cutoff),
    (51, 'copula_avoidance', 'copula avoidance', 'score', f_copula),
    (54, 'hedge_stacking', 'hedge stacking', 'advice', f_hedge_stacking),
    (55, 'contraction_absence', 'contraction absence', 'advice', f_contractions),
    (56, 'boldface', 'boldface overuse', 'score', f_bold),
    (57, 'emoji', 'emoji', 'score', f_emoji),
    (58, 'em_dash', 'em-dash overuse', 'advice', f_em_dash),
    (59, 'title_case_heading', 'title case in heading', 'score', f_title_case),
    (60, 'curly_quotes', 'curly quotation marks', 'advice', f_curly_quotes),
    (61, 'year_range_hyphen', 'hyphen for en dash in year range', 'advice', f_year_range),
    (63, 'placeholder', 'placeholder text', 'decisive', f_placeholder),
    (64, 'chat_markup', 'chatbot reference markup', 'decisive', f_chat_markup),
    (65, 'ai_tracking_param', 'AI tracking parameter', 'decisive', f_utm),
    (69, 'marketing_slop', 'canonical marketing phrase', 'score', f_slop),
    (70, 'decorative_rules', 'decorative horizontal rules', 'score', f_rules),
    (71, 'degenerate_repetition', 'degenerate repetition', 'score', f_degenerate),
]


# ---------------------------------------------------------------------------
# Scoring (FP-01 bands, families, floors, caps, confidence)
# ---------------------------------------------------------------------------

ADVICE_NUMS = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
RHYTHM_NUMS = {40, 41, 44, 55}
DECISIVE_NUMS = {13, 47, 48, 50, 62, 63, 64, 65, 66}
SHORT_DOC_SET = set(list(range(1, 40)) + list(range(47, 52)) + [69])
SCORE_KINDS = ('score', 'decisive', 'rhythm')


def band_for(score):
    for top, name in BANDS:
        if score <= top:
            return name
    return BANDS[-1][1]


def hook_phrase(band):
    return {
        'clean': 'reads clean',
        'light tells': 'reads mostly clean',
        'mixed': 'reads with some AI tells',
        'heavy tells': 'reads with heavy AI tells',
        'pervasive tells': 'reads with pervasive AI tells',
    }[band]


def _confidence(words, families):
    if words < 40:
        return 'none', 'fewer than 40 words, too little prose to judge'
    if words < 120:
        return 'low', 'fewer than 120 words'
    if words < 300 and families == 1:
        return 'low', 'under 300 words with only one score-moving pattern family'
    if words < 300:
        return 'moderate', 'under 300 words'
    return 'high', ''


def _family_entries(c, extra):
    """Build findings. extra maps a catalogue number to precomputed sample lists."""
    entries = []
    for num, slug, label, kind, fn in FAMILIES:
        if num in extra:
            snippets = extra[num]
        else:
            snippets = fn(c)
        if not snippets:
            continue
        entries.append({
            'key': '%d_%s' % (num, slug), 'num': num, 'label': label, 'kind': kind,
            'count': len(snippets), 'samples': [s for s in snippets[:3]],
        })
    return entries


# spec: N-000131..N-000144 (distinct families, floors, caps, rhythm kinds), N-000145..N-000148 (confidence)
def score_entries(entries, words):
    """Return (score, confidence, reason, flagged_numbers) for a list of findings."""
    sm = [e for e in entries if e['kind'] in SCORE_KINDS]
    fam_nums = set(e['num'] for e in sm)
    raw = 0
    per_num = {}
    for e in sm:
        per_num[e['num']] = per_num.get(e['num'], 0) + e['count']
    decisive = set(n for n in fam_nums if n in DECISIVE_NUMS)
    for num, hits in per_num.items():
        weight = 15 if num in DECISIVE_NUMS else 10
        raw += weight + min(max(hits - 1, 0), 3) * 2
    score = min(100, raw)
    conf, reason = _confidence(words, len(fam_nums))
    if not fam_nums:
        return 0, conf, reason, fam_nums

    floors = []
    caps = []
    if len(decisive) >= 2:
        floors.append(65)
    if len(decisive) == 1 and conf in ('moderate', 'high'):
        floors.append(45)
    if words < 120:
        short_n = len(fam_nums & SHORT_DOC_SET)
        if short_n >= 3:
            floors.append(45)
        elif short_n >= 2:
            floors.append(25)
    if words >= 400:
        if len(fam_nums) >= 6:
            floors.append(45)
        elif len(fam_nums) >= 5:
            floors.append(25)
    if fam_nums <= RHYTHM_NUMS:
        caps.append(20 if fam_nums <= {40} else 40)
    elif len(fam_nums) == 1 and not (len(decisive) == 1 and conf in ('moderate', 'high')):
        caps.append(40)
    if caps:
        score = min(score, min(caps))
    if floors:
        score = max(score, max(floors))
    return score, conf, reason, fam_nums


def analyze_text(scan, extra=None):
    """Score a scan text. Returns a dict with findings and score."""
    c = Context(scan)
    entries = _family_entries(c, extra or {})
    score, conf, reason, fam_nums = score_entries(entries, len(c.words))
    return {'entries': entries, 'score': score, 'confidence': conf,
            'confidence_reason': reason, 'words': len(c.words), 'sents': c.sents,
            'families': fam_nums}


def _ci(scan, point, sents):
    """Interval from four contiguous sentence blocks (only with --ci)."""
    if len(sents) < 4:
        return None, 'too few sentences for an interval (need at least four); point score unchanged'
    scores = [point]
    for k in range(4):
        lo = k * len(sents) // 4
        hi = (k + 1) * len(sents) // 4
        chunk = ' '.join(sents[lo:hi])
        scores.append(analyze_text(chunk)['score'])
    low = max(0, min(scores))
    high = min(100, max(scores))
    return [low, high], ('interval from four contiguous sentence blocks; the point score is unchanged')


def _char_layer_extra(text1, invisible, nss):
    """Findings for the character layer, computed on the scan window."""
    extra = {}
    if invisible:
        extra[62] = ['%d invisible or zero-width characters' % invisible]
    runs = homoglyph_runs(text1)
    if runs:
        extra[66] = ['%d mixed-script lookalike words' % len(runs)]
    if nss:
        extra[67] = ['%d non-standard space characters' % nss]
    trail = trailing_whitespace_hits(text1)
    if trail:
        extra[68] = ['%d lines or text ends with stray whitespace' % trail]
    return extra, len(runs)


# spec: N-000094..N-000114 (report, metrics), N-000236..N-000240 (window), N-000770..N-000774 (interval)
def build_report(prose, want_ci=False):
    """Analyse extracted prose and return the report dictionary."""
    total = len(prose)
    truncated = total > WINDOW
    window = prose[:WINDOW]
    text1, invisible, nss = scrub_characters(window)
    extra, homoglyphs = _char_layer_extra(text1, invisible, nss)
    scan = build_scan_text(text1)
    result = analyze_text(scan, extra)
    # The character-layer findings above are weight-bearing families; add their
    # entries so they appear as findings. Their keys follow the catalogue format.
    entries = result['entries']
    char_entries = []
    for num, slug, label, kind in ((62, 'invisible_characters', 'invisible or zero-width characters', 'decisive'),
                                   (66, 'homoglyphs', 'mixed-script homoglyphs', 'decisive'),
                                   (67, 'nonstandard_spaces', 'non-standard spaces', 'score'),
                                   (68, 'trailing_whitespace', 'trailing or stray whitespace', 'advice')):
        if num in extra:
            char_entries.append({'key': '%d_%s' % (num, slug), 'num': num, 'label': label,
                                 'kind': kind, 'count': len(extra[num]),
                                 'samples': extra[num][:3]})
    if char_entries:
        all_entries = entries + char_entries
        score, conf, reason, fam_nums = score_entries(all_entries, result['words'])
        entries = all_entries
    else:
        score, conf, reason, fam_nums = result['score'], result['confidence'], \
            result['confidence_reason'], result['families']
    entries.sort(key=lambda e: (e['num'], e['key']))
    band = band_for(score)
    report = {}
    for e in entries:
        report[e['key']] = {'label': e['label'], 'count': e['count'], 'samples': e['samples']}
    metrics = {
        'scanned_chars': len(window),
        'truncated': bool(truncated),
        'ai_tell_score': int(score),
        'ai_tell_band': band,
        'confidence': conf,
        'confidence_reason': reason,
        'patterns_flagged': len(entries),
        'invisible_chars': int(invisible),
        'nonstandard_spaces': int(nss),
        'homoglyphs': int(homoglyphs),
        'words': int(result['words']),
    }
    if want_ci:
        ci, note = _ci(scan, score, result['sents'])
        metrics['score_ci'] = ci
        metrics['score_ci_note'] = note
    report['_metrics'] = metrics
    return report


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------

def _error(message, status):
    line = json.dumps({'error': message}, ensure_ascii=False)
    sys.stderr.write(line + '\n')
    sys.stderr.flush()
    return status


def _write_bytes(stream, text):
    stream.buffer.write(text.encode('utf-8'))
    stream.flush()


def parse_argv(argv):
    clean = False
    ci = False
    show_help = False
    operands = []
    end = False
    for arg in argv:
        if end:
            operands.append(arg)
            continue
        if arg == '--':
            end = True
        elif arg in ('-h', '--help'):
            show_help = True
        elif arg == '--clean':
            clean = True
        elif arg == '--ci':
            ci = True
        elif arg == '-':
            operands.append(arg)
        elif arg.startswith('-'):
            return None, arg
        else:
            operands.append(arg)
    return {'clean': clean, 'ci': ci, 'help': show_help, 'operands': operands}, None


# spec: N-000226..N-000242 (error kinds, help, operands, UTF-8), N-000704..N-000715 (exit statuses)
def main(argv=None):
    if argv is None:
        argv = sys.argv[1:]
    opts, bad = parse_argv(argv)
    if opts is None:
        return _error("unknown option '%s'; see --help" % bad, 2)
    if opts['help']:
        _write_bytes(sys.stdout, USAGE)
        return 0

    operands = opts['operands']
    path = operands[0] if operands else None
    if len(operands) > 1:
        sys.stderr.write("prosecheck: scanned only the first file '%s'; %d more operand(s) ignored\n"
                         % (operands[0], len(operands) - 1))
        sys.stderr.flush()

    try:
        if path is None or path == '-':
            data = sys.stdin.buffer.read()
            ext = ''
        else:
            try:
                with open(path, 'rb') as handle:
                    data = handle.read()
            except OSError as exc:
                raise ProseError('cannot read input: %s' % (exc.strerror or exc))
            ext = os.path.splitext(path)[1].lower()
        prose = extract_prose(data, ext)
        if not prose.strip():
            raise ProseError('empty input')
        if opts['clean']:
            _write_bytes(sys.stdout, clean_for_output(prose[:]))
            return 0
        report = build_report(prose, want_ci=opts['ci'])
        _write_bytes(sys.stdout, json.dumps(report, ensure_ascii=False, indent=2) + '\n')
        return 0
    except ProseError as exc:
        return _error(exc.message, exc.status)
    except Exception as exc:  # no traceback on any failure path
        return _error('internal error: %s' % exc.__class__.__name__, 1)


if __name__ == '__main__':
    sys.exit(main())
