#!/usr/bin/env python3
"""prosecheck detector: scores AI-writing patterns in prose.

Standard library only (Python 3.9 or newer). Runs locally; no network, no model.

    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
    python3 scripts/detect.py --help

With FILE, reads that file. With no FILE, reads standard input (UTF-8).
Success: one JSON report on standard output, exit 0.
Cleanup (--clean): scrubbed text on standard output, exit 0.
Failure: nothing on standard output, last stderr line {"error": "..."}, exit 1 or 2.
"""
# spec: N-000732..N-000787 (scripts/detect.py interface), N-000226..N-000242 (empty / unreadable / options)

import bisect
import codecs
import html
import io
import json
import random
import re
import sys
import unicodedata
import zipfile

# spec: N-000245..N-000253 (size caps, binary units), N-000321 (window)
WINDOW = 262144
PLAIN_CAP = 512 * 1024
ARCHIVE_CAP = 4 * 1024 * 1024
ZIP_MEMBER_CAP = 64 * 1024 * 1024  # implementer's choice: largest archive member read

PLAIN_EXTS = frozenset(['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'])
ZIP_EXTS = frozenset(['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'])
NOTEBOOK_EXTS = frozenset(['.ipynb'])
BINARY_EXTS = frozenset(['.pdf', '.rtf'])

USAGE_FIRST_LINE = 'usage: detect.py [--clean] [--ci] [--] [FILE]'
USAGE_TEXT = (
    USAGE_FIRST_LINE + '\n'
    '\n'
    'Scores AI-writing patterns in prose. Reads FILE, or standard input when no FILE is given.\n'
    '  --clean   print the scrubbed text instead of the JSON report\n'
    '  --ci      add a low/high interval on the score (needs at least four sentences)\n'
    '  --        end option parsing, so a file name may begin with a dash\n'
    '  -h, --help  print this message and exit\n'
)

BANDS = ['clean', 'light tells', 'mixed', 'heavy tells', 'pervasive tells']
HOOK_PHRASES = {
    'clean': 'reads clean',
    'light tells': 'reads mostly clean',
    'mixed': 'reads with some AI tells',
    'heavy tells': 'reads with heavy AI tells',
    'pervasive tells': 'reads with pervasive AI tells',
}


def band_for(score):
    # spec: N-000115 (five bands, ranges of the score)
    if score <= 20:
        return 'clean'
    if score <= 40:
        return 'light tells'
    if score <= 60:
        return 'mixed'
    if score <= 80:
        return 'heavy tells'
    return 'pervasive tells'


# ---------------------------------------------------------------------------
# Extraction (FP-02)
# ---------------------------------------------------------------------------

class ReadError(Exception):
    """Unreadable input; the message is the user-facing error text."""


def decode_text(data):
    # spec: N-000254, N-000255, N-000241, N-000242 (UTF-8 with optional BOM, UTF-16 with BOM)
    if data.startswith(codecs.BOM_UTF8):
        return data[len(codecs.BOM_UTF8):].decode('utf-8', errors='replace')
    if data.startswith(codecs.BOM_UTF16_LE) or data.startswith(codecs.BOM_UTF16_BE):
        return data.decode('utf-16', errors='replace')
    return data.decode('utf-8', errors='replace')


TAG_RE = re.compile(r'<(/?)([A-Za-z_][\w.:-]*)((?:[^>"\']|"[^"]*"|\'[^\']*\')*)>')

# Block elements end a paragraph; spaced elements become a break or a tab.
DOCX_BLOCK = frozenset(['p'])
ODF_BLOCK = frozenset(['p', 'h', 'table-row', 'table-cell', 'list-item'])
XHTML_BLOCK = frozenset(['p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'tr', 'blockquote',
                         'section', 'article', 'dt', 'dd', 'figcaption', 'pre', 'ul', 'ol', 'table'])
XHTML_SKIP = frozenset(['script', 'style', 'nav', 'head', 'title', 'svg', 'math'])


def markup_to_text(src, block, skip=frozenset(), deleted=frozenset()):
    """Visible text of an XML/XHTML/ODF/OOXML fragment, without markup."""
    # spec: N-000256..N-000275 (XML markup characters must not leak into prose)
    src = re.sub(r'<!--.*?-->', ' ', src, flags=re.S)
    src = re.sub(r'<\?.*?\?>', ' ', src, flags=re.S)
    src = re.sub(r'<!DOCTYPE[^>]*>', ' ', src, flags=re.I)
    src = re.sub(r'<!\[CDATA\[(.*?)\]\]>', lambda m: html.escape(m.group(1), quote=False), src, flags=re.S)
    out = []
    stack = []
    pos = 0
    for m in TAG_RE.finditer(src):
        if not stack:
            seg = src[pos:m.start()]
            out.append(re.sub(r'[ \t\r\n]+', ' ', seg))
        pos = m.end()
        closing = bool(m.group(1))
        raw_name = m.group(2)
        local = raw_name.split(':')[-1].lower()
        attrs = m.group(3)
        self_closing = attrs.rstrip().endswith('/')
        if local in skip or local in deleted:
            if closing:
                if stack and stack[-1] == local:
                    stack.pop()
            elif not self_closing:
                stack.append(local)
            continue
        if stack:
            continue
        if not closing:
            if local in ('br', 'line-break'):
                out.append('\n')
            elif local == 'tab':
                out.append('\t')
            elif raw_name.startswith('text:') and local == 's':
                count = re.search(r'\bc="(\d+)"', attrs)
                out.append(' ' * (int(count.group(1)) if count else 1))
        if (closing or self_closing) and local in block:
            out.append('\n\n')
    if not stack:
        out.append(src[pos:])
    return html.unescape(''.join(out))


def xlsx_text(zf, names):
    # spec: N-000258..N-000263 (cell text sheet by sheet, shared strings by index)
    shared = []
    if 'xl/sharedStrings.xml' in names:
        sst = _read_member(zf, 'xl/sharedStrings.xml')
        for si in re.findall(r'<si\b[^>]*>(.*?)</si>', sst, flags=re.S):
            parts = re.findall(r'<t\b[^>]*>(.*?)</t>', si, flags=re.S)
            shared.append(html.unescape(''.join(parts)))
    sheets = sorted((n for n in names if re.match(r'xl/worksheets/sheet\d+\.xml$', n)),
                    key=lambda n: int(re.search(r'(\d+)\.xml$', n).group(1)))
    out = []
    for name in sheets:
        xml = _read_member(zf, name)
        for cm in re.finditer(r'<c\b([^>]*?)(?:/>|>(.*?)</c>)', xml, flags=re.S):
            attrs = cm.group(1)
            body = cm.group(2) or ''
            t = re.search(r'\bt="([^"]+)"', attrs)
            kind = t.group(1) if t else 'n'
            if kind == 's':
                v = re.search(r'<v>\s*(\d+)\s*</v>', body)
                if v:
                    idx = int(v.group(1))
                    if 0 <= idx < len(shared):
                        out.append(shared[idx])
            elif kind == 'inlineStr':
                parts = re.findall(r'<t\b[^>]*>(.*?)</t>', body, flags=re.S)
                if parts:
                    out.append(html.unescape(''.join(parts)))
            elif kind == 'str':
                v = re.search(r'<v>(.*?)</v>', body, flags=re.S)
                if v:
                    out.append(html.unescape(v.group(1)))
            # numeric and other cells are not required to become prose
            out.append('\n')
        out.append('\n\n')
    return ''.join(out)


def _read_member(zf, name):
    try:
        info = zf.getinfo(name)
        if info.file_size > ZIP_MEMBER_CAP:
            return ''
        return zf.read(name).decode('utf-8', errors='replace')
    except (KeyError, RuntimeError, zipfile.BadZipFile, OSError, ValueError):
        return ''


def zip_text(data, ext):
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except (zipfile.BadZipFile, OSError, ValueError):
        raise ReadError('cannot read input: not a readable zip archive')
    with zf:
        names = zf.namelist()
        pieces = []
        if ext in ('.docx', '.docm'):
            if 'word/document.xml' in names:
                pieces.append(markup_to_text(_read_member(zf, 'word/document.xml'), DOCX_BLOCK,
                                             deleted=frozenset(['instrtext', 'deltext', 'del'])))
        elif ext in ('.pptx', '.pptm'):
            slides = sorted((n for n in names if re.match(r'ppt/slides/slide\d+\.xml$', n)),
                            key=lambda n: int(re.search(r'(\d+)\.xml$', n).group(1)))
            for n in slides:
                pieces.append(markup_to_text(_read_member(zf, n), DOCX_BLOCK))
        elif ext in ('.xlsx', '.xlsm'):
            pieces.append(xlsx_text(zf, names))
        elif ext in ('.odt', '.odp', '.ods'):
            if 'content.xml' in names:
                pieces.append(markup_to_text(_read_member(zf, 'content.xml'), ODF_BLOCK,
                                             skip=frozenset(['annotation', 'script', 'style'])))
        elif ext == '.epub':
            chapters = sorted(n for n in names
                              if n.lower().endswith(('.xhtml', '.html', '.htm'))
                              and 'nav' not in n.lower().rsplit('/', 1)[-1])
            for n in chapters:
                pieces.append(markup_to_text(_read_member(zf, n), XHTML_BLOCK, skip=XHTML_SKIP))
    return '\n\n'.join(pieces)


def notebook_text(data):
    # spec: N-000271, N-000272, N-000288..N-000290
    try:
        nb = json.loads(decode_text(data))
    except ValueError:
        return ''
    if not isinstance(nb, dict):
        return ''
    cells = nb.get('cells')
    if not isinstance(cells, list):
        return ''
    parts = []
    for cell in cells:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source', '')
        if isinstance(src, list):
            if not all(isinstance(x, str) for x in src):
                return ''
            src = ''.join(src)
        elif not isinstance(src, str):
            return ''
        parts.append(src.strip())
    return '\n\n'.join(p for p in parts if p)


def extract(data, ext):
    """Extracted prose for a file body with its (lower-case) extension."""
    if ext in BINARY_EXTS:
        return ''  # spec: N-000282..N-000285 (not among the twenty formats)
    if ext in NOTEBOOK_EXTS:
        return notebook_text(data)
    if ext in ZIP_EXTS:
        return zip_text(data, ext)
    return decode_text(data)  # plain text, and unknown extensions read as plain text


def normalize_extracted(text):
    """Line structure of extracted prose: no per-line padding, paragraphs as blank lines."""
    lines = [re.sub(r'[ \t]+', ' ', ln).strip(' ') for ln in text.split('\n')]
    text = '\n'.join(lines)
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text


def load_path(path):
    try:
        with open(path, 'rb') as fh:
            data = fh.read()
    except OSError as exc:
        reason = exc.strerror or exc.__class__.__name__
        raise ReadError('cannot read input: %s: %s' % (path, reason))
    ext = _ext_of(path)
    text = extract(data, ext)
    if ext in ZIP_EXTS or ext in NOTEBOOK_EXTS:
        text = normalize_extracted(text).strip()
    return text


def _ext_of(path):
    base = path.replace('\\', '/').rsplit('/', 1)[-1]
    dot = base.rfind('.')
    return base[dot:].lower() if dot > 0 else ''


def load_stdin():
    try:
        data = sys.stdin.buffer.read()
    except (OSError, ValueError):
        return ''
    return decode_text(data)


# ---------------------------------------------------------------------------
# Masking of regions that generate no findings (FP-01)
# ---------------------------------------------------------------------------

FENCE_OPEN_RE = re.compile(r'^ {0,3}(`{3,}|~{3,})')
BLOCKQUOTE_RE = re.compile(r'^ {0,3}>')
BADGE_LINE_RE = re.compile(r'^\s*(?:\[!\[[^\]\n]*\]\([^)\n]*\)\]\([^)\n]*\)\s*)+$')
INLINE_CODE_RE = re.compile(r'(`+)(?!`)(.+?)(?<!`)\1(?!`)')


def mask_excluded(window):
    """Blank fenced code, front matter, blockquote runs, table rows and badge lines;
    replace inline code spans with underscores. Blanked lines stay as empty lines."""
    # spec: N-000149 (no findings from code, quotes, tables, badges, front matter)
    lines = window.split('\n')
    n = len(lines)
    blank = [False] * n
    if n > 1 and lines[0].strip() == '---':
        for j in range(1, n):
            if lines[j].strip() == '---':
                for k in range(0, j + 1):
                    blank[k] = True
                break
    i = 0
    while i < n:
        if blank[i]:
            i += 1
            continue
        m = FENCE_OPEN_RE.match(lines[i])
        if m:
            fence = m.group(1)
            close_re = re.compile(r'^ {0,3}' + re.escape(fence[0]) + '{%d,}[ \t]*$' % len(fence))
            blank[i] = True
            j = i + 1
            while j < n and not close_re.match(lines[j]):
                blank[j] = True
                j += 1
            if j < n:
                blank[j] = True
            i = j + 1
            continue
        i += 1
    run = []
    for i in range(n + 1):
        is_quote = i < n and not blank[i] and BLOCKQUOTE_RE.match(lines[i]) is not None
        if is_quote:
            run.append(i)
        else:
            if len(run) >= 2:
                for k in run:
                    blank[k] = True
            run = []
    for i in range(n):
        if blank[i]:
            continue
        ln = lines[i]
        if ln.lstrip().startswith('|') and ln.count('|') >= 2:
            blank[i] = True
        elif BADGE_LINE_RE.match(ln):
            blank[i] = True
    out = []
    for i, ln in enumerate(lines):
        out.append('' if blank[i] else INLINE_CODE_RE.sub(lambda m: '_' * len(m.group(0)), ln))
    return '\n'.join(out)


# ---------------------------------------------------------------------------
# Context for the catalogue rules
# ---------------------------------------------------------------------------

WORD_RE = re.compile(r"(?:[^\W_]|['\u2019\-])+")
ALNUM_RE = re.compile(r'[^\W_]')
SENT_RE = re.compile(r"(?:[^.!?\n]|[.!?](?=\S))+[.!?]*")


class Ctx(object):
    def __init__(self, masked, truncated=False):
        self.M = masked
        self.truncated = truncated
        self.lines = []  # (start, end, text)
        pos = 0
        for ln in masked.split('\n'):
            self.lines.append((pos, pos + len(ln), ln))
            pos += len(ln) + 1
        self.words = [w for w in WORD_RE.findall(masked) if ALNUM_RE.search(w)]
        self.sents = []  # (start, end, word_count)
        for m in SENT_RE.finditer(masked):
            wc = sum(1 for w in WORD_RE.findall(m.group(0)) if ALNUM_RE.search(w))
            if wc:
                self.sents.append((m.start(), m.end(), wc))
        self.sent_starts = [s for s, _, _ in self.sents]
        self.paras = []  # (start, end, text)
        cur = None
        for s, e, ln in self.lines:
            if ln.strip():
                if cur is None:
                    cur = [s, e]
                else:
                    cur[1] = e
            else:
                if cur is not None:
                    self.paras.append((cur[0], cur[1], masked[cur[0]:cur[1]]))
                    cur = None
        if cur is not None:
            self.paras.append((cur[0], cur[1], masked[cur[0]:cur[1]]))
        self.para_starts = [p[0] for p in self.paras]

    def sentences_in(self, ps, pe):
        i = bisect.bisect_left(self.sent_starts, ps)
        out = []
        while i < len(self.sents) and self.sents[i][0] < pe:
            out.append(self.sents[i])
            i += 1
        return out


def excerpt(text, limit=120):
    text = re.sub(r'\s+', ' ', text).strip()
    return text if len(text) <= limit else text[:limit - 3] + '...'


def rx(pattern, flags=re.I):
    compiled = re.compile(pattern, flags)

    def run(ctx):
        return [(m.start(), m.end(), m.group(0)) for m in compiled.finditer(ctx.M)]
    return run


def rx_min(pattern, minimum, flags=re.I):
    base = rx(pattern, flags)

    def run(ctx):
        found = base(ctx)
        return found if len(found) >= minimum else []
    return run


def word_alt(words):
    """Alternation for listed words; inflections (-s, -es, -ed, -d, -ing) are the same word."""
    alts = []
    for w in words:
        w = w.lower()
        if ' ' in w:
            alts.append(r'\s+'.join(re.escape(x) for x in w.split()))
        elif w.endswith('e'):
            alts.append(re.escape(w[:-1]) + r'(?:e|es|ed|ing|s|d)?')
        else:
            alts.append(re.escape(w) + r'(?:s|es|ed|ing)?')
    return r'\b(?:' + '|'.join(alts) + r')\b'


def _sentence_openers(ctx, words):
    out = []
    for s, e, _ in ctx.sents:
        m = re.match(r'\W*([A-Za-z]+)', ctx.M[s:e])
        if m and m.group(1).lower() in words:
            out.append((s, e, m.group(0)))
    return out


# ---------------------------------------------------------------------------
# Catalogue families (FP-01)
# ---------------------------------------------------------------------------

AI_VOCAB = ['additionally', 'align with', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant', 'meticulous',
            'testament', 'underscore', 'intricate', 'intricacies', 'interplay', 'garner', 'bolster', 'foster',
            'showcase', 'emphasize', 'enduring', 'enhance', 'leverage', 'utilize', 'facilitate', 'encompass',
            'harness', 'holistic', 'paradigm', 'transformative', 'unprecedented', 'myriad', 'plethora', 'robust',
            'seamless', 'navigate', 'embark', 'craft', 'landscape', 'journey', 'realm', 'multifaceted', 'elevate',
            'empower', 'unlock']

DIALECT_RE = (r"\bgenuinely\b|\bfascinating\b|\bnuanced\b|\bthoughtfully\b|\brefreshingly\b|\bstrikingly\b"
              r"|\bcompellingly\b|\bquietly\s+(?:powerful|profound|radical)\b"
              r"|\bdeeply\s+(?:human|personal|felt|unsettling)\b|\bresonates\s+deeply\b"
              r"|\bgame[- ]changer(?:s)?\b|\bgame[- ]changing\b|\bsupercharg\w*|\bskyrocket\w*|\bturbocharg\w*"
              r"|\brevolutioni[sz]\w*|\bdouble\s+down\s+on\b|\bdive\s+deep(?:er)?\s+into\b"
              r"|\bunlock\s+(?:the\s+)?(?:power|potential|value)\b"
              r"|\btake\b[^.!?\n]{0,40}?\bto\s+the\s+next\s+level\b")

PROMO_RE = (r"\bnestled\b|\bbreathtaking\b|\bmust-visit\b|\bstunning\b|\bpicturesque\b|\bcharming\b|\bidyllic\b"
            r"|\bvibrant\s+community\b|\brich\s+cultural\s+heritage\b|\bin\s+the\s+heart\s+of\b|\bworld-class\b"
            r"|\btop-tier\b|\bunparalleled\b|\bpremier\b|\bleading\b|\besteemed\s+organi[sz]ation\b"
            r"|\bvaluable\s+asset\b|\bpassion\s+for\s+excellence\b|\bproven\s+track\s+record\b"
            r"|\bresults-oriented\b|\bwealth\s+of\s+experience\b|\bdynamic\s+team\b|\bfast-paced\s+environment\b"
            r"|\bdeeply\s+passionate\b|\bperfectly\s+situated\b|\b(?:close|tight)-knit\s+team\b"
            r"|\bI\s+am\s+excited\s+to\s+(?:apply|bring)\b|\buniquely\s+positioned\s+to\b")
IMPERATIVES = frozenset(['install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape',
                         'transform', 'reclaim', 'unlock', 'elevate', 'boost', 'say', 'imagine', 'explore',
                         'meet', 'introducing', 'upgrade', 'claim', 'unleash', 'supercharge', 'level', 'stop',
                         'start'])

SIMPLE_YET_RE = r"\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b"

ADJ_SUFFIX_RE = re.compile(r'(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$', re.I)
STOCK_ADJ = frozenset(['powerful', 'seamless', 'robust', 'innovative', 'elegant', 'intuitive', 'scalable',
                       'reliable', 'secure', 'fast', 'modern', 'dynamic', 'vibrant', 'comprehensive',
                       'cutting-edge', 'efficient', 'simple', 'beautiful', 'stunning', 'exceptional', 'unique',
                       'rich', 'bold', 'fresh', 'smart', 'clean'])
ADJ_CHAIN_RE = re.compile(r"\b([A-Za-z][A-Za-z'-]*),\s+([A-Za-z][A-Za-z'-]*),\s+([A-Za-z][A-Za-z'-]*)"
                          r"(?:,\s+|,?\s+and\s+)([A-Za-z][A-Za-z'-]*)\b")

SYNONYM_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]

HEDGES_RE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems? to|seems? like"
                       r"|appears? to|somewhat|relatively|fairly|kind of|sort of)\b")
WRITTEN_OUT_RE = re.compile(r"\b(?:do not|does not|did not|is not|are not|was not|were not|will not|cannot"
                            r"|can not|would not|should not|could not|have not|has not|had not|I am|I have"
                            r"|I will|I would|we are|we have|we will|it is|that is|there is|they are|let us"
                            r"|you are)\b", re.I)
CONTRACTED_RE = re.compile(r"\b(?:I'm|I've|I'll|I'd|we're|we've|we'll|don't|doesn't|didn't|isn't|aren't"
                           r"|wasn't|weren't|won't|can't|couldn't|shouldn't|wouldn't|haven't|hasn't|hadn't"
                           r"|it's|that's|there's|they're|you're|let's)\b", re.I)
FIRST_PERSON_RE = re.compile(r"\b(?:I|we|we're|my|our|me|us)\b", re.I)
EMOJI_RE = re.compile('[\U0001F000-\U0001FAFF\u2600-\u27BF\U0001F1E6-\U0001F1FF]')
MINOR_WORDS = frozenset(['a', 'an', 'the', 'and', 'but', 'or', 'nor', 'for', 'so', 'yet', 'at', 'by', 'in',
                         'of', 'on', 'to', 'up', 'as', 'with', 'from', 'into', 'over'])
PARA_SPLIT_LIST_RE = re.compile(r'^\s*(?:[-*+]|\d+[.)])\s+')
HEADING_RE = re.compile(r'^\s{0,3}#{1,6}\s+\S')
TABLE_RE = re.compile(r'^\s*\|')


def f_ai_vocab(ctx):
    return rx(r'(?:' + word_alt(AI_VOCAB) + r'|\bcapture\s+the\s+(?:essence|spirit|imagination|heart|magic)\b)')(ctx)


def f_model_dialect(ctx):
    return rx_min(DIALECT_RE, 2)(ctx)


def f_promotional(ctx):
    found = rx(PROMO_RE)(ctx)
    openers = _sentence_openers(ctx, IMPERATIVES)
    if len(openers) >= 3:
        found = found + openers
    return found


def f_adjective_chains(ctx):
    out = []
    for m in ADJ_CHAIN_RE.finditer(ctx.M):
        words = [m.group(i) for i in range(1, 5)]
        if any(ADJ_SUFFIX_RE.search(w) or w.lower() in STOCK_ADJ for w in words):
            out.append((m.start(), m.end(), m.group(0)))
    return out


def f_synonym_cycling(ctx):
    out = []
    for cluster in SYNONYM_CLUSTERS:
        hits = []
        present = set()
        for member in cluster:
            pat = re.compile(r"\b" + r"\s+".join(re.escape(x) for x in member.split()) + r"(?:s|es)?\b", re.I)
            found = [(m.start(), m.end(), m.group(0)) for m in pat.finditer(ctx.M)]
            if found:
                present.add(member)
                hits.extend(found)
        if len(present) >= 3:
            out.extend(hits)
    return out


def f_significance(ctx):
    return rx(r"\b(?:stands?|serves?|stood|served)\s+as\s+an?\s+(?:testament|reminder|symbol|beacon|cornerstone"
              r"|bridge|gateway|hallmark)\b"
              r"|\b(?:underscor\w*|highlight\w*)\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring"
              r"|central|vital|crucial|pivotal|key)\b"
              r"|\breflects?\s+a\s+broader\s+(?:trend|shift|pattern)\b"
              r"|\bmarks?\s+a\s+(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)\b"
              r"|\bsymboli[sz]\w*\b|\bsets?\s+the\s+stage\s+for\b|\bleft\s+an\s+indelible\s+mark\b"
              r"|\bplays?\s+a\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b"
              r"|\bhas\s+(?:shaped|sparked)\b|\bhas\s+come\s+to\s+(?:define|symboli[sz]e)\b")(ctx)


def f_notability(ctx):
    return rx(r"\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+"
              r"[^.!?\n]{0,60}?(?-i:[A-Z][\w&.'-]*)(?:,\s+|\s+and\s+)(?-i:[A-Z][\w&.'-]*)"
              r"|\b\d[\d,.]*\s*[KkMm]?\s+followers\b"
              r"|\b(?:strong|active)\s+(?:online|digital|social[- ]media)\s+presence\b"
              r"|\bwidely\s+covered\b|\bindependent\s+coverage\b")(ctx)


def f_vague_attributions(ctx):
    return rx(r"\bexperts?\s+(?:argue|believe|say|claim|note|suggest)\b|\bindustry\s+(?:reports|observers|analysts)\b"
              r"|\bobservers\s+(?:have\s+)?(?:cited|noted)\b|\bsome\s+critics\s+argue\b"
              r"|\bresearchers\s+have\s+found\b|\bstudies\s+suggest\b|\bit\s+is\s+widely\s+believed\b")(ctx)


def f_title_proper_noun(ctx):
    return rx(r"\bthe\s+(?:List|Index|Compilation|Collection|Catalogue|Guide|Overview)\s+of\s+"
              r"(?-i:[A-Z])[^.!?\n]{0,80}?\s(?:is|are)\s+(?:a|an|the)\b")(ctx)


def f_conservation(ctx):
    return rx(r"\bplays?\s+a\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b"
              r"|\bconservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)\b"
              r"|\bserves?\s+as\s+an?\s+indicator\s+species\b|\bcontributes?\s+to\s+biodiversity\b")(ctx)


def f_false_ranges(ctx):
    return rx(r"\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]*?"
              r"\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b"
              r"|\bfrom\s+(?:the\s+)?humble\b[^.!?\n]*?\bto\s+(?:the\s+)?(?:mighty|towering|grand|sprawling)\b")(ctx)


def f_ing_tails(ctx):
    return rx(r",\s+(?:highlighting|reflecting|symboli[sz]ing|emphasi[sz]ing|underscoring|showcasing|fostering"
              r"|cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|indicating"
              r"|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b")(ctx)


def f_tailing_negation(ctx):
    return rx(r",\s+no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b")(ctx)


def f_negative_parallelism(ctx):
    return rx(r"\bit[\u2019']s\s+not\s+(?:just|merely)\s+(?:about|a|an)\b"
              r"|\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b"
              r"|\bdoesn[\u2019']t\s+just\b[^.!?\n,]{0,40}?\bit\b")(ctx)


def f_not_x_just_y(ctx):
    return rx(r"\b(?:no|not)\s+\w+,\s+(?:just|only|simply)\s+\w+"
              r"|\b(?:not|isn[\u2019']t|aren[\u2019']t|wasn[\u2019']t|weren[\u2019']t)\s+(?:just|merely)\s+"
              r"(?:a|an|the)\s+\w+,?\s*(?:\u2014|\u2013|-|,)?\s*"
              r"(?:it[\u2019']s|it\s+is|it\s+was|they[\u2019']re|they\s+are|they\s+were|that[\u2019']s|but)\b")(ctx)


FILLER_RE = (r"\bin\s+order\s+to\b|\bdue\s+to\s+the\s+fact\s+that\b|\bat\s+this\s+point\s+in\s+time\b"
             r"|\bin\s+the\s+event\s+that\b|\bhas\s+the\s+ability\s+to\b|\bit\s+is\s+important\s+to\s+note\s+that\b"
             r"|\bit\s+should\s+be\s+mentioned\s+that\b|\bneedless\s+to\s+say\b")


def f_empty_pivots(ctx):
    return rx(r"\bit[\u2019']s\s+worth\s+(?:noting|mentioning)\s+that\b|\bit\s+bears\s+(?:noting|mentioning)\s+that\b"
              r"|\bone\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is\b|\bit\s+is\s+interesting\s+to\s+note\s+that\b"
              r"|\ba\s+key\s+consideration\s+is\b|\ba\s+point\s+to\s+highlight\s+is\b")(ctx)


def f_outcome_tails(ctx):
    return rx(r",\s+(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about"
              r"|with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for"
              r"|signaling\s+a\s+shift\s+toward)\b")(ctx)


def f_editorial(ctx):
    return rx(r"\bit[\u2019']?s?\s+(?:is\s+)?important\s+to\s+(?:remember|note|understand|recognize)\b"
              r"|\bone\s+must\s+note\s+that\b|\bit\s+is\s+worth\s+pointing\s+out\b"
              r"|\bit\s+cannot\s+be\s+overstated\s+that\b|\bit\s+must\s+be\s+emphasized\s+that\b")(ctx)


def f_self_thorough(ctx):
    return rx(r"\bthis\s+(?:comprehensive|complete)\s+(?:guide|overview|analysis)\b"
              r"|\bthis\s+in-depth\s+(?:analysis|look|examination)\b|\ba\s+thorough\s+examination\s+of\b"
              r"|\beverything\s+you\s+need\s+to\s+know\s+about\b")(ctx)


def f_question_answer(ctx):
    return rx(r"(?-i:\b(?:Is|Are|Do|Does|Did|Can|Could|Will|Would|Should|Has|Have|Was|Were|May|Might|Must)\b)"
              r"[^.?!\n]{0,80}\?\s+(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)[.!]", flags=0)(ctx)


def f_concrete_evidence(ctx):
    return rx(r"\bwithout\s+concrete\s+(?:evidence|proof)\b|\bdo\s+you\s+have\s+concrete\s+(?:evidence|proof)\b"
              r"|\bI\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples|proof)\s+to\b"
              r"|\babsent\s+concrete\s+(?:proof|evidence)\b|\bprovide\s+concrete\s+(?:evidence|proof)\b")(ctx)


def f_intro_hooks(ctx):
    return rx(r"\bin\s+today[\u2019']s\s+(?:\w+\s+){0,2}?(?:world|landscape|environment|market)\b"
              r"|\bin\s+a\s+world\s+where\b|\bin\s+an\s+era\s+of\b|\bin\s+recent\s+years,"
              r"|\bmore\s+than\s+ever\s+before\b|\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b"
              r"|\b(?:great|exciting|big)\s+news\b(?=\s*[!:])"
              r"|\bever\s+(?:wanted|wondered|dreamed|wished)\b[^.!?\n]{0,80}\?"
              r"|\bin\s+an\s+(?:increasingly\s+)?(?:interconnected|digital|competitive|complex)\s+world\b")(ctx)


def f_diff_anchored(ctx):
    return rx(r"\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b"
              r"|\b(?:the|this)\s+(?:latest\s+|new\s+)?(?:update|release|version|change|patch|design)\s+"
              r"(?:adds|introduces|brings|delivers|includes|provides|improves)\b"
              r"|\b(?:has|have)\s+been\s+(?:updated|refactored|improved|enhanced)\b|\b(?:has|have)\s+been\s+changed\s+to\b"
              r"|\bpreviously\b[^.!?\n]{0,200}?\bnow\b"
              r"|\bwas(?:n[\u2019']t|\s+not)\s+there\s+before\b|\bwere(?:n[\u2019']t|\s+not)\s+there\s+before\b"
              r"|\bwe(?:[\u2019']ve|\s+have)\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b")(ctx)


def f_signposting(ctx):
    return rx(r"\blet[\u2019']s\s+(?:dive|delve|explore)\b|\blet[\u2019']s\s+break\s+(?:this|it)\s+down\b"
              r"|\bhere[\u2019']s\s+what\s+you\s+need\s+to\s+know\b|\bwithout\s+further\s+ado\b"
              r"|\bnow\s+let[\u2019']s\s+look\s+at\b|\bbuckle\s+up\b|\bstay\s+with\s+me\b"
              r"|\bready\s+to\s+dive\s+in\b")(ctx)


def f_cataloguing(ctx):
    return rx(r"\b(?:used|uses|employs?|employed|relied\s+on|utili[sz]es?)\s+(?:several|various|a\s+number\s+of"
              r"|multiple|different|many|numerous)\s+\w+"
              r"|(?:^|(?<=[.!?])\s+|\n\s*)These\s+(?:\w+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help)"
              r"\s+(?:information|insight|understanding|details|data)\b"
              r"|\b(?:is|are|was|were|remains|becomes)\s+(?:the\s+|a\s+)?(?:language|currency|architecture|heartbeat"
              r"|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b")(ctx)


def f_inline_header_lists(ctx):
    return rx(r"^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?(?:\*\*[^*\n]+:\*\*|\*\*[^*\n]+\*\*:)", flags=re.M)(ctx)


def f_mid_essay_bullets(ctx):
    if any(HEADING_RE.match(ln) for _, _, ln in ctx.lines):
        return []
    lists, prose = [], 0
    for ps, pe, text in ctx.paras:
        lns = [ln for ln in text.split('\n') if ln.strip()]
        if lns and all(PARA_SPLIT_LIST_RE.match(ln) for ln in lns):
            lists.append((ps, pe, text))
        else:
            prose += 1
    if lists and prose >= 2:
        return [(s, e, t) for s, e, t in lists]
    return []


def f_fragmented_headers(ctx):
    out = []
    for i, (s, e, ln) in enumerate(ctx.lines):
        if not HEADING_RE.match(ln):
            continue
        j = i + 1
        while j < len(ctx.lines) and not ctx.lines[j][2].strip():
            j += 1
        if j >= len(ctx.lines):
            continue
        ns, ne, nxt = ctx.lines[j]
        text = nxt.strip()
        if not text or HEADING_RE.match(nxt) or PARA_SPLIT_LIST_RE.match(nxt) or TABLE_RE.match(nxt):
            continue
        if len(text.split()) > 4:
            continue
        head_words = set(w.lower() for w in re.findall(r'[A-Za-z]{3,}', ln))
        body_words = set(w.lower() for w in re.findall(r'[A-Za-z]{3,}', text))
        if head_words & body_words:
            out.append((ns, ne, text))
    return out


def f_formulaic_challenges(ctx):
    return rx(r"\bdespite\s+(?:these|its|the)\s+(?:challenges|obstacles)\b"
              r"|\bchallenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)\b"
              r"|\bcontinues\s+to\s+thrive\b|\btypical\s+of\s+(?:emerging|urban|modern)\b"
              r"|\bfaces?\s+(?:several|many|numerous)\s+challenges\b")(ctx)


TRANSITION_RE = re.compile(r"(?:^|(?<=[.!?])\s+|(?<=\n)[ \t]*)(?-i:(Additionally|Furthermore|Moreover|However"
                           r"|Nevertheless|Consequently|Subsequently|Notably))\b", re.M)


def f_transition_clusters(ctx):
    out = []
    for ps, pe, text in ctx.paras:
        found = [(ps + m.start(1), ps + m.end(1), m.group(1)) for m in TRANSITION_RE.finditer(text)]
        if len(found) >= 2:
            out.extend(found)
    return out


def f_compulsive_conclusions(ctx):
    return rx(r"^[ \t]*(?:in\s+conclusion|overall|in\s+summary|to\s+summari[sz]e|to\s+conclude|all\s+in\s+all"
              r"|in\s+essence|ultimately)\b", flags=re.I | re.M)(ctx)


def f_generic_conclusions(ctx):
    return rx(r"\bthe\s+future\s+looks\s+bright\b|\bexciting\s+times\s+lie\s+ahead\b|\bjourney\s+toward\s+excellence\b"
              r"|\bstep\s+in\s+the\s+right\s+direction\b|\b(?:the\s+)?(?:outlook|future)\s+(?:for\s+[\w\s]{1,40}?\s+)?"
              r"(?:is|looks|remains)\s+bright\b"
              r"|\bwell[- ]positioned\s+for\s+(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)\b")(ctx)


def _cv(values):
    if len(values) < 2:
        return None
    mean = sum(values) / float(len(values))
    if mean <= 0:
        return None
    var = sum((v - mean) ** 2 for v in values) / float(len(values))
    return (var ** 0.5) / mean


def f_sentence_monotony(ctx):
    if len(ctx.sents) < 3:
        return []
    cv = _cv([wc for _, _, wc in ctx.sents])
    if cv is not None and cv < 0.35:
        s, e, _ = ctx.sents[0]
        return [(0, 0, ctx.M[s:e])]
    return []


def f_mechanical_alternation(ctx):
    lengths = [wc for _, _, wc in ctx.sents]
    if len(lengths) < 6:
        return []
    run = 0
    best = 0
    for i in range(1, len(lengths) - 1):
        a, b, c = lengths[i - 1], lengths[i], lengths[i + 1]
        up1, up2 = b > a, c > b
        big = abs(b - a) >= 4 and abs(c - b) >= 4
        if up1 != up2 and big and b != a and c != b:
            run += 1
            best = max(best, run)
        else:
            run = 0
    if best >= 4:
        s, e, _ = ctx.sents[0]
        return [(0, 0, ctx.M[s:e])]
    return []


def f_opener_repetition(ctx):
    out = []
    for ps, pe, _ in ctx.paras:
        sents = ctx.sentences_in(ps, pe)
        if len(sents) < 3:
            continue
        openers = {}
        for s, e, _ in sents:
            words = [w.lower() for w in WORD_RE.findall(ctx.M[s:e])][:2]
            if len(words) == 2:
                openers.setdefault(tuple(words), []).append((s, e, ctx.M[s:e]))
        for key, items in openers.items():
            if len(items) >= 3:
                out.extend(items)
    return out


def f_uniform_paragraphs(ctx):
    counts = []
    for _, _, text in ctx.paras:
        if HEADING_RE.match(text) or PARA_SPLIT_LIST_RE.match(text):
            continue
        counts.append(len(WORD_RE.findall(text)))
    if len(counts) < 4:
        return []
    cv = _cv(counts)
    if cv is not None and cv < 0.4:
        return [(0, 0, ctx.paras[0][2])]
    return []


def f_semicolon_underuse(ctx):
    if len(ctx.words) < 300:
        return []
    if ';' in ctx.M or ctx.M.count('(') > 1:
        return []
    return [(0, 0, 'no semicolon and at most one parenthetical')]


def f_chatbot_artifacts(ctx):
    return rx(r"\bI\s+hope\s+this\s+helps\b|\bCertainly!|\bOf\s+course!|\blet\s+me\s+know\s+if\s+you\b"
              r"|\bwould\s+you\s+like\s+me\s+to\b|\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b"
              r"|\bhappy\s+to\s+help\s*[.!](?=\s|$)|\b(?:here|below)\s+is\s+(?:a|an|the)\s+"
              r"(?:overview|summary|rundown|recap|brief)\b"
              r"|\bhere\s+(?:are|[\u2019']s)\s+(?:(?:a\s+few|some|two|three)\s+)?(?:options|drafts|versions|variations)\b"
              r"|\bhere\s+(?:is|[\u2019']s)\s+a\s+draft\b|\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b"
              r"|\bI\s+hope\s+(?:this\s+email\s+)?finds\s+you\s+well\b"
              r"|\bas\s+an\s+(?:AI\s+language\s+model|large\s+language\s+model|AI\s+assistant|AI|LLM|language\s+model)\b"
              r"|\bto\s+(?:answer|address)\s+your\s+question\b|\bin\s+(?:response|answer)\s+to\s+your\s+question\b"
              r"|\byour\s+question\s+(?:about|regarding|concerning)\b|\bas\s+(?:you\s+)?(?:requested|asked),?\s+here\b"
              r"|\bhere\s+is\s+(?:the\s+)?(?:draft|first\s+pass|revised\s+version)\s+(?:of|for\s+your)\b",
              flags=0)(ctx)


def f_sycophancy(ctx):
    return rx(r"\byou(?:[\u2019']re|\s+are)\s+absolutely\s+right\b"
              r"|\b(?:great|excellent|good|fantastic|wonderful|thoughtful|brilliant)\s+(?:question|point)\s*[!.,]"
              r"|\bwhat\s+a\s+(?:thoughtful|great|wonderful|fantastic)\s+question\b"
              r"|\bthat[\u2019']s\s+a\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\b")(ctx)


def f_knowledge_cutoff(ctx):
    return rx(r"\bas\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)\b|\bup\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)\b"
              r"|\bwhile\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+(?:extensively|widely)\s+documented)\b"
              r"|\bbased\s+on\s+(?:the\s+)?available\s+information\b|\bas\s+of\s+my\s+(?:knowledge\s+)?cutoff\b"
              r"|\bmaintains\s+a\s+low\s+profile\b|\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b")(ctx)


def f_copula_avoidance(ctx):
    return rx(r"\b(?:serves|stands|functions|acts)\s+as\b|\brepresents\s+(?:a|the)\b|\bmarks\s+(?:a|the)\b"
              r"|\bboasts\b|\bfeatures\s+(?:a|an|the|\d[\d,]*|several|many|numerous|multiple|one|two|three|four"
              r"|five|six|seven|eight|nine|ten)\b|\boffers\s+a\b|\brefers?\s+to\b")(ctx)


def f_hedge_stacking(ctx):
    out = []
    for s, e, _ in ctx.sents:
        hits = list(HEDGES_RE.finditer(ctx.M[s:e]))
        if len(hits) >= 2:
            out.extend((s + h.start(), s + h.end(), h.group(0)) for h in hits)
    return out


def f_contraction_absence(ctx):
    first_person = len(FIRST_PERSON_RE.findall(ctx.M))
    if first_person < 5 or not ctx.words or first_person / float(len(ctx.words)) < 0.02:
        return []
    written = [(m.start(), m.end(), m.group(0)) for m in WRITTEN_OUT_RE.finditer(ctx.M)]
    contracted = len(CONTRACTED_RE.findall(ctx.M))
    if len(written) < 3:
        return []
    if contracted / float(len(written) + contracted) < 0.25:
        return written
    return []


def f_boldface(ctx):
    found = rx(r"\*\*[^*\n]+\*\*")(ctx)
    return found if len(found) >= 3 else []


def f_emojis(ctx):
    return [(m.start(), m.end(), m.group(0)) for m in EMOJI_RE.finditer(ctx.M)]


def f_em_dash(ctx):
    out = []
    for ps, pe, text in ctx.paras:
        hits = [(ps + m.start(), ps + m.end(), m.group(0)) for m in re.finditer('\u2014', text)]
        if len(hits) >= 2:
            out.extend(hits)
    return out


def f_title_case(ctx):
    out = []
    for s, e, ln in ctx.lines:
        m = HEADING_RE.match(ln)
        if not m:
            continue
        heading = ln.strip().lstrip('#').strip()
        if not heading or not re.match(r'[A-Za-z]', heading):
            continue
        words = [w for w in re.findall(r"[A-Za-z][A-Za-z'\u2019-]*", heading)]
        if len(words) < 3 or heading.isupper():
            continue
        major = [w for w in words if w.lower() not in MINOR_WORDS]
        if len(major) >= 2 and all(w[0].isupper() for w in major):
            out.append((s, e, heading))
    return out


def f_curly_quotes(ctx):
    return rx('[\u2018\u2019\u201c\u201d]', flags=0)(ctx)


YEAR_RANGE_RE = re.compile(r'\b(\d{4})-(\d{4})\b')


def f_hyphen_en_dash(ctx):
    out = []
    for m in YEAR_RANGE_RE.finditer(ctx.M):
        a, b = int(m.group(1)), int(m.group(2))
        if a < b and 1000 <= a and b <= 2999:
            out.append((m.start(), m.end(), m.group(0)))
    return out


PLACEHOLDER_BRACKET_RE = re.compile(r'\[([^\[\]\n]{1,80})\](?![(\[])')
PLACEHOLDER_OPEN_RE = re.compile(r'\s*(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b', re.I)
PLACEHOLDER_SLOT_WORDS_RE = re.compile(r'\b(?:name|company|client|place|source)\b', re.I)
PLACEHOLDER_CAPS_RE = re.compile(r'[A-Z][A-Z0-9 _]{2,40}')


def f_placeholder(ctx):
    out = []
    for m in PLACEHOLDER_BRACKET_RE.finditer(ctx.M):
        inner = m.group(1)
        if PLACEHOLDER_OPEN_RE.match(inner):
            out.append((m.start(), m.end(), m.group(0)))
        elif len(inner.split()) <= 4 and PLACEHOLDER_SLOT_WORDS_RE.search(inner):
            out.append((m.start(), m.end(), m.group(0)))
        elif PLACEHOLDER_CAPS_RE.fullmatch(inner.strip()):
            out.append((m.start(), m.end(), m.group(0)))
    for m in re.finditer(r'\{\{[^{}\n]*\}\}', ctx.M):
        out.append((m.start(), m.end(), m.group(0)))
    for m in re.finditer(r'(?<![A-Za-z])[xX]{3,}(?![A-Za-z])', ctx.M):
        out.append((m.start(), m.end(), m.group(0)))
    for m in re.finditer(r'\blorem\s+ipsum\b', ctx.M, flags=re.I):
        out.append((m.start(), m.end(), m.group(0)))
    return out


CHAT_MARKUP_RE = re.compile(r'\bcite(?:turn|start|nav)\w*|\boai_citation\w*|\bcontentReference\b|\bnavlist\b'
                            '|\u3010\\d+\u2020[^\u3011\n]*\u3011', re.I)
UTM_SOURCE_RE = re.compile(r'utm_source=((?:[A-Za-z0-9-]+\.)*[A-Za-z0-9-]+)', re.I)
AI_HOSTS = frozenset(['chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai', 'gemini.google.com',
                      'copilot.microsoft.com', 'poe.com'])


def f_chat_markup(ctx):
    return [(m.start(), m.end(), m.group(0)) for m in CHAT_MARKUP_RE.finditer(ctx.M)]


def f_ai_tracking(ctx):
    out = []
    for m in UTM_SOURCE_RE.finditer(ctx.M):
        if m.group(1).lower() in AI_HOSTS:
            out.append((m.start(), m.end(), m.group(0)))
    return out


def f_homoglyphs(ctx):
    out = []
    for m in TOKEN_RE.finditer(ctx.M):
        if homoglyph_count(m.group(0)):
            out.append((m.start(), m.end(), m.group(0)))
    return out


def f_nonstandard_spaces(ctx):
    _, spaces = scan_chars(ctx.M)
    return [(i, i + 1, '\\u%04x' % ord(ctx.M[i])) for i in spaces]


def f_invisible(ctx):
    invis, _ = scan_chars(ctx.M)
    return [(i, i + 1, '\\u%04x' % ord(ctx.M[i])) for i in invis]


def f_trailing_whitespace(ctx):
    out = []
    last = len(ctx.lines) - 1
    for i, (s, e, ln) in enumerate(ctx.lines):
        if ctx.truncated and i == last:
            continue  # the window cut the last line; its end is not the document's end
        m = re.search(r'[ \t]+$', ln)
        if m:
            out.append((s + m.start(), s + m.end(), ln[m.start():m.end()]))
    tail_start = len(ctx.M.rstrip(' \t\n'))
    tail = ctx.M[tail_start:]
    # A truncated scan ends at the window, not at the end of the document.
    if not ctx.truncated and tail and (' ' in tail or '\t' in tail or tail.count('\n') >= 2):
        out.append((tail_start, len(ctx.M), 'end of text'))
    lead = len(ctx.M) - len(ctx.M.lstrip(' \t\n'))
    if lead:
        out.append((0, lead, 'start of text'))
    return out


def f_marketing_slop(ctx):
    return rx(r"\bunlocking\s+(?:its\s+|your\s+|the\s+)?full\s+potential\b|\bnavigating\s+the\s+complexities\b"
              r"|\ba\s+testament\s+to\s+the\s+(?:power|importance)\s+of\b|\bstaying\s+ahead\s+of\s+the\s+curve\b"
              r"|\bturning\s+challenges\s+into\s+opportunities\b|\bharnessing\s+the\s+power\s+of\b"
              r"|\bpaving\s+the\s+way\s+for\b|\bsaying\s+goodbye\s+to\b|\bimagining\s+a\s+world\s+where\b")(ctx)


def f_decorative_rules(ctx):
    found = rx(r"^[ \t]*(?:-{3,}|\*{3,}|_{3,})[ \t]*$", flags=re.M)(ctx)
    return found if len(found) >= 3 and len(ctx.lines) >= 24 else []


def f_degenerate(ctx):
    words = [w.lower() for w in WORD_RE.findall(ctx.M)]
    if len(words) < 30:
        return []
    grams = [tuple(words[i:i + 6]) for i in range(len(words) - 5)]
    counts = {}
    for g in grams:
        counts[g] = counts.get(g, 0) + 1
    repeated = sum(c for c in counts.values() if c > 1)
    if repeated and repeated / float(len(grams)) >= 0.2:
        top = max(counts.items(), key=lambda kv: kv[1])[0]
        return [(0, 0, ' '.join(top))] * repeated
    return []


# Character layer (FP-01 metrics, FP-03 cleanup) --------------------------------

TOKEN_RE = re.compile(r'\S+')
RTL_RE = re.compile('[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufefc]')
JOIN_RE = re.compile('[\u0590-\u08ff\u0900-\u0dff\u1000-\u109f\u1780-\u17ff\ufb1d-\ufdff\ufe70-\ufeff]')
NOSPACE_RE = re.compile('[\u0e00-\u0eff\u1000-\u109f\u1780-\u17ff\u3000-\u30ff\u3400-\u4dbf\u4e00-\u9fff'
                        '\uf900-\ufaff\U00020000-\U0002ffff]')
CJK_RE = re.compile('[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff\U00020000-\U0002ffff]')
MONGOL_RE = re.compile('[\u1800-\u18af]')
KHMER_RE = re.compile('[\u1780-\u17ff]')
EXTRA_IGNORABLE = frozenset([0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x180B, 0x180C, 0x180D, 0x180E,
                             0x180F, 0x3164, 0xFFA0])
BIDI_CONTROLS = frozenset([0x200E, 0x200F, 0x061C, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
                           0x2066, 0x2067, 0x2068, 0x2069])

# Mixed-script lookalikes of Latin letters (catalogue 66).
HOMO_MAP = {}
for _src, _dst in [
        ('\u0430', 'a'), ('\u0441', 'c'), ('\u0501', 'd'), ('\u0435', 'e'), ('\u04bb', 'h'), ('\u0456', 'i'),
        ('\u0458', 'j'), ('\u043e', 'o'), ('\u0440', 'p'), ('\u0455', 's'), ('\u051d', 'w'), ('\u0445', 'x'),
        ('\u0443', 'y'), ('\u0475', 'v'), ('\u0410', 'A'), ('\u0412', 'B'), ('\u0421', 'C'), ('\u0415', 'E'),
        ('\u041d', 'H'), ('\u0406', 'I'), ('\u0408', 'J'), ('\u041a', 'K'), ('\u041c', 'M'), ('\u041e', 'O'),
        ('\u0420', 'P'), ('\u0405', 'S'), ('\u0422', 'T'), ('\u0425', 'X'), ('\u04ae', 'Y'),
        ('\u0391', 'A'), ('\u0392', 'B'), ('\u0395', 'E'), ('\u0396', 'Z'), ('\u0397', 'H'), ('\u0399', 'I'),
        ('\u039a', 'K'), ('\u039c', 'M'), ('\u039d', 'N'), ('\u039f', 'O'), ('\u03a1', 'P'), ('\u03a4', 'T'),
        ('\u03a7', 'X'), ('\u03a5', 'Y'), ('\u03bd', 'v'), ('\u03bf', 'o'), ('\u03c1', 'p'), ('\u03b9', 'i'),
        ('\u0555', 'O'), ('\u054d', 'U'), ('\u0585', 'o'), ('\u057d', 'u'), ('\u0570', 'h'), ('\u0578', 'n'),
        ('\u0581', 'g')]:
    HOMO_MAP[_src] = _dst
HOMO_CHARS_RE = re.compile('[' + ''.join(HOMO_MAP) + ']')


def is_symbol(ch):
    if not ch:
        return False
    cp = ord(ch)
    if 0x1F000 <= cp <= 0x1FAFF or 0x2600 <= cp <= 0x27BF:
        return True
    return unicodedata.category(ch) in ('So', 'Sk')


def is_candidate(ch):
    """Characters that cleanup removes unless they do a job in their position."""
    cp = ord(ch)
    if ch in '\t\n\r':
        return False
    if cp in EXTRA_IGNORABLE or 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF:
        return True
    return unicodedata.category(ch) in ('Cf', 'Cc')


def nbsp_kept(s, i):
    prev = s[i - 1] if i > 0 else ''
    nxt = s[i + 1] if i + 1 < len(s) else ''
    if prev.isdigit() or nxt.isdigit():
        return True
    if nxt and nxt in ':;!?\u00bb\u203a%\u20ac':
        return True
    if prev and prev in '\u00ab\u2039':
        return True
    return False


def invisible_kept(s, i, rtl):
    """True when an invisible-candidate character does a job at this position (FP-03)."""
    cp = ord(s[i])
    prev = s[i - 1] if i > 0 else ''
    nxt = s[i + 1] if i + 1 < len(s) else ''
    if cp == 0xAD:
        return bool(prev) and bool(nxt) and prev.isalpha() and nxt.isalpha()
    if cp in (0x200C, 0x200D):
        return any(x and (JOIN_RE.match(x) or is_symbol(x)) for x in (prev, nxt))
    if cp == 0x200B:
        return any(x and NOSPACE_RE.match(x) for x in (prev, nxt))
    if cp in BIDI_CONTROLS:
        return rtl
    if 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF:
        return (bool(prev) and (is_symbol(prev) or bool(CJK_RE.match(prev)))) or nxt == '\u20e3'
    if 0xE0020 <= cp <= 0xE007F:
        return bool(prev) and (prev == '\U0001F3F4' or is_symbol(prev) or 0xE0020 <= ord(prev) <= 0xE007F)
    if cp in (0x180B, 0x180C, 0x180D, 0x180F):
        return bool(prev) and bool(MONGOL_RE.match(prev))
    if cp in (0x17B4, 0x17B5):
        return any(x and KHMER_RE.match(x) for x in (prev, nxt))
    return False


def scan_chars(s):
    """(invisible indexes that cleanup removes, non-standard space indexes that cleanup normalizes)."""
    rtl = bool(RTL_RE.search(s))
    invis, spaces = [], []
    for i, ch in enumerate(s):
        o = ord(ch)
        if 0x20 <= o < 0x7F or ch == '\n' or ch == '\t':
            continue
        if ch in '\u2028\u2029':
            continue
        cat = unicodedata.category(ch)
        if cat == 'Zs':
            if ch == ' ':
                continue
            if ch in '\u00a0\u202f' and nbsp_kept(s, i):
                continue
            spaces.append(i)
            continue
        if is_candidate(ch) and not invisible_kept(s, i, rtl):
            invis.append(i)
    return invis, spaces


def homoglyph_count(token):
    """Number of lookalike letters in a token that mixes ASCII Latin with lookalikes only (66)."""
    nonascii = [c for c in token if ord(c) > 127 and c.isalpha()]
    if not nonascii or any(c not in HOMO_MAP for c in nonascii):
        return 0
    if not any(c.isascii() and c.isalpha() for c in token):
        return 0
    return len(nonascii)


def fold_homoglyphs(s):
    if not HOMO_CHARS_RE.search(s):
        return s
    out = []
    last = 0
    for m in TOKEN_RE.finditer(s):
        tok = m.group(0)
        if homoglyph_count(tok):
            out.append(s[last:m.start()])
            out.append(''.join(HOMO_MAP.get(c, c) for c in tok))
            last = m.end()
    out.append(s[last:])
    return ''.join(out)


def clean_text(text):
    """Scrubbed text (FP-03): invisible characters out, spaces normalized, homoglyphs folded, trimmed."""
    s = text.replace('\r\n', '\n').replace('\r', '\n')
    if s.startswith('\ufeff'):
        s = s[1:]
    ended_with_newline = s.endswith('\n')
    for _ in range(4):
        out = []
        changed = False
        rtl = bool(RTL_RE.search(s))
        for i, ch in enumerate(s):
            o = ord(ch)
            if 0x20 <= o < 0x7F or ch == '\n' or ch == '\t':
                out.append(ch)
                continue
            if ch in '\u2028\u2029':
                out.append('\n')
                changed = True
                continue
            if unicodedata.category(ch) == 'Zs':
                if ch == ' ':
                    out.append(ch)
                elif ch in '\u00a0\u202f' and nbsp_kept(s, i):
                    out.append(ch)
                else:
                    out.append(' ')
                    changed = True
                continue
            if is_candidate(ch):
                if invisible_kept(s, i, rtl):
                    out.append(ch)
                else:
                    changed = True
                continue
            out.append(ch)
        s = ''.join(out)
        if not changed:
            break
    s = fold_homoglyphs(s)
    lines = [ln.rstrip(' \t') for ln in s.split('\n')]
    body = '\n'.join(lines).strip(' \t\n')
    if body and ended_with_newline:
        body += '\n'
    return body


# Registry -----------------------------------------------------------------------

# kind: 'score' moves the score; 'advice' is reported with weight zero.
FAMILIES = [
    dict(key='1', num=1, slug='ai_vocabulary', label='AI vocabulary', kind='score', fn=f_ai_vocab),
    dict(key='2', num=2, slug='model_dialect_vocabulary', label='model-dialect vocabulary', kind='score', fn=f_model_dialect),
    dict(key='3', num=3, slug='promotional_language', label='promotional language', kind='score', fn=f_promotional),
    dict(key='4', num=4, slug='hyphenated_word_pairs', label='hyphenated word-pair overuse', kind='advice',
         fn=rx(r"\b(?:cutting-edge|state-of-the-art|best-in-class|results-driven|forward-thinking|value-added"
               r"|next-generation|top-notch|well-rounded|fast-paced|detail-oriented|team-oriented)\b")),
    dict(key='5', num=5, slug='simple_yet', label='"simple yet X" cliche', kind='score', fn=rx(SIMPLE_YET_RE)),
    dict(key='6', num=6, slug='stacked_adjectives', label='stacked adjective chains', kind='score', fn=f_adjective_chains),
    dict(key='8', num=8, slug='synonym_cycling', label='synonym cycling', kind='score', fn=f_synonym_cycling),
    dict(key='10', num=10, slug='significance_inflation', label='significance inflation', kind='score', fn=f_significance),
    dict(key='11', num=11, slug='notability_name_dropping', label='notability name-dropping', kind='score', fn=f_notability),
    dict(key='12', num=12, slug='vague_attributions', label='vague attributions', kind='score', fn=f_vague_attributions),
    dict(key='13', num=13, slug='article_title_proper_noun', label='article-title-as-proper-noun', kind='score', fn=f_title_proper_noun),
    dict(key='14', num=14, slug='ecosystem_padding', label='conservation / ecosystem padding', kind='score', fn=f_conservation),
    dict(key='15', num=15, slug='false_ranges', label='false ranges', kind='score', fn=f_false_ranges),
    dict(key='16', num=16, slug='ing_tail_clauses', label='superficial -ing tail clauses', kind='score', fn=f_ing_tails),
    dict(key='17p', num=17, slug='negative_parallelism', label='negative parallelism', kind='advice', fn=f_negative_parallelism),
    dict(key='17t', num=17, slug='tailing_negation', label='tailing negation', kind='score', fn=f_tailing_negation),
    dict(key='18', num=18, slug='not_x_just_y', label='"Not X, just Y" framing', kind='score', fn=f_not_x_just_y),
    dict(key='19', num=19, slug='filler_phrases', label='filler phrases', kind='advice', fn=rx(FILLER_RE)),
    dict(key='20', num=20, slug='empty_pivot_phrases', label='empty pivot phrases', kind='score', fn=f_empty_pivots),
    dict(key='21', num=21, slug='outcome_speculation_tails', label='outcome-speculation tails', kind='score', fn=f_outcome_tails),
    dict(key='22', num=22, slug='persuasive_authority_tropes', label='persuasive authority tropes', kind='advice',
         fn=rx(r"\bhere[\u2019']s\s+the\s+thing\b|\bmake\s+no\s+mistake\b|\bthe\s+truth\s+is\b|\blet[\u2019']s\s+be\s+honest\b"
               r"|\bthe\s+simple\s+fact\s+is\b|\bat\s+its\s+core\b|\bwhat\s+really\s+matters\b|\bmore\s+than\s+anything\b"
               r"|\bat\s+the\s+end\s+of\s+the\s+day\b|\bthe\s+bottom\s+line\s+is\b|\bin\s+reality\b|\bfundamentally,"
               r"|\bthe\s+real\s+question\s+is\b|\bthe\s+heart\s+of\s+the\s+matter\b|\bthe\s+deeper\s+issue\b"
               r"|\bwhen\s+you\s+get\s+down\s+to\s+it\b|\bwhen\s+all\s+is\s+said\s+and\s+done\b")),
    dict(key='23', num=23, slug='editorial_interjections', label='editorial interjections', kind='score', fn=f_editorial),
    dict(key='24', num=24, slug='self_thoroughness', label='self-thoroughness phrases', kind='score', fn=f_self_thorough),
    dict(key='25', num=25, slug='question_answer_pattern', label='question-answer rhetorical pattern', kind='score', fn=f_question_answer),
    dict(key='26', num=26, slug='concrete_evidence_defense', label='"concrete evidence" defense phrase', kind='score', fn=f_concrete_evidence),
    dict(key='27', num=27, slug='intro_hooks', label='compulsive intro hooks', kind='score', fn=f_intro_hooks),
    dict(key='30', num=30, slug='diff_anchored_writing', label='diff-anchored writing', kind='score', fn=f_diff_anchored),
    dict(key='31', num=31, slug='signposting', label='signposting and announcements', kind='score', fn=f_signposting),
    dict(key='32', num=32, slug='cataloguing_leadins', label='cataloguing lead-ins', kind='score', fn=f_cataloguing),
    dict(key='33', num=33, slug='inline_header_lists', label='inline-header vertical lists', kind='score', fn=f_inline_header_lists),
    dict(key='34', num=34, slug='mid_essay_bullets', label='mid-essay bullet injection', kind='score', fn=f_mid_essay_bullets),
    dict(key='35', num=35, slug='fragmented_headers', label='fragmented headers', kind='score', fn=f_fragmented_headers),
    dict(key='36', num=36, slug='formulaic_challenges', label='formulaic challenges sections', kind='score', fn=f_formulaic_challenges),
    dict(key='37', num=37, slug='transition_clusters', label='transition cluster overuse', kind='score', fn=f_transition_clusters),
    dict(key='38', num=38, slug='compulsive_conclusions', label='compulsive conclusion phrases', kind='score', fn=f_compulsive_conclusions),
    dict(key='39', num=39, slug='generic_positive_conclusions', label='generic positive conclusions', kind='score', fn=f_generic_conclusions),
    dict(key='40', num=40, slug='sentence_length_monotony', label='sentence-length monotony', kind='score', fn=f_sentence_monotony),
    dict(key='41', num=41, slug='mechanical_alternation', label='mechanical sentence-length alternation', kind='advice', fn=f_mechanical_alternation),
    dict(key='42', num=42, slug='opener_repetition', label='opener repetition', kind='advice', fn=f_opener_repetition),
    dict(key='44', num=44, slug='uniform_paragraph_length', label='uniform paragraph length', kind='score', fn=f_uniform_paragraphs),
    dict(key='46', num=46, slug='semicolon_parenthesis_underuse', label='semicolon and parenthesis underuse', kind='advice', fn=f_semicolon_underuse),
    dict(key='47', num=47, slug='chatbot_artifacts', label='chatbot artifacts', kind='score', fn=f_chatbot_artifacts),
    dict(key='48', num=48, slug='sycophantic_tone', label='sycophantic tone', kind='score', fn=f_sycophancy),
    dict(key='50', num=50, slug='knowledge_cutoff_disclaimer', label='knowledge-cutoff disclaimers', kind='score', fn=f_knowledge_cutoff),
    dict(key='51', num=51, slug='copula_avoidance', label='copula avoidance', kind='score', fn=f_copula_avoidance),
    dict(key='54', num=54, slug='hedge_stacking', label='hedge stacking', kind='advice', fn=f_hedge_stacking),
    dict(key='55', num=55, slug='contraction_absence', label='contraction absence', kind='advice', fn=f_contraction_absence),
    dict(key='56', num=56, slug='boldface_overuse', label='boldface overuse', kind='score', fn=f_boldface),
    dict(key='57', num=57, slug='emojis', label='emojis', kind='score', fn=f_emojis),
    dict(key='58', num=58, slug='em_dash_overuse', label='em-dash overuse', kind='advice', fn=f_em_dash),
    dict(key='59', num=59, slug='title_case_headings', label='title case in headings', kind='score', fn=f_title_case),
    dict(key='60', num=60, slug='curly_quotes', label='curly quotation marks', kind='advice', fn=f_curly_quotes),
    dict(key='61', num=61, slug='hyphen_for_en_dash', label='hyphen-for-en-dash in ranges', kind='advice', fn=f_hyphen_en_dash),
    dict(key='62', num=62, slug='invisible_characters', label='invisible / zero-width characters', kind='score', fn=f_invisible),
    dict(key='63', num=63, slug='placeholder_text', label='placeholder text', kind='score', fn=f_placeholder),
    dict(key='64', num=64, slug='chat_reference_markup', label='chatbot reference-markup leak', kind='score', fn=f_chat_markup),
    dict(key='65', num=65, slug='ai_tracking_parameters', label='AI tracking parameters', kind='score', fn=f_ai_tracking),
    dict(key='66', num=66, slug='mixed_script_homoglyphs', label='mixed-script homoglyphs', kind='score', fn=f_homoglyphs),
    dict(key='67', num=67, slug='nonstandard_spaces', label='non-standard spaces', kind='score', fn=f_nonstandard_spaces),
    dict(key='68', num=68, slug='trailing_whitespace', label='trailing / stray whitespace', kind='advice', fn=f_trailing_whitespace),
    dict(key='69', num=69, slug='marketing_slop_phrases', label='canonical marketing-slop phrases', kind='score', fn=f_marketing_slop),
    dict(key='70', num=70, slug='decorative_rules', label='decorative horizontal rules', kind='score', fn=f_decorative_rules),
    dict(key='71', num=71, slug='degenerate_repetition', label='degenerate repetition', kind='score', fn=f_degenerate),
]

# spec: N-000174..N-000177 (decisive families: 13, 47, 48, 50, 62-66)
DECISIVE_NUMS = frozenset([13, 47, 48, 50, 62, 63, 64, 65, 66])
SHORT_FLOOR_NUMS = frozenset(list(range(1, 40)) + list(range(47, 52)) + [69])


def confidence_of(words, score_family_count):
    # spec: N-000145..N-000148
    if words < 40:
        return 'none', 'fewer than 40 words, too little to judge'
    if words < 120:
        return 'low', 'fewer than 120 words'
    if words < 300 and score_family_count == 1:
        return 'low', 'under 300 words with only one score-moving pattern family'
    if words < 300:
        return 'moderate', 'under 300 words'
    return 'high', ''


def compute_score(score_nums, words, confidence):
    """Integer 0-100 from the distinct score-moving families that fired (FP-01)."""
    # spec: N-000131..N-000144 (family counting, caps, floors, rhythm rules)
    n = len(score_nums)
    if n == 0:
        return 0
    decisive = score_nums & DECISIVE_NUMS
    base = 12 * n + 8 * len(decisive)
    cap = 100
    if n == 1:
        cap = 40
    if score_nums <= frozenset([40]):
        cap = 20
    elif score_nums <= frozenset([40, 44]):
        cap = 40
    score = min(base, cap)
    floors = []
    if len(decisive) >= 2:
        floors.append(65)
    elif len(decisive) == 1 and confidence in ('moderate', 'high'):
        floors.append(45)
    if words < 120:
        short = len(score_nums & SHORT_FLOOR_NUMS)
        if short >= 3:
            floors.append(45)
        elif short >= 2:
            floors.append(25)
    if words >= 400:
        if n >= 6:
            floors.append(45)
        elif n >= 5:
            floors.append(25)
    return min(100, max([score] + floors))


def interval_for(ctx, results, conf):
    # spec: N-000221..N-000225 (resampled interval, needs four sentences; point score unchanged)
    sents = ctx.sents
    if len(sents) < 4:
        return None, 'too few sentences (fewer than four) for an interval; the point score stands'
    nS = len(sents)
    fixed = set()
    per_sentence = [dict() for _ in range(nS)]
    for ent, spans in results.values():
        if ent['kind'] != 'score':
            continue
        if all(s == 0 and e == 0 for s, e, _ in spans):
            fixed.add(ent['num'])
            continue
        for s, _, _ in spans:
            idx = max(0, bisect.bisect_right(ctx.sent_starts, s) - 1)
            per_sentence[idx][ent['num']] = per_sentence[idx].get(ent['num'], 0) + 1
    nonzero = [list(d.items()) for d in per_sentence]
    wcs = [wc for _, _, wc in sents]
    rng = random.Random(20240601)
    scores = []
    for _ in range(100):
        counts = {}
        words = 0
        for _k in range(nS):
            j = rng.randrange(nS)
            words += wcs[j]
            for num, c in nonzero[j]:
                counts[num] = counts.get(num, 0) + c
        fired = set(fixed) | set(num for num, c in counts.items() if c > 0)
        scores.append(compute_score(frozenset(fired), words, conf))
    scores.sort()
    low = scores[int(0.05 * len(scores))]
    high = scores[min(len(scores) - 1, int(0.95 * len(scores)))]
    return [low, high], 'resampled sentences (100 draws, fixed seed); the point score is unchanged'


def analyze(text, want_ci=False):
    """Report dict (findings + _metrics) for extracted prose."""
    s = text.replace('\r\n', '\n').replace('\r', '\n')
    if s.startswith('\ufeff'):
        s = s[1:]
    truncated = len(s) > WINDOW
    window = s[:WINDOW]
    masked = mask_excluded(window)
    ctx = Ctx(masked, truncated=truncated)

    results = {}
    for ent in FAMILIES:
        spans = ent['fn'](ctx) or []
        if spans:
            results[ent['key']] = (ent, spans)

    findings = {}
    for ent in FAMILIES:
        if ent['key'] not in results:
            continue
        _, spans = results[ent['key']]
        findings['%d_%s' % (ent['num'], ent['slug'])] = {
            'label': ent['label'],
            'count': len(spans),
            'samples': [excerpt(sp[2]) for sp in spans[:3]],
        }

    score_nums = frozenset(ent['num'] for ent, _ in results.values() if ent['kind'] == 'score')
    words = len(ctx.words)
    conf, reason = confidence_of(words, len(score_nums))
    score = compute_score(score_nums, words, conf)

    invis, spaces = scan_chars(masked)
    homoglyphs = sum(homoglyph_count(tok) for tok in TOKEN_RE.findall(masked))
    metrics = {
        'scanned_chars': len(window),
        'truncated': truncated,
        'ai_tell_score': score,
        'ai_tell_band': band_for(score),
        'confidence': conf,
        'confidence_reason': reason,
        'patterns_flagged': len(findings),
        'invisible_chars': len(invis),
        'nonstandard_spaces': len(spaces),
        'homoglyphs': homoglyphs,
        'words': words,
    }
    if want_ci:
        ci, note = interval_for(ctx, results, conf)
        metrics['score_ci'] = ci
        metrics['score_ci_note'] = note
    report = dict(findings)
    report['_metrics'] = metrics
    return report


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------

def _err(message):
    sys.stderr.write(json.dumps({'error': message}, ensure_ascii=False) + '\n')
    sys.stderr.flush()


def _write_bytes(data):
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.flush()


def main(argv):
    clean = False
    want_ci = False
    operands = []
    end_of_options = False
    for arg in argv:
        if end_of_options:
            operands.append(arg)
            continue
        if arg == '--':
            end_of_options = True
            continue
        if arg in ('-h', '--help'):
            _write_bytes(USAGE_TEXT.encode('utf-8'))
            return 0
        if arg == '--clean':
            clean = True
            continue
        if arg == '--ci':
            want_ci = True
            continue
        if arg.startswith('-'):
            _err("unknown option '%s'; see --help" % arg)
            return 2
        operands.append(arg)

    try:
        if operands:
            if len(operands) > 1:
                sys.stderr.write("prosecheck: several files given; only the first, '%s', was scanned\n"
                                 % operands[0])
            text = load_path(operands[0])
        else:
            text = load_stdin()
    except ReadError as exc:
        _err(str(exc))
        return 1
    except Exception as exc:  # no traceback on the error stream
        _err('cannot read input: %s' % exc.__class__.__name__)
        return 1

    if not text.strip():
        _err('empty input')
        return 1

    if clean:
        scrubbed = clean_text(text)
        _write_bytes(scrubbed.encode('utf-8'))
        return 0

    try:
        report = analyze(text, want_ci=want_ci)
    except Exception as exc:  # defensive: never print a traceback
        _err('internal error while scoring: %s' % exc.__class__.__name__)
        return 1
    _write_bytes((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv[1:]))
    except BrokenPipeError:
        sys.exit(0)
