#!/usr/bin/env node
'use strict';
// Session-start hook: writes the writing contract for the stored level as plain text.
// spec: N-000788..N-000812 (hooks/prosecheck-activate.js). Always exits 0.

const fs = require('fs');
const common = require('./lib/prosecheck-common.js');

function main() {
  try {
    common.readStdinJson();
    const level = common.effectiveLevel();
    const hadFlag = fs.existsSync(common.flagPath());
    if (!hadFlag && level !== 'off') {
      // First start of a fresh install: store the level so later hooks see it.
      try {
        common.writeStored(level);
      } catch (e) {
        /* unwritable config folder: continue without storing */
      }
    }
    common.pruneLedgers(); // spec: N-000702 (ledgers untouched for seven days are deleted)
    if (level === 'off') return; // spec: N-000791 (off prints nothing)
    const parts = [];
    if (!hadFlag) parts.push(common.welcomeText());
    parts.push(common.writingContract(level));
    process.stdout.write(parts.join('\n\n') + '\n');
  } catch (e) {
    /* never fail the host session */
  }
}

main();
process.exitCode = 0;
