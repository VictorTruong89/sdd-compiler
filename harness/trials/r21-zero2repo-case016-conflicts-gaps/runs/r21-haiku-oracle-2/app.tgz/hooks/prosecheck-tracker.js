#!/usr/bin/env node
'use strict';
// Prompt-submit hook and /prosecheck command router (FP-04 reminder, FP-06 commands).
// spec: N-000457..N-000577 (FP-06), N-000380..N-000383 (reminder), N-000870..N-000908 (interface /prosecheck).
// Command prompts are blocked and answered; ordinary prompts get the live-level reminder.
// Always exits 0.

const fs = require('fs');
const path = require('path');
const common = require('./lib/prosecheck-common.js');
const stats = require('./prosecheck-stats.js');

const SUBCOMMANDS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];
const SAMPLE_TEXT = 'The writing here is plain and direct. It says what it means, then stops.';
const CHECK_TAG_CAP = 8; // spec: FP-06 check reply, up to eight labels

function helpReply(level) {
  return [
    'prosecheck: the live level is ' + level + '.',
    'Code, commits, config, and chat are always left alone; they are never scored or rewritten.',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
    '/prosecheck lite - writing contract only, with no saved-file scoring.',
    '/prosecheck full - writing contract plus the saved-file guard, threshold 40 (default).',
    '/prosecheck strict - writing contract plus the guard at threshold 20, with a cleanup scrub.',
    '/prosecheck off | on - off: disable the tool; on: re-enable it at full.',
    '/prosecheck check <path> - score one file; it reports a score and does not rewrite the file.',
    '/prosecheck doctor - health check of the install.',
    '/prosecheck stats - token use for this session and the score of its own prose.',
    '/prosecheck init - export the writing contract to AGENTS.md for agents other than Claude Code.',
    '/prosecheck status - show the live level.',
    '/prosecheck show - list the files scored in this session.',
  ].join('\n');
}

function unknownReply(word) {
  return 'unknown subcommand "' + word + '". Valid subcommands: ' + SUBCOMMANDS.join(', ') +
    '. The stored level is unchanged.';
}

function unquotePath(arg) {
  let p = String(arg || '').trim();
  if (p.charAt(0) === '@') p = p.slice(1).trim();
  if (p.length >= 2 && (p[0] === '"' || p[0] === "'") && p[p.length - 1] === p[0]) {
    p = p.slice(1, -1);
  }
  return p;
}

function checkReply(arg, cwd) {
  const typed = unquotePath(arg);
  if (!typed) {
    return 'Usage: /prosecheck check <path>. It scores one file and gives a report only; the file is not rewritten.';
  }
  const abs = path.resolve(cwd, typed);
  const base = path.basename(abs);
  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    return 'cannot read ' + typed + ': the path is not on disk or cannot be opened. The file was not changed.';
  }
  if (st.isDirectory()) return base + ': not a file.';
  if (!st.isFile()) return base + ': not a file.';
  const ext = path.extname(abs).toLowerCase();
  if (common.BINARY_EXTS.indexOf(ext) !== -1) {
    return base + ': no readable text (' + ext + ' is not among the supported formats). The file was not changed.';
  }
  const archive = common.ZIP_EXTS.indexOf(ext) !== -1 || common.NOTEBOOK_EXTS.indexOf(ext) !== -1;
  const capKb = archive ? common.ARCHIVE_CAP_KB : common.PLAIN_CAP_KB;
  if (st.size > capKb * 1024) {
    return base + ': over ' + capKb + ' KB, the size limit for this file type. The file was not changed.';
  }
  const outcome = common.runDetector([abs], { timeoutMs: archive ? 15000 : 8000 });
  if (outcome.kind === 'noPython') return base + ': detector unavailable, because Python was not found.';
  if (outcome.kind === 'noDetector') return base + ': detector unavailable, because the bundled detector is missing.';
  if (outcome.kind === 'timeout') return base + ': failed (the detector timed out). The file was not changed.';
  if (outcome.kind !== 'ok') {
    const err = common.lastErrorText(outcome.stderr);
    return base + ': failed' + (err ? ' (' + err + ')' : '') + '. The file was not changed.';
  }
  if (!outcome.stdout.trim()) return base + ': no report (the detector printed nothing).';
  const report = common.parseReport(outcome.stdout);
  if (!report) return 'no report: the detector output was not a report. The file was not changed.';
  const m = report._metrics;
  const phrase = common.HOOK_PHRASES[m.ai_tell_band] || 'reads with some AI tells';
  const tells = Object.keys(report)
    .filter((k) => k !== '_metrics')
    .map((k) => report[k].label + ' (x' + report[k].count + ')')
    .slice(0, CHECK_TAG_CAP);
  const lines = [
    base + ' - ' + phrase + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')',
    'confidence: ' + m.confidence + (m.confidence !== 'high' && m.confidence_reason ? ' - ' + m.confidence_reason : ''),
  ];
  if (m.truncated) lines.push('coverage: first ' + common.WINDOW_TEXT + ' characters only');
  lines.push('tells: ' + (tells.length ? tells.join('; ') : 'none'));
  lines.push('This is a report only; the file was not rewritten.');
  return lines.join('\n');
}

function rowBody(row) {
  if (row.kind === 'skip') {
    return 'not scored: the file is over the ' + row.limitKb + ' KB limit';
  }
  if (row.kind === 'binary') {
    return 'not re-scored: ' + (row.ext || 'this') + ' is a binary format, so only its name is recorded';
  }
  if (row.kind === 'failed') {
    return 'not scored: ' + row.reason;
  }
  const phrase = common.HOOK_PHRASES[row.band] || 'reads with some AI tells';
  const window = row.truncated ? ', first ' + common.WINDOW_TEXT + ' characters only' : '';
  let body = phrase + ' (score ' + row.score + '/' + row.band + window + ')';
  const labels = Array.isArray(row.labels) ? row.labels.slice(0, 5) : [];
  if (labels.length) {
    body += ' - ' + (row.flagged ? 'flagged' : 'under the threshold') + ': ' + labels.join('; ');
  }
  return body;
}

function showReply(sid) {
  const rows = common.readLedger(sid).slice().reverse();
  if (!rows.length) {
    return 'nothing scored yet in this session. Rows appear after prose files, such as .docx and .pdf deliverables, are saved.';
  }
  const lines = ['prosecheck show (this session, newest first):'];
  for (const row of rows) {
    lines.push('  ' + row.base + ' - ' + rowBody(row));
  }
  return lines.join('\n');
}

function initReply(form, level, cwd) {
  if (level === 'off') {
    return 'prosecheck is switched off, so no files were written. Run ' + form + ' on to allow the export.';
  }
  const out = [];
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = '';
  let readable = true;
  try {
    existing = fs.readFileSync(agents, 'utf8');
  } catch (e) {
    if (e.code !== 'ENOENT') {
      readable = false;
      out.push('cannot read AGENTS.md (' + (e.code || 'error') + '); it was not changed.');
    }
  }
  if (readable) {
    if (existing.indexOf('<!-- prosecheck:start -->') !== -1 || existing.indexOf('Writing contract for prose deliverables.') !== -1) {
      out.push('AGENTS.md already contains the writing contract; it was not changed.');
    } else {
      let next = existing;
      if (next && next.slice(-1) !== '\n') next += '\n';
      if (next) next += '\n';
      next += common.exportSection(level);
      try {
        fs.writeFileSync(agents, next, 'utf8');
        out.push('wrote the writing contract to AGENTS.md.');
      } catch (e) {
        out.push('cannot write AGENTS.md (' + (e.code || 'error') + '); it was not changed.');
      }
    }
  }
  const src = path.join(common.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
  const dstDir = path.join(cwd, '.cursor', 'rules');
  const dst = path.join(dstDir, 'prosecheck.mdc');
  if (fs.existsSync(dst)) {
    out.push('prosecheck.mdc already exists in .cursor/rules; it was not overwritten.');
  } else {
    try {
      fs.mkdirSync(dstDir, { recursive: true });
      fs.copyFileSync(src, dst);
      out.push('copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      out.push('cannot write .cursor/rules/prosecheck.mdc (' + (e.code || 'error') + '); the rule was not created.');
    }
  }
  return out.join('\n');
}

function doctorReply(form, level) {
  const lines = ['prosecheck doctor'];
  const modeOk = level !== 'off';
  lines.push(modeOk
    ? 'mode: ' + level + ' [OK]'
    : 'mode: off - not a fault of the install; run /prosecheck on to turn the tool back on.');

  const detector = common.detectorPath();
  const detectorOk = !!detector;
  lines.push(detectorOk
    ? 'detector: bundled scripts/detect.py found [OK]'
    : 'detector: the bundled scripts/detect.py is missing from the plugin tree.');

  const outcome = common.runDetector([], { input: SAMPLE_TEXT, timeoutMs: 8000 });
  let pyOk = false;
  let pyLine;
  if (outcome.kind === 'noPython') {
    pyLine = 'python not found: Python cannot be launched, so saved files are not re-scored until it is available; prose is still shaped by the writing contract.';
  } else if (outcome.kind === 'noDetector') {
    pyLine = 'python: could not run the detector because the bundled file is missing.';
  } else if (outcome.kind === 'ok' && common.parseReport(outcome.stdout)) {
    pyOk = true;
    pyLine = 'python: ran the bundled detector and got a numeric score [OK]';
  } else {
    pyLine = 'python: the bundled detector ran but did not return a numeric score.';
  }
  lines.push(pyLine);

  let settingsOk = false;
  try {
    const dir = common.configDir();
    fs.mkdirSync(dir, { recursive: true });
    fs.accessSync(dir, fs.constants.W_OK);
    settingsOk = true;
  } catch (e) {
    settingsOk = false;
  }
  lines.push(settingsOk
    ? 'settings: the settings folder is writable [OK]'
    : 'settings: the settings folder is not writable.');

  const allOk = detectorOk && pyOk && settingsOk;
  let closer;
  if (allOk && modeOk) {
    closer = 'prosecheck is active. Plain text is accepted up to 512 KB and archives up to 4 MB; the first ' +
      common.WINDOW_TEXT + ' characters are scanned. Run ' + form + ' show to see files that were only partly scanned or skipped.';
  } else if (!allOk) {
    closer = 'Fix the faulty checks above, then run /prosecheck doctor again.';
  } else {
    closer = 'The install is healthy. In off mode, saved files are not scored; run ' + form + ' on to turn scoring back on.';
  }
  lines.push(closer);
  return lines.join('\n');
}

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason: reason }) + '\n');
}

function handleCommand(sub, arg, form, payload, cwd, sid) {
  const level = common.effectiveLevel();
  if (sub === '' || sub === 'help') return helpReply(level);
  if (sub === 'lite' || sub === 'full' || sub === 'strict') {
    common.writeStored(sub);
    return 'prosecheck level set to ' + sub + '.';
  }
  if (sub === 'off') {
    common.writeStored('off');
    return 'prosecheck is off. Stored level: off. Run ' + form + ' on to turn it back on.';
  }
  if (sub === 'on') {
    common.writeStored('full');
    return 'prosecheck is on at full. Stored level: full.';
  }
  if (sub === 'status') return 'prosecheck status: level ' + level + '.';
  if (sub === 'show') return showReply(sid);
  if (sub === 'check') return checkReply(arg, cwd);
  if (sub === 'doctor') return doctorReply(form, level);
  if (sub === 'stats') return stats.statsReply(payload, level);
  if (sub === 'init') return initReply(form, level, cwd);
  return unknownReply(sub);
}

function main() {
  const payload = common.readStdinJson();
  const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
  const sid = typeof payload.session_id === 'string' ? payload.session_id : '';
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const text = prompt.trim();

  if (/^(?:stop prosecheck|prosecheck off)$/i.test(text)) {
    common.writeStored('off');
    block('prosecheck is off. Stored level: off. Run /prosecheck on to turn it back on.');
    return;
  }

  const m = /^\/prosecheck(:prosecheck)?(?=\s|$)([\s\S]*)$/i.exec(text);
  if (m) {
    const form = m[1] ? '/prosecheck:prosecheck' : '/prosecheck';
    const rest = m[2].trim();
    const first = rest.split(/\s+/)[0] || '';
    const sub = first.toLowerCase();
    const arg = rest.slice(first.length).trim();
    block(handleCommand(sub, arg, form, payload, cwd, sid));
    return;
  }

  const level = common.effectiveLevel();
  if (level === 'off') return;
  const reminder = 'prosecheck (live level: ' + level + '): prose deliverables follow the writing contract; ' +
    'code, config, and commits are untouched.';
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: { hookEventName: 'UserPromptSubmit', additionalContext: reminder },
  }) + '\n');
}

try {
  main();
} catch (e) {
  /* never fail the host session */
}
process.exitCode = 0;
