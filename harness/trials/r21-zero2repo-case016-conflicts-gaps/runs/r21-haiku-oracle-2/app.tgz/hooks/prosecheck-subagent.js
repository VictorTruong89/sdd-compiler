#!/usr/bin/env node
'use strict';
// Subagent-start hook: returns the same writing contract inside the host's JSON envelope.
// spec: N-000813..N-000818 (hooks/prosecheck-subagent.js). Always exits 0.

const common = require('./lib/prosecheck-common.js');

function main() {
  try {
    common.readStdinJson();
    const level = common.effectiveLevel();
    if (level === 'off') return; // spec: N-000815
    const envelope = {
      hookSpecificOutput: {
        hookEventName: 'SubagentStart',
        additionalContext: common.writingContract(level),
      },
    };
    process.stdout.write(JSON.stringify(envelope) + '\n');
  } catch (e) {
    /* never fail the host session */
  }
}

main();
process.exitCode = 0;
