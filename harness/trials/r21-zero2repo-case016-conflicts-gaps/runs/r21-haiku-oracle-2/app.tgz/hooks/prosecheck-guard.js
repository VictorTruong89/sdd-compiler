#!/usr/bin/env node
'use strict';
// Post-tool-use hook: saved-file guard (FP-05). Fired after Write, Edit, MultiEdit,
// NotebookEdit, or apply_patch. Scores the just-saved prose file and nudges when flagged.
// spec: N-000395..N-000456 (FP-05), N-000819..N-000835 (post-tool-use reply). Always exits 0.

const fs = require('fs');
const path = require('path');
const common = require('./lib/prosecheck-common.js');

const MAX_PATCH_PATHS = 10; // spec: N-000834 (ten paths per payload); the PRD allows up to 16
const GUARD_LABEL_CAP = 5; // spec: FP-05 "up to five fired pattern labels"
const SKIP_DIRS = ['node_modules', '.git'];
const INSTRUCTION_NAMES = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
const INSTRUCTION_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];
const PATCH_LINE_RE = /^\*\*\*\s+(?:Add File|Update File|Move to)\s*:\s*(.*)$/;

// Paths the payload names, per tool.
function namedPaths(payload) {
  const tool = String(payload.tool_name || '');
  const input = payload.tool_input && typeof payload.tool_input === 'object' ? payload.tool_input : {};
  if (tool === 'apply_patch') {
    const body = typeof input.command === 'string' ? input.command : '';
    const found = [];
    for (const line of body.split(/\r?\n/)) {
      const m = PATCH_LINE_RE.exec(line);
      if (m) {
        const p = m[1].trim();
        if (p && found.indexOf(p) === -1) found.push(p);
      }
    }
    return found.slice(0, MAX_PATCH_PATHS);
  }
  if (tool === 'NotebookEdit') {
    const p = input.notebook_path || input.file_path;
    return typeof p === 'string' && p.trim() ? [p.trim()] : [];
  }
  if (['Write', 'Edit', 'MultiEdit'].indexOf(tool) !== -1) {
    const p = input.file_path;
    return typeof p === 'string' && p.trim() ? [p.trim()] : [];
  }
  return [];
}

function isSkipped(absPath) {
  const parts = absPath.split(path.sep);
  if (parts.some((seg) => SKIP_DIRS.indexOf(seg) !== -1)) return true;
  const root = path.resolve(common.pluginRoot());
  if (absPath === root || absPath.indexOf(root + path.sep) === 0) return true;
  const base = path.basename(absPath).toLowerCase();
  if (INSTRUCTION_NAMES.indexOf(base) !== -1) return true;
  const dot = base.lastIndexOf('.');
  const stem = dot > 0 ? base.slice(0, dot) : base;
  const ext = dot > 0 ? base.slice(dot) : '';
  if (INSTRUCTION_STEMS.indexOf(stem) !== -1 && common.ELIGIBLE_EXTS.indexOf(ext) === -1) return true;
  return false;
}

function phraseFor(band) {
  return common.HOOK_PHRASES[band] || 'reads with some AI tells';
}

// The reason a check failed, from the detector's outcome. Distinct user-readable reasons.
function failureReason(outcome) {
  switch (outcome.kind) {
    case 'noPython':
      return 'Python not found';
    case 'timeout':
      return 'detector timed out';
    case 'noDetector':
      return 'detector missing from the plugin';
    default:
      break;
  }
  if (outcome.stdout && outcome.stdout.trim()) {
    // A structured report without a numeric score is a different failure from non-report output.
    try {
      const obj = JSON.parse(outcome.stdout);
      if (obj && typeof obj === 'object' && obj._metrics) return 'report had no numeric score';
    } catch (e) {
      /* not JSON */
    }
    return 'detector output was not a report';
  }
  // Empty input and other exits without a usable result share this reason.
  return 'detector produced no usable result';
}

function scoreOne(absPath, cwdSeen, stats) {
  const base = path.basename(absPath);
  const ext = path.extname(absPath).toLowerCase();
  const sid = stats.sessionId;
  if (common.BINARY_EXTS.indexOf(ext) !== -1) {
    common.appendLedger(sid, { base, kind: 'binary', ext });
    return null;
  }
  let st;
  try {
    st = fs.statSync(absPath);
  } catch (e) {
    common.appendLedger(sid, { base, kind: 'failed', reason: 'cannot read the file' });
    return null;
  }
  if (!st.isFile()) return null;
  const archive = common.ZIP_EXTS.indexOf(ext) !== -1 || common.NOTEBOOK_EXTS.indexOf(ext) !== -1;
  const capBytes = archive ? common.ARCHIVE_CAP_KB * 1024 : common.PLAIN_CAP_KB * 1024;
  const capKb = archive ? common.ARCHIVE_CAP_KB : common.PLAIN_CAP_KB;
  if (st.size > capBytes) {
    common.appendLedger(sid, { base, kind: 'skip', limitKb: capKb });
    return null;
  }
  const timeoutMs = archive ? 15000 : 8000; // spec: N-000438..N-000441
  const outcome = common.runDetector([absPath], { timeoutMs });
  const report = outcome.kind === 'ok' ? common.parseReport(outcome.stdout) : null;
  if (!report) {
    common.appendLedger(sid, { base, kind: 'failed', reason: failureReason(outcome) });
    return null;
  }
  const m = report._metrics;
  const labels = Object.keys(report)
    .filter((k) => k !== '_metrics')
    .map((k) => report[k].label)
    .filter((x) => typeof x === 'string');
  const level = stats.level;
  const threshold = level === 'strict' ? 20 : 40; // spec: N-000409..N-000411
  const flagged = m.ai_tell_score > threshold;
  common.appendLedger(sid, {
    base,
    kind: 'scored',
    score: m.ai_tell_score,
    band: m.ai_tell_band,
    labels: labels.slice(0, GUARD_LABEL_CAP),
    flagged,
    truncated: !!m.truncated,
  });
  if (!flagged) return null;
  const coverage = m.truncated ? ', first ' + common.WINDOW_TEXT + ' characters only' : '';
  const shownLabels = labels.slice(0, GUARD_LABEL_CAP).join('; ') || 'none';
  return 'prosecheck: ' + base + ' ' + phraseFor(m.ai_tell_band) + ' (score ' + m.ai_tell_score +
    ', band ' + m.ai_tell_band + coverage + '). Flagged: ' + shownLabels +
    '. Fix the flagged spans in this file, keeping the sentence-length variation.';
}

function main() {
  const payload = common.readStdinJson();
  const level = common.effectiveLevel();
  if (level === 'off' || level === 'lite') return; // spec: N-000402
  const sessionId = typeof payload.session_id === 'string' ? payload.session_id : '';
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const names = namedPaths(payload);
  if (!names.length) return; // spec: N-000442
  const lines = [];
  const seen = [];
  for (const raw of names) {
    const abs = path.resolve(cwd, raw);
    if (seen.indexOf(abs) !== -1) continue;
    seen.push(abs);
    if (isSkipped(abs)) continue;
    const ext = path.extname(abs).toLowerCase();
    if (common.BINARY_EXTS.indexOf(ext) === -1 && common.ELIGIBLE_EXTS.indexOf(ext) === -1) continue;
    const line = scoreOne(abs, cwd, { sessionId, level });
    if (line) lines.push(line);
  }
  if (!lines.length) return; // spec: N-000416
  const envelope = {
    hookSpecificOutput: {
      hookEventName: 'PostToolUse',
      additionalContext: lines.join('\n'),
    },
  };
  process.stdout.write(JSON.stringify(envelope) + '\n');
}

try {
  main();
} catch (e) {
  /* never fail the host session */
}
process.exitCode = 0;
