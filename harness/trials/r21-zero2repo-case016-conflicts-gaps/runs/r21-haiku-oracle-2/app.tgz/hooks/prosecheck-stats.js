#!/usr/bin/env node
'use strict';
// Stats (FP-06 `stats`): token totals from the session transcript and, when there is
// enough assistant prose, a score of that prose. Exports statsReply() for the prompt-submit
// router; run directly it reads a prompt-submit JSON object on standard input.
// spec: N-000543..N-000555 (FP-06 stats), N-001103..N-001121 (interface stats)

const fs = require('fs');
const path = require('path');
const common = require('./lib/prosecheck-common.js');

const SLICE_CHARS = 40000; // spec: N-000553 (last 40,000 characters of assistant text)
const PROSE_MIN_CHARS = 500; // spec: N-001117 (interface contract; the PRD states 200)

function newestTranscript(root) {
  let best = null;
  const walk = (dir, depth) => {
    if (depth > 4) return;
    let entries = [];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (e) {
      return;
    }
    for (const ent of entries) {
      const full = path.join(dir, ent.name);
      if (ent.isDirectory()) {
        walk(full, depth + 1);
      } else if (ent.isFile() && ent.name.endsWith('.jsonl')) {
        try {
          const mtime = fs.statSync(full).mtimeMs;
          if (!best || mtime > best.mtime) best = { file: full, mtime };
        } catch (e) {
          /* ignore */
        }
      }
    }
  };
  walk(root, 0);
  return best ? best.file : null;
}

function readTranscript(file) {
  let raw;
  try {
    raw = fs.readFileSync(file, 'utf8');
  } catch (e) {
    return null;
  }
  const seen = new Set();
  let turns = 0;
  let outputTokens = 0;
  let cacheRead = 0;
  const texts = [];
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    let row;
    try {
      row = JSON.parse(line);
    } catch (e) {
      continue;
    }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const id = msg.id || row.uuid || null;
    if (id) {
      if (seen.has(id)) continue;
      seen.add(id);
    }
    turns += 1;
    const usage = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    outputTokens += Number(usage.output_tokens) || 0;
    cacheRead += Number(usage.cache_read_input_tokens) || 0;
    if (Array.isArray(msg.content)) {
      for (const part of msg.content) {
        if (part && part.type === 'text' && typeof part.text === 'string') texts.push(part.text);
      }
    }
  }
  return { turns, outputTokens, cacheRead, texts };
}

function fmt(n) {
  return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function statsReply(payload, level) {
  const named = typeof payload.transcript_path === 'string' && payload.transcript_path.trim()
    ? payload.transcript_path.trim() : null;
  const file = named || newestTranscript(path.join(common.configDir(), 'projects'));
  const parsed = file ? readTranscript(file) : null;
  if (!parsed) {
    return 'prosecheck stats: no readable session transcript was found' +
      (named ? ' at the given transcript path.' : ' under the projects folder.') +
      ' Level: ' + level + '.';
  }
  const lines = [
    'prosecheck stats (this session)',
    'assistant turns: ' + fmt(parsed.turns),
    'output tokens: ' + fmt(parsed.outputTokens),
    'cache-read input tokens: ' + fmt(parsed.cacheRead),
    'level: ' + level,
  ];
  let prose = parsed.texts.join('\n');
  prose = prose.replace(/```[\s\S]*?```/g, '').replace(/~~~[\s\S]*?~~~/g, '');
  prose = prose.slice(-SLICE_CHARS).trim();
  if (prose.length > PROSE_MIN_CHARS) {
    const outcome = common.runDetector([], { input: prose, timeoutMs: 8000 });
    const report = outcome.kind === 'ok' ? common.parseReport(outcome.stdout) : null;
    if (report) lines.push('session prose ai_tell_score: ' + report._metrics.ai_tell_score);
  }
  return lines.join('\n');
}

module.exports = { statsReply, newestTranscript, readTranscript };

if (require.main === module) {
  const payload = common.readStdinJson();
  const reason = statsReply(payload, common.effectiveLevel());
  process.stdout.write(JSON.stringify({ decision: 'block', reason }) + '\n');
  process.exitCode = 0;
}
