# Ethics

prosecheck scores writing. It does not score people.

- **Not authorship.** A score, a band, and a hook phrase describe the prose in front of the detector. They do not name a person or a model as the author, and they never say that a text "was written by" anyone.
- **Triage, not proof.** The score is a triage heuristic, not a calibrated authorship classifier. It ranks patterns in prose; it does not establish truth, intent, or overall writing quality.
- **Do not use it to accuse.** Do not use a score to accuse a person of cheating, plagiarism, or dishonesty, and do not compare a person's writing to a score as evidence against them.
- **Local only.** Analysis runs on this machine. Document text is not uploaded and no account is needed.
