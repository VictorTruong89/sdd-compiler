"""Tests for the prosecheck detector. Run from /app with:

    python3 -m unittest discover -s tests -v

Acceptance-criterion tests are named after their spec labels (N-000305, N-000309).
"""
import json
import os
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DETECT = os.path.join(ROOT, 'scripts', 'detect.py')
sys.path.insert(0, os.path.join(ROOT, 'scripts'))
import detect  # noqa: E402


def run_detector(args, stdin=b''):
    return subprocess.run([sys.executable, '-I', DETECT] + args, input=stdin,
                          capture_output=True)


def report_for(text):
    proc = run_detector([], text.encode('utf-8'))
    assert proc.returncode == 0, proc.stderr
    return json.loads(proc.stdout.decode('utf-8'))


class CleanupAcceptance(unittest.TestCase):
    # spec: N-000305, N-000309 (FP-03 acceptance criteria)

    def _rescan(self, raw):
        cleaned = detect.clean_text(raw)
        report = report_for(cleaned)
        return report['_metrics'], cleaned

    def test_N_000305_after_cleanup_rescan_has_zero_invisible_hits(self):
        raw = 'Zero​width and­ soft⁠ joiners️ hide\U000e0041 here.‍\n'
        metrics, cleaned = self._rescan(raw)
        self.assertEqual(metrics['invisible_chars'], 0)
        self.assertNotIn('​', cleaned)
        self.assertIn('Zerowidth', cleaned)

    def test_N_000309_after_cleanup_rescan_has_zero_nonstandard_space_hits(self):
        raw = 'Em space, ideographic　space, narrow space and nbsp here.\n'
        metrics, cleaned = self._rescan(raw)
        self.assertEqual(metrics['nonstandard_spaces'], 0)
        self.assertIn('nbsp', cleaned)


class CleanupBehaviour(unittest.TestCase):
    # spec: N-000312..N-000319, N-000327..N-000331

    def test_nbsp_between_digits_is_kept(self):
        self.assertEqual(detect.clean_text('Route 42 km.'), 'Route 42 km.')

    def test_trailing_whitespace_removed_and_one_newline_restored(self):
        self.assertEqual(detect.clean_text('Line  \n\n\n'), 'Line\n')

    def test_zero_width_joiner_kept_beside_emoji(self):
        text = 'family \U0001F468‍\U0001F469'
        self.assertEqual(detect.clean_text(text), text)

    def test_homoglyph_word_folded_to_ascii(self):
        self.assertEqual(detect.clean_text('wоrd here'), 'word here')

    def test_genuine_cyrillic_word_untouched(self):
        self.assertEqual(detect.clean_text('слово'), 'слово')


class CliContract(unittest.TestCase):
    # spec: N-000704..N-000715, N-000732..N-000742, N-000783..N-000787

    def test_empty_stdin_is_empty_input_error(self):
        proc = run_detector([], b'  \n')
        self.assertEqual(proc.returncode, 1)
        self.assertEqual(proc.stdout, b'')
        self.assertEqual(json.loads(proc.stderr.decode().strip().splitlines()[-1]), {'error': 'empty input'})

    def test_unknown_option_exits_two_and_names_help(self):
        proc = run_detector(['--nope'], b'Some text here.')
        self.assertEqual(proc.returncode, 2)
        message = json.loads(proc.stderr.decode().strip().splitlines()[-1])['error']
        self.assertIn('unknown option', message)
        self.assertIn('--nope', message)
        self.assertIn('--help', message)

    def test_help_prints_usage_first_line_on_stdout(self):
        proc = run_detector(['--help'])
        self.assertEqual(proc.returncode, 0)
        self.assertEqual(proc.stdout.decode().splitlines()[0], 'usage: detect.py [--clean] [--ci] [--] [FILE]')

    def test_unreadable_path_is_cannot_read_error(self):
        proc = run_detector([os.path.join(tempfile.gettempdir(), 'prosecheck-no-such-file.md')])
        self.assertEqual(proc.returncode, 1)
        self.assertTrue(json.loads(proc.stderr.decode().strip().splitlines()[-1])['error'].startswith('cannot read input:'))

    def test_two_files_scan_the_first_and_notice_on_stderr(self):
        with tempfile.TemporaryDirectory() as tmp:
            a = os.path.join(tmp, 'a.md')
            b = os.path.join(tmp, 'b.md')
            with open(a, 'w', encoding='utf-8') as fh:
                fh.write('First file text.')
            with open(b, 'w', encoding='utf-8') as fh:
                fh.write('Second file text.')
            proc = run_detector([a, b])
            self.assertEqual(proc.returncode, 0)
            self.assertIn(a, proc.stderr.decode())
            self.assertIn('_metrics', json.loads(proc.stdout.decode()))

    def test_ci_interval_only_with_flag_and_four_sentences(self):
        text = 'One sentence here. Another one follows. A third sentence sits there. And a fourth ends it.'
        report = report_for(text)
        self.assertNotIn('score_ci', report['_metrics'])
        proc = run_detector(['--ci'], text.encode('utf-8'))
        metrics = json.loads(proc.stdout.decode())['_metrics']
        low, high = metrics['score_ci']
        self.assertLessEqual(low, high)
        self.assertEqual(metrics['ai_tell_score'], report['_metrics']['ai_tell_score'])


class ScoringRules(unittest.TestCase):
    # spec: N-000115, N-000131..N-000148

    def test_plain_prose_scores_clean(self):
        text = ('We walked across the bridge on Tuesday. The wind was cold. '
                'My sister wanted to stop, but we kept going because it was late.')
        self.assertEqual(report_for(text)['_metrics']['ai_tell_score'], 0)

    def test_single_family_caps_at_forty(self):
        text = 'We will delve into it. ' * 3
        report = report_for(text)
        self.assertLessEqual(report['_metrics']['ai_tell_score'], 40)

    def test_bands_cover_the_five_ranges(self):
        self.assertEqual(detect.band_for(0), 'clean')
        self.assertEqual(detect.band_for(21), 'light tells')
        self.assertEqual(detect.band_for(41), 'mixed')
        self.assertEqual(detect.band_for(61), 'heavy tells')
        self.assertEqual(detect.band_for(81), 'pervasive tells')

    def test_code_blocks_generate_no_findings(self):
        text = 'Plain prose here.\n\n```\ndelve crucial robust\n```\n'
        self.assertNotIn('1_ai_vocabulary', report_for(text))

    def test_decisive_pair_floor_is_sixty_five(self):
        score = detect.compute_score(frozenset([13, 47]), 500, 'high')
        self.assertGreaterEqual(score, 65)

    def test_monotony_only_scores_at_most_twenty(self):
        self.assertLessEqual(detect.compute_score(frozenset([40]), 500, 'high'), 20)


if __name__ == '__main__':
    unittest.main()
