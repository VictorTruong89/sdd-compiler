---
description: prosecheck controls: help, lite, full, strict, off, on, status, check, doctor, stats, show, init
argument-hint: [help | lite | full | strict | off | on | status | check <path> | doctor | stats | show | init]
---

/prosecheck $ARGUMENTS
