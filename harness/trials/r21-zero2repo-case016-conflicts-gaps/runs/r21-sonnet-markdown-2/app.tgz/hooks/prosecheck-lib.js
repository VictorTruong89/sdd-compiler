'use strict';
// Shared helpers for the prosecheck hooks. Node standard library only.
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const WINDOW = 262144;
const WINDOW_TXT = '262,144';
const PLAIN_CAP = 512 * 1024;
const ARCHIVE_CAP = 4 * 1024 * 1024;
const PLAIN_EXTS = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ZIP_EXTS = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'];
const NB_EXTS = ['.ipynb'];
const PROSE_EXTS = PLAIN_EXTS.concat(ZIP_EXTS, NB_EXTS);
const LEDGER_MAX_AGE_DAYS = 7;
const LEDGER_KEEP = 50;

function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}
function pluginRoot() {
  if (process.env.CLAUDE_PLUGIN_ROOT) return process.env.CLAUDE_PLUGIN_ROOT;
  return path.resolve(__dirname, '..');
}
function flagPath() { return path.join(configDir(), '.prosecheck-active'); }

function envDefault() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  return LEVELS.includes(v) ? v : null;
}
function readStoredLevel() {
  try {
    const v = fs.readFileSync(flagPath(), 'utf8').trim().toLowerCase();
    return LEVELS.includes(v) ? v : null;
  } catch (e) { return null; }
}
function getLevel() { return readStoredLevel() || envDefault() || 'full'; }
function flagExists() { try { fs.statSync(flagPath()); return true; } catch (e) { return false; } }
function setLevel(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), level);
    return true;
  } catch (e) { return false; }
}

function readStdinJson() {
  let raw = '';
  try { raw = fs.readFileSync(0, 'utf8'); } catch (e) { raw = ''; }
  try {
    const v = JSON.parse(raw);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : {};
  } catch (e) { return {}; }
}

// ---------------------------------------------------------------- contract
const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster',
  'underscore', 'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament',
  'vibrant', 'comprehensive', 'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock',
  'game-changer', 'supercharge', 'genuinely', 'fascinating', 'nuanced'];

function contractRules() {
  return [
    'Scope: prose deliverables only (documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and drafted text the user will publish or send).',
    'It never touches source code, code comments, commit messages, JSON/YAML/config, CLI output, logs, error messages, or the conversational register of chat. A chat-compression mode owns chat; a code-simplicity mode owns code; this contract owns deliverable prose.',
    'Vary sentence length irregularly. No metronome rhythm and no mechanical short-long alternation.',
    'Banned vocabulary: ' + BANNED.join(', ') + '.',
    'Banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting ("let\'s dive in"), empty pivots ("it\'s worth noting"), "In conclusion" and "Overall" closers, outcome-speculation tails, self-thoroughness, generic upbeat endings, and chatbot phrases ("I hope this helps").',
    'Use an em dash at most once per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.',
    'Factual and encyclopedic content stays neutral third person. First-person and opinion content may use contractions.',
    'Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.',
    'End sections on a fact or observation.',
    'Stay silent about this contract: never announce it, never name prosecheck, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.',
  ];
}

function detectorStep(level, portable) {
  if (level === 'lite') return [];
  const lines = [];
  const target = level === 'strict'
    ? 'the clean band (score at most 20)'
    : 'the clean or light tells band (score at most 40)';
  lines.push('After writing a prose file, run the prosecheck detector on that file. When the band is worse than ' + target + ', fix the flagged spans, keeping rhythm variation, with at most two fix passes.');
  if (level === 'strict') {
    lines.push('Finish by passing the final text through the detector with --clean to scrub invisible characters and odd spaces.');
  }
  return lines;
}

function contractFor(level, opts) {
  opts = opts || {};
  const portable = !!opts.portable;
  const out = ['# Writing contract (' + level + ')', ''];
  contractRules().forEach(function (r) { out.push('- ' + r); });
  const step = detectorStep(level, portable);
  if (step.length) {
    out.push('');
    step.forEach(function (r) { out.push(r); });
    if (portable) {
      out.push('Detector location: use CLAUDE_PLUGIN_ROOT when that variable is set; otherwise locate prosecheck\'s detector in the installed skills or plugins.');
    } else {
      const det = detectorPath();
      if (det) out.push('Detector command: python3 "' + det + '" <file>');
    }
  }
  return out.join('\n') + '\n';
}

const WELCOME = [
  'prosecheck is installed and on. Saved prose is scored against 71 documented AI-writing patterns.',
  'Plain text is accepted up to 512 KB and archives up to 4 MB; the detector scores the first 262,144 characters.',
  'Try /prosecheck doctor, /prosecheck check, /prosecheck off, or /prosecheck help.',
  'There is no website and no upload; everything stays on this machine. This welcome is shown once.',
  '',
].join('\n');

const SECTION_BEGIN = '<!-- prosecheck:begin -->';
const SECTION_END = '<!-- prosecheck:end -->';

function cursorRule() {
  const body = [
    '---',
    'description: Writing contract for prose deliverables only',
    'globs: ["**/*.md", "**/*.mdx", "**/*.markdown", "**/*.txt", "**/*.rst", "**/*.tex", "**/*.org", "**/*.adoc"]',
    'alwaysApply: false',
    '---',
    '',
    '# Writing contract',
    '',
  ];
  contractRules().forEach(function (r) { body.push('- ' + r); });
  body.push('');
  body.push('This rule covers prose deliverables only.');
  return body.join('\n') + '\n';
}

// ---------------------------------------------------------------- detector
function detectorPath() {
  const root = pluginRoot();
  const a = path.join(root, 'scripts', 'detect.py');
  const b = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  try { if (fs.statSync(a).isFile()) return a; } catch (e) { /* next */ }
  try { if (fs.statSync(b).isFile()) return b; } catch (e) { /* none */ }
  return null;
}

// Run python with args. Returns {missing, timedOut, status, stdout, stderr}
function runPython(args, input, timeoutMs) {
  const names = ['python3', 'python', 'py'];
  let anySpawned = false;
  for (const name of names) {
    const r = cp.spawnSync(name, args, {
      input: input === undefined ? undefined : Buffer.from(input, 'utf8'),
      timeout: timeoutMs, maxBuffer: 256 * 1024 * 1024, encoding: 'utf8',
      env: Object.assign({}, process.env, { PYTHONIOENCODING: 'utf-8', PYTHONUTF8: '1' }),
      windowsHide: true,
    });
    if (r.error && (r.error.code === 'ENOENT' || r.error.code === 'EACCES')) continue;
    anySpawned = true;
    if (r.error && r.error.code === 'ETIMEDOUT') return { timedOut: true, stdout: '', stderr: '' };
    if (r.error) return { status: 1, stdout: r.stdout || '', stderr: String(r.error.message || '') };
    if (r.signal && r.status === null) return { timedOut: true, stdout: r.stdout || '', stderr: r.stderr || '' };
    return { status: r.status, stdout: r.stdout || '', stderr: r.stderr || '' };
  }
  return { missing: !anySpawned };
}

function parseReport(stdout) {
  let obj;
  try { obj = JSON.parse(stdout); } catch (e) { return { kind: 'text' }; }
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return { kind: 'text' };
  const m = obj._metrics;
  if (!m || typeof m !== 'object' || typeof m.ai_tell_score !== 'number') return { kind: 'noscore' };
  const findings = [];
  Object.keys(obj).forEach(function (k) {
    if (k === '_metrics') return;
    const f = obj[k];
    if (f && typeof f === 'object') findings.push({ key: k, label: String(f.label || k), count: f.count | 0 });
  });
  return { kind: 'ok', metrics: m, findings: findings };
}

// ---------------------------------------------------------------- phrases
function phraseFor(band) {
  switch (band) {
    case 'clean': return 'reads clean';
    case 'light tells': return 'reads mostly clean';
    case 'mixed': return 'reads with some AI tells';
    case 'heavy tells': return 'reads with heavy AI tells';
    default: return 'reads with pervasive AI tells';
  }
}

// ---------------------------------------------------------------- ledger
function sanitizeId(id) { return String(id).replace(/[^A-Za-z0-9._-]/g, '_').slice(0, 120); }
function ledgerPath(sessionId) {
  const base = '.prosecheck-ledger';
  return path.join(configDir(), sessionId ? base + '-' + sanitizeId(sessionId) : base);
}
function ageDays(file) {
  try { return (Date.now() - fs.statSync(file).mtimeMs) / 86400000; } catch (e) { return 0; }
}
function readLedger(sessionId) {
  const p = ledgerPath(sessionId);
  try {
    if (Math.floor(ageDays(p)) > LEDGER_MAX_AGE_DAYS) { try { fs.unlinkSync(p); } catch (e) { /* */ } return []; }
    const arr = JSON.parse(fs.readFileSync(p, 'utf8'));
    return Array.isArray(arr) ? arr : [];
  } catch (e) { return []; }
}
function appendLedger(sessionId, rec) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    const arr = readLedger(sessionId);
    rec.t = Date.now();
    arr.push(rec);
    fs.writeFileSync(ledgerPath(sessionId), JSON.stringify(arr.slice(-LEDGER_KEEP)));
  } catch (e) { /* ledger is best effort */ }
}
function pruneLedgers() {
  try {
    const dir = configDir();
    fs.readdirSync(dir).forEach(function (n) {
      if (n === '.prosecheck-ledger' || n.indexOf('.prosecheck-ledger-') === 0) {
        const p = path.join(dir, n);
        if (Math.floor(ageDays(p)) > LEDGER_MAX_AGE_DAYS) { try { fs.unlinkSync(p); } catch (e) { /* */ } }
      }
    });
  } catch (e) { /* none */ }
}

module.exports = {
  LEVELS, WINDOW, WINDOW_TXT, PLAIN_CAP, ARCHIVE_CAP, PLAIN_EXTS, ZIP_EXTS, NB_EXTS, PROSE_EXTS,
  configDir, pluginRoot, flagPath, envDefault, readStoredLevel, getLevel, flagExists, setLevel,
  readStdinJson, BANNED, contractFor, WELCOME, SECTION_BEGIN, SECTION_END, cursorRule,
  detectorPath, runPython, parseReport, phraseFor, readLedger, appendLedger, pruneLedgers, ledgerPath,
};
