#!/usr/bin/env node
'use strict';
// Session statistics: token totals from the transcript and the score of the session's own prose.
const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib.js');

function newestTranscript(dir) {
  let best = null;
  function walk(d, depth) {
    let ents = [];
    try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    ents.forEach(function (en) {
      const p = path.join(d, en.name);
      if (en.isDirectory()) { if (depth < 6) walk(p, depth + 1); }
      else if (en.isFile() && en.name.endsWith('.jsonl')) {
        try {
          const m = fs.statSync(p).mtimeMs;
          if (!best || m > best.m) best = { p: p, m: m };
        } catch (e) { /* skip */ }
      }
    });
  }
  walk(dir, 0);
  return best ? best.p : null;
}

function fmt(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }

function stripFences(t) {
  return t.replace(/^[ \t]{0,3}(`{3,}|~{3,})[^\n]*\n[\s\S]*?(?:\n[ \t]{0,3}\1[`~]*[ \t]*(?=\n|$)|$)/gm, '');
}

function statsReply(transcriptPath) {
  const level = lib.getLevel();
  let file = null;
  if (transcriptPath && typeof transcriptPath === 'string') file = transcriptPath;
  else file = newestTranscript(path.join(lib.configDir(), 'projects'));
  if (!file) return 'level: ' + level + '\nNo session transcript was found, so there are no figures to show.';
  let raw;
  try {
    if (!fs.statSync(file).isFile()) throw new Error('not a file');
    raw = fs.readFileSync(file, 'utf8');
  } catch (e) { return 'level: ' + level + '\nThe session transcript could not be read, so there are no figures to show.'; }
  const msgs = new Map();
  let anon = 0;
  raw.split(/\r?\n/).forEach(function (line) {
    if (!line.trim()) return;
    let row;
    try { row = JSON.parse(line); } catch (e) { return; }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') return;
    const m = row.message;
    const id = typeof m.id === 'string' && m.id ? m.id : '#anon' + (anon++);
    let rec = msgs.get(id);
    if (!rec) { rec = { out: 0, cache: 0, texts: [] }; msgs.set(id, rec); }
    const u = m.usage && typeof m.usage === 'object' ? m.usage : {};
    const o = Number(u.output_tokens) || 0;
    const c = Number(u.cache_read_input_tokens) || 0;
    if (o > rec.out) rec.out = o;
    if (c > rec.cache) rec.cache = c;
    if (typeof m.content === 'string') rec.texts.push(m.content);
    else if (Array.isArray(m.content)) {
      m.content.forEach(function (b) { if (b && b.type === 'text' && typeof b.text === 'string') rec.texts.push(b.text); });
    }
  });
  let turns = 0, out = 0, cache = 0;
  const texts = [];
  msgs.forEach(function (r) { turns++; out += r.out; cache += r.cache; r.texts.forEach(function (t) { texts.push(t); }); });
  const lines = [
    'level: ' + level,
    'assistant turns: ' + turns,
    'output tokens: ' + out,
    'cache-read input tokens: ' + cache,
  ];
  let prose = stripFences(texts.join('\n'));
  if (prose.length > 40000) prose = prose.slice(prose.length - 40000);
  if (prose.trim().length > 500) {
    const det = lib.detectorPath();
    if (det) {
      const r = lib.runPython([det], prose, 15000);
      if (r && !r.missing && !r.timedOut && r.stdout) {
        const rep = lib.parseReport(r.stdout);
        if (rep.kind === 'ok') lines.push('session prose ai_tell_score: ' + rep.metrics.ai_tell_score);
      }
    }
  }
  return lines.join('\n');
}

module.exports = { statsReply };

if (require.main === module) {
  try {
    const p = lib.readStdinJson();
    process.stdout.write(statsReply(p.transcript_path) + '\n');
  } catch (e) { /* never fail */ }
  process.exit(0);
}
