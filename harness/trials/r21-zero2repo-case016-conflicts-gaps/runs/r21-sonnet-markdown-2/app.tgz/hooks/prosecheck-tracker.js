#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib.js');

const SUBS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason: reason }));
}

function helpReply() {
  const level = lib.getLevel();
  return [
    'prosecheck level: ' + level,
    'Code, commits, config, and chat are never touched; only prose deliverables follow the contract.',
    '',
    '/prosecheck lite - turn on the writing contract without scoring saved files',
    '/prosecheck full - contract plus the saved-file guard at threshold 40 (default)',
    '/prosecheck strict - contract plus a stricter guard at threshold 20 and a cleanup scrub',
    '/prosecheck off | on - disable / re-enable prosecheck',
    '/prosecheck status - show the current level',
    '/prosecheck show - list the files scored in this session',
    '/prosecheck check <file> - score one file (report only; it does not rewrite the file)',
    '/prosecheck doctor - health check of the install',
    '/prosecheck stats - token figures and the prose score of this session',
    '/prosecheck init - export the contract to AGENTS.md for agents other than Claude Code',
    '',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function stripPathArg(arg) {
  let p = (arg || '').trim();
  if (p.startsWith('@')) p = p.slice(1).trim();
  if (p.length >= 2 && ((p[0] === '"' && p[p.length - 1] === '"') || (p[0] === "'" && p[p.length - 1] === "'"))) {
    p = p.slice(1, -1);
  }
  return p.trim();
}

function kbOf(n) { return String(n / 1024); }

function checkReply(arg, payload) {
  if (!arg || !arg.trim()) return 'Give a file path to check, for example: /prosecheck check notes.md';
  const typed = stripPathArg(arg);
  if (!typed) return 'Give a file path to check, for example: /prosecheck check notes.md';
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const abs = path.resolve(cwd, typed);
  const base = path.basename(abs);
  let st;
  try { st = fs.statSync(abs); } catch (e) { return 'cannot read ' + typed; }
  if (!st.isFile()) return typed + ' is not a file';
  const ext = path.extname(base).toLowerCase();
  if (ext === '.pdf' || ext === '.rtf') return base + ' has no readable text for prosecheck';
  const archive = lib.ZIP_EXTS.indexOf(ext) >= 0 || lib.NB_EXTS.indexOf(ext) >= 0;
  const cap = archive ? lib.ARCHIVE_CAP : lib.PLAIN_CAP;
  if (st.size > cap) return base + ' was not scored: it is over ' + kbOf(cap) + ' KB.';
  const det = lib.detectorPath();
  if (!det) return 'detector unavailable: the bundled script was not found.';
  const r = lib.runPython([det, '--', abs], undefined, 20000);
  if (r.missing) return 'detector unavailable: Python was not found on PATH.';
  if (r.timedOut) return base + ' failed: the detector timed out.';
  if (r.status !== 0) {
    const err = (r.stderr || '').trim();
    return base + ' failed: ' + (err || 'the detector exited with status ' + r.status);
  }
  if (!r.stdout || !r.stdout.trim()) return base + ': no report came back from the detector.';
  const rep = lib.parseReport(r.stdout);
  if (rep.kind !== 'ok') return 'no report: the detector printed text that is not a report.';
  const m = rep.metrics;
  const lines = [];
  lines.push(base + ' - ' + lib.phraseFor(m.ai_tell_band) + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')');
  let conf = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && m.confidence_reason) conf += ' - ' + m.confidence_reason;
  lines.push(conf);
  if (m.truncated) lines.push('coverage: first ' + lib.WINDOW_TXT + ' characters only');
  if (rep.findings.length) {
    lines.push('tells: ' + rep.findings.slice(0, 8).map(function (f) { return f.label + ' (x' + f.count + ')'; }).join('; '));
  } else lines.push('tells: none');
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

function doctorReply(form) {
  const level = lib.getLevel();
  const lines = [];
  lines.push('prosecheck doctor');
  const modeOk = level !== 'off';
  lines.push(modeOk ? '[OK] mode: ' + level : '[--] mode: off (switched off; run /prosecheck on to re-enable)');
  const det = lib.detectorPath();
  lines.push(det ? '[OK] detector: bundled script present' : '[FAIL] detector: bundled script missing from the plugin tree');
  let pyOk = false;
  if (!det) {
    lines.push('[FAIL] python: there is no bundled script to run');
  } else {
    const r = lib.runPython([det], 'A short plain sentence for the health check. It has a few words in it, nothing more.\n', 15000);
    if (r.missing) {
      lines.push('[FAIL] python not found: prose is still shaped by the writing contract, but saved files are not re-scored until Python is available');
    } else {
      const rep = r.timedOut ? { kind: 'text' } : lib.parseReport(r.stdout || '');
      if (rep.kind === 'ok') { pyOk = true; lines.push('[OK] python: ran the bundled script and got a numeric score'); }
      else lines.push('[FAIL] python: ran, but the result was not a numeric score');
    }
  }
  let setOk = false;
  try {
    const dir = lib.configDir();
    fs.mkdirSync(dir, { recursive: true });
    const tmp = path.join(dir, '.prosecheck-write-test-' + process.pid);
    fs.writeFileSync(tmp, 'x');
    fs.unlinkSync(tmp);
    setOk = true;
  } catch (e) { setOk = false; }
  lines.push(setOk ? '[OK] settings: folder is writable' : '[FAIL] settings: folder is not writable');
  const faulty = !det || !pyOk || !setOk;
  let closer;
  if (faulty) closer = 'Please fix the faulty checks above, then run /prosecheck doctor again.';
  else if (!modeOk) closer = 'The install is healthy. prosecheck is switched off, so saving files triggers no scoring; run ' + form + ' on to turn it back on and have files scored again.';
  else closer = 'prosecheck is active. Plain text up to 512 KB, archives up to 4 MB, and the first 262,144 characters are scanned. Use ' + form + ' show to see files that were only partly scanned or skipped.';
  lines.push(closer);
  return lines.join('\n');
}

function showReply(sessionId) {
  const recs = lib.readLedger(sessionId);
  if (!recs.length) {
    return 'nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const lines = ['Files seen this session (newest first):'];
  recs.map(function (r, i) { return { r: r, i: i }; }).sort(function (a, b) { return ((b.r.t || 0) - (a.r.t || 0)) || (b.i - a.i); }).map(function (x) { return x.r; }).forEach(function (r) {
    let body;
    if (r.kind === 'scored') {
      body = lib.phraseFor(r.band) + ' (score ' + r.score + '/' + r.band + (r.truncated ? ', first ' + lib.WINDOW_TXT + ' characters only' : '') + ')';
      if (Array.isArray(r.labels) && r.labels.length) {
        body += ' - ' + (r.flagged ? 'flagged' : 'under the threshold') + ': ' + r.labels.slice(0, 5).join('; ');
      }
    } else if (r.kind === 'skipped') {
      body = 'not scored: it exceeds the limit of ' + r.limitKB + ' KB';
    } else if (r.kind === 'binary') {
      body = 'binary file, not re-scored';
    } else {
      body = 'not scored: ' + (r.reason || 'the check failed');
    }
    lines.push('  ' + r.base + ' - ' + body);
  });
  return lines.join('\n');
}

function initReply(form) {
  const level = lib.getLevel();
  if (level === 'off') {
    return 'prosecheck is switched off, so nothing was exported. Run ' + form + ' on first, then ' + form + ' init again.';
  }
  const out = [];
  const cwd = process.cwd();
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = '';
  let readable = true;
  try { existing = fs.readFileSync(agents, 'utf8'); }
  catch (e) { if (e.code !== 'ENOENT') readable = false; }
  if (!readable) {
    out.push('cannot read AGENTS.md, so the contract was not written (cannot write it safely).');
  } else if (existing.indexOf(lib.SECTION_BEGIN) >= 0 || existing.indexOf('# Writing contract (') >= 0) {
    out.push('AGENTS.md already contains the prosecheck writing contract; left unchanged.');
  } else {
    const section = lib.SECTION_BEGIN + '\n' + lib.contractFor(level, { portable: true }) + lib.SECTION_END + '\n';
    let sep = '';
    if (existing.length) sep = existing.endsWith('\n\n') ? '' : (existing.endsWith('\n') ? '\n' : '\n\n');
    try {
      fs.writeFileSync(agents, existing + sep + section);
      out.push('AGENTS.md: wrote the ' + level + ' writing contract.');
    } catch (e) { out.push('cannot write AGENTS.md (' + (e.code || 'error') + '); the contract was not exported.'); }
  }
  const rule = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(rule)) {
    out.push('.cursor/rules/prosecheck.mdc already exists; left unchanged.');
  } else {
    try {
      let content = null;
      try { content = fs.readFileSync(path.join(lib.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc')); } catch (e) { content = null; }
      if (content === null) content = Buffer.from(lib.cursorRule(), 'utf8');
      fs.mkdirSync(path.dirname(rule), { recursive: true });
      fs.writeFileSync(rule, content);
      out.push('.cursor/rules/prosecheck.mdc: copied the Cursor rule.');
    } catch (e) { out.push('cannot write .cursor/rules/prosecheck.mdc (' + (e.code || 'error') + ').'); }
  }
  return out.join('\n');
}

function handle(payload) {
  const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
  const trimmed = prompt.trim();
  const low = trimmed.toLowerCase();
  if (low === 'stop prosecheck' || low === 'prosecheck off') {
    lib.setLevel('off');
    return block('prosecheck is now off.');
  }
  const m = /^\/prosecheck(:prosecheck)?(?:\s+([\s\S]*))?$/i.exec(trimmed);
  if (!m) {
    const level = lib.getLevel();
    if (level === 'off') return;
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: {
        hookEventName: 'UserPromptSubmit',
        additionalContext: 'prosecheck level ' + level + ': prose deliverables follow the writing contract; code, config, and commits are untouched.',
      },
    }));
    return;
  }
  const form = m[1] ? '/prosecheck:prosecheck' : '/prosecheck';
  const rest = (m[2] || '').trim();
  const sp = rest.search(/\s/);
  const word = (sp < 0 ? rest : rest.slice(0, sp)).toLowerCase();
  const arg = sp < 0 ? '' : rest.slice(sp + 1).trim();
  const sid = typeof payload.session_id === 'string' ? payload.session_id : '';
  if (!word || word === 'help') return block(helpReply());
  if (SUBS.indexOf(word) < 0) {
    return block('unknown subcommand "' + word + '". Valid subcommands: ' + SUBS.join(', ') + '.');
  }
  switch (word) {
    case 'lite': case 'full': case 'strict':
      lib.setLevel(word);
      return block('prosecheck level set to ' + word + '.');
    case 'off':
      lib.setLevel('off');
      return block('prosecheck is now off.');
    case 'on':
      lib.setLevel('full');
      return block('prosecheck is on (full).');
    case 'status':
      return block('prosecheck level: ' + lib.getLevel());
    case 'show': return block(showReply(sid));
    case 'check': return block(checkReply(arg, payload));
    case 'doctor': return block(doctorReply(form));
    case 'init': return block(initReply(form));
    case 'stats': {
      const stats = require('./prosecheck-stats.js');
      return block(stats.statsReply(typeof payload.transcript_path === 'string' && payload.transcript_path ? payload.transcript_path : null));
    }
  }
}

try {
  handle(lib.readStdinJson());
} catch (e) { /* never fail the host */ }
process.exit(0);
