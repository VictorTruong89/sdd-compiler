#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib.js');

const MAX_PATHS = 10;
const INSTR_NAMES = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
const INSTR_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];

function extractPaths(payload) {
  const ti = payload.tool_input && typeof payload.tool_input === 'object' ? payload.tool_input : {};
  const out = [];
  if (typeof ti.file_path === 'string' && ti.file_path.trim()) out.push(ti.file_path.trim());
  if (typeof ti.notebook_path === 'string' && ti.notebook_path.trim()) out.push(ti.notebook_path.trim());
  const body = typeof ti.command === 'string' ? ti.command : (typeof ti.input === 'string' ? ti.input : (typeof ti.patch === 'string' ? ti.patch : ''));
  if (body) {
    const re = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/gm;
    let m;
    while ((m = re.exec(body)) !== null) {
      const p = m[1].replace(/\r$/, '').trim();
      if (p) out.push(p);
    }
  }
  const seen = [];
  out.forEach(function (p) { if (seen.indexOf(p) < 0) seen.push(p); });
  return seen;
}

function isInside(child, parent) {
  const rel = path.relative(path.resolve(parent), path.resolve(child));
  return rel !== '' && !rel.startsWith('..') && !path.isAbsolute(rel);
}

function classify(abs) {
  // returns 'skip' | 'ignore' | 'binary' | 'plain' | 'archive'
  const segs = abs.split(/[\\/]+/);
  if (segs.indexOf('node_modules') >= 0 || segs.indexOf('.git') >= 0) return 'skip';
  if (isInside(abs, lib.pluginRoot())) return 'skip';
  const base = path.basename(abs);
  const lower = base.toLowerCase();
  const ext = path.extname(lower);
  const stem = ext ? lower.slice(0, -ext.length) : lower;
  if (INSTR_NAMES.indexOf(lower) >= 0) return 'skip';
  if (lib.PROSE_EXTS.indexOf(ext) < 0 && INSTR_STEMS.indexOf(stem) >= 0) return 'skip';
  if (ext === '.pdf' || ext === '.rtf') return 'binary';
  if (lib.PLAIN_EXTS.indexOf(ext) >= 0) return 'plain';
  if (lib.ZIP_EXTS.indexOf(ext) >= 0 || lib.NB_EXTS.indexOf(ext) >= 0) return 'archive';
  return 'ignore';
}

function failed(sid, base, reason) {
  lib.appendLedger(sid, { base: base, kind: 'failed', reason: reason });
}

function scoreOne(abs, kind, threshold, sid) {
  const base = path.basename(abs);
  let st;
  try { st = fs.statSync(abs); } catch (e) { failed(sid, base, 'file could not be read'); return null; }
  if (!st.isFile()) return null;
  const cap = kind === 'plain' ? lib.PLAIN_CAP : lib.ARCHIVE_CAP;
  if (st.size > cap) {
    lib.appendLedger(sid, { base: base, kind: 'skipped', limitKB: cap / 1024 });
    return null;
  }
  const det = lib.detectorPath();
  if (!det) { failed(sid, base, 'bundled detector not found'); return null; }
  const secs = kind === 'plain' ? 8 : 15;
  const r = lib.runPython([det, '--', abs], undefined, secs * 1000);
  if (r.missing) { failed(sid, base, 'Python not found'); return null; }
  if (r.timedOut) { failed(sid, base, 'detector timed out'); return null; }
  if (!r.stdout || !r.stdout.trim()) { failed(sid, base, 'detector produced no result'); return null; }
  const rep = lib.parseReport(r.stdout);
  if (rep.kind === 'text') { failed(sid, base, 'detector printed text that is not a structured report'); return null; }
  if (rep.kind === 'noscore') { failed(sid, base, 'report had no numeric score'); return null; }
  const m = rep.metrics;
  const labels = rep.findings.map(function (f) { return f.label; }).slice(0, 5);
  const flagged = m.ai_tell_score > threshold;
  lib.appendLedger(sid, {
    base: base, kind: 'scored', score: m.ai_tell_score, band: m.ai_tell_band, labels: labels,
    flagged: flagged, truncated: !!m.truncated,
  });
  if (!flagged) return null;
  const phrase = lib.phraseFor(m.ai_tell_band);
  const cov = m.truncated ? ', first ' + lib.WINDOW_TXT + ' characters only' : '';
  return 'prosecheck: ' + base + ' ' + phrase + ' (score ' + m.ai_tell_score + ', band ' + m.ai_tell_band + cov +
    '). Flagged: ' + labels.join('; ') + '. Please fix the flagged spans and keep the rhythm varied.';
}

try {
  const payload = lib.readStdinJson();
  const level = lib.getLevel();
  if (level === 'full' || level === 'strict') {
    const threshold = level === 'strict' ? 20 : 40;
    const sid = typeof payload.session_id === 'string' ? payload.session_id : '';
    const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
    const tn = typeof payload.tool_name === 'string' ? payload.tool_name : '';
    let paths = extractPaths(payload);
    if (tn && !/^(write|edit|multiedit|notebookedit|apply_patch)$/i.test(tn)) paths = [];
    paths = paths.slice(0, MAX_PATHS);
    const lines = [];
    paths.forEach(function (p) {
      try {
        const abs = path.resolve(cwd, p);
        const kind = classify(abs);
        if (kind === 'skip' || kind === 'ignore') return;
        if (kind === 'binary') {
          lib.appendLedger(sid, { base: path.basename(abs), kind: 'binary' });
          return;
        }
        const line = scoreOne(abs, kind, threshold, sid);
        if (line) lines.push(line);
      } catch (e) { /* one file never breaks the rest */ }
    });
    if (lines.length) {
      process.stdout.write(JSON.stringify({
        hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
      }));
    }
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
