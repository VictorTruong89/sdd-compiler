#!/usr/bin/env node
'use strict';
const lib = require('./prosecheck-lib.js');

try {
  lib.readStdinJson();
  const existed = lib.flagExists();
  let level = lib.getLevel();
  if (!existed || !lib.readStoredLevel()) {
    // fresh install (or unusable flag): remember the level for later hooks
    if (!existed) lib.setLevel(level);
  }
  lib.pruneLedgers();
  if (level !== 'off') {
    const welcome = existed ? '' : lib.WELCOME + '\n';
    process.stdout.write(welcome + lib.contractFor(level));
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
