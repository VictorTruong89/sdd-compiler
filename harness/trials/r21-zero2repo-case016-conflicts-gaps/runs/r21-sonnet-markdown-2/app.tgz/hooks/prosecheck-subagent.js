#!/usr/bin/env node
'use strict';
const lib = require('./prosecheck-lib.js');

try {
  lib.readStdinJson();
  const level = lib.getLevel();
  if (level !== 'off') {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext: lib.contractFor(level) },
    }));
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
