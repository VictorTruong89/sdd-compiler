---
name: prosecheck
description: Rewrite flagged prose so it reads less like AI writing. Use when asked to "prosecheck this" or "humanize this".
---
# prosecheck

Run `python3 scripts/detect.py <file>` (from the plugin root) to score a prose file, then rewrite the flagged spans
in plain, varied prose. Preserve numbers, dates, names, quotes, and technical terms. Never invent facts. Never touch
code, comments, commits, or configuration. Do not mention the score to the reader of the final text.
