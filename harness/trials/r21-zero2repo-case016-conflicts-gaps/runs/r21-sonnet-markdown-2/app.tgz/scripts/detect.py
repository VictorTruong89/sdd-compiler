#!/usr/bin/env python3
"""prosecheck detector: local AI-writing pattern scanner. Standard library only."""
import json
import math
import os
import random
import re
import sys
from collections import Counter

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))


# ===== character layer =====
"""Character layer: invisible characters, non-standard spaces, homoglyphs, trailing whitespace, cleanup."""
import re
import unicodedata

# --- invisible candidates -------------------------------------------------
_INVIS_RANGES = [
    (0x0000, 0x0008), (0x000B, 0x000C), (0x000E, 0x001F), (0x007F, 0x009F),
    (0x00AD, 0x00AD), (0x034F, 0x034F), (0x061C, 0x061C), (0x115F, 0x1160),
    (0x17B4, 0x17B5), (0x180B, 0x180F), (0x200B, 0x200F), (0x202A, 0x202E),
    (0x2060, 0x206F), (0x3164, 0x3164), (0xFE00, 0xFE0F), (0xFEFF, 0xFEFF),
    (0xFFA0, 0xFFA0), (0xFFF0, 0xFFFB), (0x110CD, 0x110CD), (0x13430, 0x1343F),
    (0x1BCA0, 0x1BCA3), (0x1D173, 0x1D17A), (0xE0000, 0xE0FFF),
]


def _cls(ranges):
    out = []
    for a, b in ranges:
        out.append(chr(a) if a == b else chr(a) + "-" + chr(b))
    return "[" + "".join(out) + "]"


INVIS_RE = re.compile(_cls(_INVIS_RANGES))
TAG_RUN_RE = re.compile("[\U000E0000-\U000E00FF\U000E01F0-\U000E0FFF]+")
SPACE_RE = re.compile("[\u00a0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000]")

RTL_RE = re.compile("[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufefe]")

_NOSPACE = [(0x0E00, 0x0EFF), (0x1780, 0x17FF), (0x1000, 0x109F), (0x3040, 0x30FF),
            (0x31F0, 0x31FF), (0xFF66, 0xFF9F), (0x3400, 0x4DBF), (0x4E00, 0x9FFF),
            (0xF900, 0xFAFF), (0x20000, 0x2FFFF)]
_JOINING = [(0x0590, 0x06FF), (0x0700, 0x077F), (0x08A0, 0x08FF), (0xFB1D, 0xFDFF),
            (0xFE70, 0xFEFF), (0x0900, 0x0DFF), (0x1000, 0x109F), (0x1780, 0x17FF)]
_CJK = [(0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x2FFFF)]
_EMOJI = [(0x1F000, 0x1FAFF), (0x2190, 0x21FF), (0x2300, 0x23FF), (0x2600, 0x27BF),
          (0x2900, 0x297F), (0x2B00, 0x2BFF), (0x3030, 0x3030), (0x303D, 0x303D),
          (0x3297, 0x3299), (0x00A9, 0x00A9), (0x00AE, 0x00AE), (0x203C, 0x203C),
          (0x2049, 0x2049), (0x2122, 0x2122), (0x2139, 0x2139), (0x20E3, 0x20E3),
          (0xFE0E, 0xFE0F)]
_MONGOLIAN = [(0x1820, 0x1878), (0x1880, 0x18AA)]
_KHMER = [(0x1780, 0x17FF)]


def _in(c, ranges):
    o = ord(c)
    for a, b in ranges:
        if a <= o <= b:
            return True
    return False


def _symbolish(c):
    if _in(c, _EMOJI):
        return True
    return unicodedata.category(c)[0] == "S"


def _kept(text, i, has_rtl):
    c = text[i]
    o = ord(c)
    prev = text[i - 1] if i > 0 else ""
    nxt = text[i + 1] if i + 1 < len(text) else ""
    if o == 0x200B:
        return (prev and _in(prev, _NOSPACE)) or (nxt and _in(nxt, _NOSPACE))
    if o == 0x00AD:
        return bool(prev and nxt and prev.isalpha() and nxt.isalpha())
    if o in (0x200E, 0x200F, 0x061C) or 0x202A <= o <= 0x202E or 0x2066 <= o <= 0x2069:
        return has_rtl
    if 0x180B <= o <= 0x180F:
        return bool(prev and _in(prev, _MONGOLIAN))
    if o in (0x17B4, 0x17B5):
        return bool((prev and _in(prev, _KHMER)) or (nxt and _in(nxt, _KHMER)))
    if o in (0x200C, 0x200D):
        for n in (prev, nxt):
            if n and (_in(n, _JOINING) or _symbolish(n)) and n not in ("\u200c", "\u200d"):
                return True
        return False
    if 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF:
        if nxt == "\u20e3":
            return True
        if prev and (_symbolish(prev) or _in(prev, _CJK)):
            return True
        return False
    return False


def invisible_positions(text):
    """Return (remove_positions list) for invisible characters not doing a job."""
    remove = []
    if not text:
        return remove
    has_rtl = None
    tag_keep = set()
    for m in TAG_RUN_RE.finditer(text):
        s, e = m.start(), m.end()
        if s > 0 and text[s - 1] == "\U0001F3F4" and text[e - 1] == "\U000E007F":
            tag_keep.add(s)
    tag_ranges = {}
    for m in TAG_RUN_RE.finditer(text):
        tag_ranges[m.start()] = m.end()
    skip_until = -1
    for m in INVIS_RE.finditer(text):
        i = m.start()
        o = ord(m.group())
        if i < skip_until:
            continue
        if i in tag_ranges and (o >= 0xE0000 and not (0xE0100 <= o <= 0xE01EF)):
            e = tag_ranges[i]
            if i in tag_keep:
                pass
            else:
                remove.extend(range(i, e))
            skip_until = e
            continue
        if has_rtl is None and (o in (0x200E, 0x200F, 0x061C) or 0x202A <= o <= 0x202E or 0x2066 <= o <= 0x2069):
            has_rtl = RTL_RE.search(text) is not None
        if not _kept(text, i, bool(has_rtl)):
            remove.append(i)
    return remove


def space_positions(text):
    out = []
    for m in SPACE_RE.finditer(text):
        i = m.start()
        c = m.group()
        if c in ("\u00a0", "\u202f"):
            prev = text[i - 1] if i > 0 else ""
            nxt = text[i + 1] if i + 1 < len(text) else ""
            if (prev and prev.isdigit()) or (nxt and nxt.isdigit()):
                continue
            if nxt and nxt in ":;!?»›%€":
                continue
            if prev and prev in "«‹":
                continue
        out.append(i)
    return out


# --- homoglyphs -----------------------------------------------------------
_LOOK = {}
for _s, _t in [
    ("\u0430\u0441\u0435\u043e\u0440\u0445\u0443\u0456\u0458\u0455\u0501\u04bb", "acepxyijsdh"),
    ("АВСЕНІЈКМОРЅТХҮ", "ABCEHIJKMOPSTXY"),
    ("ονρυαι", "ovpuai"),
    ("ΑΒΕΖΗΙΚΜΝΟΡΤΥΧ", "ABEZHIKMNOPTYX"),
    ("օսցոհ", "ougnh"),
    ("ﻩﮪﮬ", "ooo"),
]:
    for _a, _b in zip(_s, _t):
        _LOOK[_a] = _b


_TOKEN_RE = re.compile(r"\S+")


def _letter_runs(token):
    run_start = None
    for i, ch in enumerate(token):
        if ch.isalpha():
            if run_start is None:
                run_start = i
        else:
            if run_start is not None:
                yield run_start, i
                run_start = None
    if run_start is not None:
        yield run_start, len(token)


def homoglyph_runs(text):
    """Yield (abs_start, abs_end) of runs mixing ASCII letters with lookalikes."""
    if text.isascii():
        return []
    out = []
    for m in _TOKEN_RE.finditer(text):
        tok = m.group()
        if tok.isascii():
            continue
        for s, e in _letter_runs(tok):
            run = tok[s:e]
            ascii_n = 0
            look_n = 0
            other = False
            for ch in run:
                if ch.isascii():
                    ascii_n += 1
                elif ch in _LOOK:
                    look_n += 1
                else:
                    other = True
                    break
            if not other and ascii_n and look_n:
                out.append((m.start() + s, m.start() + e))
    return out


def homoglyph_count(runs, text):
    n = 0
    for s, e in runs:
        n += sum(1 for ch in text[s:e] if not ch.isascii())
    return n


# --- trailing whitespace --------------------------------------------------
def trailing_ws_hits(text):
    n = 0
    lines = text.split("\n")
    for ln in lines[:-1]:
        if ln and ln[-1] in " \t":
            n += 1
    if text.rstrip(" \t") != text:
        n += 1
    if len(text) - len(text.rstrip("\n")) >= 2:
        n += 1
    if text and text[0].isspace():
        n += 1
    return n


# --- cleanup --------------------------------------------------------------
def clean_text(text):
    remove = set(invisible_positions(text))
    spaces = set(space_positions(text))
    folds = {}
    for s, e in homoglyph_runs(text):
        for k in range(s, e):
            if text[k] in _LOOK:
                folds[k] = _LOOK[text[k]]
    out = []
    for i, ch in enumerate(text):
        if i in remove:
            continue
        if i in spaces:
            o = ord(ch)
            out.append("\n" if o in (0x2028, 0x2029) else " ")
            continue
        if i in folds:
            out.append(folds[i])
            continue
        out.append(ch)
    s = "".join(out)
    # strip any remaining line/paragraph separators (kept ones can't be)
    ended_lf = text.endswith("\n")
    crlf_end = text.endswith("\r\n")
    ls = s.split("\n")
    for i, ln in enumerate(ls):
        if ln.endswith("\r"):
            ls[i] = ln[:-1].rstrip(" \t") + "\r"
        else:
            ls[i] = ln.rstrip(" \t")
    s = "\n".join(ls)
    k = 0
    while True:
        j = s.find("\n", k)
        if j == -1 or s[k:j].strip(" \t\r") != "":
            break
        k = j + 1
    s = s[k:]
    s = s.rstrip()
    if ended_lf and s:
        s += "\r\n" if crlf_end else "\n"
    return s

# ===== extraction =====
"""Prose extraction from the twenty supported formats."""
import html
import io
import json
import re
import zipfile
from html.parser import HTMLParser
import posixpath

PLAIN_EXTS = {".md", ".mdx", ".markdown", ".txt", ".text", ".rst", ".tex", ".org", ".adoc"}
ZIP_EXTS = {".docx", ".docm", ".pptx", ".pptm", ".xlsx", ".xlsm", ".odt", ".odp", ".ods", ".epub"}
NB_EXTS = {".ipynb"}
MEMBER_CAP = 64 * 1024 * 1024


class NotReadable(Exception):
    pass


def decode_bytes(data):
    if data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        try:
            return data.decode("utf-16")
        except UnicodeError:
            return data[2:].decode("utf-16-le", errors="replace")
    if data[:3] == b"\xef\xbb\xbf":
        data = data[3:]
    text = data.decode("utf-8", errors="replace")
    return text


_EV = re.compile(r"<!--.*?-->|<!\[CDATA\[(.*?)\]\]>|<\?.*?\?>|<(/?)([^\s/>!?][^\s/>]*)([^>]*?)(/?)>|([^<]+)", re.S)
_ATTR = re.compile(r"([\w:.-]+)\s*=\s*(?:\"([^\"]*)\"|'([^']*)')")


def xml_events(s):
    for m in _EV.finditer(s):
        if m.group(1) is not None:
            yield ("text", m.group(1))
        elif m.group(3):
            name = m.group(3)
            if m.group(2):
                yield ("close", name)
            else:
                attrs = {}
                for a in _ATTR.finditer(m.group(4) or ""):
                    attrs[a.group(1)] = html.unescape(a.group(2) if a.group(2) is not None else a.group(3))
                yield ("open", name, attrs)
                if m.group(5):
                    yield ("close", name)
        elif m.group(6) is not None:
            yield ("text", html.unescape(m.group(6)))


def _read(z, name):
    info = z.getinfo(name)
    if info.file_size > MEMBER_CAP:
        return ""
    return z.read(name).decode("utf-8", errors="replace")


def _num_key(name):
    m = re.search(r"(\d+)", posixpath.basename(name))
    return (int(m.group(1)) if m else 0, name)


def extract_docx(z):
    names = z.namelist()
    if "word/document.xml" not in names:
        return ""
    paras = []
    cur = None
    in_t = False
    skip = 0
    for ev in xml_events(_read(z, "word/document.xml")):
        k = ev[0]
        if k == "open":
            n = ev[1]
            if n == "mc:Fallback":
                skip += 1
            elif skip:
                pass
            elif n == "w:p":
                cur = []
            elif n == "w:t":
                in_t = True
            elif n == "w:tab" and cur is not None:
                cur.append("\t")
            elif n in ("w:br", "w:cr") and cur is not None:
                cur.append("\n")
        elif k == "close":
            n = ev[1]
            if n == "mc:Fallback":
                skip = max(0, skip - 1)
            elif skip:
                pass
            elif n == "w:t":
                in_t = False
            elif n == "w:p" and cur is not None:
                paras.append("".join(cur))
                cur = None
        else:
            if in_t and cur is not None and not skip:
                cur.append(ev[1])
    return "\n".join(paras)


def extract_pptx(z):
    slides = sorted([n for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)], key=_num_key)
    out = []
    for n in slides:
        paras = []
        cur = None
        in_t = False
        for ev in xml_events(_read(z, n)):
            if ev[0] == "open":
                if ev[1] == "a:p":
                    cur = []
                elif ev[1] == "a:t":
                    in_t = True
                elif ev[1] == "a:br" and cur is not None:
                    cur.append("\n")
            elif ev[0] == "close":
                if ev[1] == "a:t":
                    in_t = False
                elif ev[1] == "a:p" and cur is not None:
                    paras.append("".join(cur))
                    cur = None
            elif in_t and cur is not None:
                cur.append(ev[1])
        t = "\n".join(p for p in paras if p.strip())
        if t.strip():
            out.append(t)
    return "\n".join(out)


def extract_xlsx(z):
    names = z.namelist()
    shared = []
    if "xl/sharedStrings.xml" in names:
        cur = None
        in_t = False
        rph = 0
        for ev in xml_events(_read(z, "xl/sharedStrings.xml")):
            if ev[0] == "open":
                if ev[1] == "si":
                    cur = []
                elif ev[1] == "rPh":
                    rph += 1
                elif ev[1] == "t":
                    in_t = True
            elif ev[0] == "close":
                if ev[1] == "si" and cur is not None:
                    shared.append("".join(cur))
                    cur = None
                elif ev[1] == "rPh":
                    rph = max(0, rph - 1)
                elif ev[1] == "t":
                    in_t = False
            elif in_t and cur is not None and not rph:
                cur.append(ev[1])
    sheets = sorted([n for n in names if re.match(r"xl/worksheets/[^/]+\.xml$", n)], key=_num_key)
    out = []
    for n in sheets:
        ctype = None
        vbuf = None
        isbuf = None
        in_v = in_t = False
        in_c = False
        for ev in xml_events(_read(z, n)):
            if ev[0] == "open":
                nm = ev[1]
                if nm == "c":
                    in_c = True
                    ctype = ev[2].get("t")
                    vbuf = []
                    isbuf = []
                elif nm == "v" and in_c:
                    in_v = True
                elif nm == "t" and in_c:
                    in_t = True
            elif ev[0] == "close":
                nm = ev[1]
                if nm == "v":
                    in_v = False
                elif nm == "t":
                    in_t = False
                elif nm == "c" and in_c:
                    in_c = False
                    v = "".join(vbuf).strip()
                    val = None
                    if ctype == "s":
                        if re.fullmatch(r"\d+", v) and int(v) < len(shared):
                            val = shared[int(v)]
                    elif ctype == "inlineStr":
                        val = "".join(isbuf)
                    elif ctype == "str":
                        val = "".join(vbuf)
                    if val is not None and val.strip():
                        out.append(val)
            else:
                if in_c and in_v:
                    vbuf.append(ev[1])
                elif in_c and in_t:
                    isbuf.append(ev[1])
    return "\n".join(out)


def extract_odf(z):
    if "content.xml" not in z.namelist():
        return ""
    paras = []
    cur = None
    depth = 0
    skip = 0
    for ev in xml_events(_read(z, "content.xml")):
        if ev[0] == "open":
            n = ev[1]
            if n in ("office:annotation", "text:tracked-changes"):
                skip += 1
            elif skip:
                continue
            elif n in ("text:p", "text:h"):
                if depth == 0:
                    cur = []
                depth += 1
            elif cur is not None and n == "text:s":
                try:
                    c = int(ev[2].get("text:c", "1"))
                except ValueError:
                    c = 1
                cur.append(" " * max(c, 1))
            elif cur is not None and n == "text:tab":
                cur.append("\t")
            elif cur is not None and n == "text:line-break":
                cur.append("\n")
        elif ev[0] == "close":
            n = ev[1]
            if n in ("office:annotation", "text:tracked-changes"):
                skip = max(0, skip - 1)
            elif skip:
                continue
            elif n in ("text:p", "text:h") and depth:
                depth -= 1
                if depth == 0 and cur is not None:
                    paras.append("".join(cur))
                    cur = None
        else:
            if cur is not None and not skip:
                cur.append(ev[1])
    return "\n".join(p for p in paras if p.strip())


class _Html(HTMLParser):
    BLOCK = {"p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "br", "tr", "blockquote",
             "section", "article", "pre", "ul", "ol", "table", "hr", "dd", "dt", "figcaption", "td", "th"}
    SKIP = {"script", "style", "nav", "head", "title", "svg", "noscript"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.skip = 0
        self.buf = []
        self.blocks = []

    def flush(self):
        t = re.sub(r"\s+", " ", "".join(self.buf)).strip()
        if t:
            self.blocks.append(t)
        self.buf = []

    def handle_starttag(self, tag, attrs):
        tag = tag.split(":")[-1].lower()
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.flush()

    def handle_startendtag(self, tag, attrs):
        tag = tag.split(":")[-1].lower()
        if tag in self.BLOCK:
            self.flush()

    def handle_endtag(self, tag):
        tag = tag.split(":")[-1].lower()
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
        elif tag in self.BLOCK:
            self.flush()

    def handle_data(self, data):
        if not self.skip:
            self.buf.append(data)


def _epub_order(z):
    names = z.namelist()
    html_names = [n for n in names if re.search(r"\.(x?html?)$", n, re.I)]
    try:
        cont = _read(z, "META-INF/container.xml")
        m = re.search(r'full-path\s*=\s*"([^"]+)"', cont)
        opf_path = m.group(1)
        opf = _read(z, opf_path)
        base = posixpath.dirname(opf_path)
        manifest = {}
        spine = []
        for ev in xml_events(opf):
            if ev[0] == "open":
                nm = ev[1].split(":")[-1]
                if nm == "item" and "id" in ev[2] and "href" in ev[2]:
                    manifest[ev[2]["id"]] = ev[2]["href"]
                elif nm == "itemref" and "idref" in ev[2]:
                    spine.append(ev[2]["idref"])
        ordered = []
        for ref in spine:
            if ref in manifest:
                p = posixpath.normpath(posixpath.join(base, manifest[ref].split("#")[0]))
                from urllib.parse import unquote
                p = unquote(p)
                if p in names and p not in ordered:
                    ordered.append(p)
        rest = [n for n in sorted(html_names) if n not in ordered]
        return [n for n in ordered if re.search(r"\.(x?html?)$", n, re.I)] + rest
    except Exception:
        return sorted(html_names)


def extract_epub(z):
    out = []
    for n in _epub_order(z):
        p = _Html()
        try:
            p.feed(_read(z, n))
            p.close()
        except Exception:
            pass
        p.flush()
        if p.blocks:
            out.append("\n".join(p.blocks))
    return "\n".join(out)


def extract_ipynb(data):
    try:
        nb = json.loads(decode_bytes(data))
    except Exception:
        return ""
    if not isinstance(nb, dict):
        return ""
    cells = nb.get("cells")
    if not isinstance(cells, list):
        return ""
    out = []
    for c in cells:
        if not isinstance(c, dict) or c.get("cell_type") != "markdown":
            continue
        src = c.get("source")
        if isinstance(src, str):
            t = src
        elif isinstance(src, list) and all(isinstance(x, str) for x in src):
            t = "".join(src)
        else:
            continue
        if t.strip():
            out.append(t.strip("\n"))
    return "\n".join(out)


def extract(ext, data):
    """Return extracted prose text. Raise NotReadable for broken archives."""
    ext = ext.lower()
    if ext in ZIP_EXTS:
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
        except (zipfile.BadZipFile, OSError, ValueError) as e:
            raise NotReadable("not a readable zip archive")
        try:
            if ext in (".docx", ".docm"):
                t = extract_docx(z)
            elif ext in (".pptx", ".pptm"):
                t = extract_pptx(z)
            elif ext in (".xlsx", ".xlsm"):
                t = extract_xlsx(z)
            elif ext == ".epub":
                t = extract_epub(z)
            else:
                t = extract_odf(z)
        except (zipfile.BadZipFile, KeyError, RuntimeError, OSError, NotImplementedError, zipfile.LargeZipFile) as e:
            raise NotReadable("not a readable zip archive")
        return t.strip()
    if ext in NB_EXTS:
        return extract_ipynb(data).strip()
    if ext in (".pdf", ".rtf"):
        return ""
    return decode_bytes(data)

# ===== patterns =====
"""Lexical and structural pattern families."""
import re
from collections import Counter

I = re.I


def forms(*words):
    alts = []
    for w in words:
        if w.endswith("e"):
            st = w[:-1]
            alts += [w, st + "es", st + "ed", st + "ing"]
        elif w.endswith("y") and len(w) > 2 and w[-2] not in "aeiou":
            st = w[:-1]
            alts += [w, st + "ies", st + "ied", st + "ying"]
        else:
            alts += [w, w + "s", w + "es", w + "ed", w + "ing"]
    return "(?:" + "|".join(alts) + ")"


def R(p, flags=I):
    return re.compile(p, flags)


AI_WORDS = ["delve", "tapestry", "pivotal", "crucial", "vibrant", "meticulous", "testament",
            "underscore", "intricate", "interplay", "garner", "bolster", "foster", "showcase",
            "emphasize", "emphasise", "enhance", "leverage", "utilize", "utilise", "facilitate",
            "encompass", "harness", "holistic", "paradigm", "transformative", "unprecedented",
            "plethora", "robust", "seamless", "navigate", "embark", "craft", "landscape",
            "journey", "realm", "multifaceted", "elevate", "empower", "unlock", "additionally",
            "enduring", "myriad"]
_ai = "|".join(forms(w) for w in AI_WORDS)
FAM1 = [
    R(r"\b(?:" + _ai + r"|intricacies)\b"),
    R(r"\b" + forms("align") + r"\s+with\b"),
    R(r"\bcaptur(?:e|es|ed|ing)\s+the\s+(?:essence|spirit|imagination|heart|magic)\b"),
]

FAM2 = [
    R(r"\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly)\b"),
    R(r"\bquietly\s+(?:powerful|profound|radical)\b"),
    R(r"\bdeeply\s+(?:human|personal|felt|unsettling)\b"),
    R(r"\bresonat(?:e|es|ed|ing)\s+deeply\b"),
    R(r"\bgame[- ]chang(?:er|ers|ing)\b"),
    R(r"\b(?:supercharg(?:e|es|ed|ing)|skyrocket(?:s|ed|ing)?|turbocharg(?:e|es|ed|ing)|revolutioni[sz](?:e|es|ed|ing))\b"),
    R(r"\bdoubl(?:e|es|ed|ing)\s+down\s+on\b"),
    R(r"\bdiv(?:e|es|ed|ing)\s+deep(?:er)?\s+into\b"),
    R(r"\bunlock(?:s|ed|ing)?\s+(?:the\s+)?(?:power|potential|value)\b"),
    R(r"\btak(?:e|es|ing)\s+[^.!?\n]{1,40}?\s+to\s+the\s+next\s+level\b"),
]

FAM3 = [R(p) for p in [
    r"\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|world-class|top-tier|unparalleled|premier|leading)\b",
    r"\bvibrant\s+community\b", r"\brich\s+cultural\s+heritage\b", r"\bin\s+the\s+heart\s+of\b",
    r"\besteemed\s+organi[sz]ation\b", r"\bvaluable\s+asset\b", r"\bpassion\s+for\s+excellence\b",
    r"\bproven\s+track\s+record\b", r"\bresults-oriented\b", r"\bwealth\s+of\s+experience\b",
    r"\bdynamic\s+team\b", r"\bfast-paced\s+environment\b", r"\bdeeply\s+passionate\b",
    r"\bperfectly\s+situated\b", r"\b(?:close|tight)-knit\s+team\b",
    r"\bI\s+am\s+excited\s+to\s+(?:apply|bring)\b", r"\buniquely\s+positioned\s+to\b",
]]
MARKETING_VERBS = set("install join grab download try discover experience escape transform reclaim unlock elevate boost say imagine explore meet introducing upgrade claim unleash supercharge level stop start".split())

FAM4 = [R(r"\b(?:state-of-the-art|cutting-edge|best-in-class|results-driven|detail-oriented|forward-thinking|data-driven|customer-centric|mission-critical|end-to-end|high-impact|cross-functional|client-focused|team-oriented|well-rounded|hands-on|self-motivated|goal-oriented|value-added|business-critical|future-proof|thought-provoking|game-changing|fast-paced|results-oriented|world-class|high-quality|user-friendly|next-generation|ground-breaking|top-notch|full-service|one-stop|best-of-breed|results-focused)\b")]

FAM5 = [R(r"\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b")]

STOCK_ADJ = set("""innovative dynamic powerful seamless robust comprehensive vibrant rich stunning modern cutting-edge
scalable flexible reliable efficient effective engaging compelling bold bright creative strategic holistic
intuitive elegant sleek smart versatile impactful valuable meaningful exciting remarkable exceptional
transformative groundbreaking visionary passionate dedicated skilled talented""".split())
STOP = set("the a an of to in on at by for with and or but is are was were be been it its this that these those i you he she we they my your our their his her as from".split())
ADJ_SUFFIX = ("ive", "ous", "able", "ible", "ic", "ical", "ant", "ent", "ful", "less", "al", "ial", "ary", "ory", "ish")
CHAIN_RE = re.compile(r"\b[A-Za-z][A-Za-z-]*(?:,\s+[A-Za-z][A-Za-z-]*){2,},?\s+(?:and\s+)?[A-Za-z][A-Za-z-]*(?:\s+[A-Za-z][A-Za-z-]*)?\b")

CLUSTERS = [
    ["protagonist", "main character", "central figure", "hero", "heroine"],
    ["company", "firm", "organization", "enterprise", "business"],
    ["author", "writer", "novelist", "scribe"],
    ["report", "study", "analysis", "investigation", "examination"],
    ["technology", "tool", "system", "platform", "solution"],
    ["technique", "method", "approach", "strategy", "tactic"],
    ["challenge", "obstacle", "difficulty", "hurdle", "barrier"],
    ["benefit", "advantage", "upside", "strength"],
]


def _plural(w):
    if w.endswith("y"):
        return "(?:" + w + "|" + w[:-1] + "ies)"
    if w.endswith(("s", "ch", "sh", "x")):
        return "(?:" + w + "|" + w + "es)"
    return w + "s?"


CLUSTER_RES = []
for _c in CLUSTERS:
    _alts = []
    for w in _c:
        parts = w.split()
        parts[-1] = _plural(parts[-1]) if parts[-1].endswith(tuple("abcdefghijklmnopqrstuvwxyz")) else parts[-1]
        _alts.append(r"\s+".join(parts))
    CLUSTER_RES.append([(w, R(r"\b" + a + r"\b")) for w, a in zip(_c, _alts)])

FAM10 = [R(p) for p in [
    r"\b(?:stand|stands|stood|standing|serve|serves|served|serving)\s+as\s+(?:a|an|the)\s+(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b",
    r"\b(?:underscor(?:e|es|ed|ing)|highlight(?:s|ed|ing)?)\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b",
    r"\breflect(?:s|ed|ing)?\s+a\s+broader\s+(?:trend|shift|pattern)\b",
    r"\bmark(?:s|ed|ing)?\s+a\s+(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)\b",
    r"\bsymboli[sz](?:es|ed|ing)\b", r"\bsets?\s+the\s+stage\s+for\b", r"\bleft\s+an\s+indelible\s+mark\b",
    r"\bplays?\s+an?\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b",
    r"\b(?:has|have)\s+(?:shaped|sparked)\b", r"\bhas\s+come\s+to\s+(?:define|symboli[sz]e)\b",
]]

FAM11 = [R(p, 0) for p in [
    r"(?i:\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+)[A-Z][\w&.'’-]*(?:\s+[A-Z][\w&.'’-]*)*(?:\s*(?:,|and|&)\s*(?:and\s+)?[A-Z][\w&.'’-]*(?:\s+[A-Z][\w&.'’-]*)*)+",
    r"(?i:\b\d[\d,.]*\s*[km]?\s+(?:followers|subscribers)\b)",
    r"(?i:\b(?:strong|active|robust|significant|notable|growing)\s+(?:online|digital|social[- ]media)\s+presence\b)",
    r"(?i:\bwidely\s+covered\b|\bindependent(?:ly)?\s+(?:media\s+)?coverage\b|\bcovered\s+independently\b)",
]]

FAM12 = [R(p) for p in [
    r"\bexperts\s+(?:argue|believe|say|claim|note|suggest)\b",
    r"\bindustry\s+(?:reports?|observers?|analysts?)\b", r"\bobservers\s+have\s+(?:cited|noted)\b",
    r"\bsome\s+critics\s+argue\b", r"\bresearchers\s+have\s+found\b", r"\bstudies\s+suggest\b",
    r"\bit\s+is\s+widely\s+believed\b", r"\bit['’]s\s+widely\s+believed\b",
]]

FAM13 = [R(r"\bThe\s+(?:List|Index|Compilation|Collection|Catalogue|Catalog|Guide|Overview)\s+of\s+(?:[\w'’:,&-]+\s+){1,12}?(?:is|are|was)\s+(?:a|an|the)\b", 0)]

FAM14 = [R(p) for p in [
    r"\bplays?\s+an?\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b",
    r"\bconservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)\b",
    r"\bserves\s+as\s+an\s+indicator\s+species\b", r"\bcontributes?\s+to\s+biodiversity\b",
]]

FAM15 = [R(r"\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]{0,150}?\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering|grand|sprawling)\b")]

_ING = "highlighting|reflecting|symbolizing|symbolising|emphasizing|emphasising|underscoring|showcasing|fostering|cultivating|encompassing|signaling|signalling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing|epitomising"
FAM16 = [R(r",\s+(?:" + _ING + r")\b")]

FAM17_PAR = [R(p) for p in [
    r"\bit['’]s\s+not\s+(?:just|merely)\s+(?:about|a|an)\b",
    r"\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b",
    r"\bdoesn['’]t\s+just\b[^,.]{0,40}?\bit\b",
]]
FAM17_TAIL = [R(r",\s+no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b")]

FAM18 = [R(p) for p in [
    r"\b(?:no|not)\s+\w+,\s+(?:just|only|simply)\s+\w+",
    r"\b(?:not|isn['’]t|aren['’]t|wasn['’]t|weren['’]t)\s+(?:just|merely)\s+(?:(?:a|an|the)\s+)?\w+\s*(?:,|—|–|--)\s*(?:it['’]s|it\s+is|it\s+was|they['’]re|they\s+are|they\s+were|that['’]s|but)\b",
]]

FAM19 = [R(r"\b(?:in\s+order\s+to|due\s+to\s+the\s+fact\s+that|at\s+this\s+point\s+in\s+time|in\s+the\s+event\s+that|has\s+the\s+ability\s+to|it\s+is\s+important\s+to\s+note\s+that|it\s+should\s+be\s+mentioned\s+that|needless\s+to\s+say)\b")]

FAM20 = [R(p) for p in [
    r"\bit(?:['’]s|\s+is)\s+worth\s+(?:noting|mentioning)\s+that\b", r"\bit\s+bears\s+(?:noting|mentioning)\s+that\b",
    r"\bone\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is\b", r"\bit\s+is\s+interesting\s+to\s+note\s+that\b",
    r"\ba\s+key\s+consideration\s+is\b", r"\ba\s+point\s+to\s+highlight\s+is\b",
]]

_SPEC = "raising\\s+questions\\s+about|prompting\\s+reflection\\s+on|sparking\\s+debate\\s+about|with\\s+broader\\s+implications\\s+for|reshaping\\s+our\\s+understanding\\s+of|paving\\s+the\\s+way\\s+for|signaling\\s+a\\s+shift\\s+toward"
FAM21 = [R(r",\s+(?:" + _SPEC + r")\b")]

FAM22 = [R(r"\b(?:here['’]s\s+the\s+thing|make\s+no\s+mistake|the\s+truth\s+is|let['’]s\s+be\s+honest|the\s+simple\s+fact\s+is|at\s+its\s+core|what\s+really\s+matters|more\s+than\s+anything|at\s+the\s+end\s+of\s+the\s+day|the\s+bottom\s+line\s+is|in\s+reality|the\s+real\s+question\s+is|the\s+heart\s+of\s+the\s+matter|the\s+deeper\s+issue|when\s+you\s+get\s+down\s+to\s+it|when\s+all\s+is\s+said\s+and\s+done)\b|\bfundamentally,")]

FAM23 = [R(p) for p in [
    r"\bit(?:['’]s|\s+is)\s+important\s+to\s+(?:remember|note|understand|recognize|recognise)\b",
    r"\bone\s+must\s+note\s+that\b", r"\bit\s+is\s+worth\s+pointing\s+out\b",
    r"\bit\s+cannot\s+be\s+overstated\s+that\b", r"\bit\s+must\s+be\s+emphasi[sz]ed\s+that\b",
]]

FAM24 = [R(r"\b(?:this\s+(?:comprehensive\s+(?:guide|overview|analysis)|in-depth\s+(?:analysis|look|examination)|complete\s+(?:guide|overview))|a\s+thorough\s+examination\s+of|everything\s+you\s+need\s+to\s+know\s+about)\b")]

FAM25 = [R(r"\b(?:is|are|was|were|do|does|did|can|could|will|would|should|shall|has|have|had|may|might|must)\b[^.!?\n]{0,100}\?\s+(?:yes|no|absolutely|never|maybe|probably|always|definitely|sometimes)\s*[.!]")]

FAM26 = [R(r"\b(?:without\s+concrete\s+evidence|do\s+you\s+have\s+concrete\s+evidence|I\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples)\s+to|absent\s+concrete\s+proof|provide\s+concrete\s+evidence)\b")]

FAM27 = [R(p) for p in [
    r"\bin\s+today['’]s\s+(?:\w+\s+){0,2}?(?:world|landscape|environment|market)\b", r"\bin\s+a\s+world\s+where\b",
    r"\bin\s+an\s+era\s+of\b", r"\bin\s+recent\s+years,", r"\bmore\s+than\s+ever\s+before\b",
    r"\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b", r"\b(?:great|exciting|big)\s+news\s*[!:]",
    r"\bever\s+(?:wanted|wondered|dreamed|wished)\s+(?:to|of)\b[^.?!]*\?",
    r"\bin\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world\b",
]]

FAM30 = [R(p) for p in [
    r"\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b",
    r"\b(?:the|this)\s+(?:(?:latest|new)\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b",
    r"\b(?:has|have)\s+been\s+(?:updated|refactored|improved|enhanced|changed)\s+to\b",
    r"\bpreviously\b[^.!?\n]{0,120}?\bnow\b", r"\b(?:wasn['’]t|weren['’]t)\s+there\s+before\b",
    r"\bwe['’]ve\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b",
    r"\bwe\s+have\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b",
]]

FAM31 = [R(p) for p in [
    r"\blet['’]s\s+(?:dive|delve|explore)\b", r"\blet['’]s\s+break\s+(?:this|it)\s+down\b",
    r"\bhere['’]s\s+what\s+you\s+need\s+to\s+know\b", r"\bwithout\s+further\s+ado\b",
    r"\bnow\s+let['’]s\s+look\s+at\b", r"\bbuckle\s+up\b", r"\bstay\s+with\s+me\b",
    r"\bready\s+to\s+dive\s+in\b",
]]

FAM32 = [R(p) for p in [
    r"\b(?:used|uses|employs?|employed|relied\s+on|relies\s+on|utili[sz]es)\s+(?:several|various|a\s+number\s+of|multiple|different|many|numerous)\s+\w+",
    r"(?:^|(?<=[.!?]\s))These(?:\s+\w+)?\s+(?:provide|offer|give|reveal|show|allow|enable|help)s?\s+(?:information|insights?|understanding|details|data)\b",
    r"\b(?:is|are|was|were|remains?|becomes?)\s+(?:the|a)\s+(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b",
]]
FAM32[1] = R(FAM32[1].pattern, I | re.M)

FAM33 = [R(r"^[ \t]*(?:[-*+]\s+|\d+[.)]\s+)?\*\*[^*\n]+?(?::\*\*|\*\*:)", I | re.M)]

FAM36 = [R(p) for p in [
    r"\bdespite\s+(?:these|its|the)\s+(?:challenges|obstacles)\b",
    r"\bchallenges\s+and\s+(?:(?:future\s+)?prospects|outlook|legacy)\b",
    r"\bcontinues\s+to\s+thrive\b", r"\btypical\s+of\s+(?:emerging|urban|modern)\b",
    r"\bfaces\s+(?:several|many|numerous)\s+challenges\b",
]]

TRANS = r"(?:Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably)"
FAM37_RE = re.compile(r"(?:^|(?<=[.!?]\s)|(?<=[.!?][\"')\]]\s))" + TRANS + r"\b", re.M)

FAM38 = [R(r"^[ \t]*(?:in\s+conclusion|overall|in\s+summary|to\s+summarize|to\s+conclude|all\s+in\s+all|in\s+essence|ultimately)\b", I | re.M)]

FAM39 = [R(p) for p in [
    r"\bthe\s+future\s+looks\s+bright\b", r"\bexciting\s+times\s+lie\s+ahead\b", r"\bjourney\s+toward\s+excellence\b",
    r"\bstep\s+in\s+the\s+right\s+direction\b", r"\b(?:the\s+)?(?:outlook|future)(?:\s+for\s+[^.!?\n]{1,40}?)?\s+(?:is|looks|remains)\s+bright\b",
    r"\bwell[- ]positioned\s+for\s+(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)\b",
]]

FAM47 = [R(p) for p in [
    r"\bI\s+hope\s+this\s+helps\b", r"\b(?:Certainly|Of\s+course)!", r"\blet\s+me\s+know\s+if\s+you\b",
    r"\bwould\s+you\s+like\s+me\s+to\b", r"\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b",
    r"\bhappy\s+to\s+help\s*(?:[.!?]|$)",
    r"\b(?:here|below)\s+is\s+(?:a|an|the)\s+(?:\w+\s+)?(?:overview|summary|rundown|recap|brief)\b",
    r"\bhere(?:\s+are|['’]s)\s+(?:a\s+few|some|two|three)\s+(?:\w+\s+)?(?:options|drafts|versions|variations)\b",
    r"\bhere(?:\s+is|['’]s)\s+a\s+draft\b", r"\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b",
    r"\bI\s+hope\s+(?:this\s+(?:email|message)\s+)?finds\s+you\s+well\b",
    r"\bas\s+an?\s+(?:AI|LLM|AI\s+assistant|AI\s+language\s+model|large\s+language\s+model|language\s+model)\b",
    r"\b(?:to\s+(?:answer|address)\s+your\s+question|in\s+(?:response|answer)\s+to\s+your\s+question|your\s+question\s+(?:about|regarding|concerning))\b",
    r"\bas\s+(?:you\s+)?(?:requested|asked),\s+here\b",
    r"\bhere\s+is\s+(?:the\s+)?(?:draft|first\s+pass|revised\s+version\s+of|for\s+your)\b",
]]

FAM48 = [R(p) for p in [
    r"\byou(?:['’]re|\s+are)\s+absolutely\s+right\b",
    r"\b(?:great\s+question|excellent\s+point)\s*[!.,]",
    r"\bwhat\s+a\s+(?:thoughtful|great|wonderful|fantastic)\s+question\s*[!.,]",
    r"\bthat['’]s\s+a\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\s*[!.,]",
]]

FAM50 = [R(p) for p in [
    r"\bas\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)\b", r"\bup\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)\b",
    r"\bwhile\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+(?:extensively|widely)\s+documented)\b",
    r"\bbased\s+on\s+(?:the\s+)?available\s+information\b", r"\bas\s+of\s+my\s+(?:knowledge\s+)?cutoff\b",
    r"\bmaintains\s+a\s+low\s+profile\b", r"\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b",
    r"\bmaintains\s+(?:his|her|their)\s+privacy\b",
]]

FAM51 = [R(p) for p in [
    r"\b(?:serves|stands|functions|acts)\s+as\b", r"\brepresents\s+(?:a|the)\b", r"\bmarks\s+(?:a|the)\b",
    r"\bboasts?\b", r"\bfeatures\s+(?:a|an|the|\d+|several|many|numerous|various|multiple|over|more|dozens)\b",
    r"\boffers\s+a\b", r"\brefers\s+to\b",
]]

FAM54_RE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems?\s+(?:to|like)|appears?\s+to|somewhat|relatively|fairly|kind\s+of|sort\s+of)\b")

FAM56 = [R(r"\*\*[^*\n]+?\*\*", 0)]

EMOJI_RE = re.compile("[\U0001F300-\U0001FAFF\U0001F000-\U0001F2FF\u2600-\u27BF\u2B50\u2B55\u231A\u231B\u23E9-\u23F3\u2705\u274C\u2728\u2B06\u2B07\u2194-\u2199\u21A9\u21AA\u2934\u2935]")

CURLY_RE = re.compile("[\u2018\u2019\u201C\u201D]")
FAM61 = [R(r"\b(1[0-9]{3}|20[0-9]{2})-(1[0-9]{3}|20[0-9]{2})\b", 0)]

FAM63 = [
    R(r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])"),
    R(r"\[(?:[^\]\n]{0,30}\s)?(?:name|company|client|city|place|location|source|person|recipient|employer|organi[sz]ation)(?:\s[^\]\n]{0,30})?\](?![(\[])"),
    R(r"\{\{[^}\n]*\}\}", 0),
    R(r"(?<![A-Za-z])[xX]{3,}(?![A-Za-z])", 0),
    R(r"\blorem\s+ipsum\b"),
]
ALLCAPS_SLOT = re.compile(r"\[([A-Z][A-Z0-9 _/-]*)\](?![(\[])")
SMALL_LABEL = re.compile(r"[A-Z]{1,3}[0-9]{0,3}")

FAM64 = [R(p) for p in [r"\bcite(?:turn|start|nav)\w*", r"\boai_citation\w*", r"\bcontentReference\w*", r"\bnavlist\b", "【\\d+†[^】]*】"]]
UTM_RE = re.compile(r"utm_source=([A-Za-z0-9.-]*)", re.I)
UTM_HOSTS = {"chatgpt.com", "chat.openai.com", "perplexity.ai", "claude.ai", "gemini.google.com", "copilot.microsoft.com", "poe.com"}

FAM69 = [R(p) for p in [
    r"\bunlocking\s+(?:the\s+|its\s+|your\s+|their\s+)?(?:full\s+)?potential\b", r"\bnavigating\s+the\s+complexities\b",
    r"\ba\s+testament\s+to\s+the\s+(?:power|importance)\b", r"\bstaying\s+ahead\s+of\s+the\s+curve\b",
    r"\bturning\s+challenges\s+into\s+opportunities\b", r"\btak(?:e|es|ing)\s+[^.!?\n]{1,30}?\s+to\s+the\s+next\s+level\b",
    r"\bharness(?:es|ed|ing)?\s+the\s+power\s+of\b", r"\bpaving\s+the\s+way\s+for\b", r"\bsaying\s+goodbye\s+to\b",
    r"\bimagining\s+a\s+world\s+where\b", r"\bever-evolving\s+(?:landscape|world|digital)\b",
    r"\bunleash(?:es|ed|ing)?\s+the\s+power\s+of\b", r"\bbridging\s+the\s+gap\s+between\b",
]]

HR_RE = re.compile(r"^[ \t]*(?:-{3,}|\*{3,}|_{3,}|(?:\*[ \t]+){2,}\*)[ \t]*$", re.M)

HEADING_RE = re.compile(r"^[ \t]{0,3}#{1,6}[ \t]+(.+?)[ \t]*#*[ \t]*$", re.M)
LIST_LINE_RE = re.compile(r"^[ \t]*(?:[-*+]|\d+[.)])[ \t]+\S")

# ===== detector =====
WINDOW = 262144
USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Scan prose for AI-writing patterns and print a JSON report.
  --clean   print scrubbed text (invisible characters, odd spaces, lookalikes) instead of a report
  --ci      add a resampled low/high interval on the score
  --        stop option parsing so FILE may begin with a dash
  FILE      one file to scan; with no FILE, standard input is read
"""

BANDS = [(20, "clean"), (40, "light tells"), (60, "mixed"), (80, "heavy tells"), (100, "pervasive tells")]


def band_of(score):
    for hi, name in BANDS:
        if score <= hi:
            return name
    return "pervasive tells"


# number: (slug, label, weight)
META = {
    1: ("ai_vocabulary", "AI vocabulary", 12), 2: ("model_dialect", "Model-dialect vocabulary", 12),
    3: ("promotional", "Promotional language", 12), 4: ("hyphenated_pairs", "Hyphenated word-pair overuse", 0),
    5: ("simple_yet", "\"Simple yet X\" cliché", 8), 6: ("adjective_chains", "Stacked adjective chains", 8),
    8: ("synonym_cycling", "Synonym cycling", 7), 10: ("significance_inflation", "Significance inflation", 12),
    11: ("name_dropping", "Notability name-dropping", 8), 12: ("vague_attribution", "Vague attributions", 10),
    13: ("article_title", "Article title as proper noun", 22), 14: ("ecosystem_padding", "Conservation / ecosystem padding", 8),
    15: ("false_ranges", "False ranges", 8), 16: ("ing_tails", "Superficial -ing tail clauses", 10),
    17: ("tailing_negation", "Tailing negation", 8), 18: ("not_x_just_y", "\"Not X, just Y\" construction", 10),
    19: ("filler", "Filler phrases", 0), 20: ("empty_pivots", "Empty pivot phrases", 10),
    21: ("speculation_tails", "Outcome speculation tails", 10), 22: ("authority_tropes", "Persuasive authority tropes", 0),
    23: ("editorial", "Editorial interjections", 8), 24: ("self_thoroughness", "Self-thoroughness phrases", 10),
    25: ("question_answer", "Question-answer rhetorical pattern", 6), 26: ("concrete_evidence", "\"Concrete evidence\" defense phrase", 6),
    27: ("intro_hooks", "Compulsive intro hooks", 12), 30: ("diff_anchored", "Diff-anchored writing", 8),
    31: ("signposting", "Signposting and announcements", 12), 32: ("cataloguing", "Cataloguing lead-ins", 8),
    33: ("inline_header_lists", "Inline-header vertical lists", 6), 34: ("bullet_injection", "Mid-essay bullet injection", 6),
    35: ("fragmented_headers", "Fragmented headers", 6), 36: ("challenges_section", "Formulaic challenges section", 10),
    37: ("transition_clusters", "Transition cluster overuse", 10), 38: ("conclusion_phrases", "Compulsive conclusion phrases", 10),
    39: ("positive_conclusions", "Generic positive conclusions", 10), 40: ("sentence_monotony", "Sentence-length monotony", 8),
    41: ("length_alternation", "Mechanical sentence-length alternation", 0), 42: ("opener_repetition", "Opener repetition", 0),
    44: ("uniform_paragraphs", "Uniform paragraph length", 8), 46: ("punctuation_underuse", "Semicolon and parenthesis underuse", 0),
    47: ("chatbot_artifacts", "Chatbot artifacts", 25), 48: ("sycophancy", "Sycophantic tone", 25),
    50: ("knowledge_cutoff", "Knowledge-cutoff disclaimer", 25), 51: ("copula_avoidance", "Copula avoidance", 7),
    54: ("hedge_stacking", "Excessive hedging", 0), 55: ("contraction_absence", "Contraction absence", 0),
    56: ("boldface", "Boldface overuse", 6), 57: ("emoji", "Emojis", 6), 58: ("em_dash", "Em-dash overuse", 0),
    59: ("title_case_headings", "Title case in headings", 5), 60: ("curly_quotes", "Curly quotation marks", 0),
    61: ("hyphen_ranges", "Hyphen for en dash in ranges", 0), 62: ("invisible_chars", "Invisible / zero-width characters", 20),
    63: ("placeholders", "Placeholder / Mad-Libs text", 25), 64: ("reference_markup", "Chatbot reference-markup leak", 25),
    65: ("tracking_params", "AI tracking parameters", 25), 66: ("homoglyphs", "Homoglyph / mixed-script confusables", 25),
    67: ("nonstandard_spaces", "Non-standard spaces", 8), 68: ("trailing_whitespace", "Trailing / stray whitespace", 0),
    69: ("marketing_slop", "Canonical marketing-slop phrases", 12), 70: ("horizontal_rules", "Decorative horizontal rules", 6),
    71: ("degenerate_repetition", "Degenerate repetition", 20),
}
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
SHORT_NUMS = set(range(1, 40)) | {47, 48, 49, 50, 51, 69}
ADVICE_17 = ("negative_parallelism", "Negative parallelism (not only X but Y)")


def key_of(n, slug=None):
    return "%d_%s" % (n, slug or META[n][0])


# ---------------------------------------------------------------- masking
def mask_code(text):
    ranges = []
    n = len(text)
    # YAML front matter
    m = re.match(r"---[ \t]*\n", text)
    if m:
        cl = re.compile(r"^(?:---|\.\.\.)[ \t]*$", re.M).search(text, m.end())
        if cl:
            ranges.append((0, cl.end()))
    lines = text.split("\n")
    offs = []
    p = 0
    for ln in lines:
        offs.append(p)
        p += len(ln) + 1
    masked_line = [False] * len(lines)
    fence = None
    for i, ln in enumerate(lines):
        if fence is None:
            m = re.match(r"^ {0,3}(`{3,}|~{3,})(.*)$", ln)
            if m and not (m.group(1)[0] == "`" and "`" in m.group(2)):
                fence = (m.group(1)[0], len(m.group(1)))
                masked_line[i] = True
        else:
            masked_line[i] = True
            m = re.match(r"^ {0,3}(`{3,}|~{3,})[ \t]*$", ln)
            if m and m.group(1)[0] == fence[0] and len(m.group(1)) >= fence[1]:
                fence = None
    # blockquote runs
    i = 0
    while i < len(lines):
        if not masked_line[i] and re.match(r"^ {0,3}>", lines[i]):
            j = i
            while j < len(lines) and not masked_line[j] and re.match(r"^ {0,3}>", lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    masked_line[k] = True
            i = j
        else:
            i += 1
    sep = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(?:\|\s*:?-{2,}:?\s*)+\|?\s*$|^\s*\|\s*:?-{2,}:?\s*\|?\s*$")
    for i, ln in enumerate(lines):
        if masked_line[i]:
            continue
        if ln.lstrip().startswith("|"):
            masked_line[i] = True
        elif "|" in ln and sep.match(ln):
            masked_line[i] = True
            if i > 0 and "|" in lines[i - 1]:
                masked_line[i - 1] = True
            k = i + 1
            while k < len(lines) and "|" in lines[k] and lines[k].strip():
                masked_line[k] = True
                k += 1
        elif re.match(r"^\s*(?:\[!\[[^\]]*\](?:\([^)]*\)|\[[^\]]*\])\](?:\([^)]*\)|\[[^\]]*\])\s*)+$", ln):
            masked_line[i] = True
    for i, ln in enumerate(lines):
        if masked_line[i]:
            ranges.append((offs[i], offs[i] + len(ln)))
    out = text
    if ranges:
        parts = []
        last = 0
        for s, e in sorted(ranges):
            if s < last:
                s = last
            if e <= s:
                continue
            parts.append(out[last:s])
            parts.append(re.sub(r"[^\n]", " ", out[s:e]))
            last = e
        parts.append(out[last:])
        out = "".join(parts)
    # inline code spans
    if "`" in out:
        def rep(m):
            body = m.group(0)
            if "\n\n" in body:
                return body
            return re.sub(r"[^\n]", " ", body)
        out = re.sub(r"(?<!`)(`+)(?!`)(.+?)(?<!`)\1(?!`)", rep, out, flags=re.S)
    return out


# ---------------------------------------------------------------- text structure
WORD_RE = re.compile(r"(?:[^\W_]|['’-])+")
SENT_SPLIT = re.compile(r"(?<=[.!?])[\"'”’)\]]*\s+(?=[^\sa-z])")


def words_of(text):
    return [w for w in WORD_RE.findall(text) if any(c.isalnum() for c in w)]


def is_noprose_line(ln):
    s = ln.strip()
    return (not s) or re.match(r"^#{1,6}\s", s) is not None or HR_RE.match(ln) is not None


def paragraphs_of(masked):
    out = []
    for para in re.split(r"\n[ \t]*\n", masked):
        lines = [l for l in para.split("\n") if l.strip()]
        if not lines:
            continue
        lines = [l for l in lines if not is_noprose_line(l)]
        if not lines:
            continue
        out.append(lines)
    return out


def sentences_of_paragraph(lines):
    txt = " ".join(re.sub(r"^\s*(?:[-*+]|\d+[.)])\s+", "", l).strip() for l in lines)
    parts = [s.strip() for s in SENT_SPLIT.split(txt)]
    return [s for s in parts if words_of(s)]


def cv(values):
    m = sum(values) / len(values)
    if m == 0:
        return 99.0
    var = sum((v - m) ** 2 for v in values) / len(values)
    return math.sqrt(var) / m


def excerpt(t, s, e, pad=30):
    a = max(0, s - pad)
    b = min(len(t), e + pad)
    left = t[a:s]
    right = t[e:b]
    if a > 0:
        k = left.find(" ")
        k2 = left.find("\n")
        if k == -1 or (k2 != -1 and k2 < k):
            k = k2
        if k != -1:
            left = left[k + 1:]
    if b < len(t):
        k = max(right.rfind(" "), right.rfind("\n"))
        if k != -1:
            right = right[:k]
    piece = (left + t[s:e] + right).replace("\n", " ").replace("\r", " ").strip()
    return ("..." if a > 0 else "") + piece + ("..." if b < len(t) else "")


def short(m_text):
    s = re.sub(r"\s+", " ", m_text).strip()
    return s if len(s) <= 80 else s[:77] + "..."


def run_regs(regs, text, sample_mode="match"):
    count = 0
    samples = []
    seen = set()
    for rg in regs:
        for m in rg.finditer(text):
            if m.start() in seen:
                continue
            seen.add(m.start())
            count += 1
            if len(samples) < 3:
                samples.append(excerpt(text, m.start(), m.end()) if sample_mode == "excerpt" else short(m.group(0)))
    return count, samples


# ---------------------------------------------------------------- analysis
def analyze(masked, raw_for_ws=None):
    """Return dict number_or_key -> (count, samples). Lexical + structural families."""
    f = {}

    def put(key, res):
        if res[0] > 0:
            f[key] = res

    put(1, run_regs(FAM1, masked, "excerpt"))
    c2 = run_regs(FAM2, masked)
    if c2[0] >= 2:
        f[2] = c2
    paras = paragraphs_of(masked)
    para_sents = [sentences_of_paragraph(p) for p in paras]
    all_sents = [s for ps in para_sents for s in ps]

    # 3
    c3, s3 = run_regs(FAM3, masked)
    imper = [s for s in all_sents if (words_of(s) or [""])[0].lower() in MARKETING_VERBS]
    if len(imper) >= 3:
        c3 += len(imper)
        s3 = (s3 + [short(x) for x in imper])[:3]
    put(3, (c3, s3))
    put(4, run_regs(FAM4, masked))
    put(5, run_regs(FAM5, masked))
    # 6
    c6 = 0
    s6 = []
    for m in CHAIN_RE.finditer(masked):
        ws = [w for w in re.findall(r"[A-Za-z][A-Za-z-]*", m.group(0)) if w.lower() != "and"]
        while ws and ws[-1].lower() in STOP:
            ws.pop()
        if len(ws) < 4:
            continue
        chain = ws
        if any((w.lower() in STOCK_ADJ or w.lower().endswith(ADJ_SUFFIX)) and w.lower() not in STOP for w in chain[:-1] + ([chain[-1]] if len(chain) > 4 else [])):
            c6 += 1
            if len(s6) < 3:
                s6.append(short(m.group(0)))
    put(6, (c6, s6))
    # 8
    c8 = 0
    s8 = []
    lowered = masked
    for cl in CLUSTER_RES:
        used = []
        total = 0
        for w, rg in cl:
            n = len(rg.findall(lowered))
            if n:
                used.append(w)
                total += n
        if len(used) >= 3:
            c8 += total
            if len(s8) < 3:
                s8.append(", ".join(used))
    put(8, (c8, s8))
    put(10, run_regs(FAM10, masked))
    put(11, run_regs(FAM11, masked))
    put(12, run_regs(FAM12, masked))
    put(13, run_regs(FAM13, masked))
    put(14, run_regs(FAM14, masked))
    put(15, run_regs(FAM15, masked))
    put(16, run_regs(FAM16, masked))
    put(key_of(17, ADVICE_17[0]), run_regs(FAM17_PAR, masked))
    put(key_of(17), run_regs(FAM17_TAIL, masked))
    put(18, run_regs(FAM18, masked))
    put(19, run_regs(FAM19, masked))
    put(20, run_regs(FAM20, masked))
    put(21, run_regs(FAM21, masked))
    put(22, run_regs(FAM22, masked))
    put(23, run_regs(FAM23, masked))
    put(24, run_regs(FAM24, masked))
    put(25, run_regs(FAM25, masked))
    put(26, run_regs(FAM26, masked))
    put(27, run_regs(FAM27, masked))
    put(30, run_regs(FAM30, masked))
    put(31, run_regs(FAM31, masked))
    put(32, run_regs(FAM32, masked))
    put(33, run_regs(FAM33, masked))
    put(36, run_regs(FAM36, masked))
    # 37
    c37 = 0
    s37 = []
    for para in re.split(r"\n[ \t]*\n", masked):
        ms = list(FAM37_RE.finditer(para))
        if len(ms) >= 2:
            c37 += len(ms)
            if len(s37) < 3:
                s37.append(short(ms[0].group(0) + " ... " + ms[1].group(0)))
    put(37, (c37, s37))
    put(38, run_regs(FAM38, masked))
    put(39, run_regs(FAM39, masked))
    put(47, run_regs(FAM47, masked))
    put(48, run_regs(FAM48, masked))
    put(50, run_regs(FAM50, masked))
    put(51, run_regs(FAM51, masked))
    put(56, run_regs(FAM56, masked))
    # 57
    em = EMOJI_RE.findall(masked)
    if em:
        f[57] = (len(em), [x for x in dict.fromkeys(em)][:3])
    put(61, _hyphen_ranges(masked))
    # 63
    c63, s63 = run_regs(FAM63, masked)
    for m in ALLCAPS_SLOT.finditer(masked):
        if not SMALL_LABEL.fullmatch(m.group(1)):
            c63 += 1
            if len(s63) < 3:
                s63.append(short(m.group(0)))
    put(63, (c63, s63))
    put(64, run_regs(FAM64, masked))
    # 65
    c65 = 0
    s65 = []
    for m in UTM_RE.finditer(masked):
        host = m.group(1).lower().rstrip(".")
        if host in UTM_HOSTS:
            c65 += 1
            if len(s65) < 3:
                s65.append(short(m.group(0)))
    put(65, (c65, s65))
    put(69, run_regs(FAM69, masked))
    # 70
    hrs = HR_RE.findall(masked)
    if len(hrs) >= 3 and masked.count("\n") + 1 >= 24:
        f[70] = (len(hrs), [short(h) for h in hrs[:3]])
    # 58 em dash
    c58 = 0
    for para in re.split(r"\n[ \t]*\n", masked):
        k = para.count("—")
        if k >= 2:
            c58 += k
    if c58:
        f[58] = (c58, ["—"])
    # 59 title case
    c59 = 0
    s59 = []
    minor = set("a an the and but or nor for so yet of in on at to by up as with from into over via per vs off out".split())
    for m in HEADING_RE.finditer(masked):
        h = m.group(1).strip()
        toks = h.split()
        if len(toks) < 3 or not (h[0].isalpha()) or h.upper() == h:
            continue
        major = [t for t in toks if t.lower().strip(".,:;!?") not in minor]
        if len(major) >= 2 and all(t[0].isupper() for t in major if t[0].isalpha()) and all(t[0].isalpha() for t in major):
            c59 += 1
            if len(s59) < 3:
                s59.append(short(h))
    put(59, (c59, s59))
    # 60
    cu = CURLY_RE.findall(masked)
    if cu:
        f[60] = (len(cu), cu[:3])
    # 34
    if not HEADING_RE.search(masked):
        raw_paras = [[l for l in p.split("\n") if l.strip()] for p in re.split(r"\n[ \t]*\n", masked)]
        raw_paras = [p for p in raw_paras if p]
        listp = [p for p in raw_paras if all(LIST_LINE_RE.match(l) for l in p)]
        prose = [p for p in raw_paras if not any(LIST_LINE_RE.match(l) for l in p)]
        if listp and len(prose) >= 2:
            f[34] = (len(listp), [short(listp[0][0])])
    # 35
    c35 = 0
    s35 = []
    ls = masked.split("\n")
    for i, ln in enumerate(ls):
        hm = re.match(r"^[ \t]{0,3}#{1,6}[ \t]+(.+?)[ \t]*#*[ \t]*$", ln)
        if not hm:
            continue
        j = i + 1
        while j < len(ls) and not ls[j].strip():
            j += 1
        if j >= len(ls):
            continue
        nx = ls[j].strip()
        if re.match(r"^#{1,6}\s", nx) or LIST_LINE_RE.match(nx) or nx.startswith("|") or HR_RE.match(nx):
            continue
        nw = words_of(nx)
        if 0 < len(nw) <= 5:
            hw = {w.lower() for w in words_of(hm.group(1)) if len(w) > 2}
            if any(w.lower() in hw for w in nw):
                c35 += 1
                if len(s35) < 3:
                    s35.append(short(hm.group(1) + " / " + nx))
    put(35, (c35, s35))

    # sentence-based
    total_words = len(words_of(masked))
    if len(all_sents) >= 3:
        wc = [len(words_of(s)) for s in all_sents]
        if cv(wc) < 0.35:
            f[40] = (len(all_sents), ["%d sentences, length variation %.2f" % (len(all_sents), cv(wc))])
    # 41
    wc = [len(words_of(s)) for s in all_sents]
    run = 1
    best = 1
    for i in range(2, len(wc)):
        d1 = wc[i - 1] - wc[i - 2]
        d2 = wc[i] - wc[i - 1]
        if d1 * d2 < 0 and abs(d1) >= 4 and abs(d2) >= 4:
            run = run + 1 if run > 1 else 3
        else:
            run = 1
        best = max(best, run)
    if best >= 6:
        f[41] = (1, ["alternating sentence lengths"])
    # 42
    c42 = 0
    s42 = []
    for ps in para_sents:
        if len(ps) >= 3:
            keys = Counter(" ".join(w.lower() for w in words_of(s)[:2]) for s in ps if len(words_of(s)) >= 2)
            for k, v in keys.items():
                if v >= 3:
                    c42 += 1
                    s42.append(k)
    put(42, (c42, s42[:3]))
    # 44
    pw = [len(words_of(" ".join(p))) for p in paras]
    if len(pw) >= 4 and cv(pw) < 0.4:
        f[44] = (len(pw), ["%d paragraphs, length variation %.2f" % (len(pw), cv(pw))])
    # 46
    if total_words >= 300 and ";" not in masked and masked.count("(") <= 1:
        f[46] = (1, ["no semicolons, almost no parentheses"])
    # 54
    c54 = 0
    for s in all_sents:
        if len(FAM54_RE.findall(s)) >= 2:
            c54 += 1
    if c54:
        f[54] = (c54, ["stacked hedges"])
    # 55
    f55 = _contractions(masked, total_words)
    if f55:
        f[55] = f55
    # 71
    ws = [w.lower() for w in words_of(masked)]
    if len(ws) >= 18:
        grams = [tuple(ws[i:i + 6]) for i in range(len(ws) - 5)]
        cnt = Counter(grams)
        rep = sum(1 for g in grams if cnt[g] > 1)
        if rep and len(grams) >= 12 and rep / len(grams) >= 0.2:
            f[71] = (rep, [" ".join(next(g for g in grams if cnt[g] > 1))])
    return f


def _hyphen_ranges(masked):
    c = 0
    s = []
    for m in FAM61[0].finditer(masked):
        if int(m.group(2)) > int(m.group(1)):
            c += 1
            if len(s) < 3:
                s.append(m.group(0))
    return c, s


FULL_FORMS = re.compile(r"\b(?:do|does|did|is|are|was|were|have|has|had|would|could|should|will|can)\s+not\b|\bcannot\b|\b(?:I|we|you|they)\s+(?:am|are|have|will|would)\b|\b(?:it|that|there|he|she)\s+(?:is|has|will|would)\b", re.I)
CONTRACTED = re.compile(r"\b\w+n['’]t\b|\b\w+['’](?:s|m|re|ve|ll|d)\b", re.I)
FIRST = re.compile(r"\b(?:I|me|my|mine|myself|we|our|ours|us)\b|\bI['’](?:m|ve|ll|d)\b")


def _contractions(masked, total_words):
    if total_words < 20:
        return None
    first = len(FIRST.findall(masked))
    if first / max(total_words, 1) < 0.02:
        return None
    full = len(FULL_FORMS.findall(masked))
    con = len(CONTRACTED.findall(masked))
    if full >= 3 and full > con * 1.0 and full / (full + con) > 0.5:
        return (full, ["%d written-out forms, %d contractions" % (full, con)])
    return None


# ---------------------------------------------------------------- scoring
def confidence_of(words, nfam):
    if words < 40:
        return "none", "fewer than 40 words; too short for a meaningful score"
    if words < 120:
        return "low", "fewer than 120 words; the score is a rough guide"
    if words < 300 and nfam == 1:
        return "low", "under 300 words with only one pattern family fired"
    if words < 300:
        return "moderate", "fewer than 300 words; more text would firm up the score"
    return "high", ""


def compute_score(counts, words):
    """counts: dict catalogue number -> hit count, score-moving families only."""
    total = 0.0
    for n, c in counts.items():
        w = META[n][2]
        total += w * (1 + 0.25 * min(c - 1, 4))
    total *= 1.3
    score = int(round(min(100.0, total)))
    nums = set(counts)
    conf, reason = confidence_of(words, len(nums))
    if len(nums) == 1:
        score = min(score, 40)
    if nums and nums <= {40, 44}:
        score = min(score, 40)
    if nums and nums <= {40}:
        score = min(score, 20)
    dec = nums & DECISIVE
    if len(dec) >= 2:
        score = max(score, 65)
    elif len(dec) == 1 and conf in ("moderate", "high"):
        score = max(score, 45)
    if words < 120:
        k = len(nums & SHORT_NUMS)
        if k >= 3:
            score = max(score, 45)
        elif k >= 2:
            score = max(score, 25)
    if words >= 400:
        if len(nums) >= 6:
            score = max(score, 45)
        elif len(nums) >= 5:
            score = max(score, 25)
    return max(0, min(100, score)), conf, reason


def score_findings(f, words):
    counts = {}
    for k, (c, _) in f.items():
        n = k if isinstance(k, int) else int(k.split("_")[0])
        if n == 17 and k != key_of(17):
            continue
        if META[n][2] > 0:
            counts[n] = counts.get(n, 0) + c
    return compute_score(counts, words)


# ---------------------------------------------------------------- scan
def scan(text, want_ci=False):
    win = text[:WINDOW]
    truncated = len(text) > WINDOW
    win_n = win.replace("\r\n", "\n")
    inv = invisible_positions(win_n)
    spaces = space_positions(win_n)
    runs = homoglyph_runs(win_n)
    n_hg = homoglyph_count(runs, win_n)
    masked = mask_code(win_n)
    f = analyze(masked)
    char_f = {}
    if inv:
        char_f[62] = (len(inv), ["%d invisible characters" % len(inv)])
    if spaces:
        char_f[67] = (len(spaces), ["%d non-standard spaces" % len(spaces)])
    if n_hg:
        char_f[66] = (n_hg, [short(win_n[s:e]) for s, e in runs[:3]])
    tw = trailing_ws_hits(win_n)
    if tw:
        char_f[68] = (tw, ["trailing or stray whitespace"])
    allf = dict(f)
    allf.update(char_f)
    words = len(words_of(masked))
    score, conf, reason = score_findings(allf, words)
    report = {}

    def sort_key(k):
        n = k if isinstance(k, int) else int(k.split("_")[0])
        moving = META[n][2] > 0 and not (n == 17 and k != key_of(17))
        return (0 if moving else 1, n, str(k))

    for k in sorted(allf, key=sort_key):
        n = k if isinstance(k, int) else int(k.split("_")[0])
        if isinstance(k, int):
            key = key_of(n)
            label = META[n][1]
        elif k == key_of(17):
            key = k
            label = META[17][1]
        else:
            key = k
            label = ADVICE_17[1]
        c, smp = allf[k]
        report[key] = {"label": label, "count": int(c), "samples": [str(s) for s in smp[:3]]}
    metrics = {
        "scanned_chars": len(win),
        "truncated": truncated,
        "ai_tell_score": score,
        "ai_tell_band": band_of(score),
        "confidence": conf,
        "confidence_reason": reason,
        "patterns_flagged": len(report),
        "invisible_chars": len(inv),
        "nonstandard_spaces": len(spaces),
        "homoglyphs": n_hg,
        "word_count": words,
    }
    if want_ci:
        sents = [s for ps in [sentences_of_paragraph(p) for p in paragraphs_of(masked)] for s in ps]
        if len(sents) >= 4:
            rng = random.Random(20240601)
            pool = sents[:250]
            scores = []
            for _ in range(20):
                pick = [rng.choice(pool) for _ in range(len(pool))]
                fr = analyze("\n\n".join(pick) if False else " ".join(pick))
                fr.pop(71, None)
                fr.pop(8, None)
                fr.update(char_f)
                sc, _, _ = score_findings(fr, len(words_of(" ".join(pick))))
                scores.append(sc)
            scores.sort()
            lo = scores[int(0.05 * (len(scores) - 1))]
            hi = scores[int(math.ceil(0.95 * (len(scores) - 1)))]
            lo = min(lo, score)
            hi = max(hi, score)
            metrics["score_ci"] = [lo, hi]
            metrics["score_ci_note"] = "resampled 90%% interval over %d sentences (20 resamples)" % len(pool)
        else:
            metrics["score_ci"] = None
            metrics["score_ci_note"] = "too few sentences (fewer than 4) for an interval"
    report["_metrics"] = metrics
    return report


# ---------------------------------------------------------------- CLI
def fail(msg, code):
    sys.stderr.write(json.dumps({"error": msg}) + "\n")
    sys.stderr.flush()
    sys.exit(code)


def main(argv):
    clean = False
    ci = False
    operands = []
    opts_done = False
    for a in argv:
        if opts_done:
            operands.append(a)
        elif a == "--":
            opts_done = True
        elif a in ("-h", "--help"):
            out = sys.stdout
            out.write(USAGE)
            out.flush()
            return 0
        elif a == "--clean":
            clean = True
        elif a == "--ci":
            ci = True
        elif a.startswith("-"):
            fail("unknown option: %s (try --help)" % a, 2)
        else:
            operands.append(a)
    if operands:
        path = operands[0]
        if len(operands) > 1:
            sys.stderr.write("note: only the first file was scanned: %s (ignored %d more)\n" % (path, len(operands) - 1))
        ext = os.path.splitext(path)[1].lower()
        try:
            with open(path, "rb") as fh:
                data = fh.read()
        except (OSError, ValueError) as e:
            fail("cannot read input: %s" % (getattr(e, "strerror", None) or str(e)), 1)
        try:
            text = extract(ext, data)
        except NotReadable as e:
            fail("cannot read input: %s" % e, 1)
        except Exception as e:  # noqa
            fail("cannot read input: %s" % e, 1)
    else:
        try:
            data = sys.stdin.buffer.read()
        except Exception as e:  # noqa
            fail("cannot read input: %s" % e, 1)
        text = decode_bytes(data)
    if text.startswith("﻿"):
        text = text[1:]
    if not text.strip():
        fail("empty input", 1)
    if clean:
        out = clean_text(text)
        sys.stdout.buffer.write(out.encode("utf-8", errors="replace"))
        sys.stdout.buffer.flush()
        return 0
    rep = scan(text, ci)
    sys.stdout.buffer.write((json.dumps(rep, ensure_ascii=False, indent=2) + "\n").encode("utf-8", errors="replace"))
    sys.stdout.buffer.flush()
    return 0


if __name__ == "__main__":
    try:
        rc = main(sys.argv[1:])
    except SystemExit:
        raise
    except BrokenPipeError:
        rc = 0
    except Exception as e:  # noqa: no traceback
        sys.stderr.write(json.dumps({"error": "internal error: %s" % e}) + "\n")
        rc = 1
    sys.exit(rc)
