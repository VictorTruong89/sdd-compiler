#!/usr/bin/env python3
"""prosecheck detector: local prose-pattern scan. Standard library only."""
import sys, os, re, json, io, zipfile, math, unicodedata, random, time
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

WINDOW = 262144
USAGE = "usage: detect.py [--clean] [--ci] [--] [FILE]"
PLAIN_EXT = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXT = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NB_EXT = {'.ipynb'}

TITLES = {
 1: "AI vocabulary", 2: "Model-dialect vocabulary", 3: "Promotional language", 4: "Hyphenated word-pair overuse",
 5: "“Simple yet X” cliche", 6: "Stacked adjective chains", 8: "Synonym cycling", 10: "Significance inflation",
 11: "Notability name-dropping", 12: "Vague attributions", 13: "Article-titles-as-proper-nouns",
 14: "Conservation / ecosystem padding", 15: "False ranges", 16: "Superficial -ing tail clauses",
 17: "Negative parallelisms and tailing negations", 18: "“Not X, just Y” / “No X, just Y”",
 19: "Filler phrases", 20: "Empty pivot phrases", 21: "Outcome speculation tails", 22: "Persuasive authority tropes",
 23: "Editorial interjections", 24: "Self-thoroughness phrases", 25: "Question-answer rhetorical pattern",
 26: "“Concrete evidence” defense phrase", 27: "Compulsive intro hooks", 30: "Diff-anchored writing",
 31: "Signposting and announcements", 32: "Cataloguing lead-ins", 33: "Inline-header vertical lists",
 34: "Mid-essay bullet injection", 35: "Fragmented headers", 36: "Formulaic challenges sections",
 37: "Transition cluster overuse", 38: "Compulsive conclusion phrases", 39: "Generic positive conclusions",
 40: "Sentence-length monotony", 41: "Mechanical sentence-length alternation", 42: "Opener repetition",
 44: "Uniform paragraph length", 46: "Semicolon and parenthesis underuse", 47: "Chatbot artifacts",
 48: "Sycophantic / servile tone", 50: "Knowledge-cutoff disclaimers", 51: "Copula avoidance",
 54: "Excessive hedging", 55: "Contraction absence", 56: "Boldface overuse", 57: "Emojis", 58: "Em-dash overuse",
 59: "Title case in headings", 60: "Curly quotation marks", 61: "Hyphen-for-en-dash in ranges",
 62: "Invisible / zero-width characters", 63: "Placeholder / Mad-Libs text", 64: "Chatbot reference-markup leak",
 65: "AI tracking params", 66: "Homoglyph / mixed-script confusables", 67: "Non-standard spaces",
 68: "Trailing / stray whitespace", 69: "Canonical marketing-slop phrases", 70: "Decorative horizontal rules",
 71: "Degenerate repetition",
}
LABEL_17_PAR = "Negative parallelisms"
LABEL_17_TAIL = "Tailing negations"
ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
SHORT_SET = set(range(1, 40)) | {47, 48, 49, 50, 51, 69}
BANDS = [(20, 'clean'), (40, 'light tells'), (60, 'mixed'), (80, 'heavy tells'), (100, 'pervasive tells')]


def band_of(score):
    for hi, name in BANDS:
        if score <= hi:
            return name
    return BANDS[-1][1]


def slug(label):
    s = re.sub(r'[^a-z0-9]+', '_', label.lower()).strip('_')
    return s or 'finding'


# ---------------------------------------------------------------- character layer
def _is_cjk(c):
    o = ord(c)
    return (0x3400 <= o <= 0x4DBF or 0x4E00 <= o <= 0x9FFF or 0xF900 <= o <= 0xFAFF or
            0x20000 <= o <= 0x2FFFF or 0x3005 <= o <= 0x3007 or 0x3021 <= o <= 0x3029 or 0x3038 <= o <= 0x303B)

def _is_kana(c):
    o = ord(c)
    return 0x3040 <= o <= 0x30FF or 0x31F0 <= o <= 0x31FF or 0xFF66 <= o <= 0xFF9F

def _is_nospace_script(c):
    o = ord(c)
    return (_is_cjk(c) or _is_kana(c) or 0x0E00 <= o <= 0x0E7F or 0x0E80 <= o <= 0x0EFF or
            0x1780 <= o <= 0x17FF or 0x1000 <= o <= 0x109F or 0xA9E0 <= o <= 0xA9FF or 0xAA60 <= o <= 0xAA7F)

def _is_rtl(c):
    o = ord(c)
    return (0x0590 <= o <= 0x08FF and unicodedata.category(c).startswith('L')) or \
        (0xFB1D <= o <= 0xFDFF and unicodedata.category(c).startswith('L')) or \
        (0xFE70 <= o <= 0xFEFF and unicodedata.category(c).startswith('L')) or \
        (0x10800 <= o <= 0x10FFF and unicodedata.category(c).startswith('L')) or \
        (0x1E800 <= o <= 0x1EFFF and unicodedata.category(c).startswith('L'))

def _is_joining_letter(c):
    o = ord(c)
    if not unicodedata.category(c)[0] in 'LM':
        return False
    return (0x0590 <= o <= 0x08FF or 0x0900 <= o <= 0x0DFF or 0x1000 <= o <= 0x109F or
            0x1780 <= o <= 0x17FF or 0xFB1D <= o <= 0xFDFF or 0xFE70 <= o <= 0xFEFF)

def _is_emoji_or_symbol(c):
    o = ord(c)
    if o >= 0x1F000 and o < 0xE0000:
        return True
    if c in '©®‼⁉™ℹ〰〽㊗㊙‍':
        return c != '‍'
    if 0x2190 <= o <= 0x2BFF or 0x2300 <= o <= 0x23FF:
        return True
    return unicodedata.category(c) in ('So', 'Sk', 'Sm')

def _is_mongolian(c):
    return 0x1800 <= ord(c) <= 0x18AF and unicodedata.category(c)[0] == 'L'

def _is_khmer(c):
    return 0x1780 <= ord(c) <= 0x17FF

PREFIX_CF = {0x600, 0x601, 0x602, 0x603, 0x604, 0x605, 0x6DD, 0x70F, 0x890, 0x891, 0x8E2, 0x110BD, 0x110CD}

def is_invisible_candidate(c):
    o = ord(c)
    if o < 0x80:
        return o < 0x20 and c not in '\t\n\r' or o == 0x7F
    if o in PREFIX_CF:
        return False
    if 0x80 <= o <= 0x9F:
        return True
    if o in (0x34F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x3164, 0xFFA0, 0x180E):
        return True
    if 0x180B <= o <= 0x180F or 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF or 0xE0000 <= o <= 0xE0FFF:
        return True
    if 0x200B <= o <= 0x200F or 0x202A <= o <= 0x202E or 0x2060 <= o <= 0x206F:
        return True
    if o in (0xFEFF, 0xAD, 0x61C, 0xFFF9, 0xFFFA, 0xFFFB):
        return True
    if 0x1D173 <= o <= 0x1D17A:
        return True
    return unicodedata.category(c) == 'Cf'

BIDI = set([0x200E, 0x200F, 0x61C] + list(range(0x202A, 0x202F)) + list(range(0x2066, 0x206A)))

def _prev_nonvs(t, i):
    j = i - 1
    while j >= 0 and (0xFE00 <= ord(t[j]) <= 0xFE0F):
        j -= 1
    return t[j] if j >= 0 else ''

def _next_nonvs(t, i):
    j = i + 1
    while j < len(t) and (0xFE00 <= ord(t[j]) <= 0xFE0F):
        j += 1
    return t[j] if j < len(t) else ''

def analyze_chars(t):
    """Return (remove_indexes_set, nbsp_keep, nss_indexes) for text t."""
    n = len(t)
    cand = []
    has_cand = False
    has_rtl = None
    remove = set()
    keep_tag = set()
    # emoji tag sequences
    i = 0
    while i < n:
        c = t[i]
        if c == '\U0001F3F4':
            j = i + 1
            while j < n and 0xE0020 <= ord(t[j]) <= 0xE007E:
                j += 1
            if j > i + 1 and j < n and ord(t[j]) == 0xE007F:
                for k in range(i + 1, j + 1):
                    keep_tag.add(k)
                i = j
        i += 1
    for i in range(n):
        c = t[i]
        if not is_invisible_candidate(c):
            continue
        o = ord(c)
        keep = False
        if 0xE0000 <= o <= 0xE0FFF and o not in range(0xE0100, 0xE01F0):
            keep = i in keep_tag
        elif 0xE0100 <= o <= 0xE01EF:
            keep = i > 0 and _is_cjk(t[i - 1])
        elif 0xFE00 <= o <= 0xFE0F:
            p = t[i - 1] if i > 0 else ''
            nx = t[i + 1] if i + 1 < n else ''
            if p and (_is_cjk(p) or (_is_emoji_or_symbol(p) and not (0xFE00 <= ord(p) <= 0xFE0F))):
                keep = True
            elif nx == '⃣':
                keep = True
            elif p and (p.isdigit() or p in '#*') and nx == '⃣':
                keep = True
        elif o == 0x200B:
            p = t[i - 1] if i > 0 else ''
            nx = t[i + 1] if i + 1 < n else ''
            keep = bool((p and _is_nospace_script(p)) or (nx and _is_nospace_script(nx)))
        elif o == 0xAD:
            p = t[i - 1] if i > 0 else ''
            nx = t[i + 1] if i + 1 < n else ''
            keep = bool(p and nx and p.isalpha() and nx.isalpha())
        elif o in BIDI:
            if has_rtl is None:
                has_rtl = any(_is_rtl(ch) for ch in t if ord(ch) > 0x58F)
            keep = has_rtl
        elif 0x180B <= o <= 0x180F:
            keep = o != 0x180E and i > 0 and _is_mongolian(t[i - 1])
        elif o in (0x17B4, 0x17B5):
            p = t[i - 1] if i > 0 else ''
            nx = t[i + 1] if i + 1 < n else ''
            keep = bool((p and _is_khmer(p)) or (nx and _is_khmer(nx)))
        elif o in (0x200C, 0x200D):
            p = _prev_nonvs(t, i)
            nx = _next_nonvs(t, i)
            keep = False
            for x in (p, nx):
                if x and (_is_joining_letter(x) or _is_emoji_or_symbol(x)):
                    keep = True
        if not keep:
            remove.add(i)
    return remove


NBSPS = (' ', ' ')

def is_space_sep(c):
    cat = unicodedata.category(c)
    return (cat in ('Zs', 'Zl', 'Zp')) and c != ' '

def nss_indexes(t):
    """Indexes of non-standard spaces that cleanup normalizes (excluding kept no-break spaces)."""
    res = []
    n = len(t)
    for i, c in enumerate(t):
        if c == ' ' or ord(c) < 0xA0 and c != '\x85':
            continue
        if not is_space_sep(c):
            continue
        if c in NBSPS:
            p = t[i - 1] if i > 0 else ''
            nx = t[i + 1] if i + 1 < n else ''
            if (p and p.isdigit()) or (nx and nx.isdigit()) or (nx and nx in ':;!?»›%€') or (p and p in '«‹'):
                continue
        res.append(i)
    return res


CONFUSABLE = {}
def _mk(src, dst):
    for a, b in zip(src, dst):
        CONFUSABLE[a] = b
_mk('асеорхуіјѕԁһԛԝ', 'acceopxyijsdhqw')
_mk('АВСЕНІЈКМОРЅТХУ', 'ABCEHIJKMOPSTXY')
_mk('ονρυια', 'ovpuia')
_mk('ΑΒΕΖΗΙΚΜΝΟΡΤΧΥ', 'ABEZHIKMNOPTXY')
_mk('օսոհց', 'ounhg')
_mk('ՕՍ', 'OS')

def homoglyph_spans(t):
    """Return list of (token_start, token_end, [indexes of lookalike chars]) for tokens meeting the condition."""
    out = []
    for m in re.finditer(r'\S+', t):
        tok = m.group(0)
        if tok.isascii():
            continue
        bad = False
        for ch in tok:
            if ord(ch) > 127 and ch.isalpha() and ch not in CONFUSABLE:
                bad = True
                break
        if bad:
            continue
        idx = []
        s = m.start()
        # per run of letters
        k = 0
        L = len(tok)
        while k < L:
            if not tok[k].isalpha():
                k += 1
                continue
            e = k
            while e < L and tok[e].isalpha():
                e += 1
            run = tok[k:e]
            has_ascii = any(ch.isascii() for ch in run)
            looks = [k + j for j, ch in enumerate(run) if ch in CONFUSABLE]
            if has_ascii and looks:
                idx.extend(s + x for x in looks)
            k = e
        if idx:
            out.append((m.start(), m.end(), idx))
    return out


def clean_text(t):
    rem = analyze_chars(t)
    nss = set(nss_indexes(t))
    homo = {}
    for (_s, _e, idx) in homoglyph_spans(t):
        for x in idx:
            homo[x] = CONFUSABLE[t[x]]
    out = []
    for i, c in enumerate(t):
        if i in rem:
            continue
        if i in homo:
            out.append(homo[i])
        elif i in nss:
            o = ord(c)
            out.append('\n' if c in '  ' else ' ')
        else:
            out.append(c)
    s = ''.join(out)
    # trim per line
    ended_crlf = s.endswith('\r\n')
    ended_lf = s.endswith('\n')
    lines = s.split('\n')
    lines = [ln.rstrip(' \t\r') if True else ln for ln in lines]
    # preserve CRLF line endings where they existed: re-add \r for lines that had it
    orig_lines = s.split('\n')
    res = []
    for ln, ol in zip(lines, orig_lines):
        res.append(ln + ('\r' if ol.endswith('\r') else ''))
    # drop leading blank lines
    k = 0
    while k < len(res) and res[k].strip(' \t\r') == '':
        k += 1
    res = res[k:]
    body = '\n'.join(res)
    body = body.rstrip(' \t\r\n\f\v')
    if (ended_lf or ended_crlf) and body:
        body += '\r\n' if ended_crlf else '\n'
    return body


# ---------------------------------------------------------------- extraction
def _local(tag):
    return tag.rsplit('}', 1)[-1] if '}' in tag else tag

def _parse_xml(data):
    return ET.fromstring(data)

def _para_text_ooxml(p):
    parts = []
    for el in p.iter():
        ln = _local(el.tag)
        if ln == 't' and el.text:
            parts.append(el.text)
        elif ln == 'tab':
            parts.append('\t')
        elif ln in ('br', 'cr'):
            parts.append('\n')
    return ''.join(parts)

def _ooxml_paragraphs(root):
    res = []
    for el in root.iter():
        if _local(el.tag) == 'p':
            res.append(_para_text_ooxml(el))
    return res

def _numkey(name):
    m = re.findall(r'\d+', name)
    return (int(m[-1]) if m else 0, name)

def extract_docx(z):
    names = [n for n in z.namelist() if n == 'word/document.xml']
    if not names:
        return ''
    return '\n'.join(p for p in _ooxml_paragraphs(_parse_xml(z.read(names[0]))) if p.strip())

def extract_pptx(z):
    slides = sorted([n for n in z.namelist() if re.match(r'ppt/slides/slide\d+\.xml$', n)], key=_numkey)
    out = []
    for n in slides:
        try:
            ps = [p for p in _ooxml_paragraphs(_parse_xml(z.read(n))) if p.strip()]
        except ET.ParseError:
            continue
        out.extend(ps)
    return '\n'.join(out)

def extract_xlsx(z):
    shared = []
    if 'xl/sharedStrings.xml' in z.namelist():
        try:
            root = _parse_xml(z.read('xl/sharedStrings.xml'))
            for si in root:
                if _local(si.tag) == 'si':
                    shared.append(''.join(e.text or '' for e in si.iter() if _local(e.tag) == 't'))
        except ET.ParseError:
            pass
    sheets = sorted([n for n in z.namelist() if re.match(r'xl/worksheets/sheet\d+\.xml$', n)], key=_numkey)
    out = []
    for n in sheets:
        try:
            root = _parse_xml(z.read(n))
        except ET.ParseError:
            continue
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            t = c.get('t')
            txt = None
            if t == 's':
                v = next((e for e in c if _local(e.tag) == 'v'), None)
                if v is not None and v.text is not None and re.fullmatch(r'\s*\d+\s*', v.text):
                    i = int(v.text)
                    if i < len(shared):
                        txt = shared[i]
            elif t == 'inlineStr':
                is_ = next((e for e in c if _local(e.tag) == 'is'), None)
                if is_ is not None:
                    txt = ''.join(e.text or '' for e in is_.iter() if _local(e.tag) == 't')
            elif t == 'str':
                v = next((e for e in c if _local(e.tag) == 'v'), None)
                if v is not None:
                    txt = v.text or ''
            if txt is not None and txt.strip():
                out.append(txt)
    return '\n'.join(out)

def _odf_text(el, acc):
    ln = _local(el.tag)
    if ln == 's':
        c = el.get('{urn:oasis:names:tc:opendocument:xmlns:text:1.0}c') or '1'
        try:
            acc.append(' ' * int(c))
        except ValueError:
            acc.append(' ')
    elif ln == 'tab':
        acc.append('\t')
    elif ln == 'line-break':
        acc.append('\n')
    else:
        if el.text:
            acc.append(el.text)
        for ch in el:
            _odf_text(ch, acc)
    if ln not in ('p', 'h') or True:
        pass

def _odf_para(el):
    acc = []
    if el.text:
        acc.append(el.text)
    for ch in el:
        _odf_text(ch, acc)
        if ch.tail:
            acc.append(ch.tail)
    return ''.join(acc)

def extract_odf(z):
    if 'content.xml' not in z.namelist():
        return ''
    root = _parse_xml(z.read('content.xml'))
    out = []
    def walk(el):
        ln = _local(el.tag)
        if ln in ('p', 'h'):
            t = _odf_para(el)
            if t.strip():
                out.append(t)
            return
        for ch in el:
            walk(ch)
    walk(root)
    return '\n'.join(out)

class _Html(HTMLParser):
    BLOCK = {'p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'br', 'tr', 'blockquote', 'section', 'article', 'pre', 'ul', 'ol', 'table', 'hr', 'dt', 'dd', 'figcaption'}
    SKIP = {'style', 'script', 'nav', 'head', 'title', 'svg'}
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.skip = 0
        self.buf = ['']
    def handle_starttag(self, tag, attrs):
        tag = tag.split(':')[-1].lower()
        if tag in self.SKIP:
            self.skip += 1
        if tag in self.BLOCK:
            self.buf.append('')
    def handle_startendtag(self, tag, attrs):
        tag = tag.split(':')[-1].lower()
        if tag in self.BLOCK:
            self.buf.append('')
    def handle_endtag(self, tag):
        tag = tag.split(':')[-1].lower()
        if tag in self.SKIP and self.skip:
            self.skip -= 1
        if tag in self.BLOCK:
            self.buf.append('')
    def handle_data(self, data):
        if not self.skip:
            self.buf[-1] += data

def _opf_order(z):
    names = z.namelist()
    opf = next((n for n in names if n.lower().endswith('.opf')), None)
    if not opf:
        return None
    try:
        root = _parse_xml(z.read(opf))
    except ET.ParseError:
        return None
    manifest = {}
    spine = []
    for el in root.iter():
        ln = _local(el.tag)
        if ln == 'item':
            manifest[el.get('id')] = el.get('href')
        elif ln == 'itemref':
            spine.append(el.get('idref'))
    base = opf.rsplit('/', 1)[0] + '/' if '/' in opf else ''
    from urllib.parse import unquote
    res = []
    for r in spine:
        h = manifest.get(r)
        if h:
            p = os.path.normpath(base + unquote(h)).replace('\\', '/')
            if p in names:
                res.append(p)
    return res or None

def extract_epub(z):
    names = z.namelist()
    html = [n for n in names if n.lower().endswith(('.xhtml', '.html', '.htm'))]
    order = _opf_order(z)
    if order:
        rest = [n for n in sorted(html) if n not in order]
        docs = [n for n in order if n.lower().endswith(('.xhtml', '.html', '.htm'))] + rest
    else:
        docs = sorted(html)
    out = []
    for n in docs:
        raw = z.read(n)
        txt = raw.decode('utf-8', 'replace')
        if re.search(r'epub:type\s*=\s*["\']toc["\']', txt) and not re.search(r'<p\b', txt):
            continue
        p = _Html()
        try:
            p.feed(txt)
            p.close()
        except Exception:
            continue
        for b in p.buf:
            b = re.sub(r'\s+', ' ', b).strip()
            if b:
                out.append(b)
    return '\n'.join(out)

def extract_notebook(data):
    try:
        nb = json.loads(data.decode('utf-8-sig', 'replace'))
    except Exception:
        return ''
    cells = nb.get('cells') if isinstance(nb, dict) else None
    if not isinstance(cells, list):
        return ''
    out = []
    for c in cells:
        if not isinstance(c, dict) or c.get('cell_type') != 'markdown':
            continue
        src = c.get('source')
        if isinstance(src, str):
            s = src
        elif isinstance(src, list) and all(isinstance(x, str) for x in src):
            s = ''.join(src)
        else:
            continue
        if s.strip():
            out.append(s.strip('\n'))
    return '\n'.join(out)

def decode_bytes(b):
    if b.startswith(b'\xef\xbb\xbf'):
        return b[3:].decode('utf-8', 'replace')
    if b.startswith(b'\xff\xfe') or b.startswith(b'\xfe\xff'):
        try:
            return b.decode('utf-16')
        except UnicodeDecodeError:
            return b.decode('utf-16', 'replace')
    return b.decode('utf-8', 'replace')

class ReadError(Exception):
    pass

def load_prose(path):
    ext = os.path.splitext(path)[1].lower()
    try:
        with open(path, 'rb') as f:
            data = f.read()
    except (OSError, ValueError) as e:
        raise ReadError(str(e))
    if ext in ZIP_EXT:
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
        except zipfile.BadZipFile as e:
            raise ReadError('not a readable zip archive: %s' % path)
        try:
            if ext in ('.docx', '.docm'):
                t = extract_docx(z)
            elif ext in ('.pptx', '.pptm'):
                t = extract_pptx(z)
            elif ext in ('.xlsx', '.xlsm'):
                t = extract_xlsx(z)
            elif ext == '.epub':
                t = extract_epub(z)
            else:
                t = extract_odf(z)
        except (ET.ParseError, KeyError, zipfile.BadZipFile, RuntimeError, ValueError):
            t = ''
        return t.strip()
    if ext in NB_EXT:
        return extract_notebook(data).strip()
    if ext in ('.pdf', '.rtf'):
        return ''
    return decode_bytes(data)


# ---------------------------------------------------------------- masking
FENCE_RE = re.compile(r'^( {0,3})(`{3,}|~{3,})(.*)$')
BADGE_RE = re.compile(r'^\s*(?:\[?!\[[^\]]*\]\([^)]*\)(?:\]\([^)]*\))?\s*)+$')

def mask_text(text):
    """Return text with code/table/quote/badge/front-matter regions replaced by spaces (same length)."""
    lines = text.split('\n')
    n = len(lines)
    masked = [False] * n
    i = 0
    if n and lines[0].rstrip() == '---':
        for j in range(1, n):
            if lines[j].rstrip() in ('---', '...'):
                for k in range(0, j + 1):
                    masked[k] = True
                i = j + 1
                break
    in_fence = False
    fch = ''
    flen = 0
    while i < n:
        ln = lines[i].rstrip('\r')
        if in_fence:
            masked[i] = True
            m = FENCE_RE.match(ln)
            if m and m.group(2)[0] == fch and len(m.group(2)) >= flen and m.group(3).strip() == '':
                in_fence = False
            i += 1
            continue
        m = FENCE_RE.match(ln)
        if m and not (m.group(2)[0] == '`' and '`' in m.group(3)):
            in_fence = True
            fch = m.group(2)[0]
            flen = len(m.group(2))
            masked[i] = True
        i += 1
    # blockquote runs
    i = 0
    while i < n:
        if not masked[i] and lines[i].lstrip().startswith('>'):
            j = i
            while j < n and not masked[j] and lines[j].lstrip().startswith('>'):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    masked[k] = True
            i = j
        else:
            i += 1
    for i in range(n):
        if masked[i]:
            continue
        s = lines[i].strip()
        if s.startswith('|') and s.count('|') >= 2 or (re.match(r'^\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)+\|?$', s)):
            masked[i] = True
        elif s and BADGE_RE.match(s):
            masked[i] = True
    out = []
    for i in range(n):
        ln = lines[i]
        if masked[i]:
            out.append(re.sub(r'[^\r]', ' ', ln))
        else:
            out.append(re.sub(r'(`+)(?!`)(.+?)(?<!`)\1(?!`)', lambda m: ' ' * len(m.group(0)), ln))
    return '\n'.join(out)


# ---------------------------------------------------------------- text structure helpers
WORD_RE = re.compile(r"(?:[^\W_]|['’-])+")

def count_words(s):
    return len(WORD_RE.findall(s))

def paragraphs(masked):
    res = []
    cur = []
    for ln in masked.split('\n'):
        if ln.strip() == '':
            if cur:
                res.append(' '.join(x.strip() for x in cur))
                cur = []
        else:
            cur.append(ln)
    if cur:
        res.append(' '.join(x.strip() for x in cur))
    return res

LIST_RE = re.compile(r'^\s*(?:[-*+]|\d+[.)])\s+')
HEAD_RE = re.compile(r'^\s{0,3}#{1,6}\s+(.*?)\s*#*\s*$')

def prose_blocks(masked):
    """Paragraph strings made of plain prose lines (no headings, lists, rules)."""
    res = []
    cur = []
    def flush():
        if cur:
            res.append(' '.join(x.strip() for x in cur))
            cur.clear()
    for ln in masked.split('\n'):
        if ln.strip() == '' or HEAD_RE.match(ln) or LIST_RE.match(ln) or re.match(r'^\s*(?:-{3,}|\*{3,}|_{3,})\s*$', ln):
            flush()
        else:
            cur.append(ln)
    flush()
    return res

SENT_SPLIT = re.compile(r'(?<=[.!?])["\')\]”’]*\s+')

def split_sentences(block):
    return [s.strip() for s in SENT_SPLIT.split(block) if s.strip()]

def get_sentences(masked):
    out = []
    for b in prose_blocks(masked):
        for s in split_sentences(b):
            if count_words(s) > 0:
                out.append(s)
    return out

def cv(vals):
    m = sum(vals) / len(vals)
    if m == 0:
        return 1.0
    var = sum((v - m) ** 2 for v in vals) / len(vals)
    return math.sqrt(var) / m


# ---------------------------------------------------------------- pattern definitions
def R(p, flags=re.I):
    return re.compile(p, flags)

AI_VOCAB = [
 'additionally', r'align(?:s|ed|ing)? with', 'crucial', r'delv(?:e|es|ed|ing)', r'tapestr(?:y|ies)', 'pivotal', 'vibrant',
 r'meticulous(?:ly)?', r'testaments?', r'underscor(?:e|es|ed|ing)', r'intricate(?:ly)?', r'intricac(?:y|ies)', 'interplay',
 r'garner(?:s|ed|ing)?', r'bolster(?:s|ed|ing)?', r'foster(?:s|ed|ing)?', r'showcas(?:e|es|ed|ing)',
 r'emphasi[sz](?:e|es|ed|ing)', 'enduring', r'enhanc(?:e|es|ed|ing)', r'leverag(?:e|es|ed|ing)', r'utili[sz](?:e|es|ed|ing)',
 r'facilitat(?:e|es|ed|ing)', r'encompass(?:es|ed|ing)?', r'harness(?:es|ed|ing)?', r'holistic(?:ally)?', r'paradigms?',
 'transformative', 'unprecedented', 'myriad', 'plethora', r'robust(?:ness)?', r'seamless(?:ly)?', r'navigat(?:e|es|ed|ing)',
 r'embark(?:s|ed|ing)?', r'craft(?:s|ed|ing)?', r'landscapes?', r'journey(?:s|ed|ing)?', r'realms?', 'multifaceted',
 r'elevat(?:e|es|ed|ing)', r'empower(?:s|ed|ing|ment)?', r'unlock(?:s|ed|ing)?',
 r'captur(?:e|es|ed|ing) the (?:essence|spirit|imagination|heart|magic)',
]
DIALECT = [
 'genuinely', 'fascinating', 'nuanced', 'thoughtfully', 'refreshingly', 'strikingly', 'compellingly',
 r'quietly (?:powerful|profound|radical)', r'deeply (?:human|personal|felt|unsettling)', r'resonat(?:e|es|ed|ing) deeply',
 r'game[- ]chang(?:er|ers|ing)', r'supercharg(?:e|es|ed|ing)', r'skyrocket(?:s|ed|ing)?', r'turbocharg(?:e|es|ed|ing)',
 r'revolutioni[sz](?:e|es|ed|ing)', r'doubl(?:e|es|ed|ing) down on', r'div(?:e|es|ed|ing) deep(?:er)? into',
 r'unlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)', r'tak(?:e|es|ing|en) [^.!?\n]{1,40}? to the next level',
]
PROMO = [
 'nestled', 'breathtaking', 'must-visit', 'stunning', 'picturesque', 'charming', 'idyllic', 'vibrant community',
 'rich cultural heritage', 'in the heart of', 'world-class', 'top-tier', 'unparalleled', 'premier',
 r'(?:a|the|our|as a) leading', 'esteemed organization', 'valuable asset', 'passion for excellence',
 'proven track record', 'results-oriented', 'wealth of experience', 'dynamic team', 'fast-paced environment',
 'deeply passionate', 'perfectly situated', r'(?:close|tight)-knit team', r'i am excited to (?:apply|bring)',
 'uniquely positioned to',
]
IMPERATIVES = 'install|join|grab|download|try|discover|experience|escape|transform|reclaim|unlock|elevate|boost|say|imagine|explore|meet|introducing|upgrade|claim|unleash|supercharge|level|stop|start'
HYPHEN_CLICHES = ['state-of-the-art', 'cutting-edge', 'best-in-class', 'results-driven', 'data-driven', 'detail-oriented',
  'forward-thinking', 'high-quality', 'end-to-end', 'next-generation', 'game-changing', 'customer-centric', 'fast-moving',
  'well-rounded', 'hands-on', 'mission-critical', 'value-added', 'future-proof', 'world-leading', 'cross-functional',
  'thought-provoking', 'time-tested', 'out-of-the-box', 'all-in-one', 'one-stop-shop', 'top-notch', 'full-service', 'big-picture',
  'client-focused', 'goal-oriented', 'self-starter', 'team-oriented', 'high-performing', 'award-winning', 'ever-evolving',
  'ever-changing', 'ground-breaking', 'groundbreaking']
SYN_CLUSTERS = [
 ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
 ['company', 'firm', 'organization', 'enterprise', 'business'],
 ['author', 'writer', 'novelist', 'scribe'],
 ['report', 'study', 'analysis', 'investigation', 'examination'],
 ['technology', 'tool', 'system', 'platform', 'solution'],
 ['technique', 'method', 'approach', 'strategy', 'tactic'],
 ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
 ['benefit', 'advantage', 'upside', 'strength'],
]
def _plural_re(w):
    if w.endswith('y') and not w.endswith('ey'):
        return re.escape(w[:-1]) + r'(?:y|ies)'
    if w.endswith('is'):
        return re.escape(w) + r'(?:es)?'
    return re.escape(w) + r'(?:e?s)?'
SYN_RES = [[(w, re.compile(r'\b' + _plural_re(w) + r'\b', re.I)) for w in cl] for cl in SYN_CLUSTERS]

ADJ_SUFFIX = re.compile(r'(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$', re.I)
STOCK_ADJ = set('innovative dynamic passionate seamless robust powerful elegant stunning vibrant comprehensive reliable scalable flexible efficient modern cutting-edge intuitive'.split())

TRANS = 'Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably'

REGEXES = {}  # num -> list of (regex, min_hits)
def reg(num, pats, flags=re.I, min_hits=1):
    REGEXES.setdefault(num, []).append((re.compile('|'.join('(?:%s)' % p for p in pats), flags), min_hits))

reg(1, [r'\b(?:%s)\b' % '|'.join(AI_VOCAB)])
reg(2, [r'\b(?:%s)\b' % '|'.join(DIALECT)], min_hits=2)
reg(3, [r'\b(?:%s)\b' % '|'.join(PROMO)])
reg(4, [r'\b(?:%s)\b' % '|'.join(HYPHEN_CLICHES)])
reg(5, [r'\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b'])
reg(10, [
 r'\b(?:stands?|serves?|stood|served|standing|serving) as an? (?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b',
 r'\b(?:underscor|highlight)(?:es|ed|ing|s|e)? (?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b',
 r'\breflects? a broader (?:trend|shift|pattern)\b',
 r'\bmarks? an? (?:turning point|milestone|watershed|new chapter|new era)\b',
 r'\bsymboli[sz]es\b', r'\bsets? the stage for\b', r'\bleft an indelible mark\b',
 r'\bplays? an? (?:crucial|pivotal|vital|key|central|significant) role\b',
 r'\bhas (?:shaped|sparked)\b', r'\bhas come to (?:define|symbolize|symbolise)\b'])
reg(11, [
 r'\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by) [^.!?\n]*?\b(?:[A-Z][\w&]+(?: [A-Z][\w&]+)*)(?:,| and) (?:[A-Z][\w&]+(?: [A-Z][\w&]+)*)',
 r'\b[\d,.]+[kKmM]? (?:followers|subscribers)\b',
 r'\b(?:strong|active) (?:online|digital|social[- ]media) presence\b', r'\bwidely covered\b', r'\bindependent coverage\b'], flags=0)
reg(12, [r'\bexperts (?:argue|believe|say|claim|note|suggest)\b', r'\b(?:industry reports|industry observers|industry analysts)\b',
 r'\bobservers have (?:cited|noted)\b', r'\bsome critics argue\b', r'\bresearchers have found\b', r'\bstudies suggest\b',
 r'\bit is widely believed\b'])
reg(13, [r'\bthe (?:list|index|compilation|collection|catalogue|guide|overview) of (?:[\w\'’:-]+ ){1,8}?(?:is|are|was|were) (?:a|an|the)\b'])
reg(14, [r'\bplays? an? (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b',
 r'\bconservation efforts are (?:underway|ongoing|in place)\b', r'\bserves as an indicator species\b', r'\bcontributes? to biodiversity\b'])
reg(15, [r'\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?]{0,120}?\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering|grand|sprawling)\b'])
reg(16, [r',\s+(?:highlighting|reflecting|symbolizing|symbolising|emphasizing|emphasising|underscoring|showcasing|fostering|cultivating|encompassing|signaling|signalling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing|epitomising)\b'])
reg(17, [r"\bit['’]s not (?:just|merely) (?:about|an?)\b", r"\bnot only\b[^.!?\n]{0,40}\bbut\b", r"\bdoesn['’]t just\b[^,.\n]{0,40}\bit\b"])  # parallelism (advice)
reg(18, [r'\b(?:no|not) \w+, (?:just|only|simply) \w+',
 r"\b(?:not|isn['’]t|aren['’]t|wasn['’]t|weren['’]t) (?:just|merely) (?:(?:a|an|the) )?\w+(?:,|\s+-|\s*—|\s*–)\s*(?:it['’]s|it is|it was|they['’]re|they are|they were|that['’]s|but)\b"])
reg(19, [r'\bin order to\b', r'\bdue to the fact that\b', r'\bat this point in time\b', r'\bin the event that\b', r'\bhas the ability to\b',
 r'\bit is important to note that\b', r'\bit should be mentioned that\b', r'\bneedless to say\b'])
reg(20, [r"\bit['’]s worth (?:noting|mentioning) that\b", r'\bit bears (?:noting|mentioning) that\b', r'\bone thing to (?:consider|keep in mind) is\b',
 r'\bit is interesting to note that\b', r'\ba key consideration is\b', r'\ba point to highlight is\b', r'\bit is worth (?:noting|mentioning) that\b'])
reg(21, [r',\s+(?:raising questions about|prompting reflection on|sparking debate about|with broader implications for|reshaping our understanding of|paving the way for|signaling a shift toward|signalling a shift toward)\b'])
reg(22, [r"\bhere['’]s the thing\b", r'\bmake no mistake\b', r'\bthe truth is\b', r"\blet['’]s be honest\b", r'\bthe simple fact is\b', r'\bat its core\b',
 r'\bwhat really matters\b', r'\bmore than anything\b', r'\bat the end of the day\b', r'\bthe bottom line is\b', r'\bin reality\b', r'\bfundamentally,',
 r'\bthe real question is\b', r'\bthe heart of the matter\b', r'\bthe deeper issue\b', r'\bwhen you get down to it\b', r'\bwhen all is said and done\b'])
reg(23, [r"\bit(?:['’]s| is) important to (?:remember|note|understand|recognize|recognise)\b", r'\bone must note that\b', r'\bit is worth pointing out\b',
 r'\bit cannot be overstated that\b', r'\bit must be emphasi[sz]ed that\b'])
reg(24, [r'\bthis comprehensive (?:guide|overview|analysis)\b', r'\bthis in-depth (?:analysis|look|examination)\b', r'\bthis complete (?:guide|overview)\b',
 r'\ba thorough examination of\b', r'\beverything you need to know about\b'])
reg(26, [r'\bwithout concrete evidence\b', r'\bdo you have concrete evidence\b', r'\bi (?:would )?need concrete (?:evidence|examples) to\b',
 r'\babsent concrete proof\b', r'\bprovide concrete evidence\b'])
reg(27, [r"\bin today['’]s (?:[\w-]+ ){0,2}(?:world|landscape|environment|market)\b", r'\bin a world where\b', r'\bin an era of\b', r'\bin recent years,',
 r'\bmore than ever before\b', r'\bwe live in a (?:time|world) when\b', r'\b(?:great|exciting|big) news\s*[!:]',
 r'\bever (?:wanted|wondered|dreamed|wished)\b[^.?!]*\?', r'\bin an increasingly (?:interconnected|digital|competitive|complex) world\b'])
reg(30, [r'\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b',
 r'\b(?:the|this) (?:(?:latest|new) )?(?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b',
 r'\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b', r'\bpreviously\b[^.!?]{0,80}\bnow\b',
 r"\b(?:wasn['’]t|weren['’]t) there before\b", r"\bwe(?:['’]ve| have) (?:now )?(?:added|removed|replaced|refactored|migrated)\b"])
reg(31, [r"\blet['’]s (?:dive|delve|explore)\b", r"\blet['’]s break (?:this|it) down\b", r"\bhere['’]s what you need to know\b", r'\bwithout further ado\b',
 r"\bnow let['’]s look at\b", r'\bbuckle up\b', r'\bstay with me\b', r'\b(?:are you )?ready to dive in\b'])
reg(32, [r'\b(?:used|uses|employs?|employed|relied on|utili[sz]es) (?:several|various|a number of|multiple|different|many|numerous) \w+',
 r'(?:^|(?<=[.!?]) )These (?:\w+ )?(?:provide|offer|give|reveal|show|allow|enable|help)s? (?:information|insight|understanding|details|data)\b',
 r'\b(?:is|are|was|were|remains|becomes) (?:the |a )?(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue) of\b'])
reg(36, [r'\bdespite (?:these|its|the) (?:challenges|obstacles)\b', r'\bchallenges and (?:(?:future) )?(?:prospects|outlook|legacy)\b', r'\bcontinues to thrive\b',
 r'\btypical of (?:emerging|urban|modern)\b', r'\bfaces (?:several|many|numerous) challenges\b'])
reg(38, [r'^[ \t>*#-]*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|ultimately)\b'], flags=re.I | re.M)
reg(39, [r'\bthe future looks bright\b', r'\bexciting times lie ahead\b', r'\bjourney toward excellence\b', r'\bstep in the right direction\b',
 r'\b(?:the )?(?:outlook|future)(?: for [^.!?,]{1,40})? (?:is|looks|remains) bright\b', r'\bwell[- ]positioned for (?:whatever comes next|the future|the road ahead)\b'])
reg(47, [r'\bi hope this helps\b', r'\b(?:certainly|of course)!', r'\blet me know if you\b', r'\bwould you like me to\b', r'\bfeel free to (?:ask|reach out)\b',
 r'\bhappy to help\s*[.!?]', r'\b(?:here|below) is (?:an?|the) (?:overview|summary|rundown|recap|brief)\b',
 r"\bhere (?:are|is)|here['’]s (?:a )?(?:few|some|two|three) (?:options|drafts|versions|variations)\b",
 r"\bhere (?:is|are)\b[^.!?\n]{0,10}\b(?:a draft)\b|\bhere['’]s a draft\b", r'\bdepending on the (?:vibe|tone|style)\b',
 r'\bi hope (?:this email )?finds you well\b', r'\bas an (?:AI|LLM)(?: assistant| language model)?\b', r'\bas a (?:large )?language model\b',
 r'\bas an? (?:AI|LLM|large language model|language model)\b',
 r'\bto (?:answer|address) your question\b', r'\bin (?:response|answer) to your question\b', r'\byour question (?:about|regarding|concerning)\b',
 r'\bas (?:you )?(?:requested|asked), here\b', r'\bhere is (?:the )?(?:draft|first pass|revised version of|for your)\b'])
reg(48, [r"\byou(?:['’]re| are) absolutely right\b", r'\b(?:great question|excellent point)\s*[!.,]',
 r"\bwhat an? (?:thoughtful|great|wonderful|fantastic) question\s*[!.,]",
 r"\bthat['’]s an? (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\s*[!.,]"])
reg(50, [r'\bas of my (?:last )?(?:training|knowledge)\b', r'\bup to my (?:last )?(?:training|knowledge)\b',
 r'\bwhile specific details are (?:limited|scarce|not (?:extensively|widely) documented)\b', r'\bbased on (?:the )?available information\b',
 r'\bas of my (?:knowledge )?cutoff\b', r'\bmaintains a low profile\b', r'\bkeeps (?:his|her|their) personal life private\b'])
reg(51, [r'\b(?:serves|stands|functions|acts) as\b', r'\brepresents (?:a|the)\b', r'\bmarks (?:a|the)\b', r'\bboasts\b',
 r'\bfeatures (?:an?|the|one|two|three|four|five|six|seven|eight|nine|ten|\d+|several|many|numerous|multiple|various|a number of)\b',
 r'\boffers an?\b', r'\brefers to\b'])
reg(56, [r'\*\*[^*\n]+\*\*'], flags=0)
reg(57, ['[\U0001F300-\U0001FAFF\U0001F000-\U0001F2FF☀-➿⭐⭕⌚⌛⏩-⏺]'], flags=0)
reg(58, [])  # handled specially
reg(60, ['[‘’“”]'], flags=0)
reg(61, [r'\b(?:19|20)\d\d-(?:19|20)\d\d\b'], flags=0)
reg(63, [r'\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])',
 r'\[[^\]\n]*\b(?:name|company|client|city|place|source|date|address|title)\b[^\]\n]*\](?![(\[])',
 r'\{\{[^}\n]+\}\}', r'\bx{3,}\b|(?<![A-Za-z])[xX]{3,}(?![A-Za-z])', r'\blorem ipsum\b'], flags=re.I)
reg(64, [r'\bcite(?:turn|start|nav)\w*', r'\boai_citation\w*', r'\bcontentReference\b', r'\bnavlist\b', '【\\d+[^】]*】'], flags=re.I)
reg(69, [r'\bunlocking (?:the )?(?:full )?potential\b', r'\bnavigating the complexities\b', r'\ba testament to the (?:power|importance)\b',
 r'\bstaying ahead of the curve\b', r'\bturning challenges into opportunities\b', r'\btaking (?:\w+ ){1,3}to the next level\b',
 r'\bharnessing the power of\b', r'\bpaving the way for\b', r'\bsaying goodbye to\b', r'\bimagining a world where\b',
 r'\bunlock(?:ing)? the (?:full )?potential\b', r'\bin the ever-evolving (?:world|landscape)\b'])

ALL_CAPS_SLOT = re.compile(r'\[([A-Z][A-Z0-9 _/-]{2,})\]')
SHORT_LABEL = re.compile(r'^[A-Z]{1,2}\d{0,3}$')
UTM_RE = re.compile(r'utm_source=([A-Za-z0-9.\-]*)', re.I)
UTM_HOSTS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai', 'gemini.google.com', 'copilot.microsoft.com', 'poe.com'}


def excerpt(text, s, e, ctx=30):
    a = max(0, s - ctx)
    b = min(len(text), e + ctx)
    seg = re.sub(r'\s+', ' ', text[a:b]).strip()
    return ('...' if a > 0 else '') + seg + ('...' if b < len(text) else '')

def short(s, n=80):
    s = re.sub(r'\s+', ' ', s).strip()
    return s if len(s) <= n else s[:n - 1] + '…'

def clean_slug_label(l):
    return l


class Hit:
    def __init__(self, key, label, count, samples):
        self.key, self.label, self.count, self.samples = key, label, count, samples


def run_regex_family(num, text, masked, flags_override=None):
    spans = []
    total = 0
    for rx, mh in REGEXES.get(num, []):
        for m in rx.finditer(masked):
            if m.end() == m.start():
                continue
            spans.append((m.start(), m.end()))
    return spans


def detect_all(text, masked, window_text_raw):
    """Return dict key -> (num, label, count, samples), plus word info."""
    findings = {}
    def add(num, label, spans, sample_mode=None, min_hits=1, texts=None, slug_override=None):
        if len(spans) < min_hits or not spans:
            return
        samples = []
        seen = set()
        for (s, e) in spans:
            smp = excerpt(text, s, e) if num == 1 else short(text[s:e])
            if smp and smp not in seen:
                seen.add(smp)
                samples.append(smp)
            if len(samples) >= 3:
                break
        key = '%d_%s' % (num, slug_override or slug(label))
        findings[key] = (num, label, len(spans), samples)

    for num in (1, 2, 3, 4, 5, 10, 11, 12, 13, 14, 15, 16, 18, 19, 20, 21, 22, 23, 24, 26, 27, 30, 31, 32, 36, 38, 39,
                47, 48, 50, 51, 56, 57, 60, 61, 63, 64, 69):
        spans = []
        mh = 1
        for rx, mh_ in REGEXES[num]:
            mh = mh_
            for m in rx.finditer(masked):
                if m.end() > m.start():
                    spans.append((m.start(), m.end()))
        if num == 18:
            spans = _dedupe_spans(spans)
        add(num, TITLES[num], spans, min_hits=mh)

    # 17
    spans = []
    for rx, _ in REGEXES[17]:
        spans.extend((m.start(), m.end()) for m in rx.finditer(masked))
    if spans:
        add(17, LABEL_17_PAR, _dedupe_spans(spans), slug_override='negative_parallelism')
    tail = [(m.start(), m.end()) for m in re.finditer(r',\s+no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b', masked, re.I)]
    if tail:
        add(17, LABEL_17_TAIL, tail, slug_override='tailing_negation')

    # 3 imperative sentences
    sents = get_sentences(masked)
    n_imp = sum(1 for s in sents if re.match(r'(?:%s)\b' % IMPERATIVES, s, re.I))
    if n_imp >= 3 and '3_%s' % slug(TITLES[3]) not in findings:
        findings['3_%s' % slug(TITLES[3])] = (3, TITLES[3], n_imp, [short(s) for s in sents if re.match(r'(?:%s)\b' % IMPERATIVES, s, re.I)][:3])
    elif n_imp >= 3:
        k = '3_%s' % slug(TITLES[3])
        o = findings[k]
        findings[k] = (3, o[1], o[2] + n_imp, o[3])

    # 6 stacked adjectives
    spans = []
    for m in re.finditer(r'(?:\b[A-Za-z][A-Za-z-]*,\s+){2,}(?:and\s+)?[A-Za-z][A-Za-z-]*\s+[A-Za-z][A-Za-z-]*\b', masked):
        words = re.findall(r'[A-Za-z][A-Za-z-]*', m.group(0))
        chain = [w for w in words[:-1] if w.lower() != 'and']
        if len(chain) >= 3 and any(ADJ_SUFFIX.search(w) or w.lower() in STOCK_ADJ for w in chain):
            spans.append((m.start(), m.end()))
    add(6, TITLES[6], spans)

    # 8 synonym cycling
    spans = []
    for cl in SYN_RES:
        found = []
        for w, rx in cl:
            m = rx.search(masked)
            if m:
                found.append((m.start(), m.end()))
        if len(found) >= 3:
            spans.append(found[0])
    add(8, TITLES[8], spans)

    # 25 question-answer
    spans = [(m.start(), m.end()) for m in re.finditer(
        r'(?:^|(?<=[.!?]\s)|(?<=\n))(?:Is|Are|Do|Does|Did|Can|Could|Will|Would|Should|Shall|Has|Have|Had|May|Might|Must|Was|Were)\b[^.?!\n]{0,100}\?\s+(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)\s*[.!]',
        masked, re.M)]
    add(25, TITLES[25], spans)

    lines = masked.split('\n')
    # 33 inline-header lists
    spans = []
    pos = 0
    for ln in lines:
        if re.match(r'^\s*(?:[-*+]\s+|\d+[.)]\s+)?\*\*[^*\n]+?(?::\*\*|\*\*:)', ln):
            spans.append((pos, pos + len(ln)))
        pos += len(ln) + 1
    add(33, TITLES[33], spans)

    # headings
    heads = [(i, HEAD_RE.match(ln)) for i, ln in enumerate(lines) if HEAD_RE.match(ln)]
    # 34 bullet injection
    if not heads:
        paras = []
        cur = []
        for ln in lines + ['']:
            if ln.strip() == '':
                if cur:
                    paras.append(cur)
                    cur = []
            else:
                cur.append(ln)
        list_paras = [p for p in paras if all(LIST_RE.match(l) for l in p)]
        prose_paras = [p for p in paras if not any(LIST_RE.match(l) for l in p) and count_words(' '.join(p)) >= 4]
        if list_paras and len(prose_paras) >= 2:
            add(34, TITLES[34], [(0, 1)] * len(list_paras))
            findings['34_%s' % slug(TITLES[34])][3][:] = [short(' '.join(list_paras[0]))]
    # 35 fragmented headers
    spans = []
    for i, m in heads:
        j = i + 1
        while j < len(lines) and lines[j].strip() == '':
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if HEAD_RE.match(nxt) or LIST_RE.match(nxt) or nxt.startswith('|'):
            continue
        nw = WORD_RE.findall(nxt)
        if 0 < len(nw) <= 4:
            hw = {w.lower() for w in WORD_RE.findall(m.group(1)) if len(w) > 2}
            if any(w.lower() in hw for w in nw):
                spans.append((0, 0))
                findings.setdefault('_35_sample', []).append(short(m.group(1) + ' / ' + nxt))
    if spans:
        smp = findings.pop('_35_sample', [])[:3]
        findings['35_%s' % slug(TITLES[35])] = (35, TITLES[35], len(spans), smp)
    findings.pop('_35_sample', None)

    # 37 transition clusters
    cnt = 0
    smp = []
    trx = re.compile(r'(?:^|(?<=[.!?])[ \t]+|(?<=[.!?])\n+)(?:%s)\b' % TRANS, re.M)
    for para in paragraphs_lines(masked):
        ms = list(re.finditer(r'(?:^|(?<=[.!?])\s+)(?:%s)\b' % TRANS, para))
        if len(ms) >= 2:
            cnt += len(ms)
            smp.append(short(ms[0].group(0)))
    if cnt:
        findings['37_%s' % slug(TITLES[37])] = (37, TITLES[37], cnt, smp[:3])

    # 42 opener repetition
    cnt = 0
    smp = []
    for b in prose_blocks(masked):
        ss = split_sentences(b)
        if len(ss) >= 3:
            c = {}
            for s in ss:
                w = [x.lower() for x in WORD_RE.findall(s)[:2]]
                if len(w) == 2:
                    c[' '.join(w)] = c.get(' '.join(w), 0) + 1
            for k, v in c.items():
                if v >= 3:
                    cnt += 1
                    smp.append(k)
    if cnt:
        findings['42_%s' % slug(TITLES[42])] = (42, TITLES[42], cnt, smp[:3])

    # 54 hedges
    cnt = 0
    smp = []
    hedge = re.compile(r'\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems? (?:to|like)|appears? to|somewhat|relatively|fairly|kind of|sort of)\b')
    for s in get_sentences(masked):
        if len(hedge.findall(s)) >= 2:
            cnt += 1
            smp.append(short(s))
    if cnt:
        findings['54_%s' % slug(TITLES[54])] = (54, TITLES[54], cnt, smp[:3])

    # 58 em dashes
    cnt = 0
    smp = []
    for para in paragraphs_lines(masked):
        k = para.count('—')
        if k >= 2:
            cnt += 1
            smp.append(short(para, 60))
    if cnt:
        findings['58_%s' % slug(TITLES[58])] = (58, TITLES[58], cnt, smp[:3])

    # 59 title case headings
    SMALL = set('a an the and but or nor for so yet at by in of on to up as via off out per with from into onto over is if'.split())
    spans = []
    smp = []
    for i, m in heads:
        h = m.group(1).strip()
        if not h or not h[0].isalpha():
            continue
        words = h.split()
        if len(words) < 3:
            continue
        alpha = [w for w in words if any(c.isalpha() for c in w)]
        if h.upper() == h:
            continue
        major = [w for w in words if w.lower().strip('.,:;!?') not in SMALL and any(c.isalpha() for c in w)]
        if len(major) >= 2 and all(w.lstrip('("\'[*_')[:1].isupper() for w in major):
            spans.append((0, 0))
            smp.append(short(h))
    if spans:
        findings['59_%s' % slug(TITLES[59])] = (59, TITLES[59], len(spans), smp[:3])

    # 70 horizontal rules
    nl = len(lines)
    rules = [ln for ln in lines if re.match(r'^\s*(?:-\s*){3,}$|^\s*(?:\*\s*){3,}$|^\s*(?:_\s*){3,}$', ln)]
    if len(rules) >= 3 and nl >= 24:
        findings['70_%s' % slug(TITLES[70])] = (70, TITLES[70], len(rules), [short(r) for r in rules[:3]])

    # 71 degenerate repetition
    ws = [w.lower() for w in WORD_RE.findall(masked)]
    if len(ws) >= 12:
        grams = {}
        for i in range(len(ws) - 5):
            g = tuple(ws[i:i + 6])
            grams[g] = grams.get(g, 0) + 1
        total = len(ws) - 5
        rep = sum(v for v in grams.values() if v > 1)
        if total > 0 and rep / total >= 0.2:
            top = sorted((g for g, v in grams.items() if v > 1), key=lambda g: -grams[g])[:3]
            findings['71_%s' % slug(TITLES[71])] = (71, TITLES[71], rep, [' '.join(g) for g in top])

    # 46 semicolon/parens
    nwords = count_words(masked)
    if nwords >= 300 and ';' not in masked and len(re.findall(r'\([^)\n]+\)', masked)) <= 1:
        findings['46_%s' % slug(TITLES[46])] = (46, TITLES[46], 1, ['no semicolons or parentheticals'])

    # 55 contractions
    wl = WORD_RE.findall(masked)
    fp = sum(1 for w in wl if w.lower() in ('i', 'me', 'my', 'mine', 'myself', 'we', 'our', 'ours', 'us'))
    if nwords >= 30 and fp / max(1, nwords) >= 0.03:
        contracted = len(re.findall(r"\b\w+['’](?:t|s|m|re|ve|ll|d)\b", masked, re.I)) - len(re.findall(r"\b(?:[a-z]+)['’]s\b(?!\s+(?:not|a|an|the))", masked)) // 2
        contracted = len(re.findall(r"\b(?:\w+n['’]t|i['’]m|\w+['’](?:re|ve|ll)|it['’]s|that['’]s|i['’]d)\b", masked, re.I))
        full = len(re.findall(r"\b(?:do not|does not|did not|is not|are not|was not|were not|cannot|can not|would not|could not|should not|will not|have not|has not|had not|i am|it is|that is|i have|i will|we are|we have|i would|you are|they are|there is)\b", masked, re.I))
        if full >= 3 and full > contracted:
            findings['55_%s' % slug(TITLES[55])] = (55, TITLES[55], full, ['%d uncontracted forms vs %d contracted' % (full, contracted)])

    # 40/41/44 rhythm
    ss = get_sentences(masked)
    lens = [count_words(s) for s in ss]
    if len(lens) >= 3 and cv(lens) < 0.35:
        findings['40_%s' % slug(TITLES[40])] = (40, TITLES[40], len(lens), ['%d sentences, similar lengths' % len(lens)])
    if len(lens) >= 6:
        best = 1
        run = 1
        prev = None
        for i in range(1, len(lens)):
            d = lens[i] - lens[i - 1]
            if abs(d) >= max(4, 0.4 * max(lens[i], lens[i - 1])) and (prev is None or (d > 0) != (prev > 0)):
                run = run + 1 if prev is not None else 2
                prev = d
            else:
                if abs(d) >= max(4, 0.4 * max(lens[i], lens[i - 1])):
                    run = 2
                    prev = d
                else:
                    run = 1
                    prev = None
            best = max(best, run)
        if best >= 6:
            findings['41_%s' % slug(TITLES[41])] = (41, TITLES[41], 1, ['%d sentences alternate long/short' % best])
    pl = [count_words(p) for p in paragraphs(masked) if not HEAD_RE.match(p) and count_words(p) > 0]
    if len(pl) >= 4 and cv(pl) < 0.4:
        findings['44_%s' % slug(TITLES[44])] = (44, TITLES[44], len(pl), ['%d paragraphs, similar lengths' % len(pl)])

    # 65 tracking
    spans = []
    for m in UTM_RE.finditer(masked):
        if m.group(1).rstrip('.').lower() in UTM_HOSTS:
            spans.append((m.start(), m.end()))
    add(65, TITLES[65], spans)
    # 63 all caps slots
    spans = []
    for m in ALL_CAPS_SLOT.finditer(masked):
        end = m.end()
        if end < len(masked) and masked[end] in '([':
            continue
        if SHORT_LABEL.match(m.group(1)):
            continue
        spans.append((m.start(), m.end()))
    if spans:
        k = '63_%s' % slug(TITLES[63])
        base = findings.get(k)
        if base:
            findings[k] = (63, TITLES[63], base[2] + len(spans), base[3] + [short(text[s:e]) for s, e in spans][:3 - len(base[3])])
        else:
            add(63, TITLES[63], spans)

    # character layer on the raw window
    raw = window_text_raw
    rem = analyze_chars(raw)
    n_inv = len(rem)
    if rem:
        sm = ['U+%04X' % ord(raw[i]) for i in sorted(rem)[:3]]
        findings['62_%s' % slug(TITLES[62])] = (62, TITLES[62], n_inv, sm)
    nss = nss_indexes(raw)
    if nss:
        findings['67_%s' % slug(TITLES[67])] = (67, TITLES[67], len(nss), ['U+%04X' % ord(raw[i]) for i in nss[:3]])
    hs = homoglyph_spans(raw)
    n_homo = sum(len(x[2]) for x in hs)
    if hs:
        findings['66_%s' % slug(TITLES[66])] = (66, TITLES[66], n_homo, [short(raw[s:e]) for s, e, _ in hs[:3]])
    # 68 trailing whitespace
    c68 = 0
    for ln in raw.split('\n'):
        l2 = ln.rstrip('\r')
        if l2 != l2.rstrip(' \t'):
            c68 += 1
    if raw and raw[-1] in ' \t':
        c68 += 0
    if re.search(r'\n\n+\Z', raw) or re.search(r'\r?\n(?:\r?\n)+\Z', raw):
        c68 += 1
    if raw and raw[0].isspace() and raw.strip() != '':
        c68 += 1
    if c68:
        findings['68_%s' % slug(TITLES[68])] = (68, TITLES[68], c68, ['trailing or stray whitespace'])
    return findings, (n_inv, len(nss), n_homo)


def paragraphs_lines(masked):
    res = []
    cur = []
    for ln in masked.split('\n'):
        if ln.strip() == '':
            if cur:
                res.append('\n'.join(cur))
                cur = []
        else:
            cur.append(ln.strip())
    if cur:
        res.append('\n'.join(cur))
    return res


def _dedupe_spans(spans):
    spans = sorted(spans)
    out = []
    for s, e in spans:
        if out and s < out[-1][1]:
            continue
        out.append((s, e))
    return out


def analyze(text, with_chars=True):
    raw_window = text[:WINDOW]
    masked = mask_text(raw_window)
    findings, (n_inv, n_nss, n_homo) = detect_all(raw_window, masked, raw_window)
    # 1 and 2 in the same family? kept separate
    # extra: vocabulary 17 handled; compute score
    # extra check: finding 1 must not duplicate on masked-only; ok
    words = count_words(masked)
    return findings, words, (n_inv, n_nss, n_homo)


def weight(num):
    if num in ADVICE or num == 17 and False:
        return 0
    if num in DECISIVE:
        return 24
    if num == 40:
        return 8
    if num == 44:
        return 6
    return 14


def compute_score(findings, words):
    moving = {}
    for key, (num, label, count, samples) in findings.items():
        if num in ADVICE:
            continue
        if num == 17 and label == LABEL_17_PAR:
            continue
        moving[num] = max(moving.get(num, 0), count) if num not in moving else moving[num] + count
    n = len(moving)
    pts = 0
    for num, h in moving.items():
        pts += weight(num) + min(h - 1, 5) * 3
    score = min(100, pts)
    if n == 0:
        conf = confidence(words, 0)
        return 0, conf, moving
    if n == 1:
        score = min(score, 40)
    if set(moving) <= {40, 44}:
        score = min(score, 40)
    if set(moving) == {40}:
        score = min(score, 20)
    conf = confidence(words, n)
    dec = [k for k in moving if k in DECISIVE]
    if len(dec) >= 2:
        score = max(score, 65)
    elif len(dec) == 1 and conf[0] not in ('none', 'low'):
        score = max(score, 45)
    if words < 120:
        k = len([x for x in moving if x in SHORT_SET])
        if k >= 3:
            score = max(score, 45)
        elif k >= 2:
            score = max(score, 25)
    elif words >= 400:
        if n >= 6:
            score = max(score, 45)
        elif n >= 5:
            score = max(score, 25)
    if set(moving) == {40}:
        score = min(score, 20)
    return max(0, min(100, int(round(score)))), conf, moving


def confidence(words, n):
    if words < 40:
        return 'none', 'fewer than 40 words, too little text to score reliably'
    if words < 120:
        return 'low', 'fewer than 120 words, short text'
    if words < 300 and n <= 1:
        return 'low', 'under 300 words with at most one score-moving pattern family'
    if words < 300:
        return 'moderate', 'under 300 words'
    return 'high', ''


def build_report(text, ci=False):
    truncated = len(text) > WINDOW
    findings, words, (n_inv, n_nss, n_homo) = analyze(text)
    score, (conf, reason), moving = compute_score(findings, words)
    report = {}
    for key, (num, label, count, samples) in findings.items():
        report[key] = {'label': label, 'count': count, 'samples': samples[:3]}
    m = {
        'scanned_chars': min(len(text), WINDOW),
        'truncated': truncated,
        'ai_tell_score': score,
        'ai_tell_band': band_of(score),
        'confidence': conf,
        'confidence_reason': reason,
        'patterns_flagged': len(report),
        'invisible_chars': n_inv,
        'nonstandard_spaces': n_nss,
        'homoglyphs': n_homo,
        'word_count': words,
        'score_moving_keys': sorted(k for k, v in findings.items() if v[0] in moving and not (v[0] in ADVICE) and not (v[0] == 17 and v[1] == LABEL_17_PAR)),
    }
    if ci:
        sents = get_sentences(mask_text(text[:WINDOW]))
        if len(sents) >= 4:
            lo, hi = bootstrap(sents, score)
            m['score_ci'] = [lo, hi]
            m['score_ci_note'] = 'bootstrap interval over sentences; the point score is unchanged'
        else:
            m['score_ci'] = None
            m['score_ci_note'] = 'too few sentences (need at least 4) for an interval'
    report['_metrics'] = m
    return report


def bootstrap(sents, point, n=30, seed=1234):
    rng = random.Random(seed)
    t0 = time.time()
    scores = [point]
    budget = 3.0
    for _ in range(n):
        if time.time() - t0 > budget:
            break
        sample = [rng.choice(sents) for _ in sents]
        txt = ' '.join(sample)
        f, w, _c = analyze(txt)
        s, _, _ = compute_score(f, w)
        scores.append(s)
    scores.sort()
    k = len(scores)
    lo = scores[int(0.05 * (k - 1))]
    hi = scores[int(math.ceil(0.95 * (k - 1)))]
    return min(lo, point), max(hi, point)


# ---------------------------------------------------------------- CLI
def err(msg, code):
    sys.stderr.write(json.dumps({'error': msg}) + '\n')
    sys.stderr.flush()
    return code

def main(argv):
    clean = False
    ci = False
    operands = []
    i = 0
    opts_done = False
    while i < len(argv):
        a = argv[i]
        i += 1
        if opts_done:
            operands.append(a)
            continue
        if a == '--':
            opts_done = True
        elif a in ('--help', '-h'):
            sys.stdout.write(USAGE + '\n\nScores prose for AI-writing patterns. Reads FILE or standard input.\n  --clean  print scrubbed text instead of the report\n  --ci     add a resampled interval to the score\n')
            return 0
        elif a == '--clean':
            clean = True
        elif a == '--ci':
            ci = True
        elif a.startswith('-') and a != '':
            return err('unknown option: %s (see --help)' % a, 2)
        else:
            operands.append(a)
    try:
        if operands:
            path = operands[0]
            if len(operands) > 1:
                sys.stderr.write('note: %d files given; only the first file was scanned: %s\n' % (len(operands), path))
            text = load_prose(path)
        else:
            data = sys.stdin.buffer.read()
            text = decode_bytes(data)
    except ReadError as e:
        return err('cannot read input: %s' % e, 1)
    if text.strip() == '':
        return err('empty input', 1)
    if clean:
        out = clean_text(text)
        sys.stdout.buffer.write(out.encode('utf-8', 'replace'))
        sys.stdout.buffer.flush()
        return 0
    rep = build_report(text, ci)
    sys.stdout.buffer.write((json.dumps(rep, ensure_ascii=False, indent=2) + '\n').encode('utf-8', 'replace'))
    sys.stdout.buffer.flush()
    return 0

if __name__ == '__main__':
    try:
        code = main(sys.argv[1:])
    except SystemExit:
        raise
    except BaseException as e:
        try:
            sys.stderr.write(json.dumps({'error': 'cannot read input: internal error: %s' % type(e).__name__}) + '\n')
        except Exception:
            pass
        code = 1
    sys.exit(code)
