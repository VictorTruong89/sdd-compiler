---
description: prosecheck - writing contract controls
argument-hint: [lite|full|strict|off|on|status|show|check|doctor|stats|init|help]
---
/prosecheck $ARGUMENTS
