#!/usr/bin/env node
'use strict';
// session-start hook: places the writing contract in the session.
try {
  const lib = require('./lib');
  lib.readStdinJson();
  lib.cleanOldLedgers();
  const fresh = (() => { try { return !require('fs').existsSync(lib.flagPath()); } catch (e) { return false; } })();
  const level = lib.getLevel();
  if (level !== 'off') {
    if (fresh) lib.writeStored(level);
    const body = lib.contractBody(level, {});
    process.stdout.write((fresh ? lib.WELCOME + '\n\n' : '') + body + '\n');
  }
} catch (e) { /* never fail the host */ }
process.exitCode = 0;
