#!/usr/bin/env node
'use strict';
// subagent-start hook: same contract inside the SubagentStart envelope.
try {
  const lib = require('./lib');
  lib.readStdinJson();
  const level = lib.getLevel();
  if (level !== 'off') {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext: lib.contractBody(level, {}) },
    }) + '\n');
  }
} catch (e) {}
process.exitCode = 0;
