#!/usr/bin/env node
'use strict';
// prompt-submit hook and /prosecheck command router.
const fs = require('fs');
const path = require('path');
const lib = require('./lib');
const { statsReply } = require('./prosecheck-stats');

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }) + '\n');
}

function helpReply(level) {
  return [
    'prosecheck level: ' + level,
    'Code, commits, config, and chat are never touched; only prose deliverables follow the contract.',
    '/prosecheck lite - turn on the writing contract without scoring saved files',
    '/prosecheck full (default) - contract plus the saved-file guard, flagging above a threshold of 40',
    '/prosecheck strict - guard with a stricter threshold of 20, and the --clean scrub finish',
    '/prosecheck off - disable the contract and the guard',
    '/prosecheck on - re-enable at the default level',
    '/prosecheck status - show the current level',
    '/prosecheck show - list the files scored in this session',
    '/prosecheck check <path> - score one file; report only, never a rewrite of the file',
    '/prosecheck doctor - health check of the install',
    '/prosecheck stats - token figures and the score of this session\'s own prose',
    '/prosecheck init - export the contract to ./AGENTS.md for agents other than Claude Code',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function parseCheckPath(arg) {
  let a = (arg || '').trim();
  if (a.startsWith('@')) a = a.slice(1).trim();
  const m = /^(["'])(.*)\1$/.exec(a);
  if (m) a = m[2];
  if (a.startsWith('@') && m) a = a.slice(1);
  return a;
}

function checkReply(arg, payload) {
  const p = parseCheckPath(arg);
  if (!p) return 'Usage: /prosecheck check <path> - give the path of a file to score.';
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const abs = path.isAbsolute(p) ? p : path.resolve(cwd, p);
  const base = path.basename(abs);
  let st;
  try { st = fs.statSync(abs); } catch (e) { return 'cannot read ' + p; }
  if (!st.isFile()) return 'not a file: ' + p;
  const ext = path.extname(abs).toLowerCase();
  if (ext === '.pdf' || ext === '.rtf') return base + ': no readable text (this format is not read).';
  const archive = lib.ZIP_EXT.includes(ext) || lib.NB_EXT.includes(ext);
  const cap = archive ? lib.ARCHIVE_CAP : lib.PLAIN_CAP;
  if (st.size > cap) return base + ' is over ' + lib.kbOf(cap) + ' KB, so it was not scored.';
  const r = lib.runDetector([abs], undefined, 20000);
  if (r.status === 'nopython' || r.status === 'nodetector') return 'detector unavailable: Python or the bundled script could not be started.';
  if (r.status === 'timeout') return base + ': the check failed because the detector took too long.';
  if (r.code !== 0) {
    const err = (r.stderr || '').trim();
    return base + ': the detector failed.' + (err ? ' ' + err : ' It printed no error text.');
  }
  if (!r.stdout || !r.stdout.trim()) return base + ': no report was produced by the detector.';
  const rep = lib.parseReport(r.stdout);
  if (rep.kind !== 'ok') return 'no report: the detector printed text that is not a report.';
  const m = rep.metrics;
  const phrase = lib.PHRASES[m.ai_tell_band] || 'reads with some AI tells';
  const out = [];
  out.push(base + ' - ' + phrase + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')');
  out.push('confidence: ' + m.confidence + (m.confidence !== 'high' && m.confidence_reason ? ' - ' + m.confidence_reason : ''));
  if (m.truncated) out.push('coverage: first ' + lib.WINDOW_STR + ' characters only');
  if (rep.findings.length) {
    out.push('tells: ' + rep.findings.slice(0, 8).map((f) => f.label + ' (x' + f.count + ')').join('; '));
  } else {
    out.push('tells: none');
  }
  out.push('This is a report only; the file was left as it was.');
  return out.join('\n');
}

function doctorReply(form) {
  const level = lib.getLevel();
  const lines = [];
  lines.push('prosecheck health check');
  const checks = [];
  const modeOk = level !== 'off';
  lines.push(modeOk ? '[OK] mode: ' + level : '[--] mode: off - turn it back on with /prosecheck on');
  const det = lib.detectorPath();
  lines.push(det ? '[OK] bundled detector found in the plugin tree' : '[!!] the bundled detector was not found in the plugin tree');
  let pyOk = false;
  if (!lib.pythonAvailable()) {
    lines.push('[!!] python not found - saved files will not be re-scored until Python is available; the writing contract still shapes new prose');
  } else if (!det) {
    lines.push('[!!] Python is present but could not run the bundled detector because it is missing');
  } else {
    const r = lib.runDetector([], 'The committee met on Tuesday and approved the budget after a short discussion. Nobody objected to the plan.\n', 15000);
    const rep = r.status === 'ok' && r.code === 0 ? lib.parseReport(r.stdout) : { kind: 'text' };
    if (rep.kind === 'ok') { pyOk = true; lines.push('[OK] Python ran the bundled detector and returned a numeric score'); }
    else lines.push('[!!] Python ran but the detector result was not a numeric score');
  }
  let setOk = false;
  try {
    const dir = lib.configDir();
    fs.mkdirSync(dir, { recursive: true });
    const probe = path.join(dir, '.prosecheck-probe-' + process.pid);
    fs.writeFileSync(probe, 'x');
    fs.unlinkSync(probe);
    setOk = true;
  } catch (e) {}
  lines.push(setOk ? '[OK] settings folder is writable' : '[!!] settings folder is not writable');
  const othersOk = !!det && pyOk && setOk;
  if (othersOk && modeOk) {
    lines.push('prosecheck is active. Plain text up to ' + lib.kbOf(lib.PLAIN_CAP) + ' KB and archives up to ' + (lib.ARCHIVE_CAP / 1048576) + ' MB are accepted, and the first ' + lib.WINDOW_STR + ' characters are read. Use ' + form + ' show to see files that were only partly read or skipped.');
  } else if (othersOk && !modeOk) {
    lines.push('The install is healthy, but the mode is off, so saving files triggers no scoring; nothing is scored until you run ' + form + ' on.');
  } else {
    lines.push('Please fix the faulty checks above, then run /prosecheck doctor again.');
  }
  return lines.join('\n');
}

function showReply(sessionId) {
  const rows = lib.readLedger(sessionId);
  if (!rows.length) return 'nothing scored yet - rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  const out = ['Files checked in this session, newest first:'];
  for (const r of rows.slice().reverse()) {
    let body;
    if (r.kind === 'scored') {
      const phrase = lib.PHRASES[r.band] || 'reads with some AI tells';
      body = phrase + ' (score ' + r.score + '/' + r.band + (r.truncated ? ', first ' + lib.WINDOW_STR + ' characters only' : '') + ')';
      if (Array.isArray(r.labels) && r.labels.length) {
        body += ' - ' + (r.flagged ? 'flagged' : 'under the threshold') + ': ' + r.labels.slice(0, 5).join('; ');
      }
    } else if (r.kind === 'size') {
      body = 'not scored: larger than the ' + r.capKb + ' KB limit';
    } else if (r.kind === 'binary') {
      body = 'binary file, not re-scored';
    } else {
      body = 'not scored: ' + (r.reason || 'the check failed');
    }
    out.push('  ' + r.base + ' - ' + body);
  }
  return out.join('\n');
}

const BEGIN = '<!-- prosecheck:begin -->';
const END = '<!-- prosecheck:end -->';
const HEADING = '## Prose writing contract (prosecheck)';

function initReply(form) {
  const level = lib.getLevel();
  if (level === 'off') return 'prosecheck is switched off, so nothing was written. Run ' + form + ' on to allow the export.';
  const cwd = process.cwd();
  const msgs = [];
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = null;
  let readFail = false;
  if (fs.existsSync(agents)) {
    try { existing = fs.readFileSync(agents, 'utf8'); } catch (e) { readFail = true; }
  }
  if (readFail) {
    msgs.push('cannot read AGENTS.md, so it was not given the contract (cannot write it either).');
  } else if (existing !== null && (existing.includes(BEGIN) || existing.includes(HEADING))) {
    msgs.push('AGENTS.md already has the prosecheck contract; it was left unchanged.');
  } else {
    const section = BEGIN + '\n' + HEADING + '\n\n' + lib.contractBody(level, { portable: true }) + '\n' + END + '\n';
    let content;
    if (existing === null || existing === '') content = section;
    else content = existing + (existing.endsWith('\n\n') ? '' : existing.endsWith('\n') ? '\n' : '\n\n') + section;
    try {
      fs.writeFileSync(agents, content);
      msgs.push('Wrote the writing contract (' + level + ') to AGENTS.md.');
    } catch (e) {
      msgs.push('cannot write AGENTS.md, so it was not given the contract.');
    }
  }
  const dest = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(dest)) {
    msgs.push('The Cursor rule prosecheck.mdc is already there; it was not overwritten.');
  } else {
    const src = path.join(lib.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
    try {
      const data = fs.readFileSync(src);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, data);
      msgs.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      msgs.push('cannot write .cursor/rules/prosecheck.mdc, so the Cursor rule was not created.');
    }
  }
  return msgs.join('\n');
}

function handleCommand(m, payload) {
  const form = m[1] ? '/prosecheck:prosecheck' : '/prosecheck';
  const rest = (m[2] || '').trim();
  const sp = rest.search(/\s/);
  const word = (sp < 0 ? rest : rest.slice(0, sp)).toLowerCase();
  const arg = sp < 0 ? '' : rest.slice(sp + 1).trim();
  if (word === '' || word === 'help') return helpReply(lib.getLevel());
  if (!lib.SUBCOMMANDS.includes(word)) {
    return 'unknown subcommand: ' + rest.split(/\s+/)[0] + '\nValid subcommands: ' + lib.SUBCOMMANDS.join(', ') + '.';
  }
  switch (word) {
    case 'lite': case 'full': case 'strict':
      lib.writeStored(word);
      return 'prosecheck level set to ' + word + '.';
    case 'off':
      lib.writeStored('off');
      return 'prosecheck is now off. Run /prosecheck on to turn it back on.';
    case 'on':
      lib.writeStored('full');
      return 'prosecheck is on (full).';
    case 'status':
      return 'prosecheck level: ' + lib.getLevel();
    case 'show':
      return showReply(typeof payload.session_id === 'string' ? payload.session_id : '');
    case 'check':
      return checkReply(arg, payload);
    case 'doctor':
      return doctorReply(form);
    case 'stats':
      return statsReply(payload);
    case 'init':
      return initReply(form);
  }
  return helpReply(lib.getLevel());
}

try {
  const payload = lib.readStdinJson();
  const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
  const trimmed = prompt.trim();
  const lower = trimmed.toLowerCase();
  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    lib.writeStored('off');
    block('prosecheck is now off. Run /prosecheck on to turn it back on.');
  } else {
    const m = /^\/prosecheck(:prosecheck)?(?:\s+([\s\S]*))?$/.exec(trimmed);
    if (m) {
      block(handleCommand(m, payload));
    } else {
      const level = lib.getLevel();
      if (level !== 'off') {
        process.stdout.write(JSON.stringify({
          hookSpecificOutput: {
            hookEventName: 'UserPromptSubmit',
            additionalContext: 'prosecheck is at level ' + level + ': prose deliverables follow the writing contract; code, config, and commits are untouched.',
          },
        }) + '\n');
      }
    }
  }
} catch (e) {}
process.exitCode = 0;
