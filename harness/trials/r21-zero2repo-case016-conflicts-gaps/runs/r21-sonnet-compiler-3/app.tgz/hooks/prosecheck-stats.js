#!/usr/bin/env node
'use strict';
// stats helper: token and own-prose figures from a session transcript.
const fs = require('fs');
const path = require('path');
const lib = require('./lib');

function newestTranscript(dir) {
  let best = null;
  const walk = (d, depth) => {
    let ents;
    try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    for (const e of ents) {
      const p = path.join(d, e.name);
      if (e.isDirectory() && depth < 4) walk(p, depth + 1);
      else if (e.isFile() && e.name.endsWith('.jsonl')) {
        try {
          const t = fs.statSync(p).mtimeMs;
          if (!best || t > best.t) best = { p, t };
        } catch (x) {}
      }
    }
  };
  walk(dir, 0);
  return best ? best.p : null;
}

function readTranscript(file) {
  let raw;
  try {
    if (!fs.statSync(file).isFile()) return null;
    raw = fs.readFileSync(file, 'utf8');
  } catch (e) { return null; }
  const byId = new Map();
  let anon = 0;
  let turns = 0;
  const texts = [];
  for (const line of raw.split(/\r?\n/)) {
    if (!line.trim()) continue;
    let o;
    try { o = JSON.parse(line); } catch (e) { continue; }
    if (!o || o.type !== 'assistant' || !o.message || typeof o.message !== 'object') continue;
    const msg = o.message;
    const usage = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    const num = (v) => (typeof v === 'number' && isFinite(v) ? v : 0);
    const u = { out: num(usage.output_tokens), cache: num(usage.cache_read_input_tokens) };
    if (typeof msg.id === 'string' && msg.id) {
      if (!byId.has(msg.id)) turns++;
      byId.set(msg.id, u);
    } else {
      turns++;
      byId.set('\0anon' + (anon++), u);
    }
    if (Array.isArray(msg.content)) {
      for (const c of msg.content) if (c && c.type === 'text' && typeof c.text === 'string') texts.push(c.text);
    } else if (typeof msg.content === 'string') texts.push(msg.content);
  }
  let out = 0, cache = 0;
  for (const u of byId.values()) { out += u.out; cache += u.cache; }
  return { turns, out, cache, texts };
}

function statsReply(payload) {
  const level = lib.getLevel();
  let file = typeof payload.transcript_path === 'string' && payload.transcript_path ? payload.transcript_path : null;
  const named = !!file;
  if (!file) file = newestTranscript(path.join(lib.configDir(), 'projects'));
  const lines = ['level: ' + level];
  if (!file) {
    lines.push('No session transcript was found, so there are no token figures to show.');
    return lines.join('\n');
  }
  const tr = readTranscript(file);
  if (!tr) {
    lines.push('The transcript could not be read, so there are no token figures to show.');
    return lines.join('\n');
  }
  lines.push('assistant turns: ' + tr.turns);
  lines.push('output tokens: ' + tr.out);
  lines.push('cache-read input tokens: ' + tr.cache);
  let prose = tr.texts.join('\n\n').replace(/```[\s\S]*?(?:```|$)/g, '');
  prose = prose.slice(-40000).trim();
  if (prose.length > 500) {
    const r = lib.runDetector([], prose, 15000);
    if (r.status === 'ok' && r.code === 0) {
      const rep = lib.parseReport(r.stdout);
      if (rep.kind === 'ok') lines.push('session prose ai_tell_score: ' + rep.metrics.ai_tell_score);
    }
  }
  return lines.join('\n');
}

module.exports = { statsReply };

if (require.main === module) {
  try {
    const payload = lib.readStdinJson();
    process.stdout.write(JSON.stringify({ decision: 'block', reason: statsReply(payload) }) + '\n');
  } catch (e) {}
  process.exitCode = 0;
}
