#!/usr/bin/env node
'use strict';
// post-tool-use hook: scores a just-saved prose file and nudges when flagged.
const fs = require('fs');
const path = require('path');
const lib = require('./lib');

const TOOLS = ['Write', 'Edit', 'MultiEdit', 'NotebookEdit', 'apply_patch'];
const INSTR = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
const INSTR_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];
const MAX_PATHS = 10;

function collectPaths(payload) {
  const ti = payload.tool_input && typeof payload.tool_input === 'object' ? payload.tool_input : {};
  const out = [];
  const add = (p) => { if (typeof p === 'string' && p.trim()) out.push(p.trim()); };
  add(ti.file_path);
  add(ti.notebook_path);
  const patch = typeof ti.command === 'string' ? ti.command : (typeof ti.input === 'string' ? ti.input : (typeof ti.patch === 'string' ? ti.patch : ''));
  if (patch) {
    for (const line of patch.split(/\r?\n/)) {
      const m = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/.exec(line);
      if (m) add(m[1]);
    }
  }
  return Array.from(new Set(out));
}

function isInside(child, parent) {
  const rel = path.relative(path.resolve(parent), path.resolve(child));
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function skipPath(abs) {
  const parts = abs.split(/[\\/]/);
  if (parts.includes('node_modules') || parts.includes('.git')) return true;
  let root;
  try { root = lib.pluginRoot(); } catch (e) { root = null; }
  if (root && isInside(abs, root)) return true;
  const base = path.basename(abs).toLowerCase();
  if (INSTR.includes(base)) return true;
  const ext = path.extname(base);
  const stem = ext ? base.slice(0, -ext.length) : base;
  if (INSTR_STEMS.includes(stem) && !lib.PROSE_EXT.includes(ext)) return true;
  if (INSTR_STEMS.includes(base)) return true;
  return false;
}

function failedReason(r) {
  if (r.status === 'nopython' || r.status === 'nodetector') return 'python not found, so the detector could not run';
  if (r.status === 'timeout') return 'the detector timed out';
  if (r.code !== 0 || !r.stdout || !r.stdout.trim()) return 'the detector produced no output or exited without a usable result';
  return null;
}

function scoreOne(abs, level, sessionId) {
  const base = path.basename(abs);
  const ext = path.extname(abs).toLowerCase();
  let st;
  try { st = fs.statSync(abs); } catch (e) { st = null; }
  if (st && !st.isFile()) return null;
  if (ext === '.pdf' || ext === '.rtf') {
    lib.appendLedger(sessionId, { kind: 'binary', base, t: Date.now() });
    return null;
  }
  if (!lib.PROSE_EXT.includes(ext)) return null;
  if (!st) {
    lib.appendLedger(sessionId, { kind: 'failed', base, reason: 'the file could not be read', t: Date.now() });
    return null;
  }
  const archive = !lib.PLAIN_EXT.includes(ext);
  const cap = archive ? lib.ARCHIVE_CAP : lib.PLAIN_CAP;
  if (st.size > cap) {
    lib.appendLedger(sessionId, { kind: 'size', base, capKb: lib.kbOf(cap), t: Date.now() });
    return null;
  }
  const r = lib.runDetector([abs], undefined, archive ? 15000 : 8000);
  let reason = failedReason(r);
  let rep = null;
  if (!reason) {
    rep = lib.parseReport(r.stdout);
    if (rep.kind === 'text') reason = 'the detector printed text that is not a structured report';
    else if (rep.kind === 'noscore') reason = 'the report has no numeric score';
  }
  if (reason) {
    lib.appendLedger(sessionId, { kind: 'failed', base, reason, t: Date.now() });
    return null;
  }
  const m = rep.metrics;
  const threshold = level === 'strict' ? 20 : 40;
  const flagged = m.ai_tell_score > threshold;
  const labels = rep.findings.map((f) => f.label).slice(0, 5);
  lib.appendLedger(sessionId, {
    kind: 'scored', base, score: m.ai_tell_score, band: m.ai_tell_band, labels, flagged, truncated: !!m.truncated, t: Date.now(),
  });
  if (!flagged) return null;
  const phrase = lib.PHRASES[m.ai_tell_band] || 'reads with some AI tells';
  const cov = m.truncated ? ', first ' + lib.WINDOW_STR + ' characters only' : '';
  const lab = labels.map((l) => l.replace(/[.\s]+$/, '')).join('; ');
  return 'prosecheck: ' + base + ' ' + phrase + ' (score ' + m.ai_tell_score + ', band ' + m.ai_tell_band + cov + '). Flagged: ' + lab + '. Please fix the flagged spans, keeping sentence rhythm varied.';
}

try {
  const payload = lib.readStdinJson();
  const level = lib.getLevel();
  const tool = payload.tool_name;
  if ((level === 'full' || level === 'strict') && (tool === undefined || TOOLS.includes(tool))) {
    const sessionId = typeof payload.session_id === 'string' ? payload.session_id : '';
    const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
    const lines = [];
    const paths = collectPaths(payload).slice(0, MAX_PATHS);
    for (const p of paths) {
      try {
        const abs = path.isAbsolute(p) ? path.normalize(p) : path.resolve(cwd, p);
        if (skipPath(abs)) continue;
        const line = scoreOne(abs, level, sessionId);
        if (line) lines.push(line);
      } catch (e) {}
    }
    if (lines.length) {
      process.stdout.write(JSON.stringify({
        hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
      }) + '\n');
    }
  }
} catch (e) {}
process.exitCode = 0;
