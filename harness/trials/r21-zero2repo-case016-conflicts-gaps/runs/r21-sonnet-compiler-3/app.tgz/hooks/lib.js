'use strict';
// Shared helpers for the prosecheck hooks. Node standard library only.
const fs = require('fs');
const path = require('path');
const os = require('os');
const cp = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const SUBCOMMANDS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];
const WINDOW = 262144;
const WINDOW_STR = '262,144';
const PLAIN_CAP = 512 * 1024;
const ARCHIVE_CAP = 4 * 1024 * 1024;
const PLAIN_EXT = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ZIP_EXT = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'];
const NB_EXT = ['.ipynb'];
const PROSE_EXT = PLAIN_EXT.concat(ZIP_EXT, NB_EXT);
const LEDGER_MAX = 50;
const LEDGER_AGE_MS = 7 * 24 * 3600 * 1000;
const PHRASES = {
  'clean': 'reads clean',
  'light tells': 'reads mostly clean',
  'mixed': 'reads with some AI tells',
  'heavy tells': 'reads with heavy AI tells',
  'pervasive tells': 'reads with pervasive AI tells',
};

function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}
function pluginRoot() {
  return process.env.CLAUDE_PLUGIN_ROOT || path.resolve(__dirname, '..');
}
function detectorPath() {
  const root = pluginRoot();
  const a = path.join(root, 'scripts', 'detect.py');
  const b = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  try { if (fs.statSync(a).isFile()) return a; } catch (e) {}
  try { if (fs.statSync(b).isFile()) return b; } catch (e) {}
  return null;
}
function flagPath() { return path.join(configDir(), '.prosecheck-active'); }
function readStored() {
  try {
    const v = fs.readFileSync(flagPath(), 'utf8').trim();
    return LEVELS.includes(v) ? v : null;
  } catch (e) { return null; }
}
function writeStored(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), level);
    return true;
  } catch (e) { return false; }
}
function envDefault() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  return LEVELS.includes(v) ? v : null;
}
function getLevel() {
  return envDefault() || readStored() || 'full';
}

function readStdinJson() {
  let raw = '';
  try { raw = fs.readFileSync(0, 'utf8'); } catch (e) { raw = ''; }
  try {
    const v = JSON.parse(raw);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : {};
  } catch (e) { return {}; }
}

// ---------------------------------------------------------------- ledger
function ledgerPath(sessionId) {
  const dir = configDir();
  if (typeof sessionId === 'string' && sessionId) {
    return path.join(dir, '.prosecheck-ledger-' + sessionId.replace(/[^A-Za-z0-9_.-]/g, '_'));
  }
  return path.join(dir, '.prosecheck-ledger');
}
function readLedger(sessionId) {
  const p = ledgerPath(sessionId);
  try {
    const st = fs.statSync(p);
    if (Date.now() - st.mtimeMs > LEDGER_AGE_MS) {
      try { fs.unlinkSync(p); } catch (e) {}
      return [];
    }
    const v = JSON.parse(fs.readFileSync(p, 'utf8'));
    return Array.isArray(v) ? v : [];
  } catch (e) { return []; }
}
function appendLedger(sessionId, rec) {
  try {
    const rows = readLedger(sessionId);
    rows.push(rec);
    const keep = rows.slice(-LEDGER_MAX);
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(ledgerPath(sessionId), JSON.stringify(keep));
  } catch (e) {}
}
function cleanOldLedgers() {
  try {
    const dir = configDir();
    for (const n of fs.readdirSync(dir)) {
      if (n === '.prosecheck-ledger' || n.startsWith('.prosecheck-ledger-')) {
        const p = path.join(dir, n);
        try {
          if (Date.now() - fs.statSync(p).mtimeMs > LEDGER_AGE_MS) fs.unlinkSync(p);
        } catch (e) {}
      }
    }
  } catch (e) {}
}

// ---------------------------------------------------------------- detector
function runDetector(args, input, timeoutMs) {
  // returns {status:'nopython'|'timeout'|'ok', code, stdout, stderr}
  const det = detectorPath();
  if (!det) return { status: 'nodetector' };
  const names = ['python3', 'python', 'py'];
  for (const n of names) {
    const r = cp.spawnSync(n, [det].concat(args), {
      input: input === undefined ? undefined : input,
      encoding: 'utf8',
      timeout: timeoutMs,
      maxBuffer: 64 * 1024 * 1024,
      env: process.env,
    });
    if (r.error && r.error.code === 'ENOENT') continue;
    if (r.error && (r.error.code === 'ETIMEDOUT' || r.signal === 'SIGTERM')) return { status: 'timeout' };
    if (r.error) return { status: 'ok', code: null, stdout: '', stderr: String(r.error.message || '') };
    return { status: 'ok', code: r.status, stdout: r.stdout || '', stderr: r.stderr || '' };
  }
  return { status: 'nopython' };
}
function pythonAvailable() {
  for (const n of ['python3', 'python', 'py']) {
    const r = cp.spawnSync(n, ['--version'], { encoding: 'utf8', timeout: 10000, env: process.env });
    if (!(r.error && r.error.code === 'ENOENT')) return true;
  }
  return false;
}
function parseReport(stdout) {
  let v;
  try { v = JSON.parse(stdout); } catch (e) { return { kind: 'text' }; }
  if (!v || typeof v !== 'object' || Array.isArray(v) || !v._metrics || typeof v._metrics !== 'object') return { kind: 'text' };
  const m = v._metrics;
  if (typeof m.ai_tell_score !== 'number' || !isFinite(m.ai_tell_score)) return { kind: 'noscore' };
  const findings = [];
  const moving = new Set(Array.isArray(m.score_moving_keys) ? m.score_moving_keys : []);
  for (const k of Object.keys(v)) {
    if (k === '_metrics') continue;
    const f = v[k];
    if (f && typeof f.label === 'string') findings.push({ key: k, label: f.label, count: f.count, moving: moving.has(k) });
  }
  findings.sort((a, b) => (b.moving ? 1 : 0) - (a.moving ? 1 : 0));
  return { kind: 'ok', metrics: m, findings };
}

// ---------------------------------------------------------------- contract text
const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster', 'underscore', 'showcase',
  'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament', 'vibrant', 'comprehensive', 'plethora', 'myriad',
  'boast', 'elevate', 'empower', 'unlock', 'game-changer', 'supercharge', 'genuinely', 'fascinating', 'nuanced'];

function contractBody(level, opts) {
  opts = opts || {};
  const L = [];
  L.push('Prose writing contract (level: ' + level + ')');
  L.push('Scope: prose deliverables only (documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, drafted text the user will publish or send). This contract never applies to source code. It never touches code comments, commit messages, JSON/YAML/config, CLI output, logs, error messages, or the conversational register of chat. It composes with other modes: a chat-compression mode owns chat, a code-simplicity mode owns code, and this contract owns deliverable prose.');
  L.push('- Vary sentence length irregularly: no metronome, no mechanical short-long alternation.');
  L.push('- Banned vocabulary: ' + BANNED.join(', ') + '.');
  L.push('- Banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting ("let\'s dive in"), empty pivots ("it\'s worth noting"), "In conclusion" or "Overall" closers, outcome-speculation tails, self-thoroughness, generic upbeat endings, and chatbot phrases ("I hope this helps").');
  L.push('- Use an em-dash at most once per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.');
  L.push('- Factual or encyclopedic content stays neutral third person; first-person or opinion content may use contractions.');
  L.push('- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.');
  L.push('- End sections on a fact or observation.');
  L.push('- Stay silent about this contract: never announce it, never name prosecheck, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.');
  if (level === 'full' || level === 'strict') {
    const target = level === 'strict'
      ? 'the target is the clean band (score at most 20)'
      : 'the target is the clean or light tells band (score at most 40)';
    let how;
    if (opts.portable) {
      how = 'Run the bundled detector on that file (see the resolution note below).';
    } else {
      const det = detectorPath();
      how = det ? ('Run the detector on that file: python3 ' + det + ' <file>') : 'Run the bundled detector on that file.';
    }
    L.push('- After writing a prose file, ' + how.charAt(0).toLowerCase() + how.slice(1).replace(/\.?$/, '.') + ' When the band is worse than the target, fix the flagged spans (at most two fix passes, keeping rhythm variation); ' + target + '.');
    if (level === 'strict') {
      L.push('- Finish a strict-level deliverable by running the detector with --clean and keeping its scrubbed text.');
    }
    if (opts.portable) {
      L.push('- Resolving the detector: use scripts/detect.py under CLAUDE_PLUGIN_ROOT when that variable is set; otherwise locate the prosecheck detector among installed skills and plugins.');
    }
  }
  return L.join('\n');
}

const WELCOME = [
  'Welcome: prosecheck is installed and on. It is shown once.',
  'Saved prose is scored against 71 documented patterns. Plain text is accepted up to 512 KB and archives up to 4 MB; the detector scores the first 262,144 characters.',
  'There is no website and no upload; everything stays on this machine.',
  'Try /prosecheck doctor, /prosecheck check <file>, /prosecheck off, or /prosecheck help.',
].join('\n');

// ---------------------------------------------------------------- misc
function kbOf(cap) { return Math.round(cap / 1024); }
function capFor(ext) { return PLAIN_EXT.includes(ext) || !(ZIP_EXT.includes(ext) || NB_EXT.includes(ext)) ? PLAIN_CAP : ARCHIVE_CAP; }
function baseName(p) { return path.basename(p); }

module.exports = {
  LEVELS, SUBCOMMANDS, WINDOW, WINDOW_STR, PLAIN_CAP, ARCHIVE_CAP, PLAIN_EXT, ZIP_EXT, NB_EXT, PROSE_EXT, PHRASES,
  LEDGER_MAX, configDir, pluginRoot, detectorPath, readStored, writeStored, getLevel, envDefault, flagPath,
  readStdinJson, readLedger, appendLedger, cleanOldLedgers, ledgerPath, runDetector, pythonAvailable, parseReport,
  BANNED, contractBody, WELCOME, kbOf, capFor, baseName,
};
