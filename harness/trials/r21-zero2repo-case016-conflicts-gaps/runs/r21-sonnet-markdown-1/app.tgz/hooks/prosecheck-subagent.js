#!/usr/bin/env node
'use strict';
const L = require('./prosecheck-lib');
function main() {
  L.readInput();
  const level = L.getLevel();
  if (level === 'off') return;
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext: L.liveContract(level) }
  }));
}
try { main(); } catch (e) { /* never fail the host */ }
process.exit(0);
