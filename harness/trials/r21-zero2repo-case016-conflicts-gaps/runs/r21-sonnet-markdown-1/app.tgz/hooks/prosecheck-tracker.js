#!/usr/bin/env node
'use strict';
const L = require('./prosecheck-lib');
const fs = L.fs;
const path = L.path;

const SUBS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];
const KB_PLAIN = L.PLAIN_CAP / 1024;
const KB_ARCH = L.ARCHIVE_CAP / 1024;

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }));
}

function helpReply() {
  const level = L.getLevel();
  return [
    'prosecheck level: ' + level,
    '',
    'prosecheck never touches code, commits, config, or chat; it only shapes prose deliverables.',
    '',
    '/prosecheck lite - writing contract only, no scoring of saved files',
    '/prosecheck full - contract plus saved-file guard, threshold 40 (default)',
    '/prosecheck strict - stricter guard, threshold 20, adds a scrub of invisible characters',
    '/prosecheck off | on - disable / re-enable prosecheck',
    '/prosecheck status - show the current level',
    '/prosecheck show - list the files scored in this session',
    '/prosecheck check <file> - score one file (report only, no rewrite)',
    '/prosecheck doctor - health check of the install',
    '/prosecheck stats - token figures and the score of this session\'s own prose',
    '/prosecheck init - export the contract to ./AGENTS.md for other agents',
    '',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".'
  ].join('\n');
}

function bandPhrase(b) { return L.phraseForBand(b); }

function parsePathArg(arg) {
  let s = (arg || '').trim();
  for (let i = 0; i < 3; i++) {
    if (s.length >= 2 && (s[0] === '"' || s[0] === "'") && s[s.length - 1] === s[0]) s = s.slice(1, -1).trim();
    else if (s[0] === '@') s = s.slice(1).trim();
    else break;
  }
  return s;
}

function extOf(p) { return path.extname(p).toLowerCase(); }
function capFor(ext) { return (L.ZIP_EXTS.indexOf(ext) >= 0 || L.NB_EXTS.indexOf(ext) >= 0) ? L.ARCHIVE_CAP : L.PLAIN_CAP; }

function checkReply(arg) {
  const typed = parsePathArg(arg);
  if (!typed) return 'check needs a file path. Usage: /prosecheck check <path to a prose file>';
  const abs = path.resolve(process.cwd(), typed);
  const base = path.basename(abs);
  const ext = extOf(abs);
  let st = null;
  try { st = fs.statSync(abs); } catch (e) { st = null; }
  if (st && st.isDirectory()) return typed + ': not a file (a directory).';
  if (ext === '.pdf' || ext === '.rtf') return base + ': no readable text (' + ext + ' files are not scanned).';
  if (!st) return typed + ': cannot read this path (not found).';
  if (!st.isFile()) return typed + ': not a file.';
  try { fs.accessSync(abs, fs.constants.R_OK); } catch (e) { return typed + ': cannot read this file (permission denied).'; }
  const cap = capFor(ext);
  if (st.size > cap) return base + ': not scored, the file is over ' + (cap / 1024) + ' KB.';
  const timeout = cap === L.ARCHIVE_CAP ? 15000 : 8000;
  const r = L.runDetector(['--', abs], null, timeout);
  if (r.status === 'nopython' || r.status === 'nodetector') return 'detector unavailable: Python or the bundled detector could not be run, so nothing was scored.';
  if (r.status === 'timeout') return base + ': check failed, the detector timed out.';
  if (r.code !== 0) {
    const err = (r.stderr || '').trim();
    return base + ': check failed' + (err ? ': ' + err : ' (the detector reported a failure).');
  }
  if (!(r.stdout || '').trim()) return base + ': the detector produced no report (no report).';
  const pr = L.parseReport(r.stdout);
  if (pr.kind !== 'ok') return 'The detector printed no report it could read (no report).';
  const rep = pr.report;
  const m = rep._metrics;
  const lines = [];
  lines.push(base + ' - ' + bandPhrase(m.ai_tell_band) + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')');
  let c = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && m.confidence_reason) c += ' - ' + m.confidence_reason;
  lines.push(c);
  if (m.truncated) lines.push('coverage: first ' + L.WINDOW_TXT + ' characters only (the rest was not scanned)');
  const fs_ = L.findings(rep).slice(0, 8);
  if (fs_.length) lines.push('tells: ' + fs_.map(f => f.label + ' (x' + f.count + ')').join('; '));
  else lines.push('tells: none');
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

function doctorReply(typedForm) {
  const level = L.getLevel();
  const lines = ['prosecheck doctor'];
  const modeOk = level !== 'off';
  lines.push(modeOk ? '[OK] mode: ' + level
    : '[--] mode: off - prosecheck is switched off; turn it back on with /prosecheck on');
  const det = L.detectorPath();
  lines.push(det ? '[OK] detector: bundled detector found (scripts/detect.py)'
    : '[!!] detector: bundled detector not found in the plugin tree');
  let pyOk = false;
  let pyLine;
  const r = L.runDetector([], 'The doctor sample text has a few plain words in it to see whether a run produces a score.\n', 8000);
  if (r.status === 'nopython') {
    pyLine = '[!!] python not found: saved files are not re-scored until Python is available; the writing contract still shapes new prose.';
  } else if (r.status === 'nodetector') {
    pyLine = '[!!] python: cannot run the bundled detector because it is missing.';
  } else if (r.status === 'timeout') {
    pyLine = '[!!] python: the detector run timed out.';
  } else {
    const pr = L.parseReport(r.stdout || '');
    if (pr.kind === 'ok') { pyOk = true; pyLine = '[OK] python: ran the bundled detector and got a numeric score'; }
    else pyLine = '[!!] python: ran but the result was not a numeric score.';
  }
  lines.push(pyLine);
  let setOk = false;
  try {
    fs.mkdirSync(L.configDir(), { recursive: true });
    const probe = path.join(L.configDir(), '.prosecheck-probe-' + process.pid);
    fs.writeFileSync(probe, 'x');
    fs.unlinkSync(probe);
    setOk = true;
  } catch (e) { setOk = false; }
  lines.push(setOk ? '[OK] settings: config folder is writable' : '[!!] settings: config folder is not writable');
  const others = !!det && pyOk && setOk;
  let closer;
  if (!others) {
    closer = 'Please fix the faulty checks above, then run /prosecheck doctor again.';
  } else if (!modeOk) {
    closer = 'The install is healthy, but prosecheck is off, so no saved file is scored in this mode. Turn it on with ' + typedForm + ' on.';
  } else {
    closer = 'prosecheck is active. Plain text is accepted up to ' + KB_PLAIN + ' KB and archives up to 4 MB; the first ' + L.WINDOW_TXT +
      ' characters are scanned. Run ' + typedForm + ' show to see files that were only partly scanned or skipped.';
  }
  lines.push(closer);
  return lines.join('\n');
}

function showReply(sid) {
  const arr = L.readLedger(sid);
  if (!arr.length) {
    return 'prosecheck: nothing scored yet in this session. Rows appear here after prose files (.md, .txt, .docx, and also .pdf deliverables) are saved.';
  }
  const out = ['Files checked in this session (newest first):'];
  for (const r of arr.slice().reverse()) {
    const b = r.base;
    if (r.kind === 'scored') {
      let s = b + ' - ' + bandPhrase(r.band) + ' (score ' + r.score + '/' + r.band;
      if (r.truncated) s += ', first ' + L.WINDOW_TXT + ' characters only';
      s += ')';
      if (r.labels && r.labels.length) {
        s += ' - ' + (r.flagged ? 'flagged' : 'under threshold') + ': ' + r.labels.slice(0, 5).join('; ');
      }
      out.push(s);
    } else if (r.kind === 'size') {
      out.push(b + ' - not scored: larger than the ' + r.capKb + ' KB limit');
    } else if (r.kind === 'binary') {
      out.push(b + ' - binary file, not re-scored');
    } else {
      out.push(b + ' - not scored: ' + (r.reason || 'the check failed'));
    }
  }
  return out.join('\n');
}

// ---- init ----
function initReply(typedForm) {
  const level = L.getLevel();
  if (level === 'off') {
    return 'prosecheck is switched off, so nothing was exported. Turn it on with ' + typedForm + ' on, then run init again.';
  }
  const cwd = process.cwd();
  const msgs = [];
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = null;
  let readFail = false;
  try {
    if (fs.existsSync(agents)) existing = fs.readFileSync(agents, 'utf8');
  } catch (e) { readFail = true; }
  const section = L.MARK_BEGIN + '\n' + L.exportedContract(level) + '\n' + L.MARK_END + '\n';
  if (readFail) {
    msgs.push('cannot read AGENTS.md, so the contract was not written.');
  } else if (existing !== null && (existing.indexOf(L.MARK_BEGIN) >= 0 || existing.indexOf('## Prose contract (prosecheck') >= 0)) {
    msgs.push('AGENTS.md already contains the prosecheck contract; left unchanged.');
  } else {
    try {
      let add = section;
      if (existing !== null && existing.length > 0) {
        add = (existing.endsWith('\n') ? '\n' : '\n\n') + section;
      }
      fs.appendFileSync(agents, add);
      msgs.push('Wrote the writing contract (' + level + ') to AGENTS.md.');
    } catch (e) {
      msgs.push('cannot write AGENTS.md, so the contract was not exported.');
    }
  }
  const rule = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(rule)) {
    msgs.push('The Cursor rule prosecheck.mdc is already there; left unchanged.');
  } else {
    try {
      const src = path.join(L.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
      let body;
      try { body = fs.readFileSync(src); } catch (e) { body = Buffer.from(require('./prosecheck-rule').RULE); }
      fs.mkdirSync(path.dirname(rule), { recursive: true });
      fs.writeFileSync(rule, body);
      msgs.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      msgs.push('cannot write the Cursor rule .cursor/rules/prosecheck.mdc.');
    }
  }
  return msgs.join('\n');
}

// ---- stats ----
function findNewestTranscript() {
  const root = path.join(L.configDir(), 'projects');
  let best = null;
  function walk(d, depth) {
    let ents;
    try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    for (const e of ents) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { if (depth < 6) walk(p, depth + 1); }
      else if (e.isFile() && e.name.endsWith('.jsonl')) {
        try {
          const m = fs.statSync(p).mtimeMs;
          if (!best || m > best.m) best = { p, m };
        } catch (x) { /* ignore */ }
      }
    }
  }
  walk(root, 0);
  return best ? best.p : null;
}

function statsReply(input) {
  const level = L.getLevel();
  let tp = (typeof input.transcript_path === 'string' && input.transcript_path) ? input.transcript_path : null;
  if (!tp) tp = findNewestTranscript();
  if (!tp) return 'level: ' + level + '\nNo session transcript was found, so there are no token figures to show.';
  let raw;
  try { raw = fs.readFileSync(tp, 'utf8'); } catch (e) {
    return 'level: ' + level + '\nThe transcript could not be read, so there are no token figures to show.';
  }
  const byId = new Map();
  let anon = 0;
  const texts = [];
  for (const ln of raw.split('\n')) {
    if (!ln.trim()) continue;
    let o;
    try { o = JSON.parse(ln); } catch (e) { continue; }
    if (!o || o.type !== 'assistant' || !o.message || typeof o.message !== 'object') continue;
    const msg = o.message;
    const u = msg.usage || {};
    const rec = {
      out: Number(u.output_tokens) || 0,
      cache: Number(u.cache_read_input_tokens) || 0,
      text: ''
    };
    if (typeof msg.content === 'string') rec.text = msg.content;
    else if (Array.isArray(msg.content)) {
      rec.text = msg.content.filter(c => c && c.type === 'text' && typeof c.text === 'string').map(c => c.text).join('\n');
    }
    const id = (typeof msg.id === 'string' && msg.id) ? msg.id : ('anon' + (anon++));
    if (byId.has(id)) {
      const prev = byId.get(id);
      prev.out = Math.max(prev.out, rec.out);
      prev.cache = Math.max(prev.cache, rec.cache);
      if (rec.text && prev.text.indexOf(rec.text) < 0) prev.text += (prev.text ? '\n' : '') + rec.text;
    } else byId.set(id, rec);
  }
  let turns = 0, out = 0, cache = 0;
  for (const r of byId.values()) { turns++; out += r.out; cache += r.cache; texts.push(r.text); }
  const lines = ['level: ' + level, 'assistant turns: ' + turns, 'output tokens: ' + out, 'cache-read input tokens: ' + cache];
  let prose = texts.filter(Boolean).join('\n\n').replace(/```[\s\S]*?(?:```|$)/g, '');
  if (prose.length > 40000) prose = prose.slice(prose.length - 40000);
  const trimmed = prose.trim();
  if (trimmed.length > 500) {
    const r = L.runDetector([], trimmed, 15000);
    if (r.status === 'ok') {
      const pr = L.parseReport(r.stdout || '');
      if (pr.kind === 'ok') lines.push('session prose ai_tell_score: ' + pr.report._metrics.ai_tell_score);
    }
  }
  return lines.join('\n');
}

function main() {
  const input = L.readInput();
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const sid = typeof input.session_id === 'string' ? input.session_id : '';
  const trimmed = prompt.trim();
  const low = trimmed.toLowerCase();
  if (low === 'stop prosecheck' || low === 'prosecheck off') {
    L.setLevel('off');
    return block('prosecheck is now off.');
  }
  const m = /^\/prosecheck(:prosecheck)?(?:\s+([\s\S]*))?$/i.exec(trimmed);
  if (m) {
    const form = m[1] ? '/prosecheck:prosecheck' : '/prosecheck';
    const rest = (m[2] || '').trim();
    const sp = /^(\S+)(?:\s+([\s\S]*))?$/.exec(rest);
    const word = sp ? sp[1].toLowerCase() : 'help';
    const arg = sp && sp[2] ? sp[2] : '';
    switch (word) {
      case 'lite': case 'full': case 'strict':
        L.setLevel(word);
        return block('prosecheck level set to ' + word + '.');
      case 'off':
        L.setLevel('off');
        return block('prosecheck is now off.');
      case 'on':
        L.setLevel('full');
        return block('prosecheck is now on (level: full).');
      case 'status': return block('prosecheck level: ' + L.getLevel());
      case 'help': return block(helpReply());
      case 'show': return block(showReply(sid));
      case 'check': return block(checkReply(arg));
      case 'doctor': return block(doctorReply(form));
      case 'stats': return block(statsReply(input));
      case 'init': return block(initReply(form));
      default:
        return block('Unknown subcommand "' + (sp ? sp[1] : '') + '". Valid subcommands: ' + SUBS.join(', ') + '.');
    }
  }
  const level = L.getLevel();
  if (level === 'off') return;
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: 'prosecheck is active at level ' + level + ': prose deliverables follow the writing contract; code, config, and commits are untouched.'
    }
  }));
}
try { main(); } catch (e) { /* never fail the host */ }
process.exit(0);
