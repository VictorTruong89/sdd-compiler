#!/usr/bin/env node
'use strict';
// Stats entry: reuses the prompt router with the stats subcommand.
const L = require('./prosecheck-lib');
const cp = L.cp;
const path = L.path;
const input = L.readInput();
input.prompt = '/prosecheck stats';
const r = cp.spawnSync(process.execPath, [path.join(__dirname, 'prosecheck-tracker.js')], {
  input: JSON.stringify(input), encoding: 'utf8', env: process.env
});
if (r.stdout) process.stdout.write(r.stdout);
process.exit(0);
