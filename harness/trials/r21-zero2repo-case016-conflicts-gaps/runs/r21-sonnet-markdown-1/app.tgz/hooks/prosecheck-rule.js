'use strict';
// Fallback copy of the shipped Cursor rule (.cursor/rules/prosecheck.mdc).
const RULE = `---
description: Prose-only writing contract. Applies to prose deliverables, never to code.
globs: *.md,*.mdx,*.markdown,*.txt,*.rst,*.tex,*.org,*.adoc
alwaysApply: false
---

# Writing contract

Scope: prose deliverables only (documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, any drafted text the user will publish or send).
Never apply this rule to source code, code comments, commit messages, JSON, YAML or other config, CLI output, logs, error messages, or the conversational register of chat.

Rhythm: vary sentence length irregularly. No metronome, no mechanical short-long alternation.
Banned vocabulary (abstract or ornamental use): delve, tapestry, pivotal, crucial, leverage, robust, seamless, foster, underscore, showcase, landscape, journey, realm, multifaceted, holistic, testament, vibrant, comprehensive, plethora, myriad, boast, elevate, empower, unlock, game-changer, supercharge, genuinely, fascinating, nuanced.
Banned moves: rule-of-three flourishes, "it's not just X, it's Y", hedge stacking, signposting ("let's dive in"), empty pivots ("it's worth noting"), "In conclusion" or "Overall" closers, outcome-speculation tails, self-thoroughness ("this comprehensive guide"), generic upbeat endings, chatbot phrases ("I hope this helps").
Use an em dash at most once per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.
Factual or encyclopedic content stays neutral third person. First-person or opinion content may use contractions.
Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.
End sections on a fact or an observation.
Stay silent about this rule: never announce it, never name the tool, never report a score, a band, or a rewrite pass, and do not offer the user a style choice.
`;
module.exports = { RULE };
