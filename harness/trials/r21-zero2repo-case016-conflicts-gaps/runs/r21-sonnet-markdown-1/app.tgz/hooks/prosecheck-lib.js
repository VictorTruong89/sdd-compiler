'use strict';
// Shared helpers for the prosecheck hooks. Node standard library only.
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const WINDOW = 262144;
const WINDOW_TXT = '262,144';
const PLAIN_CAP = 512 * 1024;
const ARCHIVE_CAP = 4 * 1024 * 1024;
const PLAIN_EXTS = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ZIP_EXTS = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'];
const NB_EXTS = ['.ipynb'];
const PROSE_EXTS = PLAIN_EXTS.concat(ZIP_EXTS, NB_EXTS);
const LEDGER_MAX = 20;
const LEDGER_MAX_AGE_MS = 7 * 24 * 3600 * 1000;
const ADVICE = new Set([4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68]);

function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}
function pluginRoot() {
  if (process.env.CLAUDE_PLUGIN_ROOT) return process.env.CLAUDE_PLUGIN_ROOT;
  return path.resolve(__dirname, '..');
}
function flagPath() { return path.join(configDir(), '.prosecheck-active'); }

function readStdin() {
  try { return fs.readFileSync(0, 'utf8'); } catch (e) { return ''; }
}
function readInput() {
  const raw = readStdin();
  try {
    const v = JSON.parse(raw.replace(/^﻿/, ''));
    if (v && typeof v === 'object' && !Array.isArray(v)) return v;
  } catch (e) { /* fall through */ }
  return {};
}

function envDefault() {
  const e = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  return LEVELS.indexOf(e) >= 0 ? e : null;
}
// Returns { level, hasFlag, valid }
function readFlag() {
  let raw = null;
  let exists = false;
  try {
    exists = fs.existsSync(flagPath());
    if (exists) raw = fs.readFileSync(flagPath(), 'utf8');
  } catch (e) { raw = null; }
  const v = raw == null ? '' : raw.trim().toLowerCase();
  const valid = LEVELS.indexOf(v) >= 0;
  return { exists, valid, level: valid ? v : (envDefault() || 'full') };
}
function getLevel() { return readFlag().level; }
function setLevel(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), level);
    return true;
  } catch (e) { return false; }
}

// ---------- detector ----------
function detectorPath() {
  const root = pluginRoot();
  const a = path.join(root, 'scripts', 'detect.py');
  const b = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  if (fs.existsSync(a)) return a;
  if (fs.existsSync(b)) return b;
  return null;
}
const PY_NAMES = ['python3', 'python', 'py'];

// Returns {status:'nopython'|'nodetector'|'timeout'|'ok', stdout, stderr, code}
function runDetector(args, input, timeoutMs) {
  const det = detectorPath();
  if (!det) return { status: 'nodetector' };
  let launched = false;
  for (const name of PY_NAMES) {
    const opts = { encoding: 'utf8', timeout: timeoutMs, maxBuffer: 64 * 1024 * 1024, env: process.env };
    if (input != null) opts.input = input;
    const r = cp.spawnSync(name, [det].concat(args), opts);
    if (r.error) {
      if (r.error.code === 'ENOENT' || r.error.code === 'EACCES') continue;
      if (r.error.code === 'ETIMEDOUT' || r.signal === 'SIGTERM') return { status: 'timeout' };
      launched = true;
      return { status: 'ok', stdout: r.stdout || '', stderr: String(r.error.message || ''), code: r.status == null ? 1 : r.status };
    }
    if (r.signal === 'SIGTERM' || r.signal === 'SIGKILL') return { status: 'timeout' };
    launched = true;
    return { status: 'ok', stdout: r.stdout || '', stderr: r.stderr || '', code: r.status };
  }
  return launched ? { status: 'ok', stdout: '', stderr: '', code: 1 } : { status: 'nopython' };
}

function phraseForBand(band) {
  switch (band) {
    case 'clean': return 'reads clean';
    case 'light tells': return 'reads mostly clean';
    case 'mixed': return 'reads with some AI tells';
    case 'heavy tells': return 'reads with heavy AI tells';
    default: return 'reads with pervasive AI tells';
  }
}
function parseReport(stdout) {
  // returns {kind:'ok', report} | {kind:'notjson'} | {kind:'noscore'}
  let rep;
  try { rep = JSON.parse(stdout); } catch (e) { return { kind: 'notjson' }; }
  if (!rep || typeof rep !== 'object' || Array.isArray(rep)) return { kind: 'notjson' };
  const m = rep._metrics;
  if (!m || typeof m !== 'object' || typeof m.ai_tell_score !== 'number' || !isFinite(m.ai_tell_score)) {
    return { kind: 'noscore' };
  }
  return { kind: 'ok', report: rep };
}
function findings(rep) {
  const out = [];
  for (const k of Object.keys(rep)) {
    if (k === '_metrics') continue;
    const m = /^(\d+)_(.*)$/.exec(k);
    const num = m ? parseInt(m[1], 10) : 0;
    const v = rep[k] || {};
    const advice = ADVICE.has(num) || k === '17_negative_parallelism';
    out.push({ key: k, num, label: String(v.label || k), count: v.count | 0, advice });
  }
  out.sort((a, b) => (a.advice - b.advice) || (b.count - a.count) || (a.num - b.num));
  return out;
}

// ---------- ledger ----------
function ledgerPath(sid) {
  const s = (typeof sid === 'string' && sid) ? sid.replace(/[^A-Za-z0-9_.-]/g, '_').slice(0, 120) : '';
  return path.join(configDir(), s ? '.prosecheck-ledger-' + s : '.prosecheck-ledger');
}
function readLedger(sid) {
  const p = ledgerPath(sid);
  try {
    const st = fs.statSync(p);
    if (Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) {
      try { fs.unlinkSync(p); } catch (e) { /* ignore */ }
      return [];
    }
    const arr = JSON.parse(fs.readFileSync(p, 'utf8'));
    return Array.isArray(arr) ? arr : [];
  } catch (e) { return []; }
}
function appendLedger(sid, rec) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    let arr = readLedger(sid);
    rec.t = Date.now();
    arr.push(rec);
    if (arr.length > LEDGER_MAX) arr = arr.slice(arr.length - LEDGER_MAX);
    fs.writeFileSync(ledgerPath(sid), JSON.stringify(arr));
  } catch (e) { /* ignore */ }
}
function purgeOldLedgers() {
  try {
    for (const f of fs.readdirSync(configDir())) {
      if (f === '.prosecheck-ledger' || f.indexOf('.prosecheck-ledger-') === 0) {
        const p = path.join(configDir(), f);
        try {
          if (Date.now() - fs.statSync(p).mtimeMs > LEDGER_MAX_AGE_MS) fs.unlinkSync(p);
        } catch (e) { /* ignore */ }
      }
    }
  } catch (e) { /* ignore */ }
}

// ---------- contract ----------
const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster', 'underscore',
  'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament', 'vibrant', 'comprehensive',
  'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock', 'game-changer', 'supercharge', 'genuinely',
  'fascinating', 'nuanced'];

function rulesBlock() {
  return [
    'Scope: prose deliverables only (documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, any drafted text the user will publish or send).',
    'Never apply this contract to source code, code comments, commit messages, JSON, YAML or other config, CLI output, logs, error messages, or the conversational register of chat. A chat-compression mode owns chat; a code-simplicity mode owns code; this contract owns deliverable prose.',
    'Rhythm: vary sentence length irregularly. No metronome, no mechanical short-long alternation.',
    'Banned vocabulary (abstract or ornamental use): ' + BANNED.join(', ') + '.',
    'Banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting ("let\'s dive in"), empty pivots ("it\'s worth noting"), "In conclusion" or "Overall" closers, outcome-speculation tails, self-thoroughness ("this comprehensive guide"), generic upbeat endings, chatbot phrases ("I hope this helps").',
    'Use an em dash at most once per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.',
    'Factual or encyclopedic content stays neutral third person. First-person or opinion content may use contractions.',
    'Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.',
    'End sections on a fact or an observation.',
    'Stay silent about this contract: never announce it, never name the tool, never report a score, a band, a pattern list, or a rewrite pass, and do not offer the user a style choice.'
  ];
}

function liveContract(level) {
  const lines = ['# Writing contract (level: ' + level + ')', ''].concat(rulesBlock());
  if (level === 'full' || level === 'strict') {
    const det = detectorPath() || 'scripts/detect.py';
    lines.push('');
    if (level === 'full') {
      lines.push('After you write a prose file, run `python3 "' + det + '" <file>` and read the report. If the band is worse than light tells (score above 40), fix the flagged spans and run it again: at most two fix passes, keeping the rhythm varied. Target: the clean or light tells band (score at most 40).');
    } else {
      lines.push('After you write a prose file, run `python3 "' + det + '" <file>` and read the report. If the band is worse than clean (score above 20), fix the flagged spans and run it again: at most two fix passes, keeping the rhythm varied. Target: the clean band (score at most 20).');
      lines.push('Finish by passing the final file through `python3 "' + det + '" --clean <file>` and saving the scrubbed text.');
    }
  }
  return lines.join('\n');
}

function exportedContract(level) {
  const lines = ['## Prose contract (prosecheck, level: ' + level + ')', ''].concat(rulesBlock());
  if (level === 'full' || level === 'strict') {
    lines.push('');
    lines.push('Detector lookup: use CLAUDE_PLUGIN_ROOT when that variable is set, otherwise locate the prosecheck detector (scripts/detect.py) among the installed skills and plugins.');
    if (level === 'full') {
      lines.push('After you write a prose file, run the detector on it. If the score is above 40, fix the flagged spans and run it again: at most two fix passes, keeping the rhythm varied. Target: the clean or light tells band (score at most 40).');
    } else {
      lines.push('After you write a prose file, run the detector on it. If the score is above 20, fix the flagged spans and run it again: at most two fix passes, keeping the rhythm varied. Target: the clean band (score at most 20).');
      lines.push('Finish by running the detector with --clean on the final file and saving the scrubbed text.');
    }
  }
  return lines.join('\n');
}

const MARK_BEGIN = '<!-- prosecheck:begin -->';
const MARK_END = '<!-- prosecheck:end -->';

function isOk(v) { return v !== undefined && v !== null; }

module.exports = {
  fs, path, cp, LEVELS, WINDOW, WINDOW_TXT, PLAIN_CAP, ARCHIVE_CAP, PLAIN_EXTS, ZIP_EXTS, NB_EXTS, PROSE_EXTS,
  configDir, pluginRoot, flagPath, readInput, readFlag, getLevel, setLevel, envDefault,
  detectorPath, runDetector, phraseForBand, parseReport, findings,
  ledgerPath, readLedger, appendLedger, purgeOldLedgers,
  liveContract, exportedContract, BANNED, MARK_BEGIN, MARK_END, isOk
};
