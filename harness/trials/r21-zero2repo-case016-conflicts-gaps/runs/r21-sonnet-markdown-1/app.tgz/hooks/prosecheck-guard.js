#!/usr/bin/env node
'use strict';
const L = require('./prosecheck-lib');
const fs = L.fs;
const path = L.path;

const MAX_PATHS = 10;
const INSTR = new Set(['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md']);
const INSTR_STEMS = new Set(['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory']);

function isInstructionFile(p) {
  const base = path.basename(p).toLowerCase();
  if (INSTR.has(base)) return true;
  const ext = path.extname(base);
  const stem = ext ? base.slice(0, -ext.length) : base;
  if (INSTR_STEMS.has(stem) && L.PROSE_EXTS.indexOf(ext) < 0) return true;
  return false;
}

function collectPaths(input) {
  const ti = (input.tool_input && typeof input.tool_input === 'object') ? input.tool_input : {};
  const out = [];
  const push = p => {
    if (typeof p !== 'string') return;
    const t = p.trim();
    if (t && out.indexOf(t) < 0) out.push(t);
  };
  push(ti.file_path);
  push(ti.notebook_path);
  for (const key of ['command', 'patch', 'input']) {
    if (typeof ti[key] === 'string') {
      for (const ln of ti[key].split(/\r?\n/)) {
        const m = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/.exec(ln);
        if (m) push(m[1]);
      }
    }
  }
  return out;
}

function reasonFor(kind) {
  switch (kind) {
    case 'nopython': return 'python not found';
    case 'notjson': return 'detector output was not a structured report';
    case 'noscore': return 'report had no numeric score';
    case 'timeout': return 'detector timed out';
    case 'unreadable': return 'file could not be read';
    default: return 'detector gave no usable result';
  }
}

function handle(p, input, level, lines) {
  const sid = typeof input.session_id === 'string' ? input.session_id : '';
  const cwd = (typeof input.cwd === 'string' && input.cwd) ? input.cwd : process.cwd();
  const abs = path.resolve(cwd, p);
  const parts = abs.split(path.sep);
  if (parts.indexOf('node_modules') >= 0 || parts.indexOf('.git') >= 0) return;
  const root = path.resolve(L.pluginRoot());
  if (abs === root || abs.startsWith(root + path.sep)) return;
  if (isInstructionFile(abs)) return;
  const base = path.basename(abs);
  const ext = path.extname(abs).toLowerCase();
  if (ext === '.pdf' || ext === '.rtf') { L.appendLedger(sid, { kind: 'binary', base }); return; }
  if (L.PROSE_EXTS.indexOf(ext) < 0) return;
  let st;
  try { st = fs.statSync(abs); } catch (e) {
    L.appendLedger(sid, { kind: 'failed', base, reason: reasonFor('unreadable') });
    return;
  }
  if (!st.isFile()) return;
  const archive = L.ZIP_EXTS.indexOf(ext) >= 0 || L.NB_EXTS.indexOf(ext) >= 0;
  const cap = archive ? L.ARCHIVE_CAP : L.PLAIN_CAP;
  if (st.size > cap) { L.appendLedger(sid, { kind: 'size', base, capKb: cap / 1024 }); return; }
  const r = L.runDetector(['--', abs], null, archive ? 15000 : 8000);
  if (r.status === 'nopython' || r.status === 'nodetector') { L.appendLedger(sid, { kind: 'failed', base, reason: reasonFor('nopython') }); return; }
  if (r.status === 'timeout') { L.appendLedger(sid, { kind: 'failed', base, reason: reasonFor('timeout') }); return; }
  if (!(r.stdout || '').trim()) { L.appendLedger(sid, { kind: 'failed', base, reason: reasonFor('empty') }); return; }
  const pr = L.parseReport(r.stdout);
  if (pr.kind !== 'ok') { L.appendLedger(sid, { kind: 'failed', base, reason: reasonFor(pr.kind) }); return; }
  const rep = pr.report;
  const m = rep._metrics;
  const threshold = level === 'strict' ? 20 : 40;
  const flagged = m.ai_tell_score > threshold;
  const labels = L.findings(rep).map(f => f.label).slice(0, 5);
  L.appendLedger(sid, {
    kind: 'scored', base, score: m.ai_tell_score, band: m.ai_tell_band, labels, flagged, truncated: !!m.truncated
  });
  if (flagged) {
    const cov = m.truncated ? ', first ' + L.WINDOW_TXT + ' characters only' : '';
    let line = 'prosecheck: ' + base + ' ' + L.phraseForBand(m.ai_tell_band) + ' (score ' + m.ai_tell_score +
      ', band ' + m.ai_tell_band + cov + '). Flagged: ' + (labels.length ? labels.join('; ') : 'see report') +
      '. Please fix the flagged spans, keeping sentence lengths varied and the facts unchanged.';
    if (m.truncated) line += ' Only the first ' + L.WINDOW_TXT + ' characters were included in the scan.';
    lines.push(line);
  }
}

function main() {
  const input = L.readInput();
  const level = L.getLevel();
  if (level !== 'full' && level !== 'strict') return;
  const paths = collectPaths(input).slice(0, MAX_PATHS);
  if (!paths.length) return;
  const lines = [];
  for (const p of paths) {
    try { handle(p, input, level, lines); } catch (e) { /* ignore one file */ }
  }
  if (lines.length) {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') }
    }));
  }
}
try { main(); } catch (e) { /* never fail the host */ }
process.exit(0);
