#!/usr/bin/env node
'use strict';
const L = require('./prosecheck-lib');

function welcome() {
  return [
    'prosecheck is installed and on. Saved prose is scored against 71 documented AI-writing patterns, locally: there is no website, no account, and nothing is uploaded.',
    'Plain text is accepted up to 512 KB and archives and notebooks up to 4 MB. The detector scores the first 262,144 characters of extracted prose.',
    'Commands: /prosecheck doctor (check the install), /prosecheck check (score one file), /prosecheck off (switch it off), /prosecheck help (list everything).',
    'This welcome is shown once.',
    ''
  ].join('\n');
}

function main() {
  L.readInput();
  L.purgeOldLedgers();
  const f = L.readFlag();
  if (!f.valid) L.setLevel(f.level);
  if (f.level === 'off') return;
  let out = '';
  if (!f.exists) out += welcome() + '\n';
  out += L.liveContract(f.level) + '\n';
  process.stdout.write(out);
}
try { main(); } catch (e) { /* never fail the host */ }
process.exit(0);
