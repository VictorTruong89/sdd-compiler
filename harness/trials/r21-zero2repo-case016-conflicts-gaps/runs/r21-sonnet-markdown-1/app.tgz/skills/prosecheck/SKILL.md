---
name: prosecheck
description: Rewrite flagged prose so it reads less like AI output. Use when the user says "prosecheck this" or "humanize this".
---

Run the bundled detector (`scripts/detect.py <file>`) to find flagged spans, then rewrite only those spans.
Preserve numbers, units, dates, proper nouns, citations, quotes and technical terms. Never invent facts.
Vary sentence length; do not narrate the rewrite. Prose only: never touch code, commits or config.
