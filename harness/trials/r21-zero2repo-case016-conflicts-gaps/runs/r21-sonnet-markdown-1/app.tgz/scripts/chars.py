"""Character layer for prosecheck: invisible characters, odd spaces, homoglyphs, cleanup."""
import re
import unicodedata

INV_RE = re.compile(
    '[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f\u00ad\u034f\u061c\u115f\u1160\u17b4\u17b5'
    '\u180b-\u180f\u200b-\u200f\u202a-\u202e\u2060-\u206f\u3164\ufe00-\ufe0f\ufeff\uffa0'
    '\ufff9-\ufffb\U0001bca0-\U0001bca3\U0001d173-\U0001d17a\U000e0000-\U000e0fff]')
SP_RE = re.compile('[\u00a0\u1680\u2000-\u200a\u2028\u2029\u202f\u205f\u3000]')
TAGSEQ_RE = re.compile('\U0001F3F4[\U000E0020-\U000E007E]+\U000E007F')
RTL_RE = re.compile('[\u0590-\u08ff\ufb1d-\ufdff\ufe70-\ufeff]')

BIDI = set('\u200e\u200f\u061c\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069')


def _in(o, ranges):
    for a, b in ranges:
        if a <= o <= b:
            return True
    return False


CJK = [(0x4e00, 0x9fff), (0x3400, 0x4dbf), (0xf900, 0xfaff), (0x20000, 0x3134f), (0x2e80, 0x2fdf)]
NOSPACE = CJK + [(0x0e00, 0x0eff), (0x1780, 0x17ff), (0x19e0, 0x19ff), (0x1000, 0x109f),
                 (0x3040, 0x30ff), (0x31f0, 0x31ff)]
JOINING = [(0x0590, 0x05ff), (0x0600, 0x06ff), (0x0700, 0x074f), (0x0750, 0x077f), (0x08a0, 0x08ff),
           (0xfb1d, 0xfdff), (0xfe70, 0xfeff), (0x0900, 0x0dff), (0x1000, 0x109f), (0x1780, 0x17ff)]
KHMER = [(0x1780, 0x17ff), (0x19e0, 0x19ff)]
MONGOLIAN = [(0x1800, 0x18af)]


def is_cjk(c):
    return _in(ord(c), CJK)


def is_symbol(c):
    o = ord(c)
    if unicodedata.category(c)[0] == 'S':
        return True
    return 0x1f000 <= o <= 0x1faff or 0x2600 <= o <= 0x27bf or o in (0x20e3, 0xfe0f, 0x200d)


def _vs(c):
    o = ord(c)
    return 0xfe00 <= o <= 0xfe0f or 0xe0100 <= o <= 0xe01ef


def invisible_indices(text):
    """Return sorted list of indices of invisible characters that do no job."""
    out = []
    n = len(text)
    seq_keep = None
    rtl = None
    for m in INV_RE.finditer(text):
        i = m.start()
        c = text[i]
        o = ord(c)
        prev = text[i - 1] if i > 0 else ''
        nxt = text[i + 1] if i + 1 < n else ''
        keep = False
        if 0xe0000 <= o <= 0xe0fff and not (0xe0100 <= o <= 0xe01ef):
            if seq_keep is None:
                seq_keep = set()
                for sm in TAGSEQ_RE.finditer(text):
                    seq_keep.update(range(sm.start() + 1, sm.end()))
            keep = i in seq_keep
        elif _vs(c) or 0x180b <= o <= 0x180f:
            if 0x180b <= o <= 0x180f:
                keep = bool(prev) and _in(ord(prev), MONGOLIAN)
            else:
                keep = bool(prev) and (is_cjk(prev) or is_symbol(prev)) or nxt == '\u20e3'
        elif o == 0x200b:
            keep = (bool(prev) and _in(ord(prev), NOSPACE)) or (bool(nxt) and _in(ord(nxt), NOSPACE))
        elif o == 0x00ad:
            keep = bool(prev) and bool(nxt) and prev.isalpha() and nxt.isalpha()
        elif c in BIDI:
            if rtl is None:
                rtl = RTL_RE.search(text) is not None
            keep = rtl
        elif o in (0x17b4, 0x17b5):
            keep = (bool(prev) and _in(ord(prev), KHMER)) or (bool(nxt) and _in(ord(nxt), KHMER))
        elif o in (0x200c, 0x200d):
            p = prev
            if p and _vs(p) and i > 1:
                p = text[i - 2]
            for ch in (p, nxt):
                if ch and ((_in(ord(ch), JOINING) and unicodedata.category(ch)[0] in 'LM')
                           or is_symbol(ch)):
                    keep = True
                    break
        if not keep:
            out.append(i)
    return out


def _space_kept(text, i):
    c = text[i]
    if c not in '\u00a0\u202f':
        return False
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if (prev and prev.isdigit()) or (nxt and nxt.isdigit()):
        return True
    if nxt and nxt in ':;!?\u00bb\u203a%\u20ac':
        return True
    if prev and prev in '\u00ab\u2039':
        return True
    return False


def space_indices(text):
    out = []
    for m in SP_RE.finditer(text):
        i = m.start()
        if not _space_kept(text, i):
            out.append(i)
    return out


# ---- homoglyphs -------------------------------------------------------------
_PAIRS = {
    # Cyrillic lower
    '\u0430': 'a', '\u0441': 'c', '\u0501': 'd', '\u0435': 'e', '\u04bb': 'h', '\u0456': 'i',
    '\u0458': 'j', '\u043e': 'o', '\u0440': 'p', '\u0455': 's', '\u0475': 'v', '\u051d': 'w',
    '\u0445': 'x', '\u0443': 'y',
    # Cyrillic upper
    '\u0410': 'A', '\u0412': 'B', '\u0421': 'C', '\u0415': 'E', '\u041d': 'H', '\u0406': 'I',
    '\u0408': 'J', '\u041a': 'K', '\u041c': 'M', '\u041e': 'O', '\u0420': 'P', '\u0405': 'S',
    '\u0422': 'T', '\u0425': 'X', '\u04ae': 'Y', '\u0423': 'Y',
    # Greek
    '\u0391': 'A', '\u0392': 'B', '\u0395': 'E', '\u0396': 'Z', '\u0397': 'H', '\u0399': 'I',
    '\u039a': 'K', '\u039c': 'M', '\u039d': 'N', '\u039f': 'O', '\u03a1': 'P', '\u03a4': 'T',
    '\u03a5': 'Y', '\u03a7': 'X',
    '\u03bf': 'o', '\u03bd': 'v', '\u03c1': 'p', '\u03b9': 'i', '\u03c5': 'u', '\u03b1': 'a',
    '\u03c7': 'x', '\u03b3': 'y',
    # Armenian
    '\u0570': 'h', '\u0578': 'n', '\u057d': 'u', '\u0581': 'g', '\u0585': 'o', '\u054f': 'S',
    '\u0555': 'O', '\u0548': 'N',
}
HOMOGLYPHS = _PAIRS
RUN_RE = re.compile(r'[^\W\d_]+')
_ASCII_LET = re.compile('[A-Za-z]')


def homoglyph_runs(text):
    """Return list of (start, end, count) for mixed-script runs."""
    out = []
    for m in RUN_RE.finditer(text):
        s = m.group()
        if s.isascii():
            continue
        if not _ASCII_LET.search(s):
            continue
        cnt = 0
        ok = True
        for ch in s:
            if ch in _PAIRS:
                cnt += 1
            elif ord(ch) > 127:
                ok = False
                break
        if ok and cnt:
            out.append((m.start(), m.end(), cnt))
    return out


def clean_text(text):
    ended_lf = text.endswith('\n')
    ended_crlf = text.endswith('\r\n')
    rm = set(invisible_indices(text))
    sp = set(space_indices(text))
    folds = {}
    for s, e, _ in homoglyph_runs(text):
        for k in range(s, e):
            if text[k] in _PAIRS:
                folds[k] = _PAIRS[text[k]]
    out = []
    for i, ch in enumerate(text):
        if i in rm:
            continue
        if i in sp:
            out.append('\n' if ch in '\u2028\u2029' else ' ')
        elif i in folds:
            out.append(folds[i])
        else:
            out.append(ch)
    t = ''.join(out)
    t = re.sub(r'[ \t]+(?=\r?\n|$)', '', t)
    t = re.sub(r'\A(?:[ \t]*\r?\n)+', '', t)
    t = t.rstrip(' \t\r\n\f\v')
    if ended_lf:
        t += '\r\n' if ended_crlf else '\n'
    return t
