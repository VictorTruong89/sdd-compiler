#!/usr/bin/env python3
"""prosecheck detector: local, standard-library prose-pattern scanner."""
import json
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import chars as CH  # noqa: E402
import extract as EX  # noqa: E402
import families as FM  # noqa: E402

USAGE = ("usage: detect.py [--clean] [--ci] [--] [FILE]\n"
         "\n"
         "Scores prose for AI-writing patterns (0-100) and prints a JSON report.\n"
         "  --clean   print the text with invisible characters, odd spaces and\n"
         "            lookalike letters scrubbed, instead of the report\n"
         "  --ci      add a resampled low/high interval on the score\n"
         "  --        stop option parsing (a file name may begin with a dash)\n"
         "  FILE      one file; with no FILE, text is read from standard input\n"
         "  -h, --help  show this message\n")


def fail(code, msg):
    sys.stderr.write(json.dumps({"error": msg}, ensure_ascii=False) + "\n")
    sys.stderr.flush()
    return code


def out_bytes(s):
    sys.stdout.flush()
    sys.stdout.buffer.write(s.encode('utf-8', 'replace'))
    sys.stdout.buffer.flush()


def main(argv):
    args = list(argv)
    clean = False
    ci = False
    files = []
    opts_done = False
    for a in args:
        if a == '--':
            break
        if a in ('-h', '--help'):
            out_bytes(USAGE)
            return 0
    for a in args:
        if opts_done:
            files.append(a)
        elif a == '--':
            opts_done = True
        elif a == '--clean':
            clean = True
        elif a == '--ci':
            ci = True
        elif a.startswith('-'):
            return fail(2, "unknown option: %s (see --help)" % a)
        else:
            files.append(a)
    if len(files) > 1:
        sys.stderr.write("prosecheck: only the first file was scanned: %s\n" % files[0])
    path = files[0] if files else None

    if path is None:
        try:
            data = sys.stdin.buffer.read()
        except Exception as e:
            return fail(1, "cannot read input: %s" % e)
        text = EX.decode_bytes(data)
    else:
        try:
            with open(path, 'rb') as f:
                data = f.read()
        except Exception as e:
            return fail(1, "cannot read input: %s" % (getattr(e, 'strerror', None) or e))
        ext = os.path.splitext(path)[1].lower()
        try:
            text = EX.extract_bytes(ext, data)
        except EX.ReadError as e:
            return fail(1, "cannot read input: %s" % e)
    if text.startswith('﻿'):
        text = text[1:]
    if text.strip() == '':
        return fail(1, "empty input")

    if clean:
        out_bytes(CH.clean_text(text))
        return 0

    report = FM.analyze_document(text, ci=ci)
    out_bytes(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    return 0


if __name__ == '__main__':
    try:
        code = main(sys.argv[1:])
    except BrokenPipeError:
        code = 0
    except Exception as e:  # never a traceback
        code = fail(1, "cannot read input: %s" % e)
    sys.exit(code)
