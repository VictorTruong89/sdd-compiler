"""Pattern families, scoring and report assembly for prosecheck."""
import math
import random
import re
from collections import Counter

import chars as CH

WINDOW = 262144

BANDS = [(20, 'clean'), (40, 'light tells'), (60, 'mixed'), (80, 'heavy tells'), (100, 'pervasive tells')]


def band_of(score):
    for hi, name in BANDS:
        if score <= hi:
            return name
    return BANDS[-1][1]


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def forms(w):
    s = {w}
    if w.endswith('e'):
        s |= {w + 's', w[:-1] + 'ing', w + 'd'}
    elif w.endswith('y'):
        s |= {w[:-1] + 'ies', w[:-1] + 'ied', w + 'ing', w + 's', w + 'ed'}
    else:
        s |= {w + 's', w + 'es', w + 'ed', w + 'ing'}
    return '|'.join(sorted(s, key=lambda x: -len(x)))


def V(*ws):
    return '(?:' + '|'.join(forms(w) for w in ws) + ')'


def A(*ws):
    return '(?:' + '|'.join(ws) + ')'


ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
SHORT_SET = set(range(1, 40)) | {47, 48, 49, 50, 51, 69}
RHYTHM = {40, 41, 44, 55}

WORD_RE = re.compile(r"(?:[^\W_]|['\-])+")
HEAD_RE = re.compile(r'^\s{0,3}#{1,6}(?:\s|$)')
LIST_RE = re.compile(r'^\s*(?:[-*+]|\d{1,3}[.)])\s+')


def words_of(s):
    return [w for w in WORD_RE.findall(s) if re.search(r'[^\W_]', w)]


# --------------------------------------------------------------------------
# masking
# --------------------------------------------------------------------------
FENCE_OPEN = re.compile(r'^( {0,3})(`{3,}|~{3,})(.*)$')
BADGE_RE = re.compile(r'^\s*(?:\[?!\[[^\]]*\]\([^)]*\)(?:\]\([^)]*\))?\s*)+$')
TABLE_RE = re.compile(r'^\s*\|.*\|\s*$|^\s*\|?\s*:?-{2,}:?\s*(?:\|\s*:?-{2,}:?\s*)+\|?\s*$')
INLINE_CODE = re.compile(r'(?<!`)(`+)(?!`)(.+?)(?<!`)\1(?!`)', re.S)


def _blank(s):
    return ''.join('\n' if c == '\n' else ' ' for c in s)


def mask_markdown(a):
    lines = a.split('\n')
    n = len(lines)
    mask = [False] * n
    i = 0
    # front matter
    if n and lines[0].rstrip() == '---':
        for j in range(1, n):
            if lines[j].rstrip() in ('---', '...'):
                for k in range(0, j + 1):
                    mask[k] = True
                i = j + 1
                break
    fence = None
    bq = [False] * n
    while i < n:
        ln = lines[i]
        if fence is not None:
            mask[i] = True
            m = re.match(r'^ {0,3}(`{3,}|~{3,})\s*$', ln)
            if m and m.group(1)[0] == fence[0] and len(m.group(1)) >= fence[1]:
                fence = None
        else:
            m = FENCE_OPEN.match(ln)
            if m and not (m.group(2)[0] == '`' and '`' in m.group(3)):
                fence = (m.group(2)[0], len(m.group(2)))
                mask[i] = True
            elif ln.lstrip().startswith('>') and len(ln) - len(ln.lstrip()) < 4:
                bq[i] = True
            elif TABLE_RE.match(ln) or (BADGE_RE.match(ln) and '![' in ln):
                mask[i] = True
        i += 1
    i = 0
    while i < n:
        if bq[i]:
            j = i
            while j < n and bq[j]:
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    mask[k] = True
            i = j
        else:
            i += 1
    res = [(_blank(l) if mask[k] else l) for k, l in enumerate(lines)]
    out = '\n'.join(res)
    out = INLINE_CODE.sub(lambda m: _blank(m.group(0)).replace('\n', ' ') if '\n' not in m.group(0)
                          else ''.join(' ' if c != '\n' else '\n' for c in m.group(0)), out)
    return out


# --------------------------------------------------------------------------
# sentences / paragraphs
# --------------------------------------------------------------------------
ABBR = {'mr', 'mrs', 'ms', 'dr', 'prof', 'vs', 'etc', 'e.g', 'i.e', 'inc', 'no', 'st', 'jr', 'sr',
        'fig', 'al', 'approx', 'co', 'ltd', 'u.s', 'cf'}
SPLIT_RE = re.compile(r'[.!?]+["\')\]*_]*[ \t]+')


def split_sentences(seg):
    out = []
    last = 0
    for m in SPLIT_RE.finditer(seg):
        rest = seg[m.end():m.end() + 1]
        if rest and rest.islower():
            continue
        before = seg[last:m.start()]
        tok = re.findall(r'[\w.]+$', before)
        if tok and tok[0].lower().strip('.') in ABBR and m.group().startswith('.'):
            continue
        out.append(seg[last:m.end()].strip())
        last = m.end()
    tail = seg[last:].strip()
    if tail:
        out.append(tail)
    return out


def para_segments(par):
    segs = []
    buf = []

    def flush():
        if buf:
            segs.append(' '.join(buf))
            del buf[:]
    for ln in par.split('\n'):
        s = ln.strip()
        if not s:
            continue
        if HEAD_RE.match(ln):
            flush()
            continue
        if re.fullmatch(r'[-=*_ \t]{3,}', s):
            flush()
            continue
        mm = LIST_RE.match(ln)
        if mm:
            flush()
            segs.append(ln[mm.end():].strip())
            continue
        buf.append(s)
    flush()
    return segs


class Ctx(object):
    pass


def build_ctx(w):
    ctx = Ctx()
    a = w.replace('\r\n', ' \n').replace('\r', '\n')
    a = a.replace(' ', '\n').replace(' ', '\n')
    ctx.orig = w
    ctx.a = a
    mo = mask_markdown(a)
    ctx.mo = mo
    m = mo.replace('’', "'").replace('‘', "'")
    m = CH.SP_RE.sub(' ', m)
    ctx.m = m
    ctx.paras = [p for p in re.split(r'\n[ \t]*\n+', m)]
    ctx.sents = []        # (para_idx, text, nwords)
    for pi, p in enumerate(ctx.paras):
        for seg in para_segments(p):
            for s in split_sentences(seg):
                nw = len(words_of(s))
                if nw:
                    ctx.sents.append((pi, s, nw))
    ctx.words = words_of(m)
    ctx.nwords = len(ctx.words)
    return ctx


# --------------------------------------------------------------------------
# regex families
# --------------------------------------------------------------------------
def rxf(*pats, **kw):
    flags = kw.get('flags', re.I)
    c = re.compile('|'.join('(?:%s)' % p for p in pats), flags)

    def f(ctx):
        return [(x.start(), x.end()) for x in c.finditer(ctx.m)]
    return f


ADJ1 = A('crucial', 'pivotal', 'vibrant', 'meticulous', 'intricate', 'enduring', 'holistic',
         'transformative', 'unprecedented', 'myriad', 'robust', 'seamless', 'multifaceted')
VERB1 = V('delve', 'tapestry', 'testament', 'underscore', 'interplay', 'garner', 'bolster', 'foster',
          'showcase', 'emphasize', 'emphasise', 'enhance', 'leverage', 'utilize', 'utilise',
          'facilitate', 'encompass', 'harness', 'navigate', 'embark', 'craft', 'landscape', 'journey',
          'realm', 'elevate', 'empower', 'unlock', 'paradigm', 'plethora')
F1 = rxf(r'\b(?:' + VERB1 + r'|' + ADJ1 + r'(?:ly)?|intricacies|additionally|aligns?\s+with|aligned\s+with|aligning\s+with|'
         r'captur(?:e|es|ed|ing)\s+the\s+(?:essence|spirit|imagination|heart|magic))\b')

F2 = rxf(r'\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly)\b',
         r'\bquietly\s+(?:powerful|profound|radical)\b',
         r'\bdeeply\s+(?:human|personal|felt|unsettling)\b',
         r'\bresonat(?:e|es|ed|ing)\s+deeply\b',
         r'\bgame[- ]chang(?:er|ers|ing)\b',
         r'\b' + V('supercharge') + r'\b', r'\bskyrocket(?:s|ed|ing)?\b', r'\b' + V('turbocharge') + r'\b',
         r'\brevolution(?:ize|izes|ized|izing|ise|ises|ised|ising)\b',
         r'\bdoubl(?:e|es|ed|ing)\s+down\s+on\b',
         r'\b(?:div(?:e|es|ed|ing)|dove)\s+deep(?:er)?\s+into\b',
         r'\bunlock(?:s|ed|ing)?\s+(?:the\s+)?(?:power|potential|value)\b',
         r'\b(?:take|takes|took|taken|taking)\b[^.!?\n]{0,40}?\bto\s+the\s+next\s+level\b')

PROMO_WORDS = rxf(
    r'\bnestled\b', r'\bbreathtaking\b', r'\bmust-visit\b', r'\bstunning\b', r'\bpicturesque\b',
    r'\bcharming\b', r'\bidyllic\b', r'\bvibrant\s+community\b', r'\brich\s+cultural\s+heritage\b',
    r'\bin\s+the\s+heart\s+of\b', r'\bworld-class\b', r'\btop-tier\b', r'\bunparalleled\b',
    r'\bpremier\b', r'\bleading\b(?!\s+(?:to|up|the|a|an|by|with|from|into|in|off|on|us|me|you|them|her|him|his|its|their|our)\b)',
    r'\besteemed\s+organi[sz]ation\b', r'\bvaluable\s+asset\b', r'\bpassion\s+for\s+excellence\b',
    r'\bproven\s+track\s+record\b', r'\bresults-oriented\b', r'\bwealth\s+of\s+experience\b',
    r'\bdynamic\s+team\b', r'\bfast-paced\s+environment\b', r'\bdeeply\s+passionate\b',
    r'\bperfectly\s+situated\b', r'\b(?:close|tight)-knit\s+team\b',
    r"\bI\s+am\s+excited\s+to\s+(?:apply|bring)\b", r'\buniquely\s+positioned\s+to\b')
IMPER = re.compile(r'^(?:install|join|grab|download|try|discover|experience|escape|transform|reclaim|unlock|'
                   r'elevate|boost|say|imagine|explore|meet|introducing|upgrade|claim|unleash|supercharge|'
                   r'level|stop|start)\b', re.I)


def f3(ctx):
    hits = PROMO_WORDS(ctx)
    k = sum(1 for _, s, _ in ctx.sents if IMPER.match(s.lstrip('*_#> ')))
    if k >= 3:
        hits.append((0, 0))
    return hits


F5 = rxf(r'\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b')

STOCK_ADJ = set('''innovative dynamic powerful seamless robust scalable flexible intuitive modern sleek elegant
versatile efficient reliable secure vibrant stunning comprehensive cutting-edge state-of-the-art
engaging compelling exciting rich diverse unique effective advanced cohesive impactful strategic
holistic streamlined user-friendly transformative thoughtful meaningful beautiful bold fresh
simple clean fast smart lightweight performant'''.split())
ADJ_END = re.compile(r'(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$', re.I)
CHAIN = re.compile(r"\b([A-Za-z][A-Za-z-]+)((?:,\s+[A-Za-z][A-Za-z-]+){2,})(?:,?\s+(?:and|or)\s+([A-Za-z][A-Za-z-]+))?(?:\s+([A-Za-z]+))?")


def f6(ctx):
    out = []
    for m in CHAIN.finditer(ctx.m):
        items = [m.group(1)] + re.findall(r'[A-Za-z][A-Za-z-]+', m.group(2))
        if m.group(3):
            items.append(m.group(3))
        if len(items) < 4:
            continue
        low = [x.lower() for x in items]

        def adjy(x):
            return x in STOCK_ADJ or bool(ADJ_END.search(x))
        if not any(adjy(x) for x in low):
            continue
        trailing = m.group(4)
        if m.group(3):
            last_is_noun = not adjy(low[-1])
        else:
            last_is_noun = not adjy(low[-1])
        if last_is_noun or (trailing and trailing.lower() not in
                            ('and', 'or', 'but', 'that', 'which', 'to', 'is', 'are', 'for', 'with', 'in', 'of')
                            and not adjy(trailing.lower())):
            out.append((m.start(), m.end()))
    return out


SYN = [
    [r'protagonists?', r'main\s+characters?', r'central\s+figures?', r'hero(?:es)?', r'heroines?'],
    [r'compan(?:y|ies)', r'firms?', r'organi[sz]ations?', r'enterprises?', r'business(?:es)?'],
    [r'authors?', r'writers?', r'novelists?', r'scribes?'],
    [r'reports?', r'stud(?:y|ies)', r'analys[ie]s', r'investigations?', r'examinations?'],
    [r'technolog(?:y|ies)', r'tools?', r'systems?', r'platforms?', r'solutions?'],
    [r'techniques?', r'methods?', r'approach(?:es)?', r'strateg(?:y|ies)', r'tactics?'],
    [r'challenges?', r'obstacles?', r'difficult(?:y|ies)', r'hurdles?', r'barriers?'],
    [r'benefits?', r'advantages?', r'upsides?', r'strengths?'],
]
SYN_C = [[re.compile(r'\b' + p + r'\b', re.I) for p in cl] for cl in SYN]


def f8(ctx):
    out = []
    for cl in SYN_C:
        present = [c for c in cl if c.search(ctx.m)]
        if len(present) >= 3:
            mm = present[0].search(ctx.m)
            out.append((mm.start(), mm.end()))
    return out


SIG_NOUN = r'(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)'
F10 = rxf(
    r'\b(?:stand|stands|stood|standing|serve|serves|served|serving)\s+as\s+(?:a|an|the)\s+' + SIG_NOUN + r'\b',
    r'\b(?:underscor|highlight)(?:e|es|ed|ing)?s?\s+(?:its|the|their|his|her)\s+(?:\w+\s+)?'
    r'(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b',
    r'\breflects?\s+(?:a\s+)?broader\s+(?:trend|shift|pattern)\b',
    r'\bmarks?\s+(?:a\s+)?(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)\b',
    r'\bsymboli[sz]es\b', r'\bsets?\s+the\s+stage\s+for\b', r'\bleft\s+an\s+indelible\s+mark\b',
    r'\bplays?\s+an?\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b',
    r'\bhas\s+(?:shaped|sparked)\b', r'\bhas\s+come\s+to\s+(?:define|symboli[sz]e)\b')

OUTLETS = re.compile(r'(?:[A-Z][\w&\'.-]*(?:\s+[A-Z][\w&\'.-]*)*)')
CREDIT = re.compile(r'\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+([^.!?\n]*)', re.I)


def f11(ctx):
    out = []
    for m in CREDIT.finditer(ctx.m):
        rest = m.group(1)
        names = [x for x in OUTLETS.findall(rest)]
        if len(names) >= 2 and re.search(r'[A-Z]', rest):
            out.append((m.start(), m.end()))
    for m in re.finditer(r'\b\d[\d,.]*\s*[kKmM]?\+?\s+followers\b|\b(?:strong|active)\s+(?:online|digital|social[- ]media)\s+presence\b|'
                         r'\bwidely\s+covered\b|\bindependent\s+coverage\b', ctx.m, re.I):
        out.append((m.start(), m.end()))
    return out


F12 = rxf(r'\bexperts\s+(?:argue|believe|say|claim|note|suggest)\b',
          r'\bindustry\s+(?:reports|observers|analysts)\b', r'\bobservers\s+have\s+(?:cited|noted)\b',
          r'\bsome\s+critics\s+argue\b', r'\bresearchers\s+have\s+found\b', r'\bstudies\s+suggest\b',
          r"\bit\s+(?:is|'s)\s+widely\s+believed\b")

F13 = rxf(r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Catalog|Guide|Overview) of "
          r"[A-Z0-9][\w'&:-]*(?: (?:of|the|and|in|for|a|to|de|von|[A-Z0-9][\w'&:-]*)){0,7} "
          r"(?:is|are|was|were) (?:a|an|the)\b", flags=0)

F14 = rxf(r'\bplays?\s+an?\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b',
          r'\bconservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)\b',
          r'\bserves?\s+as\s+an?\s+indicator\s+species\b', r'\bcontributes?\s+to\s+biodiversity\b')

F15 = rxf(r'\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]{0,120}?'
          r'\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering|grand|sprawling)\b')

ING = A('highlighting', 'reflecting', 'symbolizing', 'symbolising', 'emphasizing', 'emphasising', 'underscoring',
        'showcasing', 'fostering', 'cultivating', 'encompassing', 'signaling', 'signalling', 'demonstrating',
        'illustrating', 'representing', 'suggesting', 'indicating', 'reinforcing', 'leveraging', 'aligning',
        'embodying', 'exemplifying', 'epitomizing', 'epitomising')
F16 = rxf(r',\s+' + ING + r'\b')

F17P = rxf(r"\bit['’]?s\s+not\s+(?:just|merely)\s+(?:about|an?)\b",
           r'\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b',
           r"\bdoesn['’]?t\s+just\b[^,.\n]{0,40}?\bit\b")
F17T = rxf(r',\s+no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b')

F18 = rxf(r'\b(?:no|not)\s+\w+,\s+(?:just|only|simply)\s+\w+',
          r"\b(?:not|isn't|aren't|wasn't|weren't)\s+(?:just|merely)\b[^.!?;\n]{0,40}?"
          r"(?:,|\s[—–-]+\s?|—)\s*(?:it's|it\s+is|it\s+was|they're|they\s+are|they\s+were|that's|but)\b")

F19 = rxf(r'\bin\s+order\s+to\b', r'\bdue\s+to\s+the\s+fact\s+that\b', r'\bat\s+this\s+point\s+in\s+time\b',
          r'\bin\s+the\s+event\s+that\b', r'\bhas\s+the\s+ability\s+to\b', r'\bit\s+is\s+important\s+to\s+note\s+that\b',
          r'\bit\s+should\s+be\s+mentioned\s+that\b', r'\bneedless\s+to\s+say\b')

F20 = rxf(r"\bit(?:'s|\s+is)\s+worth\s+(?:noting|mentioning)\s+that\b", r'\bit\s+bears\s+(?:noting|mentioning)\s+that\b',
          r'\bone\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is\b', r'\bit\s+is\s+interesting\s+to\s+note\s+that\b',
          r'\ba\s+key\s+consideration\s+is\b', r'\ba\s+point\s+to\s+highlight\s+is\b')

F21 = rxf(r',\s+(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about|'
          r'with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for|'
          r'signaling\s+a\s+shift\s+toward)\b')

F22 = rxf(r"\bhere's\s+the\s+thing\b", r'\bmake\s+no\s+mistake\b', r'\bthe\s+truth\s+is\b', r"\blet's\s+be\s+honest\b",
          r'\bthe\s+simple\s+fact\s+is\b', r'\bat\s+its\s+core\b', r'\bwhat\s+really\s+matters\b',
          r'\bmore\s+than\s+anything\b', r'\bat\s+the\s+end\s+of\s+the\s+day\b', r'\bthe\s+bottom\s+line\s+is\b',
          r'\bin\s+reality\b', r'\bfundamentally,', r'\bthe\s+real\s+question\s+is\b', r'\bthe\s+heart\s+of\s+the\s+matter\b',
          r'\bthe\s+deeper\s+issue\b', r'\bwhen\s+you\s+get\s+down\s+to\s+it\b', r'\bwhen\s+all\s+is\s+said\s+and\s+done\b')

F23 = rxf(r"\bit(?:'s|\s+is)\s+important\s+to\s+(?:remember|note|understand|recognize|recognise)\b",
          r'\bone\s+must\s+note\s+that\b', r'\bit\s+is\s+worth\s+pointing\s+out\b',
          r'\bit\s+cannot\s+be\s+overstated\s+that\b', r'\bit\s+must\s+be\s+emphasi[sz]ed\s+that\b')

F24 = rxf(r'\bthis\s+comprehensive\s+(?:guide|overview|analysis)\b', r'\bthis\s+in-depth\s+(?:analysis|look|examination)\b',
          r'\bthis\s+complete\s+(?:guide|overview)\b', r'\ba\s+thorough\s+examination\s+of\b',
          r'\beverything\s+you\s+need\s+to\s+know\s+about\b')

F25 = rxf(r"(?:^|[.!?]\s+|\n)(?:Is|Are|Was|Were|Do|Does|Did|Can|Could|Will|Would|Should|Shall|May|Might|Must|Has|Have|Had)\b"
          r"[^.!?\n]{0,80}\?\s+(?:Yes|No|Absolutely|Never|Maybe|Probably|Always|Definitely|Certainly|Sometimes|Not really)[.!](?=\s|$)",
          flags=re.M)

F26 = rxf(r'\bwithout\s+concrete\s+evidence\b', r'\bdo\s+you\s+have\s+concrete\s+evidence\b',
          r'\bI\s+(?:would\s+|\'d\s+)?need\s+concrete\s+(?:evidence|examples)\s+to\b', r'\babsent\s+concrete\s+proof\b',
          r'\bprovide\s+concrete\s+evidence\b')

F27 = rxf(r"\bin\s+today's\s+(?:[\w-]+\s+){0,2}?(?:world|landscape|environment|market)\b", r'\bin\s+a\s+world\s+where\b',
          r'\bin\s+an\s+era\s+of\b', r'\bin\s+recent\s+years,', r'\bmore\s+than\s+ever\s+before\b',
          r'\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b', r'\b(?:great|exciting|big)\s+news\s*[!:]',
          r'\bever\s+(?:wanted|wondered|dreamed|wished)\s+to\b[^?.!\n]*\?',
          r'\bin\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world\b')

F30 = rxf(r'\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b',
          r'\b(?:the|this)\s+(?:(?:latest|new)\s+)?(?:update|release|version|change|patch|design)\s+'
          r'(?:adds|introduces|brings|delivers|includes|provides|improves)\b',
          r'\b(?:has|have)\s+been\s+(?:updated|refactored|improved|enhanced|changed)\s+to\b',
          r'\bpreviously\b[^.!?\n]{0,120}?\bnow\b', r"\b(?:wasn't|weren't)\s+there\s+before\b",
          r"\bwe(?:'ve|\s+have)\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b")

F31 = rxf(r"\blet's\s+(?:dive|delve|explore)\b", r"\blet's\s+break\s+(?:this|it)\s+down\b",
          r"\bhere's\s+what\s+you\s+need\s+to\s+know\b", r'\bwithout\s+further\s+ado\b', r"\bnow\s+let's\s+look\s+at\b",
          r'\bbuckle\s+up\b', r'\bstay\s+with\s+me\b', r'\b(?:are\s+you\s+)?ready\s+to\s+dive\s+in\b')

F32 = rxf(r'\b(?:used|uses|employs|employed|relied\s+on|utili[sz]es)\s+(?:several|various|a\s+number\s+of|multiple|'
          r'different|many|numerous)\s+\w+',
          r'(?:^|[.!?]\s+|\n)These\s+(?:\w+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help)\s+(?:\w+\s+)?'
          r'(?:information|insights?|understanding|details|data)\b',
          r'\b(?:is|are|was|were|remains|becomes)\s+(?:the|a)\s+(?:language|currency|architecture|heartbeat|lifeblood|DNA|'
          r'backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b')

F33 = rxf(r'^[ \t]*(?:(?:[-*+]|\d{1,3}[.)])[ \t]+)?\*\*[^*\n]+?(?::\*\*|\*\*[ \t]*:)', flags=re.M)

TITLE_MIN = 3


def f34(ctx):
    if re.search(r'^\s{0,3}#{1,6}\s', ctx.m, re.M):
        return []
    list_pars = 0
    prose = 0
    for p in ctx.paras:
        ls = [l for l in p.split('\n') if l.strip()]
        if not ls:
            continue
        if all(LIST_RE.match(l) for l in ls):
            list_pars += 1
        elif any(len(words_of(l)) >= 3 for l in ls) and not any(LIST_RE.match(l) for l in ls[:1]):
            prose += 1
    if list_pars >= 1 and prose >= 2:
        return [(0, 0)]
    return []


STOPW = {'the', 'and', 'for', 'with', 'from', 'that', 'this', 'are', 'was', 'what', 'how', 'why', 'your', 'our'}


def f35(ctx):
    lines = ctx.m.split('\n')
    out = []
    for i, ln in enumerate(lines):
        if not HEAD_RE.match(ln):
            continue
        h = re.sub(r'^\s*#+\s*', '', ln).strip(' #')
        hw = set(w.lower() for w in words_of(h) if len(w) >= 3 and w.lower() not in STOPW)
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nx = lines[j]
        if HEAD_RE.match(nx) or LIST_RE.match(nx) or nx.lstrip().startswith('|'):
            continue
        nw = words_of(nx)
        if 0 < len(nw) <= 5 and hw & set(w.lower() for w in nw):
            out.append((0, 0))
    return out


F36 = rxf(r'\bdespite\s+(?:these|its|the)\s+(?:\w+\s+)?(?:challenges|obstacles)\b',
          r'\bchallenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)\b', r'\bcontinues\s+to\s+thrive\b',
          r'\btypical\s+of\s+(?:emerging|urban|modern)\b', r'\bfaces\s+(?:several|many|numerous)\s+challenges\b')

TRANS = re.compile(r'(?:^[ \t>*#_-]*|[.!?]["\')\]*_]*[ \t]+)(?:Additionally|Furthermore|Moreover|However|Nevertheless|'
                   r'Consequently|Subsequently|Notably)\b', re.M)


def f37(ctx):
    out = []
    for p in ctx.paras:
        ms = list(TRANS.finditer(p))
        if len(ms) >= 2:
            out.extend((0, 0) for _ in ms)
    return out


F38 = rxf(r'^[ \t>*_#-]*(?:in\s+conclusion|overall|in\s+summary|to\s+summari[sz]e|to\s+conclude|all\s+in\s+all|in\s+essence|ultimately)\b',
          flags=re.M | re.I)

F39 = rxf(r'\bthe\s+future\s+looks\s+bright\b', r'\bexciting\s+times\s+lie\s+ahead\b', r'\bjourney\s+toward\s+excellence\b',
          r'\bstep\s+in\s+the\s+right\s+direction\b', r'\b(?:the\s+)?(?:outlook|future)(?:\s+for\s+[\w\s]{1,30}?)?\s+(?:is|looks|remains)\s+bright\b',
          r'\bwell[- ]positioned\s+for\s+(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)\b')


def cv(vals):
    mean = sum(vals) / float(len(vals))
    if mean == 0:
        return 0.0
    var = sum((v - mean) ** 2 for v in vals) / float(len(vals))
    return math.sqrt(var) / mean


def f40(ctx):
    v = [nw for _, _, nw in ctx.sents]
    if len(v) >= 3 and cv(v) < 0.35:
        return [(0, 0)]
    return []


def f41(ctx):
    v = [nw for _, _, nw in ctx.sents]
    out = []
    i = 0
    n = len(v)
    while i < n - 1:
        j = i
        direction = 0
        while j + 1 < n:
            d = v[j + 1] - v[j]
            if abs(d) < 4 or max(v[j], v[j + 1]) < 1.6 * min(v[j], v[j + 1]):
                break
            sgn = 1 if d > 0 else -1
            if direction and sgn == direction:
                break
            direction = sgn if not direction else -direction
            if direction != sgn:
                break
            j += 1
        if j - i + 1 >= 6:
            out.append((0, 0))
            i = j + 1
        else:
            i += 1
    return out


def f42(ctx):
    out = []
    by = {}
    for pi, s, nw in ctx.sents:
        by.setdefault(pi, []).append(s)
    for pi, ss in by.items():
        if len(ss) < 3:
            continue
        c = Counter()
        for s in ss:
            w = [x.lower() for x in words_of(s)[:2]]
            if len(w) == 2:
                c[tuple(w)] += 1
        for k, v in c.items():
            if v >= 3:
                out.append((0, 0))
    return out


def f44(ctx):
    vals = []
    for p in ctx.paras:
        txt = '\n'.join(l for l in p.split('\n') if not HEAD_RE.match(l))
        n = len(words_of(txt))
        if n:
            vals.append(n)
    if len(vals) >= 4 and cv(vals) < 0.4:
        return [(0, 0)]
    return []


def f46(ctx):
    if ctx.nwords < 300:
        return []
    if ';' not in ctx.m and ctx.m.count('(') <= 1:
        return [(0, 0)]
    return []


F47 = rxf(r'\bI\s+hope\s+this\s+helps\b', r'\b(?:Certainly|Of\s+course)!', r'\blet\s+me\s+know\s+if\s+you\b',
          r'\bwould\s+you\s+like\s+me\s+to\b', r'\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b',
          r'\bhappy\s+to\s+help\s*(?:[.!?]|$)', r'\b(?:here|below)\s+is\s+(?:an?|the)\s+(?:overview|summary|rundown|recap|brief)\b',
          r"\bhere(?:'s|\s+are)\s+(?:a\s+few|some|two|three)\s+(?:\w+\s+)?(?:options|drafts|versions|variations)\b",
          r"\bhere(?:\s+is|'s)\s+a\s+draft\b", r'\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b',
          r'\bI\s+hope\s+(?:this\s+(?:email|message|note)\s+)?finds\s+you\s+well\b',
          r'\bas\s+an?\s+(?:AI|LLM|AI\s+assistant|AI\s+language\s+model|large\s+language\s+model|language\s+model)\b',
          r'\bto\s+(?:answer|address)\s+your\s+question\b', r'\bin\s+(?:response|answer)\s+to\s+your\s+question\b',
          r'\byour\s+question\s+(?:about|regarding|concerning)\b', r'\bas\s+(?:you\s+)?(?:requested|asked),\s+here\b',
          r'\bhere\s+is\s+(?:the\s+)?(?:draft|first\s+pass|revised\s+version\s+of|for\s+your)\b')

F48 = rxf(r"\byou(?:'re|\s+are)\s+absolutely\s+right\b",
          r'\b(?:great\s+question|excellent\s+point)(?=[!.,])',
          r'\bwhat\s+an?\s+(?:thoughtful|great|wonderful|fantastic)\s+question(?=[!.,])',
          r"\bthat's\s+an?\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)(?=[!.,])")

F50 = rxf(r'\bas\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)\b', r'\bup\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)\b',
          r'\bwhile\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+(?:extensively|widely)\s+documented)\b',
          r'\bbased\s+on\s+(?:the\s+)?available\s+information\b', r'\bas\s+of\s+my\s+(?:knowledge\s+)?cutoff\b',
          r'\bmaintains\s+a\s+low\s+profile\b', r"\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b")

F51 = rxf(r'\b(?:serves|stands|functions|acts)\s+as\b', r'\brepresents\s+(?:a|the)\b', r'\bmarks\s+(?:a|the)\b',
          r'\bboast(?:s|ed|ing)?\b',
          r'\bfeatures\s+(?:an?|the|\d+|several|many|numerous|multiple|various|some|a\s+(?:number|variety|range))\b',
          r'\boffers\s+a\b', r'\brefers\s+to\b')

HEDGE = re.compile(r'\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively|fairly|kind of|sort of|'
                   r'seems? (?:to|like)|appears? to)\b')


def f54(ctx):
    out = []
    for _, s, _ in ctx.sents:
        if len(HEDGE.findall(s)) >= 2:
            out.append((0, 0))
    return out


FIRST = re.compile(r"\b(?:i|me|my|mine|myself|we|us|our|ours|ourselves|i'm|i've|i'll|i'd|we're|we've|we'll|we'd)\b", re.I)
WRITTEN = re.compile(r"\b(?:do|does|did|is|are|was|were|has|have|had|will|would|could|should|can)\s+not\b|\bcannot\b|"
                     r"\b(?:I|we|you|they|he|she|it|that|there)\s+(?:am|is|are|will|would|have|has|had)\b", re.I)
CONTR = re.compile(r"\b\w+n't\b|\b(?:i|we|you|they|he|she|it|that|there|what|here|let)'(?:m|re|ve|ll|d|s)\b", re.I)


def f55(ctx):
    if ctx.nwords < 20:
        return []
    fp = len(FIRST.findall(ctx.m))
    if fp / float(ctx.nwords) < 0.02:
        return []
    w = len(WRITTEN.findall(ctx.m))
    c = len(CONTR.findall(ctx.m))
    if w >= 3 and w > 1.5 * c:
        return [(0, 0)]
    return []


F56 = rxf(r'\*\*[^*\n]+?\*\*')
F57 = rxf('[\U0001F000-\U0001FAFF☀-➿⭐⭕⌚⌛⏩-⏳✅❌✨‼⁉]')


def f58(ctx):
    out = []
    for p in ctx.paras:
        n = p.count('—')
        if n >= 2:
            out.extend((0, 0) for _ in range(n))
    return out


SMALLW = set('a an the and but or nor for so yet at by in of on to up as per via vs with from into onto over off out'.split())


def f59(ctx):
    out = []
    for ln in ctx.m.split('\n'):
        m = re.match(r'^\s{0,3}#{1,6}\s+(.*?)\s*#*\s*$', ln)
        if not m:
            continue
        h = m.group(1)
        ws = h.split()
        if len(ws) < 3 or not h[:1].isalpha() or h.isupper():
            continue
        major = [w for w in ws if w.lower().strip('.,:;!?') not in SMALLW]
        if len(major) < 2:
            continue
        if all(w[:1].isupper() for w in major if w[:1].isalpha()) and all(w[:1].isalpha() for w in major):
            out.append((0, 0))
    return out


F60 = lambda ctx: [(x.start(), x.end()) for x in re.finditer('[‘’“”]', ctx.mo)]  # noqa: E731


def f61(ctx):
    out = []
    for m in re.finditer(r'\b(1[5-9]\d\d|20\d\d)-(1[5-9]\d\d|20\d\d)\b', ctx.m):
        if int(m.group(2)) >= int(m.group(1)):
            out.append((m.start(), m.end()))
    return out


PH_WORDS = re.compile(r'^(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b', re.I)
PH_NAMES = {'name', 'person', 'company', 'client', 'place', 'city', 'location', 'source', 'recipient',
            'employer', 'organization', 'organisation', 'town', 'country'}


def f63(ctx):
    out = []
    t = ctx.m
    for m in re.finditer(r'\[([^\[\]\n]{1,80})\]', t):
        nxt = t[m.end():m.end() + 1]
        if nxt in ('(', '['):
            continue
        inner = m.group(1).strip()
        if PH_WORDS.match(inner):
            out.append((m.start(), m.end()))
            continue
        ws = [w.lower() for w in re.findall(r"[A-Za-z]+", inner)]
        if ws and len(ws) <= 4 and any(w in PH_NAMES for w in ws) and not re.search(r'\d', inner):
            out.append((m.start(), m.end()))
            continue
        if re.fullmatch(r"[A-Z][A-Z0-9 _/'.-]*[A-Z0-9]", inner) and len(re.findall('[A-Z]', inner)) >= 3 \
                and not re.fullmatch(r'[A-Z]{1,3}\d*', inner):
            out.append((m.start(), m.end()))
    for m in re.finditer(r'\{\{[^{}\n]*\}\}', t):
        out.append((m.start(), m.end()))
    for m in re.finditer(r'(?<![A-Za-z0-9])[xX]{3,}(?![A-Za-z0-9])', t):
        out.append((m.start(), m.end()))
    for m in re.finditer(r'lorem\s+ipsum', t, re.I):
        out.append((m.start(), m.end()))
    return out


F64 = rxf(r'\bcite(?:turn|start|nav)\w*', r'\boai_citation\w*', r'contentReference', r'\bnavlist\b',
          '【\\d+†[^】]*】')

AI_HOSTS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai', 'gemini.google.com',
            'copilot.microsoft.com', 'poe.com'}


def f65(ctx):
    out = []
    for m in re.finditer(r'utm_source=([A-Za-z0-9.\-]*)', ctx.m):
        host = m.group(1).rstrip('.').lower()
        if host in AI_HOSTS:
            out.append((m.start(), m.end()))
    return out


F69 = rxf(r'\bunlock(?:ing|s|ed)?\s+(?:the\s+|your\s+|its\s+|their\s+|our\s+)?(?:full\s+)?potential\b',
          r'\bnavigat(?:e|es|ed|ing)\s+the\s+complexit(?:y|ies)\b',
          r'\ba\s+testament\s+to\s+the\s+(?:power|importance)\b', r'\bstaying\s+ahead\s+of\s+the\s+curve\b',
          r'\bturning\s+challenges\s+into\s+opportunities\b',
          r'\b(?:taking|takes|take|took)\s+\w+(?:\s+\w+)?\s+to\s+the\s+next\s+level\b',
          r'\bharness(?:ing|es|ed)?\s+the\s+power\s+of\b', r'\bpaving\s+the\s+way\s+for\b', r'\bsaying\s+goodbye\s+to\b',
          r'\bimagining\s+a\s+world\s+where\b', r'\bever-evolving\s+(?:landscape|world|field)\b',
          r'\bat\s+the\s+forefront\s+of\b', r'\bbridging\s+the\s+gap\s+between\b', r'\bpushing\s+the\s+boundaries\s+of\b')

HR_RE = re.compile(r'^\s*(?:-{3,}|\*{3,}|_{3,}|(?:-\s){2,}-|(?:\*\s){2,}\*)\s*$')


def f70(ctx):
    lines = ctx.m.split('\n')
    cnt = 0
    for i, l in enumerate(lines):
        if HR_RE.match(l):
            if l.strip().startswith('-') and i > 0 and lines[i - 1].strip() and not HR_RE.match(lines[i - 1]) \
                    and not HEAD_RE.match(lines[i - 1]):
                continue
            cnt += 1
    if cnt >= 3 and len(lines) >= 24:
        return [(0, 0)] * cnt
    return []


def f71(ctx):
    ws = [w.lower() for w in ctx.words]
    if len(ws) < 17:
        return []
    sh = [tuple(ws[i:i + 6]) for i in range(len(ws) - 5)]
    c = Counter(sh)
    rep = sum(1 for s in sh if c[s] > 1)
    if rep and rep / float(len(sh)) >= 0.2:
        return [(0, 0)]
    return []


F4 = rxf(r'\b(?:cutting-edge|state-of-the-art|best-in-class|results-driven|data-driven|forward-thinking|game-changing|'
         r'fast-paced|detail-oriented|customer-centric|mission-critical|next-generation|end-to-end|top-notch|'
         r'user-friendly|cross-functional|results-oriented|value-added|thought-provoking|ever-evolving|ever-changing|'
         r'one-of-a-kind|time-tested|full-service|self-starter|team-oriented|client-focused|goal-oriented|tech-savvy|'
         r'world-class|high-impact|well-rounded|hands-on|long-standing|far-reaching|innovation-driven)\b')


# --------------------------------------------------------------------------
# registry: number, slug, label, finder
# --------------------------------------------------------------------------
FAMILIES = [
    (1, 'ai_vocabulary', 'AI vocabulary', F1),
    (2, 'model_dialect', 'Model-dialect vocabulary', F2),
    (3, 'promotional_language', 'Promotional language', f3),
    (4, 'hyphenated_pairs', 'Hyphenated word-pair overuse', F4),
    (5, 'simple_yet', '"Simple yet X" cliche', F5),
    (6, 'adjective_chains', 'Stacked adjective chains', f6),
    (8, 'synonym_cycling', 'Synonym cycling', f8),
    (10, 'significance_inflation', 'Significance inflation', F10),
    (11, 'notability_name_dropping', 'Notability name-dropping', f11),
    (12, 'vague_attributions', 'Vague attributions', F12),
    (13, 'article_title_proper_noun', 'Article title as proper noun', F13),
    (14, 'ecosystem_padding', 'Conservation / ecosystem padding', F14),
    (15, 'false_ranges', 'False ranges', F15),
    (16, 'ing_tails', 'Superficial -ing tail clauses', F16),
    (17, 'negative_parallelism', 'Negative parallelism', F17P),
    (17, 'tailing_negation', 'Tailing negation', F17T),
    (18, 'not_x_just_y', '"Not X, just Y" construction', F18),
    (19, 'filler_phrases', 'Filler phrases', F19),
    (20, 'empty_pivots', 'Empty pivot phrases', F20),
    (21, 'outcome_speculation', 'Outcome speculation tails', F21),
    (22, 'authority_tropes', 'Persuasive authority tropes', F22),
    (23, 'editorial_interjections', 'Editorial interjections', F23),
    (24, 'self_thoroughness', 'Self-thoroughness phrases', F24),
    (25, 'question_answer', 'Question-answer rhetorical pattern', F25),
    (26, 'concrete_evidence', '"Concrete evidence" defense phrase', F26),
    (27, 'intro_hooks', 'Compulsive intro hooks', F27),
    (30, 'diff_anchored', 'Diff-anchored writing', F30),
    (31, 'signposting', 'Signposting and announcements', F31),
    (32, 'cataloguing_lead_ins', 'Cataloguing lead-ins', F32),
    (33, 'inline_header_lists', 'Inline-header vertical lists', F33),
    (34, 'mid_essay_bullets', 'Mid-essay bullet injection', f34),
    (35, 'fragmented_headers', 'Fragmented headers', f35),
    (36, 'formulaic_challenges', 'Formulaic challenges section', F36),
    (37, 'transition_clusters', 'Transition cluster overuse', f37),
    (38, 'compulsive_conclusions', 'Compulsive conclusion phrases', F38),
    (39, 'generic_positive_conclusions', 'Generic positive conclusions', F39),
    (40, 'sentence_length_monotony', 'Sentence-length monotony', f40),
    (41, 'length_alternation', 'Mechanical sentence-length alternation', f41),
    (42, 'opener_repetition', 'Opener repetition', f42),
    (44, 'uniform_paragraphs', 'Uniform paragraph length', f44),
    (46, 'semicolon_underuse', 'Semicolon and parenthesis underuse', f46),
    (47, 'chatbot_artifacts', 'Chatbot artifacts', F47),
    (48, 'sycophantic_tone', 'Sycophantic tone', F48),
    (50, 'knowledge_cutoff', 'Knowledge-cutoff disclaimers', F50),
    (51, 'copula_avoidance', 'Copula avoidance', F51),
    (54, 'hedge_stacking', 'Excessive hedging', f54),
    (55, 'contraction_absence', 'Contraction absence', f55),
    (56, 'boldface_overuse', 'Boldface overuse', F56),
    (57, 'emojis', 'Emojis', F57),
    (58, 'em_dash_overuse', 'Em-dash overuse', f58),
    (59, 'title_case_headings', 'Title case in headings', f59),
    (60, 'curly_quotes', 'Curly quotation marks', F60),
    (61, 'hyphen_ranges', 'Hyphen for en dash in ranges', f61),
    (63, 'placeholder_text', 'Placeholder text', f63),
    (64, 'chat_markup_leak', 'Chatbot reference-markup leak', F64),
    (65, 'ai_tracking_params', 'AI tracking parameters', f65),
    (69, 'marketing_slop', 'Canonical marketing-slop phrases', F69),
    (70, 'horizontal_rules', 'Decorative horizontal rules', f70),
    (71, 'degenerate_repetition', 'Degenerate repetition', f71),
]

# score weights: (base, per extra hit, cap)
WEIGHTS = {
    40: (8, 0, 8), 44: (8, 0, 8), 56: (6, 1, 12), 57: (6, 1, 12), 59: (6, 1, 10), 70: (8, 1, 12),
    1: (10, 2, 22), 2: (10, 2, 18), 3: (10, 2, 18),
    62: (20, 2, 26), 63: (20, 2, 26), 64: (20, 2, 26), 65: (20, 2, 26), 66: (20, 2, 26),
    13: (18, 2, 24), 47: (18, 2, 24), 48: (18, 2, 24), 50: (18, 2, 24),
    67: (12, 1, 16),
}
DEFAULT_W = (10, 2, 16)


def sample_for(ctx, num, s, e):
    if s == e:
        return ''
    if num == 1:
        a = max(0, s - 30)
        b = min(len(ctx.orig), e + 30)
        txt = ctx.orig[a:b]
        txt = re.sub(r'[\r\n]', ' ', txt)
        return ('...' if a > 0 else '') + txt + ('...' if b < len(ctx.orig) else '')
    t = re.sub(r'\s+', ' ', ctx.m[s:e]).strip()
    return t[:80]


def char_findings(ctx):
    res = {}
    w = ctx.orig
    inv = CH.invisible_indices(w)
    if inv:
        s = []
        for i in inv[:3]:
            s.append('U+%04X at %d' % (ord(w[i]), i))
        res[62] = ('invisible_chars', 'Invisible / zero-width characters', len(inv), s)
    hg = CH.homoglyph_runs(w)
    hcount = sum(c for _, _, c in hg)
    if hg:
        s = [w[a:b] for a, b, _ in hg[:3]]
        res[66] = ('homoglyph_confusables', 'Homoglyph / mixed-script confusables', hcount, s)
    sp = CH.space_indices(w)
    if sp:
        s = ['U+%04X at %d' % (ord(w[i]), i) for i in sp[:3]]
        res[67] = ('nonstandard_spaces', 'Non-standard spaces', len(sp), s)
    # 68 trailing whitespace
    a = ctx.a
    tw = len(re.findall(r'[ \t]+(?=\n)', a))
    if re.search(r'[ \t]\Z', a):
        tw += 1
    if re.search(r'\n\s*\n\Z', a) or re.search(r'\n\n+\Z', a):
        tw += 1
    if a[:1].isspace():
        tw += 1
    if tw:
        res[68] = ('trailing_whitespace', 'Trailing / stray whitespace', tw, ['trailing whitespace'])
    return res, len(inv), len(sp), hcount


def run_families(ctx, a_findings):
    found = {}
    for num, slug, label, fn in FAMILIES:
        try:
            hits = fn(ctx)
        except Exception:
            hits = []
        if num == 2 and len(hits) < 2:
            hits = []
        if not hits:
            continue
        samples = []
        for s, e in hits:
            sm = sample_for(ctx, num, s, e)
            if sm and sm not in samples:
                samples.append(sm)
            if len(samples) >= 3:
                break
        if not samples:
            samples = [label.lower()]
        found[(num, slug)] = (label, len(hits), samples)
    for num, (slug, label, cnt, samples) in a_findings.items():
        found[(num, slug)] = (label, cnt, samples)
    return found


def compute_score(found, nwords):
    fam = {}
    for (num, slug), (label, cnt, _) in found.items():
        if num in ADVICE or (num, slug) == (17, 'negative_parallelism'):
            continue
        fam[num] = fam.get(num, 0) + cnt
    n = len(fam)
    if n == 0:
        return 0, fam
    total = 0
    for num, cnt in fam.items():
        b, inc, cap = WEIGHTS.get(num, DEFAULT_W)
        total += min(cap, b + inc * (cnt - 1))
    score = total
    if n == 1:
        score = min(score, 40)
    if set(fam) <= RHYTHM:
        score = min(score, 40)
    if set(fam) - {40} == set():
        score = min(score, 20)
    # confidence
    if nwords < 40:
        conf = 'none'
    elif nwords < 120:
        conf = 'low'
    elif nwords < 300:
        conf = 'low' if n == 1 else 'moderate'
    else:
        conf = 'high'
    dec = len(set(fam) & DECISIVE)
    if dec >= 2:
        score = max(score, 65)
    elif dec == 1 and conf in ('moderate', 'high'):
        score = max(score, 45)
    if nwords < 120:
        k = len(set(fam) & SHORT_SET)
        if k >= 3:
            score = max(score, 45)
        elif k >= 2:
            score = max(score, 25)
    if nwords >= 400:
        if n >= 6:
            score = max(score, 45)
        elif n >= 5:
            score = max(score, 25)
    return max(0, min(100, int(round(score)))), fam


def confidence_of(nwords, nfam):
    if nwords < 40:
        return 'none', 'under 40 words: too short to score reliably'
    if nwords < 120:
        return 'low', 'under 120 words: short text, score is a rough guide'
    if nwords < 300:
        if nfam <= 1:
            return 'low', 'under 300 words with only one scoring pattern family'
        return 'moderate', 'under 300 words: moderate sample size'
    return 'high', ''


def analyze_text(w):
    ctx = build_ctx(w)
    a_find, ninv, nsp, nhg = char_findings(ctx)
    found = run_families(ctx, a_find)
    score, fam = compute_score(found, ctx.nwords)
    return ctx, found, score, fam, ninv, nsp, nhg


def analyze_document(text, ci=False):
    truncated = len(text) > WINDOW
    w = text[:WINDOW]
    ctx, found, score, fam, ninv, nsp, nhg = analyze_text(w)
    conf, reason = confidence_of(ctx.nwords, len(fam))
    report = {}
    for (num, slug) in sorted(found):
        label, cnt, samples = found[(num, slug)]
        report['%d_%s' % (num, slug)] = {'label': label, 'count': cnt, 'samples': samples[:3]}
    metrics = {
        'scanned_chars': len(w),
        'truncated': truncated,
        'ai_tell_score': score,
        'ai_tell_band': band_of(score),
        'confidence': conf,
        'confidence_reason': reason,
        'patterns_flagged': len(report),
        'invisible_chars': ninv,
        'nonstandard_spaces': nsp,
        'homoglyphs': nhg,
        'word_count': ctx.nwords,
    }
    if ci:
        sents = [s for _, s, _ in ctx.sents]
        if len(sents) < 4:
            metrics['score_ci'] = None
            metrics['score_ci_note'] = 'too few sentences (fewer than 4) for an interval'
        else:
            rng = random.Random(20240601)
            n_res = 30 if len(w) < 40000 else 8
            vals = []
            for _ in range(n_res):
                pick = [sents[rng.randrange(len(sents))] for _ in sents]
                _, f2, s2, _, _, _, _ = analyze_text(' '.join(pick))
                vals.append(s2)
            vals.sort()
            lo = vals[int(0.05 * (len(vals) - 1))]
            hi = vals[int(math.ceil(0.95 * (len(vals) - 1)))]
            lo = min(lo, score)
            hi = max(hi, score)
            metrics['score_ci'] = [float(lo), float(hi)]
            metrics['score_ci_note'] = 'resampled over sentences (%d draws, fixed seed)' % n_res
    report['_metrics'] = metrics
    return report
