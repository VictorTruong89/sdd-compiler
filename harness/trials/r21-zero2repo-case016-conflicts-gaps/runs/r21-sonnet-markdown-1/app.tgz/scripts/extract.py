"""Prose extraction for prosecheck (standard library only)."""
import io
import json
import posixpath
import re
import zipfile
from html.parser import HTMLParser
from xml.etree import ElementTree as ET

PLAIN_EXTS = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXTS = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NOTEBOOK_EXTS = {'.ipynb'}
MEMBER_CAP = 64 * 1024 * 1024


class ReadError(Exception):
    pass


def decode_bytes(data):
    if data.startswith(b'\xef\xbb\xbf'):
        return data[3:].decode('utf-8', 'replace')
    if data.startswith(b'\xff\xfe') or data.startswith(b'\xfe\xff'):
        try:
            return data.decode('utf-16')
        except UnicodeDecodeError:
            return data.decode('utf-16', 'replace')
    return data.decode('utf-8', 'replace')


def _local(tag):
    return tag.rsplit('}', 1)[-1] if isinstance(tag, str) else ''


def _read(zf, name):
    info = zf.getinfo(name)
    if info.file_size > MEMBER_CAP:
        return b''
    return zf.read(name)


def _parse(data):
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


def _fallback_strip(data, para_tags):
    s = data.decode('utf-8', 'replace')
    for t in para_tags:
        s = re.sub(r'</' + t + r'\s*>', '\n', s)
    s = re.sub(r'<[^>]+>', '', s)
    import html
    return html.unescape(s)


def _clean_paras(paras):
    out = []
    for p in paras:
        if p is None:
            continue
        if p.strip() == '':
            continue
        out.append(p)
    return out


# ---- docx -----------------------------------------------------------------
def _docx(zf):
    names = [n for n in zf.namelist() if n == 'word/document.xml']
    if not names:
        return ''
    data = _read(zf, names[0])
    root = _parse(data)
    if root is None:
        return _fallback_strip(data, ['w:p']).strip()
    paras = []

    def para_text(p):
        buf = []

        def rec(el):
            for ch in el:
                t = _local(ch.tag)
                if t == 't':
                    buf.append(ch.text or '')
                elif t == 'tab':
                    buf.append('\t')
                elif t in ('br', 'cr'):
                    buf.append('\n')
                elif t in ('p', 'Fallback', 'delText', 'instrText'):
                    continue
                else:
                    rec(ch)
        rec(p)
        return ''.join(buf)

    for el in root.iter():
        if _local(el.tag) == 'p':
            paras.append(para_text(el))
    return '\n'.join(_clean_paras(paras))


# ---- pptx -----------------------------------------------------------------
def _pptx(zf):
    slides = []
    for n in zf.namelist():
        m = re.match(r'ppt/slides/slide(\d+)\.xml$', n)
        if m:
            slides.append((int(m.group(1)), n))
    slides.sort()
    paras = []
    for _, n in slides:
        data = _read(zf, n)
        root = _parse(data)
        if root is None:
            paras.extend(_fallback_strip(data, ['a:p']).split('\n'))
            continue
        for p in root.iter():
            if _local(p.tag) != 'p':
                continue
            buf = []
            for e in p.iter():
                t = _local(e.tag)
                if t == 't':
                    buf.append(e.text or '')
                elif t == 'br':
                    buf.append('\n')
            paras.append(''.join(buf))
    return '\n'.join(_clean_paras(paras))


# ---- xlsx -----------------------------------------------------------------
def _xlsx(zf):
    shared = []
    if 'xl/sharedStrings.xml' in zf.namelist():
        root = _parse(_read(zf, 'xl/sharedStrings.xml'))
        if root is not None:
            for si in root:
                if _local(si.tag) != 'si':
                    continue
                buf = []

                def rec(el):
                    for ch in el:
                        t = _local(ch.tag)
                        if t == 't':
                            buf.append(ch.text or '')
                        elif t == 'rPh':
                            continue
                        else:
                            rec(ch)
                rec(si)
                shared.append(''.join(buf))
    sheets = []
    for n in zf.namelist():
        m = re.match(r'xl/worksheets/sheet(\d+)\.xml$', n)
        if m:
            sheets.append((int(m.group(1)), n))
    sheets.sort()
    out = []
    for _, n in sheets:
        root = _parse(_read(zf, n))
        if root is None:
            continue
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            t = c.get('t')
            text = None
            if t == 's':
                v = None
                for ch in c:
                    if _local(ch.tag) == 'v':
                        v = (ch.text or '').strip()
                if v is not None and re.fullmatch(r'[0-9]+', v):
                    idx = int(v)
                    if idx < len(shared):
                        text = shared[idx]
            elif t == 'inlineStr':
                buf = []
                for ch in c:
                    if _local(ch.tag) == 'is':
                        for e in ch.iter():
                            if _local(e.tag) == 't':
                                buf.append(e.text or '')
                text = ''.join(buf)
            elif t == 'str':
                for ch in c:
                    if _local(ch.tag) == 'v':
                        text = ch.text or ''
            if text is not None and text.strip():
                out.append(text)
    return '\n'.join(out)


# ---- odf ------------------------------------------------------------------
def _odf(zf):
    if 'content.xml' not in zf.namelist():
        return ''
    data = _read(zf, 'content.xml')
    root = _parse(data)
    if root is None:
        return _fallback_strip(data, ['text:p', 'text:h']).strip()
    paras = []

    def inline(el):
        buf = [el.text or '']
        for ch in el:
            t = _local(ch.tag)
            if t == 's':
                try:
                    n = int(ch.get('{urn:oasis:names:tc:opendocument:xmlns:text:1.0}c', '1'))
                except ValueError:
                    n = 1
                buf.append(' ' * max(n, 1))
            elif t == 'tab':
                buf.append('\t')
            elif t == 'line-break':
                buf.append('\n')
            elif t == 'annotation':
                pass
            else:
                buf.append(inline(ch))
            buf.append(ch.tail or '')
        return ''.join(buf)

    def walk(el):
        for ch in el:
            t = _local(ch.tag)
            if t in ('p', 'h'):
                paras.append(inline(ch))
            else:
                walk(ch)
    walk(root)
    return '\n'.join(_clean_paras(paras))


# ---- epub -----------------------------------------------------------------
class _HTMLText(HTMLParser):
    BLOCK = {'p', 'div', 'br', 'li', 'ul', 'ol', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'table',
             'section', 'article', 'blockquote', 'pre', 'hr', 'body', 'aside', 'header', 'footer',
             'dd', 'dt', 'dl', 'figure', 'figcaption', 'td', 'th'}
    SKIP = {'script', 'style', 'nav', 'head', 'title', 'template'}

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.parts.append('\0')

    def handle_startendtag(self, tag, attrs):
        tag = tag.lower()
        if tag in self.BLOCK and not self.skip:
            self.parts.append('\0')

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
        elif tag in self.BLOCK:
            self.parts.append('\0')

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def _html_text(data):
    p = _HTMLText()
    try:
        p.feed(data.decode('utf-8', 'replace'))
        p.close()
    except Exception:
        pass
    segs = ''.join(p.parts).split('\0')
    out = []
    for s in segs:
        s = re.sub(r'\s+', ' ', s).strip()
        if s:
            out.append(s)
    return out


def _epub(zf):
    names = zf.namelist()
    chapters = []
    try:
        cont = _read(zf, 'META-INF/container.xml').decode('utf-8', 'replace')
        m = re.search(r'full-path\s*=\s*["\']([^"\']+)["\']', cont)
        if m:
            opf_path = m.group(1)
            opf = _read(zf, opf_path).decode('utf-8', 'replace')
            base = posixpath.dirname(opf_path)
            items = {}
            for im in re.finditer(r'<(?:\w+:)?item\b([^>]*)>', opf):
                attrs = dict((a.lower(), v) for a, _, v in re.findall(r'([\w:.-]+)\s*=\s*(["\'])(.*?)\2', im.group(1)))
                if 'id' in attrs and 'href' in attrs:
                    items[attrs['id']] = attrs
            for rm in re.finditer(r'<(?:\w+:)?itemref\b([^>]*)>', opf):
                mm = re.search(r'idref\s*=\s*["\']([^"\']+)["\']', rm.group(1))
                if not mm or mm.group(1) not in items:
                    continue
                it = items[mm.group(1)]
                if 'nav' in it.get('properties', '').split():
                    continue
                mt = it.get('media-type', '')
                href = it['href'].split('#')[0]
                if mt and 'html' not in mt and 'xml' not in mt:
                    continue
                full = posixpath.normpath(posixpath.join(base, href)) if base else posixpath.normpath(href)
                from urllib.parse import unquote
                for cand in (full, unquote(full)):
                    if cand in names:
                        chapters.append(cand)
                        break
    except Exception:
        chapters = []
    if not chapters:
        chapters = sorted(n for n in names if re.search(r'\.(?:xhtml|html|htm)$', n, re.I))
    out = []
    for n in chapters:
        out.extend(_html_text(_read(zf, n)))
    return '\n'.join(out)


def _notebook(data):
    try:
        nb = json.loads(decode_bytes(data))
    except Exception:
        return ''
    if not isinstance(nb, dict) or not isinstance(nb.get('cells'), list):
        return ''
    out = []
    for c in nb['cells']:
        if not isinstance(c, dict) or c.get('cell_type') != 'markdown':
            continue
        src = c.get('source')
        if isinstance(src, str):
            s = src
        elif isinstance(src, list) and all(isinstance(x, str) for x in src):
            s = ''.join(src)
        else:
            continue
        if s.strip():
            out.append(s.strip())
    return '\n'.join(out)


def extract_bytes(ext, data):
    """Return extracted text. Raises ReadError for unreadable archives."""
    ext = ext.lower()
    if ext in ('.pdf', '.rtf'):
        return ''
    if ext in NOTEBOOK_EXTS:
        return _notebook(data).strip()
    if ext in ZIP_EXTS:
        try:
            zf = zipfile.ZipFile(io.BytesIO(data))
        except Exception as e:
            raise ReadError('not a readable zip archive: %s' % e)
        try:
            if ext in ('.docx', '.docm'):
                t = _docx(zf)
            elif ext in ('.pptx', '.pptm'):
                t = _pptx(zf)
            elif ext in ('.xlsx', '.xlsm'):
                t = _xlsx(zf)
            elif ext in ('.odt', '.odp', '.ods'):
                t = _odf(zf)
            else:
                t = _epub(zf)
        except ReadError:
            raise
        except Exception as e:
            raise ReadError('archive could not be read: %s' % e)
        return t.strip()
    return decode_bytes(data)
