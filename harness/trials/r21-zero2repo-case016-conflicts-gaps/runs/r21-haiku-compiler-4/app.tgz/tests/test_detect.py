"""Tests for scripts/detect.py. Run: python3 -I -m unittest discover -s tests -v

Test names follow the spec's ids where a spec id is the natural anchor
(for example test_N_000305_... for the rescan-after-cleanup claim).
"""
import json
import os
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
DETECT = os.path.join(ROOT, 'scripts', 'detect.py')
sys.path.insert(0, os.path.join(ROOT, 'scripts'))
import detect  # noqa: E402


def run(args, stdin_text=None):
    p = subprocess.run([sys.executable, DETECT] + args,
                       input=(stdin_text or '').encode('utf-8'),
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return p.returncode, p.stdout.decode('utf-8'), p.stderr.decode('utf-8')


def report_for(text):
    return detect.scan(text)


class CliContract(unittest.TestCase):
    def test_help_first_line_and_exit_zero(self):
        code, out, _ = run(['--help'])
        self.assertEqual(code, 0)
        self.assertEqual(out.splitlines()[0], 'usage: detect.py [--clean] [--ci] [--] [FILE]')

    def test_empty_stdin_is_empty_input(self):
        code, out, err = run([], '   \n')
        self.assertEqual(code, 1)
        self.assertEqual(out, '')
        self.assertEqual(json.loads(err.strip().splitlines()[-1]), {'error': 'empty input'})

    def test_unknown_option_exit_two(self):
        code, out, err = run(['--nope'])
        self.assertEqual(code, 2)
        last = json.loads(err.strip().splitlines()[-1])['error']
        self.assertIn('unknown option', last)
        self.assertIn('--nope', last)
        self.assertIn('--help', last)

    def test_double_dash_allows_dash_file_name(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, '-dash.md')
            with open(path, 'w', encoding='utf-8') as fh:
                fh.write('A plain paragraph with enough ordinary words to be read as prose here.\n')
            code, out, _ = run(['--', path])
            self.assertEqual(code, 0)
            self.assertIn('_metrics', json.loads(out))

    def test_missing_file_is_cannot_read(self):
        code, _, err = run(['/nonexistent/none.md'])
        self.assertEqual(code, 1)
        self.assertTrue(json.loads(err.strip().splitlines()[-1])['error'].startswith('cannot read input:'))

    def test_two_files_scan_first_with_notice(self):
        with tempfile.TemporaryDirectory() as d:
            a = os.path.join(d, 'a.md')
            b = os.path.join(d, 'b.md')
            for p in (a, b):
                with open(p, 'w', encoding='utf-8') as fh:
                    fh.write('Plain text here.\n')
            code, out, err = run([a, b])
            self.assertEqual(code, 0)
            self.assertIn(a, err)
            json.loads(out)

    def test_pdf_has_no_text(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'x.pdf')
            with open(p, 'wb') as fh:
                fh.write(b'%PDF-1.4')
            code, _, _ = run([p])
            self.assertEqual(code, 1)

    def test_clean_prints_text_not_json(self):
        code, out, _ = run(['--clean'], 'Hello world  \n\n\n')
        self.assertEqual(code, 0)
        self.assertEqual(out, 'Hello world\n'.replace(' ', ' '))

    def test_ci_interval_present_only_with_flag(self):
        text = ('This is a sentence. ' * 10) + 'Another one here.'
        _, out_plain, _ = run([], text)
        self.assertNotIn('score_ci', json.loads(out_plain)['_metrics'])
        _, out_ci, _ = run(['--ci'], text)
        self.assertIn('score_ci', json.loads(out_ci)['_metrics'])


class Report(unittest.TestCase):
    def test_report_members_and_bands(self):
        rep = report_for('Plain writing with a few words. It stays simple and direct for the reader here. Done now.')
        m = rep['_metrics']
        for key in ('scanned_chars', 'truncated', 'ai_tell_score', 'ai_tell_band', 'confidence',
                    'confidence_reason', 'patterns_flagged', 'invisible_chars', 'nonstandard_spaces',
                    'homoglyphs'):
            self.assertIn(key, m)
        self.assertIn(m['ai_tell_band'], ['clean', 'light tells', 'mixed', 'heavy tells', 'pervasive tells'])

    def test_band_ranges(self):
        self.assertEqual(detect.band_of(0), 'clean')
        self.assertEqual(detect.band_of(20), 'clean')
        self.assertEqual(detect.band_of(21), 'light tells')
        self.assertEqual(detect.band_of(41), 'mixed')
        self.assertEqual(detect.band_of(61), 'heavy tells')
        self.assertEqual(detect.band_of(81), 'pervasive tells')

    def test_single_score_moving_family_capped_at_forty(self):
        self.assertLessEqual(detect.score_of({1}, set(), 500, detect.confidence_of(500, 1)[0]), 40)

    def test_two_decisive_families_floor_sixty_five(self):
        self.assertGreaterEqual(detect.score_of({62, 66}, {62, 66}, 500, 'high'), 65)

    def test_single_decisive_needs_confidence_above_low(self):
        self.assertEqual(detect.score_of({47}, {47}, 50, 'low'), 14)
        self.assertGreaterEqual(detect.score_of({47}, {47}, 400, 'high'), 45)

    def test_nine_no_detector_numbers_never_appear(self):
        text = ('The rule of three, a model is a rule of three, and it features a real example. '
                'Nested inside: tapestry, tapestry. Sentence after sentence to make it long enough. ') * 3
        rep = report_for(text)
        for key in rep:
            if key == '_metrics':
                continue
            number = int(key.split('_', 1)[0])
            self.assertNotIn(number, detect.NO_DETECTOR)

    def test_catalogue_numbers_and_labels_unique(self):
        labels = [v[1] for v in detect.LABELS.values()] + [detect.LABELS_17P[1], detect.LABELS_17T[1]]
        self.assertEqual(len(labels), len(set(labels)))
        # 62 machine-checked numbers: 61 keyed by LABELS plus catalogue 17 in two forms
        self.assertEqual(len(detect.LABELS), 61)
        self.assertEqual(len(detect.NO_DETECTOR), 9)

    def test_AC_4_7_fenced_code_generates_no_findings(self):
        text = 'Intro sentence here.\n\n```\ndelve tapestry robust\n```\n\nEnd sentence here.'
        rep = report_for(text)
        self.assertFalse([k for k in rep if k.startswith('1_')])


class CharacterLayer(unittest.TestCase):
    def test_N_000305_rescan_after_cleanup_has_no_invisible(self):
        dirty = 'a​b‌c­x️ text here now\n'
        cleaned = detect.clean_text(dirty)
        cl = detect.char_layer(cleaned)
        self.assertEqual(cl['invisible'], [])
        self.assertEqual(cl['nonstandard'], [])

    def test_N_000309_cleanup_folds_mixed_script_lookalike_word(self):
        mixed = 'We wrote Сomputer tools.'  # Cyrillic С in an otherwise Latin word
        self.assertIn('Computer', detect.clean_text(mixed))
        self.assertEqual(detect.char_layer(detect.clean_text(mixed))['homoglyph_runs'], [])

    def test_whole_cyrillic_word_is_not_folded(self):
        text = 'Это простой текст на русском языке.'
        self.assertEqual(detect.clean_text(text), text)

    def test_nbsp_between_digits_is_kept(self):
        text = '10 000 items'
        self.assertIn(' ', detect.clean_text(text))

    def test_char_after_window_not_counted(self):
        text = ('x' * detect.WINDOW) + '​'
        rep = detect.scan(text)
        self.assertEqual(rep['_metrics']['invisible_chars'], 0)
        self.assertTrue(rep['_metrics']['truncated'])

    def test_utm_only_ai_hosts_count(self):
        rep = report_for('See the link https://x.example/?utm_source=google for more detail here today.')
        self.assertFalse([k for k in rep if k.startswith('65_')])
        rep2 = report_for('See https://x.example/?utm_source=chatgpt.com for more detail here today.')
        self.assertTrue([k for k in rep2 if k.startswith('65_')])

    def test_trailing_whitespace_fires_advice_not_score(self):
        rep = report_for('A line with spaces at the end.   \nAnother line here.\n')
        keys = [k for k in rep if k.startswith('68_')]
        self.assertTrue(keys)
        self.assertIn(68, detect.ADVICE)


class Extraction(unittest.TestCase):
    def test_utf16_bom_decoded(self):
        data = 'Hello there.'.encode('utf-16')  # includes BOM
        self.assertEqual(detect.decode_plain(data), 'Hello there.')

    def test_utf8_bom_stripped(self):
        self.assertEqual(detect.decode_plain(b'\xef\xbb\xbfHi'), 'Hi')

    def test_notebook_only_markdown_cells(self):
        nb = json.dumps({'cells': [
            {'cell_type': 'markdown', 'source': ['# T\n', 'Body.']},
            {'cell_type': 'code', 'source': ['print("secret code")']},
        ]}).encode('utf-8')
        self.assertEqual(detect._notebook_text(nb), '# T\nBody.')


if __name__ == '__main__':
    unittest.main()
