'use strict';
// Shared logic for the prosecheck plugin hooks. Node.js standard library only.
// spec: N-000064..N-000070 (no network client, local ledgers), FP-04, FP-05, FP-06.

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const WINDOW = 262144;
const WINDOW_TEXT = '262,144';
const TEXT_CAP_BYTES = 512 * 1024; // plain text: 524,288 bytes
const ARCHIVE_CAP_BYTES = 4 * 1024 * 1024; // zip/notebook: 4,194,304 bytes
const TEXT_CAP_KB = 512;
const ARCHIVE_CAP_KB = 4096;
const LEDGER_MAX = 50; // newest records kept per ledger (interface contract)
const LEDGER_MAX_AGE_MS = 7 * 24 * 60 * 60 * 1000; // PRD: seven days
const GUARD_LABEL_CAP = 5;
const CHECK_LABEL_CAP = 8;
const SHOW_LABEL_CAP = 5;
const MAX_GUARD_PATHS = 10;
const TEXT_TIMEOUT_MS = 8000;
const ARCHIVE_TIMEOUT_MS = 15000;
const STATS_SLICE_CHARS = 40000;
const STATS_MIN_PROSE = 200;

const MODES = ['lite', 'full', 'strict', 'off'];
const SUBCOMMANDS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];
const THRESHOLD = { full: 40, strict: 20 };
const FLAG_FILE = '.prosecheck-active';
const LEDGER_PREFIX = '.prosecheck-ledger';
const CONTRACT_MARK = '<!-- prosecheck-contract:start -->';
const CONTRACT_END = '<!-- prosecheck-contract:end -->';

const PLAIN_EXTS = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ZIP_EXTS = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'];
const NOTEBOOK_EXTS = ['.ipynb'];
const NO_TEXT_EXTS = ['.pdf', '.rtf'];
const PROSE_EXTS = PLAIN_EXTS.concat(ZIP_EXTS, NOTEBOOK_EXTS);
const INSTRUCTION_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];

const BANDS = [
  [20, 'clean', 'reads clean'],
  [40, 'light tells', 'reads mostly clean'],
  [60, 'mixed', 'reads with some AI tells'],
  [80, 'heavy tells', 'reads with heavy AI tells'],
  [100, 'pervasive tells', 'reads with pervasive AI tells'],
];

function bandPhrase(band) {
  for (const row of BANDS) if (row[1] === band) return row[2];
  return 'reads with some AI tells';
}

function phraseForScore(score) {
  for (const row of BANDS) if (score <= row[0]) return { band: row[1], phrase: row[2] };
  return { band: 'pervasive tells', phrase: 'reads with pervasive AI tells' };
}

// ------------------------------------------------------------------ input

function readStdinJson() {
  let raw = '';
  try {
    raw = fs.readFileSync(0, 'utf8');
  } catch (e) {
    raw = '';
  }
  if (!raw || !raw.trim()) return {};
  try {
    const v = JSON.parse(raw);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : {};
  } catch (e) {
    return {};
  }
}

// ----------------------------------------------------------------- config

function configDir() {
  const d = process.env.CLAUDE_CONFIG_DIR;
  return d && d.trim() ? d : path.join(os.homedir(), '.claude');
}

function pluginRoot() {
  const r = process.env.CLAUDE_PLUGIN_ROOT;
  if (r && r.trim()) return r;
  return path.resolve(__dirname, '..');
}

function detectorPath() {
  const root = pluginRoot();
  const candidates = [
    path.join(root, 'scripts', 'detect.py'),
    path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py'),
  ];
  for (const c of candidates) {
    try {
      if (fs.statSync(c).isFile()) return c;
    } catch (e) {
      // try next
    }
  }
  return null;
}

function flagPath() {
  return path.join(configDir(), FLAG_FILE);
}

function flagExists() {
  try {
    return fs.statSync(flagPath()).isFile();
  } catch (e) {
    return false;
  }
}

function storedMode() {
  try {
    const word = fs.readFileSync(flagPath(), 'utf8').trim();
    return MODES.includes(word) ? word : null;
  } catch (e) {
    return null;
  }
}

function envMode() {
  const w = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  return MODES.includes(w) ? w : null;
}

// Effective level: the environment word wins when valid; otherwise the stored
// word; otherwise 'full'.
function effectiveMode() {
  return envMode() || storedMode() || 'full';
}

function writeMode(word) {
  fs.mkdirSync(configDir(), { recursive: true });
  fs.writeFileSync(flagPath(), word);
}

// ------------------------------------------------------------- processes

function runDetector(args, input, timeoutMs) {
  const det = detectorPath();
  if (!det) return { missing: true };
  for (const py of ['python3', 'python', 'py']) {
    const r = spawnSync(py, [det].concat(args), {
      input: input === undefined ? '' : input,
      encoding: 'utf8',
      timeout: timeoutMs,
      maxBuffer: 64 * 1024 * 1024,
      windowsHide: true,
      env: process.env,
    });
    if (r.error && r.error.code === 'ENOENT') continue;
    if (r.error && r.error.code === 'ETIMEDOUT') return { timedOut: true };
    if (r.error) return { error: r.error };
    return { status: r.status, signal: r.signal, stdout: r.stdout || '', stderr: r.stderr || '' };
  }
  return { pythonMissing: true };
}

function lastErrorLine(stderr) {
  const lines = String(stderr || '').split('\n').map((l) => l.trim()).filter(Boolean);
  for (let i = lines.length - 1; i >= 0; i--) {
    try {
      const o = JSON.parse(lines[i]);
      if (o && typeof o.error === 'string') return o.error;
    } catch (e) {
      // not JSON
    }
  }
  return lines.length ? lines[lines.length - 1] : '';
}

// Score one file. Returns { ok: true, report } or { ok: false, reason }.
// Reasons stay distinguishable: Python not found; timeout; not a report;
// report without a numeric score; no output; exit failure.
function scoreFile(file, timeoutMs) {
  const r = runDetector(['--', file], undefined, timeoutMs);
  if (r.missing) return { ok: false, code: 'detector-missing', reason: 'detector missing from the plugin tree' };
  if (r.pythonMissing) return { ok: false, code: 'python-missing', reason: 'Python not found' };
  if (r.timedOut) return { ok: false, code: 'timeout', reason: 'detector timed out' };
  if (r.error) return { ok: false, code: 'no-result', reason: 'detector produced no usable result' };
  if (r.status === 0) {
    const out = r.stdout.trim();
    if (!out) return { ok: false, code: 'no-output', reason: 'detector produced no output' };
    let report;
    try {
      report = JSON.parse(out);
    } catch (e) {
      return { ok: false, code: 'not-report', reason: 'detector output was not a report' };
    }
    const m = report && report._metrics;
    if (!m || typeof m.ai_tell_score !== 'number' || !Number.isFinite(m.ai_tell_score)) {
      return { ok: false, code: 'no-score', reason: 'report had no numeric score' };
    }
    return { ok: true, report };
  }
  const detail = lastErrorLine(r.stderr);
  return { ok: false, code: 'exit', reason: 'detector failed' + (detail ? ': ' + detail : ' (exit ' + r.status + ')'), stderr: detail };
}

// Turn a report into the list of finding labels, in report order.
function findingLabels(report) {
  const out = [];
  for (const key of Object.keys(report)) {
    if (key === '_metrics') continue;
    const f = report[key];
    if (f && typeof f.label === 'string') out.push({ label: f.label, count: f.count || 0 });
  }
  return out;
}

// ------------------------------------------------------------- inspection

function extOf(p) {
  const ext = path.extname(p).toLowerCase();
  return ext;
}

function isArchiveOrNotebook(ext) {
  return ZIP_EXTS.includes(ext) || NOTEBOOK_EXTS.includes(ext);
}

// Returns { kind, size, cap } for a path. kind: missing | dir | notfile | binary | over | file
function inspectTarget(p) {
  let st;
  try {
    st = fs.statSync(p);
  } catch (e) {
    return { kind: 'missing' };
  }
  if (st.isDirectory()) return { kind: 'dir' };
  if (!st.isFile()) return { kind: 'notfile' };
  const ext = extOf(p);
  if (NO_TEXT_EXTS.includes(ext)) return { kind: 'binary', ext };
  const archive = isArchiveOrNotebook(ext);
  const cap = archive ? ARCHIVE_CAP_BYTES : TEXT_CAP_BYTES;
  if (st.size > cap) {
    return { kind: 'over', size: st.size, cap, capKb: archive ? ARCHIVE_CAP_KB : TEXT_CAP_KB, archive };
  }
  return { kind: 'file', size: st.size, cap, archive, ext };
}

// ----------------------------------------------------------------- ledger

function ledgerName(sid) {
  if (!sid) return LEDGER_PREFIX;
  const safe = String(sid).replace(/[^A-Za-z0-9_]/g, '_').slice(0, 120);
  return LEDGER_PREFIX + '-' + safe;
}

function ledgerPath(sid) {
  return path.join(configDir(), ledgerName(sid));
}

function readLedger(sid) {
  try {
    const arr = JSON.parse(fs.readFileSync(ledgerPath(sid), 'utf8'));
    return Array.isArray(arr) ? arr : [];
  } catch (e) {
    return [];
  }
}

function appendLedger(sid, record) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    const arr = readLedger(sid);
    arr.unshift(Object.assign({ time: new Date().toISOString() }, record));
    const kept = arr.slice(0, LEDGER_MAX);
    fs.writeFileSync(ledgerPath(sid), JSON.stringify(kept, null, 1));
  } catch (e) {
    // a ledger write failure must not fail the host
  }
}

// Delete ledgers that are older than the age limit (run at session start).
function pruneLedgers() {
  let names = [];
  try {
    names = fs.readdirSync(configDir());
  } catch (e) {
    return;
  }
  const now = Date.now();
  for (const n of names) {
    if (n !== LEDGER_PREFIX && !n.startsWith(LEDGER_PREFIX + '-')) continue;
    const full = path.join(configDir(), n);
    try {
      const st = fs.statSync(full);
      if (now - st.mtimeMs > LEDGER_MAX_AGE_MS) fs.unlinkSync(full);
    } catch (e) {
      // ignore
    }
  }
}

function ledgerIsFresh(sid) {
  try {
    const st = fs.statSync(ledgerPath(sid));
    return Date.now() - st.mtimeMs <= LEDGER_MAX_AGE_MS;
  } catch (e) {
    return false;
  }
}

// ---------------------------------------------------------------- contract

const BANNED = [
  'delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster',
  'underscore', 'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic',
  'testament', 'vibrant', 'comprehensive', 'plethora', 'myriad', 'boast', 'elevate',
  'empower', 'unlock', 'game-changer', 'supercharge', 'genuinely', 'fascinating', 'nuanced',
];

function contractBody(level, opts) {
  const det = opts.live ? opts.detector : null;
  const lines = [];
  lines.push('# Writing contract (prose deliverables)');
  lines.push('');
  lines.push('This contract governs prose deliverables only: documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and drafted text the user will publish or send.');
  lines.push('It never applies to source code, code comments, commit messages, JSON, YAML, or other config, CLI output, logs, error messages, or the conversational register of chat.');
  lines.push('It composes with other modes: a chat-compression mode owns chat, a code-simplicity mode owns code, and this contract owns deliverable prose.');
  lines.push('');
  lines.push('Rules for deliverable prose:');
  lines.push('- Vary sentence length irregularly. No metronome and no mechanical short-long alternation.');
  lines.push('- Banned vocabulary: ' + BANNED.join(', ') + '.');
  lines.push('- Banned moves: rule-of-three flourishes; "it is not just X, it is Y" framings; hedge stacking; signposting such as "let us dive in"; empty pivots such as "it is worth noting"; "In conclusion" or "Overall" closers; outcome-speculation tails; self-thoroughness phrases; generic upbeat endings; chatbot phrases such as "I hope this helps".');
  lines.push('- Use at most one em dash per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.');
  lines.push('- Factual or encyclopedic content stays neutral and third person. First-person or opinion content may use contractions.');
  lines.push('- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.');
  lines.push('- End sections on a fact or an observation.');
  lines.push('- Stay silent about this contract: never announce it, never name prosecheck, never report a score, a band, a pattern list, or a rewrite pass, and never offer a style choice.');
  if (level === 'full' || level === 'strict') {
    lines.push('');
    lines.push('Verification after saving a prose file:');
    if (opts.portable) {
      lines.push('- Run the bundled detector on the saved file. When CLAUDE_PLUGIN_ROOT is set, use the scripts/detect.py file under it; otherwise locate scripts/detect.py inside the installed skills or plugins folder.');
    } else {
      lines.push('- Run the bundled detector on the saved file: python3 ' + (det || 'scripts/detect.py') + ' <file>');
    }
    if (level === 'full') {
      lines.push('- Target: score at most 40, band clean or light tells. If the band is worse than the target, fix the flagged spans. Make at most two fix passes, keep the rhythm variation, and do not flatten sentence length.');
    } else {
      lines.push('- Target: score at most 20, band clean. If the band is worse than the target, fix the flagged spans. Make at most two fix passes, keep the rhythm variation, and do not flatten sentence length.');
      if (opts.portable) {
        lines.push('- When the prose is final, finish it with the cleanup switch --clean, as described above.');
      } else {
        lines.push('- When the prose is final, finish it with the cleanup switch: python3 ' + (det || 'scripts/detect.py') + ' --clean <file> > scrubbed.txt, then review the result.');
      }
    }
  }
  return lines.join('\n');
}

function contractText(level, opts) {
  opts = opts || {};
  return contractBody(level, { live: opts.live !== false, detector: opts.detector, portable: !!opts.portable });
}

function welcomeText() {
  return [
    'prosecheck is installed and on.',
    'Saved prose is scored against 71 documented patterns. Plain text is accepted up to 512 KB and archives up to 4 MB.',
    'The detector scores the first ' + WINDOW_TEXT + ' characters of extracted prose.',
    'Useful commands: /prosecheck doctor, /prosecheck check <file>, /prosecheck off, /prosecheck help.',
    'There is no website and no upload; nothing you write leaves this machine.',
    'This welcome is shown once.',
  ].join('\n');
}

function reminderText(level) {
  return 'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.';
}

// --------------------------------------------------------------- transcripts

function newestTranscript(root) {
  let best = null;
  const walk = (dir, depth) => {
    if (depth > 6) return;
    let entries = [];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (e) {
      return;
    }
    for (const ent of entries) {
      const full = path.join(dir, ent.name);
      if (ent.isDirectory()) walk(full, depth + 1);
      else if (ent.isFile() && ent.name.endsWith('.jsonl')) {
        try {
          const st = fs.statSync(full);
          if (!best || st.mtimeMs > best.mtime) best = { file: full, mtime: st.mtimeMs };
        } catch (e) {
          // ignore
        }
      }
    }
  };
  walk(root, 0);
  return best ? best.file : null;
}

function statsReply(transcriptPath, level) {
  const lines = ['level: ' + level];
  let file = null;
  if (transcriptPath && typeof transcriptPath === 'string') {
    try {
      if (fs.statSync(transcriptPath).isFile()) file = transcriptPath;
    } catch (e) {
      file = null;
    }
  }
  if (!file) file = newestTranscript(path.join(configDir(), 'projects'));
  let raw = null;
  if (file) {
    try {
      raw = fs.readFileSync(file, 'utf8');
    } catch (e) {
      raw = null;
    }
  }
  if (raw === null) {
    lines.push('No readable transcript was found for this session, so no token figures are shown.');
    return lines.join('\n');
  }
  const seen = new Set();
  let turns = 0;
  let outTokens = 0;
  let cacheTokens = 0;
  const texts = [];
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    let row;
    try {
      row = JSON.parse(line);
    } catch (e) {
      continue;
    }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const id = typeof msg.id === 'string' ? msg.id : null;
    if (id) {
      if (seen.has(id)) {
        // same message split over rows: take its text only once
      } else {
        seen.add(id);
        turns += 1;
        const u = msg.usage || {};
        outTokens += Number(u.output_tokens) || 0;
        cacheTokens += Number(u.cache_read_input_tokens) || 0;
      }
    } else {
      turns += 1;
      const u = msg.usage || {};
      outTokens += Number(u.output_tokens) || 0;
      cacheTokens += Number(u.cache_read_input_tokens) || 0;
    }
    if (Array.isArray(msg.content)) {
      for (const c of msg.content) {
        if (c && c.type === 'text' && typeof c.text === 'string') texts.push(c.text);
      }
    }
  }
  lines.push('assistant turns: ' + turns);
  lines.push('output tokens: ' + outTokens.toLocaleString('en-US', { useGrouping: false }));
  lines.push('cache-read input tokens: ' + cacheTokens.toLocaleString('en-US', { useGrouping: false }));
  let prose = texts.join('\n');
  prose = prose.replace(/```[\s\S]*?```/g, '').replace(/~~~[\s\S]*?~~~/g, '');
  prose = prose.slice(-STATS_SLICE_CHARS).trim();
  if (prose.length > STATS_MIN_PROSE) {
    const r = runDetector([], prose, TEXT_TIMEOUT_MS);
    if (r.status === 0) {
      try {
        const rep = JSON.parse(r.stdout);
        if (rep && rep._metrics && typeof rep._metrics.ai_tell_score === 'number') {
          lines.push('session prose ai_tell_score: ' + rep._metrics.ai_tell_score);
        }
      } catch (e) {
        // no score line
      }
    }
  }
  return lines.join('\n');
}

module.exports = {
  WINDOW, WINDOW_TEXT, TEXT_CAP_KB, ARCHIVE_CAP_KB, GUARD_LABEL_CAP, CHECK_LABEL_CAP, SHOW_LABEL_CAP,
  MAX_GUARD_PATHS, TEXT_TIMEOUT_MS, ARCHIVE_TIMEOUT_MS, MODES, SUBCOMMANDS, THRESHOLD, CONTRACT_MARK,
  CONTRACT_END, PLAIN_EXTS, ZIP_EXTS, NOTEBOOK_EXTS, NO_TEXT_EXTS, PROSE_EXTS, INSTRUCTION_STEMS,
  readStdinJson, configDir, pluginRoot, detectorPath, flagExists, storedMode, envMode, effectiveMode,
  writeMode, runDetector, scoreFile, findingLabels, inspectTarget, extOf, isArchiveOrNotebook,
  readLedger, appendLedger, pruneLedgers, ledgerIsFresh, ledgerPath, contractText, welcomeText,
  reminderText, statsReply, phraseForScore, bandPhrase, lastErrorLine, BANNED,
};
