#!/usr/bin/env node
'use strict';
// SubagentStart hook: returns the same writing contract inside the envelope.
// spec: FP-04, interface prosecheck-subagent.js.
const lib = require('./prosecheck-lib');

function main() {
  lib.readStdinJson();
  const level = lib.effectiveMode();
  if (level === 'off') return;
  const detector = lib.detectorPath() || 'scripts/detect.py';
  const payload = {
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: lib.contractText(level, { live: true, detector }),
    },
  };
  process.stdout.write(JSON.stringify(payload) + '\n');
}

try {
  main();
} catch (e) {
  // never fail the host
}
process.exitCode = 0;
