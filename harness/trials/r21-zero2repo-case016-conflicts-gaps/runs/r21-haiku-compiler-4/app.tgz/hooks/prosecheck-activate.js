#!/usr/bin/env node
'use strict';
// SessionStart hook: writes the writing contract (and a one-time welcome on a
// fresh install) as plain text. spec: FP-04, interface prosecheck-activate.js.
const lib = require('./prosecheck-lib');

function main() {
  lib.readStdinJson();
  const firstStart = !lib.flagExists();
  if (firstStart) {
    try {
      lib.writeMode(lib.effectiveMode());
    } catch (e) {
      // settings folder not writable: keep going with the effective level
    }
  }
  lib.pruneLedgers();
  const level = lib.effectiveMode();
  if (level === 'off') return;
  const detector = lib.detectorPath() || 'scripts/detect.py';
  let out = '';
  if (firstStart) out += lib.welcomeText() + '\n\n';
  out += lib.contractText(level, { live: true, detector });
  process.stdout.write(out + '\n');
}

try {
  main();
} catch (e) {
  // a hook must never fail the host session
}
process.exitCode = 0;
