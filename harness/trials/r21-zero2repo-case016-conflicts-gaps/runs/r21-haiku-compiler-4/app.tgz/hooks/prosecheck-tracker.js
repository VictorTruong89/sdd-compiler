#!/usr/bin/env node
'use strict';
// UserPromptSubmit hook and /prosecheck command router.
// spec: FP-04 (reminder), FP-06 (commands), interface prosecheck-tracker.js.
const lib = require('./prosecheck-lib');
const { route } = require('./prosecheck-commands');

function main() {
  const input = lib.readStdinJson();
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const sid = typeof input.session_id === 'string' ? input.session_id : '';
  const transcriptPath = typeof input.transcript_path === 'string' ? input.transcript_path : null;
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const reply = route(prompt, sid, { transcriptPath, cwd });
  if (reply !== null) {
    process.stdout.write(JSON.stringify({ decision: 'block', reason: reply }) + '\n');
    return;
  }
  const level = lib.effectiveMode();
  if (level === 'off') return;
  const payload = {
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: lib.reminderText(level),
    },
  };
  process.stdout.write(JSON.stringify(payload) + '\n');
}

try {
  main();
} catch (e) {
  // never fail the host
}
process.exitCode = 0;
