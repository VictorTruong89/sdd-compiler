'use strict';
// The /prosecheck command router (used by prosecheck-tracker.js).
// spec: FP-06, interface "/prosecheck" entry. Replies are returned as text.

const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib');

const WINDOW_TEXT = lib.WINDOW_TEXT;

function commandForm(typed) {
  return typed.includes(':prosecheck') ? '/prosecheck:prosecheck' : '/prosecheck';
}

function helpReply(level) {
  const lines = [];
  lines.push('prosecheck help: current level is ' + level + '.');
  lines.push('Code, commits, config, and chat are never touched. Use the contract for deliverable prose only.');
  lines.push('/prosecheck lite - turns on the writing contract without scoring saved files.');
  lines.push('/prosecheck full - adds the writing contract and the saved-file guard with its threshold of 40 (default).');
  lines.push('/prosecheck strict - lowers the guard threshold to 20 and adds the cleanup scrub.');
  lines.push('/prosecheck off | on - off: disable the tool; on: re-enable it at full.');
  lines.push('/prosecheck status - reports the current level in one line.');
  lines.push('/prosecheck show - lists the files this session scored, skipped, or failed.');
  lines.push('/prosecheck check <file> - score one file (score, band, tells); it does not rewrite the file.');
  lines.push('/prosecheck doctor - health check of the install: mode, detector, Python, settings.');
  lines.push('/prosecheck stats - session token figures and the score of the session prose.');
  lines.push('/prosecheck init - exports the contract to AGENTS.md for agents other than Claude Code.');
  lines.push('For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".');
  return lines.join('\n');
}

function unknownReply(word) {
  return 'Unknown word "' + word + '". Valid words: ' + lib.SUBCOMMANDS.join(', ') + '.';
}

function cleanArgPath(arg) {
  let p = String(arg || '').trim();
  if (p.startsWith('@')) p = p.slice(1);
  if ((p.startsWith('"') && p.endsWith('"') && p.length >= 2) || (p.startsWith("'") && p.endsWith("'") && p.length >= 2)) {
    p = p.slice(1, -1);
  }
  return p;
}

function checkReply(arg) {
  const typed = cleanArgPath(arg);
  if (!typed) {
    return 'Usage: /prosecheck check <file>. Give the path of the file to score; the file is not rewritten.';
  }
  const abs = path.resolve(process.cwd(), typed);
  const base = path.basename(abs);
  const target = lib.inspectTarget(abs);
  switch (target.kind) {
    case 'missing':
      return 'cannot read ' + typed + ': the path does not exist.';
    case 'dir':
      return typed + ' is not a file.';
    case 'notfile':
      return typed + ' is not a file.';
    case 'binary':
      return base + ': no readable text in this format (' + target.ext + '), so nothing was scored.';
    case 'over':
      return base + ': over ' + target.capKb + ' KB, so it was not scored.';
    default:
      break;
  }
  const timeout = target.archive ? lib.ARCHIVE_TIMEOUT_MS : lib.TEXT_TIMEOUT_MS;
  const res = lib.scoreFile(abs, timeout);
  if (!res.ok) {
    if (res.code === 'python-missing' || res.code === 'detector-missing') {
      return base + ': detector unavailable (' + res.reason + '), so no score was produced.';
    }
    if (res.code === 'not-report' || res.code === 'no-output') {
      if (res.code === 'no-output') return base + ': no report was produced.';
      return 'no report: the detector returned text that is not a report.';
    }
    if (res.code === 'no-score') return 'no report: the detector returned a report without a score.';
    return base + ' failed to score: ' + (res.stderr || res.reason) + '.';
  }
  const rep = res.report;
  const m = rep._metrics;
  const phrase = lib.bandPhrase(m.ai_tell_band);
  const out = [];
  out.push(base + ' - ' + phrase + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')');
  let conf = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && m.confidence_reason) conf += ' - ' + m.confidence_reason;
  out.push(conf);
  if (m.truncated) out.push('coverage: first ' + WINDOW_TEXT + ' characters only');
  const labels = lib.findingLabels(rep);
  if (labels.length === 0) {
    out.push('tells: none');
  } else {
    const parts = labels.slice(0, lib.CHECK_LABEL_CAP).map((l) => l.label + ' (x' + l.count + ')');
    out.push('tells: ' + parts.join('; '));
  }
  out.push('This is a report only; the file was not changed.');
  return out.join('\n');
}

function doctorReply(form, level) {
  const lines = [];
  lines.push('prosecheck doctor');
  // mode
  if (level === 'off') {
    lines.push('mode: off - the tool is switched off. Run /prosecheck on to allow scoring.');
  } else {
    lines.push('[OK] mode: ' + level);
  }
  // detector
  const det = lib.detectorPath();
  if (det) lines.push('[OK] detector: bundled detector found at scripts/detect.py');
  else lines.push('[FAIL] detector: bundled detector not found in the plugin tree');
  // python
  const probe = lib.runDetector([], 'This is a short sample sentence for the doctor check.', lib.TEXT_TIMEOUT_MS);
  if (probe.pythonMissing) {
    lines.push('[FAIL] python: python not found; saved files are not re-scored until Python is available. The writing contract still applies to new prose.');
  } else if (probe.status === 0) {
    let good = false;
    try {
      const rep = JSON.parse(probe.stdout);
      good = rep && rep._metrics && typeof rep._metrics.ai_tell_score === 'number';
    } catch (e) {
      good = false;
    }
    if (good) lines.push('[OK] python: ran the bundled detector and got a numeric score');
    else lines.push('[FAIL] python: the bundled detector returned output that is not a numeric score');
  } else {
    lines.push('[FAIL] python: the bundled detector returned no numeric score (exit ' + probe.status + ')');
  }
  // settings
  const dir = lib.configDir();
  let writable = false;
  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.accessSync(dir, fs.constants.W_OK);
    writable = true;
  } catch (e) {
    writable = false;
  }
  lines.push(writable ? '[OK] settings: folder ' + dir + ' is writable' : '[FAIL] settings: folder ' + dir + ' is not writable');
  // closer
  const checks = lines.slice(1);
  const allOk = checks.every((l) => l.includes('[OK]'));
  const modeOnlyOff = level === 'off' && checks.slice(1).every((l) => l.includes('[OK]'));
  if (allOk && level !== 'off') {
    lines.push('All four checks passed and the tool is active. Plain text up to ' + lib.TEXT_CAP_KB + ' KB and archives up to 4 MB are scored, reading the first ' + WINDOW_TEXT + ' characters. Run ' + form + ' show to see files that were only partly scanned or skipped.');
  } else if (modeOnlyOff) {
    lines.push('The install is healthy. While the tool is off, saved files are not scored. Run ' + form + ' on to allow it.');
  } else {
    lines.push('Repair the faulty checks above: fix them, then run /prosecheck doctor again.');
  }
  return lines.join('\n');
}

function showReply(form, sid) {
  const rows = lib.readLedger(sid);
  if (!rows.length || !lib.ledgerIsFresh(sid)) {
    return 'nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const out = ['Session files, newest first:'];
  for (const r of rows) {
    if (r.status === 'scored') {
      let body = r.phrase + ' (score ' + r.score + '/' + r.band;
      if (r.truncated) body += ', first ' + WINDOW_TEXT + ' characters only';
      body += ')';
      if (r.labels && r.labels.length) {
        body += ' - ' + (r.flagged ? 'flagged' : 'under threshold') + ': ' + r.labels.slice(0, lib.SHOW_LABEL_CAP).join('; ');
      }
      out.push(r.base + ' - ' + body);
    } else if (r.status === 'skipped') {
      out.push(r.base + ' - not scored: over ' + r.capKb + ' KB limit.');
    } else if (r.status === 'binary') {
      out.push(r.base + ' - not re-scored (binary format).');
    } else {
      out.push(r.base + ' - not scored: ' + (r.reason || 'unknown reason'));
    }
  }
  return out.join('\n');
}

function initReply(form, level, cwd) {
  if (level === 'off') {
    return 'prosecheck is switched off, so nothing was written. Run ' + form + ' on to allow the export.';
  }
  const lines = [];
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = null;
  try {
    existing = fs.readFileSync(agents, 'utf8');
  } catch (e) {
    if (e.code === 'ENOENT') existing = '';
    else existing = undefined;
  }
  if (existing === undefined) {
    lines.push('cannot read AGENTS.md, so the contract was not written there.');
  } else if (existing.includes(lib.CONTRACT_MARK)) {
    lines.push('AGENTS.md already has the prosecheck contract; the file was not changed.');
  } else {
    const section = lib.CONTRACT_MARK + '\n' + lib.contractText(level, { live: false, portable: true }) + '\n' + lib.CONTRACT_END + '\n';
    const sep = existing.length ? (existing.endsWith('\n') ? '\n' : '\n\n') : '';
    try {
      fs.writeFileSync(agents, existing + sep + section);
      lines.push('Wrote the writing contract to AGENTS.md.');
    } catch (e) {
      lines.push('cannot write AGENTS.md; the contract was not written there.');
    }
  }
  // cursor rule
  const dest = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  let destExists = false;
  try {
    fs.statSync(dest);
    destExists = true;
  } catch (e) {
    destExists = false;
  }
  if (destExists) {
    lines.push('prosecheck.mdc already exists in .cursor/rules; it was not overwritten.');
  } else {
    try {
      const src = path.join(lib.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      let body = null;
      try {
        body = fs.readFileSync(src, 'utf8');
      } catch (e) {
        body = null;
      }
      if (body === null) throw new Error('shipped rule missing');
      fs.writeFileSync(dest, body);
      lines.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      lines.push('cannot write .cursor/rules/prosecheck.mdc; the rule was not created.');
    }
  }
  return lines.join('\n');
}

// Route a command prompt. Returns the reply text, or null when the prompt is
// not a /prosecheck command and not a stop phrase.
function route(prompt, sid, opts) {
  opts = opts || {};
  const text = String(prompt || '');
  const stop = /^\s*(stop prosecheck|prosecheck off)\s*$/i.exec(text);
  if (stop) {
    lib.writeMode('off');
    return 'prosecheck is switched off. Run /prosecheck on to turn it back on.';
  }
  const m = /^\s*\/prosecheck(?::prosecheck)?(?=\s|$)([\s\S]*)$/i.exec(text);
  if (!m) return null;
  const typedForm = /^\s*\/prosecheck:prosecheck/i.test(text) ? '/prosecheck:prosecheck' : '/prosecheck';
  const rest = m[1].trim();
  const level = lib.effectiveMode();
  if (!rest) return helpReply(level);
  const parts = rest.split(/\s+/);
  const sub = parts[0].toLowerCase();
  const arg = rest.slice(parts[0].length).trim();
  if (!lib.SUBCOMMANDS.includes(sub)) return unknownReply(parts[0]);

  switch (sub) {
    case 'lite':
    case 'full':
    case 'strict':
      lib.writeMode(sub);
      return 'prosecheck level set to ' + sub + '.';
    case 'off':
      lib.writeMode('off');
      return 'prosecheck is switched off. Run ' + typedForm + ' on to turn it back on.';
    case 'on':
      lib.writeMode('full');
      return 'prosecheck is on at level full.';
    case 'status':
      return 'Current level: ' + level + '.';
    case 'help':
      return helpReply(level);
    case 'show':
      return showReply(typedForm, sid);
    case 'check':
      return checkReply(arg);
    case 'doctor':
      return doctorReply(typedForm, level);
    case 'stats':
      return lib.statsReply(opts.transcriptPath, level);
    case 'init':
      return initReply(typedForm, level, opts.cwd || process.cwd());
    default:
      return helpReply(level);
  }
}

module.exports = { route, helpReply, commandForm, checkReply };
