#!/usr/bin/env node
'use strict';
// stats hook: prints the session token figures and own-prose score as a
// block reply. spec: FP-06 stats, interface "stats" and "transcript_path".
const lib = require('./prosecheck-lib');

function main() {
  const input = lib.readStdinJson();
  const transcriptPath = typeof input.transcript_path === 'string' ? input.transcript_path : null;
  const reply = lib.statsReply(transcriptPath, lib.effectiveMode());
  process.stdout.write(JSON.stringify({ decision: 'block', reason: reply }) + '\n');
}

try {
  main();
} catch (e) {
  // never fail the host
}
process.exitCode = 0;
