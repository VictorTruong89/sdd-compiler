#!/usr/bin/env node
'use strict';
// PostToolUse hook: scores just-saved prose files and nudges when flagged.
// spec: FP-05 (saved-file guard), interface prosecheck-guard.js and the
// post-tool-use reply. The process always exits 0.
const path = require('path');
const lib = require('./prosecheck-lib');

const INSTRUCTION_EXACT = new Set(['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md']);
const TIMEOUT_FOR = (archive) => (archive ? lib.ARCHIVE_TIMEOUT_MS : lib.TEXT_TIMEOUT_MS);

function patchPaths(command) {
  const out = [];
  for (const line of String(command || '').split('\n')) {
    const m = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/.exec(line);
    if (m) {
      const p = m[1].trim();
      if (p) out.push(p);
    }
  }
  return out;
}

function collectPaths(input) {
  const tool = typeof input.tool_name === 'string' ? input.tool_name : '';
  const ti = input.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  let raw = [];
  if (tool === 'apply_patch' || (typeof ti.command === 'string' && /^\*\*\* (?:Add File|Update File|Move to):/m.test(ti.command))) {
    raw = patchPaths(ti.command);
  } else {
    const p = typeof ti.file_path === 'string' ? ti.file_path : typeof ti.notebook_path === 'string' ? ti.notebook_path : null;
    if (p && p.trim()) raw = [p.trim()];
  }
  const seen = new Set();
  const unique = [];
  for (const p of raw) {
    if (!seen.has(p)) {
      seen.add(p);
      unique.push(p);
    }
  }
  return unique.slice(0, lib.MAX_GUARD_PATHS);
}

function isSkipped(abs) {
  const parts = abs.split(path.sep);
  if (parts.includes('node_modules') || parts.includes('.git')) return true;
  const root = path.resolve(lib.pluginRoot());
  const rel = path.relative(root, abs);
  if (rel && !rel.startsWith('..') && !path.isAbsolute(rel)) return true;
  const base = path.basename(abs).toLowerCase();
  if (INSTRUCTION_EXACT.has(base)) return true;
  const ext = lib.extOf(base);
  for (const stem of lib.INSTRUCTION_STEMS) {
    if (base.startsWith(stem + '.') && !lib.PROSE_EXTS.includes(ext) && !lib.NO_TEXT_EXTS.includes(ext)) {
      return true;
    }
  }
  return false;
}

function main() {
  const input = lib.readStdinJson();
  const level = lib.effectiveMode();
  if (level === 'off' || level === 'lite') return;
  const threshold = lib.THRESHOLD[level];
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const sid = typeof input.session_id === 'string' ? input.session_id : '';
  const lines = [];

  for (const raw of collectPaths(input)) {
    const abs = path.isAbsolute(raw) ? raw : path.resolve(cwd, raw);
    if (isSkipped(abs)) continue;
    const base = path.basename(abs);
    const ext = lib.extOf(base);
    const eligible = lib.PROSE_EXTS.includes(ext) || lib.NO_TEXT_EXTS.includes(ext);
    if (!eligible) continue;
    const target = lib.inspectTarget(abs);
    if (target.kind === 'dir' || target.kind === 'notfile') continue;
    if (target.kind === 'missing') {
      lib.appendLedger(sid, { base, status: 'failed', reason: 'cannot read the file (not on disk)' });
      continue;
    }
    if (target.kind === 'binary') {
      lib.appendLedger(sid, { base, status: 'binary' });
      continue;
    }
    if (target.kind === 'over') {
      lib.appendLedger(sid, { base, status: 'skipped', capKb: target.capKb });
      continue;
    }
    const res = lib.scoreFile(abs, TIMEOUT_FOR(target.archive));
    if (!res.ok) {
      lib.appendLedger(sid, { base, status: 'failed', reason: res.reason });
      continue;
    }
    const m = res.report._metrics;
    const flagged = m.ai_tell_score > threshold;
    const labels = lib.findingLabels(res.report).map((l) => l.label).slice(0, lib.GUARD_LABEL_CAP);
    lib.appendLedger(sid, {
      base,
      status: 'scored',
      score: m.ai_tell_score,
      band: m.ai_tell_band,
      phrase: lib.bandPhrase(m.ai_tell_band),
      labels,
      flagged,
      truncated: !!m.truncated,
    });
    if (flagged) {
      const coverage = m.truncated ? ', first ' + lib.WINDOW_TEXT + ' characters only' : '';
      const flaggedList = labels.length ? labels.join('; ') : 'none listed';
      lines.push(
        'prosecheck: ' + base + ' ' + lib.bandPhrase(m.ai_tell_band) + ' (score ' + m.ai_tell_score +
        ', band ' + m.ai_tell_band + coverage + '). Flagged: ' + flaggedList +
        '. Please fix the flagged spans.'
      );
    }
  }

  if (lines.length) {
    const payload = {
      hookSpecificOutput: {
        hookEventName: 'PostToolUse',
        additionalContext: lines.join('\n'),
      },
    };
    process.stdout.write(JSON.stringify(payload) + '\n');
  }
}

try {
  main();
} catch (e) {
  // never fail the host
}
process.exitCode = 0;
