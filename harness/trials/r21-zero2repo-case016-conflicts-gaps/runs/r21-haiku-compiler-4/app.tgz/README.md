# prosecheck

A local detector for AI-writing patterns, with a writing contract and a saved-file guard for coding agents.

prosecheck has two parts:

- `scripts/detect.py` is a Python standard-library command. It scores prose against 71 documented patterns (62 are machine-checked), reports findings and a 0–100 score with a band, and can print scrubbed text with `--clean`.
- `hooks/` holds Node.js plugin hooks. They place the writing contract in a session and into subagents, score prose files after a supported file-edit tool saves them, and implement the `/prosecheck` commands.

## Use

```sh
python3 scripts/detect.py notes.md          # JSON report
python3 scripts/detect.py --clean notes.md  # scrubbed text
python3 scripts/detect.py --help
```

Supported files: plain text (`.md`, `.mdx`, `.markdown`, `.txt`, `.text`, `.rst`, `.tex`, `.org`, `.adoc`, up to 512 KB), zip-based documents (`.docx`, `.docm`, `.pptx`, `.pptm`, `.xlsx`, `.xlsm`, `.odt`, `.odp`, `.ods`, `.epub`) and notebooks (`.ipynb`, up to 4 MB). Only the first 262,144 characters of extracted prose are scored.

In a coding agent, run `/prosecheck doctor` after install. A healthy install shows four successful checks. Other commands: `/prosecheck lite | full | strict | off | on`, `status`, `show`, `check <file>`, `stats`, `init`, `help`.

## Requirements

Python 3.9 or newer for the detector, and Node.js for the hooks. There is no package to install, no compiled extension, and no runtime third-party dependency.

## Privacy

Analysis is local. The runtime contains no network client and no telemetry. Nothing you write is uploaded, and there is no account. The plugin stores a one-word mode flag and a per-session ledger of base names and scores, in the Claude configuration folder.

## What a score means

A score, band, and hook phrase describe the writing in front of the detector. They are a triage heuristic, not a classifier of authorship. They do not show that a person or a model wrote a document, and they must not be used to accuse anyone. Scoring is English-prose oriented.

## Tests

```sh
python3 -I -m unittest discover -s tests -v
```

Implementation choices and spec disagreements are recorded in `NOTES.md`.
