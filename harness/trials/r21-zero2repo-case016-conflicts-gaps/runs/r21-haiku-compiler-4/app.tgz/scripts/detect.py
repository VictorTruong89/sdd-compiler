#!/usr/bin/env python3
"""prosecheck detector: a local, deterministic scanner for AI-writing patterns.

Usage:
    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
    python3 scripts/detect.py --help

Standard library only. No network, no model, no random component in the
default scan (the optional --ci interval uses a fixed seed).
"""
import bisect
import json
import math
import random
import re
import sys
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

# spec: N-000044, N-000094 (public entry of the detector command)
WINDOW = 262144                       # spec: N-000107 scan window, characters
PLAIN_EXTS = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXTS = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NOTEBOOK_EXTS = {'.ipynb'}
NO_TEXT_EXTS = {'.pdf', '.rtf'}      # spec: N-000086 binary, no extracted prose
PROSE_EXTS = PLAIN_EXTS | ZIP_EXTS | NOTEBOOK_EXTS
MAX_MEMBER_BYTES = 64 * 1024 * 1024  # archive-member cutoff (implementer's choice)

USAGE_FIRST = 'usage: detect.py [--clean] [--ci] [--] [FILE]'
USAGE = (
    USAGE_FIRST + '\n'
    'prosecheck detector. Scores the first 262,144 characters of prose.\n'
    '  FILE          a file to score (plain text, .docx, .epub, .ipynb, ...).\n'
    '                With no FILE, standard input is read.\n'
    '  --clean       print the scrubbed text instead of the JSON report.\n'
    '  --ci          add a low/high interval on the score (needs enough sentences).\n'
    '  --            end option parsing so FILE may begin with a dash.\n'
    '  -h, --help    print this usage message and exit 0.\n'
)


class ReadError(Exception):
    """Input cannot be read. Message is the reason after 'cannot read input:'."""


class EmptyInput(Exception):
    pass


# ---------------------------------------------------------------- extraction

def _local(tag):
    return tag.rsplit('}', 1)[-1] if isinstance(tag, str) else ''


def decode_plain(data):
    """Decode plain-text bytes: UTF-8 (optional BOM) or UTF-16 with a BOM."""
    if data[:2] in (b'\xff\xfe', b'\xfe\xff'):
        try:
            text = data.decode('utf-16')
        except UnicodeDecodeError:
            text = data.decode('utf-8', errors='replace')
    else:
        if data.startswith(b'\xef\xbb\xbf'):
            data = data[3:]
        try:
            text = data.decode('utf-8')
        except UnicodeDecodeError:
            text = data.decode('utf-8', errors='replace')
    if text.startswith('\ufeff'):
        text = text[1:]
    return text.replace('\r\n', '\n').replace('\r', '\n')


def _xml_root(raw):
    try:
        return ET.fromstring(raw)
    except ET.ParseError:
        # tolerate stray control characters or broken markup: strip what breaks the parser
        cleaned = re.sub(rb'[\x00-\x08\x0b\x0c\x0e-\x1f]', b'', raw)
        return ET.fromstring(cleaned)


def _members(zf, pattern):
    names = []
    for name in zf.namelist():
        m = re.fullmatch(pattern, name)
        if m:
            names.append((int(m.group(1)), name))
    return [n for _, n in sorted(names)]


def _read_member(zf, name):
    info = zf.getinfo(name)
    if info.file_size > MAX_MEMBER_BYTES:
        return b''
    return zf.read(name)


def _docx_text(zf):
    root = _xml_root(_read_member(zf, 'word/document.xml'))
    paras = []
    for p in root.iter():
        if _local(p.tag) != 'p':
            continue
        parts = []
        for el in p.iter():
            ln = _local(el.tag)
            if ln == 't' and el.text:
                parts.append(el.text)
            elif ln == 'tab':
                parts.append('\t')
            elif ln in ('br', 'cr'):
                parts.append('\n')
        paras.append(''.join(parts))
    return '\n'.join(paras)


def _pptx_text(zf):
    slides = []
    for name in _members(zf, r'ppt/slides/slide(\d+)\.xml'):
        root = _xml_root(_read_member(zf, name))
        paras = []
        for p in root.iter():
            if _local(p.tag) == 'p':
                paras.append(''.join(el.text or '' for el in p.iter() if _local(el.tag) == 't'))
        slides.append('\n'.join(paras))
    return '\n'.join(slides)


def _xlsx_text(zf):
    shared = []
    if 'xl/sharedStrings.xml' in zf.namelist():
        root = _xml_root(_read_member(zf, 'xl/sharedStrings.xml'))
        for si in root.iter():
            if _local(si.tag) == 'si':
                shared.append(''.join(el.text or '' for el in si.iter() if _local(el.tag) == 't'))
    sheets = []
    for name in _members(zf, r'xl/worksheets/sheet(\d+)\.xml'):
        root = _xml_root(_read_member(zf, name))
        cells = []
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            kind = c.get('t')
            text = None
            if kind == 's':
                v = None
                for el in c:
                    if _local(el.tag) == 'v':
                        v = el.text
                try:
                    idx = int(v)
                    if 0 <= idx < len(shared):
                        text = shared[idx]
                except (TypeError, ValueError):
                    text = None
            elif kind == 'inlineStr':
                text = ''.join(el.text or '' for el in c.iter() if _local(el.tag) == 't')
            elif kind == 'str':
                text = ''.join(el.text or '' for el in c if _local(el.tag) == 'v')
            if text:
                cells.append(text)
        sheets.append('\n'.join(cells))
    return '\n'.join(sheets)


def _odf_text(zf):
    root = _xml_root(_read_member(zf, 'content.xml'))
    body = None
    for el in root.iter():
        if _local(el.tag) == 'body':
            body = el
            break
    if body is None:
        return ''
    out = []

    def rec(el):
        ln = _local(el.tag)
        if ln == 's':
            count = 1
            for k, v in el.attrib.items():
                if _local(k) == 'c':
                    try:
                        count = int(v)
                    except ValueError:
                        count = 1
            out.append(' ' * max(count, 0))
        elif ln == 'tab':
            out.append('\t')
        elif ln == 'line-break':
            out.append('\n')
        else:
            if el.text:
                out.append(el.text)
            for ch in el:
                rec(ch)
                if ch.tail:
                    out.append(ch.tail)
        if ln in ('p', 'h'):
            out.append('\n')

    rec(body)
    return ''.join(out)


class _HTMLText(HTMLParser):
    SKIP = {'script', 'style', 'head', 'nav', 'title'}
    BLOCK = {'p', 'div', 'br', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'section',
             'article', 'blockquote', 'pre', 'ul', 'ol', 'table', 'header', 'footer', 'figure'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        if tag in self.BLOCK:
            self.parts.append('\n')

    def handle_endtag(self, tag):
        if tag in self.SKIP and self.skip:
            self.skip -= 1
        if tag in self.BLOCK:
            self.parts.append('\n')

    def handle_startendtag(self, tag, attrs):
        if tag in self.BLOCK:
            self.parts.append('\n')

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def _html_to_text(raw):
    parser = _HTMLText()
    try:
        parser.feed(raw.decode('utf-8', errors='replace'))
        parser.close()
    except Exception:  # tolerant: keep whatever was parsed
        pass
    lines = []
    for line in ''.join(parser.parts).split('\n'):
        line = re.sub(r'[ \t\f\v\r ]+', ' ', line).strip()
        lines.append(line)
    text = '\n'.join(lines)
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip('\n')


def _epub_text(zf):
    chapters = []
    names = sorted(n for n in zf.namelist()
                   if n.lower().endswith(('.xhtml', '.html', '.htm'))
                   and 'nav' not in n.lower().rsplit('/', 1)[-1])
    for name in names:
        chapters.append(_html_to_text(_read_member(zf, name)))
    return '\n\n'.join(c for c in chapters if c.strip())


def _notebook_text(raw_bytes):
    try:
        nb = json.loads(raw_bytes.decode('utf-8-sig', errors='replace'))
    except (ValueError, UnicodeDecodeError):
        return ''
    if not isinstance(nb, dict) or not isinstance(nb.get('cells'), list):
        return ''
    out = []
    for cell in nb['cells']:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source', '')
        if isinstance(src, list):
            if not all(isinstance(s, str) for s in src):
                return ''
            src = ''.join(src)
        elif not isinstance(src, str):
            return ''
        out.append(src)
    return '\n'.join(out).strip()


def extract_path(path):
    """Return the extracted prose of a file path (str)."""
    ext = ''
    dot = path.rfind('.')
    if dot > path.rfind('/') and dot >= 0:
        ext = path[dot:].lower()
    try:
        with open(path, 'rb') as fh:
            data = fh.read()
    except IsADirectoryError:
        raise ReadError('%s: is a directory' % path)
    except OSError as exc:
        raise ReadError('%s: %s' % (path, exc.strerror or exc))
    if ext in NO_TEXT_EXTS:
        return ''
    if ext in NOTEBOOK_EXTS:
        return _notebook_text(data)
    if ext in ZIP_EXTS:
        try:
            import io
            zf = zipfile.ZipFile(io.BytesIO(data))
        except (zipfile.BadZipFile, OSError):
            raise ReadError('%s: not a readable zip archive' % path)
        try:
            with zf:
                if ext in ('.docx', '.docm'):
                    text = _docx_text(zf)
                elif ext in ('.pptx', '.pptm'):
                    text = _pptx_text(zf)
                elif ext in ('.xlsx', '.xlsm'):
                    text = _xlsx_text(zf)
                elif ext == '.epub':
                    text = _epub_text(zf)
                else:
                    text = _odf_text(zf)
        except (ET.ParseError, KeyError, zipfile.BadZipFile, ValueError) as exc:
            raise ReadError('%s: unreadable document (%s)' % (path, exc.__class__.__name__))
        return text.strip()
    return decode_plain(data)


# ------------------------------------------------------------- character layer

def _is_pictographic(ch):
    o = ord(ch)
    return (0x1F000 <= o <= 0x1FAFF or 0x2600 <= o <= 0x27BF or o in (0x2B50, 0x2B55)
            or 0x1F1E6 <= o <= 0x1F1FF or 0x231A <= o <= 0x231B or 0x23E9 <= o <= 0x23F3)


def _is_cjk(ch):
    o = ord(ch)
    return (0x3400 <= o <= 0x4DBF or 0x4E00 <= o <= 0x9FFF or 0xF900 <= o <= 0xFAFF
            or 0x20000 <= o <= 0x2FA1F or 0x3005 <= o <= 0x3007)


def _is_kana(ch):
    return 0x3040 <= ord(ch) <= 0x30FF


def _is_nospace_script(ch):
    o = ord(ch)
    return (0x0E00 <= o <= 0x0EFF or 0x1000 <= o <= 0x109F or 0x1780 <= o <= 0x17FF
            or _is_kana(ch) or _is_cjk(ch))


def _is_joining_script(ch):
    o = ord(ch)
    return (0x0590 <= o <= 0x06FF or 0x0900 <= o <= 0x0DFF or 0x1000 <= o <= 0x109F
            or 0x1780 <= o <= 0x17FF or 0x0750 <= o <= 0x077F or 0xFB1D <= o <= 0xFDFF
            or 0xFE70 <= o <= 0xFEFF)


def _is_rtl_script(ch):
    o = ord(ch)
    return 0x0590 <= o <= 0x08FF or 0xFB1D <= o <= 0xFDFF or 0xFE70 <= o <= 0xFEFF


def is_invisible(ch):
    if ch in '\t\n\r':
        return False
    o = ord(ch)
    cat = unicodedata.category(ch)
    if cat in ('Cc', 'Cf'):
        return True
    if 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF or 0xE0000 <= o <= 0xE007F:
        return True
    if 0x180B <= o <= 0x180F or o in (0x115F, 0x1160, 0x3164, 0xFFA0):
        return True
    return False


def _rtl_in(text):
    return any(_is_rtl_script(c) for c in text if ord(c) > 0x0590)


def kept_invisible(text, i, rtl):
    """True when an invisible character does a job in its position (cleanup keeps it)."""
    ch = text[i]
    o = ord(ch)
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if 0xE0020 <= o <= 0xE007F:
        return bool(prev) and (_is_pictographic(prev) or 0xE0020 <= ord(prev) <= 0xE007F
                               or prev == '\U0001F3F4')
    if 0xFE00 <= o <= 0xFE0F:
        if nxt == '\u20e3':
            return True
        return bool(prev) and (_is_pictographic(prev) or unicodedata.category(prev).startswith('S')
                               or _is_cjk(prev))
    if 0xE0100 <= o <= 0xE01EF:
        return bool(prev) and _is_cjk(prev)
    if 0x180B <= o <= 0x180F:
        return bool(prev) and 0x1800 <= ord(prev) <= 0x18AF
    if o == 0x200B:
        return (bool(prev) and _is_nospace_script(prev)) or (bool(nxt) and _is_nospace_script(nxt))
    if o == 0x00AD:
        return bool(prev) and bool(nxt) and prev.isalpha() and nxt.isalpha()
    if o in (0x200E, 0x200F, 0x061C, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
             0x2066, 0x2067, 0x2068, 0x2069):
        return rtl
    if o in (0x200C, 0x200D):
        def joinable(c):
            return bool(c) and (_is_joining_script(c) or _is_pictographic(c)
                                or unicodedata.category(c).startswith('S'))
        return joinable(prev) or joinable(nxt)
    if 0x17B4 <= o <= 0x17B5:
        return (bool(prev) and 0x1780 <= ord(prev) <= 0x17FF) or (bool(nxt) and 0x1780 <= ord(nxt) <= 0x17FF)
    return False


NBSP_CHARS = ('\u00a0', '\u202f')


def nbsp_kept(text, i):
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if (prev and prev.isdigit()) or (nxt and nxt.isdigit()):
        return True
    if nxt and nxt in ':;!?»›%€':
        return True
    if prev and prev in '«‹':
        return True
    return False


def is_nonstandard_space(ch):
    return ch != ' ' and unicodedata.category(ch) == 'Zs'


LOOKALIKE = {}
for _c, _l in [
    ('а', 'a'), ('с', 'c'), ('ԁ', 'd'), ('е', 'e'), ('һ', 'h'), ('і', 'i'), ('ј', 'j'),
    ('ո', 'n'), ('о', 'o'), ('р', 'p'), ('ѕ', 's'), ('ѵ', 'v'), ('ԝ', 'w'), ('х', 'x'),
    ('у', 'y'), ('ս', 'u'),
    ('А', 'A'), ('В', 'B'), ('С', 'C'), ('Е', 'E'), ('Н', 'H'), ('І', 'I'), ('Ј', 'J'),
    ('К', 'K'), ('М', 'M'), ('О', 'O'), ('Р', 'P'), ('Ѕ', 'S'), ('Т', 'T'), ('Х', 'X'),
    ('У', 'Y'),
    ('ο', 'o'), ('ρ', 'p'), ('ν', 'v'), ('ι', 'i'),
    ('Α', 'A'), ('Β', 'B'), ('Ε', 'E'), ('Ζ', 'Z'), ('Η', 'H'), ('Ι', 'I'), ('Κ', 'K'),
    ('Μ', 'M'), ('Ν', 'N'), ('Ο', 'O'), ('Ρ', 'P'), ('Τ', 'T'), ('Χ', 'X'), ('Υ', 'Y'),
]:
    LOOKALIKE[ord(_c)] = _l

LETTER_RUN = re.compile(r'[^\W\d_]+')


def _homoglyph_run_ok(run):
    has_ascii = False
    has_look = False
    for c in run:
        if c.isascii():
            if c.isalpha():
                has_ascii = True
        elif ord(c) in LOOKALIKE:
            has_look = True
        else:
            return False
    return has_ascii and has_look


def homoglyph_runs(text):
    """Return list of (start, end, lookalike_count) for qualifying mixed-script runs."""
    out = []
    for m in LETTER_RUN.finditer(text):
        run = m.group(0)
        if _homoglyph_run_ok(run):
            n = sum(1 for c in run if ord(c) in LOOKALIKE)
            out.append((m.start(), m.end(), n))
    return out


def fold_homoglyphs(text):
    def rep(m):
        run = m.group(0)
        if _homoglyph_run_ok(run):
            return ''.join(LOOKALIKE.get(ord(c), c) for c in run)
        return run
    return LETTER_RUN.sub(rep, text)


def char_layer(window):
    """Counts on the scan window: invisible (not kept), non-standard spaces (not kept), homoglyph chars."""
    rtl = _rtl_in(window)
    inv = []
    nons = []
    for i, ch in enumerate(window):
        if is_invisible(ch):
            if not kept_invisible(window, i, rtl):
                inv.append(i)
        elif ch in NBSP_CHARS:
            if not nbsp_kept(window, i):
                nons.append(i)
        elif is_nonstandard_space(ch):
            nons.append(i)
    hg = homoglyph_runs(window)
    return {
        'invisible': inv,
        'nonstandard': nons,
        'homoglyph_runs': hg,
        'homoglyph_chars': sum(n for _, _, n in hg),
    }


def clean_text(text):
    """Deterministic cleanup. Returns the scrubbed text (whole input)."""
    rtl = _rtl_in(text)
    out = []
    for i, ch in enumerate(text):
        if ch in '\n\t\r':
            out.append(ch)
            continue
        if is_invisible(ch):
            if kept_invisible(text, i, rtl):
                out.append(ch)
            continue
        if ch in NBSP_CHARS:
            out.append(ch if nbsp_kept(text, i) else ' ')
            continue
        if is_nonstandard_space(ch):
            out.append(' ')
            continue
        cat = unicodedata.category(ch)
        if cat in ('Zl', 'Zp'):
            out.append('\n')
            continue
        out.append(ch)
    s = fold_homoglyphs(''.join(out))
    lines = [line.rstrip(' \t') for line in s.split('\n')]
    while lines and lines[0] == '':
        lines.pop(0)
    result = '\n'.join(lines).rstrip()
    if s.endswith('\n') and result:
        result += '\n'
    return result


# ------------------------------------------------------------------- masking

FENCE_OPEN = re.compile(r'^ {0,3}(`{3,}|~{3,})')
BADGE_LINE = re.compile(r'^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$')
TABLE_ROW = re.compile(r'^\s*\|.*\|\s*$')
QUOTE_LINE = re.compile(r'^\s{0,3}>')


def _blank(s):
    return re.sub(r'[^\n]', ' ', s)


def mask_text(text):
    """Blank out regions that generate no findings; keeps length and newlines."""
    lines = text.split('\n')
    keep = [True] * len(lines)
    i = 0
    # YAML front matter at the very start
    if lines and lines[0].strip() == '---':
        for j in range(1, len(lines)):
            if lines[j].strip() == '---':
                for k in range(0, j + 1):
                    keep[k] = False
                i = j + 1
                break
    # fenced code blocks
    while i < len(lines):
        m = FENCE_OPEN.match(lines[i])
        if m:
            fence = m.group(1)
            ch, n = fence[0], len(fence)
            close_re = re.compile(r'^ {0,3}' + re.escape(ch) + '{%d,}\\s*$' % n)
            j = i + 1
            while j < len(lines) and not close_re.match(lines[j]):
                j += 1
            end = min(j, len(lines) - 1)
            for k in range(i, end + 1):
                keep[k] = False
            i = end + 1
            continue
        i += 1
    # blockquote runs of two or more lines
    i = 0
    while i < len(lines):
        if keep[i] and QUOTE_LINE.match(lines[i]):
            j = i
            while j < len(lines) and keep[j] and QUOTE_LINE.match(lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    keep[k] = False
            i = j
        else:
            i += 1
    # table rows and badge lines
    for k, line in enumerate(lines):
        if keep[k] and (TABLE_ROW.match(line) and line.count('|') >= 2 or BADGE_LINE.match(line)):
            keep[k] = False
    out_lines = []
    for k, line in enumerate(lines):
        line = re.sub(r'`[^`\n]*`', lambda m: _blank(m.group(0)), line) if keep[k] else _blank(line)
        out_lines.append(line)
    return '\n'.join(out_lines)


# --------------------------------------------------------------- structure

WORD_RE = re.compile(r"[^\W_](?:[^\W_]|['’\-])*")
SENT_SPLIT = re.compile(r"(?<=[.!?])[\"')\]]*\s+|\n+")
PARA_SPLIT = re.compile(r'\n[ \t]*\n')


def _spans_of_segments(text, splitter):
    spans = []
    pos = 0
    for m in splitter.finditer(text):
        spans.append((pos, m.start()))
        pos = m.end()
    spans.append((pos, len(text)))
    return spans


def sentences_of(text):
    out = []
    for s, e in _spans_of_segments(text, SENT_SPLIT):
        seg = text[s:e]
        n = len(WORD_RE.findall(seg))
        if n:
            out.append((s, e, n))
    return out


def paragraphs_of(text):
    out = []
    for s, e in _spans_of_segments(text, PARA_SPLIT):
        seg = text[s:e]
        if seg.strip():
            out.append((s, e))
    return out


def _cv(values):
    mean = sum(values) / len(values)
    if mean == 0:
        return None
    var = sum((v - mean) ** 2 for v in values) / len(values)
    return math.sqrt(var) / mean


def _infl(word):
    """Inflected forms of a listed word (simple English rules)."""
    forms = {word, word + 's', word + 'es', word + 'd', word + 'ed', word + 'ing'}
    if word.endswith('e'):
        forms.add(word[:-1] + 'ing')
    if word.endswith('y') and len(word) > 2 and word[-2] not in 'aeiou':
        forms.add(word[:-1] + 'ies')
        forms.add(word[:-1] + 'ied')
    return forms


def _phrase_pat(item):
    parts = item.split()
    return r'\s+'.join(re.escape(p) for p in parts)


def words_rx(items, flags=re.I):
    alts = set()
    for it in items:
        if ' ' in it:
            alts.add(_phrase_pat(it))
        elif '-' in it:
            alts.add(re.escape(it))
        else:
            for f in _infl(it):
                alts.add(re.escape(f))
    ordered = sorted(alts, key=len, reverse=True)
    return re.compile(r'(?<![^\W_])(?:' + '|'.join(ordered) + r')(?![^\W_])', flags)


def raw_rx(patterns, flags=re.I):
    return re.compile('|'.join('(?:%s)' % p for p in patterns), flags)


def _spans(rx, text):
    return [(m.start(), m.end()) for m in rx.finditer(text)]


# --------------------------------------------------------------- catalogue

AI_VOCAB = [
    'additionally', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant', 'meticulous',
    'testament', 'underscore', 'intricate', 'intricacies', 'interplay', 'garner', 'bolster',
    'foster', 'showcase', 'emphasize', 'enduring', 'enhance', 'leverage', 'utilize',
    'facilitate', 'encompass', 'harness', 'holistic', 'paradigm', 'transformative',
    'unprecedented', 'myriad', 'plethora', 'robust', 'seamless', 'navigate', 'embark',
    'craft', 'landscape', 'journey', 'realm', 'multifaceted', 'elevate', 'empower', 'unlock',
]
RX_AI_VOCAB = re.compile(words_rx(AI_VOCAB).pattern + '|' + r'capture\s+the\s+(?:essence|spirit|imagination|heart|magic)\b' + '|' +
                         r'\balign\s+with\b', re.I)

DIALECT_WORDS = ['genuinely', 'fascinating', 'nuanced', 'thoughtfully', 'refreshingly',
                 'strikingly', 'compellingly']
RX_DIALECT = re.compile(
    words_rx(DIALECT_WORDS).pattern + '|' + raw_rx([
        r'quietly\s+(?:powerful|profound|radical)\b',
        r'deeply\s+(?:human|personal|felt|unsettling)\b',
        r'resonates?\s+deeply\b',
        r'game[\s-]+chang\w*',
        r'supercharg\w*', r'skyrocket\w*', r'turbocharg\w*', r'revolutioniz\w*',
        r'double\s+down\s+on\b',
        r'dive\s+deep(?:er)?\s+into\b',
        r'unlock\s+(?:the\s+)?(?:power|potential|value)\b',
        r'take\s+[^.!?\n]{1,60}?\s+to\s+the\s+next\s+level\b',
    ]).pattern, re.I)

PROMO = [
    'nestled', 'breathtaking', 'must-visit', 'stunning', 'picturesque', 'charming', 'idyllic',
    'world-class', 'top-tier', 'unparalleled', 'premier', 'leading', 'results-oriented',
    'results-driven',
]
RX_PROMO = re.compile(
    words_rx(PROMO).pattern + '|' + raw_rx([
        r'vibrant\s+community', r'rich\s+cultural\s+heritage', r'in\s+the\s+heart\s+of',
        r'esteemed\s+organization', r'valuable\s+asset', r'passion\s+for\s+excellence',
        r'proven\s+track\s+record', r'wealth\s+of\s+experience', r'dynamic\s+team',
        r'fast-paced\s+environment', r'deeply\s+passionate', r'perfectly\s+situated',
        r'(?:close|tight)-knit\s+team', r'I\s+am\s+excited\s+to\s+(?:apply|bring)\b',
        r'uniquely\s+positioned\s+to\b',
    ]).pattern, re.I)
IMPERATIVES = {'install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape',
               'transform', 'reclaim', 'unlock', 'elevate', 'boost', 'say', 'imagine', 'explore',
               'meet', 'introducing', 'upgrade', 'claim', 'unleash', 'supercharge', 'level',
               'stop', 'start'}

HYPHEN_PAIRS = ['cutting-edge', 'state-of-the-art', 'best-in-class', 'top-notch', 'user-friendly',
                'data-driven', 'value-driven', 'forward-thinking', 'thought-provoking',
                'high-quality', 'next-generation', 'all-in-one', 'one-stop-shop', 'turn-key',
                'detail-oriented', 'results-focused', 'customer-centric']
RX_HYPHEN = re.compile('|'.join(r'(?<![\w-])%s(?![\w-])' % re.escape(h) for h in HYPHEN_PAIRS), re.I)

RX_SIMPLE_YET = re.compile(r'\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b', re.I)

STOCK_ADJ = {'powerful', 'seamless', 'robust', 'innovative', 'dynamic', 'vibrant', 'elegant',
             'sleek', 'bold', 'modern', 'intuitive', 'reliable', 'comprehensive', 'scalable',
             'efficient', 'unique', 'rich', 'lush', 'sophisticated', 'polished', 'simple',
             'clear', 'cutting-edge', 'transformative', 'meticulous', 'vibrant', 'compelling'}
ADJ_SUFFIX = ('ive', 'ous', 'able', 'ible', 'ic', 'ical', 'ant', 'ent', 'ful', 'less', 'al', 'ial', 'ary', 'ory', 'ish')
RX_CHAIN4 = re.compile(
    r"(?<![\w-])[A-Za-z][\w-]*(?:,\s+(?:and\s+)?|\s+and\s+)[A-Za-z][\w-]*(?:,\s+(?:and\s+)?|\s+and\s+)"
    r"[A-Za-z][\w-]*(?:,\s+(?:and\s+)?|\s+and\s+)[A-Za-z][\w-]*\b")

SYNONYM_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]
SYN_RX = []
for _cluster in SYNONYM_CLUSTERS:
    _alts = set()
    for _m in _cluster:
        if ' ' in _m:
            _alts.add(_phrase_pat(_m))
        else:
            _alts.update(re.escape(f) for f in _infl(_m))
    _rx = re.compile(r'(?<![^\W_])(' + '|'.join(sorted(_alts, key=len, reverse=True)) + r')(?![^\W_])', re.I)
    SYN_RX.append((_cluster, _rx))

RX_SIGNIFICANCE = raw_rx([
    r'\b(?:stands?|serves?|stood|served)\s+as\s+(?:a\s+|an\s+|the\s+)?(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b',
    r'\b(?:underscor\w*|highlight\w*)\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b',
    r'\breflects\s+a\s+broader\s+(?:trend|shift|pattern)\b',
    r'\bmarks\s+an?\s+(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)\b',
    r'\bsymboliz\w*\b',
    r'\bsets\s+the\s+stage\s+for\b',
    r'\bleft\s+an\s+indelible\s+mark\b',
    r'\bplays?\s+an?\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b',
    r'\bhas\s+(?:shaped|sparked)\b',
    r'\bhas\s+come\s+to\s+(?:define|symbolize)\b',
], re.I)

RX_NOTABILITY = re.compile(raw_rx([
    r'(?i:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?i:in|by)\s+[^.!?\n]{0,80}?\b[A-Z][\w&.]+(?:\s+[A-Z][\w&.]+)*\s*(?:,|and)\s+[A-Z]',
    r'\b\d[\d,.]*\s*[kKmM]?\s+(?:followers|subscribers)\b',
    r'\b(?:strong|active|significant)\s+(?:online|digital|social\s+media|social)\s+presence\b',
    r'\bwidely\s+(?:covered|reported|cited)\b',
    r'\bindependent\s+(?:coverage|media\s+coverage)\b',
], 0).pattern)

RX_VAGUE = raw_rx([
    r'\bexperts?\s+(?:argue|believe|say|claim|note|suggest)\b',
    r'\bindustry\s+(?:reports|observers|analysts)\b',
    r'\bobservers\s+(?:have\s+)?(?:cited|noted)\b',
    r'\bsome\s+critics\s+argue\b',
    r'\bresearchers\s+have\s+found\b',
    r'\bstudies\s+suggest\b',
    r'\bit\s+is\s+widely\s+believed\b',
])

RX_ARTICLE_TITLE = raw_rx([
    r'\bThe\s+(?:List|Index|Compilation|Collection|Catalogue|Guide|Overview)\s+of\s+[^\n.!?]{2,}?\s+(?:is|are)\s+(?:a|an|the)\b',
])

RX_CONSERVATION = raw_rx([
    r'\bplays?\s+a\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b',
    r'\bconservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)\b',
    r'\bserves\s+as\s+an\s+indicator\s+species\b',
    r'\bcontributes\s+to\s+biodiversity\b',
])

RX_FALSE_RANGE = raw_rx([
    r'\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]*?\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b',
    r'\bfrom\s+(?:the\s+)?humble\b[^.!?\n]*?\bto\s+(?:the\s+)?(?:mighty|towering|grand|sprawling)\b',
])

RX_ING_TAIL = re.compile(r',\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b', re.I)

RX_PARALLEL = raw_rx([
    r'\bit[’\']s\s+not\s+(?:just|merely)\s+(?:about|an?)\b',
    r'\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b',
    r'\bdoesn[’\']t\s+just\b[^,.\n]{0,40}?\bit\b',
])
RX_TAILING_NEG = re.compile(r'\w,\s+no\s+(?:wasted\s+motion|guessing|waste|hassle|fluff|stress|jargon)\b', re.I)

RX_NOT_X_JUST_Y = raw_rx([
    r'\b(?:no|not)\s+\w+,\s+(?:just|only|simply)\s+\w+',
    r'\b(?:not|isn[’\']t|aren[’\']t|wasn[’\']t|weren[’\']t)\s+(?:just|merely)\s+(?:a|an|the)\s+\w+(?:,|\s*[—–-])\s*(?:it[’\']s|it\s+is|it\s+was|they[’\']re|they\s+are|they\s+were|that[’\']s|but)\b',
])

FILLER = ['in order to', 'due to the fact that', 'at this point in time', 'in the event that',
          'has the ability to', 'it is important to note that', 'it should be mentioned that',
          'needless to say']
RX_FILLER = re.compile('|'.join(r'\b%s\b' % _phrase_pat(f) for f in FILLER), re.I)

RX_EMPTY_PIVOT = raw_rx([
    r'\bit[’\']s\s+worth\s+(?:noting|mentioning)\s+that\b',
    r'\bit\s+bears\s+(?:noting|mentioning)\s+that\b',
    r'\bone\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is\b',
    r'\bit\s+is\s+interesting\s+to\s+note\s+that\b',
    r'\ba\s+key\s+consideration\s+is\b',
    r'\ba\s+point\s+to\s+highlight\s+is\b',
])

RX_OUTCOME_TAIL = re.compile(r',\s+(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about|with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for|signaling\s+a\s+shift\s+toward)\b', re.I)

PERSUASIVE = ["here’s the thing", "here's the thing", 'make no mistake', 'the truth is',
              "let's be honest", 'the simple fact is', 'at its core', 'what really matters',
              'more than anything', 'at the end of the day', 'the bottom line is', 'in reality',
              '"fundamentally,"', 'the real question is', 'the heart of the matter',
              'the deeper issue', 'when you get down to it', 'when all is said and done']
def _apos(phrase):
    return _phrase_pat(phrase).replace("'", "['’]")


RX_PERSUASIVE = re.compile('|'.join(
    (r'[“"]fundamentally,[”"]' if p == '"fundamentally,"' else r'\b%s\b' % _apos(p))
    for p in PERSUASIVE), re.I)

RX_EDITORIAL = raw_rx([
    r'\bit(?:[’\']s|\s+is)\s+important\s+to\s+(?:remember|note|understand|recognize)\b',
    r'\bone\s+must\s+note\s+that\b',
    r'\bit\s+is\s+worth\s+pointing\s+out\b',
    r'\bit\s+cannot\s+be\s+overstated\s+that\b',
    r'\bit\s+must\s+be\s+emphasized\s+that\b',
])

RX_SELF_THOROUGH = raw_rx([
    r'\bthis\s+(?:comprehensive|in-depth|complete)\s+(?:guide|overview|analysis|look|examination)\b',
    r'\ba\s+thorough\s+examination\s+of\b',
    r'\beverything\s+you\s+need\s+to\s+know\s+about\b',
])

RX_QA = re.compile(r'(?:^|[.!?]\s+|\n)(?:Is|Are|Was|Were|Do|Does|Did|Can|Could|Will|Would|Should|Has|Have|Had|May|Might|Must)\b[^.!?\n]{0,120}\?\s*(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)[.!]', re.I)

RX_CONCRETE = raw_rx([
    r'\bwithout\s+(?:any\s+)?concrete\s+(?:evidence|proof)\b',
    r'\bdo\s+you\s+have\s+concrete\s+(?:evidence|proof)\b',
    r'\bI\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples|proof)\b',
    r'\babsent\s+concrete\s+(?:proof|evidence)\b',
    r'\bprovide\s+concrete\s+(?:evidence|proof)\b',
])

RX_INTRO_HOOK = re.compile('|'.join([
    r"\bin\s+today[’']s\s+(?:[\w-]+\s+){0,2}(?:world|landscape|environment|market)\b",
    r'\bin\s+a\s+world\s+where\b',
    r'\bin\s+an\s+era\s+of\b',
    r'\bin\s+recent\s+years,',
    r'\bmore\s+than\s+ever\s+before\b',
    r'\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b',
    r'\b(?:great|exciting|big)\s+news\s*[!:]',
    r'\bever\s+(?:wanted|wondered|dreamed|wished)\b[^.!?\n]{0,60}\?',
    r'\bin\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world\b',
]), re.I)

RX_DIFF_ANCHOR = raw_rx([
    r'\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b',
    r'\b(?:the|this)\s+(?:latest\s+|new\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b',
    r'\b(?:has|have)\s+been\s+(?:updated|refactored|improved|enhanced|changed)\s+to\b',
    r'\bpreviously\b[^.!?\n]{0,80}\bnow\b',
    r'\bwas(?:n[’\']t|\s+not)\s+there\s+before\b',
    r'\bwere(?:n[’\']t|\s+not)\s+there\s+before\b',
    r'\bwe(?:[’\']ve|\s+have)\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b',
])

RX_SIGNPOST = raw_rx([
    r'\blet[’\']s\s+(?:dive|delve|explore)\b',
    r'\blet[’\']s\s+break\s+(?:this|it)\s+down\b',
    r'\bhere[’\']s\s+what\s+you\s+need\s+to\s+know\b',
    r'\bwithout\s+further\s+ado\b',
    r'\bnow\s+let[’\']s\s+look\s+at\b',
    r'\bbuckle\s+up\b',
    r'\bstay\s+with\s+me\b',
    r'\bready\s+to\s+dive\s+in\b',
])

RX_CATALOGUE = raw_rx([
    r'\b(?:used|uses|use|employs?|employed|relied\s+on|utilizes?|utilized)\s+(?:several|various|a\s+number\s+of|multiple|different|many|numerous)\s+\w+',
    r'\bThese\b(?:\s+\w+)?\s+(?:provide|offer|give|reveal|show|allow|enable|help)\s+(?:\w+\s+)?(?:information|insight|understanding|details|data)\b',
    r'\b(?:is|are|was|were|remains|becomes)\s+(?:the|a)\s+(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b',
])

RX_FORMULAIC = raw_rx([
    r'\bdespite\s+(?:these|its|the)\s+(?:challenges|obstacles)\b',
    r'\bchallenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)\b',
    r'\bcontinues?\s+to\s+thrive\b',
    r'\btypical\s+of\s+(?:emerging|urban|modern)\b',
    r'\bfaces?\s+(?:several|many|numerous)\s+challenges\b',
])

TRANSITIONS = {'additionally', 'furthermore', 'moreover', 'however', 'nevertheless',
               'consequently', 'subsequently', 'notably'}

RX_COMPULSIVE_CONCL = re.compile(r'^[ \t]*(?:in\s+conclusion|overall|in\s+summary|to\s+summarize|to\s+conclude|all\s+in\s+all|in\s+essence|ultimately)\b', re.I | re.M)

RX_GENERIC_POS = raw_rx([
    r'\bthe\s+future\s+looks\s+bright\b',
    r'\bexciting\s+times\s+lie\s+ahead\b',
    r'\bjourney\s+toward\s+excellence\b',
    r'\bstep\s+in\s+the\s+right\s+direction\b',
    r'\b(?:outlook|future)(?:\s+for\s+[^.!?\n]{1,40})?\s+(?:is|looks|remains)\s+bright\b',
    r'\bwell[- ]positioned\s+for\s+(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)\b',
])

RX_INLINE_HEADER = re.compile(r'^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?(?:\*\*[^*\n]*:\*\*|\*\*[^*\n]+\*\*:)', re.M)

RX_HEADING = re.compile(r'^(#{1,6})[ \t]+(.+?)[ \t#]*$', re.M)
RX_LIST_LINE = re.compile(r'^\s*(?:[-*+]|\d+[.)])\s+')

RX_CHATBOT = raw_rx([
    r'\bI\s+hope\s+this\s+helps\b',
    r'\b(?:certainly|of\s+course)!',
    r'\blet\s+me\s+know\s+if\s+you\b',
    r'\bwould\s+you\s+like\s+me\s+to\b',
    r'\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b',
    r'\bhappy\s+to\s+help\s*[.!]',
    r'\b(?:here|below)\s+is\s+(?:a\s+|an\s+|the\s+)?(?:overview|summary|rundown|recap|brief)\b',
    r'\bhere\s+(?:are|is)\s+(?:(?:a\s+few|some|two|three)\s+)?(?:options|drafts|versions|variations)\b',
    r'\bhere[’\']?s\s+(?:a\s+few|some|two|three)\s+(?:options|drafts|versions|variations)\b',
    r'\bhere\s+(?:is|[’\']s)\s+(?:a\s+|an\s+|the\s+)?(?:draft|first\s+pass|revised\s+version)\b',
    r'\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b',
    r'\bI\s+hope\s+(?:this\s+email\s+)?finds\s+you\s+well\b',
    r'\bas\s+an?\s+(?:AI|LLM)\b',
    r'\bas\s+an?\s+(?:AI\s+assistant|AI\s+language\s+model|large\s+language\s+model|language\s+model)\b',
    r'\bto\s+(?:answer|address)\s+your\s+question\b',
    r'\bin\s+(?:response|answer)\s+to\s+your\s+question\b',
    r'\byour\s+question\s+(?:about|regarding|concerning)\b',
    r'\bas\s+(?:you\s+)?(?:requested|asked),?\s+here\b',
    r'\bhere\s+is\s+(?:the\s+)?(?:draft|first\s+pass|revised\s+version)\s+(?:of|for\s+your)\b',
])

RX_SYCOPHANT = raw_rx([
    r'\byou(?:[’\']re|\s+are)\s+absolutely\s+right\b',
    r'\b(?:great|excellent|fantastic|wonderful|good|insightful|thoughtful|brilliant)\s+(?:question|point)\s*[!.,]',
    r'\bwhat\s+a\s+(?:thoughtful|great|wonderful|fantastic|brilliant|excellent)\s+question\b',
    r'\bthat[’\']?s\s+a\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\b',
])

RX_CUTOFF = raw_rx([
    r'\bas\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)\b',
    r'\bup\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)\b',
    r'\bwhile\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+extensively\s+(?:documented|widely\s+documented))\b',
    r'\bbased\s+on\s+(?:the\s+)?available\s+information\b',
    r'\bas\s+of\s+my\s+knowledge\s+cutoff\b',
    r'\bmaintains\s+a\s+low\s+profile\b',
    r'\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b',
])

RX_COPULA = raw_rx([
    r'\b(?:serves|stands|functions|acts|served|stood|functioned|acted)\s+as\b',
    r'\brepresents\s+(?:a|the)\b',
    r'\bmarks\s+(?:a|the)\b',
    r'\bboasts\b',
    r'\bfeatures\s+(?:a|an|the|\d+|one|two|three|four|five|several|many|numerous|multiple|various|some)\b',
    r'\boffers\s+a\b',
    r'\brefers\s+to\b',
])

HEDGE_WORDS = re.compile(r'\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively|fairly)\b|\bseems?\s+(?:to|like)\b|\bappears?\s+to\b|\bkind\s+of\b|\bsort\s+of\b')
RX_CONTRACTION_TOKEN = re.compile(r"\b\w+(?:n['’]t|['’](?:re|m|ll|ve|d|s))\b", re.I)
EXPANDED_RX = re.compile(r"\b(?:do not|does not|did not|is not|are not|was not|were not|will not|would not|should not|could not|cannot|can not|have not|has not|I am|I have|I will|I would|we are|we have|we will|it is|that is|there is|they are|you are|let us)\b", re.I)
FIRST_PERSON_RX = re.compile(r'\b(?:I|me|my|we|our|us)\b')

RX_EMOJI = re.compile('[\U0001F000-\U0001FAFF\u2600-\u27BF\u2B50\u2B55\u231A\u231B\u23E9-\u23F3]')
RX_BOLD = re.compile(r'\*\*[^*\n]+?\*\*')
RX_CURLY = re.compile('[\u2018\u2019\u201c\u201d]')
RX_YEAR_RANGE = re.compile(r'\b(1[0-9]{3}|20[0-9]{2})-(1[0-9]{3}|20[0-9]{2})\b')
RX_HR = re.compile(r'^[ \t]{0,3}([-*_])(?:[ \t]*\1){2,}[ \t]*$', re.M)

RX_PLACEHOLDER = raw_rx([
    r'\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![\(\[])',
    r'\[(?:name|company|client|person|place|source)\](?![\(\[])',
    r'\{\{[^{}\n]*\}\}',
    r'\bx{3,}\b',
    r'\blorem\s+ipsum\b',
])
RX_ALLCAPS_SLOT = re.compile(r'\[([A-Z][A-Z \-_]{1,})\](?![\(\[])')
RX_CHAT_MARKUP = raw_rx([
    r'\bcite(?:turn|start|nav)\w*',
    r'\boai_citation\w*',
    r'\bcontentReference\w*',
    r'\bnavlist\w*',
    r'【\d+†[^】\n]*】',
])
RX_UTM = re.compile(r'utm_source=((?:[A-Za-z0-9-]+\.)+[A-Za-z]{2,})(?![A-Za-z0-9-])')
AI_HOSTS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai', 'gemini.google.com',
            'copilot.microsoft.com', 'poe.com'}


# ---------------------------------------------------------------- labels

LABELS = {
    1: ('ai_vocabulary', 'AI vocabulary'),
    2: ('model_dialect_vocabulary', 'Model-dialect vocabulary'),
    3: ('promotional_language', 'Promotional language'),
    4: ('hyphenated_word_pairs', 'Hyphenated word-pair overuse'),
    5: ('simple_yet', '"Simple yet X" cliche'),
    6: ('stacked_adjectives', 'Stacked adjective chains'),
    8: ('synonym_cycling', 'Synonym cycling'),
    10: ('significance_inflation', 'Significance inflation'),
    11: ('notability_name_dropping', 'Notability name-dropping'),
    12: ('vague_attributions', 'Vague attributions'),
    13: ('article_title_proper_noun', 'Article title as proper noun'),
    14: ('conservation_padding', 'Conservation and ecosystem padding'),
    15: ('false_ranges', 'False ranges'),
    16: ('ing_tail_clauses', 'Superficial -ing tail clauses'),
    18: ('not_x_just_y', 'Not X, just Y'),
    19: ('filler_phrases', 'Filler phrases'),
    20: ('empty_pivot_phrases', 'Empty pivot phrases'),
    21: ('outcome_speculation_tails', 'Outcome-speculation tails'),
    22: ('persuasive_authority_tropes', 'Persuasive authority tropes'),
    23: ('editorial_interjections', 'Editorial interjections'),
    24: ('self_thoroughness', 'Self-thoroughness phrases'),
    25: ('question_answer_pattern', 'Question-answer rhetorical pattern'),
    26: ('concrete_evidence_defense', 'Concrete-evidence defense phrase'),
    27: ('compulsive_intro_hooks', 'Compulsive intro hooks'),
    30: ('diff_anchored_writing', 'Diff-anchored writing'),
    31: ('signposting', 'Signposting and announcements'),
    32: ('cataloguing_lead_ins', 'Cataloguing lead-ins'),
    33: ('inline_header_lists', 'Inline-header vertical lists'),
    34: ('mid_essay_bullets', 'Mid-essay bullet injection'),
    35: ('fragmented_headers', 'Fragmented headers'),
    36: ('formulaic_challenges', 'Formulaic challenges sections'),
    37: ('transition_clusters', 'Transition cluster overuse'),
    38: ('compulsive_conclusions', 'Compulsive conclusion phrases'),
    39: ('generic_positive_conclusions', 'Generic positive conclusions'),
    40: ('sentence_length_monotony', 'Sentence-length monotony'),
    41: ('mechanical_alternation', 'Mechanical sentence-length alternation'),
    42: ('opener_repetition', 'Opener repetition'),
    44: ('uniform_paragraph_length', 'Uniform paragraph length'),
    46: ('semicolon_paren_underuse', 'Semicolon and parenthesis underuse'),
    47: ('chatbot_artifacts', 'Chatbot artifacts'),
    48: ('sycophantic_tone', 'Sycophantic tone'),
    50: ('knowledge_cutoff_disclaimer', 'Knowledge-cutoff disclaimer'),
    51: ('copula_avoidance', 'Copula avoidance'),
    54: ('hedge_stacking', 'Hedge stacking'),
    55: ('contraction_absence', 'Contraction absence'),
    56: ('boldface_overuse', 'Boldface overuse'),
    57: ('emojis', 'Emojis'),
    58: ('em_dash_overuse', 'Em-dash overuse'),
    59: ('title_case_headings', 'Title case in headings'),
    60: ('curly_quotes', 'Curly quotation marks'),
    61: ('hyphen_for_en_dash', 'Hyphen for en dash in numeric range'),
    62: ('invisible_characters', 'Invisible or zero-width characters'),
    63: ('placeholder_text', 'Placeholder text'),
    64: ('chat_reference_markup', 'Chatbot reference-markup leak'),
    65: ('ai_tracking_parameter', 'AI tracking parameter'),
    66: ('mixed_script_homoglyphs', 'Mixed-script homoglyphs'),
    67: ('nonstandard_spaces', 'Non-standard spaces'),
    68: ('trailing_whitespace', 'Trailing or stray whitespace'),
    69: ('canonical_marketing_phrases', 'Canonical marketing phrases'),
    70: ('decorative_rules', 'Decorative horizontal rules'),
    71: ('degenerate_repetition', 'Degenerate repetition'),
}
LABELS_17P = ('negative_parallelism', 'Negative parallelisms (advice)')
LABELS_17T = ('tailing_negation', 'Tailing negation')

ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
ADVICE_17P = 'negative_parallelism'
DECISIVE = {13, 47, 48, 50, 62, 63, 64, 65, 66}
RHYTHM = {40, 44}
NO_DETECTOR = {7, 9, 28, 29, 43, 45, 49, 52, 53}
SHORT_DOC_FAMILIES = set(range(1, 40)) | set(range(47, 52)) | {69}

def _rule_spans(text, sents, paras, raw_lines):
    """Return {number_or_key: [(start, end), ...]} for pattern-based families."""
    res = {}
    res[1] = _spans(RX_AI_VOCAB, text)
    res[2] = _spans(RX_DIALECT, text)
    promo = _spans(RX_PROMO, text)
    imp = []
    run = []
    for s, e, _n in sents:
        seg = text[s:e].strip()
        first = WORD_RE.findall(seg)
        if first and first[0].lower() in IMPERATIVES:
            imp.append((s, e))
    if len(imp) >= 3:
        promo += imp
    res[3] = promo
    res[4] = _spans(RX_HYPHEN, text)
    res[5] = _spans(RX_SIMPLE_YET, text)
    chain = []
    for m in RX_CHAIN4.finditer(text):
        words = [w.lower() for w in WORD_RE.findall(m.group(0))]
        if 'and' in words or 'or' in words:
            words = [w for w in words if w not in ('and', 'or')]
        if len(words) < 4:
            continue
        if any(w in STOCK_ADJ or w.endswith(ADJ_SUFFIX) for w in words):
            chain.append((m.start(), m.end()))
    res[6] = chain
    syn = []
    for cluster, rx in SYN_RX:
        found = {m.group(1).lower() for m in rx.finditer(text)}
        members = set()
        for f in found:
            for c in cluster:
                if f == c or f.rstrip('s') == c.rstrip('s') or f == c + 's':
                    members.add(c)
        if len(members) >= 3:
            syn += _spans(rx, text)
    res[8] = syn
    res[10] = _spans(RX_SIGNIFICANCE, text)
    res[11] = _spans(RX_NOTABILITY, text)
    res[12] = _spans(RX_VAGUE, text)
    res[13] = _spans(RX_ARTICLE_TITLE, text)
    res[14] = _spans(RX_CONSERVATION, text)
    res[15] = _spans(RX_FALSE_RANGE, text)
    res[16] = _spans(RX_ING_TAIL, text)
    res['17p'] = _spans(RX_PARALLEL, text)
    res['17t'] = _spans(RX_TAILING_NEG, text)
    res[18] = _spans(RX_NOT_X_JUST_Y, text)
    res[19] = _spans(RX_FILLER, text)
    res[20] = _spans(RX_EMPTY_PIVOT, text)
    res[21] = _spans(RX_OUTCOME_TAIL, text)
    res[22] = _spans(RX_PERSUASIVE, text)
    res[23] = _spans(RX_EDITORIAL, text)
    res[24] = _spans(RX_SELF_THOROUGH, text)
    res[25] = _spans(RX_QA, text)
    res[26] = _spans(RX_CONCRETE, text)
    res[27] = _spans(RX_INTRO_HOOK, text)
    res[30] = _spans(RX_DIFF_ANCHOR, text)
    res[31] = _spans(RX_SIGNPOST, text)
    res[32] = _spans(RX_CATALOGUE, text)
    res[33] = _spans(RX_INLINE_HEADER, text)
    res[36] = _spans(RX_FORMULAIC, text)
    res[38] = _spans(RX_COMPULSIVE_CONCL, text)
    res[39] = _spans(RX_GENERIC_POS, text)
    res[47] = _spans(RX_CHATBOT, text)
    res[48] = _spans(RX_SYCOPHANT, text)
    res[50] = _spans(RX_CUTOFF, text)
    res[51] = _spans(RX_COPULA, text)
    res[57] = _spans(RX_EMOJI, text)
    res[60] = _spans(RX_CURLY, text)
    res[61] = [(m.start(), m.end()) for m in RX_YEAR_RANGE.finditer(text)
               if int(m.group(1)) < int(m.group(2))]
    res[63] = _spans(RX_PLACEHOLDER, text)
    for m in RX_ALLCAPS_SLOT.finditer(text):
        if not re.fullmatch(r'[A-Z]\d*', m.group(1)) and not re.fullmatch(r'[A-Z]\d+', m.group(1)):
            res.setdefault(63, []).append((m.start(), m.end()))
    res[64] = _spans(RX_CHAT_MARKUP, text)
    res[65] = [(m.start(), m.end()) for m in RX_UTM.finditer(text)
               if m.group(1).lower() in AI_HOSTS]
    res[69] = _spans(CANON_RX, text)
    return res


CANON_RX = raw_rx([
    r'\bunlocking\s+(?:its|your|the|their)?\s*full\s+potential\b',
    r'\bnavigating\s+the\s+complexities\b',
    r'\ba\s+testament\s+to\s+the\s+(?:power|importance)\s+of\b',
    r'\bstaying\s+ahead\s+of\s+the\s+curve\b',
    r'\bturning\s+challenges\s+into\s+opportunities\b',
    r'\btaking\s+(?:it|something|your\s+\w+|\w+)\s+to\s+the\s+next\s+level\b',
    r'\bharnessing\s+the\s+power\s+of\b',
    r'\bpaving\s+the\s+way\s+for\b',
    r'\bsaying\s+goodbye\s+to\b',
    r'\bimagining\s+a\s+world\s+where\b',
])


def _structural_spans(text, sents, paras, raw_text):
    res = {}
    # 34: mid-essay bullet injection
    has_heading = bool(RX_HEADING.search(text))
    if not has_heading:
        prose_paras = 0
        list_paras = []
        for s, e in paras:
            seg = text[s:e].strip('\n')
            lines = [ln for ln in seg.split('\n') if ln.strip()]
            if not lines:
                continue
            if all(RX_LIST_LINE.match(ln) for ln in lines):
                list_paras.append((s, e))
            elif WORD_RE.search(seg):
                prose_paras += 1
        if list_paras and prose_paras >= 2:
            res[34] = list_paras
    # 35: fragmented headers
    frag = []
    lines = text.split('\n')
    for idx, line in enumerate(lines):
        m = re.match(r'^#{1,6}[ \t]+(.+?)[ \t#]*$', line)
        if not m:
            continue
        j = idx + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if not nxt or nxt.startswith(('#', '-', '*', '+', '|', '>')) or re.match(r'^\d+[.)]\s', nxt):
            continue
        nwords = WORD_RE.findall(nxt)
        if not nwords or len(nwords) > 4:
            continue
        head_words = {w.lower() for w in WORD_RE.findall(m.group(1)) if len(w) >= 3}
        if head_words & {w.lower() for w in nwords if len(w) >= 3}:
            start = sum(len(x) + 1 for x in lines[:j])
            frag.append((start, start + len(lines[j])))
    if frag:
        res[35] = frag
    # 37: transition clusters; 42: opener repetition
    trans = []
    opener = []
    sent_starts = [s for s, _e, _n in sents]
    for ps, pe in paras:
        lo = bisect.bisect_left(sent_starts, ps)
        hi = bisect.bisect_left(sent_starts, pe)
        ss = [(s, e) for s, e, _n in sents[lo:hi] if e <= pe]
        openers = []
        for s, e in ss:
            words = WORD_RE.findall(text[s:e])
            if words:
                openers.append((s, e, words[0].lower(), words[:2]))
        t = [(s, e) for s, e, w, _ in openers if w in TRANSITIONS]
        if len(t) >= 2:
            trans += t
        if len(openers) >= 3:
            counts = {}
            for _s, _e, _w, two in openers:
                key = ' '.join(x.lower() for x in two)
                counts.setdefault(key, []).append((_s, _e))
            for key, lst in counts.items():
                if len(lst) >= 3 and len(key.split()) == 2:
                    opener += lst
    if trans:
        res[37] = trans
    if opener:
        res[42] = opener
    # 58: em-dash overuse (two or more in one paragraph)
    dash = []
    for ps, pe in paras:
        found = [(m.start() + ps, m.end() + ps) for m in re.finditer('—', text[ps:pe])]
        if len(found) >= 2:
            dash += found
    if dash:
        res[58] = dash
    # 59: title case in headings
    tc = []
    minor = {'a', 'an', 'the', 'and', 'but', 'or', 'nor', 'for', 'so', 'yet', 'of', 'in', 'on', 'at',
             'to', 'by', 'with', 'from', 'as', 'up', 'via', 'vs', 'into', 'over'}
    for m in RX_HEADING.finditer(text):
        title = m.group(2)
        words = WORD_RE.findall(title)
        if len(words) < 3:
            continue
        if not title[0].isalpha() or title.upper() == title:
            continue
        major = [w for w in words if w.lower() not in minor]
        if len(major) >= 2 and all(w[0].isupper() for w in major):
            tc.append((m.start(), m.end()))
    if tc:
        res[59] = tc
    # 66 is character-layer: handled elsewhere
    # 70: decorative horizontal rules
    hr = _spans(RX_HR, text)
    if len(hr) >= 3 and raw_text.count('\n') + 1 >= 24:
        res[70] = hr
    # 56: boldface overuse (three or more bold spans)
    bold = _spans(RX_BOLD, text)
    if len(bold) >= 3:
        res[56] = bold
    # 54: hedge stacking (advice): sentences with two or more distinct hedges
    hedge = []
    for s, e, _n in sents:
        seg = text[s:e]
        found = {m.group(0).lower() for m in HEDGE_WORDS.finditer(seg)}
        if len(found) >= 2:
            hedge.append((s, e))
    if hedge:
        res[54] = hedge
    # 46: semicolon and parenthesis underuse (advice), long documents only
    words_total = len(WORD_RE.findall(text))
    if words_total >= 300 and ';' not in text and text.count('(') <= 1:
        res[46] = [(0, min(len(text), 80))]
    # 55: contraction absence (advice), first-person writing only
    if words_total >= 20:
        fp = len(FIRST_PERSON_RX.findall(text))
        contr = len(RX_CONTRACTION_TOKEN.findall(text))
        expanded = EXPANDED_RX.findall(text)
        if fp >= max(2, words_total * 0.03) and len(expanded) >= 2 and len(expanded) > 2 * contr:
            res[55] = [(m.start(), m.end()) for m in EXPANDED_RX.finditer(text)]
    return res


def _stat_spans(text, sents, paras):
    """Rhythm families 40, 44 and mechanical alternation 41. Return {num: spans}."""
    res = {}
    lengths = [n for _s, _e, n in sents]
    if len(lengths) >= 3:
        cv = _cv(lengths)
        if cv is not None and cv < 0.35:
            res[40] = [(0, min(len(text), 80))]
    pwords = []
    for s, e in paras:
        n = len(WORD_RE.findall(text[s:e]))
        if n:
            pwords.append((s, e, n))
    if len(pwords) >= 4:
        cv = _cv([n for _, _, n in pwords])
        if cv is not None and cv < 0.4:
            res[44] = [(s, e) for s, e, _n in pwords]
    # 41: six or more sentences in strict up/down alternation with substantial differences
    if len(sents) >= 6:
        diffs = [lengths[k + 1] - lengths[k] for k in range(len(lengths) - 1)]
        run_spans = []
        k = 0
        while k < len(diffs):
            if abs(diffs[k]) < 6:
                k += 1
                continue
            j = k
            while (j + 1 < len(diffs) and abs(diffs[j + 1]) >= 6
                   and diffs[j] * diffs[j + 1] < 0):
                j += 1
            if j - k + 1 >= 5:  # five alternating differences span six sentences
                run_spans.append((sents[k][0], sents[j + 1][1]))
            k = j + 1
        if run_spans:
            res[41] = run_spans
    return res


def _words_repetition(text):
    words = [w.lower() for w in WORD_RE.findall(text)]
    if len(words) < 6:
        return []
    grams = [tuple(words[i:i + 6]) for i in range(len(words) - 5)]
    counts = {}
    for g in grams:
        counts[g] = counts.get(g, 0) + 1
    repeated = [i for i, g in enumerate(grams) if counts[g] > 1]
    if not repeated or len(repeated) / float(len(grams)) < 0.2:
        return []
    return [(i, i + 1) for i in repeated]


def _sample(text, s, e):
    frag = text[s:e].replace('\n', ' ').strip()
    if len(frag) > 80:
        frag = frag[:77] + '...'
    return frag


def _all_spans(text, sents, paras, raw_text):
    """Collect every family's spans: returns {key: [(s,e), ...]}."""
    res = {}
    res.update(_rule_spans(text, sents, paras, raw_text))
    res.update(_structural_spans(text, sents, paras, raw_text))
    res.update(_stat_spans(text, sents, paras))
    rep = _words_repetition(text)
    if rep:
        res[71] = rep
    return res


# --------------------------------------------------------------- scoring

def band_of(score):
    if score <= 20:
        return 'clean'
    if score <= 40:
        return 'light tells'
    if score <= 60:
        return 'mixed'
    if score <= 80:
        return 'heavy tells'
    return 'pervasive tells'


def confidence_of(words, families):
    if words < 40:
        return 'none', 'fewer than 40 words, too little text to judge'
    if words < 120:
        return 'low', 'fewer than 120 words'
    if words < 300 and families == 1:
        return 'low', 'under 300 words with only one score-moving family'
    if words < 300:
        return 'moderate', 'under 300 words'
    return 'high', ''


def score_of(sm, decisive, words, conf):
    """sm: set of score-moving family numbers fired; decisive: subset of sm."""
    base = min(100, 14 * len(sm))
    cap = 100
    if len(sm) == 1:
        only = next(iter(sm))
        cap = 20 if only == 40 else 40
    elif sm and sm <= RHYTHM:
        cap = 40
    floor = 0
    if len(decisive) >= 2:
        floor = 65
    elif len(decisive) == 1 and conf in ('moderate', 'high'):
        floor = 45
        if len(sm) == 1:
            cap = 100
    if words < 120:
        n2 = len(sm & SHORT_DOC_FAMILIES)
        if n2 >= 3:
            floor = max(floor, 45)
        elif n2 >= 2:
            floor = max(floor, 25)
    if words >= 400:
        if len(sm) >= 6:
            floor = max(floor, 45)
        elif len(sm) >= 5:
            floor = max(floor, 25)
    score = max(min(base, cap), floor)
    return max(0, min(100, int(score)))


def build_report(window, full_len):
    """Return (report_dict, meta) for the scan window text."""
    cl = char_layer(window)
    masked = mask_text(window)
    sents = sentences_of(masked)
    paras = paragraphs_of(masked)
    words = WORD_RE.findall(masked)
    nwords = len(words)
    spans = _all_spans(masked, sents, paras, window)

    # decide which keys fired and their counts
    fired = {}  # key -> (number, slug, label, spans, advice, weight_ok)
    for key, lst in spans.items():
        if not lst:
            continue
        if key == 17 or key == '17p' or key == '17t':
            continue
        fired[key] = lst
    # family 2 needs two hits
    if 2 in fired and len(fired[2]) < 2:
        del fired[2]

    # ensure 17 forms
    sm = set()
    decisive = set()
    report = {}
    findings = []

    def add_finding(member_key, number, label, lst, slug):
        samples = [_sample(masked, s, e) for s, e in lst[:3]]
        report[member_key] = {'label': label, 'count': len(lst), 'samples': samples}
        findings.append(number)

    for number in sorted(k for k in fired if isinstance(k, int)):
        slug, label = LABELS[number]
        add_finding('%d_%s' % (number, slug), number, label, fired[number], slug)
        if number not in ADVICE:
            sm.add(number)
            if number in DECISIVE:
                decisive.add(number)
    if spans.get('17p'):
        add_finding('17_negative_parallelism', 17, LABELS_17P[1], spans['17p'], LABELS_17P[0])
    if spans.get('17t'):
        add_finding('17_tailing_negation', 17, LABELS_17T[1], spans['17t'], LABELS_17T[0])
        sm.add(17)

    # character layer findings (counted on the whole window, not the mask)
    inv = cl['invisible']
    if inv:
        s0 = [(i, i + 1) for i in inv]
        slug, label = LABELS[62]
        add_finding('62_%s' % slug, 62, label, s0, slug)
        sm.add(62)
        decisive.add(62)
    hg = cl['homoglyph_runs']
    if hg:
        slug, label = LABELS[66]
        add_finding('66_%s' % slug, 66, label, [(s, e) for s, e, _n in hg], slug)
        sm.add(66)
        decisive.add(66)
    nons = cl['nonstandard']
    if nons:
        slug, label = LABELS[67]
        add_finding('67_%s' % slug, 67, label, [(i, i + 1) for i in nons], slug)
        sm.add(67)
    trailing = []
    lines = window.split('\n')
    pos = 0
    for idx, line in enumerate(lines):
        stripped = line.rstrip(' \t')
        if stripped != line and idx < len(lines) - 1:
            trailing.append((pos + len(stripped), pos + len(line)))
        elif stripped != line and idx == len(lines) - 1:
            trailing.append((pos + len(stripped), pos + len(line)))
        pos += len(line) + 1
    if window[:1].isspace():
        trailing.insert(0, (0, 1))
    if window.endswith('\n\n'):
        trailing.append((len(window) - 2, len(window)))
    if trailing:
        slug, label = LABELS[68]
        add_finding('68_%s' % slug, 68, label, trailing, slug)

    # families 2 and others already in fired; advice families are in ADVICE set
    if 2 in fired and 2 not in report and 2 in [k for k in fired if isinstance(k, int)]:
        pass

    words_count = nwords
    conf, reason = confidence_of(words_count, len(sm))
    score = score_of(sm, decisive, words_count, conf)
    band = band_of(score)

    metrics = {
        'scanned_chars': len(window),
        'truncated': bool(full_len > WINDOW),
        'ai_tell_score': score,
        'ai_tell_band': band,
        'confidence': conf,
        'confidence_reason': reason,
        'patterns_flagged': len(report),
        'invisible_chars': len(inv),
        'nonstandard_spaces': len(nons),
        'homoglyphs': cl['homoglyph_chars'],
        'word_count': words_count,
        'score_moving_families': sorted(sm),
    }
    meta = {'sm': sm, 'decisive': decisive, 'sents': sents, 'masked': masked,
            'findings_numbers': findings, 'words': words_count}
    return report, metrics, meta


def ci_interval(meta, rng_seed=20240101, rounds=200):
    sents = meta['sents']
    if len(sents) < 4:
        return None, 'too few sentences for an interval (need at least 4)'
    # per-sentence family sets from spans; rebuild lazily
    sent_starts = [s for s, _e, _n in sents]
    fam_by_sent = [set() for _ in sents]
    for number, lst in meta.get('spans_by_number', {}).items():
        for s, e in lst:
            idx = bisect.bisect_right(sent_starts, s) - 1
            if 0 <= idx < len(sents):
                fam_by_sent[idx].add(number)
    rng = random.Random(rng_seed)
    scores = []
    n = len(sents)
    for _ in range(rounds):
        union = set()
        for _k in range(n):
            union |= fam_by_sent[rng.randrange(n)]
        scores.append(min(100, 14 * len(union & meta['sm'])))
    scores.sort()
    lo = scores[int(0.025 * (len(scores) - 1))]
    hi = scores[int(math.ceil(0.975 * (len(scores) - 1)))]
    lo, hi = min(lo, hi), max(lo, hi)
    return [lo, hi], 'bootstrap over sentences with a fixed seed; the point score is unchanged'


def scan(text, want_ci=False):
    window = text[:WINDOW]
    report, metrics, meta = build_report(window, len(text))
    if want_ci:
        spans = _all_spans(meta['masked'], meta['sents'],
                           paragraphs_of(meta['masked']), window)
        numbered = {}
        for k, lst in spans.items():
            # document-level families (rhythm, alternation) do not map to a sentence
            if isinstance(k, int) and k not in ADVICE and k in LABELS and k not in (40, 41, 44):
                numbered[k] = lst
        if spans.get('17t'):
            numbered[17] = spans['17t']
        meta['spans_by_number'] = numbered
        ci, note = ci_interval(meta)
        metrics['score_ci'] = ci
        metrics['score_ci_note'] = note
    report['_metrics'] = metrics
    return report


# ------------------------------------------------------------------ CLI

def _err(msg):
    sys.stderr.write(json.dumps({'error': msg}, ensure_ascii=False) + '\n')


def main(argv):
    clean = False
    want_ci = False
    operands = []
    end_opts = False
    for arg in argv:
        if end_opts:
            operands.append(arg)
            continue
        if arg == '--':
            end_opts = True
            continue
        if arg in ('-h', '--help'):
            sys.stdout.buffer.write(USAGE.encode('utf-8'))
            return 0
        if arg == '--clean':
            clean = True
            continue
        if arg == '--ci':
            want_ci = True
            continue
        if arg.startswith('-'):
            _err('unknown option %s (see --help)' % arg)
            return 2
        operands.append(arg)

    if len(operands) >= 2:
        sys.stderr.write('detect.py: note: scanning only the first file: %s\n' % operands[0])
    try:
        if operands:
            text = extract_path(operands[0])
        else:
            text = decode_plain(sys.stdin.buffer.read())
    except ReadError as exc:
        _err('cannot read input: %s' % exc)
        return 1

    if not text.strip():
        _err('empty input')
        return 1

    if clean:
        sys.stdout.buffer.write(clean_text(text).encode('utf-8'))
        return 0

    report = scan(text, want_ci=want_ci)
    out = json.dumps(report, ensure_ascii=False, indent=2) + '\n'
    sys.stdout.buffer.write(out.encode('utf-8'))
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv[1:]))
    except BrokenPipeError:
        sys.exit(0)
