#!/usr/bin/env node
'use strict';
// prompt-submit hook and `/prosecheck` command router.
// spec: N-000457 N-000458 N-000459 N-000460 N-000461 N-000462 N-000463 N-000464 N-000465
// spec: N-000466 N-000468 N-000469 N-000470 N-000471 N-000472 N-000473 N-000474 N-000475
// spec: N-000476 N-000477 N-000478 N-000479 N-000480 N-000481 N-000482 N-000483 N-000484
// spec: N-000485 N-000486 N-000487 N-000488 N-000489 N-000490 N-000491 N-000492 N-000493
// spec: N-000494 N-000495 N-000496 N-000497 N-000498 N-000499 N-000500 N-000501 N-000502
// spec: N-000503 N-000504 N-000505 N-000506 N-000507 N-000508 N-000509 N-000510 N-000511
// spec: N-000512 N-000513 N-000514 N-000515 N-000516 N-000517 N-000518 N-000519 N-000520
// spec: N-000521 N-000522 N-000523 N-000524 N-000525 N-000526 N-000527 N-000528 N-000529
// spec: N-000530 N-000531 N-000532 N-000533 N-000534 N-000535 N-000536 N-000537 N-000538
// spec: N-000539 N-000540 N-000541 N-000542 N-000556 N-000557 N-000558 N-000559 N-000560
// spec: N-000561 N-000562 N-000563 N-000564 N-000565 N-000566 N-000567 N-000568 N-000569
// spec: N-000570 N-000571 N-000572 N-000573 N-000574 N-000575 N-000576 N-000577 N-000380
// spec: N-000381 N-000382 N-000383 N-000388 N-000903 N-000904 N-000905 N-000906 N-000907
// spec: N-000935 N-000936 N-000937 N-000938 N-000939 N-000940 N-000941 N-000942 N-000943
// spec: N-000944 N-000945 N-000946 N-000947 N-000948 N-000949 N-000950 N-000951 N-000909
// spec: N-000910 N-000911 N-000912 N-000913 N-000914 N-000915 N-000916 N-000917 N-000918
// spec: N-000919 N-000920 N-000921 N-000922 N-000923 N-000924 N-000925 N-000926 N-000927
// spec: N-000928 N-000929 N-000930 N-000931 N-000932 N-000933 N-000934 N-000993 N-000994

const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib.js');
const stats = require('./prosecheck-stats.js');

const SUBCOMMANDS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];

function formOf(namespaced) {
  return namespaced ? '/prosecheck:prosecheck' : '/prosecheck';
}

function helpReply(level) {
  return [
    'prosecheck is set to ' + level + '.',
    'Code, commits, config, and chat are never touched: the writing contract and the guard cover prose only.',
    '/prosecheck lite - turns on the writing contract without scoring saved files.',
    '/prosecheck full (default) - writing contract plus the saved-file guard, threshold 40.',
    '/prosecheck strict - writing contract plus the guard at threshold 20, with a cleanup scrub.',
    '/prosecheck off - disable prosecheck: no contract and no scoring until re-enabled.',
    '/prosecheck on - re-enable prosecheck at the full level (stores full).',
    '/prosecheck check <file> - scores one file out of 100 and reports only; it does not rewrite the file.',
    '/prosecheck doctor - health check of the install.',
    '/prosecheck stats - session token use and a score of the session prose.',
    '/prosecheck init - writes the writing contract to AGENTS.md for agents other than Claude Code.',
    '/prosecheck status - shows the stored level.',
    '/prosecheck show - lists the files scored in this session.',
    'For a deep rewrite, ask in plain language with "prosecheck this" or "humanize this".',
  ].join('\n');
}

function unknownReply(word) {
  return 'unknown subcommand "' + word + '". Valid words: ' + SUBCOMMANDS.join(', ') + '.';
}

// ---------------------------------------------------------------- doctor

function doctorReply(form) {
  const level = lib.effectiveLevel();
  const checks = [];
  let faulty = false;

  if (level === 'off') {
    checks.push('mode: off - prosecheck is switched off; this is not a fault of the install. Run /prosecheck on to switch it back on.');
  } else {
    checks.push('mode: ' + level + ' [OK]');
  }

  const script = lib.detectorPath();
  if (script) {
    checks.push('detector: bundled detector found in the plugin tree [OK]');
  } else {
    faulty = true;
    checks.push('detector: bundled detector not found in the plugin tree');
  }

  const sample = 'A short sample sentence for the health check. It is plain prose, written to be scored.';
  let pythonLine;
  const ran = script ? lib.runDetector([], 8000, sample) : { state: 'missing' };
  if (ran.state === 'missing') {
    faulty = true;
    pythonLine = 'python: there is no bundled detector to run, so no numeric score was produced.';
  } else if (ran.state === 'noPython') {
    faulty = true;
    pythonLine = 'python not found: Python is absent, so saved files will not be re-scored until Python is available. '
      + 'The writing contract still applies, so new prose is still shaped.';
  } else if (ran.state === 'timeout') {
    faulty = true;
    pythonLine = 'python: the scoring run timed out, so no numeric score was produced.';
  } else {
    const parsed = ran.status === 0 ? lib.parseReport(ran.stdout) : { ok: false };
    if (parsed.ok) {
      pythonLine = 'python: scoring run returned numeric score ' + parsed.score + ' [OK]';
    } else {
      faulty = true;
      pythonLine = 'python: the scoring run did not return a numeric score.';
    }
  }
  checks.push(pythonLine);

  const dir = lib.configDir();
  let writable = true;
  try {
    lib.ensureDir(dir);
    fs.accessSync(dir, fs.constants.W_OK);
  } catch (err) {
    writable = false;
  }
  if (writable) {
    checks.push('settings folder: writable [OK]');
  } else {
    faulty = true;
    checks.push('settings folder: not writable');
  }

  const lines = ['prosecheck health check'];
  for (const c of checks) {
    if (c) lines.push(c);
  }
  const modeOff = level === 'off';
  if (!faulty && !modeOff) {
    lines.push('prosecheck is active. Plain text up to ' + lib.PLAIN_CAP_KB + ' KB and archives up to '
      + lib.ARCHIVE_CAP_MB + ' MB are scored; the first ' + lib.WINDOW_TEXT
      + ' characters are scanned. Run ' + form + ' show to see files that were only partly scanned or skipped.');
  } else if (faulty) {
    lines.push('To fix the faulty checks above, then run /prosecheck doctor again.');
  } else {
    lines.push('The install is healthy. In this mode saved files are not scored; run ' + form
      + ' on to turn scoring back on.');
  }
  return lines.join('\n');
}

// ---------------------------------------------------------------- check

function unquotePath(raw) {
  let p = String(raw || '').trim();
  if (p.startsWith('@')) p = p.slice(1);
  if (p.length >= 2 && (p[0] === '"' || p[0] === "'") && p[p.length - 1] === p[0]) {
    p = p.slice(1, -1);
  }
  return p;
}

function checkReply(rest, baseDir) {
  const typed = unquotePath(rest);
  if (!typed) {
    return 'check needs a file path: /prosecheck check <file>. Nothing was scored.';
  }
  const abs = path.resolve(baseDir || process.cwd(), typed);
  const base = path.basename(abs);
  let st;
  try {
    st = fs.statSync(abs);
  } catch (err) {
    return 'cannot read ' + typed + ': no such file.';
  }
  if (st.isDirectory()) {
    return typed + ' is not a file.';
  }
  const ext = path.extname(abs).toLowerCase();
  if (lib.BINARY_EXTS.has(ext)) {
    return base + ': no readable text in this format.';
  }
  const cap = lib.capFor(abs);
  if (st.size > cap.bytes) {
    return base + ': over ' + cap.kb + ' KB limit; it was not scored.';
  }
  const res = lib.analyzeFile(abs, cap.timeout);
  if (res.ok) {
    const lines = [];
    lines.push(base + ' - ' + lib.phraseFor(res.band) + ' (score ' + res.score + '/100, band: ' + res.band + ')');
    let conf = 'confidence: ' + res.confidence;
    if (res.confidence !== 'high' && res.reason) conf += ' - ' + res.reason;
    lines.push(conf);
    if (res.truncated) lines.push('coverage: first ' + lib.WINDOW_TEXT + ' characters only');
    if (res.findings.length) {
      const tells = res.findings.slice(0, 8).map((f) => f.label + ' (x' + f.count + ')');
      lines.push('tells: ' + tells.join('; '));
    } else {
      lines.push('tells: none');
    }
    lines.push('This is a report only; the file was not changed.');
    return lines.join('\n');
  }
  switch (res.why) {
    case 'noPython':
      return 'detector unavailable: Python was not found, so ' + base + ' was not scored.';
    case 'timeout':
      return base + ': detector failed (timed out).';
    case 'unreadable':
      return 'cannot read ' + base + '.';
    case 'notReport':
    case 'noScore':
      return 'no report from the detector.';
    default:
      if (res.exitStatus !== undefined && res.exitStatus !== 0) {
        const why = res.stderr ? res.stderr : 'exit status ' + res.exitStatus;
        return base + ': detector failed (' + why + ').';
      }
      return base + ' - no report from the detector.';
  }
}

// ---------------------------------------------------------------- show

function showReply(sessionId, form) {
  const rows = lib.readLedger(sessionId).slice().reverse();
  if (!rows.length) {
    return 'nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const lines = ['prosecheck ledger for this session, newest first:'];
  for (const r of rows) {
    if (r.status === 'scored') {
      let body = lib.phraseFor(r.band) + ' (score ' + r.score + '/' + r.band
        + (r.truncated ? ', first ' + lib.WINDOW_TEXT + ' characters only' : '') + ')';
      const labels = Array.isArray(r.labels) ? r.labels.slice(0, 5) : [];
      if (labels.length) {
        body += ' - ' + (r.flagged ? 'flagged' : 'under threshold') + ': ' + labels.join('; ');
      }
      lines.push(r.base + ' - ' + body);
    } else if (r.status === 'skipped') {
      lines.push(r.base + ' - not scored: over the ' + r.cap + ' KB limit');
    } else if (r.status === 'binary') {
      lines.push(r.base + ' - not re-scored: binary format');
    } else {
      lines.push(r.base + ' - not scored: ' + (r.reason || 'the file could not be scored'));
    }
  }
  return lines.join('\n');
}

// ---------------------------------------------------------------- init

function initReply(form, level, cwd) {
  if (level === 'off') {
    return 'prosecheck is switched off, so no files were written. Run ' + form + ' on to allow the export.';
  }
  const out = [];
  const agents = path.join(cwd, 'AGENTS.md');
  const section = lib.contractText(level, { exported: true });
  let existing = null;
  let readable = true;
  try {
    existing = fs.readFileSync(agents, 'utf8');
  } catch (err) {
    if (err.code !== 'ENOENT') {
      readable = false;
      out.push('cannot read AGENTS.md: ' + err.message + '; it was not changed.');
    }
  }
  if (readable) {
    if (existing !== null && existing.indexOf('## Prose writing contract') !== -1) {
      out.push('AGENTS.md already contains the prosecheck contract; it was left unchanged.');
    } else {
      let next;
      if (existing === null) {
        next = section;
      } else {
        next = existing + (existing.endsWith('\n') ? '\n' : '\n\n') + section;
      }
      try {
        fs.writeFileSync(agents, next, 'utf8');
        out.push('Wrote the prosecheck writing contract to AGENTS.md.');
      } catch (err) {
        out.push('cannot write AGENTS.md: ' + err.message);
      }
    }
  }
  const dest = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(dest)) {
    out.push('The Cursor rule prosecheck.mdc is already present; it was left unchanged.');
  } else {
    const src = lib.cursorRuleSource();
    try {
      const body = fs.readFileSync(src);
      lib.ensureDir(path.dirname(dest));
      fs.writeFileSync(dest, body);
      out.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (err) {
      out.push('cannot write .cursor/rules/prosecheck.mdc: ' + err.message);
    }
  }
  return out.join('\n');
}

// ---------------------------------------------------------------- router

function setLevelReply(word) {
  if (word === 'lite') return 'prosecheck level set to lite: the writing contract is on; saved files are not scored.';
  if (word === 'full') return 'prosecheck level set to full (default): the writing contract is on and saved files are scored with threshold 40.';
  return 'prosecheck level set to strict: the writing contract is on; saved files are scored with threshold 20 and the cleanup scrub applies.';
}

function route(prompt, input) {
  const trimmed = prompt.trim();
  const lower = trimmed.toLowerCase();
  const sessionId = input.session_id;

  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    lib.writeStoredLevel('off');
    return { block: 'prosecheck is off. Nothing is scored and no contract is added until you run /prosecheck on.' };
  }

  const m = /^\/prosecheck(:prosecheck)?(?=\s|$)([\s\S]*)$/.exec(trimmed);
  if (!m) return null;
  const form = formOf(!!m[1]);
  const tokens = m[2].trim().split(/\s+/).filter(Boolean);
  const sub = tokens.length ? tokens[0].toLowerCase() : 'help';
  const rawRest = m[2].trim().replace(/^\S+\s*/, '');

  if (sub === 'lite' || sub === 'full' || sub === 'strict') {
    lib.writeStoredLevel(sub);
    return { block: setLevelReply(sub) };
  }
  if (sub === 'off') {
    lib.writeStoredLevel('off');
    return { block: 'prosecheck is off. Nothing is scored and no contract is added until you run ' + form + ' on.' };
  }
  if (sub === 'on') {
    lib.writeStoredLevel('full');
    return { block: 'prosecheck is on at full: the writing contract is on and saved files are scored with threshold 40.' };
  }
  if (sub === 'status') {
    return { block: 'prosecheck level: ' + lib.effectiveLevel() };
  }
  if (sub === 'help') {
    return { block: helpReply(lib.effectiveLevel()) };
  }
  if (sub === 'show') {
    return { block: showReply(sessionId, form) };
  }
  if (sub === 'check') {
    const baseDir = typeof input.cwd === 'string' && path.isAbsolute(input.cwd) ? input.cwd : process.cwd();
    return { block: checkReply(rawRest, baseDir) };
  }
  if (sub === 'doctor') {
    return { block: doctorReply(form) };
  }
  if (sub === 'init') {
    const cwd = typeof input.cwd === 'string' && path.isAbsolute(input.cwd) && fs.existsSync(input.cwd)
      ? input.cwd : process.cwd();
    return { block: initReply(form, lib.effectiveLevel(), cwd) };
  }
  if (sub === 'stats') {
    return { block: stats.statsReply(input, lib.effectiveLevel()) };
  }
  return { block: unknownReply(tokens[0]) };
}

function reminder(level) {
  return 'prosecheck (level ' + level + '): prose deliverables follow the writing contract; '
    + 'code, config, and commits are untouched.';
}

function main() {
  const input = lib.readStdinJson();
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  try {
    const result = route(prompt, input);
    if (result) {
      lib.blockReply(result.block);
    } else {
      const level = lib.effectiveLevel();
      if (level !== 'off') {
        lib.emitJson({
          hookSpecificOutput: {
            hookEventName: 'UserPromptSubmit',
            additionalContext: reminder(level),
          },
        });
      }
    }
  } catch (err) {
    // A hook must not fail the host session.
  }
  process.exitCode = 0;
}

if (require.main === module) {
  main();
}

module.exports = { route, helpReply, checkReply, showReply, doctorReply, initReply, unquotePath, SUBCOMMANDS };
