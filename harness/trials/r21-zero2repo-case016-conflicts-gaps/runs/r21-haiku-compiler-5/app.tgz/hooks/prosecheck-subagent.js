#!/usr/bin/env node
'use strict';
// subagent-start hook: returns the same writing contract inside the subagent envelope.
// spec: N-000384 N-000385 N-000813 N-000814 N-000815 N-000816 N-000817 N-000818 N-000386 N-000387 N-000388 N-000730

const lib = require('./prosecheck-lib.js');

function main() {
  lib.readStdinJson();
  try {
    const level = lib.effectiveLevel();
    if (level !== 'off') {
      lib.emitJson({
        hookSpecificOutput: {
          hookEventName: 'SubagentStart',
          additionalContext: lib.contractText(level, { detector: lib.detectorPath() }),
        },
      });
    }
  } catch (err) {
    // a hook must not fail the host session
  }
  process.exitCode = 0;
}

main();
