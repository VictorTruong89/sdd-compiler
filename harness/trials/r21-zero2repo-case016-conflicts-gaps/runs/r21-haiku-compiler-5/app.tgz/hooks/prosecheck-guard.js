#!/usr/bin/env node
'use strict';
// post-tool-use hook: scores a just-saved prose file and nudges when it is flagged.
// spec: N-000395 N-000396 N-000397 N-000398 N-000399 N-000400 N-000401 N-000402 N-000403
// spec: N-000404 N-000405 N-000406 N-000407 N-000408 N-000409 N-000410 N-000411 N-000412
// spec: N-000413 N-000414 N-000415 N-000416 N-000417 N-000418 N-000419 N-000420 N-000421
// spec: N-000422 N-000423 N-000424 N-000425 N-000426 N-000427 N-000428 N-000429 N-000430
// spec: N-000431 N-000432 N-000433 N-000434 N-000435 N-000436 N-000437 N-000438 N-000439
// spec: N-000440 N-000441 N-000442 N-000443 N-000444 N-000445 N-000446 N-000447 N-000448
// spec: N-000449 N-000450 N-000451 N-000452 N-000453 N-000454 N-000455 N-000456 N-000820
// spec: N-000821 N-000822 N-000823 N-000824 N-000825 N-000826 N-000827 N-000828 N-000829
// spec: N-000830 N-000831 N-000832 N-000833 N-000834 N-000835 N-000843 N-000844 N-000845 N-000846

const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib.js');

const TOOLS = new Set(['Write', 'Edit', 'MultiEdit', 'NotebookEdit', 'apply_patch']);
const PATCH_LINE = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/gm;
const SKIP_SEGMENTS = new Set(['node_modules', '.git']);
const MAX_LABELS = 5;

function pathsFromPayload(input) {
  const tool = input.tool_name;
  if (!TOOLS.has(tool)) return [];
  const ti = input.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  const cwd = typeof input.cwd === 'string' && input.cwd.trim() ? input.cwd.trim() : process.cwd();
  const raw = [];
  if (tool === 'apply_patch') {
    const body = typeof ti.command === 'string' ? ti.command : (typeof ti.patch === 'string' ? ti.patch : '');
    let m;
    PATCH_LINE.lastIndex = 0;
    while ((m = PATCH_LINE.exec(body)) !== null) {
      const p = m[1].trim();
      if (p) raw.push(p);
    }
  } else if (tool === 'NotebookEdit') {
    if (typeof ti.notebook_path === 'string' && ti.notebook_path.trim()) raw.push(ti.notebook_path.trim());
    else if (typeof ti.file_path === 'string' && ti.file_path.trim()) raw.push(ti.file_path.trim());
  } else if (typeof ti.file_path === 'string' && ti.file_path.trim()) {
    raw.push(ti.file_path.trim());
  }
  const out = [];
  const seen = new Set();
  for (const p of raw) {
    const abs = path.resolve(cwd, p);
    if (!seen.has(abs)) {
      seen.add(abs);
      out.push(abs);
    }
    if (out.length >= lib.MAX_GUARD_PATHS) break;
  }
  return out;
}

function skipPath(abs) {
  const segments = abs.split(/[\\/]/);
  if (segments.some((s) => SKIP_SEGMENTS.has(s))) return true;
  if (lib.isInside(abs, lib.pluginRoot())) return true;
  return false;
}

// Returns the nudge line for this file (or null) and records the attempt.
function guardOne(abs, level, sessionId) {
  if (skipPath(abs)) return null;
  const kind = lib.fileKind(abs);
  if (kind === 'skip' || kind === 'other') return null;
  const info = lib.classify(abs);
  let st;
  try {
    st = fs.statSync(abs);
  } catch (err) {
    lib.appendLedger(sessionId, { base: info.base, status: 'failed', reason: lib.REASON.unreadable });
    return null;
  }
  if (!st.isFile()) return null;
  if (kind === 'binary') {
    lib.appendLedger(sessionId, { base: info.base, status: 'binary' });
    return null;
  }
  const cap = lib.capFor(abs);
  if (st.size > cap.bytes) {
    lib.appendLedger(sessionId, { base: info.base, status: 'skipped', cap: cap.kb });
    return null;
  }
  const res = lib.analyzeFile(abs, cap.timeout);
  if (!res.ok) {
    lib.appendLedger(sessionId, { base: info.base, status: 'failed', reason: res.message });
    return null;
  }
  const threshold = lib.thresholdFor(level);
  const flagged = res.score > threshold;
  const labels = res.findings.map((f) => f.label).slice(0, MAX_LABELS);
  lib.appendLedger(sessionId, {
    base: info.base,
    status: 'scored',
    score: res.score,
    band: res.band,
    labels,
    flagged,
    truncated: res.truncated,
  });
  if (!flagged) return null;
  const coverage = res.truncated ? ', first ' + lib.WINDOW_TEXT + ' characters only' : '';
  const labelText = labels.length ? labels.join('; ') : 'none';
  return 'prosecheck: ' + info.base + ' ' + lib.phraseFor(res.band) + ' (score ' + res.score + ', band '
    + res.band + coverage + '). Flagged: ' + labelText + '. Please fix the flagged spans.';
}

function main() {
  const input = lib.readStdinJson();
  try {
    const level = lib.effectiveLevel();
    if (level === 'off' || level === 'lite') return;
    const paths = pathsFromPayload(input);
    if (!paths.length) return;
    const sessionId = input.session_id;
    const lines = [];
    for (const abs of paths) {
      const line = guardOne(abs, level, sessionId);
      if (line) lines.push(line);
    }
    if (lines.length) {
      lib.emitJson({
        hookSpecificOutput: {
          hookEventName: 'PostToolUse',
          additionalContext: lines.join('\n'),
        },
      });
    }
  } catch (err) {
    // a hook must not fail the host session
  } finally {
    process.exitCode = 0;
  }
}

main();
