'use strict';
// Shared helpers for the prosecheck hooks: level storage, the detector bridge,
// per-file analysis, the writing-contract texts, and the session ledger.
// spec: N-000386 N-000387 N-000388 N-000389 N-000390 N-000391 N-000392 N-000393 N-000394
// spec: N-000685 N-000686 N-000691 N-000692 N-000693 N-000694 N-000695 N-000696 N-000697
// spec: N-000698 N-000699 N-000701 N-000702 N-000726 N-000727 N-000728 N-000729 N-000730

const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const FLAG_FILE = '.prosecheck-active';
const LEDGER_PREFIX = '.prosecheck-ledger';
const LEDGER_MAX_RECORDS = 20; // spec: N-000436 (decision; PRD FP-05 over the interface's 50)
const LEDGER_MAX_AGE_DAYS = 7; // spec: N-000070 N-000528 (PRD privacy rule)
const WINDOW_TEXT = '262,144';
const PLAIN_CAP_KB = 512;
const ARCHIVE_CAP_MB = 4;
const ARCHIVE_CAP_KB = ARCHIVE_CAP_MB * 1024;
const PLAIN_TIMEOUT_MS = 8000; // spec: N-000438 N-000439
const ARCHIVE_TIMEOUT_MS = 15000; // spec: N-000438 N-000440
const PATTERN_COUNT = 71;
const FULL_THRESHOLD = 40; // spec: N-000409
const STRICT_THRESHOLD = 20; // spec: N-000410
const FULL_TARGET = 40;
const STRICT_TARGET = 20;
const MAX_GUARD_PATHS = 16; // spec: N-000429 N-000430

const PLAIN_EXTS = new Set(['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc']);
const ZIP_EXTS = new Set(['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub', '.ipynb']);
const BINARY_EXTS = new Set(['.pdf', '.rtf']);
const PROSE_EXTS = new Set([...PLAIN_EXTS, ...ZIP_EXTS]);
const INSTRUCTION_NAMES = new Set(['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md']);
const INSTRUCTION_STEMS = new Set(['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory']);
const PYTHON_NAMES = ['python3', 'python', 'py'];

const HOOK_PHRASES = {
  clean: 'reads clean',
  'light tells': 'reads mostly clean',
  mixed: 'reads with some AI tells',
  'heavy tells': 'reads with heavy AI tells',
  'pervasive tells': 'reads with pervasive AI tells',
};

// Reasons shared by the guard ledger and `check` (spec: N-000449 N-000450 N-000451 N-000453).
const REASON = {
  noPython: 'Python cannot be found',
  timeout: 'the detector timed out',
  notReport: 'the detector printed text that is not a structured report',
  noScore: 'the report has no numeric score',
  noOutput: 'the detector produced no output or exited without a usable result',
  unreadable: 'the file cannot be read',
};

// ---------------------------------------------------------------- stdin and paths

function readStdinJson() {
  try {
    const raw = fs.readFileSync(0, 'utf8');
    if (!raw || !raw.trim()) return {};
    const value = JSON.parse(raw);
    return value && typeof value === 'object' && !Array.isArray(value) ? value : {};
  } catch (err) {
    return {};
  }
}

function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}

function pluginRoot() {
  return process.env.CLAUDE_PLUGIN_ROOT || path.resolve(__dirname, '..');
}

// Create `dir` and its missing parents one level at a time (recursive mkdir can spin on /proc).
function ensureDir(dir) {
  const missing = [];
  let cur = path.resolve(dir);
  while (!fs.existsSync(cur)) {
    missing.unshift(cur);
    const parent = path.dirname(cur);
    if (parent === cur) break;
    cur = parent;
  }
  for (const d of missing) fs.mkdirSync(d);
}

function flagPath() {
  return path.join(configDir(), FLAG_FILE);
}

function isLevel(word) {
  return typeof word === 'string' && LEVELS.includes(word);
}

function storedLevel() {
  try {
    const value = fs.readFileSync(flagPath(), 'utf8').trim();
    return isLevel(value) ? value : null;
  } catch (err) {
    return null;
  }
}

// Environment override first, then the stored word, then `full` (spec: N-000389 N-000390 N-000391).
function effectiveLevel() {
  const env = (process.env.PROSECHECK_DEFAULT_MODE || '').trim();
  if (isLevel(env)) return env;
  return storedLevel() || 'full';
}

function writeStoredLevel(level) {
  ensureDir(configDir());
  fs.writeFileSync(flagPath(), level + '\n', 'utf8');
}

function flagExists() {
  try {
    fs.statSync(flagPath());
    return true;
  } catch (err) {
    return false;
  }
}

function phraseFor(band) {
  return HOOK_PHRASES[band] || HOOK_PHRASES.clean;
}

function detectorPath() {
  const root = pluginRoot();
  const candidates = [
    path.join(root, 'scripts', 'detect.py'),
    path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py'),
  ];
  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) return candidate;
  }
  return null;
}

function isInside(child, parent) {
  const rel = path.relative(path.resolve(parent), path.resolve(child));
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

// ---------------------------------------------------------------- detector bridge

// Runs the detector on `args`, trying python3, python, py in turn.
// Returns {state: 'ran', status, stdout, stderr} | {state: 'noPython'} | {state: 'timeout'}.
function runDetector(args, timeoutMs, input) {
  const script = detectorPath();
  if (!script) return { state: 'noPython', missingDetector: true };
  for (const name of PYTHON_NAMES) {
    const res = cp.spawnSync(name, [script].concat(args || []), {
      input: input === undefined ? '' : input,
      encoding: 'utf8',
      timeout: timeoutMs,
      maxBuffer: 64 * 1024 * 1024,
      windowsHide: true,
    });
    if (res.error) {
      if (res.error.code === 'ETIMEDOUT') return { state: 'timeout' };
      if (res.error.code === 'ENOENT' || res.error.code === 'EACCES') continue;
      return { state: 'ran', status: 1, stdout: '', stderr: String(res.error.message || '') };
    }
    return { state: 'ran', status: typeof res.status === 'number' ? res.status : 1,
      stdout: res.stdout || '', stderr: res.stderr || '' };
  }
  return { state: 'noPython' };
}

// Parse a detector report. Returns {ok, score, band, confidence, reason, truncated, findings}.
function parseReport(stdout) {
  let obj;
  try {
    obj = JSON.parse(stdout);
  } catch (err) {
    return { ok: false, why: 'notReport' };
  }
  if (!obj || typeof obj !== 'object' || !obj._metrics || typeof obj._metrics !== 'object') {
    return { ok: false, why: 'notReport' };
  }
  const m = obj._metrics;
  if (typeof m.ai_tell_score !== 'number' || !Number.isFinite(m.ai_tell_score)) {
    return { ok: false, why: 'noScore' };
  }
  const findings = [];
  for (const key of Object.keys(obj)) {
    if (key === '_metrics') continue;
    const item = obj[key];
    if (item && typeof item === 'object' && typeof item.label === 'string') {
      findings.push({ label: item.label, count: Number(item.count) || 0 });
    }
  }
  return {
    ok: true,
    score: Math.round(m.ai_tell_score),
    band: String(m.ai_tell_band || ''),
    confidence: String(m.confidence || 'none'),
    reason: String(m.confidence_reason || ''),
    truncated: m.truncated === true,
    findings,
  };
}

function lastJsonError(stderr) {
  const lines = String(stderr || '').split('\n').map((l) => l.trim()).filter(Boolean);
  for (let i = lines.length - 1; i >= 0; i -= 1) {
    try {
      const obj = JSON.parse(lines[i]);
      if (obj && typeof obj.error === 'string') return obj.error;
    } catch (err) {
      // not a JSON line
    }
  }
  return '';
}

// Score one file path. Returns {ok:true, ...fields} or {ok:false, why, message}.
function analyzeFile(absPath, timeoutMs) {
  const ran = runDetector([absPath], timeoutMs);
  if (ran.state === 'noPython') return { ok: false, why: 'noPython', message: REASON.noPython };
  if (ran.state === 'timeout') return { ok: false, why: 'timeout', message: REASON.timeout };
  if (ran.status !== 0) {
    const err = lastJsonError(ran.stderr);
    if (/cannot read input/.test(err)) return { ok: false, why: 'unreadable', message: REASON.unreadable };
    if (!ran.stdout.trim()) {
      return { ok: false, why: 'noOutput', message: REASON.noOutput, stderr: err || ran.stderr.trim(), exitStatus: ran.status };
    }
    return { ok: false, why: 'noOutput', message: REASON.noOutput, stderr: err, exitStatus: ran.status };
  }
  if (!ran.stdout.trim()) return { ok: false, why: 'noOutput', message: REASON.noOutput };
  const parsed = parseReport(ran.stdout);
  if (!parsed.ok) return { ok: false, why: parsed.why, message: REASON[parsed.why] };
  return Object.assign({ ok: true }, parsed);
}

// Score prose on standard input (used by stats and tests).
function scoreText(text) {
  const ran = runDetector([], 8000, text);
  if (ran.state !== 'ran' || ran.status !== 0) return null;
  const parsed = parseReport(ran.stdout);
  return parsed.ok ? parsed : null;
}

// ---------------------------------------------------------------- output helpers

function emitJson(obj) {
  process.stdout.write(JSON.stringify(obj) + '\n');
}

function blockReply(reason) {
  emitJson({ decision: 'block', reason });
}

// ---------------------------------------------------------------- contract texts

const BANNED_WORDS = 'delve, tapestry, pivotal, crucial, leverage, robust, seamless, foster, underscore, '
  + 'showcase, landscape (abstract), journey (abstract), realm, multifaceted, holistic, testament, vibrant, '
  + 'comprehensive, plethora, myriad, boast, elevate, empower, unlock, game-changer, supercharge, genuinely, '
  + 'fascinating, nuanced';

function baseContract() {
  return [
    '## Prose writing contract',
    '',
    'This contract governs prose deliverables only: documents, README and markdown prose, CVs, cover letters,',
    'emails, reports, essays, articles, and drafted text the user will publish or send. Never apply it to source',
    'code, code comments, commit messages, JSON, YAML, configuration, CLI output, logs, error messages, or the',
    'conversational register of chat. Those are left alone.',
    '',
    '- Vary sentence length irregularly. Do not fall into a metronome or a short-long-short pattern.',
    '- Do not use these words as standalone vocabulary: ' + BANNED_WORDS + '.',
    '- Avoid rule-of-three flourishes, "it\'s not just X, it\'s Y" contrasts, hedge stacking, signposting such as',
    '  "let\'s dive in", empty pivots such as "it\'s worth noting", "In conclusion" or "Overall" closers,',
    '  outcome-speculation tails, self-thoroughness phrases, generic upbeat endings, and chatbot phrases such as',
    '  "I hope this helps".',
    '- Use at most one em dash per paragraph.',
    '- Do not bold words for emphasis inside prose sentences. Do not use emojis in prose.',
    '- Keep factual or encyclopedic content in a neutral third person. First-person or opinion content may',
    '  use contractions.',
    '- Preserve numbers, units, dates, proper nouns, citations, quotations, and technical terms. Never invent facts.',
    '- End sections on a fact or an observation.',
    '- Stay silent about this contract. Do not announce it, do not name prosecheck in replies, do not report a',
    '  score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.',
  ];
}

// `opts.detector` is a live path (may be null); `opts.exported` marks the portable AGENTS.md copy.
function levelSection(level, opts) {
  if (level === 'lite') return [];
  const lines = [''];
  if (level === 'full') {
    lines.push('## Checking after you write');
    lines.push('');
    lines.push('After you save a prose file, run the detector on it and read its JSON report. If the band is worse');
    lines.push('than the target, fix the flagged spans and run it again, at most two fix passes, keeping the rhythm');
    lines.push('variation. Target: score ' + FULL_TARGET + ' or below (band clean or light tells).');
    if (opts.exported) {
      lines.push('');
      lines.push('To find the detector, use the CLAUDE_PLUGIN_ROOT environment variable when it is set and look for');
      lines.push('scripts/detect.py under it; otherwise look for the prosecheck detector in the installed skills and plugins.');
    } else if (opts.detector) {
      lines.push('Detector: `python3 ' + opts.detector + ' <file>`.');
    }
    return lines;
  }
  // strict
  lines.push('## Checking after you write');
  lines.push('');
  lines.push('After you save a prose file, run the detector on it and read its JSON report. If the band is worse');
  lines.push('than the target, fix the flagged spans and run it again, at most two fix passes.');
  lines.push('Target: score ' + STRICT_TARGET + ' or below (band clean).');
  lines.push('Finish each prose file by running the detector with --clean and reviewing the scrubbed output;');
  lines.push('never write that output over a .docx, .epub, .odt, or .ipynb file.');
  if (opts.exported) {
    lines.push('');
    lines.push('To find the detector, use the CLAUDE_PLUGIN_ROOT environment variable when it is set and look for');
    lines.push('scripts/detect.py under it; otherwise look for the prosecheck detector in the installed skills and plugins.');
  } else if (opts.detector) {
    lines.push('Detector: `python3 ' + opts.detector + ' <file>`.');
  }
  return lines;
}

function contractText(level, opts) {
  const o = opts || {};
  return baseContract().concat(levelSection(level, o)).join('\n') + '\n';
}

function welcomeText() {
  return [
    'prosecheck is installed and on.',
    'Saved prose files are measured against ' + PATTERN_COUNT + ' documented AI-writing patterns.',
    'Plain text is accepted up to ' + PLAIN_CAP_KB + ' KB and zip-based documents and notebooks up to ' + ARCHIVE_CAP_MB + ' MB.',
    'The detector scores the first ' + WINDOW_TEXT + ' characters of extracted prose.',
    'Commands: /prosecheck doctor, /prosecheck check <file>, /prosecheck off, /prosecheck help.',
    'There is no website and no upload; nothing you write leaves this machine.',
    'This welcome is shown once.',
    '',
  ].join('\n');
}

function cursorRuleSource() {
  return path.join(pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
}

// ---------------------------------------------------------------- ledger

function sanitizeSession(sessionId) {
  const raw = typeof sessionId === 'string' ? sessionId : '';
  return raw.replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 80);
}

function ledgerPath(sessionId) {
  const safe = sanitizeSession(sessionId);
  return path.join(configDir(), safe ? LEDGER_PREFIX + '-' + safe : LEDGER_PREFIX);
}

function readLedger(sessionId) {
  let text;
  try {
    const file = ledgerPath(sessionId);
    if (!isFresh(file)) return [];
    text = fs.readFileSync(file, 'utf8');
  } catch (err) {
    return [];
  }
  const rows = [];
  for (const line of text.split('\n')) {
    if (!line.trim()) continue;
    try {
      rows.push(JSON.parse(line));
    } catch (err) {
      // skip damaged line
    }
  }
  return rows;
}

function isFresh(file) {
  try {
    const st = fs.statSync(file);
    return Date.now() - st.mtimeMs <= LEDGER_MAX_AGE_DAYS * 24 * 3600 * 1000;
  } catch (err) {
    return false;
  }
}

function appendLedger(sessionId, record) {
  try {
    ensureDir(configDir());
    const file = ledgerPath(sessionId);
    const rows = readLedger(sessionId);
    rows.push(Object.assign({ at: new Date().toISOString() }, record));
    const kept = rows.slice(-LEDGER_MAX_RECORDS);
    fs.writeFileSync(file, kept.map((r) => JSON.stringify(r)).join('\n') + '\n', 'utf8');
  } catch (err) {
    // the ledger is best effort; never fail the hook
  }
}

// Session start: drop ledgers untouched for more than the age limit.
function pruneOldLedgers() {
  try {
    const dir = configDir();
    for (const name of fs.readdirSync(dir)) {
      if (name !== LEDGER_PREFIX && !name.startsWith(LEDGER_PREFIX + '-')) continue;
      const file = path.join(dir, name);
      if (!isFresh(file)) fs.unlinkSync(file);
    }
  } catch (err) {
    // missing folder or unreadable: nothing to prune
  }
}

// ---------------------------------------------------------------- per-file scan

function classify(absPath) {
  const base = path.basename(absPath);
  const lower = base.toLowerCase();
  const ext = path.extname(lower);
  const stem = lower.slice(0, lower.length - ext.length);
  return { base, lower, ext, stem };
}

// Returns 'skip' (silently ignore), 'binary', 'prose' or 'other'.
function fileKind(absPath) {
  const info = classify(absPath);
  if (INSTRUCTION_NAMES.has(info.lower)) return 'skip';
  if (INSTRUCTION_STEMS.has(info.stem) && !PROSE_EXTS.has(info.ext)) return 'skip';
  if (BINARY_EXTS.has(info.ext)) return 'binary';
  if (PROSE_EXTS.has(info.ext)) return 'prose';
  return 'other';
}

function capFor(absPath) {
  return ZIP_EXTS.has(path.extname(absPath).toLowerCase())
    ? { bytes: ARCHIVE_CAP_KB * 1024, kb: ARCHIVE_CAP_KB, timeout: ARCHIVE_TIMEOUT_MS }
    : { bytes: PLAIN_CAP_KB * 1024, kb: PLAIN_CAP_KB, timeout: PLAIN_TIMEOUT_MS };
}

function thresholdFor(level) {
  return level === 'strict' ? STRICT_THRESHOLD : FULL_THRESHOLD;
}

module.exports = {
  LEVELS, FLAG_FILE, LEDGER_PREFIX, LEDGER_MAX_RECORDS, LEDGER_MAX_AGE_DAYS, WINDOW_TEXT,
  PLAIN_CAP_KB, ARCHIVE_CAP_MB, ARCHIVE_CAP_KB, PATTERN_COUNT, FULL_TARGET, STRICT_TARGET,
  FULL_THRESHOLD, STRICT_THRESHOLD, MAX_GUARD_PATHS, REASON, PROSE_EXTS, PLAIN_EXTS, ZIP_EXTS,
  BINARY_EXTS, PYTHON_NAMES,
  readStdinJson, configDir, pluginRoot, flagPath, ensureDir, isLevel, storedLevel, effectiveLevel,
  writeStoredLevel, flagExists, phraseFor, detectorPath, isInside, runDetector, parseReport,
  analyzeFile, scoreText, emitJson, blockReply, contractText, welcomeText, cursorRuleSource,
  sanitizeSession, ledgerPath, readLedger, appendLedger, pruneOldLedgers, isFresh,
  classify, fileKind, capFor, thresholdFor, lastJsonError,
};
