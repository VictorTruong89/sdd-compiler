#!/usr/bin/env node
'use strict';
// session-start hook: places the writing contract (and, once, the welcome) in context.
// spec: N-000332 N-000335 N-000336 N-000337 N-000370 N-000371 N-000372 N-000373 N-000374
// spec: N-000375 N-000376 N-000377 N-000378 N-000379 N-000384 N-000385 N-000386 N-000387
// spec: N-000388 N-000389 N-000390 N-000391 N-000393 N-000394 N-000790 N-000791 N-000792
// spec: N-000793 N-000794 N-000795 N-000796 N-000797 N-000798 N-000799 N-000800 N-000801
// spec: N-000802 N-000803 N-000804 N-000805 N-000806 N-000807 N-000808 N-000809 N-000810
// spec: N-000811 N-000812 N-000788 N-000789 N-000730

const lib = require('./prosecheck-lib.js');

function main() {
  lib.readStdinJson();
  try {
    lib.pruneOldLedgers();
    const fresh = !lib.flagExists();
    const level = lib.effectiveLevel();
    if (level !== 'off') {
      if (lib.storedLevel() !== level) lib.writeStoredLevel(level);
      const detector = lib.detectorPath();
      const parts = [];
      if (fresh) parts.push(lib.welcomeText());
      parts.push(lib.contractText(level, { detector }));
      process.stdout.write(parts.join('\n'));
    }
  } catch (err) {
    // a hook must not fail the host session
  }
  process.exitCode = 0;
}

main();
