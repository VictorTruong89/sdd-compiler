#!/usr/bin/env node
'use strict';
// `/prosecheck stats`: token figures from the session transcript and a score of the
// session's own prose. Also runnable directly: it reads the host JSON and prints a block reply.
// spec: N-000543 N-000544 N-000545 N-000546 N-000547 N-000548 N-000549 N-000550 N-000551
// spec: N-000552 N-000553 N-000554 N-000555 N-001103 N-001104 N-001105 N-001106 N-001107
// spec: N-001108 N-001109 N-001110 N-001111 N-001112 N-001113 N-001114 N-001115 N-001116
// spec: N-001117 N-001118 N-001119 N-001120 N-001121 N-001122 N-001123 N-001124 N-001125 N-001126

const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib.js');

const PROSE_WINDOW = 40000; // spec: N-000549 (last 40,000 characters of the prose slice)
const SCORE_MIN_CHARS = 500; // spec: N-001115 (score line only above 500 characters)

// Newest .jsonl transcript under <config>/projects (searched a few folders deep).
function newestTranscript() {
  const root = path.join(lib.configDir(), 'projects');
  let best = null;
  function walk(dir, depth) {
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (err) {
      return;
    }
    for (const entry of entries) {
      const full = path.join(dir, entry.name);
      if (entry.isDirectory() && depth < 3) {
        walk(full, depth + 1);
      } else if (entry.isFile() && entry.name.endsWith('.jsonl')) {
        try {
          const mtime = fs.statSync(full).mtimeMs;
          if (!best || mtime > best.mtime) best = { file: full, mtime };
        } catch (err) {
          // ignore unreadable entry
        }
      }
    }
  }
  walk(root, 0);
  return best ? best.file : null;
}

function resolveTranscript(input) {
  if (typeof input.transcript_path === 'string' && input.transcript_path.trim()) {
    return input.transcript_path.trim();
  }
  return newestTranscript();
}

// Reads assistant rows. Returns null when the file cannot be read.
function readAssistant(file) {
  let text;
  try {
    text = fs.readFileSync(file, 'utf8');
  } catch (err) {
    return null;
  }
  const seen = new Set();
  let turns = 0;
  let outputTokens = 0;
  let cacheRead = 0;
  const texts = [];
  for (const line of text.split('\n')) {
    if (!line.trim()) continue;
    let row;
    try {
      row = JSON.parse(line);
    } catch (err) {
      continue;
    }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const id = typeof msg.id === 'string' ? msg.id : null;
    if (id) {
      if (seen.has(id)) continue;
      seen.add(id);
    }
    turns += 1;
    const usage = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    outputTokens += Number(usage.output_tokens) || 0;
    cacheRead += Number(usage.cache_read_input_tokens) || 0;
    if (Array.isArray(msg.content)) {
      for (const part of msg.content) {
        if (part && part.type === 'text' && typeof part.text === 'string') texts.push(part.text);
      }
    }
  }
  return { turns, outputTokens, cacheRead, texts };
}

function proseSlice(texts) {
  let joined = texts.join('\n');
  joined = joined.replace(/```[\s\S]*?```/g, ' ').replace(/~~~[\s\S]*?~~~/g, ' ');
  return joined.slice(-PROSE_WINDOW);
}

function statsReply(input, level) {
  const file = resolveTranscript(input || {});
  if (!file) {
    return 'level: ' + level + '\nstats: no session transcript was found, so no token figures are available.';
  }
  const data = readAssistant(file);
  if (!data) {
    return 'level: ' + level + '\nstats: the transcript could not be read, so no token figures are available.';
  }
  const lines = [
    'level: ' + level,
    'assistant turns: ' + data.turns,
    'output tokens: ' + data.outputTokens,
    'cache-read input tokens: ' + data.cacheRead,
  ];
  const slice = proseSlice(data.texts).trim();
  if (slice.length > SCORE_MIN_CHARS) {
    const parsed = lib.scoreText(slice);
    if (parsed) lines.push('session prose ai_tell_score: ' + parsed.score);
  }
  return lines.join('\n');
}

if (require.main === module) {
  const input = lib.readStdinJson();
  try {
    lib.blockReply(statsReply(input, lib.effectiveLevel()));
  } catch (err) {
    // never fail the host
  }
  process.exitCode = 0;
}

module.exports = { statsReply, resolveTranscript, readAssistant, proseSlice };
