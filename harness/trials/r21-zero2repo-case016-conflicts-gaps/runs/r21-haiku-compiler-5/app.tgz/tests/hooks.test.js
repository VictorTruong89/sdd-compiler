'use strict';
// Hook and command tests. Run: node --test tests/
// Each test uses a fresh CLAUDE_CONFIG_DIR so the level flag and ledgers start empty.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const HOOKS = path.join(ROOT, 'hooks');

function freshEnv() {
  const cfg = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-cfg-'));
  return { cfg, env: Object.assign({}, process.env, { CLAUDE_CONFIG_DIR: cfg }) };
}

function hook(name, payload, env, raw) {
  const input = raw !== undefined ? raw : JSON.stringify(payload || {});
  const res = cp.spawnSync(process.execPath, [path.join(HOOKS, name)], {
    input, env, encoding: 'utf8', cwd: os.tmpdir(), timeout: 60000,
  });
  return { status: res.status, stdout: res.stdout, stderr: res.stderr };
}

function reason(res) {
  return JSON.parse(res.stdout).reason;
}

function command(prompt, env, extra) {
  return hook('prosecheck-tracker.js', Object.assign({ prompt, session_id: 'sess-1' }, extra || {}), env);
}

test('malformed input never fails the host (N-000386 N-000388)', () => {
  const { env } = freshEnv();
  for (const name of ['prosecheck-activate.js', 'prosecheck-tracker.js', 'prosecheck-subagent.js', 'prosecheck-guard.js']) {
    const res = hook(name, null, env, '{not json');
    assert.equal(res.status, 0, name);
  }
});

test('session start: welcome once, then the contract; flag stored (N-000370 N-000371 N-000379)', () => {
  const { env, cfg } = freshEnv();
  const first = hook('prosecheck-activate.js', {}, env);
  assert.equal(first.status, 0);
  assert.match(first.stdout, /prosecheck is installed and on/);
  assert.match(first.stdout, /\/prosecheck doctor/);
  assert.equal(fs.readFileSync(path.join(cfg, '.prosecheck-active'), 'utf8').trim(), 'full');
  const second = hook('prosecheck-activate.js', {}, env);
  assert.doesNotMatch(second.stdout, /is installed and on/);
  assert.match(second.stdout, /Prose writing contract/);
});

test('off: session start, prompts, subagent and guard are silent (N-000335 N-000380)', () => {
  const { env } = freshEnv();
  command('/prosecheck off', env);
  assert.equal(hook('prosecheck-activate.js', {}, env).stdout, '');
  assert.equal(hook('prosecheck-tracker.js', { prompt: 'write a memo' }, env).stdout, '');
  assert.equal(hook('prosecheck-subagent.js', {}, env).stdout, '');
});

test('subagent gets the contract inside the SubagentStart envelope (N-000384 N-000385)', () => {
  const { env } = freshEnv();
  const out = JSON.parse(hook('prosecheck-subagent.js', {}, env).stdout);
  assert.equal(out.hookSpecificOutput.hookEventName, 'SubagentStart');
  assert.match(out.hookSpecificOutput.additionalContext, /Prose writing contract/);
});

test('ordinary prompt gets a reminder naming the live level (N-000380 N-000381)', () => {
  const { env } = freshEnv();
  command('/prosecheck lite', env);
  const out = JSON.parse(hook('prosecheck-tracker.js', { prompt: 'draft a note' }, env).stdout);
  assert.equal(out.hookSpecificOutput.hookEventName, 'UserPromptSubmit');
  assert.match(out.hookSpecificOutput.additionalContext, /\blite\b/);
});

test('level commands store the word; on stores full; unknown word changes nothing (N-000471 N-000472 N-000474)', () => {
  const { env, cfg } = freshEnv();
  assert.match(reason(command('/prosecheck strict', env)), /strict/);
  assert.equal(fs.readFileSync(path.join(cfg, '.prosecheck-active'), 'utf8').trim(), 'strict');
  command('/prosecheck off', env);
  assert.match(reason(command('/prosecheck on', env)), /\bon\b.*\bfull\b/);
  command('/prosecheck lite', env);
  const unknown = reason(command('/prosecheck frobnicate', env));
  assert.match(unknown, /unknown/);
  assert.match(unknown, /frobnicate/);
  assert.equal(fs.readFileSync(path.join(cfg, '.prosecheck-active'), 'utf8').trim(), 'lite');
});

test('namespaced form behaves the same (N-000457 N-000458)', () => {
  const { env } = freshEnv();
  assert.match(reason(command('/prosecheck:prosecheck status', env)), /level: full/);
});

test('stop phrase only as the entire prompt (N-000475 N-000885 N-000886)', () => {
  const { env, cfg } = freshEnv();
  command('/prosecheck full', env);
  command('please stop prosecheck now', env);
  assert.equal(fs.readFileSync(path.join(cfg, '.prosecheck-active'), 'utf8').trim(), 'full');
  assert.match(reason(command('Stop Prosecheck', env)), /\boff\b/);
  assert.equal(fs.readFileSync(path.join(cfg, '.prosecheck-active'), 'utf8').trim(), 'off');
});

test('help: first line names only the live level; required words present (N-000910 N-000912 N-000913)', () => {
  const { env } = freshEnv();
  command('/prosecheck full', env);
  const text = reason(command('/prosecheck', env));
  const lines = text.split('\n');
  assert.match(lines[0], /\bfull\b/);
  assert.doesNotMatch(lines[0], /\b(lite|strict|off)\b/);
  assert.match(text, /\bnever\b/);
  assert.match(text, /prosecheck this/);
  assert.match(text, /humanize this/);
  assert.ok(lines.some((l) => /^\/prosecheck full/.test(l) && /\b40\b/.test(l) && /\(default\)/.test(l) && /contract/.test(l) && /guard/.test(l)));
  assert.ok(lines.some((l) => /^\/prosecheck strict/.test(l) && /\b20\b/.test(l) && /\bguard\b/.test(l) && /\bscrub\b/.test(l)));
  assert.ok(lines.some((l) => /^\/prosecheck lite/.test(l) && /\bcontract\b/.test(l) && /\bscoring\b/.test(l) && !/\b40\b|\b20\b/.test(l)));
});

test('status names only the stored level (N-000937 N-000939)', () => {
  const { env } = freshEnv();
  command('/prosecheck strict', env);
  const text = reason(command('/prosecheck status', env));
  assert.match(text, /\bstrict\b/);
  assert.doesNotMatch(text, /\b(lite|full|off)\b/);
});

test('doctor: four successful checks when healthy, and a closing line naming show (N-000497 .. N-001022)', () => {
  const { env } = freshEnv();
  command('/prosecheck full', env);
  const lines = reason(command('/prosecheck doctor', env)).split('\n').filter(Boolean);
  const ok = lines.filter((l) => l.includes('[OK]'));
  assert.equal(ok.length, 4);
  const closer = lines[lines.length - 1];
  assert.match(closer, /512 KB/);
  assert.match(closer, /4 MB/);
  assert.match(closer, /262,144/);
  assert.match(closer, /\/prosecheck show/);
  assert.doesNotMatch(closer, /\/prosecheck doctor/);
});

test('doctor when mode is off: points at on in the form typed (N-001026 N-001027)', () => {
  const { env } = freshEnv();
  command('/prosecheck off', env);
  const text = reason(command('/prosecheck:prosecheck doctor', env));
  const lines = text.split('\n').filter(Boolean);
  assert.equal(lines.filter((l) => l.includes('[OK]')).length, 3);
  assert.match(lines[lines.length - 1], /\/prosecheck:prosecheck on/);
  assert.match(lines[lines.length - 1], /scored/);
  assert.doesNotMatch(lines[lines.length - 1], /not re-scored/);
});

test('doctor line rules: python line is the only one with python; mode off is not a fault (N-001009 N-001010)', () => {
  const { env } = freshEnv();
  command('/prosecheck full', env);
  const lines = reason(command('/prosecheck doctor', env)).split('\n').filter(Boolean);
  const pythonLines = lines.filter((l) => /python/i.test(l));
  assert.equal(pythonLines.length, 1);
  assert.match(pythonLines[0], /\[OK\]/);
});

test('show: empty ledger and rows after a guard save (N-001035 N-001044 N-001052)', () => {
  const { env, cfg } = freshEnv();
  command('/prosecheck full', env);
  assert.match(reason(command('/prosecheck show', env)), /nothing scored yet/);
  const doc = path.join(cfg, 'draft.md');
  fs.writeFileSync(doc, 'Additionally, this tool is a testament to the power of careful writing. Furthermore, it delves into the tapestry of ideas. Let\'s dive in. It\'s worth noting that the landscape is vibrant, robust, and seamless. In conclusion, the future looks bright.\n');
  const guard = hook('prosecheck-guard.js', { session_id: 'sess-1', cwd: cfg, tool_name: 'Write', tool_input: { file_path: 'draft.md' } }, env);
  assert.equal(guard.status, 0);
  const out = JSON.parse(guard.stdout);
  assert.match(out.hookSpecificOutput.additionalContext, /^prosecheck: draft\.md reads with/);
  assert.match(out.hookSpecificOutput.additionalContext, /Please fix/);
  const shown = reason(command('/prosecheck show', env));
  assert.match(shown, /draft\.md - reads with/);
  assert.match(shown, /flagged/);
});

test('guard: unflagged prose is silent and recorded; lite does not score (N-000402 N-000416 N-000417)', () => {
  const { env, cfg } = freshEnv();
  command('/prosecheck full', env);
  fs.writeFileSync(path.join(cfg, 'plain.txt'), 'We walked to the shop and bought bread and milk for the week.\n');
  const quiet = hook('prosecheck-guard.js', { session_id: 'sess-1', cwd: cfg, tool_name: 'Write', tool_input: { file_path: 'plain.txt' } }, env);
  assert.equal(quiet.stdout, '');
  command('/prosecheck lite', env);
  const lite = hook('prosecheck-guard.js', { session_id: 'sess-1', cwd: cfg, tool_name: 'Write', tool_input: { file_path: 'plain.txt' } }, env);
  assert.equal(lite.stdout, '');
});

test('guard: apply_patch paths and instruction files are skipped (N-000421 N-000422 N-000429)', () => {
  const { env, cfg } = freshEnv();
  command('/prosecheck full', env);
  fs.writeFileSync(path.join(cfg, 'AGENTS.md'), 'Delve into the tapestry of ideas. Vibrant and robust. Testament.\n');
  const patch = '*** Begin Patch\n*** Update File: AGENTS.md\n@@\n+x\n*** End Patch';
  const res = hook('prosecheck-guard.js', { session_id: 'sess-1', cwd: cfg, tool_name: 'apply_patch', tool_input: { command: patch } }, env);
  assert.equal(res.stdout, '');
});

test('check: report only, names the file, never rewrites (N-000490 .. N-000496)', () => {
  const { env, cfg } = freshEnv();
  command('/prosecheck full', env);
  const doc = path.join(cfg, 'draft.md');
  const body = 'Delve into the tapestry of ideas. It is a testament to care.\n';
  fs.writeFileSync(doc, body);
  const text = reason(command('/prosecheck check "' + doc + '"', env));
  assert.match(text, /^draft\.md - reads/m);
  assert.match(text, /^confidence: /m);
  assert.match(text, /^tells: /m);
  assert.match(text, /report only/);
  assert.equal(fs.readFileSync(doc, 'utf8'), body);
  fs.writeFileSync(path.join(cfg, 'blob.pdf'), '%PDF-1.4');
  assert.match(reason(command('/prosecheck check ' + path.join(cfg, 'blob.pdf'), env)), /no readable text/);
  assert.match(reason(command('/prosecheck check ' + path.join(cfg, 'nope.md'), env)), /cannot read/);
});

test('check without a path returns text without a score (N-000975)', () => {
  const { env } = freshEnv();
  command('/prosecheck full', env);
  const text = reason(command('/prosecheck check', env));
  assert.ok(text.length > 0);
  assert.doesNotMatch(text, /\b(\d|[1-9]\d|100)\b/);
  assert.doesNotMatch(text, /unknown/);
});

test('init: writes AGENTS.md once, keeps prefix, portable export (N-001065 N-001069 N-001085)', () => {
  const { env, cfg } = freshEnv();
  command('/prosecheck full', env);
  const project = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-proj-'));
  fs.writeFileSync(path.join(project, 'AGENTS.md'), '# Team notes\n\nKeep this.\n');
  const payload = { prompt: '/prosecheck init', cwd: project, session_id: 'sess-1' };
  const first = JSON.parse(hook('prosecheck-tracker.js', payload, env).stdout).reason;
  assert.match(first, /AGENTS\.md/);
  const agents = fs.readFileSync(path.join(project, 'AGENTS.md'), 'utf8');
  assert.ok(agents.startsWith('# Team notes\n\nKeep this.\n'));
  assert.ok(!agents.includes(cfg));
  assert.ok(!agents.includes(os.userInfo().username) || os.userInfo().username.length < 3);
  assert.match(agents, /CLAUDE_PLUGIN_ROOT/);
  const second = JSON.parse(hook('prosecheck-tracker.js', payload, env).stdout).reason;
  assert.match(second, /already[^\n]*AGENTS\.md|AGENTS\.md[^\n]*already/);
  assert.equal(fs.readFileSync(path.join(project, 'AGENTS.md'), 'utf8'), agents);
  assert.ok(fs.existsSync(path.join(project, '.cursor', 'rules', 'prosecheck.mdc')));
});

test('init when off writes nothing (N-001065 N-001066)', () => {
  const { env } = freshEnv();
  command('/prosecheck off', env);
  const project = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-proj-'));
  const reply = JSON.parse(hook('prosecheck-tracker.js', { prompt: '/prosecheck:prosecheck init', cwd: project }, env).stdout).reason;
  assert.match(reply, /switched off/);
  assert.match(reply, /\/prosecheck:prosecheck on/);
  assert.equal(fs.existsSync(path.join(project, 'AGENTS.md')), false);
  assert.equal(fs.existsSync(path.join(project, '.cursor')), false);
});

test('stats: named transcript, deduplicated assistant turns, token sums (N-001107 .. N-001114)', () => {
  const { env, cfg } = freshEnv();
  command('/prosecheck full', env);
  const transcript = path.join(cfg, 't.jsonl');
  const rows = [
    { type: 'user', message: { content: 'hi' } },
    { type: 'assistant', message: { id: 'a', usage: { output_tokens: 120, cache_read_input_tokens: 5000 }, content: [{ type: 'text', text: 'Hello there.' }] } },
    { type: 'assistant', message: { id: 'a', usage: { output_tokens: 120, cache_read_input_tokens: 5000 }, content: [{ type: 'text', text: 'dup' }] } },
    { type: 'assistant', message: { id: 'b', usage: { output_tokens: 30, cache_read_input_tokens: 10 }, content: [{ type: 'text', text: 'Second.' }] } },
  ];
  fs.writeFileSync(transcript, rows.map((r) => JSON.stringify(r)).join('\n') + '\n');
  const text = reason(command('/prosecheck stats', env, { transcript_path: transcript }));
  assert.match(text, /^\s*assistant turns: 2$/m);
  assert.match(text, /^\s*output tokens: 150$/m);
  assert.match(text, /^\s*cache-read input tokens: 5010$/m);
  assert.doesNotMatch(text, /session prose ai_tell_score/);
});

test('stats: unreadable transcript yields no count lines (N-001120)', () => {
  const { env } = freshEnv();
  command('/prosecheck full', env);
  const text = reason(command('/prosecheck stats', env, { transcript_path: '/nonexistent/x.jsonl' }));
  assert.doesNotMatch(text, /assistant turns:/);
  assert.doesNotMatch(text, /output tokens:/);
});

test('contract texts per level (N-000335 N-000363 N-000807 N-000810)', () => {
  const lib = require(path.join(HOOKS, 'prosecheck-lib.js'));
  const lite = lib.contractText('lite', {});
  const full = lib.contractText('full', {});
  const strict = lib.contractText('strict', {});
  assert.doesNotMatch(lite, /\b40\b|light tells/);
  assert.match(full, /\b40\b/);
  assert.match(full, /light tells/);
  assert.doesNotMatch(full, /--clean/);
  assert.match(strict, /\b20\b/);
  assert.match(strict, /--clean/);
  assert.match(strict, /(^|[^-])\bclean\b/);
  for (const word of ['delve', 'tapestry', 'nuanced', 'game-changer', 'landscape']) {
    assert.match(full, new RegExp('(^|[^A-Za-z-])' + word + '([^A-Za-z-]|$)'));
  }
});
