"""Tests for scripts/detect.py. Run: python3 -m unittest discover -s tests -v

Test names carry the spec ids they exercise (N-000nnn) where a single id applies.
"""
import io
import json
import os
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DETECT = os.path.join(ROOT, 'scripts', 'detect.py')


def run(args=(), data=None):
    proc = subprocess.run([sys.executable, DETECT] + list(args),
                          input=data, capture_output=True, cwd=ROOT, timeout=60)
    return proc.returncode, proc.stdout, proc.stderr.decode('utf-8', 'replace')


def report(args=(), data=None):
    rc, out, err = run(args, data)
    if rc != 0:
        raise AssertionError('exit %d: %s' % (rc, err))
    return json.loads(out.decode('utf-8'))


class DetectorTests(unittest.TestCase):

    def setUp(self):
        self.tmp = tempfile.mkdtemp(prefix='pc-test-')

    def write(self, name, data):
        path = os.path.join(self.tmp, name)
        mode = 'wb' if isinstance(data, bytes) else 'w'
        with open(path, mode, **({} if mode == 'wb' else {'encoding': 'utf-8'})) as fh:
            fh.write(data)
        return path

    # --- process contract (N-000703 .. N-000715, N-000777 .. N-000787)
    def test_N_000704_empty_input_exits_1_with_error_object(self):
        rc, out, err = run([], b'   \n\t ')
        self.assertEqual(rc, 1)
        self.assertEqual(out, b'')
        self.assertEqual(json.loads(err.strip().splitlines()[-1]), {'error': 'empty input'})
        self.assertNotIn('Traceback', err)

    def test_N_000708_unreadable_path_exits_1(self):
        rc, out, err = run([os.path.join(self.tmp, 'missing.md')])
        self.assertEqual(rc, 1)
        self.assertEqual(out, b'')
        self.assertTrue(json.loads(err.strip().splitlines()[-1])['error'].startswith('cannot read input:'))

    def test_N_000712_unknown_option_exits_2(self):
        rc, out, err = run(['--frobnicate'])
        self.assertEqual(rc, 2)
        self.assertEqual(out, b'')
        msg = json.loads(err.strip().splitlines()[-1])['error']
        self.assertIn('unknown option', msg)
        self.assertIn('--frobnicate', msg)
        self.assertIn('--help', msg)

    def test_N_000732_help_prints_usage_on_stdout(self):
        rc, out, _ = run(['--help'])
        self.assertEqual(rc, 0)
        self.assertEqual(out.decode().splitlines()[0], 'usage: detect.py [--clean] [--ci] [--] [FILE]')
        rc2, out2, _ = run(['-h'])
        self.assertEqual(rc2, 0)
        self.assertEqual(out2, out)

    def test_N_000783_two_operands_scan_first_with_notice(self):
        a = self.write('a.md', 'Plain words in the first file. ' * 5)
        b = self.write('b.md', 'Second file. ' * 5)
        rc, out, err = run([a, b])
        self.assertEqual(rc, 0)
        self.assertIn(a, err)
        self.assertNotIn('b.md', err)
        self.assertIn('_metrics', json.loads(out))

    def test_N_000736_double_dash_allows_leading_dash_name(self):
        path = self.write('-dash.md', 'Some plain prose here. ' * 4)
        rc, out, _ = run(['--', path])
        self.assertEqual(rc, 0)
        self.assertIn('_metrics', json.loads(out))

    # --- report shape (N-000742 .. N-000774)
    def test_N_000742_report_members_and_metrics(self):
        r = report([], 'Delve into the tapestry of ideas. It is a testament to care. '.encode())
        self.assertIn('_metrics', r)
        m = r['_metrics']
        for key in ('scanned_chars', 'truncated', 'ai_tell_score', 'ai_tell_band', 'confidence',
                    'confidence_reason', 'patterns_flagged', 'invisible_chars',
                    'nonstandard_spaces', 'homoglyphs'):
            self.assertIn(key, m)
        self.assertIn('1_ai_vocabulary', r)
        f = r['1_ai_vocabulary']
        self.assertEqual(f['label'], 'AI vocabulary')
        self.assertGreaterEqual(f['count'], 1)
        self.assertLessEqual(len(f['samples']), 3)
        self.assertTrue(0 <= m['ai_tell_score'] <= 100)

    def test_N_000115_bands(self):
        from importlib import util
        spec = util.spec_from_file_location('detect', DETECT)
        mod = util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        expect = {0: 'clean', 20: 'clean', 21: 'light tells', 40: 'light tells', 41: 'mixed',
                  60: 'mixed', 61: 'heavy tells', 80: 'heavy tells', 81: 'pervasive tells', 100: 'pervasive tells'}
        for score, band in expect.items():
            self.assertEqual(mod.band_for(score), band)

    def test_N_000097_ci_interval_only_with_flag(self):
        text = ('Plain prose sentence number one is here. Another sentence follows in the paragraph. '
                'A third sentence adds more words. Yet a fourth sentence closes it out.')
        self.assertNotIn('score_ci', report([], text.encode())['_metrics'])
        m = report(['--ci'], text.encode())['_metrics']
        low, high = m['score_ci']
        self.assertLessEqual(low, high)
        self.assertLessEqual(low, m['ai_tell_score'])
        self.assertGreaterEqual(high, m['ai_tell_score'])

    def test_N_000225_ci_null_with_too_few_sentences(self):
        m = report(['--ci'], b'Short one. Short two.')['_metrics']
        self.assertIsNone(m['score_ci'])
        self.assertIn('too few sentences', m['score_ci_note'])

    # --- scan window (N-000236 .. N-000240, N-000292 .. N-000294)
    def test_N_000236_window_metrics(self):
        m = report([], ('word ' * 60000).encode())['_metrics']
        self.assertEqual(m['scanned_chars'], 262144)
        self.assertTrue(m['truncated'])

    def test_N_000238_exactly_window_is_not_truncated(self):
        m = report([], b'a' * 262144)['_metrics']
        self.assertEqual(m['scanned_chars'], 262144)
        self.assertFalse(m['truncated'])

    def test_N_000240_character_past_window_is_not_a_finding(self):
        data = ('a' * 262144 + '​').encode('utf-8')
        m = report([], data)['_metrics']
        self.assertEqual(m['invisible_chars'], 0)

    # --- encodings (N-000241, N-000242)
    def test_N_000241_utf16_bom_decoded(self):
        data = b'\xff\xfe' + 'Plain prose sentence for the test. It has two sentences.'.encode('utf-16-le')
        self.assertEqual(report([], data)['_metrics']['scanned_chars'], len('Plain prose sentence for the test. It has two sentences.'))

    def test_N_000241_utf8_bom_not_prose(self):
        data = b'\xef\xbb\xbfPlain prose.'
        self.assertEqual(report([], data)['_metrics']['scanned_chars'], len('Plain prose.'))

    # --- markdown masking (N-000149)
    def test_N_000149_code_blocks_and_spans_produce_no_findings(self):
        text = 'Intro text here.\n```\nlet me delve into the tapestry\n```\n`delve` inline here.\n'
        r = report([], text.encode())
        self.assertEqual([k for k in r if k != '_metrics'], [])

    # --- character layer and cleanup (N-000303 .. N-000331)
    def test_N_000303_zero_width_is_counted_and_cleanup_removes_it(self):
        text = 'Hello​there, plain words in one sentence.'
        m = report([], text.encode())['_metrics']
        self.assertEqual(m['invisible_chars'], 1)
        rc, out, _ = run(['--clean'], text.encode())
        self.assertEqual(rc, 0)
        self.assertEqual(out.decode(), 'Hellothere, plain words in one sentence.')
        self.assertEqual(report([], out)['_metrics']['invisible_chars'], 0)

    def test_N_000305_rescan_after_cleanup_reports_zero(self):
        text = 'A​B­C﻿D\U000E0041 end of text.'
        _, out, _ = run(['--clean'], text.encode())
        self.assertEqual(report([], out)['_metrics']['invisible_chars'], 0)

    def test_N_000309_nonstandard_spaces_normalised_and_rescan_zero(self):
        text = 'Costs are 5 % more and spacing　here.'
        m = report([], text.encode())['_metrics']
        self.assertGreater(m['nonstandard_spaces'], 0)
        _, out, _ = run(['--clean'], text.encode())
        self.assertIn(' ', out.decode())  # kept: digit beside it
        self.assertEqual(report([], out)['_metrics']['nonstandard_spaces'], 0)

    def test_N_000310_homoglyph_folding(self):
        text = 'The pаypal account is ready.'  # Cyrillic a inside a Latin token
        m = report([], text.encode())['_metrics']
        self.assertEqual(m['homoglyphs'], 1)
        _, out, _ = run(['--clean'], text.encode())
        self.assertIn('paypal', out.decode())
        self.assertEqual(report([], out)['_metrics']['homoglyphs'], 0)

    def test_N_000327_cyrillic_word_not_folded(self):
        text = 'Привет мир, это тест.'
        _, out, _ = run(['--clean'], text.encode())
        self.assertEqual(out.decode(), text)

    def test_N_000312_trailing_whitespace_trimmed_and_one_final_newline_restored(self):
        _, out, _ = run(['--clean'], b'line one   \nline two\t\n\n\n')
        self.assertEqual(out, b'line one\nline two\n')

    # --- decisive floors and caps (N-000131 .. N-000139)
    def test_N_000135_two_decisive_families_floor_65(self):
        text = ('Sentence one.​ Placeholder [Insert client name] appears here with more words. '
                'Sentence three is also here for length purposes.')
        m = report([], text.encode())['_metrics']
        self.assertGreaterEqual(m['ai_tell_score'], 65)

    def test_N_000131_single_family_capped_at_40_without_decisive(self):
        text = ('The cat sat. ' * 30) + ' Some words here.'
        m = report([], text.encode())['_metrics']
        self.assertLessEqual(m['ai_tell_score'], 40)

    # --- family rules (N-000152 .. N-000219)
    def test_N_000150_lexical_families_case_insensitive(self):
        r = report([], 'DELVE into it. Delves again.'.encode())
        self.assertIn('1_ai_vocabulary', r)

    def test_N_000153_dialect_needs_two_hits(self):
        self.assertNotIn('2_model_dialect_vocabulary', report([], b'This is genuinely useful for many people.'))
        self.assertIn('2_model_dialect_vocabulary',
                      report([], b'This is genuinely useful. That was genuinely fascinating for everyone.'))

    def test_N_000116_writing_advice_does_not_move_score(self):
        plain = 'We went home after the long walk and cooked dinner together for everyone. '
        advice = plain + ' We stayed in order to finish the meal, due to the fact that it was late.'
        a = report([], plain.encode())['_metrics']['ai_tell_score']
        b = report([], advice.encode())['_metrics']['ai_tell_score']
        self.assertEqual(a, b)

    def test_N_000127_parallelism_and_tailing_negation_keys(self):
        r = report([], b"It's not just about speed, it's about care. We ship it, no guessing required.")
        self.assertIn('17_negative_parallelism', r)
        self.assertIn('17_tailing_negation', r)

    def test_N_000171_invisible_and_placeholder_labels_unique(self):
        r = report([], b'Fill [Insert client name] and [TBD] here with words to pad the text out.')
        labels = [v['label'] for k, v in r.items() if k != '_metrics']
        self.assertEqual(len(labels), len(set(labels)))

    def test_N_000213_marketing_slop_phrase(self):
        r = report([], b'We are unlocking full potential for every team this year.')
        self.assertIn('69_marketing_slop', r)

    # --- extraction (N-000254 .. N-000281)
    def _zip(self, name, files):
        path = os.path.join(self.tmp, name)
        with zipfile.ZipFile(path, 'w') as zf:
            for member, body in files.items():
                zf.writestr(member, body)
        return path

    def test_N_000256_docx_text_without_markup(self):
        path = self._zip('a.docx', {'word/document.xml': (
            '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
            '<w:body><w:p><w:r><w:t>Alpha &amp; beta.</w:t></w:r></w:p>'
            '<w:p><w:r><w:t>Gamma.</w:t></w:r></w:p></w:body></w:document>')})
        rc, out, _ = run(['--clean', path])
        self.assertEqual(rc, 0)
        self.assertEqual(out.decode(), 'Alpha & beta.\nGamma.')

    def test_N_000271_ipynb_only_markdown_cells(self):
        import json as _json
        path = os.path.join(self.tmp, 'n.ipynb')
        with open(path, 'w', encoding='utf-8') as fh:
            _json.dump({'cells': [{'cell_type': 'markdown', 'source': ['# Title\n', 'Prose here.']},
                                  {'cell_type': 'code', 'source': ['print("code")'], 'outputs': []}]}, fh)
        rc, out, _ = run(['--clean', path])
        self.assertEqual(rc, 0)
        self.assertEqual(out.decode(), '# Title\nProse here.')

    def test_N_000286_archive_not_zip_is_cannot_read(self):
        path = self.write('bad.docx', b'not a zip at all')
        rc, out, err = run([path])
        self.assertEqual(rc, 1)
        self.assertTrue(json.loads(err.strip().splitlines()[-1])['error'].startswith('cannot read input:'))

    def test_N_000282_pdf_is_empty_input(self):
        path = self.write('doc.pdf', b'%PDF-1.4 not really')
        rc, out, err = run([path])
        self.assertEqual(rc, 1)
        self.assertEqual(json.loads(err.strip().splitlines()[-1]), {'error': 'empty input'})

    def test_N_000289_notebook_invalid_json_is_empty(self):
        path = self.write('bad.ipynb', 'not json')
        rc, out, err = run([path])
        self.assertEqual(rc, 1)
        self.assertEqual(json.loads(err.strip().splitlines()[-1]), {'error': 'empty input'})


if __name__ == '__main__':
    unittest.main()
