#!/usr/bin/env python3
"""prosecheck detector: a local, standard-library-only scanner for AI-writing patterns.

    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
    python3 scripts/detect.py --help

With no FILE the text is read from standard input (UTF-8, BOM aware).
Successful report: one JSON object on stdout, exit 0.
Cleanup (--clean): scrubbed text on stdout, exit 0.
Failure: nothing on stdout, one JSON object {"error": ...} as the last
non-empty stderr line, exit 1 (empty input, unreadable input) or 2 (unknown option).
"""
# spec: N-000094 N-000097 N-000098 N-000099 N-000100 N-000101 N-000226 N-000229 N-000231
# spec: N-000232 N-000234 N-000235 N-000236 N-000241 N-000242 N-000243 N-000244 N-000245
# spec: N-000732 N-000733 N-000734 N-000735 N-000736 N-000737 N-000739 N-000740 N-000742
# spec: N-000743 N-000775 N-000776 N-000777 N-000778 N-000779 N-000780 N-000781 N-000782
# spec: N-000783 N-000784 N-000785 N-000786 N-000787

import bisect
import collections
import io
import json
import math
import os
import random
import re
import sys
import unicodedata
import zipfile
from html.parser import HTMLParser
from xml.etree import ElementTree as ET

WINDOW_CHARS = 262144                      # spec: N-000236 N-000237 (scan window)
PLAIN_CAP_BYTES = 512 * 1024               # spec: N-000245 N-000246 (plain text cap)
ARCHIVE_CAP_BYTES = 4 * 1024 * 1024        # spec: N-000245 N-000247 (zip/notebook cap)

PLAIN_EXTS = frozenset(['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'])
ZIP_EXTS = frozenset(['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'])
NOTEBOOK_EXT = '.ipynb'
NO_PROSE_EXTS = frozenset(['.pdf', '.rtf'])  # spec: N-000282 N-000283 N-000284 N-000285
SUPPORTED_EXTS = PLAIN_EXTS | ZIP_EXTS | frozenset([NOTEBOOK_EXT])

USAGE = (
    "usage: detect.py [--clean] [--ci] [--] [FILE]\n"
    "\n"
    "Score prose for AI-writing patterns and print a JSON report.\n"
    "With no FILE, standard input is read.\n"
    "  --clean     print the cleaned text instead of the report\n"
    "  --ci        add a low/high interval on the score when there are enough sentences\n"
    "  --          end option parsing so a file name may begin with a dash\n"
    "  -h, --help  print this message and exit\n"
)

BANDS = [(20, 'clean'), (40, 'light tells'), (60, 'mixed'), (80, 'heavy tells'), (100, 'pervasive tells')]
HOOK_PHRASES = {
    'clean': 'reads clean',
    'light tells': 'reads mostly clean',
    'mixed': 'reads with some AI tells',
    'heavy tells': 'reads with heavy AI tells',
    'pervasive tells': 'reads with pervasive AI tells',
}


class DetectorError(Exception):
    def __init__(self, status, message):
        Exception.__init__(self, message)
        self.status = status
        self.message = message


# ---------------------------------------------------------------- extraction
# spec: N-000254 N-000255 N-000256 N-000257 N-000258 N-000259 N-000260 N-000261 N-000262
# spec: N-000263 N-000264 N-000265 N-000266 N-000267 N-000268 N-000269 N-000270 N-000271
# spec: N-000272 N-000273 N-000274 N-000275 N-000276 N-000277 N-000278 N-000279 N-000280
# spec: N-000281 N-000286 N-000287 N-000288 N-000289 N-000290 N-000292 N-000296 N-000297

def _local(tag):
    if not isinstance(tag, str):
        return ''
    return tag.rsplit('}', 1)[-1]


def _decode_plain(data):
    if data.startswith(b'\xff\xfe') or data.startswith(b'\xfe\xff'):
        text = data.decode('utf-16', errors='replace')
    else:
        if data.startswith(b'\xef\xbb\xbf'):
            data = data[3:]
        text = data.decode('utf-8', errors='replace')
    if text.startswith('﻿'):
        text = text[1:]
    return text.replace('\r\n', '\n').replace('\r', '\n')


def _open_zip(data):
    try:
        return zipfile.ZipFile(io.BytesIO(data))
    except (zipfile.BadZipFile, OSError, ValueError, EOFError) as exc:
        raise DetectorError(1, 'cannot read input: not a readable zip archive (%s)' % exc)


def _parse_xml(data):
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


def _inline(el, specials, skip):
    name = _local(el.tag)
    if name in skip:
        body = ''
    elif name in specials:
        body = specials[name](el)
    else:
        body = (el.text or '') + ''.join(_inline(c, specials, skip) for c in el)
    return body + (el.tail or '')


def _paragraphs(root, para_names, specials, skip):
    out = []

    def visit(el):
        if _local(el.tag) in para_names:
            text = (el.text or '') + ''.join(_inline(c, specials, skip) for c in el)
            out.append(text)
            return
        for child in el:
            visit(child)

    if root is not None:
        visit(root)
    cleaned = []
    for para in out:
        para = ' '.join(para.replace('\r', ' ').replace('\n', ' ').split(' ')).strip()
        if para:
            cleaned.append(para)
    return cleaned


def _attr_count(el):
    for key, value in el.attrib.items():
        if _local(key) == 'c':
            try:
                return ' ' * max(1, int(value))
            except ValueError:
                return ' '
    return ' '


_DOCX_SPECIALS = {
    't': lambda el: el.text or '',
    'tab': lambda el: '\t',
    'br': lambda el: '\n',
    'cr': lambda el: '\n',
}
_ODF_SPECIALS = {
    't': lambda el: el.text or '',
    's': _attr_count,
    'tab': lambda el: '\t',
    'line-break': lambda el: '\n',
    's-tab': lambda el: '\t',
}
_ODF_SKIP = frozenset(['script', 'style'])


def _zip_read(zf, name):
    try:
        return zf.read(name)
    except KeyError:
        return None


def _natural_key(name):
    return [int(p) if p.isdigit() else p for p in re.split(r'(\d+)', name)]


def _extract_zip(zf, ext):
    names = zf.namelist()
    paragraphs = []
    if ext in ('.docx', '.docm'):
        root = _parse_xml(_zip_read(zf, 'word/document.xml') or b'')
        paragraphs = _paragraphs(root, {'p'}, _DOCX_SPECIALS, frozenset(['instrText', 'delText', 'rPr', 'pPr']))
    elif ext in ('.pptx', '.pptm'):
        slides = sorted([n for n in names if re.match(r'ppt/slides/slide\d+\.xml$', n)], key=_natural_key)
        for name in slides:
            root = _parse_xml(zf.read(name))
            paragraphs.extend(_paragraphs(root, {'p'}, _DOCX_SPECIALS, frozenset(['rPr', 'endParaRPr', 'pPr'])))
    elif ext in ('.xlsx', '.xlsm'):
        shared = []
        sroot = _parse_xml(_zip_read(zf, 'xl/sharedStrings.xml') or b'')
        if sroot is not None:
            for si in sroot.iter():
                if _local(si.tag) == 'si':
                    shared.append(''.join((t.text or '') for t in si.iter() if _local(t.tag) == 't'))
        sheets = sorted([n for n in names if re.match(r'xl/worksheets/sheet\d+\.xml$', n)], key=_natural_key)
        for name in sheets:
            root = _parse_xml(zf.read(name))
            if root is None:
                continue
            cells = []
            for c in root.iter():
                if _local(c.tag) != 'c':
                    continue
                kind = c.get('t')
                value = None
                if kind == 's':
                    v = None
                    for child in c:
                        if _local(child.tag) == 'v':
                            v = child.text
                    if v is not None and v.strip().isdigit() and int(v.strip()) < len(shared):
                        value = shared[int(v.strip())]
                elif kind == 'inlineStr':
                    value = ''.join((t.text or '') for t in c.iter() if _local(t.tag) == 't')
                elif kind == 'str':
                    for child in c:
                        if _local(child.tag) == 'v':
                            value = child.text
                if value:
                    cells.append(value)
            paragraphs.extend(cells)
    elif ext in ('.odt', '.odp', '.ods'):
        root = _parse_xml(_zip_read(zf, 'content.xml') or b'')
        paragraphs = _paragraphs(root, {'p', 'h'}, _ODF_SPECIALS, _ODF_SKIP)
    elif ext == '.epub':
        for name in names:
            low = name.lower()
            base = low.rsplit('/', 1)[-1]
            if not low.endswith(('.xhtml', '.html', '.htm')):
                continue
            if 'nav' in base or base.startswith('toc') or low.startswith('meta-inf/'):
                continue
            try:
                raw = zf.read(name)
            except KeyError:
                continue
            parser = _HTMLText()
            try:
                parser.feed(raw.decode('utf-8', errors='replace'))
                parser.close()
            except Exception:  # malformed markup: keep what was read
                pass
            for line in parser.text().split('\n'):
                line = ' '.join(line.split())
                if line:
                    paragraphs.append(line)
    return '\n'.join(paragraphs)


class _HTMLText(HTMLParser):
    BLOCK = frozenset(['p', 'div', 'br', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'section',
                       'article', 'blockquote', 'pre', 'ul', 'ol', 'table', 'header', 'footer'])
    SKIP = frozenset(['script', 'style', 'head', 'title', 'nav'])

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self._parts = []
        self._skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self._skip += 1
        if tag in self.BLOCK:
            self._parts.append('\n')

    def handle_endtag(self, tag):
        if tag in self.SKIP and self._skip > 0:
            self._skip -= 1
        if tag in self.BLOCK:
            self._parts.append('\n')

    def handle_data(self, data):
        if self._skip == 0:
            self._parts.append(data)

    def text(self):
        return ''.join(self._parts)


def _extract_notebook(data):
    try:
        doc = json.loads(_decode_plain(data))
    except ValueError:
        return ''
    if not isinstance(doc, dict):
        return ''
    cells = doc.get('cells')
    if not isinstance(cells, list):
        return ''
    out = []
    for cell in cells:
        if not isinstance(cell, dict) or cell.get('cell_type') != 'markdown':
            continue
        source = cell.get('source', '')
        if isinstance(source, list):
            if not all(isinstance(s, str) for s in source):
                continue
            source = ''.join(source)
        if not isinstance(source, str):
            continue
        out.append(source.replace('\r\n', '\n').replace('\r', '\n'))
    return '\n'.join(out)


def extract_prose(data, ext):
    """Return the extracted prose for `data` whose extension is `ext` (lower case)."""
    if ext in NO_PROSE_EXTS:
        return ''
    if ext in ZIP_EXTS:
        text = _extract_zip(_open_zip(data), ext)
        return text.strip()
    if ext == NOTEBOOK_EXT:
        return _extract_notebook(data).strip()
    return _decode_plain(data)


def _check_prose(text):
    if not text.strip():
        raise DetectorError(1, 'empty input')
    return text


# ---------------------------------------------------------------- code masking
# spec: N-000149

_FENCE_OPEN = re.compile(r'^( {0,3})(`{3,}|~{3,})(.*)$')
_BADGE_LINE = re.compile(r'^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$')
_TABLE_ROW = re.compile(r'^\s*\|.*\|\s*$')
_BLOCKQUOTE = re.compile(r'^ {0,3}>')
_INLINE_CODE = re.compile(r'(`+)(?!`).*?(?<!`)\1(?!`)')


def mask_code(text):
    """Blank out code and other non-prose regions, keeping every offset."""
    lines = text.split('\n')
    n = len(lines)
    masked = [False] * n
    # YAML front matter at the very start
    if n and lines[0].strip() == '---':
        for k in range(1, n):
            if lines[k].rstrip() in ('---', '...'):
                for j in range(0, k + 1):
                    masked[j] = True
                break
    # fenced code blocks (CommonMark: a fence closes on a matching run at least as long)
    i = 0
    while i < n:
        m = _FENCE_OPEN.match(lines[i])
        if m and not (m.group(2)[0] == '`' and '`' in m.group(3)):
            ch = m.group(2)[0]
            length = len(m.group(2))
            masked[i] = True
            j = i + 1
            closer = re.compile(r'^ {0,3}' + re.escape(ch) + '{' + str(length) + r',}\s*$')
            while j < n:
                masked[j] = True
                if closer.match(lines[j]):
                    break
                j += 1
            i = j + 1
            continue
        i += 1
    # runs of two or more blockquote lines, table rows, badge lines
    i = 0
    while i < n:
        if _BLOCKQUOTE.match(lines[i]):
            j = i
            while j < n and _BLOCKQUOTE.match(lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    masked[k] = True
            i = j
            continue
        i += 1
    for k in range(n):
        if _TABLE_ROW.match(lines[k]) or _BADGE_LINE.match(lines[k]):
            masked[k] = True
    out = []
    for k, line in enumerate(lines):
        if masked[k]:
            out.append(' ' * len(line))
        else:
            out.append(_INLINE_CODE.sub(lambda m: ' ' * len(m.group(0)), line))
    return '\n'.join(out)


# ---------------------------------------------------------------- helpers

_WORD_RX = re.compile(r"(?:[^\W_]|['’\-])+")
_SENT_RX = re.compile(r"[^.!?\n]+")
_PARA_RX = re.compile(r"\S(?:[^\n]|\n(?!\s*\n))*")


def _words(text):
    return [w for w in _WORD_RX.findall(text) if any(c.isalnum() for c in w)]


def _spans(rx, text):
    return [m.span() for m in rx.finditer(text)]


def _cv(values):
    if len(values) < 2:
        return None
    mean = sum(values) / float(len(values))
    if mean <= 0:
        return None
    var = sum((v - mean) ** 2 for v in values) / float(len(values))
    return math.sqrt(var) / mean


class Ctx(object):
    def __init__(self, raw, masked):
        self.raw = raw
        self.masked = masked
        self.sents = []
        for m in _SENT_RX.finditer(masked):
            if any(c.isalnum() for c in m.group(0)):
                self.sents.append(m.span())
        self.paras = [m.span() for m in _PARA_RX.finditer(masked)]
        self.sent_words = [len(_words(masked[s:e])) for s, e in self.sents]
        self.para_words = [len(_words(masked[s:e])) for s, e in self.paras]
        self.words = _words(masked)
        self.word_count = len(self.words)

    def sentence_text(self, span):
        return self.masked[span[0]:span[1]]


# ---------------------------------------------------------------- character layer
# spec: N-000303 N-000304 N-000305 N-000306 N-000307 N-000308 N-000309 N-000310 N-000311
# spec: N-000312 N-000313 N-000314 N-000315 N-000316 N-000317 N-000318 N-000319 N-000320
# spec: N-000327 N-000328 N-000329 N-000330 N-000331 N-000171 N-000177 N-000178 N-000179
# spec: N-000180 N-000181 N-000220 N-000221 N-000222 N-000223 N-000224

_CONFUSABLES = {}
for _lat, _others in [
    ('a', 'аαա'),
    ('c', 'с'),
    ('d', 'ԁ'),
    ('e', 'е'),
    ('h', 'һ'),
    ('i', 'іι'),
    ('j', 'ј'),
    ('n', 'ո'),
    ('o', 'оοօ'),
    ('p', 'рρ'),
    ('s', 'ѕ'),
    ('u', 'υՍ'),
    ('v', 'ν'),
    ('w', 'ԝ'),
    ('x', 'хχ'),
    ('y', 'у'),
    ('A', 'АΑ'),
    ('B', 'ВΒ'),
    ('C', 'С'),
    ('E', 'ЕΕ'),
    ('H', 'НΗ'),
    ('I', 'ІΙ'),
    ('J', 'Ј'),
    ('K', 'КΚ'),
    ('M', 'МΜ'),
    ('N', 'Ν'),
    ('O', 'ОΟՕ'),
    ('P', 'РΡ'),
    ('S', 'Ѕ'),
    ('T', 'ТΤ'),
    ('X', 'ХΧ'),
    ('Y', 'УΥ'),
    ('Z', 'Ζ'),
]:
    for _ch in _others:
        _CONFUSABLES[_ch] = _lat
_TOKEN_RX = re.compile(r'\S+')


def _is_cjk(ch):
    if not ch:
        return False
    o = ord(ch)
    return (0x4E00 <= o <= 0x9FFF or 0x3400 <= o <= 0x4DBF or 0x20000 <= o <= 0x2FFFF
            or 0xF900 <= o <= 0xFAFF or 0x3040 <= o <= 0x30FF or 0x31F0 <= o <= 0x31FF)


def _is_nospace_script(ch):
    if not ch:
        return False
    o = ord(ch)
    return (_is_cjk(ch) or 0x0E00 <= o <= 0x0EFF or 0x1000 <= o <= 0x109F or 0x1780 <= o <= 0x17FF)


def _is_indic_or_joining(ch):
    if not ch:
        return False
    o = ord(ch)
    return (0x0590 <= o <= 0x08FF or 0x0900 <= o <= 0x0DFF or 0x1000 <= o <= 0x109F
            or 0x1780 <= o <= 0x17FF)


def _is_emoji_or_symbol(ch):
    if not ch:
        return False
    o = ord(ch)
    if o >= 0x1F000 or 0x2600 <= o <= 0x27BF:
        return True
    return unicodedata.category(ch) in ('So', 'Sm')


def _is_invisible_candidate(ch):
    if ch in '\t\n\r':
        return False
    o = ord(ch)
    cat = unicodedata.category(ch)
    if cat in ('Cc', 'Cf'):
        return True
    if 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF or 0x180B <= o <= 0x180F:
        return True
    return o in (0x115F, 0x1160, 0x3164, 0xFFA0)


def _keep_invisible(text, i, ch, has_rtl):
    """True when an invisible-looking character does a job in its position (FP-03)."""
    o = ord(ch)
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if 0xE0020 <= o <= 0xE007F:
        j = i
        while j > 0 and 0xE0020 <= ord(text[j - 1]) <= 0xE007F:
            j -= 1
        base = text[j - 1] if j > 0 else ''
        return base == '\U0001F3F4'
    if 0x180B <= o <= 0x180F:
        return 0x1800 <= ord(prev or '\x00') <= 0x18AF if prev else False
    if 0xE0100 <= o <= 0xE01EF:
        return _is_cjk(prev)
    if 0xFE00 <= o <= 0xFE0F:
        return _is_emoji_or_symbol(prev) or _is_cjk(prev) or nxt == '\u20e3'
    if o in (0x200C, 0x200D):
        return (_is_indic_or_joining(prev) or _is_indic_or_joining(nxt)
                or _is_emoji_or_symbol(prev) or _is_emoji_or_symbol(nxt))
    if o == 0x200B:
        return _is_nospace_script(prev) or _is_nospace_script(nxt)
    if o == 0x00AD:
        return prev.isalpha() and nxt.isalpha()
    if o in (0x200E, 0x200F, 0x061C) or 0x202A <= o <= 0x202E or 0x2066 <= o <= 0x2069:
        return has_rtl
    return False


def _has_rtl(text):
    return re.search(r'[\u0590-\u08ff]', text) is not None


def invisible_removals(text):
    """Indices of invisible characters that cleanup removes (and detection counts)."""
    has_rtl = _has_rtl(text)
    out = []
    for i, ch in enumerate(text):
        if _is_invisible_candidate(ch) and not _keep_invisible(text, i, ch, has_rtl):
            out.append(i)
    return out


def nonstandard_space_removals(text):
    """Indices of space separators that cleanup normalises (and detection counts)."""
    out = []
    for i, ch in enumerate(text):
        if ch == ' ':
            continue
        cat = unicodedata.category(ch)
        if cat not in ('Zs', 'Zl', 'Zp'):
            continue
        if ch in ('\u00a0', '\u202f'):
            prev = text[i - 1] if i > 0 else ''
            nxt = text[i + 1] if i + 1 < len(text) else ''
            if prev.isdigit() or nxt.isdigit() or nxt in ':;!?»›%€' or prev in '«‹':
                continue
        out.append(i)
    return out


def homoglyph_tokens(text):
    """(start, end, folded) for whitespace-delimited tokens that mix Latin with lookalikes."""
    out = []
    for m in _TOKEN_RX.finditer(text):
        tok = m.group(0)
        if not any(c in _CONFUSABLES for c in tok):
            continue
        if not any(('A' <= c <= 'Z') or ('a' <= c <= 'z') for c in tok):
            continue
        ok = True
        for c in tok:
            if c.isalpha() and ord(c) > 127 and c not in _CONFUSABLES:
                ok = False
                break
        if ok:
            out.append((m.start(), m.end(), ''.join(_CONFUSABLES.get(c, c) for c in tok)))
    return out


def trailing_whitespace_spans(text):
    spans = []
    pos = 0
    lines = text.split('\n')
    for idx, line in enumerate(lines):
        stripped = line.rstrip(' \t')
        if len(stripped) != len(line):
            spans.append((pos + len(stripped), pos + len(line)))
        pos += len(line) + 1
    if text and text[0] in ' \t\n':
        spans.append((0, 1))
    if text and text[-1] in ' \t':
        if not spans or spans[-1][1] != len(text):
            spans.append((len(text) - 1, len(text)))
    if text.endswith('\n\n'):
        spans.append((len(text) - 2, len(text)))
    return spans


def clean_text(text):
    """FP-03 cleanup: fold lookalikes, drop invisible characters, normalise spaces, trim."""
    folded = list(text)
    for start, end, repl in homoglyph_tokens(text):
        folded[start:end] = list(repl)
    folded = ''.join(folded)
    inv = set(invisible_removals(folded))
    nons = set(nonstandard_space_removals(folded))
    out = []
    for i, ch in enumerate(folded):
        if i in inv:
            continue
        if i in nons:
            out.append('\n' if unicodedata.category(ch) in ('Zl', 'Zp') else ' ')
            continue
        out.append(ch)
    body = ''.join(out)
    lines = [line.rstrip(' \t') for line in body.split('\n')]
    while lines and lines[0].strip() == '':
        lines.pop(0)
    result = '\n'.join(lines).rstrip()
    if text.endswith('\n') and result:
        result += '\n'
    return result


# ---------------------------------------------------------------- lexical families
# spec: N-000150 N-000151 N-000152 N-000153 N-000154 N-000155 N-000156 N-000157 N-000158
# spec: N-000159 N-000160 N-000161 N-000162 N-000163 N-000164 N-000165 N-000166 N-000167
# spec: N-000168 N-000169 N-000170 N-000172 N-000173 N-000174 N-000175 N-000176 N-000182
# spec: N-000183 N-000184 N-000185 N-000186 N-000187 N-000188 N-000189 N-000190 N-000191
# spec: N-000192 N-000193 N-000194 N-000195 N-000196 N-000197 N-000198 N-000199 N-000200
# spec: N-000201 N-000202 N-000203 N-000204 N-000205 N-000206 N-000207 N-000208 N-000209
# spec: N-000210 N-000211 N-000212 N-000213 N-000214 N-000215 N-000216 N-000217 N-000218
# spec: N-000219 N-000120 N-000121 N-000122 N-000123 N-000124 N-000125 N-000126 N-000127
# spec: N-000128 N-000129 N-000131 N-000132 N-000133 N-000134 N-000135 N-000136 N-000137
# spec: N-000138 N-000139 N-000140 N-000141 N-000142 N-000143 N-000144 N-000145 N-000146
# spec: N-000147 N-000148 N-000116 N-000117 N-000118 N-000119

Hit = collections.namedtuple('Hit', 'key num label spans count advice samples')

ADVICE_KEYS = frozenset([
    '4_hyphenated_pairs', '19_filler_phrases', '22_persuasive_tropes', '41_alternation',
    '42_opener_repetition', '46_semicolon_underuse', '54_stacked_hedges', '55_contraction_absence',
    '58_em_dash_overuse', '60_curly_quotes', '61_year_range_hyphen', '68_trailing_whitespace',
    '17_negative_parallelism',
])
DECISIVE_NUMS = frozenset([13, 47, 48, 50, 62, 63, 64, 65, 66])
RHYTHM_NUMS = frozenset([40, 41, 44, 55])
SHORT_CHECK_NUMS = frozenset(list(range(1, 40)) + [47, 48, 49, 50, 51, 69])


def _rx(pattern, flags=re.I):
    return re.compile(pattern, flags)


_AI_VOCAB = _rx(
    r"\b(?:additionally|align(?:s|ed|ing)? with|crucial|delv(?:e|es|ed|ing)|tapestr(?:y|ies)|pivotal"
    r"|vibrant|meticulous(?:ly)?|testament|underscor(?:e|es|ed|ing)|intricac(?:y|ies)|intricate"
    r"|interplay|garner(?:s|ed|ing)?|bolster(?:s|ed|ing)?|foster(?:s|ed|ing)?|showcas(?:e|es|ed|ing)"
    r"|emphasi[sz](?:e|es|ed|ing)|enduring|enhanc(?:e|es|ed|ing)|leverag(?:e|es|ed|ing)"
    r"|utiliz(?:e|es|ed|ing)|facilitat(?:e|es|ed|ing)|encompass(?:es|ed|ing)?|harness(?:es|ed|ing)?"
    r"|holistic|paradigms?|transformative|unprecedented|myriad|plethora|robust|seamless(?:ly)?"
    r"|navigat(?:e|es|ed|ing)|embark(?:s|ed|ing)?|craft(?:s|ed|ing)?|landscapes?|journeys?|realms?"
    r"|multifaceted|elevat(?:e|es|ed|ing)|empower(?:s|ed|ing)?|unlock(?:s|ed|ing)?"
    r"|capture the (?:essence|spirit|imagination|heart|magic))\b")
_DIALECT = _rx(
    r"\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly"
    r"|quietly (?:powerful|profound|radical)|deeply (?:human|personal|felt|unsettling)"
    r"|resonates deeply|game-chang(?:er|ers|ing)|supercharg(?:e|es|ed|ing)|skyrocket(?:s|ed|ing)?"
    r"|turbocharg(?:e|es|ed|ing)|revolutioniz(?:e|es|ed|ing)|double down on"
    r"|dive deep(?:er)? into|unlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)"
    r"|take [^.!?\n]{1,40}? to the next level)\b")
_PROMO = _rx(
    r"\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|vibrant community"
    r"|rich cultural heritage|in the heart of|world-class|top-tier|unparalleled|premier|leading"
    r"|esteemed organization|valuable asset|passion for excellence|proven track record"
    r"|results-oriented|wealth of experience|dynamic team|fast-paced environment|deeply passionate"
    r"|perfectly situated|close-knit team|tight-knit team|I am excited to (?:apply|bring)"
    r"|uniquely positioned to)\b", 0)
_MKT_OPENER = _rx(
    r"(?:^|(?<=[.!?]\s)|(?<=\n))(?:install|join|grab|download|try|discover|experience|escape"
    r"|transform|reclaim|unlock|elevate|boost|say|imagine|explore|meet|introducing|upgrade|claim"
    r"|unleash|supercharge|level|stop|start)\b", re.M | re.I)
_SIMPLE_YET = _rx(r"\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b")
_HYPHEN_PAIRS = _rx(
    r"\b(?:cutting-edge|best-in-class|data-driven|customer-centric|results-driven|value-driven"
    r"|mission-critical|next-generation|state-of-the-art|top-notch)\b")
_ADJ_SUFFIX = re.compile(r"(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$", re.I)
_STOCK_ADJ = frozenset(['powerful', 'elegant', 'seamless', 'robust', 'innovative', 'dynamic', 'vibrant',
                        'modern', 'comprehensive', 'intuitive', 'scalable', 'reliable', 'secure',
                        'efficient', 'smart', 'bold', 'sleek', 'cutting-edge', 'stunning', 'premier'])
_LIST_RUN = re.compile(r"\b[A-Za-z][A-Za-z'-]*(?:(?:,\s*(?:and\s+)?|\s+and\s+)[A-Za-z][A-Za-z'-]*){3,}\b")
_SYNONYMS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]
_SIGNIFICANCE = [
    _rx(r"\b(?:stands?|serves?|stood|served) as an? (?:testament|reminder|symbol|beacon|cornerstone"
        r"|bridge|gateway|hallmark)\b"),
    _rx(r"\b(?:underscor|highlight)(?:es|ed|ing|s)? (?:its|the|their|his|her) (?:importance|significance"
        r"|enduring|central|vital|crucial|pivotal|key)\b"),
    _rx(r"\breflects? a broader (?:trend|shift|pattern)\b"),
    _rx(r"\bmarks? a (?:turning point|milestone|watershed|new chapter|new era)\b"),
    _rx(r"\bsymbolizes\b"),
    _rx(r"\bsets? the stage for\b"),
    _rx(r"\bleft an indelible mark\b"),
    _rx(r"\bplays? an? (?:crucial|pivotal|vital|key|central|significant) role\b"),
    _rx(r"\bhas (?:shaped|sparked)\b|\bhas come to (?:define|symbolize)\b"),
]
_NOTABILITY = [
    _rx(r"\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by)\b[^.!?\n]{0,200}?"
        r"(?-i:[A-Z][A-Za-z&]+)(?:,| and) (?-i:[A-Z][A-Za-z&]+)"),
    _rx(r"\b\d[\d,.]*\s*(?:[kKmM]|thousand|million)?\s+(?:followers|subscribers)\b"),
    _rx(r"\b(?:strong|active) (?:online|digital|social[- ]media) presence\b|\bwidely covered\b"
        r"|\bindependent coverage\b"),
]
_VAGUE = _rx(
    r"\bexperts? (?:argue|believe|say|claim|note|suggest)\b|\bindustry (?:reports|observers|analysts)\b"
    r"|\bobservers (?:have )?(?:cited|noted)\b|\bsome critics argue\b|\bresearchers have found\b"
    r"|\bstudies suggest\b|\bit is widely believed\b")
_TITLE_PROPER = re.compile(r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of "
                           r"(?:[^\s.!?,]+ ){1,8}?(?:is|are) (?:a|an|the)\b")
_CONSERVATION = _rx(
    r"\bplays? an? (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b"
    r"|\bconservation efforts are (?:underway|ongoing|in place)\b|\bserves as an indicator species\b"
    r"|\bcontributes to biodiversity\b")
_FALSE_RANGE = _rx(
    r"\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]{0,200}?"
    r"\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b"
    r"|\bfrom (?:the )?humble\b[^.!?\n]{0,200}?\bto (?:the )?(?:mighty|towering|grand|sprawling)\b")
_ING_TAIL = _rx(
    r",\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering"
    r"|cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting"
    r"|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b")
_PARALLEL = _rx(
    r"\bit['’]s not (?:just|merely) (?:about|an?)\b"
    r"|\bnot only\b[^.!?\n]{0,40}?\bbut\b"
    r"|\bdoesn['’]t just\b[^,.\n]{0,40}?\bit\b")
_TAILING_NEG = _rx(
    r",\s+no (?:wasted motion|guessing|waste|hassle|fluff|stress|jargon)\b")
_NOT_X_JUST_Y_A = _rx(r"\b(?:no|not) \w+, (?:just|only|simply) \w+")
_NOT_X_JUST_Y_B = _rx(
    r"\b(?:not|isn['’]t|aren['’]t|wasn['’]t|weren['’]t) (?:just|merely) "
    r"(?:(?:a|an|the) )?\w+(?:,\s*|\s*[—–]\s*|\s+--\s*)"
    r"(?:it['’]s|it is|it was|they['’]re|they are|they were|that['’]s|but)\b")
_FILLER = _rx(
    r"\bin order to\b|\bdue to the fact that\b|\bat this point in time\b|\bin the event that\b"
    r"|\bhas the ability to\b|\bit is important to note that\b|\bit should be mentioned that\b"
    r"|\bneedless to say\b")
_EMPTY_PIVOT = _rx(
    r"\bit['’]s worth (?:noting|mentioning) that\b|\bit bears (?:noting|mentioning) that\b"
    r"|\bone thing to (?:consider|keep in mind) is\b|\bit is interesting to note that\b"
    r"|\ba key consideration is\b|\ba point to highlight is\b")
_OUTCOME_TAIL = _rx(
    r",\s+(?:raising questions about|prompting reflection on|sparking debate about"
    r"|with broader implications for|reshaping our understanding of|paving the way for"
    r"|signaling a shift toward)\b")
_PERSUASIVE = _rx(
    r"\bhere['’]s the thing\b|\bmake no mistake\b|\bthe truth is\b|\blet['’]s be honest\b"
    r"|\bthe simple fact is\b|\bat its core\b|\bwhat really matters\b|\bmore than anything\b"
    r"|\bat the end of the day\b|\bthe bottom line is\b|\bin reality\b|\bfundamentally,"
    r"|\bthe real question is\b|\bthe heart of the matter\b|\bthe deeper issue\b"
    r"|\bwhen you get down to it\b|\bwhen all is said and done\b")
_EDITORIAL = _rx(
    r"\bit(?:['’]s| is) important to (?:remember|note|understand|recognize)\b|\bone must note that\b"
    r"|\bit is worth pointing out\b|\bit cannot be overstated that\b|\bit must be emphasi[sz]ed that\b")
_SELF_THOROUGH = _rx(
    r"\bthis (?:comprehensive (?:guide|overview|analysis)|in-depth (?:analysis|look|examination)"
    r"|complete (?:guide|overview))\b|\ba thorough examination of\b|\beverything you need to know about\b")
_QA_RHET = _rx(
    r"(?:^|(?<=[.!?\n]\s)|(?<=\n))(?:Is|Are|Do|Does|Can|Will|Should|Would|Could|Have|Has|Was|Were|Did"
    r"|May|Might)\b[^.?!\n]{0,80}\?\s*(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)[.!]", re.M)
_CONCRETE = _rx(
    r"\bwithout concrete (?:evidence|proof)\b|\bdo you have concrete evidence\b"
    r"|\bI (?:would )?need concrete (?:evidence|examples)\b|\babsent concrete proof\b"
    r"|\bprovide concrete evidence\b", re.I)
_INTRO_HOOK = _rx(
    r"\bin today['’]s (?:\S+\s+){0,2}?(?:world|landscape|environment|market)\b|\bin a world where\b"
    r"|\bin an era of\b|\bin recent years,|\bmore than ever before\b|\bwe live in a (?:time|world) when\b"
    r"|\b(?:great|exciting|big) news\s*[!:]|\bever (?:wanted|wondered|dreamed|wished)\b[^?\n]{0,80}\?"
    r"|\bin an increasingly (?:interconnected|digital|competitive|complex) world\b")
_DIFF_ANCHOR = _rx(
    r"\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b"
    r"|\b(?:the|this) (?:latest |new )?(?:update|release|version|change|patch|design) "
    r"(?:adds|introduces|brings|delivers|includes|provides|improves)\b"
    r"|\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b"
    r"|\bpreviously\b[^.!?\n]{0,200}?\bnow\b|\bwasn['’]t there before\b|\bweren['’]t there before\b"
    r"|\bwe(?:['’]ve| have) (?:now )?(?:added|removed|replaced|refactored|migrated)\b")
_SIGNPOST = _rx(
    r"\blet['’]s (?:dive|delve|explore)\b|\blet['’]s (?:break (?:this|it) down|break down)\b"
    r"|\bhere['’]s what you need to know\b|\bwithout further ado\b|\bnow let['’]s look at\b"
    r"|\bbuckle up\b|\bstay with me\b|\bready to dive in\b")
_CATALOGUE_A = _rx(r"\b(?:used|uses|employ|employs|employed|relied on|utilizes)\s+"
                   r"(?:several|various|a number of|multiple|different|many|numerous)\s+\w+")
_CATALOGUE_B = re.compile(r"(?:^|(?<=[.!?]\s)|(?<=\n))These\s+(?:\w+\s+)?"
                          r"(?:provide|offer|give|reveal|show|allow|enable|help)\s+"
                          r"(?:information|insight|understanding|details|data)\b", re.M)
_CATALOGUE_C = _rx(r"\b(?:is|are|was|were|remains|becomes)\s+(?:the|a)\s+(?:language|currency|architecture"
                   r"|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue)\s+of\b")
_INLINE_HEADER = re.compile(r"^[ \t]*(?:(?:[-*+]|\d+\.)[ \t]+)?\*\*[^*\n]+(?::\*\*|\*\*:)", re.M)
_HEADING = re.compile(r"^#{1,6}[ \t]+(.+?)[ \t]*#*[ \t]*$", re.M)
_LIST_LINE = re.compile(r"^\s*(?:[-*+]|\d+[.)])\s+")
_TRANSITION_OPENER = re.compile(r"(?:^|(?<=[.!?]\s)|(?<=\n))(Additionally|Furthermore|Moreover|However|"
                                r"Nevertheless|Consequently|Subsequently|Notably)\b", re.M)
_CONCLUSION = _rx(r"^[ \t]*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all"
                  r"|in essence|ultimately)\b", re.M)
_POSITIVE_END = _rx(
    r"\bthe future looks bright\b|\bexciting times lie ahead\b|\bjourney toward excellence\b"
    r"|\bstep in the right direction\b|\b(?:the )?(?:outlook|future)(?: for [^.!?\n,]{1,40})? "
    r"(?:is|looks|remains) bright\b|\bwell[- ]positioned (?:for )?(?:whatever comes next|the future"
    r"|the road ahead)\b")
_CHATBOT = _rx(
    r"\bI hope this helps\b|\b(?:Certainly|Of course)!|\blet me know if you\b|\bwould you like me to\b"
    r"|\bfeel free to (?:ask|reach out)\b|\bhappy to help[.!](?=\s|$)"
    r"|\bhere (?:is|are|'s|’s) (?:an? )?(?:overview|summary|rundown|recap|brief)\b"
    r"|\bhere (?:are|'s|’s) (?:a few|some|two|three) (?:options|drafts|versions|variations)\b"
    r"|\bhere (?:is|'s|’s) a draft\b|\bdepending on the (?:vibe|tone|style)\b"
    r"|\bI hope this email finds you well\b|\bas an (?:AI|LLM)\b|\bas an (?:AI language model|large language model"
    r"|AI assistant)\b|\bto (?:answer|address) your question\b|\bin (?:response|answer) to your question\b"
    r"|\byour question (?:about|regarding|concerning)\b|\bas you (?:requested|asked), here\b"
    r"|\bhere (?:is|'s|’s) (?:the )?(?:draft|first pass|revised version) (?:of|for your)\b")
_SYCOPHANT = _rx(
    r"\byou(?:['’]re| are) absolutely right\b"
    r"|\b(?:great|excellent|good|fantastic|wonderful|thoughtful|brilliant|insightful) question[!.,]"
    r"|\bwhat a (?:thoughtful|great|wonderful|fantastic) question\b"
    r"|\bthat['’]s a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b"
    r"|\b(?:great|excellent) point[!.,]")
_CUTOFF = _rx(
    r"\bas of my (?:last )?(?:training|knowledge)\b|\bup to my (?:last )?(?:training|knowledge)\b"
    r"|\bwhile specific details are (?:limited|scarce|not extensively (?:or widely )?documented)\b"
    r"|\bbased on (?:the )?available information\b|\bas of my (?:knowledge )?cutoff\b"
    r"|\bmaintains a low profile\b|\bkeeps (?:his|her|their) personal life private\b")
_COPULA = _rx(
    r"\b(?:serves as|stands as|functions as|acts as|boasts|refers to|represents (?:a|the)|marks (?:a|the)"
    r"|offers a|features (?:a|an|the|\d+|one|two|three|several|many|numerous))\b")
_HEDGE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems? to|seems? like"
                    r"|appears? to|somewhat|relatively|fairly|kind of|sort of)\b")
_FIRST_PERSON = frozenset(['I', 'we', 'We', 'my', 'My', 'our', 'Our', 'me', 'us'])
_WRITTEN_FORMS = _rx(r"\b(?:do not|does not|did not|is not|are not|was not|were not|have not|has not"
                     r"|will not|would not|should not|could not|I am|I will|I have|I would|we are|we have"
                     r"|we will|that is|it is|there is|you are|they are|let us)\b", re.I)
_CONTRACTED_FORMS = _rx(r"\b(?:don['’]t|doesn['’]t|didn['’]t|isn['’]t|aren['’]t"
                        r"|wasn['’]t|weren['’]t|haven['’]t|hasn['’]t|won['’]t"
                        r"|wouldn['’]t|shouldn['’]t|couldn['’]t|I['’]m|I['’]ll"
                        r"|I['’]ve|I['’]d|we['’]re|we['’]ll|we['’]ve|that['’]s"
                        r"|it['’]s|there['’]s|you['’]re|they['’]re|let['’]s)\b", re.I)
_BOLD = re.compile(r"\*\*[^*\n]+?\*\*")
_EMOJI = re.compile(u"[\U0001F300-\U0001FAFF☀-➿]")
_EM_DASH = re.compile(u"—")
_CURLY = re.compile(u"[‘’“”]")
_YEAR_RANGE = re.compile(r"\b(1[5-9]\d\d|20\d\d)-(1[5-9]\d\d|20\d\d)\b")
_PLACEHOLDER = [
    _rx(r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]{0,200}\](?![(\[])"),
    re.compile(r"\[[A-Z][A-Z ]{2,}\](?![(\[])"),
    re.compile(r"\{\{[^}\n]{0,200}\}\}"),
    _rx(r"(?<![\w])x{3,}(?![\w])"),
    _rx(r"\blorem ipsum\b"),
]
_CHAT_MARKUP = _rx(r"\bcite(?:turn|start|nav)\w*|\boai_citation\w*|\bcontentReference\b|\bnavlist\b"
                   u"|【\\d+†[^】\\n]{0,200}】", 0)
_UTM = re.compile(r"utm_source=([A-Za-z0-9.\-]+)")
_UTM_HOSTS = frozenset(['chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai',
                        'gemini.google.com', 'copilot.microsoft.com', 'poe.com'])
_SLOP = _rx(
    r"\bunlocking (?:(?:its|your|the) )?full potential\b|\bnavigating the complexities\b"
    r"|\ba testament to the (?:power|importance) of\b|\bstaying ahead of the curve\b"
    r"|\bturning challenges into opportunities\b|\btaking (?:it|something|your \w+|\w+) to the next level\b"
    r"|\bharnessing the power of\b|\bpaving the way for\b|\bsaying goodbye to\b"
    r"|\bimagining a world where\b")
_RULE_LINE = re.compile(r"^[ \t]*(?:-{3,}|\*{3,}|_{3,})[ \t]*$", re.M)
_TITLE_SMALL = frozenset(['a', 'an', 'the', 'of', 'in', 'on', 'at', 'to', 'for', 'by', 'with', 'from',
                          'up', 'as', 'into', 'onto', 'per', 'via', 'over', 'and', 'or', 'but', 'nor',
                          'so', 'yet'])


def _sample_list(raw, spans):
    out = []
    for s, e in spans[:3]:
        out.append(_excerpt(raw, s, e))
    return out


def _excerpt(raw, s, e):
    a = max(0, s - 30)
    b = min(len(raw), e + 30)
    frag = raw[a:b].replace('\r', ' ').replace('\n', ' ')
    out = ('...' if a > 0 else '') + frag + ('...' if b < len(raw) else '')
    if len(out) > 140:
        out = out[:137] + '...'
    return out


def _hit(key, label, raw, spans, count=None, advice=False, samples=None):
    num = int(key.split('_', 1)[0])
    if count is None:
        count = len(spans)
    if samples is None:
        samples = _sample_list(raw, spans)
    return Hit(key, num, label, spans, count, advice, samples)


def _rx_hits(ctx, rx, text=None):
    text = ctx.masked if text is None else text
    return _spans(rx, text)


def _rule_list_hits(ctx, key, label, regexes, advice=False, min_hits=1):
    spans = []
    for rx in regexes:
        spans.extend(_rx_hits(ctx, rx))
    if len(spans) < min_hits:
        return []
    spans.sort()
    return [_hit(key, label, ctx.raw, spans, advice=advice)]


def _rule_synonyms(ctx):
    spans = []
    fired = 0
    for cluster in _SYNONYMS:
        members = []
        for term in cluster:
            rx = re.compile(r"\b" + re.escape(term) + r"(?:s|es)?\b", re.I)
            found = _spans(rx, ctx.masked)
            if found:
                members.append(term)
                spans.extend(found)
        if len(members) >= 3:
            fired += 1
    if not fired:
        return []
    spans.sort()
    return [_hit('8_synonym_cycling', 'synonym cycling', ctx.raw, spans, count=fired)]


def _rule_sentence_monotony(ctx):
    counts = [c for c in ctx.sent_words if c > 0]
    if len(counts) < 3:
        return []
    cv = _cv(counts)
    if cv is None or cv >= 0.35:
        return []
    spans = ctx.sents[:3]
    return [_hit('40_sentence_monotony', 'sentence-length monotony', ctx.raw, spans, count=1)]


def _rule_alternation(ctx):
    lengths = ctx.sent_words
    idx = [i for i, c in enumerate(lengths) if c > 0]
    vals = [lengths[i] for i in idx]
    if len(vals) < 6:
        return []
    for k in range(len(vals) - 5):
        window = vals[k:k + 6]
        ok = True
        for j in range(1, 5):
            d1 = window[j] - window[j - 1]
            d2 = window[j + 1] - window[j]
            if not ((d1 > 0) != (d2 > 0) and min(abs(d1), abs(d2)) >= 6 and d1 != 0 and d2 != 0):
                ok = False
                break
        if ok:
            spans = [ctx.sents[i] for i in idx[k:k + 6]]
            return [_hit('41_alternation', 'mechanical sentence-length alternation', ctx.raw, spans,
                         count=1, advice=True)]
    return []


def _rule_uniform_paragraphs(ctx):
    counts = [c for c in ctx.para_words if c > 0]
    if len(counts) < 4:
        return []
    cv = _cv(counts)
    if cv is None or cv >= 0.4:
        return []
    return [_hit('44_uniform_paragraphs', 'uniform paragraph length', ctx.raw, ctx.paras[:3], count=1)]


def _rule_opener_repetition(ctx):
    spans = []
    paragraphs = 0
    for ps, pe in ctx.paras:
        sents = [s for s in ctx.sents if s[0] >= ps and s[1] <= pe]
        if len(sents) < 3:
            continue
        keys = {}
        for s in sents:
            words = _words(ctx.masked[s[0]:s[1]])[:2]
            if len(words) < 2:
                continue
            keys.setdefault(' '.join(w.lower() for w in words), []).append(s)
        for group in keys.values():
            if len(group) >= 3:
                paragraphs += 1
                spans.extend(group)
                break
    if not paragraphs:
        return []
    return [_hit('42_opener_repetition', 'repeated sentence openers', ctx.raw, spans, count=paragraphs,
                 advice=True)]


def _rule_semicolons(ctx):
    if ctx.word_count < 300:
        return []
    if ';' in ctx.masked or ctx.masked.count('(') > 1:
        return []
    return [_hit('46_semicolon_underuse', 'semicolon and parenthesis underuse', ctx.raw,
                 [(0, len(ctx.masked))], count=1, advice=True)]


def _rule_hedges(ctx):
    spans = []
    for s, e in ctx.sents:
        found = _spans(_HEDGE, ctx.masked[s:e])
        if len(found) >= 2:
            spans.append((s, e))
    if not spans:
        return []
    return [_hit('54_stacked_hedges', 'stacked hedges', ctx.raw, spans, advice=True)]


def _rule_contractions(ctx):
    pronouns = sum(1 for w in ctx.words if w in _FIRST_PERSON)
    if ctx.word_count == 0 or pronouns < 3 or pronouns / float(ctx.word_count) < 0.02:
        return []
    written = _spans(_WRITTEN_FORMS, ctx.masked)
    contracted = len(_spans(_CONTRACTED_FORMS, ctx.masked))
    if len(written) < 3 or len(written) < 2 * contracted:
        return []
    return [_hit('55_contraction_absence', 'contraction absence', ctx.raw, written, advice=True)]


def _rule_boldface(ctx):
    spans = _spans(_BOLD, ctx.masked)
    if len(spans) < 3:
        return []
    return [_hit('56_boldface_overuse', 'boldface overuse', ctx.raw, spans)]


def _rule_em_dash(ctx):
    spans = []
    paragraphs = 0
    for ps, pe in ctx.paras:
        found = [(m.start() + ps, m.end() + ps) for m in _EM_DASH.finditer(ctx.masked[ps:pe])]
        if len(found) >= 2:
            paragraphs += 1
            spans.extend(found)
    if not paragraphs:
        return []
    return [_hit('58_em_dash_overuse', 'em-dash overuse', ctx.raw, spans, count=paragraphs, advice=True)]


def _rule_title_case(ctx):
    spans = []
    for m in _HEADING.finditer(ctx.masked):
        text = m.group(1)
        words = re.findall(r"[A-Za-z][A-Za-z'’-]*", text)
        if len(words) < 3 or not text[:1].isalpha():
            continue
        if all(w.isupper() for w in words):
            continue
        major = [w for w in words if w.lower() not in _TITLE_SMALL]
        if len(major) < 2:
            continue
        if all(w[0].isupper() for w in major):
            spans.append(m.span())
    if not spans:
        return []
    return [_hit('59_title_case_heading', 'title case in headings', ctx.raw, spans)]


def _rule_curly(ctx):
    spans = _spans(_CURLY, ctx.masked)
    if not spans:
        return []
    return [_hit('60_curly_quotes', 'curly quotation marks', ctx.raw, spans, advice=True)]


def _rule_year_ranges(ctx):
    spans = []
    for m in _YEAR_RANGE.finditer(ctx.masked):
        if int(m.group(1)) < int(m.group(2)):
            spans.append(m.span())
    if not spans:
        return []
    return [_hit('61_year_range_hyphen', 'hyphen for en dash in year range', ctx.raw, spans, advice=True)]


def _rule_placeholder(ctx):
    spans = []
    for rx in _PLACEHOLDER:
        spans.extend(_spans(rx, ctx.masked))
    if not spans:
        return []
    spans.sort()
    return [_hit('63_placeholder_text', 'placeholder text', ctx.raw, spans)]


def _rule_utm(ctx):
    spans = []
    for m in _UTM.finditer(ctx.masked):
        host = m.group(1).rstrip('.').lower()
        if host in _UTM_HOSTS:
            spans.append(m.span())
    if not spans:
        return []
    return [_hit('65_ai_tracking_params', 'AI tracking parameter', ctx.raw, spans)]


def _rule_rules(ctx):
    spans = _spans(_RULE_LINE, ctx.masked)
    if len(spans) < 3 or ctx.masked.count('\n') + 1 < 24:
        return []
    return [_hit('70_decorative_rules', 'decorative horizontal rules', ctx.raw, spans)]


def _rule_degenerate(ctx):
    toks = [(m.start(), m.end(), m.group(0).lower()) for m in re.finditer(r"[^\W_]+", ctx.masked)]
    if len(toks) < 6:
        return []
    grams = {}
    for k in range(len(toks) - 5):
        key = tuple(t[2] for t in toks[k:k + 6])
        grams.setdefault(key, []).append(k)
    total = len(toks) - 5
    repeated = [k for g in grams.values() if len(g) > 1 for k in g]
    if not repeated or len(repeated) / float(total) < 0.2:
        return []
    spans = [(toks[k][0], toks[k + 5][1]) for k in sorted(repeated)[:3]]
    return [_hit('71_degenerate_repetition', 'degenerate repetition', ctx.raw, spans, count=1)]


def _rule_transitions(ctx):
    spans = []
    paragraphs = 0
    for ps, pe in ctx.paras:
        found = [(m.start(1) + 0, m.end(1)) for m in _TRANSITION_OPENER.finditer(ctx.masked[ps:pe])]
        found = [(s + ps, e + ps) for s, e in found]
        if len(found) >= 2:
            paragraphs += 1
            spans.extend(found)
    if not spans:
        return []
    return [_hit('37_transition_cluster', 'transition cluster overuse', ctx.raw, spans, count=paragraphs)]


def _rule_list_paragraphs(ctx):
    if re.search(r"^\s{0,3}#{1,6}\s", ctx.masked, re.M):
        return []
    list_paras = []
    prose = 0
    for ps, pe in ctx.paras:
        block = ctx.masked[ps:pe]
        lines = [ln for ln in block.split('\n') if ln.strip()]
        if lines and all(_LIST_LINE.match(ln) for ln in lines):
            list_paras.append((ps, pe))
        else:
            prose += 1
    if not list_paras or prose < 2:
        return []
    return [_hit('34_mid_essay_bullets', 'mid-essay bullet injection', ctx.raw, list_paras)]


def _rule_fragmented_headers(ctx):
    lines = ctx.masked.split('\n')
    offsets = []
    pos = 0
    for ln in lines:
        offsets.append(pos)
        pos += len(ln) + 1
    spans = []
    for idx, ln in enumerate(lines):
        m = re.match(r"^#{1,6}[ \t]+(.+)$", ln)
        if not m:
            continue
        heading_words = set(w.lower() for w in re.findall(r"[A-Za-z]{4,}", m.group(1)))
        j = idx + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if not nxt or nxt[0] in '#-*+|>`' or re.match(r"^\d+[.)]\s", nxt):
            continue
        words = nxt.split()
        if len(words) > 5:
            continue
        if heading_words & set(w.lower() for w in re.findall(r"[A-Za-z]{4,}", nxt)):
            spans.append((offsets[j], offsets[j] + len(lines[j])))
    if not spans:
        return []
    return [_hit('35_fragmented_headers', 'fragmented header', ctx.raw, spans)]


def _rule_inline_headers(ctx):
    spans = _spans(_INLINE_HEADER, ctx.masked)
    if not spans:
        return []
    return [_hit('33_inline_header_list', 'inline-header vertical list', ctx.raw, spans)]


def _rule_title_proper(ctx):
    spans = _spans(_TITLE_PROPER, ctx.masked)
    if not spans:
        return []
    return [_hit('13_article_title_proper_noun', 'article title used as a proper noun', ctx.raw, spans)]


def _rule_negation_forms(ctx):
    hits = []
    par = _spans(_PARALLEL, ctx.masked)
    if par:
        hits.append(_hit('17_negative_parallelism', 'negative parallelism', ctx.raw, par, advice=True))
    tail = _spans(_TAILING_NEG, ctx.masked)
    if tail:
        hits.append(_hit('17_tailing_negation', 'tailing negation', ctx.raw, tail))
    return hits


def _rule_not_x_just_y(ctx):
    spans = _spans(_NOT_X_JUST_Y_A, ctx.masked) + _spans(_NOT_X_JUST_Y_B, ctx.masked)
    if not spans:
        return []
    spans.sort()
    return [_hit('18_not_x_just_y', '"not X, just Y" contrast', ctx.raw, spans)]


def _rule_chatbot(ctx):
    spans = _spans(_CHATBOT, ctx.masked)
    if not spans:
        return []
    return [_hit('47_chatbot_artifacts', 'chatbot artifact', ctx.raw, spans)]


def _rule_sycophancy(ctx):
    spans = _spans(_SYCOPHANT, ctx.masked)
    if not spans:
        return []
    return [_hit('48_sycophantic_tone', 'sycophantic tone', ctx.raw, spans)]


def _rule_qa(ctx):
    spans = _spans(_QA_RHET, ctx.masked)
    if not spans:
        return []
    return [_hit('25_question_answer_pattern', 'question-answer rhetorical pattern', ctx.raw, spans)]


def _rule_catalogue(ctx):
    spans = _spans(_CATALOGUE_A, ctx.masked) + _spans(_CATALOGUE_B, ctx.masked) + _spans(_CATALOGUE_C, ctx.masked)
    if not spans:
        return []
    spans.sort()
    return [_hit('32_cataloguing_lead_in', 'cataloguing lead-in', ctx.raw, spans)]


def _rule_emoji(ctx):
    spans = _spans(_EMOJI, ctx.masked)
    if not spans:
        return []
    return [_hit('57_emoji', 'emoji', ctx.raw, spans)]


def _rule_conclusions(ctx):
    spans = _spans(_CONCLUSION, ctx.masked)
    if not spans:
        return []
    return [_hit('38_compulsive_conclusion', 'compulsive conclusion opener', ctx.raw, spans)]


def _rule_marketing_openers(ctx):
    """Promotional phrases; three or more marketing-imperative sentence openers also fire."""
    spans = _spans(_PROMO, ctx.masked)
    openers = _spans(_MKT_OPENER, ctx.masked)
    if len(openers) >= 3:
        spans.extend(openers)
    if not spans:
        return []
    spans.sort()
    return [_hit('3_promotional_language', 'promotional language', ctx.raw, spans)]


def _rule_adjective_chains(ctx):
    spans = []
    for m in _LIST_RUN.finditer(ctx.masked):
        words = re.findall(r"[A-Za-z][A-Za-z'-]*", m.group(0))
        if len(words) < 4:
            continue
        if any(w.lower() in _STOCK_ADJ or _ADJ_SUFFIX.search(w) for w in words):
            spans.append(m.span())
    if not spans:
        return []
    return [_hit('6_stacked_adjectives', 'stacked adjective chains', ctx.raw, spans)]


def _rule_significance(ctx):
    spans = []
    for rx in _SIGNIFICANCE:
        spans.extend(_spans(rx, ctx.masked))
    if not spans:
        return []
    spans.sort()
    return [_hit('10_significance_inflation', 'significance inflation', ctx.raw, spans)]


def _rule_notability(ctx):
    spans = []
    for rx in _NOTABILITY:
        spans.extend(_spans(rx, ctx.masked))
    if not spans:
        return []
    spans.sort()
    return [_hit('11_notability_name_dropping', 'notability name-dropping', ctx.raw, spans)]


def _rule_ai_vocab(ctx):
    spans = _spans(_AI_VOCAB, ctx.masked)
    if not spans:
        return []
    return [_hit('1_ai_vocabulary', 'AI vocabulary', ctx.raw, spans)]


def _rule_dialect(ctx):
    spans = _spans(_DIALECT, ctx.masked)
    if len(spans) < 2:
        return []
    return [_hit('2_model_dialect_vocabulary', 'model-dialect vocabulary', ctx.raw, spans)]


def _rule_hyphen_pairs(ctx):
    spans = _spans(_HYPHEN_PAIRS, ctx.masked)
    if not spans:
        return []
    return [_hit('4_hyphenated_pairs', 'hyphenated word-pair overuse', ctx.raw, spans, advice=True)]


def _rule_simple_yet(ctx):
    spans = _spans(_SIMPLE_YET, ctx.masked)
    if not spans:
        return []
    return [_hit('5_simple_yet', '"simple yet" cliche', ctx.raw, spans)]


def _rule_vague(ctx):
    spans = _spans(_VAGUE, ctx.masked)
    if not spans:
        return []
    return [_hit('12_vague_attributions', 'vague attributions', ctx.raw, spans)]


def _rule_conservation(ctx):
    spans = _spans(_CONSERVATION, ctx.masked)
    if not spans:
        return []
    return [_hit('14_conservation_padding', 'conservation and ecosystem padding', ctx.raw, spans)]


def _rule_false_range(ctx):
    spans = _spans(_FALSE_RANGE, ctx.masked)
    if not spans:
        return []
    return [_hit('15_false_range', 'false range', ctx.raw, spans)]


def _rule_ing_tail(ctx):
    spans = _spans(_ING_TAIL, ctx.masked)
    if not spans:
        return []
    return [_hit('16_superficial_ing_tail', 'superficial -ing tail clause', ctx.raw, spans)]


def _rule_filler(ctx):
    spans = _spans(_FILLER, ctx.masked)
    if not spans:
        return []
    return [_hit('19_filler_phrases', 'filler phrases', ctx.raw, spans, advice=True)]


def _rule_empty_pivot(ctx):
    spans = _spans(_EMPTY_PIVOT, ctx.masked)
    if not spans:
        return []
    return [_hit('20_empty_pivot', 'empty pivot phrase', ctx.raw, spans)]


def _rule_outcome(ctx):
    spans = _spans(_OUTCOME_TAIL, ctx.masked)
    if not spans:
        return []
    return [_hit('21_outcome_speculation', 'outcome-speculation tail', ctx.raw, spans)]


def _rule_persuasive(ctx):
    spans = _spans(_PERSUASIVE, ctx.masked)
    if not spans:
        return []
    return [_hit('22_persuasive_tropes', 'persuasive authority trope', ctx.raw, spans, advice=True)]


def _rule_editorial(ctx):
    spans = _spans(_EDITORIAL, ctx.masked)
    if not spans:
        return []
    return [_hit('23_editorial_interjection', 'editorial interjection', ctx.raw, spans)]


def _rule_self_thorough(ctx):
    spans = _spans(_SELF_THOROUGH, ctx.masked)
    if not spans:
        return []
    return [_hit('24_self_thoroughness', 'self-thoroughness phrase', ctx.raw, spans)]


def _rule_concrete(ctx):
    spans = _spans(_CONCRETE, ctx.masked)
    if not spans:
        return []
    return [_hit('26_concrete_evidence_defense', '"concrete evidence" defense phrase', ctx.raw, spans)]


def _rule_intro_hook(ctx):
    spans = _spans(_INTRO_HOOK, ctx.masked)
    if not spans:
        return []
    return [_hit('27_compulsive_intro_hook', 'compulsive intro hook', ctx.raw, spans)]


def _rule_diff_anchor(ctx):
    spans = _spans(_DIFF_ANCHOR, ctx.masked)
    if not spans:
        return []
    return [_hit('30_diff_anchored_writing', 'diff-anchored writing', ctx.raw, spans)]


def _rule_signpost(ctx):
    spans = _spans(_SIGNPOST, ctx.masked)
    if not spans:
        return []
    return [_hit('31_signposting', 'signposting and announcements', ctx.raw, spans)]


def _rule_challenges(ctx):
    spans = _spans(_rx(
        r"\bdespite (?:these|its|the) (?:challenges|obstacles)\b|\bchallenges and (?:future )?(?:prospects"
        r"|outlook|legacy)\b|\bcontinues to thrive\b|\btypical of (?:emerging|urban|modern)\b"
        r"|\bfaces (?:several|many|numerous) challenges\b"), ctx.masked)
    if not spans:
        return []
    return [_hit('36_formulaic_challenges', 'formulaic challenges section', ctx.raw, spans)]


def _rule_positive_end(ctx):
    spans = _spans(_POSITIVE_END, ctx.masked)
    if not spans:
        return []
    return [_hit('39_generic_positive_conclusion', 'generic positive conclusion', ctx.raw, spans)]


def _rule_chat_markup(ctx):
    spans = _spans(_CHAT_MARKUP, ctx.masked)
    if not spans:
        return []
    return [_hit('64_chat_reference_markup', 'chat reference markup', ctx.raw, spans)]


def _rule_cutoff(ctx):
    spans = _spans(_CUTOFF, ctx.masked)
    if not spans:
        return []
    return [_hit('50_knowledge_cutoff_disclaimer', 'knowledge-cutoff disclaimer', ctx.raw, spans)]


def _rule_copula(ctx):
    spans = _spans(_COPULA, ctx.masked)
    if not spans:
        return []
    return [_hit('51_copula_avoidance', 'copula avoidance', ctx.raw, spans)]


def _rule_slop(ctx):
    spans = _spans(_SLOP, ctx.masked)
    if not spans:
        return []
    return [_hit('69_marketing_slop', 'canonical marketing-slop phrase', ctx.raw, spans)]


def _rule_chat_residue(ctx):
    return []


def _rule_char_layer(ctx):
    hits = []
    raw = ctx.raw
    inv = invisible_removals(raw)
    if inv:
        samples = ['U+%04X at character %d' % (ord(raw[i]), i) for i in inv[:3]]
        hits.append(_hit('62_invisible_characters', 'invisible or zero-width characters', raw,
                         [(i, i + 1) for i in inv], samples=samples))
    homo = homoglyph_tokens(raw)
    if homo:
        samples = [_excerpt(raw, s, e) for s, e, _f in homo[:3]]
        hits.append(_hit('66_mixed_script_lookalikes', 'mixed-script lookalike letters', raw,
                         [(s, e) for s, e, _f in homo], samples=samples))
    ns = nonstandard_space_removals(raw)
    if ns:
        samples = ['U+%04X at character %d' % (ord(raw[i]), i) for i in ns[:3]]
        hits.append(_hit('67_nonstandard_spaces', 'non-standard space characters', raw,
                         [(i, i + 1) for i in ns], samples=samples))
    trail = trailing_whitespace_spans(raw)
    if trail:
        samples = ['trailing or stray whitespace at character %d' % s for s, _e in trail[:3]]
        hits.append(_hit('68_trailing_whitespace', 'trailing or stray whitespace', raw, trail,
                         advice=True, samples=samples))
    return hits


_RULES = [
    _rule_ai_vocab, _rule_dialect, _rule_marketing_openers, _rule_hyphen_pairs, _rule_simple_yet,
    _rule_adjective_chains, _rule_synonyms, _rule_significance, _rule_notability, _rule_vague,
    _rule_title_proper, _rule_conservation, _rule_false_range, _rule_ing_tail, _rule_negation_forms,
    _rule_not_x_just_y, _rule_filler, _rule_empty_pivot, _rule_outcome, _rule_persuasive,
    _rule_editorial, _rule_self_thorough, _rule_qa, _rule_concrete, _rule_intro_hook,
    _rule_challenges, _rule_transitions, _rule_conclusions, _rule_positive_end, _rule_chatbot,
    _rule_sycophancy, _rule_cutoff, _rule_copula, _rule_hedges, _rule_contractions,
    _rule_boldface, _rule_emoji, _rule_em_dash, _rule_title_case, _rule_curly, _rule_year_ranges,
    _rule_placeholder, _rule_chat_markup, _rule_utm, _rule_slop, _rule_rules, _rule_degenerate,
    _rule_sentence_monotony, _rule_alternation, _rule_uniform_paragraphs, _rule_opener_repetition,
    _rule_semicolons, _rule_list_paragraphs, _rule_fragmented_headers, _rule_inline_headers,
    _rule_diff_anchor, _rule_signpost, _rule_catalogue, _rule_char_layer,
]


def run_rules(ctx):
    hits = []
    for rule in _RULES:
        hits.extend(rule(ctx))
    hits.sort(key=lambda h: (h.num, h.key))
    return hits


# ---------------------------------------------------------------- scoring
# spec: N-000115 N-000131 N-000132 N-000133 N-000134 N-000135 N-000136 N-000137 N-000138
# spec: N-000139 N-000140 N-000141 N-000142 N-000143 N-000144 N-000145 N-000146 N-000147
# spec: N-000148 N-000683 N-000684 N-000685 N-000766 N-000763 N-000764 N-000765 N-000766 N-000767

def band_for(score):
    for limit, name in BANDS:
        if score <= limit:
            return name
    return BANDS[-1][1]


def _confidence(words, families):
    if words < 40:
        return 'none', 'fewer than 40 words; there is too little prose to score'
    if words < 120:
        return 'low', 'fewer than 120 words; the score is rough'
    if words < 300 and families <= 1:
        return 'low', 'fewer than 300 words with only one pattern family'
    if words < 300:
        return 'moderate', 'fewer than 300 words'
    return 'high', ''


def score_hits(hits, word_count):
    """Return (score, confidence, confidence_reason) from fired findings."""
    scoring = [h for h in hits if not h.advice]
    families = set(h.num for h in scoring)
    raw = 0
    for h in scoring:
        if h.num in RHYTHM_NUMS:
            raw += 6
        else:
            raw += 10 + min(max(h.count - 1, 0), 4) * 2
    raw = min(100, raw)
    confidence, reason = _confidence(word_count, len(families))
    decisive = families & DECISIVE_NUMS
    cap = 100
    floor = 0
    if len(decisive) >= 2:
        floor = max(floor, 65)
    elif len(decisive) == 1 and confidence not in ('none', 'low'):
        floor = max(floor, 45)
    if families and families <= RHYTHM_NUMS:
        cap = min(cap, 20 if families == frozenset([40]) else 40)
    if len(families) == 1 and floor < 45:
        cap = min(cap, 40)
    score = min(raw, cap)
    if word_count < 120:
        short_fams = families & SHORT_CHECK_NUMS
        if len(short_fams) >= 3:
            floor = max(floor, 45)
        elif len(short_fams) >= 2:
            floor = max(floor, 25)
    if word_count >= 400:
        if len(families) >= 6:
            floor = max(floor, 45)
        elif len(families) >= 5:
            floor = max(floor, 25)
    score = max(score, floor)
    return max(0, min(100, int(score))), confidence, reason


def _interval(ctx, hits, point):
    n = len(ctx.sents)
    if n < 4:
        return None, 'too few sentences to estimate an interval (need at least 4)'
    starts = [s for s, _e in ctx.sents]
    counts = [0] * n
    for h in hits:
        if h.advice:
            continue
        for s, _e in h.spans:
            idx = bisect.bisect_right(starts, s) - 1
            if 0 <= idx < n:
                counts[idx] += 1
    total = sum(counts)
    if total == 0 or point == 0:
        return [float(point), float(point)], 'interval from a resampling of sentences (seeded)'
    rnd = random.Random(20240601)
    values = []
    for _ in range(400):
        sample = sum(counts[rnd.randrange(n)] for _ in range(n))
        values.append(min(100.0, max(0.0, point * sample / float(total))))
    values.sort()
    low = min(values[int(0.025 * len(values))], float(point))
    high = max(values[min(len(values) - 1, int(0.975 * len(values)))], float(point))
    return [round(low, 1), round(high, 1)], 'interval from a resampling of sentences (seeded)'


def build_report(prose, ci=False):
    window = prose[:WINDOW_CHARS]
    truncated = len(prose) > WINDOW_CHARS
    masked = mask_code(window)
    ctx = Ctx(window, masked)
    hits = run_rules(ctx)
    score, confidence, reason = score_hits(hits, ctx.word_count)
    report = collections.OrderedDict()
    for h in hits:
        report[h.key] = collections.OrderedDict([
            ('label', h.label),
            ('count', int(h.count)),
            ('samples', list(h.samples[:3])),
        ])
    inv = len(invisible_removals(window))
    ns = len(nonstandard_space_removals(window))
    homo = len(homoglyph_tokens(window))
    metrics = collections.OrderedDict([
        ('scanned_chars', len(window)),
        ('truncated', bool(truncated)),
        ('ai_tell_score', score),
        ('ai_tell_band', band_for(score)),
        ('confidence', confidence),
        ('confidence_reason', reason),
        ('patterns_flagged', len(hits)),
        ('invisible_chars', inv),
        ('nonstandard_spaces', ns),
        ('homoglyphs', homo),
    ])
    if ci:
        interval, note = _interval(ctx, hits, score)
        metrics['score_ci'] = interval
        metrics['score_ci_note'] = note
    report['_metrics'] = metrics
    return report


# ---------------------------------------------------------------- command line

def _write_out(data):
    sys.stdout.buffer.write(data)
    sys.stdout.buffer.flush()


def _write_err_json(message):
    line = json.dumps({'error': message}, ensure_ascii=False)
    sys.stderr.write(line + '\n')
    sys.stderr.flush()


def main(argv=None):
    argv = sys.argv[1:] if argv is None else list(argv)
    clean = False
    ci = False
    operands = []
    end_of_options = False
    for arg in argv:
        if end_of_options:
            operands.append(arg)
            continue
        if arg == '--':
            end_of_options = True
            continue
        if arg in ('-h', '--help'):
            _write_out(USAGE.encode('utf-8'))
            return 0
        if arg == '--clean':
            clean = True
            continue
        if arg == '--ci':
            ci = True
            continue
        if arg.startswith('-'):
            _write_err_json("unknown option '%s'; see --help" % arg)
            return 2
        operands.append(arg)
    try:
        if len(operands) >= 2:
            sys.stderr.write('prosecheck: only the first file was scanned: %s\n' % operands[0])
            sys.stderr.flush()
        if operands:
            path = operands[0]
            ext = os.path.splitext(path)[1].lower()
            try:
                with open(path, 'rb') as fh:
                    data = fh.read()
            except OSError as exc:
                raise DetectorError(1, 'cannot read input: %s: %s' % (path, exc.strerror or exc))
        else:
            ext = ''
            data = sys.stdin.buffer.read()
        prose = _check_prose(extract_prose(data, ext))
        if clean:
            cleaned = clean_text(prose)
            _check_prose(cleaned)
            _write_out(cleaned.encode('utf-8'))
            return 0
        report = build_report(prose, ci=ci)
        _write_out((json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode('utf-8'))
        return 0
    except DetectorError as exc:
        _write_err_json(exc.message)
        return exc.status
    except Exception:  # never print a traceback
        _write_err_json('cannot read input: internal error while reading the input')
        return 1


if __name__ == '__main__':
    sys.exit(main())
