# Spec trace

Every id in `spec/CHECKLIST.md` (1126 ids) with its status.

- Counts: 99 tested, 1027 implemented, 0 not done.
- **tested**: a test title in `tests/` cites the id. The test is a check of the stated behaviour, not a proof that every clause of the id is covered.
- **implemented**: the id is satisfied by the code at the location given for its pack (or by a marker in that file). Where the spec was ambiguous or approximated, see `NOTES.md`.
- **not done**: none. The spec's nine catalogue numbers without a detector (7, 9, 28, 29, 43, 45, 49, 52, 53) are implemented by never reporting them, as the spec requires.

## Pack 02 (5 ids) — scripts/detect.py (stdlib only, no compile step)

| id | status | where |
|---|---|---|
| N-000588 | implemented | scripts/detect.py (stdlib only, no compile step) |
| N-000589 | implemented | scripts/detect.py (stdlib only, no compile step) |
| N-000590 | implemented | scripts/detect.py (stdlib only, no compile step) |
| N-000591 | implemented | scripts/detect.py (stdlib only, no compile step) |
| N-000592 | implemented | scripts/detect.py (stdlib only, no compile step) |

## Pack 03 (10 ids) — scripts/detect.py run from the tree; hooks/*.js run with node

| id | status | where |
|---|---|---|
| N-000593 | implemented | scripts/detect.py run from the tree; hooks/*.js run with node |
| N-000594 | implemented | scripts/detect.py run from the tree; hooks/*.js run with node |
| N-000595 | implemented | scripts/detect.py run from the tree; hooks/*.js run with node |
| N-000596 | implemented | scripts/detect.py run from the tree; hooks/*.js run with node |
| N-000597 | implemented | scripts/detect.py run from the tree; hooks/*.js run with node |
| N-000598 | implemented | scripts/detect.py run from the tree; hooks/*.js run with node |
| N-000599 | implemented | scripts/detect.py run from the tree; hooks/*.js run with node |
| N-000600 | implemented | scripts/detect.py run from the tree; hooks/*.js run with node |
| N-000601 | implemented | scripts/detect.py run from the tree; hooks/*.js run with node |
| N-000602 | implemented | scripts/detect.py run from the tree; hooks/*.js run with node |

## Pack 04 (18 ids) — scripts/detect.py; hooks/*.js; commands/prosecheck.md

| id | status | where |
|---|---|---|
| N-000001 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |
| N-000002 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |
| N-000003 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |
| N-000004 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |
| N-000005 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |
| N-000006 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |
| N-000007 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |
| N-000008 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |
| N-000009 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |
| N-000010 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |
| N-000011 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |
| N-000012 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |
| N-000013 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |
| N-000014 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |
| N-000015 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |
| N-000016 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |
| N-000017 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |
| N-000018 | implemented | scripts/detect.py; hooks/*.js; commands/prosecheck.md |

## Pack 05 (22 ids) — scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file)

| id | status | where |
|---|---|---|
| N-000019 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000020 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000021 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000022 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000023 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000024 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000025 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000026 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000027 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000028 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000029 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000030 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000031 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000032 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000033 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000034 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000035 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000036 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000037 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000038 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000039 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |
| N-000040 | implemented | scripts/detect.py (BANDS, families, caps); hooks/prosecheck-lib.js (HOOK_PHRASES, flag file) |

## Pack 06 (11 ids) — scripts/detect.py (CLI); hooks/prosecheck-*.js; commands/prosecheck.md

| id | status | where |
|---|---|---|
| N-000041 | implemented | scripts/detect.py (CLI); hooks/prosecheck-*.js; commands/prosecheck.md |
| N-000042 | implemented | scripts/detect.py (CLI); hooks/prosecheck-*.js; commands/prosecheck.md |
| N-000043 | implemented | scripts/detect.py (CLI); hooks/prosecheck-*.js; commands/prosecheck.md |
| N-000044 | implemented | scripts/detect.py (CLI); hooks/prosecheck-*.js; commands/prosecheck.md |
| N-000045 | implemented | scripts/detect.py (CLI); hooks/prosecheck-*.js; commands/prosecheck.md |
| N-000046 | implemented | scripts/detect.py (CLI); hooks/prosecheck-*.js; commands/prosecheck.md |
| N-000047 | implemented | scripts/detect.py (CLI); hooks/prosecheck-*.js; commands/prosecheck.md |
| N-000048 | implemented | scripts/detect.py (CLI); hooks/prosecheck-*.js; commands/prosecheck.md |
| N-000049 | implemented | scripts/detect.py (CLI); hooks/prosecheck-*.js; commands/prosecheck.md |
| N-000050 | implemented | scripts/detect.py (CLI); hooks/prosecheck-*.js; commands/prosecheck.md |
| N-000051 | implemented | scripts/detect.py (CLI); hooks/prosecheck-*.js; commands/prosecheck.md |

## Pack 07 (26 ids) — scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network)

| id | status | where |
|---|---|---|
| N-000052 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000053 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000054 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000055 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000056 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000057 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000058 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000059 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000060 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000061 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000062 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000063 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000064 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000065 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000066 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000067 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000068 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000069 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000070 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000071 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000072 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000073 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000074 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000075 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000076 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |
| N-000077 | implemented | scripts/detect.py (stdlib only, window, determinism); hooks/prosecheck-lib.js (ledger age, no network) |

## Pack 08 (4 ids) — scripts/detect.py; hooks/prosecheck-guard.js

| id | status | where |
|---|---|---|
| N-000078 | implemented | scripts/detect.py; hooks/prosecheck-guard.js |
| N-000079 | implemented | scripts/detect.py; hooks/prosecheck-guard.js |
| N-000080 | implemented | scripts/detect.py; hooks/prosecheck-guard.js |
| N-000081 | implemented | scripts/detect.py; hooks/prosecheck-guard.js |

## Pack 09 (12 ids) — scripts/detect.py (extract_prose: no PDF/RTF text); hooks/prosecheck-guard.js (binary rows, no nudge)

| id | status | where |
|---|---|---|
| N-000082 | implemented | scripts/detect.py (extract_prose: no PDF/RTF text); hooks/prosecheck-guard.js (binary rows, no nudge) |
| N-000083 | implemented | scripts/detect.py (extract_prose: no PDF/RTF text); hooks/prosecheck-guard.js (binary rows, no nudge) |
| N-000084 | implemented | scripts/detect.py (extract_prose: no PDF/RTF text); hooks/prosecheck-guard.js (binary rows, no nudge) |
| N-000085 | implemented | scripts/detect.py (extract_prose: no PDF/RTF text); hooks/prosecheck-guard.js (binary rows, no nudge) |
| N-000086 | implemented | scripts/detect.py (extract_prose: no PDF/RTF text); hooks/prosecheck-guard.js (binary rows, no nudge) |
| N-000087 | implemented | scripts/detect.py (extract_prose: no PDF/RTF text); hooks/prosecheck-guard.js (binary rows, no nudge) |
| N-000088 | implemented | scripts/detect.py (extract_prose: no PDF/RTF text); hooks/prosecheck-guard.js (binary rows, no nudge) |
| N-000089 | implemented | scripts/detect.py (extract_prose: no PDF/RTF text); hooks/prosecheck-guard.js (binary rows, no nudge) |
| N-000090 | implemented | scripts/detect.py (extract_prose: no PDF/RTF text); hooks/prosecheck-guard.js (binary rows, no nudge) |
| N-000091 | implemented | scripts/detect.py (extract_prose: no PDF/RTF text); hooks/prosecheck-guard.js (binary rows, no nudge) |
| N-000092 | implemented | scripts/detect.py (extract_prose: no PDF/RTF text); hooks/prosecheck-guard.js (binary rows, no nudge) |
| N-000093 | implemented | scripts/detect.py (extract_prose: no PDF/RTF text); hooks/prosecheck-guard.js (binary rows, no nudge) |

## Pack 10 (149 ids) — scripts/detect.py (run_rules, score_hits, build_report, main)

| id | status | where |
|---|---|---|
| N-000094 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000095 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000096 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000097 | tested | test_detector.py; scripts/detect.py |
| N-000098 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000099 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000100 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000101 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000102 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000103 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000104 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000105 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000106 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000107 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000108 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000109 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000110 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000111 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000112 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000113 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000114 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000115 | tested | test_detector.py; scripts/detect.py |
| N-000116 | tested | test_detector.py; scripts/detect.py |
| N-000117 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000118 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000119 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000120 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000121 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000122 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000123 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000124 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000125 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000126 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000127 | tested | test_detector.py; scripts/detect.py |
| N-000128 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000129 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000130 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000131 | tested | test_detector.py; scripts/detect.py |
| N-000132 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000133 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000134 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000135 | tested | test_detector.py; scripts/detect.py |
| N-000136 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000137 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000138 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000139 | tested | test_detector.py; scripts/detect.py |
| N-000140 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000141 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000142 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000143 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000144 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000145 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000146 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000147 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000148 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000149 | tested | test_detector.py; scripts/detect.py |
| N-000150 | tested | test_detector.py; scripts/detect.py |
| N-000151 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000152 | tested | test_detector.py; scripts/detect.py |
| N-000153 | tested | test_detector.py; scripts/detect.py |
| N-000154 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000155 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000156 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000157 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000158 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000159 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000160 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000161 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000162 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000163 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000164 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000165 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000166 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000167 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000168 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000169 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000170 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000171 | tested | test_detector.py; scripts/detect.py |
| N-000172 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000173 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000174 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000175 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000176 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000177 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000178 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000179 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000180 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000181 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000182 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000183 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000184 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000185 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000186 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000187 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000188 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000189 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000190 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000191 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000192 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000193 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000194 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000195 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000196 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000197 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000198 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000199 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000200 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000201 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000202 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000203 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000204 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000205 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000206 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000207 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000208 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000209 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000210 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000211 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000212 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000213 | tested | test_detector.py; scripts/detect.py |
| N-000214 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000215 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000216 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000217 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000218 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000219 | tested | test_detector.py; scripts/detect.py |
| N-000220 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000221 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000222 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000223 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000224 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000225 | tested | test_detector.py |
| N-000226 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000227 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000228 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000229 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000230 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000231 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000232 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000233 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000234 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000235 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000236 | tested | test_detector.py; scripts/detect.py |
| N-000237 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000238 | tested | test_detector.py |
| N-000239 | implemented | scripts/detect.py (run_rules, score_hits, build_report, main) |
| N-000240 | tested | test_detector.py |
| N-000241 | tested | test_detector.py; scripts/detect.py |
| N-000242 | tested | test_detector.py; scripts/detect.py |

## Pack 11 (56 ids) — scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps)

| id | status | where |
|---|---|---|
| N-000243 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000244 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000245 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000246 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000247 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000248 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000249 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000250 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000251 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000252 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000253 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000254 | tested | test_detector.py; scripts/detect.py |
| N-000255 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000256 | tested | test_detector.py; scripts/detect.py |
| N-000257 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000258 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000259 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000260 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000261 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000262 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000263 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000264 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000265 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000266 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000267 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000268 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000269 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000270 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000271 | tested | test_detector.py; scripts/detect.py |
| N-000272 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000273 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000274 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000275 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000276 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000277 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000278 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000279 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000280 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000281 | tested | test_detector.py; scripts/detect.py |
| N-000282 | tested | test_detector.py; scripts/detect.py |
| N-000283 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000284 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000285 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000286 | tested | test_detector.py; scripts/detect.py |
| N-000287 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000288 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000289 | tested | test_detector.py; scripts/detect.py |
| N-000290 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000291 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000292 | tested | test_detector.py; scripts/detect.py |
| N-000293 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000294 | tested | test_detector.py |
| N-000295 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000296 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000297 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |
| N-000298 | implemented | scripts/detect.py (extract_prose and per-format extractors); hooks/prosecheck-lib.js (caps) |

## Pack 12 (33 ids) — scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens)

| id | status | where |
|---|---|---|
| N-000299 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000300 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000301 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000302 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000303 | tested | test_detector.py; scripts/detect.py |
| N-000304 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000305 | tested | test_detector.py; scripts/detect.py |
| N-000306 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000307 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000308 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000309 | tested | test_detector.py; scripts/detect.py |
| N-000310 | tested | test_detector.py; scripts/detect.py |
| N-000311 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000312 | tested | test_detector.py; scripts/detect.py |
| N-000313 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000314 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000315 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000316 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000317 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000318 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000319 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000320 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000321 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000322 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000323 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000324 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000325 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000326 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000327 | tested | test_detector.py; scripts/detect.py |
| N-000328 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000329 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000330 | implemented | scripts/detect.py (clean_text, invisible_removals, nonstandard_space_removals, homoglyph_tokens) |
| N-000331 | tested | test_detector.py; scripts/detect.py |

## Pack 13 (63 ids) — hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText)

| id | status | where |
|---|---|---|
| N-000332 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000333 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000334 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000335 | tested | hooks.test.js; hooks/prosecheck-activate.js |
| N-000336 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000337 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000338 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000339 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000340 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000341 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000342 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000343 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000344 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000345 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000346 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000347 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000348 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000349 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000350 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000351 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000352 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000353 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000354 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000355 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000356 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000357 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000358 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000359 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000360 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000361 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000362 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000363 | tested | hooks.test.js |
| N-000364 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000365 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000366 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000367 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000368 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000369 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000370 | tested | hooks.test.js; hooks/prosecheck-activate.js |
| N-000371 | tested | hooks.test.js; hooks/prosecheck-activate.js |
| N-000372 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000373 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000374 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000375 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000376 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000377 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000378 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000379 | tested | hooks.test.js; hooks/prosecheck-activate.js |
| N-000380 | tested | hooks.test.js; hooks/prosecheck-tracker.js |
| N-000381 | tested | hooks.test.js; hooks/prosecheck-tracker.js |
| N-000382 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000383 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000384 | tested | hooks.test.js; hooks/prosecheck-activate.js, hooks/prosecheck-subagent.js |
| N-000385 | tested | hooks.test.js; hooks/prosecheck-activate.js, hooks/prosecheck-subagent.js |
| N-000386 | tested | hooks.test.js; hooks/prosecheck-activate.js, hooks/prosecheck-lib.js, hooks/prosecheck-subagent.js |
| N-000387 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000388 | tested | hooks.test.js; hooks/prosecheck-activate.js, hooks/prosecheck-lib.js, hooks/prosecheck-subagent.js, hooks/prosecheck-tracker.js |
| N-000389 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000390 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000391 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000392 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000393 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000394 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-tracker.js (reminder); hooks/prosecheck-subagent.js; hooks/prosecheck-lib.js (contractText, welcomeText) |

## Pack 14 (62 ids) — hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger)

| id | status | where |
|---|---|---|
| N-000395 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000396 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000397 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000398 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000399 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000400 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000401 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000402 | tested | hooks.test.js; hooks/prosecheck-guard.js |
| N-000403 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000404 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000405 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000406 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000407 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000408 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000409 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000410 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000411 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000412 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000413 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000414 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000415 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000416 | tested | hooks.test.js; hooks/prosecheck-guard.js |
| N-000417 | tested | hooks.test.js; hooks/prosecheck-guard.js |
| N-000418 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000419 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000420 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000421 | tested | hooks.test.js; hooks/prosecheck-guard.js |
| N-000422 | tested | hooks.test.js; hooks/prosecheck-guard.js |
| N-000423 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000424 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000425 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000426 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000427 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000428 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000429 | tested | hooks.test.js; hooks/prosecheck-guard.js, hooks/prosecheck-lib.js |
| N-000430 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000431 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000432 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000433 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000434 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000435 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000436 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000437 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000438 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000439 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000440 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000441 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000442 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000443 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000444 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000445 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000446 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000447 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000448 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000449 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000450 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000451 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000452 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000453 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000454 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000455 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |
| N-000456 | implemented | hooks/prosecheck-guard.js; hooks/prosecheck-lib.js (analyzeFile, ledger) |

## Pack 15 (121 ids) — hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc

| id | status | where |
|---|---|---|
| N-000457 | tested | hooks.test.js; hooks/prosecheck-tracker.js |
| N-000458 | tested | hooks.test.js; hooks/prosecheck-tracker.js |
| N-000459 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000460 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000461 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000462 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000463 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000464 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000465 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000466 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000467 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000468 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000469 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000470 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000471 | tested | hooks.test.js; hooks/prosecheck-tracker.js |
| N-000472 | tested | hooks.test.js; hooks/prosecheck-tracker.js |
| N-000473 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000474 | tested | hooks.test.js; hooks/prosecheck-tracker.js |
| N-000475 | tested | hooks.test.js; hooks/prosecheck-tracker.js |
| N-000476 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000477 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000478 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000479 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000480 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000481 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000482 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000483 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000484 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000485 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000486 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000487 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000488 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000489 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000490 | tested | hooks.test.js; hooks/prosecheck-tracker.js |
| N-000491 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000492 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000493 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000494 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000495 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000496 | tested | hooks.test.js; hooks/prosecheck-tracker.js |
| N-000497 | tested | hooks.test.js; hooks/prosecheck-tracker.js |
| N-000498 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000499 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000500 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000501 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000502 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000503 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000504 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000505 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000506 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000507 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000508 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000509 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000510 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000511 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000512 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000513 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000514 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000515 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000516 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000517 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000518 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000519 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000520 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000521 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000522 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000523 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000524 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000525 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000526 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000527 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000528 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000529 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000530 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000531 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000532 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000533 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000534 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000535 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000536 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000537 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000538 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000539 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000540 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000541 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000542 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000543 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000544 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000545 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000546 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000547 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000548 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000549 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000550 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000551 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000552 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000553 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000554 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000555 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000556 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000557 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000558 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000559 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000560 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000561 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000562 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000563 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000564 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000565 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000566 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000567 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000568 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000569 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000570 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000571 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000572 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000573 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000574 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000575 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000576 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000577 | implemented | hooks/prosecheck-tracker.js (router, doctor, check, show, init); hooks/prosecheck-stats.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |

## Pack 16 (10 ids) — hooks/*.js (local only, no network); scripts/detect.py

| id | status | where |
|---|---|---|
| N-000578 | implemented | hooks/*.js (local only, no network); scripts/detect.py |
| N-000579 | implemented | hooks/*.js (local only, no network); scripts/detect.py |
| N-000580 | implemented | hooks/*.js (local only, no network); scripts/detect.py |
| N-000581 | implemented | hooks/*.js (local only, no network); scripts/detect.py |
| N-000582 | implemented | hooks/*.js (local only, no network); scripts/detect.py |
| N-000583 | implemented | hooks/*.js (local only, no network); scripts/detect.py |
| N-000584 | implemented | hooks/*.js (local only, no network); scripts/detect.py |
| N-000585 | implemented | hooks/*.js (local only, no network); scripts/detect.py |
| N-000586 | implemented | hooks/*.js (local only, no network); scripts/detect.py |
| N-000587 | implemented | hooks/*.js (local only, no network); scripts/detect.py |

## Pack 17 (24 ids) — scripts/detect.py; hooks/*.js

| id | status | where |
|---|---|---|
| N-000603 | implemented | scripts/detect.py; hooks/*.js |
| N-000604 | implemented | scripts/detect.py; hooks/*.js |
| N-000605 | implemented | scripts/detect.py; hooks/*.js |
| N-000606 | implemented | scripts/detect.py; hooks/*.js |
| N-000607 | implemented | scripts/detect.py; hooks/*.js |
| N-000608 | implemented | scripts/detect.py; hooks/*.js |
| N-000609 | implemented | scripts/detect.py; hooks/*.js |
| N-000610 | implemented | scripts/detect.py; hooks/*.js |
| N-000611 | implemented | scripts/detect.py; hooks/*.js |
| N-000612 | implemented | scripts/detect.py; hooks/*.js |
| N-000613 | implemented | scripts/detect.py; hooks/*.js |
| N-000614 | implemented | scripts/detect.py; hooks/*.js |
| N-000615 | implemented | scripts/detect.py; hooks/*.js |
| N-000616 | implemented | scripts/detect.py; hooks/*.js |
| N-000617 | implemented | scripts/detect.py; hooks/*.js |
| N-000618 | implemented | scripts/detect.py; hooks/*.js |
| N-000619 | implemented | scripts/detect.py; hooks/*.js |
| N-000620 | implemented | scripts/detect.py; hooks/*.js |
| N-000621 | implemented | scripts/detect.py; hooks/*.js |
| N-000622 | implemented | scripts/detect.py; hooks/*.js |
| N-000623 | implemented | scripts/detect.py; hooks/*.js |
| N-000624 | implemented | scripts/detect.py; hooks/*.js |
| N-000625 | implemented | scripts/detect.py; hooks/*.js |
| N-000626 | implemented | scripts/detect.py; hooks/*.js |

## Pack 18 (47 ids) — scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js

| id | status | where |
|---|---|---|
| N-000627 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000628 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000629 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000630 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000631 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000632 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000633 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000634 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000635 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000636 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000637 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000638 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000639 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000640 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000641 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000642 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000643 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000644 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000645 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000646 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000647 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000648 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000649 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000650 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000651 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000652 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000653 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000654 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000655 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000656 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000657 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000658 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000659 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000660 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000661 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000662 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000663 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000664 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000665 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000666 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000667 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000668 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000669 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000670 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000671 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000672 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |
| N-000673 | implemented | scripts/detect.py (flags, usage, report); hooks/hooks.json; hooks/prosecheck-tracker.js |

## Pack 19 (29 ids) — hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names)

| id | status | where |
|---|---|---|
| N-000674 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000675 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000676 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000677 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000678 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000679 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000680 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000681 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000682 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000683 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000684 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000685 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000686 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000687 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000688 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000689 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000690 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000691 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000692 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000693 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000694 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000695 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000696 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000697 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000698 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000699 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000700 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000701 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |
| N-000702 | implemented | hooks/prosecheck-lib.js (flag, ledger, env variables, config names); scripts/detect.py (band names) |

## Pack 20 (28 ids) — scripts/detect.py (exit codes, error objects); every hook exits 0

| id | status | where |
|---|---|---|
| N-000703 | tested | test_detector.py |
| N-000704 | tested | test_detector.py |
| N-000705 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000706 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000707 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000708 | tested | test_detector.py |
| N-000709 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000710 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000711 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000712 | tested | test_detector.py |
| N-000713 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000714 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000715 | tested | test_detector.py |
| N-000716 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000717 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000718 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000719 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000720 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000721 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000722 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000723 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000724 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000725 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000726 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000727 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000728 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000729 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |
| N-000730 | implemented | scripts/detect.py (exit codes, error objects); every hook exits 0 |

## Pack 21 (57 ids) — scripts/detect.py (signature, report, errors, several operands)

| id | status | where |
|---|---|---|
| N-000731 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000732 | tested | test_detector.py; scripts/detect.py |
| N-000733 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000734 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000735 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000736 | tested | test_detector.py; scripts/detect.py |
| N-000737 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000738 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000739 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000740 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000741 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000742 | tested | test_detector.py; scripts/detect.py |
| N-000743 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000744 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000745 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000746 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000747 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000748 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000749 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000750 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000751 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000752 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000753 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000754 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000755 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000756 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000757 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000758 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000759 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000760 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000761 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000762 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000763 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000764 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000765 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000766 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000767 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000768 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000769 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000770 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000771 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000772 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000773 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000774 | tested | test_detector.py |
| N-000775 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000776 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000777 | tested | test_detector.py; scripts/detect.py |
| N-000778 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000779 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000780 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000781 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000782 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000783 | tested | test_detector.py; scripts/detect.py |
| N-000784 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000785 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000786 | implemented | scripts/detect.py (signature, report, errors, several operands) |
| N-000787 | tested | test_detector.py; scripts/detect.py |

## Pack 22 (25 ids) — hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText)

| id | status | where |
|---|---|---|
| N-000788 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000789 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000790 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000791 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000792 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000793 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000794 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000795 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000796 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000797 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000798 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000799 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000800 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000801 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000802 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000803 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000804 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000805 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000806 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000807 | tested | hooks.test.js; hooks/prosecheck-activate.js |
| N-000808 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000809 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000810 | tested | hooks.test.js; hooks/prosecheck-activate.js |
| N-000811 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |
| N-000812 | implemented | hooks/prosecheck-activate.js; hooks/prosecheck-lib.js (contractText, welcomeText) |

## Pack 23 (6 ids) — hooks/prosecheck-subagent.js

| id | status | where |
|---|---|---|
| N-000813 | implemented | hooks/prosecheck-subagent.js |
| N-000814 | implemented | hooks/prosecheck-subagent.js |
| N-000815 | implemented | hooks/prosecheck-subagent.js |
| N-000816 | implemented | hooks/prosecheck-subagent.js |
| N-000817 | implemented | hooks/prosecheck-subagent.js |
| N-000818 | implemented | hooks/prosecheck-subagent.js |

## Pack 24 (17 ids) — hooks/prosecheck-guard.js (JSON reply, additionalContext lines)

| id | status | where |
|---|---|---|
| N-000819 | implemented | hooks/prosecheck-guard.js (JSON reply, additionalContext lines) |
| N-000820 | implemented | hooks/prosecheck-guard.js (JSON reply, additionalContext lines) |
| N-000821 | implemented | hooks/prosecheck-guard.js (JSON reply, additionalContext lines) |
| N-000822 | implemented | hooks/prosecheck-guard.js (JSON reply, additionalContext lines) |
| N-000823 | implemented | hooks/prosecheck-guard.js (JSON reply, additionalContext lines) |
| N-000824 | implemented | hooks/prosecheck-guard.js (JSON reply, additionalContext lines) |
| N-000825 | implemented | hooks/prosecheck-guard.js (JSON reply, additionalContext lines) |
| N-000826 | implemented | hooks/prosecheck-guard.js (JSON reply, additionalContext lines) |
| N-000827 | implemented | hooks/prosecheck-guard.js (JSON reply, additionalContext lines) |
| N-000828 | implemented | hooks/prosecheck-guard.js (JSON reply, additionalContext lines) |
| N-000829 | implemented | hooks/prosecheck-guard.js (JSON reply, additionalContext lines) |
| N-000830 | implemented | hooks/prosecheck-guard.js (JSON reply, additionalContext lines) |
| N-000831 | implemented | hooks/prosecheck-guard.js (JSON reply, additionalContext lines) |
| N-000832 | implemented | hooks/prosecheck-guard.js (JSON reply, additionalContext lines) |
| N-000833 | implemented | hooks/prosecheck-guard.js (JSON reply, additionalContext lines) |
| N-000834 | implemented | hooks/prosecheck-guard.js (JSON reply, additionalContext lines) |
| N-000835 | implemented | hooks/prosecheck-guard.js (JSON reply, additionalContext lines) |

## Pack 25 (5 ids) — hooks/prosecheck-guard.js (tool_input.content read as part of the request)

| id | status | where |
|---|---|---|
| N-000836 | implemented | hooks/prosecheck-guard.js (tool_input.content read as part of the request) |
| N-000837 | implemented | hooks/prosecheck-guard.js (tool_input.content read as part of the request) |
| N-000838 | implemented | hooks/prosecheck-guard.js (tool_input.content read as part of the request) |
| N-000839 | implemented | hooks/prosecheck-guard.js (tool_input.content read as part of the request) |
| N-000840 | implemented | hooks/prosecheck-guard.js (tool_input.content read as part of the request) |

## Pack 26 (3 ids) — hooks/prosecheck-guard.js (cwd resolution)

| id | status | where |
|---|---|---|
| N-000841 | implemented | hooks/prosecheck-guard.js (cwd resolution) |
| N-000842 | implemented | hooks/prosecheck-guard.js (cwd resolution) |
| N-000843 | implemented | hooks/prosecheck-guard.js (cwd resolution) |

## Pack 27 (3 ids) — hooks/prosecheck-guard.js (file_path resolution)

| id | status | where |
|---|---|---|
| N-000844 | implemented | hooks/prosecheck-guard.js (file_path resolution) |
| N-000845 | implemented | hooks/prosecheck-guard.js (file_path resolution) |
| N-000846 | implemented | hooks/prosecheck-guard.js (file_path resolution) |

## Pack 28 (10 ids) — hooks/prosecheck-tracker.js (prompt, session_id)

| id | status | where |
|---|---|---|
| N-000847 | implemented | hooks/prosecheck-tracker.js (prompt, session_id) |
| N-000848 | implemented | hooks/prosecheck-tracker.js (prompt, session_id) |
| N-000849 | implemented | hooks/prosecheck-tracker.js (prompt, session_id) |
| N-000850 | implemented | hooks/prosecheck-tracker.js (prompt, session_id) |
| N-000851 | implemented | hooks/prosecheck-tracker.js (prompt, session_id) |
| N-000852 | implemented | hooks/prosecheck-tracker.js (prompt, session_id) |
| N-000853 | implemented | hooks/prosecheck-tracker.js (prompt, session_id) |
| N-000854 | implemented | hooks/prosecheck-tracker.js (prompt, session_id) |
| N-000855 | implemented | hooks/prosecheck-tracker.js (prompt, session_id) |
| N-000856 | implemented | hooks/prosecheck-tracker.js (prompt, session_id) |

## Pack 29 (7 ids) — hooks/prosecheck-guard.js (tool_input members: file_path, notebook_path, command)

| id | status | where |
|---|---|---|
| N-000857 | implemented | hooks/prosecheck-guard.js (tool_input members: file_path, notebook_path, command) |
| N-000858 | implemented | hooks/prosecheck-guard.js (tool_input members: file_path, notebook_path, command) |
| N-000859 | implemented | hooks/prosecheck-guard.js (tool_input members: file_path, notebook_path, command) |
| N-000860 | implemented | hooks/prosecheck-guard.js (tool_input members: file_path, notebook_path, command) |
| N-000861 | implemented | hooks/prosecheck-guard.js (tool_input members: file_path, notebook_path, command) |
| N-000862 | implemented | hooks/prosecheck-guard.js (tool_input members: file_path, notebook_path, command) |
| N-000863 | implemented | hooks/prosecheck-guard.js (tool_input members: file_path, notebook_path, command) |

## Pack 30 (6 ids) — hooks/prosecheck-guard.js (tool_name, session_id)

| id | status | where |
|---|---|---|
| N-000864 | implemented | hooks/prosecheck-guard.js (tool_name, session_id) |
| N-000865 | implemented | hooks/prosecheck-guard.js (tool_name, session_id) |
| N-000866 | implemented | hooks/prosecheck-guard.js (tool_name, session_id) |
| N-000867 | implemented | hooks/prosecheck-guard.js (tool_name, session_id) |
| N-000868 | implemented | hooks/prosecheck-guard.js (tool_name, session_id) |
| N-000869 | implemented | hooks/prosecheck-guard.js (tool_name, session_id) |

## Pack 31 (39 ids) — hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts)

| id | status | where |
|---|---|---|
| N-000870 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000871 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000872 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000873 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000874 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000875 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000876 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000877 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000878 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000879 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000880 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000881 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000882 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000883 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000884 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000885 | tested | hooks.test.js |
| N-000886 | tested | hooks.test.js |
| N-000887 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000888 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000889 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000890 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000891 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000892 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000893 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000894 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000895 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000896 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000897 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000898 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000899 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000900 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000901 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000902 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000903 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000904 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000905 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000906 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000907 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |
| N-000908 | implemented | hooks/prosecheck-tracker.js (route: block decision, router, stop phrases, ordinary prompts) |

## Pack 32 (26 ids) — hooks/prosecheck-tracker.js (helpReply)

| id | status | where |
|---|---|---|
| N-000909 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000910 | tested | hooks.test.js; hooks/prosecheck-tracker.js |
| N-000911 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000912 | tested | hooks.test.js; hooks/prosecheck-tracker.js |
| N-000913 | tested | hooks.test.js; hooks/prosecheck-tracker.js |
| N-000914 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000915 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000916 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000917 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000918 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000919 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000920 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000921 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000922 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000923 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000924 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000925 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000926 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000927 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000928 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000929 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000930 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000931 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000932 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000933 | implemented | hooks/prosecheck-tracker.js (helpReply) |
| N-000934 | implemented | hooks/prosecheck-tracker.js (helpReply) |

## Pack 33 (7 ids) — hooks/prosecheck-tracker.js (status)

| id | status | where |
|---|---|---|
| N-000935 | implemented | hooks/prosecheck-tracker.js (status) |
| N-000936 | implemented | hooks/prosecheck-tracker.js (status) |
| N-000937 | tested | hooks.test.js; hooks/prosecheck-tracker.js |
| N-000938 | implemented | hooks/prosecheck-tracker.js (status) |
| N-000939 | tested | hooks.test.js; hooks/prosecheck-tracker.js |
| N-000940 | implemented | hooks/prosecheck-tracker.js (status) |
| N-000941 | implemented | hooks/prosecheck-tracker.js (status) |

## Pack 34 (10 ids) — hooks/prosecheck-tracker.js (lite, full, strict, off, on)

| id | status | where |
|---|---|---|
| N-000942 | implemented | hooks/prosecheck-tracker.js (lite, full, strict, off, on) |
| N-000943 | implemented | hooks/prosecheck-tracker.js (lite, full, strict, off, on) |
| N-000944 | implemented | hooks/prosecheck-tracker.js (lite, full, strict, off, on) |
| N-000945 | implemented | hooks/prosecheck-tracker.js (lite, full, strict, off, on) |
| N-000946 | implemented | hooks/prosecheck-tracker.js (lite, full, strict, off, on) |
| N-000947 | implemented | hooks/prosecheck-tracker.js (lite, full, strict, off, on) |
| N-000948 | implemented | hooks/prosecheck-tracker.js (lite, full, strict, off, on) |
| N-000949 | implemented | hooks/prosecheck-tracker.js (lite, full, strict, off, on) |
| N-000950 | implemented | hooks/prosecheck-tracker.js (lite, full, strict, off, on) |
| N-000951 | implemented | hooks/prosecheck-tracker.js (lite, full, strict, off, on) |

## Pack 35 (41 ids) — hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile)

| id | status | where |
|---|---|---|
| N-000952 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000953 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000954 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000955 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000956 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000957 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000958 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000959 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000960 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000961 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000962 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000963 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000964 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000965 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000966 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000967 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000968 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000969 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000970 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000971 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000972 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000973 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000974 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000975 | tested | hooks.test.js |
| N-000976 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000977 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000978 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000979 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000980 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000981 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000982 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000983 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000984 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000985 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000986 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000987 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000988 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000989 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000990 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000991 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |
| N-000992 | implemented | hooks/prosecheck-tracker.js (checkReply, unquotePath); hooks/prosecheck-lib.js (analyzeFile) |

## Pack 36 (36 ids) — hooks/prosecheck-tracker.js (doctorReply)

| id | status | where |
|---|---|---|
| N-000993 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-000994 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-000995 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-000996 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-000997 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-000998 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-000999 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001000 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001001 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001002 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001003 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001004 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001005 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001006 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001007 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001008 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001009 | tested | hooks.test.js |
| N-001010 | tested | hooks.test.js |
| N-001011 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001012 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001013 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001014 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001015 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001016 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001017 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001018 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001019 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001020 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001021 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001022 | tested | hooks.test.js |
| N-001023 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001024 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001025 | implemented | hooks/prosecheck-tracker.js (doctorReply) |
| N-001026 | tested | hooks.test.js |
| N-001027 | tested | hooks.test.js |
| N-001028 | implemented | hooks/prosecheck-tracker.js (doctorReply) |

## Pack 37 (32 ids) — hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit)

| id | status | where |
|---|---|---|
| N-001029 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001030 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001031 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001032 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001033 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001034 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001035 | tested | hooks.test.js |
| N-001036 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001037 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001038 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001039 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001040 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001041 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001042 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001043 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001044 | tested | hooks.test.js |
| N-001045 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001046 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001047 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001048 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001049 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001050 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001051 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001052 | tested | hooks.test.js |
| N-001053 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001054 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001055 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001056 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001057 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001058 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001059 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |
| N-001060 | implemented | hooks/prosecheck-tracker.js (showReply); hooks/prosecheck-lib.js (ledger reads, age limit) |

## Pack 38 (42 ids) — hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource)

| id | status | where |
|---|---|---|
| N-001061 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001062 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001063 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001064 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001065 | tested | hooks.test.js |
| N-001066 | tested | hooks.test.js |
| N-001067 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001068 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001069 | tested | hooks.test.js |
| N-001070 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001071 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001072 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001073 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001074 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001075 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001076 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001077 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001078 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001079 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001080 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001081 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001082 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001083 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001084 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001085 | tested | hooks.test.js |
| N-001086 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001087 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001088 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001089 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001090 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001091 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001092 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001093 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001094 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001095 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001096 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001097 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001098 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001099 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001100 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001101 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |
| N-001102 | implemented | hooks/prosecheck-tracker.js (initReply); hooks/prosecheck-lib.js (contractText exported, cursorRuleSource) |

## Pack 39 (19 ids) — hooks/prosecheck-stats.js (statsReply, readAssistant, proseSlice)

| id | status | where |
|---|---|---|
| N-001103 | implemented | hooks/prosecheck-stats.js (statsReply, readAssistant, proseSlice) |
| N-001104 | implemented | hooks/prosecheck-stats.js (statsReply, readAssistant, proseSlice) |
| N-001105 | implemented | hooks/prosecheck-stats.js (statsReply, readAssistant, proseSlice) |
| N-001106 | implemented | hooks/prosecheck-stats.js (statsReply, readAssistant, proseSlice) |
| N-001107 | tested | hooks.test.js; hooks/prosecheck-stats.js |
| N-001108 | implemented | hooks/prosecheck-stats.js (statsReply, readAssistant, proseSlice) |
| N-001109 | implemented | hooks/prosecheck-stats.js (statsReply, readAssistant, proseSlice) |
| N-001110 | implemented | hooks/prosecheck-stats.js (statsReply, readAssistant, proseSlice) |
| N-001111 | implemented | hooks/prosecheck-stats.js (statsReply, readAssistant, proseSlice) |
| N-001112 | implemented | hooks/prosecheck-stats.js (statsReply, readAssistant, proseSlice) |
| N-001113 | implemented | hooks/prosecheck-stats.js (statsReply, readAssistant, proseSlice) |
| N-001114 | tested | hooks.test.js; hooks/prosecheck-stats.js |
| N-001115 | implemented | hooks/prosecheck-stats.js (statsReply, readAssistant, proseSlice) |
| N-001116 | implemented | hooks/prosecheck-stats.js (statsReply, readAssistant, proseSlice) |
| N-001117 | implemented | hooks/prosecheck-stats.js (statsReply, readAssistant, proseSlice) |
| N-001118 | implemented | hooks/prosecheck-stats.js (statsReply, readAssistant, proseSlice) |
| N-001119 | implemented | hooks/prosecheck-stats.js (statsReply, readAssistant, proseSlice) |
| N-001120 | tested | hooks.test.js; hooks/prosecheck-stats.js |
| N-001121 | implemented | hooks/prosecheck-stats.js (statsReply, readAssistant, proseSlice) |

## Pack 40 (5 ids) — hooks/prosecheck-stats.js (resolveTranscript)

| id | status | where |
|---|---|---|
| N-001122 | implemented | hooks/prosecheck-stats.js (resolveTranscript) |
| N-001123 | implemented | hooks/prosecheck-stats.js (resolveTranscript) |
| N-001124 | implemented | hooks/prosecheck-stats.js (resolveTranscript) |
| N-001125 | implemented | hooks/prosecheck-stats.js (resolveTranscript) |
| N-001126 | implemented | hooks/prosecheck-stats.js (resolveTranscript) |

