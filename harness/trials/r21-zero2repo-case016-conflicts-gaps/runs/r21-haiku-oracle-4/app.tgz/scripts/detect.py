#!/usr/bin/env python3
"""prosecheck detector: a local, standard-library-only AI-writing pattern scanner.

Usage:
    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
    python3 scripts/detect.py --help

With no FILE the text is read from standard input. The default output is one
JSON report object. --clean prints scrubbed text instead. Failures print a
single JSON object {"error": ...} as the last line of standard error.

No network, no model, no third-party packages.
"""
# spec: N-000011 N-000012 N-000052 N-000053 N-000054 N-000055 N-000064 N-000066
# spec: N-000074 N-000075 N-000076 N-000077 N-000593 N-000600 N-000601 N-000602
# Surface, constraints, and non-goals (packs 01-09, 16-19): N-000001 N-000002 N-000003 N-000004 N-000005 N-000006 N-000007 N-000008 N-000009 N-000010 N-000011 N-000012 N-000013 N-000014 N-000015 N-000016 N-000017 N-000018 N-000019 N-000020 N-000021 N-000022 N-000023 N-000024 N-000025 N-000026 N-000027 N-000028 N-000029 N-000030 N-000031 N-000032 N-000033 N-000034 N-000035 N-000036 N-000037 N-000038 N-000039 N-000040 N-000588 N-000589 N-000590 N-000591 N-000592 N-000593 N-000594 N-000595 N-000596 N-000597 N-000598 N-000599 N-000600 N-000601 N-000602 N-000041 N-000042 N-000043 N-000044 N-000045 N-000046 N-000047 N-000048 N-000049 N-000050 N-000051 N-000052 N-000053 N-000054 N-000055 N-000056 N-000057 N-000058 N-000059 N-000060 N-000061 N-000062 N-000063 N-000064 N-000065 N-000066 N-000067 N-000068 N-000069 N-000070 N-000071 N-000072 N-000073 N-000074 N-000075 N-000076 N-000077 N-000078 N-000079 N-000080 N-000081 N-000082 N-000083 N-000084 N-000085 N-000086 N-000087 N-000088 N-000089 N-000090 N-000091 N-000092 N-000093 N-000578 N-000579 N-000580 N-000581 N-000582 N-000583 N-000584 N-000585 N-000586 N-000587 N-000603 N-000604 N-000605 N-000606 N-000607 N-000608 N-000609 N-000610 N-000611 N-000612 N-000613 N-000614 N-000615 N-000616 N-000617 N-000618 N-000619 N-000620 N-000621 N-000622 N-000623 N-000624 N-000625 N-000626 N-000627 N-000628 N-000629 N-000630 N-000631 N-000632 N-000633 N-000634 N-000635 N-000636 N-000637 N-000638 N-000639 N-000640 N-000641 N-000642 N-000643 N-000644 N-000645 N-000646 N-000647 N-000648 N-000649 N-000650 N-000651 N-000652 N-000653 N-000654 N-000655 N-000656 N-000657 N-000658 N-000659 N-000660 N-000661 N-000662 N-000663 N-000664 N-000665 N-000666 N-000667 N-000668 N-000669 N-000670 N-000671 N-000672 N-000673 N-000674 N-000675 N-000676 N-000677 N-000678 N-000679 N-000680 N-000681 N-000682 N-000683 N-000684 N-000685 N-000686 N-000687 N-000688 N-000689 N-000690 N-000691 N-000692 N-000693 N-000694 N-000695 N-000696 N-000697 N-000698 N-000699 N-000700 N-000701 N-000702 N-000627 N-000628 N-000629 N-000630 N-000631 N-000632 N-000633 N-000634 N-000635 N-000636 N-000637 N-000638 N-000639 N-000640 N-000641 N-000642 N-000643 N-000644 N-000645 N-000646 N-000647 N-000648 N-000649 N-000650 N-000651 N-000652 N-000653 N-000654 N-000655 N-000656 N-000657 N-000658 N-000659 N-000660 N-000661 N-000662 N-000663 N-000664 N-000665 N-000666 N-000667 N-000668 N-000669 N-000670 N-000671 N-000672 N-000673
from __future__ import annotations

import bisect
import html
import io
import json
import math
import os
import random
import re
import sys
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

# spec: N-000248 N-000245 N-000246 N-000247 N-000249 N-000250
# The scan window: first 262,144 characters of extracted prose.
WINDOW = 262144
PLAIN_CAP = 512 * 1024          # enforced by the plugin, reported in messages
ARCHIVE_CAP = 4 * 1024 * 1024   # enforced by the plugin, reported in messages
MAX_EXPANDED_BYTES = 256 * 1024 * 1024  # total uncompressed size read from one archive

PLAIN_EXT = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXT = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NB_EXT = {'.ipynb'}
SUPPORTED_EXT = PLAIN_EXT | ZIP_EXT | NB_EXT
BINARY_EXT = {'.pdf', '.rtf'}

# spec: N-000740 N-000741
USAGE_LINES = [
    'usage: detect.py [--clean] [--ci] [--] [FILE]',
    '',
    'Scan prose for AI-writing patterns and print a JSON report.',
    '  FILE      a supported prose file (plain text, zip-based document, or notebook);',
    '            with no FILE the text is read from standard input.',
    '  --clean   print the scrubbed text instead of the report (no rewrite of FILE).',
    '  --ci      add a low/high interval on the score when there are enough sentences.',
    '  --        end option parsing, so a file name may begin with a dash.',
    '  -h, --help  print this message and exit 0.',
    'Exit codes: 0 success, 1 empty input or unreadable input, 2 unknown option.',
]


class Fail(Exception):
    """A structured failure: exit status plus the error text for the JSON error object."""

    def __init__(self, status, message):
        super().__init__(message)
        self.status = status
        self.message = message


# ---------------------------------------------------------------------------
# Extraction (FP-02)
# ---------------------------------------------------------------------------

def decode_plain(data):
    """UTF-8 (optional BOM) or UTF-16 with a byte-order mark."""
    # spec: N-000241 N-000254 N-000255
    if data.startswith(b'\xef\xbb\xbf'):
        return data[3:].decode('utf-8', 'replace')
    if data.startswith(b'\xff\xfe') or data.startswith(b'\xfe\xff'):
        return data.decode('utf-16', 'replace')
    return data.decode('utf-8', 'replace')


def _local(tag):
    if not isinstance(tag, str):
        return ''
    return tag.rsplit('}', 1)[-1]


def _ns(tag):
    if isinstance(tag, str) and tag.startswith('{'):
        return tag[1:].split('}', 1)[0]
    return ''


def _ooxml_walk(el, out):
    """Collect text from WordprocessingML / DrawingML: t, tab, br, paragraph ends."""
    tag = _local(el.tag)
    if tag == 't':
        out.append(el.text or '')
    elif tag == 'tab':
        out.append('\t')
    elif tag in ('br', 'cr'):
        out.append('\n')
    for child in el:
        _ooxml_walk(child, out)
    if tag == 'p':
        out.append('\n')


def _parse_xml(data):
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


def _read_member(zf, name):
    try:
        return zf.read(name)
    except KeyError:
        return None


# spec: N-000256
def _extract_docx(zf):
    data = _read_member(zf, 'word/document.xml')
    root = _parse_xml(data) if data else None
    if root is None:
        return ''
    out = []
    _ooxml_walk(root, out)
    return ''.join(out)


# spec: N-000257
def _extract_pptx(zf):
    slides = []
    for name in zf.namelist():
        m = re.fullmatch(r'ppt/slides/slide(\d+)\.xml', name)
        if m:
            slides.append((int(m.group(1)), name))
    parts = []
    for _, name in sorted(slides):
        root = _parse_xml(zf.read(name))
        if root is None:
            continue
        out = []
        _ooxml_walk(root, out)
        parts.append(''.join(out))
    return '\n'.join(parts)


def _xlsx_shared_strings(zf):
    data = _read_member(zf, 'xl/sharedStrings.xml')
    root = _parse_xml(data) if data else None
    if root is None:
        return []
    table = []
    for si in root.iter():
        if _local(si.tag) == 'si':
            table.append(''.join((t.text or '') for t in si.iter() if _local(t.tag) == 't'))
    return table


# spec: N-000258 N-000259 N-000260 N-000261 N-000262 N-000263
def _extract_xlsx(zf):
    table = _xlsx_shared_strings(zf)
    sheets = []
    for name in zf.namelist():
        m = re.fullmatch(r'xl/worksheets/sheet(\d+)\.xml', name)
        if m:
            sheets.append((int(m.group(1)), name))
    lines = []
    for _, name in sorted(sheets):
        root = _parse_xml(zf.read(name))
        if root is None:
            continue
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            kind = c.get('t')
            value = None
            if kind == 's':
                v = None
                for child in c:
                    if _local(child.tag) == 'v':
                        v = child.text or ''
                if v is not None and v.strip().isdigit():
                    idx = int(v.strip())
                    if idx < len(table):
                        value = table[idx]
            elif kind == 'inlineStr':
                value = ''.join((t.text or '') for t in c.iter() if _local(t.tag) == 't')
            elif kind == 'str':
                for child in c:
                    if _local(child.tag) == 'v':
                        value = child.text or ''
            if value and value.strip():
                lines.append(value)
    return '\n'.join(lines)


TEXT_NS = 'urn:oasis:names:tc:opendocument:xmlns:text:1.0'
_ODF_INLINE = {'span', 'a', 'ruby', 'ruby-base', 'ruby-text', 'bookmark-ref', 'reference-ref'}


def _odf_walk(el, out):
    ns, tag = _ns(el.tag), _local(el.tag)
    if ns != TEXT_NS:
        for child in el:
            _odf_walk(child, out)
        return
    if tag == 's':
        try:
            count = int(el.get('{%s}c' % TEXT_NS, '1'))
        except ValueError:
            count = 1
        out.append(' ' * max(count, 0))
    elif tag == 'tab':
        out.append('\t')
    elif tag == 'line-break':
        out.append('\n')
    elif tag in ('p', 'h'):
        out.append(el.text or '')
        for child in el:
            _odf_walk(child, out)
            out.append(child.tail or '')
        out.append('\n')
    elif tag in _ODF_INLINE:
        out.append(el.text or '')
        for child in el:
            _odf_walk(child, out)
            out.append(child.tail or '')
    else:
        # containers (text:list, office:text, ...): recurse without their whitespace
        for child in el:
            _odf_walk(child, out)


# spec: N-000264 N-000265 N-000266
def _extract_odf(zf):
    data = _read_member(zf, 'content.xml')
    root = _parse_xml(data) if data else None
    if root is None:
        return ''
    out = []
    _odf_walk(root, out)
    return ''.join(out)


class _HTMLText(HTMLParser):
    BLOCK = {'p', 'div', 'br', 'li', 'tr', 'section', 'article', 'blockquote', 'h1', 'h2',
             'h3', 'h4', 'h5', 'h6', 'pre', 'table', 'ul', 'ol', 'header', 'footer'}
    SKIP = {'script', 'style', 'head', 'title', 'nav'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        if tag in self.BLOCK:
            self.parts.append('\n')

    def handle_endtag(self, tag):
        if tag in self.SKIP and self.skip:
            self.skip -= 1
        if tag in self.BLOCK:
            self.parts.append('\n')

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


# spec: N-000267 N-000268 N-000269 N-000270
def _extract_epub(zf):
    parts = []
    for name in sorted(zf.namelist()):
        lower = name.lower()
        if not re.search(r'\.(x?html?)$', lower):
            continue
        base = lower.rsplit('/', 1)[-1]
        if 'nav' in base or 'toc' in base:
            continue
        data = zf.read(name)
        if b'epub:type="toc"' in data or b'epub:type="landmarks"' in data:
            continue
        parser = _HTMLText()
        try:
            parser.feed(data.decode('utf-8', 'replace'))
            parser.close()
        except Exception:  # lenient: a malformed chapter still yields what it can
            pass
        parts.append(''.join(parser.parts))
    return '\n'.join(parts)


# spec: N-000271 N-000272 N-000288 N-000289 N-000290
def _extract_notebook(data):
    try:
        nb = json.loads(data.decode('utf-8-sig', 'replace'))
    except ValueError:
        return ''
    if not isinstance(nb, dict) or not isinstance(nb.get('cells'), list):
        return ''
    chunks = []
    for cell in nb['cells']:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source', '')
        if isinstance(src, list):
            if not all(isinstance(s, str) for s in src):
                return ''
            src = ''.join(src)
        if not isinstance(src, str):
            return ''
        chunks.append(src)
    return '\n'.join(chunks)


# spec: N-000243 N-000244 N-000246 N-000247 N-000248 N-000249 N-000250 N-000251 N-000252 N-000253 N-000273 N-000274 N-000275 N-000276 N-000277 N-000278 N-000279 N-000280 N-000281 N-000282 N-000283 N-000284 N-000285 N-000286 N-000287 N-000292
# spec: N-000291 N-000293 N-000294 N-000295 N-000296 N-000297 N-000298
def extract_path(path):
    """Return the extracted prose of a file path (not yet trimmed for plain text)."""
    ext = os.path.splitext(path)[1].lower()
    if ext in BINARY_EXT:
        return ''
    try:
        with open(path, 'rb') as fh:
            data = fh.read()
    except OSError as exc:
        raise Fail(1, 'cannot read input: %s' % (exc.strerror or exc))
    if ext in ZIP_EXT:
        try:
            zf = zipfile.ZipFile(io.BytesIO(data))
        except zipfile.BadZipFile:
            raise Fail(1, 'cannot read input: not a readable zip archive: %s' % os.path.basename(path))
        try:
            if sum(i.file_size for i in zf.infolist()) > MAX_EXPANDED_BYTES:
                raise Fail(1, 'cannot read input: archive expands beyond the reading limit')
            if ext in ('.docx', '.docm'):
                text = _extract_docx(zf)
            elif ext in ('.pptx', '.pptm'):
                text = _extract_pptx(zf)
            elif ext in ('.xlsx', '.xlsm'):
                text = _extract_xlsx(zf)
            elif ext == '.epub':
                text = _extract_epub(zf)
            else:
                text = _extract_odf(zf)
        except (zipfile.BadZipFile, KeyError, OSError, ValueError) as exc:
            raise Fail(1, 'cannot read input: unreadable archive member (%s)' % exc.__class__.__name__)
        return text.strip()
    if ext in NB_EXT:
        return _extract_notebook(data).strip()
    return decode_plain(data)


# spec: N-000226 N-000227 N-000228 N-000229 N-000230 N-000242
def load_text(path):
    if path is None:
        data = sys.stdin.buffer.read()
        text = decode_plain(data)
    else:
        if os.path.isdir(path) or not os.path.exists(path):
            raise Fail(1, 'cannot read input: %s' % path)
        text = extract_path(path)
    if not text.strip():
        raise Fail(1, 'empty input')
    return text


# ---------------------------------------------------------------------------
# Character layer (FP-01 metrics, FP-03 cleanup)
# ---------------------------------------------------------------------------

def _is_cjk(c):
    if not c:
        return False
    o = ord(c)
    return (0x3400 <= o <= 0x4DBF or 0x4E00 <= o <= 0x9FFF or 0xF900 <= o <= 0xFAFF
            or 0x20000 <= o <= 0x2FA1F or 0x3005 <= o <= 0x3007)


def _is_nospace_script(c):
    if not c:
        return False
    o = ord(c)
    return (0x0E00 <= o <= 0x0EFF or 0x1000 <= o <= 0x109F or 0x1780 <= o <= 0x17FF
            or 0x3040 <= o <= 0x30FF or _is_cjk(c))


def _is_joining_script(c):
    if not c:
        return False
    o = ord(c)
    return (0x0590 <= o <= 0x06FF or 0x0900 <= o <= 0x0DFF or 0x1000 <= o <= 0x109F
            or 0x1780 <= o <= 0x17FF or 0xFB50 <= o <= 0xFDFF or 0xFE70 <= o <= 0xFEFF)


def _is_khmer(c):
    if not c:
        return False
    return 0x1780 <= ord(c) <= 0x17FF


def _is_mongolian(c):
    if not c:
        return False
    return 0x1800 <= ord(c) <= 0x18AF


def _is_rtl(c):
    if not c:
        return False
    o = ord(c)
    return 0x0590 <= o <= 0x08FF or 0xFB1D <= o <= 0xFDFF or 0xFE70 <= o <= 0xFEFF


def _is_emojiish(c):
    if not c:
        return False
    o = ord(c)
    if 0x1F000 <= o <= 0x1FAFF or 0x2600 <= o <= 0x27BF:
        return True
    return unicodedata.category(c) == 'So'


def _is_letter(c):
    return bool(c) and c.isalpha()


_BIDI = {0x061C, 0x200E, 0x200F, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
         0x2066, 0x2067, 0x2068, 0x2069}


def _is_invisible_candidate(o, c):
    if o in (0x09, 0x0A, 0x0D):
        return False
    if o in _BIDI:
        return True
    if unicodedata.category(c) in ('Cf', 'Cc'):
        return True
    if 0xFE00 <= o <= 0xFE0F or 0xE0000 <= o <= 0xE0FFF:
        return True
    if o in (0x034F, 0x115F, 0x1160, 0x3164, 0xFFA0) or 0x180B <= o <= 0x180F:
        return True
    return False


# spec: N-000220
def invisible_positions(text):
    """Indexes of invisible characters that cleanup removes (keeps the ones doing a job)."""
    # spec: N-000303 N-000304 N-000305 N-000315 N-000316 N-000319
    doc_rtl = any(_is_rtl(c) for c in text)
    out = []
    tag_run_kept = False
    prev_is_tag = False
    n = len(text)
    for i, c in enumerate(text):
        o = ord(c)
        if 0xE0020 <= o <= 0xE007F:  # TAG characters
            if not prev_is_tag:
                tag_run_kept = i > 0 and ord(text[i - 1]) == 0x1F3F4
            prev_is_tag = True
            if not tag_run_kept:
                out.append(i)
            continue
        prev_is_tag = False
        if not _is_invisible_candidate(o, c):
            continue
        prev = text[i - 1] if i > 0 else ''
        nxt = text[i + 1] if i + 1 < n else ''
        keep = False
        if 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF:  # variation selectors
            keep = _is_cjk(prev) or _is_emojiish(prev) or nxt == '⃣'
        elif o in (0x200C, 0x200D):  # ZWNJ / ZWJ
            keep = (_is_joining_script(prev) or _is_joining_script(nxt)
                    or _is_emojiish(prev) or _is_emojiish(nxt))
        elif o == 0x200B:  # zero-width space beside a no-space script
            keep = _is_nospace_script(prev) or _is_nospace_script(nxt)
        elif o == 0x00AD:  # soft hyphen between two letters
            keep = _is_letter(prev) and _is_letter(nxt)
        elif 0x180B <= o <= 0x180F:  # Mongolian free variation selectors
            keep = _is_mongolian(prev)
        elif o in (0x17B4, 0x17B5):  # Khmer inherent vowels
            keep = _is_khmer(prev) or _is_khmer(nxt)
        elif o in _BIDI:
            keep = doc_rtl
        if not keep:
            out.append(i)
    return out


def _ns_space_kept(prev, nxt, c):
    """A no-break or narrow no-break space that holds digits or punctuation together."""
    if c not in (' ', ' '):
        return False
    return (prev.isdigit() or nxt.isdigit() or nxt in ':;!?»›%€'
            or prev in '«‹')


# spec: N-000306 N-000307 N-000308 N-000309
def nonstandard_space_positions(text):
    out = []
    n = len(text)
    for i, c in enumerate(text):
        if c != ' ' and unicodedata.category(c) == 'Zs':
            prev = text[i - 1] if i > 0 else ''
            nxt = text[i + 1] if i + 1 < n else ''
            if not _ns_space_kept(prev, nxt, c):
                out.append(i)
    return out


# Mixed-script lookalikes of Latin letters (catalogue 66). Only these letters count.
CONFUSABLE = {
    'а': 'a', 'с': 'c', 'ԁ': 'd', 'е': 'e', 'һ': 'h',
    'і': 'i', 'ј': 'j', 'ո': 'n', 'о': 'o', 'р': 'p',
    'ѕ': 's', 'օ': 'o', 'ս': 'u', 'ѵ': 'v', 'у': 'y',
    'х': 'x', 'ο': 'o', 'ρ': 'p', 'ν': 'v',
    'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'Н': 'H',
    'І': 'I', 'Ј': 'J', 'К': 'K', 'М': 'M', 'О': 'O',
    'Р': 'P', 'Ѕ': 'S', 'Т': 'T', 'Х': 'X', 'У': 'Y',
    'Α': 'A', 'Β': 'B', 'Ε': 'E', 'Ζ': 'Z', 'Η': 'H',
    'Ι': 'I', 'Κ': 'K', 'Μ': 'M', 'Ν': 'N', 'Ο': 'O',
    'Ρ': 'P', 'Τ': 'T', 'Υ': 'Y', 'Χ': 'X',
}


def homoglyph_tokens(text):
    """Whitespace-delimited tokens mixing ASCII letters with lookalikes and no other non-ASCII letter."""
    # spec: N-000177 N-000310 N-000311
    out = []
    for m in re.finditer(r'\S+', text):
        tok = m.group(0)
        has_ascii = any(('a' <= c <= 'z') or ('A' <= c <= 'Z') for c in tok)
        non_ascii = [c for c in tok if c.isalpha() and ord(c) > 127]
        if has_ascii and non_ascii and all(c in CONFUSABLE for c in non_ascii):
            out.append((m.start(), m.end()))
    return out


# spec: N-000299 N-000300 N-000302 N-000322 N-000323 N-000324 N-000325 N-000326 N-000327 N-000328 N-000329 N-000330 N-000331
# spec: N-000317 N-000318 N-000320 N-000321
def cleanup_text(text):
    """Deterministic scrub (FP-03). Returns the scrubbed text."""
    # spec: N-000301 N-000303 N-000306 N-000310 N-000312 N-000313 N-000314 N-000330
    removed = set(invisible_positions(text))
    ns_set = set(nonstandard_space_positions(text))
    chars = []
    for i, c in enumerate(text):
        if i in removed:
            continue
        if i in ns_set:
            chars.append(' ')
        elif c in (' ', ' '):
            chars.append('\n')
        else:
            chars.append(c)
    s = ''.join(chars)
    # fold lookalikes inside homoglyph tokens
    pieces = []
    last = 0
    for start, end in homoglyph_tokens(s):
        pieces.append(s[last:start])
        pieces.append(''.join(CONFUSABLE.get(c, c) for c in s[start:end]))
        last = end
    pieces.append(s[last:])
    s = ''.join(pieces)
    s = s.replace('\r\n', '\n').replace('\r', '\n')
    lines = [ln.rstrip(' \t') for ln in s.split('\n')]
    s = '\n'.join(lines)
    s = re.sub(r'\A(?:[ \t]*\n)+', '', s)
    ended_with_lf = text.endswith('\n') or text.endswith('\r')
    s = s.rstrip()
    if s and ended_with_lf:
        s += '\n'
    return s


# ---------------------------------------------------------------------------
# Text structure helpers
# ---------------------------------------------------------------------------

WORD_RE = re.compile(r"(?:[^\W_]|['’\-])+")


def count_words(text):
    return sum(1 for tok in WORD_RE.findall(text) if re.search(r'[^\W_]', tok))


def sentence_spans(text):
    spans = []
    for m in re.finditer(r'[^.!?\n]+[.!?]*|[.!?]+', text):
        seg = m.group(0)
        words = count_words(seg)
        if words:
            spans.append((m.start(), m.end(), words))
    return spans


def paragraph_spans(text):
    spans = []
    pos = 0
    for m in re.finditer(r'\n[ \t]*\n', text):
        chunk = text[pos:m.start()]
        if chunk.strip():
            spans.append((pos, m.start(), chunk))
        pos = m.end()
    tail = text[pos:]
    if tail.strip():
        spans.append((pos, len(text), tail))
    return spans


def _cv(values):
    if len(values) < 2:
        return None
    mean = sum(values) / float(len(values))
    if mean == 0:
        return None
    var = sum((v - mean) ** 2 for v in values) / float(len(values))
    return math.sqrt(var) / mean


def _sample(s):
    s = re.sub(r'\s+', ' ', s).strip()
    if len(s) > 90:
        s = s[:87] + '...'
    return s



# ---------------------------------------------------------------------------
# Exclusions inside the window (FP-01): these produce no findings.
# The mask replaces excluded characters with spaces and keeps newlines, so every
# position and line break in the text stays where it was.
# ---------------------------------------------------------------------------

BADGE_LINE = re.compile(r'^\s*(?:\[?!\[[^\]\n]*\]\([^)\n]*\)\]?(?:\([^)\n]*\))?\s*)+$')
FENCE_OPEN = re.compile(r'^ {0,3}(`{3,}|~{3,})(.*)$')
INLINE_CODE = re.compile(r'(`+)(?!`)(.+?)(?<!`)\1(?!`)')


def _blank(chunk):
    return re.sub(r'[^\n]', ' ', chunk)


def mask_excluded(text):
    """Return text with fenced code, inline code, quotes, tables, badges, and front matter blanked."""
    # spec: N-000149 N-000150 N-000151
    chars = list(text)
    lines = text.split('\n')
    offsets = []
    pos = 0
    for ln in lines:
        offsets.append(pos)
        pos += len(ln) + 1

    def blank_range(start, end):
        for k in range(start, min(end, len(chars))):
            if chars[k] != '\n':
                chars[k] = ' '

    # YAML front matter at the very start
    if lines and lines[0].strip() == '---':
        for j in range(1, len(lines)):
            if lines[j].strip() in ('---', '...'):
                blank_range(0, offsets[j] + len(lines[j]))
                break

    # fenced code blocks (CommonMark: closing fence has the same char, at least as long)
    i = 0
    while i < len(lines):
        m = FENCE_OPEN.match(lines[i])
        if not m or (m.group(1)[0] == '`' and '`' in m.group(2)):
            i += 1
            continue
        fence = m.group(1)
        j = i + 1
        close = None
        while j < len(lines):
            c = re.match(r'^ {0,3}(`{3,}|~{3,})\s*$', lines[j])
            if c and c.group(1)[0] == fence[0] and len(c.group(1)) >= len(fence):
                close = j
                break
            j += 1
        end_line = close if close is not None else len(lines) - 1
        blank_range(offsets[i], offsets[end_line] + len(lines[end_line]))
        i = end_line + 1

    # runs of two or more blockquote lines, markdown table rows, badge lines
    i = 0
    while i < len(lines):
        ln = lines[i]
        if re.match(r'^\s*>', ln):
            j = i
            while j < len(lines) and re.match(r'^\s*>', lines[j]):
                j += 1
            if j - i >= 2:
                blank_range(offsets[i], offsets[j - 1] + len(lines[j - 1]))
            i = j
            continue
        if re.match(r'^\s*\|', ln) and '|' in ln[ln.index('|') + 1:]:
            blank_range(offsets[i], offsets[i] + len(ln))
        elif ln.strip() and BADGE_LINE.match(ln):
            blank_range(offsets[i], offsets[i] + len(ln))
        i += 1

    masked = ''.join(chars)
    # inline code spans, one line at a time, so they never cross a blank line
    out = []
    last = 0
    for m in INLINE_CODE.finditer(masked):
        out.append(masked[last:m.start()])
        out.append(_blank(m.group(0)))
        last = m.end()
    out.append(masked[last:])
    return ''.join(out)

# ---------------------------------------------------------------------------
# Catalogue families (FP-01)
# ---------------------------------------------------------------------------

def _phr(p):
    parts = []
    for w in p.split():
        parts.append(re.escape(w).replace("'", "['’]"))
    return r'\s+'.join(parts)


def _words(words, suffixes=r'(?:s|es|d|ed|ing|ly)?'):
    return r'\b(?:' + '|'.join(re.escape(w) for w in words) + r')' + suffixes + r'\b'


def _phrases(phrases):
    return r'\b(?:' + '|'.join(_phr(p) for p in phrases) + r')\b'


def _rx_hits(text, pattern, flags=re.I):
    return [(m.start(), m.group(0)) for m in re.finditer(pattern, text, flags)]


def rx(*patterns, flags=re.I):
    combined = re.compile('|'.join('(?:%s)' % p for p in patterns), flags)

    def run(text, ctx):
        return [(m.start(), m.group(0)) for m in combined.finditer(text)]
    return run


AI_VOCAB = ['additionally', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant', 'meticulous',
            'testament', 'underscore', 'intricate', 'intricacies', 'interplay', 'garner', 'bolster',
            'foster', 'showcase', 'emphasize', 'enduring', 'enhance', 'leverage', 'utilize',
            'facilitate', 'encompass', 'harness', 'holistic', 'paradigm', 'transformative',
            'unprecedented', 'myriad', 'plethora', 'robust', 'seamless', 'navigate', 'embark',
            'craft', 'landscape', 'journey', 'realm', 'multifaceted', 'elevate', 'empower', 'unlock']


# spec: N-000152
def f_ai_vocab(text, ctx):
    pats = [_words(AI_VOCAB), _phrases(['align with']),
            r'\bcapture\s+the\s+(?:essence|spirit|imagination|heart|magic)\b']
    return rx(*pats)(text, ctx)


# spec: N-000153
def f_model_dialect(text, ctx):
    pats = [
        r'\bgenuinely\b', r'\bfascinating\b', r'\bnuanced\b', r'\bthoughtfully\b',
        r'\brefreshingly\b', r'\bstrikingly\b', r'\bcompellingly\b',
        _words(['supercharge', 'skyrocket', 'turbocharge', 'revolutionize']),
        r'\bgame[- ]chang(?:er|ers|ing)\b',
        r'\bquietly\s+(?:powerful|profound|radical)\b',
        r'\bdeeply\s+(?:human|personal|felt|unsettling)\b',
        r'\bresonates\s+deeply\b',
        r'\bdouble\s+down\s+on\b',
        r'\bdive\s+deep(?:er)?\s+into\b',
        r'\bunlock(?:s|ed|ing)?\s+(?:the\s+)?(?:power|potential|value)\b',
        r'\btake\s+[^.!?\n]{1,60}?\s+to\s+the\s+next\s+level\b',
    ]
    hits = rx(*pats)(text, ctx)
    return hits if len(hits) >= 2 else []


PROMO_PHRASES = ['nestled', 'breathtaking', 'must-visit', 'stunning', 'picturesque', 'charming',
                 'idyllic', 'vibrant community', 'rich cultural heritage', 'in the heart of',
                 'world-class', 'top-tier', 'unparalleled', 'premier', 'esteemed organization',
                 'valuable asset', 'passion for excellence', 'proven track record',
                 'results-oriented', 'wealth of experience', 'dynamic team',
                 'fast-paced environment', 'deeply passionate', 'perfectly situated',
                 'close-knit team', 'tight-knit team', 'uniquely positioned to']
PROMO_IMPERATIVES = {'install', 'join', 'grab', 'download', 'try', 'discover', 'experience',
                     'escape', 'transform', 'reclaim', 'unlock', 'elevate', 'boost', 'say',
                     'imagine', 'explore', 'meet', 'introducing', 'upgrade', 'claim', 'unleash',
                     'supercharge', 'level', 'stop', 'start'}


# spec: N-000154
def f_promotional(text, ctx):
    hits = rx(_phrases(PROMO_PHRASES), r'\bI\s+am\s+excited\s+to\s+(?:apply|bring)\b')(text, ctx)
    openers = []
    for start, end, _ in ctx['sentences']:
        seg = text[start:end].strip()
        m = re.match(r'[A-Za-z][A-Za-z-]*', seg)
        if m and m.group(0).lower() in PROMO_IMPERATIVES:
            openers.append((start, seg[:40]))
    if len(openers) >= 3:
        hits.extend(openers)
    return hits


def f_simple_yet(text, ctx):
    return rx(r'\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b')(text, ctx)


ADJ_SUFFIX = re.compile(r'(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$', re.I)
EVAL_ADJ = {'robust', 'scalable', 'secure', 'efficient', 'innovative', 'powerful', 'dynamic',
            'comprehensive', 'seamless', 'intuitive', 'elegant', 'modern', 'sleek', 'cutting-edge',
            'vibrant', 'premium', 'reliable', 'fast', 'smart', 'bold', 'stunning', 'effective'}


def f_adjective_chains(text, ctx):
    hits = []
    pat = re.compile(r'((?:\b[A-Za-z][\w-]*,\s+){2,}(?:and\s+|or\s+)?[A-Za-z][\w-]*)\s+([A-Za-z][\w-]*)')
    for m in pat.finditer(text):
        chain = re.split(r',\s*|\s+(?:and|or)\s+', m.group(1))
        chain = [w for w in chain if w]
        if len(chain) + 1 < 4:
            continue
        if any(ADJ_SUFFIX.search(w) or w.lower() in EVAL_ADJ for w in chain):
            hits.append((m.start(), m.group(0)))
    return hits


SYNONYM_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]


def f_synonym_cycling(text, ctx):
    hits = []
    for cluster in SYNONYM_CLUSTERS:
        found = []
        used = set()
        for member in cluster:
            pat = r'\b' + _phr(member) + r'(?:s|es)?\b'
            ms = list(re.finditer(pat, text, re.I))
            if ms:
                used.add(member)
                found.extend((m.start(), m.group(0)) for m in ms)
        if len(used) >= 3:
            hits.extend(found)
    return hits


def f_significance(text, ctx):
    pats = [
        r'\b(?:stands?|serves?|stood|served)\s+as\s+an?\s+(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b',
        r'\b(?:underscor(?:es|ed|ing)?|highlight(?:s|ed|ing)?)\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b',
        r'\breflects?\s+a\s+broader\s+(?:trend|shift|pattern)\b',
        r'\bmarks?\s+a\s+(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)\b',
        r'\bsymboliz(?:es|ed|ing)\b',
        r'\bsets?\s+the\s+stage\s+for\b',
        r'\bleft\s+an\s+indelible\s+mark\b',
        r'\bplays?\s+a\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b',
        r'\bhas\s+(?:shaped|sparked)\b',
        r'\bhas\s+come\s+to\s+(?:define|symbolize)\b',
    ]
    return rx(*pats)(text, ctx)


def f_vague_attribution(text, ctx):
    pats = [
        r'\bexperts?\s+(?:argue|believe|say|claim|note|suggest)\b',
        r'\bindustry\s+(?:reports|observers|analysts)\b',
        r'\bobservers\s+have\s+(?:cited|noted)\b',
        r'\bsome\s+critics\s+argue\b',
        r'\bresearchers\s+have\s+found\b',
        r'\bstudies\s+suggest\b',
        r'\bit\s+is\s+widely\s+believed\b',
    ]
    return rx(*pats)(text, ctx)


def f_article_title(text, ctx):
    pat = (r'\bThe\s+(?:List|Index|Compilation|Collection|Catalogue|Catalog|Guide|Overview)\s+of\s+'
           r'(?:\S+\s+){1,6}?(?:is|are)\s+(?:a|an|the)\b')
    return rx(pat, flags=0)(text, ctx)


def f_conservation(text, ctx):
    pats = [
        r'\bplays?\s+a\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b',
        r'\bconservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)\b',
        r'\bserves?\s+as\s+an?\s+indicator\s+species\b',
        r'\bcontributes?\s+to\s+biodiversity\b',
    ]
    return rx(*pats)(text, ctx)


def f_false_range(text, ctx):
    pats = [
        r'\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]*?\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b',
        r'\bfrom\s+(?:the\s+)?humble\b[^.!?\n]*?\bto\s+(?:the\s+)?(?:mighty|towering|grand|sprawling)\b',
    ]
    return rx(*pats)(text, ctx)


def f_ing_tails(text, ctx):
    verbs = ['highlighting', 'reflecting', 'symbolizing', 'emphasizing', 'underscoring',
             'showcasing', 'fostering', 'cultivating', 'encompassing', 'signaling',
             'demonstrating', 'illustrating', 'representing', 'suggesting', 'indicating',
             'reinforcing', 'leveraging', 'aligning', 'embodying', 'exemplifying', 'epitomizing']
    return rx(r',\s+' + _words(verbs, suffixes=''))(text, ctx)


def f_negative_parallelism(text, ctx):
    """Catalogue 17, parallelism form: weight-zero writing advice."""
    pats = [
        r"\bit['’]s\s+not\s+just\s+(?:about|an?)\b",
        r"\bit['’]s\s+not\s+merely\s+(?:about|an?)\b",
        r'\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b',
        r"\bdoesn['’]t\s+just\b[^,.\n]{0,40}?\bit\b",
    ]
    return rx(*pats)(text, ctx)


def f_tailing_negation(text, ctx):
    """Catalogue 17, tailing-negation form: score-moving."""
    pat = r',\s+no\s+(?:guessing|wasted\s+motion|waste|hassle|fluff|stress|jargon)\b'
    return rx(pat)(text, ctx)


# spec: N-000155
def f_not_x_just_y(text, ctx):
    pats = [
        r'\b(?:no|not)\s+\w+,\s+(?:just|only|simply)\s+\w+',
        r"\b(?:not|isn['’]t|aren['’]t|wasn['’]t|weren['’]t)\s+(?:just|merely)\s+(?:a|an|the)\s+\w+\s*(?:,|–|—|-)\s*(?:it['’]s|it\s+is|it\s+was|they['’]re|they\s+are|they\s+were|that['’]s|but)\b",
    ]
    return rx(*pats, flags=re.I)(text, ctx)


# spec: N-000161
def f_filler(text, ctx):
    phrases = ['in order to', 'due to the fact that', 'at this point in time', 'in the event that',
               'has the ability to', 'it is important to note that',
               'it should be mentioned that', 'needless to say']
    return rx(_phrases(phrases))(text, ctx)


def f_empty_pivot(text, ctx):
    pats = [
        r"\bit['’]s\s+worth\s+(?:noting|mentioning)\s+that\b",
        r'\bit\s+bears\s+(?:noting|mentioning)\s+that\b',
        r'\bone\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is\b',
        r'\bit\s+is\s+interesting\s+to\s+note\s+that\b',
        r'\ba\s+key\s+consideration\s+is\b',
        r'\ba\s+point\s+to\s+highlight\s+is\b',
    ]
    return rx(*pats)(text, ctx)


def f_outcome_tails(text, ctx):
    phrases = ['raising questions about', 'prompting reflection on', 'sparking debate about',
               'with broader implications for', 'reshaping our understanding of',
               'paving the way for', 'signaling a shift toward']
    return rx(r',\s+' + _phrases(phrases))(text, ctx)


# spec: N-000162
def f_persuasive_tropes(text, ctx):
    phrases = ["here's the thing", 'make no mistake', 'the truth is', "let's be honest",
               'the simple fact is', 'at its core', 'what really matters', 'more than anything',
               'at the end of the day', 'the bottom line is', 'in reality', 'fundamentally,',
               'the real question is', 'the heart of the matter', 'the deeper issue',
               'when you get down to it', 'when all is said and done']
    return rx(_phrases(phrases))(text, ctx)


# spec: N-000188
def f_editorial(text, ctx):
    pats = [
        r"\bit(?:['’]s|\s+is)\s+important\s+to\s+(?:remember|note|understand|recognize)\b",
        r'\bone\s+must\s+note\s+that\b',
        r'\bit\s+is\s+worth\s+pointing\s+out\b',
        r'\bit\s+cannot\s+be\s+overstated\s+that\b',
        r'\bit\s+must\s+be\s+emphasized\s+that\b',
    ]
    return rx(*pats)(text, ctx)


# spec: N-000189 N-000190
def f_question_answer(text, ctx):
    pat = (r'\b(?:Is|Are|Can|Could|Do|Does|Did|Will|Would|Should|Has|Have|Was|Were|May|Might|Must|Shall)\b'
           r'[^.?!\n]{0,80}\?\s+(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)[.!]')
    return rx(pat, flags=0)(text, ctx)


# spec: N-000191
def f_concrete_evidence(text, ctx):
    pats = [
        r'\bwithout\s+concrete\s+(?:evidence|proof)\b',
        r'\bdo\s+you\s+have\s+concrete\s+evidence\b',
        r'\bI\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples)\s+to\b',
        r'\babsent\s+concrete\s+proof\b',
        r'\bprovide\s+concrete\s+evidence\b',
    ]
    return rx(*pats)(text, ctx)


def f_intro_hooks(text, ctx):
    pats = [
        r"\bin\s+today['’]s\s+(?:\w+\s+){0,2}?(?:world|landscape|environment|market)\b",
        r'\bin\s+a\s+world\s+where\b',
        r'\bin\s+an\s+era\s+of\b',
        r'\bin\s+recent\s+years,',
        r'\bmore\s+than\s+ever\s+before\b',
        r'\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b',
        r'\b(?:great|exciting|big)\s+news\s*[!:]',
        r'\bever\s+(?:wanted|wondered|dreamed|wished)\b[^?\n]{0,80}\?',
        r'\bin\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world\b',
    ]
    return rx(*pats)(text, ctx)


# spec: N-000156 N-000157
def f_formulaic_challenges(text, ctx):
    pats = [
        r'\bdespite\s+(?:these|its|the)\s+(?:challenges|obstacles)\b',
        r'\bchallenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)\b',
        r'\bcontinues?\s+to\s+thrive\b',
        r'\btypical\s+of\s+(?:emerging|urban|modern)\b',
        r'\bfaces?\s+(?:several|many|numerous)\s+challenges\b',
    ]
    return rx(*pats)(text, ctx)


TRANSITIONS = ('Additionally', 'Furthermore', 'Moreover', 'However', 'Nevertheless',
               'Consequently', 'Subsequently', 'Notably')
_TRANS_RE = re.compile(r'(?:^|(?<=[.!?]\s)|(?<=\n))(' + '|'.join(TRANSITIONS) + r')\b', re.M)


# spec: N-000158
def f_transition_clusters(text, ctx):
    hits = []
    for start, end, _chunk in ctx['paragraphs']:
        found = [(start + m.start(), m.group(0)) for m in _TRANS_RE.finditer(text[start:end])]
        if len(found) >= 2:
            hits.extend(found)
    return hits


# spec: N-000159
def f_compulsive_conclusions(text, ctx):
    pat = (r'^[ \t]*(?:[-*+][ \t]+)?(?:in\s+conclusion|overall|in\s+summary|to\s+summarize|'
           r'to\s+conclude|all\s+in\s+all|in\s+essence|ultimately)\b')
    return rx(pat, flags=re.I | re.M)(text, ctx)


# spec: N-000160
def f_generic_conclusions(text, ctx):
    pats = [
        r'\bthe\s+future\s+looks\s+bright\b',
        r'\bexciting\s+times\s+lie\s+ahead\b',
        r'\bjourney\s+toward\s+excellence\b',
        r'\bstep\s+in\s+the\s+right\s+direction\b',
        r'\b(?:outlook|future)(?:\s+for\s+[\w ]{1,30}?)?\s+(?:is|looks|remains)\s+bright\b',
        r'\bwell[- ]positioned\s+for\s+whatever\s+comes\s+next\b',
        r'\bwell[- ]positioned\s+for\s+the\s+(?:future|road\s+ahead)\b',
    ]
    return rx(*pats)(text, ctx)


def f_monotony(text, ctx):
    lengths = [w for _, _, w in ctx['sentences']]
    if len(lengths) < 3:
        return []
    cv = _cv(lengths)
    if cv is not None and cv < 0.35:
        return [(0, 'sentence-length monotony (CV %.2f)' % cv)]
    return []


def f_uniform_paragraphs(text, ctx):
    counts = [count_words(chunk) for _, _, chunk in ctx['paragraphs']]
    if len(counts) < 4:
        return []
    cv = _cv(counts)
    if cv is not None and cv < 0.4:
        return [(0, 'uniform paragraph length (CV %.2f)' % cv)]
    return []


# spec: N-000207
def f_mechanical_alternation(text, ctx):
    spans = ctx['sentences']
    lengths = [w for _, _, w in spans]
    hits = []
    i = 0
    n = len(lengths)
    while i < n - 1:
        j = i
        while j + 1 < n:
            d = lengths[j + 1] - lengths[j]
            if abs(d) < 5:
                break
            if j > i:
                prev_d = lengths[j] - lengths[j - 1]
                if (prev_d > 0) == (d > 0):
                    break
            j += 1
        run = j - i + 1
        if run >= 6:
            hits.append((spans[i][0], text[spans[i][0]:spans[i][1]]))
            i = j + 1
        else:
            i += 1
    return hits


# spec: N-000164
def f_opener_repetition(text, ctx):
    hits = []
    for start, end, _chunk in ctx['paragraphs']:
        sents = [s for s in ctx['sentences'] if start <= s[0] < end]
        if len(sents) < 3:
            continue
        counts = {}
        for s0, s1, _ in sents:
            words = re.findall(r"[A-Za-z0-9'’-]+", text[s0:s1])
            if len(words) >= 2:
                key = (words[0].lower(), words[1].lower())
                counts.setdefault(key, []).append(s0)
        for key, positions in counts.items():
            if len(positions) >= 3:
                hits.append((positions[0], ' '.join(key)))
    return hits


# spec: N-000201 N-000202 N-000203
def f_semicolon_underuse(text, ctx):
    if count_words(text) < 300:
        return []
    if ';' not in text and text.count('(') <= 1:
        return [(0, 'no semicolons and almost no parentheses')]
    return []


# spec: N-000165
def f_chatbot_artifacts(text, ctx):
    pats = [
        r'\bI\s+hope\s+this\s+helps\b',
        r'\b(?:Certainly|Of course)!',
        r'\blet\s+me\s+know\s+if\s+you\b',
        r'\bwould\s+you\s+like\s+me\s+to\b',
        r'\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b',
        r'\bhappy\s+to\s+help\s*[.!]',
        r'\b(?:here|below)\s+is\s+(?:a|an|the)\s+(?:overview|summary|rundown|recap|brief)\b',
        r'\bhere\s+are\s+(?:some|two|three)\s+(?:options|drafts|versions|variations)\b',
        r"\bhere['’]s\s+(?:a\s+few|some|two|three)\s+(?:options|drafts|versions|variations)\b",
        r"\bhere\s+(?:is|['’]s)\s+a\s+draft\b",
        r'\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b',
        r'\bI\s+hope\s+(?:this\s+email\s+)?finds\s+you\s+well\b',
        r'\bas\s+an\s+(?:AI\s+assistant|AI\s+language\s+model|large\s+language\s+model|language\s+model|AI|LLM)\b',
        r'\bto\s+(?:answer|address)\s+your\s+question\b',
        r'\bin\s+(?:response|answer)\s+to\s+your\s+question\b',
        r'\byour\s+question\s+(?:about|regarding|concerning)\b',
        r'\bas\s+you\s+(?:requested|asked),?\s+here\b',
        r'\bhere\s+is\s+(?:the\s+)?(?:draft|first\s+pass|revised\s+version)\s+(?:of|for\s+your)\b',
    ]
    return rx(*pats, flags=re.I)(text, ctx)


# spec: N-000166 N-000167
def f_sycophancy(text, ctx):
    pats = [
        r"\byou(?:['’]re|\s+are)\s+absolutely\s+right\b",
        r'\b(?:great|excellent)\s+(?:question|point)\s*[!.,]',
        r'\bwhat\s+a\s+(?:thoughtful|great|wonderful|fantastic)\s+question\b',
        r"\bthat['’]s\s+a\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\b",
    ]
    return rx(*pats)(text, ctx)


# spec: N-000168
def f_cutoff(text, ctx):
    pats = [
        r'\bas\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)\b',
        r'\bup\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)\b',
        r'\bwhile\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+extensively\s+documented|not\s+widely\s+documented)',
        r'\bbased\s+on\s+(?:the\s+)?available\s+information\b',
        r'\bas\s+of\s+my\s+(?:knowledge\s+)?cutoff\b',
        r'\bmaintains\s+a\s+low\s+profile\b',
        r'\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b',
    ]
    return rx(*pats)(text, ctx)


# spec: N-000169
def f_copula(text, ctx):
    pats = [
        r'\b(?:serves|stands|functions|acts)\s+as\b',
        r'\brepresents\s+(?:an?|the)\b',
        r'\bmarks\s+(?:a|the)\b',
        r'\bboasts\b',
        r'\bfeatures\s+(?:an?|the|\d+|several|many|some)\b',
        r'\boffers\s+an?\b',
        r'\brefers\s+to\b',
    ]
    return rx(*pats)(text, ctx)


HEDGE_RE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems?\s+(?:to|like)|"
                      r"appears?\s+to|somewhat|relatively|fairly|kind\s+of|sort\s+of)\b")


# spec: N-000170
def f_hedge_stacking(text, ctx):
    hits = []
    for s0, s1, _ in ctx['sentences']:
        if len(HEDGE_RE.findall(text[s0:s1])) >= 2:
            hits.append((s0, text[s0:s1]))
    return hits


FIRST_PERSON_RE = re.compile(r"\b(?:I|me|my|we|our|us)\b")
FULL_FORMS_RE = re.compile(r"\b(?:do not|does not|did not|is not|are not|was not|were not|have not|"
                           r"has not|will not|would not|cannot|should not|could not|it is|that is|"
                           r"there is|I am|we are|they are|you are|I have|we have|they have|I will|I would)\b")
CONTRACTED_RE = re.compile(r"\b(?:don['’]t|doesn['’]t|didn['’]t|isn['’]t|aren['’]t|"
                           r"wasn['’]t|weren['’]t|haven['’]t|hasn['’]t|won['’]t|"
                           r"wouldn['’]t|can['’]t|shouldn['’]t|couldn['’]t|it['’]s|"
                           r"that['’]s|there['’]s|I['’]m|we['’]re|they['’]re|"
                           r"you['’]re|I['’]ve|we['’]ve|they['’]ve|I['’]ll|"
                           r"we['’]ll|I['’]d)\b")


# spec: N-000204 N-000205 N-000206
def f_contraction_absence(text, ctx):
    words = count_words(text)
    fp = len(FIRST_PERSON_RE.findall(text))
    if words == 0 or fp < 5 or fp / float(words) < 0.02:
        return []
    full = FULL_FORMS_RE.findall(text)
    contracted = len(CONTRACTED_RE.findall(text))
    if len(full) >= 3 and len(full) >= 3 * contracted:
        m = FULL_FORMS_RE.search(text)
        return [(m.start(), m.group(0))]
    return []


def f_bold_overuse(text, ctx):
    return rx(r'\*\*[^*\n]+?\*\*', flags=0)(text, ctx) if len(re.findall(r'\*\*[^*\n]+?\*\*', text)) >= 3 else []


def f_emoji(text, ctx):
    return rx(r'[\U0001F000-\U0001FAFF☀-➿]', flags=0)(text, ctx)


# spec: N-000208
def f_em_dash(text, ctx):
    hits = []
    for start, end, _ in ctx['paragraphs']:
        chunk = text[start:end]
        if chunk.count('—') >= 2:
            hits.append((start, chunk[:60]))
    return hits


MINOR_WORDS = {'a', 'an', 'the', 'and', 'but', 'or', 'nor', 'for', 'so', 'yet', 'of', 'in', 'on',
               'at', 'to', 'by', 'with', 'from', 'as', 'into', 'onto', 'via', 'per', 'up', 'off', 'over'}


# spec: N-000209 N-000210
def f_title_case(text, ctx):
    hits = []
    for m in re.finditer(r'^[ \t]{0,3}#{1,6}[ \t]+(.+?)[ \t]*#*[ \t]*$', text, re.M):
        heading = m.group(1).strip()
        words = heading.split()
        if len(words) < 3 or not heading or heading.isupper() or not heading[0].isalpha():
            continue
        major = [w for w in words if w.lower().strip('.,:;!?') not in MINOR_WORDS and w[0].isalpha()]
        if len(major) >= 2 and all(w[0].isupper() for w in major):
            hits.append((m.start(), heading))
    return hits


# spec: N-000211
def f_curly_quotes(text, ctx):
    return rx('[“”‘’]', flags=0)(text, ctx)


# spec: N-000212
def f_hyphen_ranges(text, ctx):
    hits = []
    for m in re.finditer(r'\b(1[5-9]\d\d|20\d\d)-(1[5-9]\d\d|20\d\d)\b', text):
        if int(m.group(1)) < int(m.group(2)):
            hits.append((m.start(), m.group(0)))
    return hits


# spec: N-000171
def f_invisible(text, ctx):
    return [(p, 'U+%04X' % ord(text[p])) for p in ctx['invisible']]


PLACEHOLDER_PATS = [
    r'\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]{0,80}\](?![(\[])',
    r'\[[A-Z][A-Z _-]{2,}\](?![(\[])',
    r'\{\{[^{}\n]*\}\}',
    r'(?<![A-Za-z])x{3,}(?![A-Za-z])',
    r'lorem\s+ipsum',
]


# spec: N-000172 N-000173
def f_placeholder(text, ctx):
    return rx(*PLACEHOLDER_PATS, flags=re.I)(text, ctx)


# spec: N-000174
def f_chat_markup(text, ctx):
    pats = [r'\bcite(?:turn|start|nav)\w*', r'\boai_citation\w*', r'contentReference', r'navlist',
            r'【\d+†']
    return rx(*pats, flags=0)(text, ctx)


AI_HOSTS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai', 'gemini.google.com',
            'copilot.microsoft.com', 'poe.com'}


# spec: N-000175 N-000176
def f_ai_tracking(text, ctx):
    hits = []
    for m in re.finditer(r'utm_source=([A-Za-z0-9.\-]+)', text, re.I):
        host = m.group(1).rstrip('.').lower()
        if host in AI_HOSTS:
            hits.append((m.start(), m.group(0)))
    return hits


# spec: N-000177
def f_homoglyph(text, ctx):
    return [(s, text[s:e]) for s, e in ctx['homoglyph']]


# spec: N-000178 N-000179
def f_nonstandard_spaces(text, ctx):
    return [(p, 'U+%04X' % ord(text[p])) for p in ctx['nonstandard']]


# spec: N-000180 N-000181
def f_trailing_ws(text, ctx):
    # Read the original window text: the exclusion mask must not create whitespace findings.
    text = ctx.get('orig', text)
    hits = []
    for m in re.finditer(r'[ \t]+$', text, re.M):
        hits.append((m.start(), 'trailing'))
    if text[:1].isspace():
        hits.append((0, 'leading whitespace'))
    m = re.search(r'\n{2,}\Z', text)
    if m:
        hits.append((m.start(), 'blank lines at end'))
    return hits


MARKETING_SLOP = ['unlocking (?:its |your |the )?full potential', 'navigating the complexities',
                  'a testament to the (?:power|importance) of', 'staying ahead of the curve',
                  'turning challenges into opportunities', 'taking [\\w ]{1,30}? to the next level',
                  'harnessing the power of', 'paving the way for', 'saying goodbye to',
                  'imagining a world where']


# spec: N-000213 N-000214
def f_marketing_slop(text, ctx):
    return rx(*[r'\b' + p for p in MARKETING_SLOP], flags=re.I)(text, ctx)


# spec: N-000215 N-000216
def f_decorative_rules(text, ctx):
    if text.count('\n') + 1 < 24:
        return []
    hits = [(m.start(), m.group(0).strip()) for m in
            re.finditer(r'^[ \t]{0,3}([-*_])(?:[ \t]*\1){2,}[ \t]*$', text, re.M)]
    return hits if len(hits) >= 3 else []


# spec: N-000217 N-000218 N-000219
def f_degenerate(text, ctx):
    toks = [(m.start(), m.group(0).lower()) for m in re.finditer(r"[^\W_]+", text)]
    if len(toks) < 6:
        return []
    grams = []
    for i in range(len(toks) - 5):
        grams.append(tuple(t for _, t in toks[i:i + 6]))
    counts = {}
    for g in grams:
        counts[g] = counts.get(g, 0) + 1
    repeated = [i for i, g in enumerate(grams) if counts[g] > 1]
    if not repeated or len(repeated) / float(len(grams)) < 0.2:
        return []
    return [(toks[i][0], ' '.join(grams[i])) for i in repeated[:200]]


HYPHEN_COMPOUNDS = ['cutting-edge', 'state-of-the-art', 'best-in-class', 'user-friendly',
                    'time-saving', 'results-driven', 'detail-oriented', 'data-driven',
                    'forward-thinking', 'value-added', 'next-generation', 'user-centric',
                    'high-performing', 'top-notch', 'well-rounded', 'cost-effective',
                    'laser-focused', 'battle-tested', 'future-proof', 'industry-leading']


# spec: N-000182 N-000183 N-000184
def f_hyphen_pairs(text, ctx):
    return rx(*[r'\b' + re.escape(h) + r'\b' for h in HYPHEN_COMPOUNDS], flags=re.I)(text, ctx)


# spec: N-000197
def f_inline_headers(text, ctx):
    pats = [
        r'^[ \t]*(?:(?:[-*+]|\d+\.)[ \t]+)?\*\*[^*\n]*:\*\*',
        r'^[ \t]*(?:(?:[-*+]|\d+\.)[ \t]+)?\*\*[^*\n]+\*\*:',
    ]
    return rx(*pats, flags=re.M)(text, ctx)


LIST_LINE = re.compile(r'^[ \t]*(?:[-*+]|\d+[.)])[ \t]+\S')
HEADING_LINE = re.compile(r'^[ \t]{0,3}#{1,6}[ \t]')


# spec: N-000198 N-000199
def f_bullet_injection(text, ctx):
    if HEADING_LINE.search(text):
        return []
    prose = 0
    list_paras = []
    for start, end, chunk in ctx['paragraphs']:
        lines = [ln for ln in chunk.split('\n') if ln.strip()]
        if lines and all(LIST_LINE.match(ln) for ln in lines):
            list_paras.append((start, chunk[:60]))
        else:
            prose += 1
    if list_paras and prose >= 2:
        return list_paras[:1]
    return []


# spec: N-000200
def f_fragmented_headers(text, ctx):
    hits = []
    lines = text.split('\n')
    offsets = []
    pos = 0
    for ln in lines:
        offsets.append(pos)
        pos += len(ln) + 1
    for i, ln in enumerate(lines):
        m = re.match(r'^[ \t]{0,3}#{1,6}[ \t]+(.+?)[ \t]*$', ln)
        if not m:
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if not nxt or re.match(r'^(?:#|[-*+>|]|\d+[.)]\s)', nxt) or len(nxt.split()) > 4:
            continue
        head_words = {w.lower() for w in re.findall(r'[A-Za-z]{3,}', m.group(1))}
        next_words = {w.lower() for w in re.findall(r'[A-Za-z]{3,}', nxt)}
        if head_words & next_words:
            hits.append((offsets[i], m.group(1)))
    return hits




def _families():
    """Catalogue families: (key, number, label, advice, decisive, function)."""
    return [
        ('1', 1, 'AI vocabulary', False, False, f_ai_vocab),
        ('2', 2, 'model-dialect vocabulary', False, False, f_model_dialect),
        ('3', 3, 'promotional language', False, False, f_promotional),
        ('4', 4, 'hyphenated word-pair overuse', True, False, f_hyphen_pairs),
        ('5', 5, 'simple yet X cliche', False, False, f_simple_yet),
        ('6', 6, 'stacked adjective chains', False, False, f_adjective_chains),
        ('8', 8, 'synonym cycling', False, False, f_synonym_cycling),
        ('10', 10, 'significance inflation', False, False, f_significance),
        ('11', 11, 'notability name-dropping', False, False, f_notability),
        ('12', 12, 'vague attributions', False, False, f_vague_attribution),
        ('13', 13, 'article title as proper noun', False, True, f_article_title),
        ('14', 14, 'conservation and ecosystem padding', False, False, f_conservation),
        ('15', 15, 'false ranges', False, False, f_false_range),
        ('16', 16, 'superficial -ing tail clauses', False, False, f_ing_tails),
        ('17p', 17, 'negative parallelism', True, False, f_negative_parallelism),
        ('17t', 17, 'tailing negation', False, False, f_tailing_negation),
        ('18', 18, 'not X, just Y', False, False, f_not_x_just_y),
        ('19', 19, 'filler phrases', True, False, f_filler),
        ('20', 20, 'empty pivot phrases', False, False, f_empty_pivot),
        ('21', 21, 'outcome speculation tails', False, False, f_outcome_tails),
        ('22', 22, 'persuasive authority tropes', True, False, f_persuasive_tropes),
        ('23', 23, 'editorial interjections', False, False, f_editorial),
        ('24', 24, 'self-thoroughness phrases', False, False, f_self_thorough),
        ('25', 25, 'question-answer rhetorical pattern', False, False, f_question_answer),
        ('26', 26, 'concrete evidence defense phrase', False, False, f_concrete_evidence),
        ('27', 27, 'compulsive intro hooks', False, False, f_intro_hooks),
        ('30', 30, 'diff-anchored writing', False, False, f_diff_anchored),
        ('31', 31, 'signposting and announcements', False, False, f_signposting),
        ('32', 32, 'cataloguing lead-ins', False, False, f_cataloguing),
        ('33', 33, 'inline-header vertical lists', False, False, f_inline_headers),
        ('34', 34, 'mid-essay bullet injection', False, False, f_bullet_injection),
        ('35', 35, 'fragmented headers', False, False, f_fragmented_headers),
        ('36', 36, 'formulaic challenges sections', False, False, f_formulaic_challenges),
        ('37', 37, 'transition cluster overuse', False, False, f_transition_clusters),
        ('38', 38, 'compulsive conclusion phrases', False, False, f_compulsive_conclusions),
        ('39', 39, 'generic positive conclusions', False, False, f_generic_conclusions),
        ('40', 40, 'sentence-length monotony', False, False, f_monotony),
        ('41', 41, 'mechanical sentence-length alternation', True, False, f_mechanical_alternation),
        ('42', 42, 'opener repetition', True, False, f_opener_repetition),
        ('44', 44, 'uniform paragraph length', False, False, f_uniform_paragraphs),
        ('46', 46, 'semicolon and parenthesis underuse', True, False, f_semicolon_underuse),
        ('47', 47, 'chatbot artifacts', False, True, f_chatbot_artifacts),
        ('48', 48, 'sycophantic tone', False, True, f_sycophancy),
        ('50', 50, 'knowledge-cutoff disclaimers', False, True, f_cutoff),
        ('51', 51, 'copula avoidance', False, False, f_copula),
        ('54', 54, 'hedge stacking', True, False, f_hedge_stacking),
        ('55', 55, 'contraction absence', True, False, f_contraction_absence),
        ('56', 56, 'boldface overuse', False, False, f_bold_overuse),
        ('57', 57, 'emojis', False, False, f_emoji),
        ('58', 58, 'em-dash overuse', True, False, f_em_dash),
        ('59', 59, 'title case in headings', False, False, f_title_case),
        ('60', 60, 'curly quotation marks', True, False, f_curly_quotes),
        ('61', 61, 'hyphen-for-en-dash in numeric ranges', True, False, f_hyphen_ranges),
        ('62', 62, 'invisible or zero-width characters', False, True, f_invisible),
        ('63', 63, 'placeholder text', False, True, f_placeholder),
        ('64', 64, 'chat reference markup', False, True, f_chat_markup),
        ('65', 65, 'AI tracking parameters', False, True, f_ai_tracking),
        ('66', 66, 'mixed-script homoglyphs', False, True, f_homoglyph),
        ('67', 67, 'non-standard spaces', False, False, f_nonstandard_spaces),
        ('68', 68, 'trailing whitespace', True, False, f_trailing_ws),
        ('69', 69, 'canonical marketing phrases', False, False, f_marketing_slop),
        ('70', 70, 'decorative horizontal rules', False, False, f_decorative_rules),
        ('71', 71, 'degenerate repetition', False, False, f_degenerate),
    ]


# spec: N-000163
def f_self_thorough(text, ctx):
    pats = [
        r'\bthis\s+(?:comprehensive|complete)\s+(?:guide|overview|analysis)\b',
        r'\bthis\s+in-depth\s+(?:analysis|look|examination)\b',
        r'\ba\s+thorough\s+examination\s+of\b',
        r'\beverything\s+you\s+need\s+to\s+know\s+about\b',
    ]
    return rx(*pats)(text, ctx)


# spec: N-000185 N-000186 N-000187
def f_notability(text, ctx):
    pats = [
        r'(?i:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?i:in|by)\s+'
        r'[A-Z][\w&.-]*(?:\s+[A-Z][\w&.-]*)*(?:,\s*|\s+and\s+|\s+or\s+)[A-Z][\w&.-]*',
        r'\b\d[\d,.]*\s*[KkMm]?\s+(?:followers|subscribers)\b',
        r'\bstrong\s+(?:online|digital|social[- ]media)\s+presence\b',
        r'\bactive\s+(?:online|digital|social[- ]media)\s+presence\b',
        r'\bwidely\s+covered\b',
        r'\bindependent\s+coverage\b',
    ]
    return rx(*pats, flags=0)(text, ctx)


# spec: N-000192
def f_diff_anchored(text, ctx):
    pats = [
        r'\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b',
        r'\b(?:the|this)\s+(?:latest\s+|new\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b',
        r'\b(?:has|have)\s+been\s+(?:updated|refactored|improved|enhanced|changed)\s+to\b',
        r'\bpreviously\b[^.!?\n]{0,80}\bnow\b',
        r"\bwasn['’]t\s+there\s+before\b|\bweren['’]t\s+there\s+before\b",
        r"\bwe['’]ve\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b|\bwe\s+have\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b",
    ]
    return rx(*pats)(text, ctx)


# spec: N-000193
def f_signposting(text, ctx):
    pats = [
        r"\blet['’]s\s+(?:dive|delve|explore)\b",
        r"\blet['’]s\s+break\s+(?:this|it)\s+down\b",
        r"\bhere['’]s\s+what\s+you\s+need\s+to\s+know\b",
        r'\bwithout\s+further\s+ado\b',
        r"\bnow\s+let['’]s\s+look\s+at\b",
        r'\bbuckle\s+up\b',
        r'\bstay\s+with\s+me\b',
        r'\b(?:are\s+you\s+)?ready\s+to\s+dive\s+in\b',
    ]
    return rx(*pats)(text, ctx)


# spec: N-000194 N-000195 N-000196
def f_cataloguing(text, ctx):
    pats = [
        r'\b(?:used|uses|employ|employs|employed|relied\s+on|utilizes?)\s+(?:several|various|a\s+number\s+of|multiple|different|many|numerous)\s+\w+',
        r'\bThese\s+(?:\w+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help)\s+(?:information|insight|understanding|details|data)\b',
        r'\b(?:is|are|was|were|remains|becomes)\s+(?:the\s+|a\s+)?(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b',
    ]
    return rx(*pats, flags=re.I)(text, ctx)


def _catalogue_families(text, ctx):
    results = []
    for key, num, label, advice, decisive, fn in _families():
        hits = fn(text, ctx) or []
        if hits:
            results.append({'key': key, 'num': num, 'label': label, 'advice': advice,
                            'decisive': decisive, 'hits': hits})
    return results


# ---------------------------------------------------------------------------
# Scoring (FP-01)
# ---------------------------------------------------------------------------

BANDS = [(20, 'clean'), (40, 'light tells'), (60, 'mixed'), (80, 'heavy tells'), (100, 'pervasive tells')]
RHYTHM_NUMS = {40, 44}
SHORT_FLOOR_NUMS = set(range(1, 40)) | set(range(47, 52)) | {69}


def band_for(score):
    for limit, name in BANDS:
        if score <= limit:
            return name
    return 'pervasive tells'


def confidence_for(words, n_families):
    if words < 40:
        return 'none', 'fewer than 40 words, so the score is not meaningful'
    if words < 120:
        return 'low', 'fewer than 120 words'
    if words < 300 and n_families <= 1:
        return 'low', 'fewer than 300 words with only one pattern family'
    if words < 300:
        return 'moderate', 'between 120 and 299 words'
    return 'high', ''


def score_from(families, words):
    """families: list of dicts with key, num, advice, decisive, count. Returns score, band, confidence, reason."""
    sm = [f for f in families if not f['advice'] and f['count'] > 0]
    sm_nums = {f['num'] for f in sm}
    dec_nums = {f['num'] for f in sm if f['decisive']}
    n_fam = len(sm_nums)
    conf, reason = confidence_for(words, n_fam)

    base = 0
    for f in sm:
        extra = min(f['count'] - 1, 3)
        base += (16 if f['decisive'] else 10) + 2 * extra
    score = min(100, base)

    caps = []
    if n_fam and sm_nums <= {40}:
        caps.append(20)
    elif n_fam and sm_nums <= RHYTHM_NUMS:
        caps.append(40)
    if n_fam == 1 and not (len(dec_nums) == 1 and conf in ('moderate', 'high')):
        caps.append(40)
    if caps:
        score = min(score, min(caps))

    floor = 0
    if len(dec_nums) >= 2:
        floor = max(floor, 65)
    elif len(dec_nums) == 1 and conf in ('moderate', 'high'):
        floor = max(floor, 45)
    if words < 120:
        short_n = len(sm_nums & SHORT_FLOOR_NUMS)
        if short_n >= 3:
            floor = max(floor, 45)
        elif short_n >= 2:
            floor = max(floor, 25)
    if words >= 400:
        if n_fam >= 6:
            floor = max(floor, 45)
        elif n_fam >= 5:
            floor = max(floor, 25)
    score = max(score, floor)
    score = max(0, min(100, int(score)))
    return score, band_for(score), conf, reason


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------

def _slug(label):
    return re.sub(r'[^a-z0-9]+', '_', label.lower()).strip('_')


# spec: N-000094 N-000095 N-000096 N-000097 N-000098 N-000099 N-000100 N-000101 N-000102 N-000103 N-000104 N-000105 N-000106 N-000107 N-000108 N-000109 N-000110 N-000111 N-000112 N-000113 N-000114 N-000115 N-000116 N-000117 N-000118 N-000119 N-000120 N-000121 N-000122 N-000123 N-000124 N-000125 N-000126 N-000127 N-000128 N-000129 N-000130 N-000131 N-000132 N-000133 N-000134 N-000135 N-000136 N-000137 N-000138 N-000139 N-000140 N-000141 N-000142 N-000143 N-000144 N-000145 N-000146 N-000147 N-000148 N-000149 N-000236 N-000237 N-000238 N-000239 N-000240 N-000630 N-000631 N-000632 N-000744 N-000745 N-000746 N-000747 N-000748 N-000749 N-000750 N-000751 N-000752 N-000753 N-000754 N-000755 N-000756 N-000757 N-000758 N-000759 N-000760 N-000761 N-000762 N-000763 N-000764 N-000765 N-000766 N-000767 N-000768 N-000769 N-000770 N-000771 N-000772 N-000773 N-000774
def analyze(full_text, ci=False):
    truncated = len(full_text) > WINDOW
    text = full_text[:WINDOW]
    invisible = invisible_positions(text)
    nonstandard = nonstandard_space_positions(text)
    homoglyph = homoglyph_tokens(text)
    scan = mask_excluded(text)
    words = count_words(scan)
    sentences = sentence_spans(scan)
    paragraphs = paragraph_spans(scan)
    ctx = {'sentences': sentences, 'paragraphs': paragraphs, 'invisible': invisible,
           'nonstandard': nonstandard, 'homoglyph': homoglyph, 'orig': text}

    fams = _catalogue_families(scan, ctx)
    members = {}
    for f in fams:
        hits = f['hits']
        f['count'] = len(hits)
        samples = []
        for _, s in hits:
            s2 = _sample(s)
            if s2 and s2 not in samples:
                samples.append(s2)
            if len(samples) == 3:
                break
        if f['key'] == '17p':
            member_key = '17_negative_parallelism'
        elif f['key'] == '17t':
            member_key = '17_tailing_negation'
        else:
            member_key = '%d_%s' % (f['num'], _slug(f['label']))
        members[member_key] = {'label': f['label'], 'count': len(hits), 'samples': samples}

    score, band, conf, reason = score_from(fams, words)
    metrics = {
        'scanned_chars': len(text),
        'truncated': truncated,
        'ai_tell_score': score,
        'ai_tell_band': band,
        'confidence': conf,
        'confidence_reason': reason,
        'patterns_flagged': len(members),
        'invisible_chars': len(invisible),
        'nonstandard_spaces': len(nonstandard),
        'homoglyphs': len(homoglyph),
    }
    if ci:
        metrics.update(_interval(text, fams, sentences))
    report = dict(members)
    report['_metrics'] = metrics
    return report


# spec: N-000221 N-000222 N-000223 N-000224 N-000225
def _interval(text, fams, sentences):
    """Resampled interval over sentences. The point score is unchanged."""
    if len(sentences) < 4:
        return {'score_ci': None,
                'score_ci_note': 'too few sentences (%d; need at least 4) for an interval' % len(sentences)}
    starts = [s[0] for s in sentences]
    per_sentence = [dict() for _ in sentences]
    meta = {}
    for f in fams:
        meta[f['key']] = f
        for pos, _ in f['hits']:
            idx = bisect.bisect_right(starts, pos) - 1
            if idx < 0:
                idx = 0
            per_sentence[idx][f['key']] = per_sentence[idx].get(f['key'], 0) + 1
    rng = random.Random(20260506)
    n = len(sentences)
    scores = []
    for _ in range(200):
        counts = {}
        words = 0
        for _ in range(n):
            k = rng.randrange(n)
            words += sentences[k][2]
            for key, c in per_sentence[k].items():
                counts[key] = counts.get(key, 0) + c
        fam_list = []
        for key, c in counts.items():
            m = meta[key]
            fam_list.append({'key': key, 'num': m['num'], 'advice': m['advice'],
                             'decisive': m['decisive'], 'count': c})
        s, _, _, _ = score_from(fam_list, words)
        scores.append(s)
    scores.sort()
    low = scores[int(0.025 * (len(scores) - 1))]
    high = scores[int(math.ceil(0.975 * (len(scores) - 1)))]
    return {'score_ci': [low, high],
            'score_ci_note': 'resampled over sentences (200 draws); the point score is unchanged'}


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------

def _err(message):
    sys.stderr.write(json.dumps({'error': message}) + '\n')
    sys.stderr.flush()


# spec: N-000716 N-000717
def _write_stdout(data):
    sys.stdout.buffer.write(data.encode('utf-8'))
    sys.stdout.flush()


# spec: N-000231 N-000232 N-000233 N-000234 N-000235 N-000704 N-000705 N-000706 N-000707 N-000708 N-000709 N-000710 N-000711 N-000712 N-000713 N-000714 N-000715 N-000716 N-000717 N-000718 N-000719 N-000720 N-000721 N-000731 N-000732 N-000733 N-000734 N-000735 N-000736 N-000737 N-000738 N-000739 N-000740 N-000741 N-000742 N-000743 N-000775 N-000776 N-000777 N-000778 N-000779 N-000780 N-000781 N-000782 N-000783 N-000784 N-000785 N-000786 N-000787 N-000322 N-000323 N-000324
# spec: N-000703
def main(argv):
    clean = False
    ci = False
    operands = []
    end_of_opts = False
    show_help = False
    unknown = None
    for arg in argv[1:]:
        if end_of_opts:
            operands.append(arg)
            continue
        if arg == '--':
            end_of_opts = True
        elif arg in ('--help', '-h'):
            show_help = True
        elif arg == '--clean':
            clean = True
        elif arg == '--ci':
            ci = True
        elif arg.startswith('-') and len(arg) > 1:
            unknown = arg
            break
        else:
            operands.append(arg)

    if unknown is not None:
        _err('unknown option %r; see --help' % unknown)
        return 2
    if show_help:
        _write_stdout('\n'.join(USAGE_LINES) + '\n')
        return 0

    if len(operands) > 1:
        sys.stderr.write('detect.py: note: %d file operands given; only the first file was scanned: %s\n'
                         % (len(operands), operands[0]))
        sys.stderr.flush()
    path = operands[0] if operands else None

    try:
        text = load_text(path)
    except Fail as exc:
        _err(exc.message)
        return exc.status

    if clean:
        _write_stdout(cleanup_text(text))
        return 0
    report = analyze(text, ci=ci)
    _write_stdout(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv))
    except BrokenPipeError:
        sys.exit(0)
