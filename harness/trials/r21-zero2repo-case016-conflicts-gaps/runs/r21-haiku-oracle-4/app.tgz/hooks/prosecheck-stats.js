#!/usr/bin/env node
'use strict';
// Stats: session token figures from the transcript, plus the session-prose score when
// there is enough assistant text. Used by the prompt-submit router; also runnable as a hook.
// spec: N-000543 N-000544 N-000545 N-000546 N-000547 N-000548 N-000549 N-000550 N-000551
// spec: N-000552 N-000553 N-000554 N-000555 N-001103 N-001104 N-001105 N-001106
// spec: N-001107 N-001108 N-001109 N-001110 N-001111 N-001112 N-001113 N-001114
// spec: N-001115 N-001116 N-001117 N-001118 N-001119 N-001120 N-001121 N-001122 N-001123 N-001124 N-001125 N-001126
const fs = require('fs');
const path = require('path');
const core = require('./lib/prosecheck-core.js');

const PROSE_SLICE_CHARS = 40000;
const PROSE_SCORE_MIN_CHARS = 200;

// spec: N-000543 N-000544 N-000545 N-000546 N-000547 N-000548 N-000549 N-000550 N-000551 N-000552 N-000553 N-000554 N-000555
function newestTranscript(root) {
  let best = null;
  const walk = (dir, depth) => {
    if (depth > 6) return;
    let entries = [];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (e) {
      return;
    }
    for (const ent of entries) {
      const full = path.join(dir, ent.name);
      if (ent.isDirectory()) walk(full, depth + 1);
      else if (ent.isFile() && ent.name.endsWith('.jsonl')) {
        try {
          const mtime = fs.statSync(full).mtimeMs;
          if (!best || mtime > best.mtime) best = { file: full, mtime: mtime };
        } catch (e) {
          // ignore
        }
      }
    }
  };
  walk(path.join(root, 'projects'), 0);
  return best ? best.file : null;
}

function readTranscript(file) {
  const data = fs.readFileSync(file, 'utf8');
  const usageById = new Map();
  const textById = new Map();
  let anon = 0;
  for (const line of data.split('\n')) {
    const t = line.trim();
    if (!t) continue;
    let row;
    try {
      row = JSON.parse(t);
    } catch (e) {
      continue;
    }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const key = typeof msg.id === 'string' && msg.id ? msg.id : 'anon-' + (anon++);
    usageById.set(key, msg.usage && typeof msg.usage === 'object' ? msg.usage : {});
    const texts = [];
    if (Array.isArray(msg.content)) {
      for (const c of msg.content) {
        if (c && c.type === 'text' && typeof c.text === 'string') texts.push(c.text);
      }
    }
    textById.set(key, texts);
  }
  let output = 0;
  let cache = 0;
  for (const u of usageById.values()) {
    output += Number(u.output_tokens) || 0;
    cache += Number(u.cache_read_input_tokens) || 0;
  }
  const prose = [];
  for (const texts of textById.values()) prose.push(...texts);
  return { turns: usageById.size, output: output, cache: cache, prose: prose.join('\n') };
}

function fmt(n) {
  return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// spec: N-001103 N-001104 N-001105 N-001106 N-001107 N-001108 N-001109 N-001110 N-001111 N-001112 N-001113 N-001114 N-001115 N-001116 N-001117 N-001118 N-001119 N-001120 N-001121 N-001122 N-001123 N-001124 N-001125 N-001126
function statsReply(transcriptPath, level) {
  let file = null;
  if (typeof transcriptPath === 'string' && transcriptPath.trim()) {
    file = transcriptPath.trim();
  } else {
    file = newestTranscript(core.configDir());
  }
  if (!file) {
    return 'prosecheck stats: no session transcript was found, so there are no turn or token figures.';
  }
  let info;
  try {
    info = readTranscript(file);
  } catch (e) {
    return 'prosecheck stats: could not read the transcript at ' + file + '.';
  }
  const lines = [
    'prosecheck stats for this session',
    'level: ' + level,
    'assistant turns: ' + fmt(info.turns),
    'output tokens: ' + fmt(info.output),
    'cache-read input tokens: ' + fmt(info.cache),
  ];
  let slice = info.prose.replace(/```[\s\S]*?```/g, '');
  slice = slice.slice(-PROSE_SLICE_CHARS).trim();
  if (slice.length > PROSE_SCORE_MIN_CHARS) {
    const det = core.detectorPath();
    if (det) {
      const r = core.runPython([det], { input: slice, timeout: 8000 });
      if (!r.launchFailed && !r.timedOut && r.status === 0) {
        try {
          const report = JSON.parse(String(r.stdout).trim());
          const score = report && report._metrics && report._metrics.ai_tell_score;
          if (typeof score === 'number') lines.push('session prose ai_tell_score: ' + score);
        } catch (e) {
          // no score line when the report is unusable
        }
      }
    }
  }
  return lines.join('\n');
}

module.exports = { statsReply, newestTranscript };

if (require.main === module) {
  try {
    const input = core.readStdinJson();
    const reply = statsReply(input.transcript_path, core.effectiveLevel());
    process.stdout.write(JSON.stringify({ decision: 'block', reason: reply }) + '\n');
  } catch (e) {
    // never fail the host session
  }
  process.exitCode = 0;
}
