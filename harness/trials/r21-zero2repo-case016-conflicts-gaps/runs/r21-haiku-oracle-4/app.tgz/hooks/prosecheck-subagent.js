#!/usr/bin/env node
'use strict';
// Subagent-start hook: returns the same writing contract inside the subagent JSON envelope.
// spec: N-000813 N-000814 N-000815 N-000816 N-000817 N-000818 N-000384 N-000385
const core = require('./lib/prosecheck-core.js');

// spec: N-000813 N-000814 N-000815 N-000816 N-000817 N-000818 N-000730
function main() {
  core.readStdinJson();
  const level = core.effectiveLevel();
  if (level === 'off') return;
  const envelope = {
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: core.contractText(level),
    },
  };
  process.stdout.write(JSON.stringify(envelope) + '\n');
}

try {
  main();
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
