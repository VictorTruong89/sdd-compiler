#!/usr/bin/env node
'use strict';
// Prompt-submit hook and /prosecheck command router.
// Command prompts are answered with a block decision whose reason is the reply.
// Ordinary prompts get the live-level reminder (or nothing when off).
// spec: N-000380 N-000381 N-000382 N-000383 N-000468 N-000469 N-000470 N-000471 N-000472
// spec: N-000473 N-000474 N-000475 N-000476 N-000477 N-000478 N-000479 N-000480 N-000481
// spec: N-000575 N-000576 N-000577 N-000870 N-000871 N-000872 N-000873 N-000874 N-000875
// spec: N-000876 N-000877 N-000878 N-000879 N-000880 N-000881 N-000882 N-000883 N-000884
// spec: N-000885 N-000886 N-000887 N-000888 N-000889 N-000890 N-000891 N-000892
// spec: N-000904 N-000905 N-000906 N-000907 N-000908 N-000909 N-000910 N-000911 N-000912
// spec: N-000913 N-000914 N-000915 N-000916 N-000917 N-000918 N-000919 N-000920 N-000921
// spec: N-000922 N-000923 N-000924 N-000925 N-000926 N-000927 N-000928 N-000929 N-000930
// spec: N-000931 N-000932 N-000933 N-000934 N-000935 N-000936 N-000937 N-000938 N-000939
// spec: N-000940 N-000941 N-000942 N-000943 N-000944 N-000945 N-000946 N-000947 N-000948
// spec: N-000949 N-000950 N-000951 N-000952 N-000953 N-000954 N-000955 N-000956 N-000957
// spec: N-000958 N-000959 N-000960 N-000961 N-000962 N-000963 N-000964 N-000965 N-000966
// spec: N-000967 N-000968 N-000969 N-000970 N-000971 N-000972 N-000973 N-000974 N-000975
// spec: N-000976 N-000977 N-000978 N-000979 N-000980 N-000981 N-000982 N-000983 N-000984
// spec: N-000985 N-000986 N-000987 N-000988 N-000989 N-000990 N-000991 N-000992 N-000993
// spec: N-000994 N-000995 N-000996 N-000997 N-000998 N-000999 N-001000 N-001001 N-001002
// spec: N-001003 N-001004 N-001005 N-001006 N-001007 N-001008 N-001009 N-001010 N-001011
// spec: N-001012 N-001013 N-001014 N-001015 N-001016 N-001017 N-001018 N-001019 N-001020
// spec: N-001021 N-001022 N-001023 N-001024 N-001025 N-001026 N-001027 N-001028 N-001029
// spec: N-001030 N-001031 N-001032 N-001033 N-001034 N-001035 N-001036 N-001037 N-001038
// spec: N-001039 N-001040 N-001041 N-001042 N-001043 N-001044 N-001045 N-001046 N-001047
// spec: N-001048 N-001049 N-001050 N-001051 N-001052 N-001053 N-001054 N-001055 N-001056
// spec: N-001057 N-001058 N-001059 N-001060 N-001061 N-001062 N-001063 N-001064 N-001065
// spec: N-001066 N-001067 N-001068 N-001069 N-001070 N-001071 N-001072 N-001073 N-001074
// spec: N-001075 N-001076 N-001077 N-001078 N-001079 N-001080 N-001081 N-001082 N-001083
// spec: N-001084 N-001085 N-001086 N-001087 N-001088 N-001089 N-001090 N-001091 N-001092
// spec: N-001093 N-001094 N-001095 N-001096 N-001097 N-001098 N-001099 N-001100 N-001101
// spec: N-001102 N-000570 N-000571 N-000572 N-000573 N-000574 N-000385
const fs = require('fs');
const path = require('path');
const core = require('./lib/prosecheck-core.js');
const { statsReply } = require('./prosecheck-stats.js');

const SUB_LIST = 'lite, full, strict, off, on, status, show, check, doctor, stats, init, help';

// ---------------------------------------------------------------------------
// Replies
// ---------------------------------------------------------------------------

// spec: N-000457 N-000458 N-000459 N-000460 N-000461 N-000462 N-000463 N-000464 N-000465 N-000466 N-000467 N-000468 N-000469 N-000470 N-000471 N-000472 N-000473 N-000474 N-000475 N-000476 N-000477 N-000909 N-000910 N-000911 N-000912 N-000913 N-000914 N-000915 N-000916 N-000917 N-000918 N-000919 N-000920 N-000921 N-000922 N-000923 N-000924 N-000925 N-000926 N-000927 N-000928 N-000929 N-000930 N-000931 N-000932 N-000933 N-000934
// spec: N-000482 N-000483 N-000484 N-000485 N-000486 N-000487 N-000488 N-000489
function helpReply(level) {
  return [
    'prosecheck help: the live level is ' + level + '.',
    '',
    'Operator commands (each also works with the /prosecheck:prosecheck spelling):',
    '/prosecheck lite - the writing contract only, with no saved-file scoring.',
    '/prosecheck full - the contract plus the saved-file guard at threshold 40 (default).',
    '/prosecheck strict - the guard at threshold 20 and the cleanup scrub.',
    '/prosecheck off | on - off disables the tool; on re-enable turns it back on at full.',
    '/prosecheck status - one line with the stored level.',
    '/prosecheck show - the files scored or skipped in this session, newest first.',
    '/prosecheck check <path> - score one file; a report only, it does not rewrite the file.',
    '/prosecheck doctor - a health check of the install.',
    '/prosecheck stats - token figures for the session and the score of its own prose.',
    '/prosecheck init - writes the contract to AGENTS.md for agents other than Claude Code.',
    '',
    'Code, commits, config, and chat are always left alone; the contract never touches them.',
    'For a deep rewrite, ask in plain language with "prosecheck this" or "humanize this".',
  ].join('\n');
}

// spec: N-000471 N-000472 N-000473 N-000474 N-000475
function setLevelReply(word) {
  if (word === 'lite') {
    return 'prosecheck level set to lite: the writing contract is on; saved files are not scored.';
  }
  if (word === 'full') {
    return 'prosecheck level set to full: the writing contract is on and saved prose files are scored '
      + 'against threshold 40.';
  }
  return 'prosecheck level set to strict: the writing contract is on; saved prose files are scored against '
    + 'threshold 20 and the cleanup scrub is requested.';
}

// spec: N-001029 N-001030 N-001031 N-001032 N-001033 N-001034 N-001035 N-001036 N-001037 N-001038 N-001039 N-001040 N-001041 N-001042 N-001043 N-001044 N-001045 N-001046 N-001047 N-001048 N-001049 N-001050 N-001051 N-001052 N-001053 N-001054 N-001055 N-001056 N-001057 N-001058 N-001059 N-001060
// spec: N-000518 N-000519 N-000520 N-000521 N-000522 N-000523 N-000524 N-000525 N-000526 N-000527 N-000528
function showReply(sid) {
  const rows = core.listLedger(sid);
  if (!rows.length) {
    return 'nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf '
      + 'deliverables, are saved.';
  }
  const lines = ['Files in this session, newest first:'];
  for (const r of rows) {
    let body;
    if (r.status === 'scored') {
      body = r.phrase + ' (score ' + r.score + '/' + r.band
        + (r.truncated ? ', first ' + core.WINDOW_TEXT + ' characters only' : '') + ')';
      if (r.labels && r.labels.length) {
        body += ' - ' + (r.flagged ? 'flagged' : 'under threshold') + ': '
          + r.labels.slice(0, core.SHOW_LABEL_CAP).join('; ');
      }
    } else if (r.status === 'skipped') {
      body = 'not scored: over the ' + r.cap_kb + ' KB limit';
    } else if (r.status === 'binary') {
      body = 'not re-scored: binary format with no readable text';
    } else {
      body = 'not scored: ' + (r.reason || 'unknown reason');
    }
    lines.push((r.base || '?') + ' - ' + body);
  }
  return lines.join('\n');
}

// spec: N-000957 N-000958 N-000959 N-000960
function parsePathArg(raw) {
  let t = String(raw || '').trim();
  if (t.startsWith('@')) t = t.slice(1);
  if (t.length >= 2 && ((t[0] === '"' && t[t.length - 1] === '"') || (t[0] === "'" && t[t.length - 1] === "'"))) {
    t = t.slice(1, -1);
  }
  return t;
}

// spec: N-000952 N-000953 N-000954 N-000955 N-000956 N-000957 N-000958 N-000959 N-000960 N-000961 N-000962 N-000963 N-000964 N-000965 N-000966 N-000967 N-000968 N-000969 N-000970 N-000971 N-000972 N-000973 N-000974 N-000975 N-000976 N-000977 N-000978 N-000979 N-000980 N-000981 N-000982 N-000983 N-000984 N-000985 N-000986 N-000987 N-000988 N-000989 N-000990 N-000991 N-000992
// spec: N-000490 N-000491 N-000492 N-000493 N-000494 N-000495 N-000496 N-000556 N-000557 N-000558 N-000559 N-000560 N-000561 N-000562 N-000563 N-000564 N-000565 N-000566 N-000567 N-000568 N-000569
function checkReply(rawArg, cwd) {
  const typed = parsePathArg(rawArg);
  if (!typed) {
    return 'No file path was given. Usage: /prosecheck check <path>. No file was scored.';
  }
  const abs = path.resolve(cwd || process.cwd(), typed);
  const base = path.basename(abs);
  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    return 'cannot read ' + typed + ': no such file.';
  }
  if (!st.isFile()) return typed + ' is not a file.';
  const ext = path.extname(abs).toLowerCase();
  if (core.BINARY_EXT.includes(ext)) {
    return base + ': no readable text (' + ext + ' is not one of the supported formats).';
  }
  const isArchive = core.ARCHIVE_EXT.includes(ext);
  const cap = isArchive ? core.ARCHIVE_CAP_BYTES : core.PLAIN_CAP_BYTES;
  if (st.size > cap) {
    return base + ' is over ' + (cap / 1024) + ' KB and was not scored.';
  }
  const res = core.scoreFile(abs);
  switch (res.kind) {
    case 'nopython':
      return base + ': detector unavailable because Python cannot be found.';
    case 'missing':
      return base + ': detector unavailable because the bundled detector is missing.';
    case 'empty':
      return base + ': no report (the detector printed nothing).';
    case 'notreport':
      return 'no report: the detector output was not a report.';
    case 'noscore':
      return 'no report: the detector report had no numeric score.';
    case 'timeout':
      return base + ': failed because the detector timed out.';
    case 'failure': {
      const extra = res.stderr ? ' ' + res.stderr.split('\n').filter(Boolean).pop() : '';
      return base + ': failed (' + res.reason + ').' + extra;
    }
    default:
      break;
  }
  const phrase = core.hookPhrase(res.band);
  const lines = [base + ' - ' + phrase + ' (score ' + res.score + '/100, band: ' + res.band + ')'];
  let conf = 'confidence: ' + res.confidence;
  if (res.confidence !== 'high' && res.confidence_reason) conf += ' - ' + res.confidence_reason;
  lines.push(conf);
  if (res.truncated) lines.push('coverage: first ' + core.WINDOW_TEXT + ' characters only');
  const tells = res.tells.slice(0, core.CHECK_LABEL_CAP)
    .map((t) => t.label + ' (x' + t.count + ')');
  lines.push(tells.length ? 'tells: ' + tells.join('; ') : 'tells: none');
  lines.push('report only: this shows the score and does not rewrite the file.');
  return lines.join('\n');
}

// spec: N-001015 N-001016
function probeSettings() {
  const dir = core.configDir();
  try {
    fs.mkdirSync(dir, { recursive: true });
    const probe = path.join(dir, '.prosecheck-write-probe');
    fs.writeFileSync(probe, 'ok');
    fs.unlinkSync(probe);
    return true;
  } catch (e) {
    return false;
  }
}

// spec: N-000993 N-000994 N-000995 N-000996 N-000997 N-000998 N-000999 N-001000 N-001001 N-001002 N-001003 N-001004 N-001005 N-001006 N-001007 N-001008 N-001009 N-001010 N-001011 N-001012 N-001013 N-001014 N-001015 N-001016 N-001017 N-001018 N-001019 N-001020 N-001021 N-001022 N-001023 N-001024 N-001025 N-001026 N-001027 N-001028
// spec: N-000497 N-000498 N-000499 N-000500 N-000501 N-000502 N-000503 N-000504 N-000505 N-000506 N-000507 N-000508 N-000509 N-000510 N-000511 N-000512 N-000513 N-000514 N-000515 N-000516 N-000517
function doctorReply(level, form) {
  const modeOk = level !== 'off';
  const detector = core.detectorPath();
  const detectorOk = !!detector;

  let pythonOk = false;
  let pythonLine;
  if (!detectorOk) {
    pythonLine = 'python: not run because the bundled check is missing.';
  } else {
    const r = core.runPython([detector], { input: 'Doctor check sentence for the install.', timeout: 8000 });
    if (r.launchFailed) {
      pythonLine = 'python not found: saved files will not be re-scored until Python is available; '
        + 'the writing contract still shapes new prose.';
    } else {
      let numeric = false;
      if (!r.timedOut && r.status === 0) {
        try {
          const rep = JSON.parse(String(r.stdout).trim());
          numeric = !!(rep && rep._metrics && typeof rep._metrics.ai_tell_score === 'number');
        } catch (e) {
          numeric = false;
        }
      }
      pythonOk = numeric;
      pythonLine = numeric
        ? 'python: the bundled check ran and returned a numeric score [OK]'
        : 'python: the bundled check ran but did not return a numeric score.';
    }
  }
  const settingsOk = probeSettings();

  const modeLine = modeOk
    ? 'mode: ' + level + ' [OK]'
    : 'mode: off, which is not a fault of the install; run /prosecheck on to turn it back on.';
  const detectorLine = detectorOk
    ? 'detector: the bundled detector is present in the plugin tree [OK]'
    : 'detector: the bundled detector is missing from the plugin tree.';
  const settingsLine = settingsOk
    ? 'settings: the config folder is writable [OK]'
    : 'settings: the config folder is not writable.';

  const others = detectorOk && pythonOk && settingsOk;
  let closer;
  if (others && modeOk) {
    closer = 'prosecheck is active. Plain text up to 512 KB and archives up to 4 MB are scored, the first '
      + core.WINDOW_TEXT + ' characters are read, and partly scanned or skipped files are listed by '
      + form + ' show.';
  } else if (others && !modeOk) {
    closer = 'The install is healthy. While it is off, saving files is not scored; run ' + form
      + ' on to turn scoring back on.';
  } else {
    closer = 'Please fix the faulty checks above, then run /prosecheck doctor again.';
  }
  return [
    'prosecheck doctor',
    modeLine,
    detectorLine,
    pythonLine,
    settingsLine,
    closer,
  ].join('\n');
}

// spec: N-001061 N-001062 N-001063 N-001064 N-001065 N-001066 N-001067 N-001068 N-001069 N-001070 N-001071 N-001072 N-001073 N-001074 N-001075 N-001076 N-001077 N-001078 N-001079 N-001080 N-001081 N-001082 N-001083 N-001084 N-001085 N-001086 N-001087 N-001088 N-001089 N-001090 N-001091 N-001092 N-001093 N-001094 N-001095 N-001096 N-001097 N-001098 N-001099 N-001100 N-001101 N-001102
// spec: N-000529 N-000530 N-000531 N-000532 N-000533 N-000534 N-000535 N-000536 N-000537 N-000538 N-000539 N-000540 N-000541 N-000542 N-000570 N-000571 N-000572 N-000573
function initReply(level, form, cwd) {
  if (level === 'off') {
    return 'prosecheck is switched off, so no files were written. Run ' + form + ' on to allow the export.';
  }
  const lines = [];
  const base = cwd || process.cwd();
  const agents = path.join(base, 'AGENTS.md');
  let existing = null;
  let readable = true;
  try {
    existing = fs.readFileSync(agents, 'utf8');
  } catch (e) {
    if (e.code !== 'ENOENT') readable = false;
  }
  if (!readable) {
    lines.push('cannot read AGENTS.md, so the contract was not written to it.');
  } else if (existing !== null && existing.includes(core.CONTRACT_MARKER_BEGIN)) {
    lines.push('AGENTS.md already has the writing contract; it was left unchanged.');
  } else {
    try {
      let next = existing === null ? '' : existing;
      if (next && !next.endsWith('\n')) next += '\n';
      if (next) next += '\n';
      next += core.exportedContract(level);
      fs.writeFileSync(agents, next);
      lines.push('AGENTS.md: the writing contract was added.');
    } catch (e) {
      lines.push('cannot write AGENTS.md, so the contract was not added.');
    }
  }

  const ruleDir = path.join(base, '.cursor', 'rules');
  const ruleFile = path.join(ruleDir, 'prosecheck.mdc');
  if (fs.existsSync(ruleFile)) {
    lines.push('prosecheck.mdc already exists in .cursor/rules; it was left unchanged.');
  } else {
    try {
      const shipped = path.join(core.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
      const body = fs.readFileSync(shipped, 'utf8');
      fs.mkdirSync(ruleDir, { recursive: true });
      fs.writeFileSync(ruleFile, body);
      lines.push('.cursor/rules/prosecheck.mdc: the Cursor rule was written.');
    } catch (e) {
      lines.push('cannot write .cursor/rules/prosecheck.mdc, so the Cursor rule was not created.');
    }
  }
  return lines.join('\n');
}

function unknownReply(word) {
  return 'unknown subcommand "' + word + '". Valid subcommands: ' + SUB_LIST + '. The stored level is unchanged.';
}

// ---------------------------------------------------------------------------
// Routing
// ---------------------------------------------------------------------------

function block(reason) {
  return JSON.stringify({ decision: 'block', reason: reason }) + '\n';
}

// spec: N-000847 N-000848 N-000849 N-000850 N-000851 N-000852 N-000853 N-000854 N-000855 N-000856 N-000870 N-000871 N-000872 N-000873 N-000874 N-000875 N-000876 N-000877 N-000878 N-000879 N-000880 N-000881 N-000882 N-000883 N-000884 N-000885 N-000886 N-000887 N-000888 N-000889 N-000890 N-000891 N-000892
// spec: N-000893 N-000894 N-000895 N-000896 N-000897 N-000898 N-000899 N-000900 N-000901 N-000902 N-000903 N-000574 N-000575 N-000576 N-000577
function route(input) {
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const trimmed = prompt.trim();
  const lower = trimmed.toLowerCase();
  const sid = input.session_id;
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();

  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    core.writeLevel('off');
    return block('prosecheck is off. Nothing is scored and no contract is added until you run /prosecheck on.');
  }

  const m = /^\/prosecheck(?::prosecheck)?(?=\s|$)/i.exec(trimmed);
  if (!m) {
    const level = core.effectiveLevel();
    if (level === 'off') return '';
    const reminder = 'prosecheck is ' + level + '. Prose deliverables in this reply follow the writing contract; '
      + 'code, config, and commits are untouched.';
    return JSON.stringify({
      hookSpecificOutput: { hookEventName: 'UserPromptSubmit', additionalContext: reminder },
    }) + '\n';
  }

  const form = m[0].toLowerCase() === '/prosecheck:prosecheck' ? '/prosecheck:prosecheck' : '/prosecheck';
  const rest = trimmed.slice(m[0].length).trim();
  const parts = rest.split(/\s+/);
  const word = (parts[0] || '').toLowerCase();
  const arg = rest.slice(parts[0] ? parts[0].length : 0).trim();
  const level = core.effectiveLevel();

  if (!word || word === 'help') return block(helpReply(level));
  if (word === 'lite' || word === 'full' || word === 'strict') {
    core.writeLevel(word);
    return block(setLevelReply(word));
  }
  if (word === 'off') {
    core.writeLevel('off');
    return block('prosecheck is switched off. Nothing is scored and no contract is added. Run '
      + form + ' on to switch it back on.');
  }
  if (word === 'on') {
    core.writeLevel('full');
    return block('prosecheck is on (full): the writing contract is active and saved prose files are scored.');
  }
  if (word === 'status') {
    return block('prosecheck status: ' + level + '.');
  }
  if (word === 'show') return block(showReply(sid));
  if (word === 'check') return block(checkReply(arg, cwd));
  if (word === 'doctor') return block(doctorReply(level, form));
  if (word === 'stats') return block(statsReply(input.transcript_path, level));
  if (word === 'init') return block(initReply(level, form, cwd));
  return block(unknownReply(parts[0]));
}

function main() {
  const input = core.readStdinJson();
  const out = route(input);
  if (out) process.stdout.write(out);
}

try {
  main();
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
