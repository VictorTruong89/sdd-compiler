#!/usr/bin/env node
'use strict';
// Session-start hook: emits the writing contract for the live level (plain text).
// spec: N-000788 N-000789 N-000790 N-000791 N-000792 N-000793 N-000794 N-000370 N-000371
// spec: N-000379 N-000386 N-000387 N-000388 N-000730
const fs = require('fs');
const core = require('./lib/prosecheck-core.js');

// spec: N-000332 N-000333 N-000334 N-000335 N-000336 N-000337 N-000379 N-000788 N-000789 N-000790 N-000791 N-000792 N-000793 N-000794 N-000386 N-000387 N-000388 N-000389 N-000390 N-000391 N-000392 N-000393 N-000394
function main() {
  core.readStdinJson();
  const level = core.effectiveLevel();
  let out = '';
  if (level !== 'off') {
    const firstStart = !fs.existsSync(core.flagPath());
    if (firstStart) core.writeLevel(level);
    const parts = [];
    if (firstStart) parts.push(core.WELCOME);
    parts.push(core.contractText(level));
    out = parts.join('\n\n') + '\n';
  }
  core.purgeOldLedgers();
  process.stdout.write(out);
}

try {
  main();
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
