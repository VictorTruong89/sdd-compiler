#!/usr/bin/env node
'use strict';
// Post-tool-use hook (saved-file guard). Scores just-saved prose files and nudges
// when a file is flagged. Always exits 0; malformed input is an empty object.
// spec: N-000819 N-000820 N-000821 N-000822 N-000823 N-000824 N-000825 N-000826
// spec: N-000827 N-000828 N-000829 N-000830 N-000831 N-000832 N-000833 N-000834 N-000835
// spec: N-000395 N-000396 N-000397 N-000398 N-000399 N-000400 N-000401
// spec: N-000402 N-000403 N-000404 N-000405 N-000406 N-000407 N-000408
// spec: N-000409 N-000410 N-000411 N-000412 N-000413 N-000414 N-000415 N-000416 N-000417
// spec: N-000418 N-000419 N-000420 N-000421 N-000422 N-000423 N-000424 N-000425 N-000426 N-000427 N-000428
// spec: N-000431 N-000432 N-000433 N-000434 N-000435 N-000436 N-000437
// spec: N-000442 N-000443 N-000444 N-000445 N-000446 N-000447 N-000448 N-000449 N-000450
// spec: N-000451 N-000452 N-000453 N-000454 N-000455 N-000456
const fs = require('fs');
const path = require('path');
const core = require('./lib/prosecheck-core.js');

// spec: N-000863
function parsePatchPaths(body) {
  const out = [];
  for (const line of String(body).split('\n')) {
    const m = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/.exec(line.replace(/\r$/, ''));
    if (m) {
      const p = m[1].trim();
      if (p) out.push(p);
    }
  }
  return out;
}

// spec: N-000837 N-000838 N-000839 N-000840 N-000841 N-000842 N-000843 N-000844 N-000845 N-000846 N-000857 N-000858 N-000859 N-000860 N-000861 N-000862 N-000863 N-000864 N-000865 N-000866 N-000867 N-000868 N-000869
// spec: N-000836
function collectPaths(input) {
  const ti = input.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  const paths = [];
  if (typeof ti.file_path === 'string' && ti.file_path.trim()) paths.push(ti.file_path.trim());
  if (typeof ti.notebook_path === 'string' && ti.notebook_path.trim()) paths.push(ti.notebook_path.trim());
  if (typeof ti.command === 'string') paths.push(...parsePatchPaths(ti.command));
  return paths;
}

function isSkippedLocation(abs, root) {
  const segs = abs.split(path.sep);
  if (segs.includes('node_modules') || segs.includes('.git')) return true;
  const rel = path.relative(root, abs);
  if (rel && !rel.startsWith('..') && !path.isAbsolute(rel)) return true;
  return false;
}

function isInstructionFile(base) {
  const lower = base.toLowerCase();
  if (core.INSTRUCTION_NAMES.has(lower)) return true;
  const ext = path.extname(lower);
  const stem = ext ? lower.slice(0, -ext.length) : lower;
  if (core.INSTRUCTION_STEMS.has(stem) && (!ext || !core.PROSE_EXT.includes(ext))) return true;
  return false;
}

function capKb(ext) {
  return core.ARCHIVE_EXT.includes(ext) ? core.ARCHIVE_CAP_BYTES / 1024 : core.PLAIN_CAP_BYTES / 1024;
}

// spec: N-000430 N-000440 N-000441
function nudgeLine(base, res) {
  const cover = res.truncated ? ', first ' + core.WINDOW_TEXT + ' characters only' : '';
  const labels = res.labels.slice(0, core.SHOW_LABEL_CAP).join('; ');
  return 'prosecheck: ' + base + ' ' + core.hookPhrase(res.band) + ' (score ' + res.score + ', band '
    + res.band + cover + '). Flagged: ' + labels + '. Fix the flagged spans in ' + base + '.';
}

// spec: N-000730
function main() {
  const input = core.readStdinJson();
  const level = core.effectiveLevel();
  if (level === 'off' || level === 'lite') return;
  const threshold = core.THRESHOLD[level];
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const sid = input.session_id;
  const root = core.pluginRoot();

  let paths = collectPaths(input);
  const seen = new Set();
  const unique = [];
  for (const p of paths) {
    const abs = path.resolve(cwd, p);
    if (!seen.has(abs)) {
      seen.add(abs);
      unique.push(abs);
    }
  }
  const capped = unique.slice(0, core.PATCH_PATH_CAP);
  const nudges = [];

  for (const abs of capped) {
    const base = path.basename(abs);
    const ext = path.extname(abs).toLowerCase();
    if (isSkippedLocation(abs, root)) continue;
    if (isInstructionFile(base)) continue;
    const eligible = core.PROSE_EXT.includes(ext);
    const binary = core.BINARY_EXT.includes(ext);
    if (!eligible && !binary) continue;

    let st = null;
    try {
      st = fs.statSync(abs);
    } catch (e) {
      st = null;
    }
    if (!st) {
      core.appendLedger(sid, { base: base, status: 'failed', reason: 'cannot read: not on disk' });
      continue;
    }
    if (st.isDirectory() || !st.isFile()) continue;
    if (binary) {
      core.appendLedger(sid, { base: base, status: 'binary' });
      continue;
    }
    const cap = core.ARCHIVE_EXT.includes(ext) ? core.ARCHIVE_CAP_BYTES : core.PLAIN_CAP_BYTES;
    if (st.size > cap) {
      core.appendLedger(sid, { base: base, status: 'skipped', cap_kb: cap / 1024 });
      continue;
    }
    const res = core.scoreFile(abs);
    if (res.kind !== 'scored') {
      core.appendLedger(sid, { base: base, status: 'failed', reason: res.reason });
      continue;
    }
    const flagged = res.score > threshold;
    core.appendLedger(sid, {
      base: base, status: 'scored', score: res.score, band: res.band,
      phrase: core.hookPhrase(res.band), labels: res.labels.slice(0, core.SHOW_LABEL_CAP),
      flagged: flagged, truncated: res.truncated,
    });
    if (flagged) nudges.push(nudgeLine(base, res));
  }

  if (nudges.length) {
    const envelope = {
      hookSpecificOutput: {
        hookEventName: 'PostToolUse',
        additionalContext: nudges.join('\n'),
      },
    };
    process.stdout.write(JSON.stringify(envelope) + '\n');
  }
}

try {
  main();
} catch (e) {
  // never fail the host session
}
process.exitCode = 0;
