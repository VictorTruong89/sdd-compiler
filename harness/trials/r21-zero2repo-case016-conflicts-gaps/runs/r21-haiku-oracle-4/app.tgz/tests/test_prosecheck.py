"""Tests for the prosecheck detector and plugin hooks (standard library only).

Run from /app:  python3 -m unittest discover -s tests -v
"""
import json
import os
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, 'scripts'))
import detect  # noqa: E402

DETECT = os.path.join(ROOT, 'scripts', 'detect.py')
HOOKS = os.path.join(ROOT, 'hooks')


def run_detect(args=(), data=None):
    p = subprocess.run([sys.executable, DETECT] + list(args),
                       input=None if data is None else data.encode('utf-8'),
                       capture_output=True)
    return p.returncode, p.stdout.decode('utf-8'), p.stderr.decode('utf-8')


def run_hook(name, payload, env=None):
    e = dict(os.environ)
    e.update(env or {})
    p = subprocess.run(['node', os.path.join(HOOKS, name)], input=json.dumps(payload).encode('utf-8'),
                       capture_output=True, env=e)
    return p.returncode, p.stdout.decode('utf-8')


class DetectorCliTests(unittest.TestCase):
    def test_help_prints_usage_and_succeeds(self):
        rc, out, _ = run_detect(['--help'])
        self.assertEqual(rc, 0)
        self.assertEqual(out.splitlines()[0], 'usage: detect.py [--clean] [--ci] [--] [FILE]')

    def test_unknown_option_exit_2_with_json_error(self):
        rc, out, err = run_detect(['--nope'])
        self.assertEqual(rc, 2)
        self.assertEqual(out, '')
        self.assertIn('unknown option', json.loads(err.strip().splitlines()[-1])['error'])

    def test_empty_input_exit_1(self):
        rc, out, err = run_detect([], '  \n\t\n')
        self.assertEqual(rc, 1)
        self.assertEqual(json.loads(err.strip().splitlines()[-1]), {'error': 'empty input'})

    def test_report_has_metrics_and_bands(self):
        rc, out, _ = run_detect([], 'A plain sentence about a bus ride to town. It was late.')
        self.assertEqual(rc, 0)
        m = json.loads(out)['_metrics']
        self.assertIn(m['ai_tell_band'], ['clean', 'light tells', 'mixed', 'heavy tells', 'pervasive tells'])
        self.assertIn(m['confidence'], ['none', 'low', 'moderate', 'high'])

    def test_double_dash_allows_dash_file_name(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, '-notes.md')
            with open(path, 'w', encoding='utf-8') as fh:
                fh.write('Some prose here about the weather.\n')
            rc, out, _ = run_detect(['--', path])
            self.assertEqual(rc, 0)
            self.assertIn('_metrics', json.loads(out))

    def test_window_is_262144_characters(self):
        rc, out, _ = run_detect([], 'a' * 262145)
        m = json.loads(out)['_metrics']
        self.assertTrue(m['truncated'])
        self.assertEqual(m['scanned_chars'], 262144)

    def test_exclusions_hide_code_fences(self):
        text = 'Intro.\n```\nDelve into the tapestry, it is crucial.\n```\nEnd.\n'
        report = detect.analyze(text)
        self.assertFalse([k for k in report if k != '_metrics'])
        report = detect.analyze('Intro.\nDelve into the tapestry.\n')
        self.assertIn('1_ai_vocabulary', report)

    def test_decisive_family_needs_confidence_for_45_floor(self):
        self.assertEqual(detect.score_from([{'key': '62', 'num': 62, 'advice': False, 'decisive': True,
                                             'count': 1}], 200)[0], 16)
        self.assertEqual(detect.score_from([{'key': '62', 'num': 62, 'advice': False, 'decisive': True,
                                             'count': 1}], 400)[0], 45)

    def test_two_decisive_families_floor_65(self):
        fams = [{'key': '62', 'num': 62, 'advice': False, 'decisive': True, 'count': 1},
                {'key': '63', 'num': 63, 'advice': False, 'decisive': True, 'count': 1}]
        self.assertEqual(detect.score_from(fams, 50)[0], 65)

    def test_rhythm_only_scores_clean(self):
        fams = [{'key': '40', 'num': 40, 'advice': False, 'decisive': False, 'count': 1}]
        self.assertLessEqual(detect.score_from(fams, 400)[0], 20)


class CleanupTests(unittest.TestCase):
    def test_N_000305_cleanup_leaves_zero_invisible_hits(self):
        text = 'Cafe​​ is open.⁠ Tags\U000e0041 here.\n'
        rc, cleaned, _ = run_detect(['--clean'], text)
        self.assertEqual(rc, 0)
        rc, out, _ = run_detect([], cleaned)
        self.assertEqual(json.loads(out)['_metrics']['invisible_chars'], 0)

    def test_N_000309_cleanup_leaves_zero_nonstandard_space_hits(self):
        text = 'Two words and a wide gap, also　ideographic.\n'
        rc, cleaned, _ = run_detect(['--clean'], text)
        self.assertEqual(rc, 0)
        rc, out, _ = run_detect([], cleaned)
        self.assertEqual(json.loads(out)['_metrics']['nonstandard_spaces'], 0)

    def test_nbsp_holding_digits_is_kept(self):
        rc, cleaned, _ = run_detect(['--clean'], 'Price 5 %.\n')
        self.assertIn(' %', cleaned)

    def test_trailing_whitespace_removed_and_one_newline_restored(self):
        rc, cleaned, _ = run_detect(['--clean'], 'Line one.   \nLine two.\t\n\n\n')
        self.assertEqual(cleaned, 'Line one.\nLine two.\n')


class ArchiveTests(unittest.TestCase):
    def test_docx_text_extracted_without_markup(self):
        import zipfile
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, 'a.docx')
            with zipfile.ZipFile(path, 'w') as zf:
                zf.writestr('word/document.xml',
                            '<w:document xmlns:w="urn:w"><w:body><w:p><w:r><w:t>Hello docx.</w:t></w:r>'
                            '</w:p><w:p><w:r><w:t>Second.</w:t></w:r></w:p></w:body></w:document>')
            rc, out, _ = run_detect(['--clean', path])
            self.assertEqual(rc, 0)
            self.assertEqual(out, 'Hello docx.\nSecond.')

    def test_pdf_is_empty_input(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, 'x.pdf')
            with open(path, 'wb') as fh:
                fh.write(b'%PDF-1.4')
            rc, _, err = run_detect([path])
            self.assertEqual(rc, 1)
            self.assertEqual(json.loads(err.strip().splitlines()[-1])['error'], 'empty input')


class HookTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.env = {'CLAUDE_CONFIG_DIR': self._tmp.name}

    def tearDown(self):
        self._tmp.cleanup()

    def test_session_start_welcome_once(self):
        _, first = run_hook('prosecheck-activate.js', {}, self.env)
        _, second = run_hook('prosecheck-activate.js', {}, self.env)
        self.assertIn('shown once', first)
        self.assertNotIn('shown once', second)
        self.assertIn('# Writing contract', second)

    def test_off_level_emits_nothing(self):
        run_hook('prosecheck-tracker.js', {'prompt': '/prosecheck off'}, self.env)
        _, out = run_hook('prosecheck-activate.js', {}, self.env)
        self.assertEqual(out, '')

    def test_lite_contract_has_no_threshold(self):
        run_hook('prosecheck-tracker.js', {'prompt': '/prosecheck lite'}, self.env)
        _, out = run_hook('prosecheck-activate.js', {}, self.env)
        self.assertNotIn('light tells', out)
        self.assertNotIn('at most 40', out)

    def test_command_is_blocked_and_reply_has_help(self):
        _, out = run_hook('prosecheck-tracker.js', {'prompt': '/prosecheck:prosecheck'}, self.env)
        reply = json.loads(out)
        self.assertEqual(reply['decision'], 'block')
        self.assertIn('/prosecheck doctor', reply['reason'])

    def test_unknown_subcommand_keeps_level(self):
        run_hook('prosecheck-tracker.js', {'prompt': '/prosecheck strict'}, self.env)
        _, out = run_hook('prosecheck-tracker.js', {'prompt': '/prosecheck bogus'}, self.env)
        self.assertIn('unknown', json.loads(out)['reason'])
        with open(os.path.join(self._tmp.name, '.prosecheck-active')) as fh:
            self.assertEqual(fh.read(), 'strict')

    def test_guard_nudges_flagged_prose_only(self):
        prose = os.path.join(self._tmp.name, 'essay.md')
        with open(prose, 'w', encoding='utf-8') as fh:
            fh.write('Delve into the tapestry of this robust framework. Moreover, it is crucial. '
                     'Furthermore, it leverages seamless integration. I hope this helps.\n')
        _, out = run_hook('prosecheck-guard.js', {'tool_name': 'Write',
                                                  'tool_input': {'file_path': prose}}, self.env)
        ctx = json.loads(out)['hookSpecificOutput']['additionalContext']
        self.assertIn('essay.md', ctx)
        self.assertIn('fix', ctx.lower())
        code = os.path.join(self._tmp.name, 'code.py')
        with open(code, 'w', encoding='utf-8') as fh:
            fh.write('x = 1\n')
        _, out = run_hook('prosecheck-guard.js', {'tool_name': 'Write',
                                                  'tool_input': {'file_path': code}}, self.env)
        self.assertEqual(out, '')


if __name__ == '__main__':
    unittest.main()
