const core = require(require('path').join(__dirname, '..', 'hooks', 'lib', 'prosecheck-core.js'));
const fs = require('fs');
const assert = require('assert');
const has = (s, re) => re.test(s);
const lvl = {};
for (const l of ['lite', 'full', 'strict']) lvl[l] = core.contractText(l);
const exp = {};
for (const l of ['lite', 'full', 'strict']) exp[l] = core.exportedContract(l);
// live contract
assert(has(lvl.full, /(?<![\d.])40(?![\d])/), 'full has 40');
assert(/\bclean\b|light tells/.test(lvl.full) && lvl.full.includes('light tells'));
assert(!lvl.full.includes('--clean'), 'full no --clean');
assert(/(?<![\d.])20(?![\d])/.test(lvl.strict) && lvl.strict.includes('--clean'));
assert(!/(?<![\d.])40(?![\d])/.test(lvl.lite) && !lvl.lite.includes('light tells'), 'lite');
// banned words standalone
const banned = 'delve tapestry pivotal crucial leverage robust seamless foster underscore showcase landscape journey realm multifaceted holistic testament vibrant comprehensive plethora myriad boast elevate empower unlock game-changer supercharge genuinely fascinating nuanced'.split(' ');
for (const b of banned) assert(new RegExp('(^|[^A-Za-z-])' + b + '([^A-Za-z-]|$)', 'i').test(lvl.lite), 'banned ' + b);
// source code sentences
for (const l of Object.keys(lvl)) {
  const sents = lvl[l].split(/(?<=[.!?])\s+|\n/);
  for (const s of sents) {
    if (/source[ -]code/i.test(s)) assert(/\b(never|not)\b/i.test(s.slice(0, s.search(/source[ -]code/i))), l + ': ' + s);
  }
}
// exports
const lines = (s) => s.split('\n');
const pr = (s) => lines(s).filter((l) => l.includes('CLAUDE_PLUGIN_ROOT'));
assert(!/skills|plugins|CLAUDE_PLUGIN_ROOT/.test(exp.lite), 'lite export');
assert(!/(?<![\d.])40(?![\d])/.test(exp.lite) && !exp.lite.includes('light tells'), 'lite export numbers');
assert(pr(exp.full).length === 1 && /\bskills\b/.test(pr(exp.full)[0]) && /\bplugins\b/.test(pr(exp.full)[0]), 'full export line');
assert(pr(exp.strict).length === 1, 'strict export line');
assert(!exp.full.includes('--clean'), 'full export no --clean');
assert(exp.strict.includes('--clean') && /\bclean\b/.test(exp.strict));
assert(!exp.lite.includes('--clean'));
assert(!exp.full.includes(process.env.HOME || '/root'));
assert(exp.full.includes('scripts/detect.py'));
// cursor rule
const mdc = fs.readFileSync(require('path').join(__dirname, '..', '.cursor', 'rules', 'prosecheck.mdc'), 'utf8');
const fm = mdc.split('---')[1];
assert(fm.includes('globs: *.md,*.mdx,*.markdown,*.txt,*.rst,*.tex,*.org,*.adoc'));
assert(!/\*\.(py|js|ts|json)\b/.test(fm));
assert(mdc.includes('prose deliverables only'));
assert(!/detect/i.test(mdc) && !mdc.includes('light tells') && !/(?<![\d.])40(?![\d])/.test(mdc));
// welcome
for (const t of ['71', '512 KB', '4 MB', '262,144', '/prosecheck doctor', '/prosecheck check', '/prosecheck off', '/prosecheck help']) assert(core.WELCOME.includes(t), 'welcome ' + t);
console.log('contract checks passed');
