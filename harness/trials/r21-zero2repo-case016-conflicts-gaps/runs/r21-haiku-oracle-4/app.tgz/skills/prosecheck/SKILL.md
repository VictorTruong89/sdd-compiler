---
name: prosecheck
description: Rewrite prose flagged by prosecheck when the user asks to "prosecheck this" or "humanize this". Use only for prose deliverables.
---

# prosecheck rewrite guidance

This skill tells the host agent how to rewrite prose that the prosecheck detector flagged. The detector only reports; the rewrite is done by the host agent.

1. Scope: prose deliverables only (documents, README prose, CVs, cover letters, emails, reports, essays, articles). Never rewrite source code, code comments, commit messages, configuration, CLI output, logs, or chat replies.
2. Run the bundled detector on the file: `python3 scripts/detect.py <file>` from the plugin root, or `skills/prosecheck/scripts/detect.py` when only the skill is installed.
3. Fix only the flagged spans. Keep the facts, numbers, names, quotations, and citations exactly as written.
4. Keep the rhythm varied. Do not replace one banned pattern with another.
5. Stay silent about the process: do not mention the detector, the score, or the pattern list in the rewritten prose.
6. Re-run the detector once after the rewrite. Stop after two passes.
