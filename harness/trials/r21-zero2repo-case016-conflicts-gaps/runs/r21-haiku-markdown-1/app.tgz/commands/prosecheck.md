---
description: prosecheck operator commands: levels, check, doctor, show, stats, init, help
argument-hint: [lite|full|strict|off|on|status|show|check <path>|doctor|stats|init|help]
---
/prosecheck $ARGUMENTS
