---
name: prosecheck
description: Rewrite flagged prose when the user asks to "prosecheck this" or "humanize this". Used by the host agent; the detector never rewrites text.
---

# prosecheck rewrite

Use this only when the user asks in plain language, with "prosecheck this" or "humanize this", for a deep rewrite of a prose deliverable.

1. Run the bundled detector on the file: `python3 scripts/detect.py FILE` from the plugin root (or `skills/prosecheck/scripts/detect.py`). Read the JSON report; each member names a pattern, its count, and up to three samples.
2. Rewrite only the flagged spans. Keep numbers, units, dates, proper nouns, citations, quotations, and technical terms exactly. Never invent facts.
3. Keep the rhythm varied; do not replace one metronome with another.
4. Do not touch code, configuration, commit messages, or chat replies. Do not report the score or the pattern list to the user unless they ask.
5. Re-run the detector once to confirm. Stop after two passes.
