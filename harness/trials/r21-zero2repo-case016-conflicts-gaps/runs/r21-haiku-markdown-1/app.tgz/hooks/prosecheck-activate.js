#!/usr/bin/env node
'use strict';
// Session-start hook: prints the welcome (first start only) and the writing contract.
const fs = require('fs');
const core = require('./lib/core');

function main() {
  core.readStdinJson();
  const flagExists = fs.existsSync(core.modeFile());
  const envLevel = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  const envSet = core.validLevel(envLevel);
  if (!flagExists && !envSet) {
    core.setStoredLevel('full');
  }
  core.pruneLedgers();
  const level = core.effectiveLevel();
  if (level === 'off') return '';
  const parts = [];
  if (!flagExists) parts.push(core.WELCOME);
  parts.push(core.contractFor(level));
  return parts.join('\n\n') + '\n';
}

try {
  const text = main();
  if (text) process.stdout.write(text);
} catch (_) {
  /* a hook never fails the host session */
}
process.exitCode = 0;
