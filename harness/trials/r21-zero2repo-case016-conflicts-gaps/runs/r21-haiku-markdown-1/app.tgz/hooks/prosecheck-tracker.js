#!/usr/bin/env node
'use strict';
// Prompt-submit hook and /prosecheck command router.
const core = require('./lib/core');
const cmd = require('./lib/commands');

function block(reason) {
  return JSON.stringify({ decision: 'block', reason });
}

function route(input, root) {
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const trimmed = prompt.trim();
  const lower = trimmed.toLowerCase();
  const sid = typeof input.session_id === 'string' ? input.session_id : '';

  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    core.setStoredLevel('off');
    return block(cmd.setReply('off'));
  }

  const m = trimmed.match(/^\/prosecheck(?::prosecheck)?(?:\s+([\s\S]*))?$/i);
  if (m) {
    const form = core.formOf(trimmed);
    const rest = (m[1] || '').trim();
    const spaceAt = rest.search(/\s/);
    const sub = (spaceAt === -1 ? rest : rest.slice(0, spaceAt)).toLowerCase();
    const arg = spaceAt === -1 ? '' : rest.slice(spaceAt).trim();
    const level = core.effectiveLevel();
    switch (sub) {
      case '':
      case 'help':
        return block(cmd.helpReply(level, form));
      case 'lite':
      case 'full':
      case 'strict':
        core.setStoredLevel(sub);
        return block(cmd.setReply(sub));
      case 'off':
        core.setStoredLevel('off');
        return block(cmd.setReply('off'));
      case 'on':
        core.setStoredLevel('full');
        return block(cmd.setReply('on'));
      case 'status':
        return block(cmd.statusReply(level));
      case 'show':
        return block(cmd.showReply(sid));
      case 'check':
        return block(cmd.checkReply(arg, input.cwd, root));
      case 'doctor':
        return block(cmd.doctorReply(form, root));
      case 'stats':
        return block(cmd.statsReply(input, root, level));
      case 'init':
        return block(cmd.initReply(form, input.cwd, root));
      default:
        return block(cmd.unknownReply(sub));
    }
  }

  const level = core.effectiveLevel();
  if (level === 'off') return null;
  return JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: 'prosecheck (level: ' + level + '): prose deliverables follow the writing contract; ' +
        'code, config, and commits are untouched.',
    },
  });
}

try {
  const input = core.readStdinJson();
  const root = core.pluginRoot(__dirname);
  const out = route(input, root);
  if (out) process.stdout.write(out);
} catch (_) {
  /* never fail the host */
}
process.exitCode = 0;
