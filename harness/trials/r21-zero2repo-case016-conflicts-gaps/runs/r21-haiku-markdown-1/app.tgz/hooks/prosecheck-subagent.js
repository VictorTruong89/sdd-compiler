#!/usr/bin/env node
'use strict';
// Subagent-start hook: returns the same writing contract inside the hook envelope.
const core = require('./lib/core');

try {
  core.readStdinJson();
  const level = core.effectiveLevel();
  if (level !== 'off') {
    const out = {
      hookSpecificOutput: {
        hookEventName: 'SubagentStart',
        additionalContext: core.contractFor(level),
      },
    };
    process.stdout.write(JSON.stringify(out));
  }
} catch (_) {
  /* never fail the host */
}
process.exitCode = 0;
