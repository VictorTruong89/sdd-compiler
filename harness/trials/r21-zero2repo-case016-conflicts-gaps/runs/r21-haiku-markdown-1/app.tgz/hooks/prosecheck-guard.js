#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when it is flagged.
const fs = require('fs');
const path = require('path');
const core = require('./lib/core');

const MAX_PATHS = 16;
const INSTRUCTION_EXACT = new Set(['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md']);
const INSTRUCTION_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];
const ASK = 'Please fix the flagged spans in this file, keeping its meaning and rhythm.';

function isInstructionFile(base) {
  const n = base.toLowerCase();
  if (INSTRUCTION_EXACT.has(n)) return true;
  for (const stem of INSTRUCTION_STEMS) {
    if (n === stem) return true;
    if (n.startsWith(stem + '.')) {
      const ext = n.slice(stem.length);
      if (!core.PLAIN_EXTS.includes(ext)) return true;
    }
  }
  return false;
}

function isUnder(root, abs) {
  const rel = path.relative(root, abs);
  return rel !== '' && !rel.startsWith('..') && !path.isAbsolute(rel);
}

function pathsFromInput(input) {
  const tool = typeof input.tool_name === 'string' ? input.tool_name.toLowerCase() : '';
  const ti = input.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  const found = [];
  if (tool.includes('apply_patch')) {
    const body = typeof ti.command === 'string' ? ti.command : '';
    const re = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/gm;
    let m;
    while ((m = re.exec(body)) !== null) {
      const p = m[1].trim();
      if (p) found.push(p);
    }
    return found;
  }
  if (tool === 'notebookedit') {
    const p = typeof ti.notebook_path === 'string' ? ti.notebook_path : (typeof ti.file_path === 'string' ? ti.file_path : '');
    if (p.trim()) found.push(p.trim());
    return found;
  }
  const p = typeof ti.file_path === 'string' ? ti.file_path : (typeof input.file_path === 'string' ? input.file_path : '');
  if (p.trim()) found.push(p.trim());
  return found;
}

function record(sid, rec) {
  core.appendLedger(sid, Object.assign({ time: Date.now() }, rec));
}

function main() {
  const input = core.readStdinJson();
  const level = core.effectiveLevel();
  if (level === 'off' || level === 'lite') return '';
  const threshold = core.THRESHOLD[level];
  const root = core.pluginRoot(__dirname);
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const sid = typeof input.session_id === 'string' ? input.session_id : '';

  const raw = pathsFromInput(input);
  if (!raw.length) return '';
  const unique = [];
  for (const p of raw) if (!unique.includes(p)) unique.push(p);

  const lines = [];
  for (const p of unique.slice(0, MAX_PATHS)) {
    const abs = path.resolve(cwd, p);
    const base = path.basename(abs);
    const segments = abs.split(/[\\/]+/);
    if (segments.includes('node_modules') || segments.includes('.git')) continue;
    if (isUnder(root, abs)) continue;
    if (isInstructionFile(base)) continue;

    const ext = path.extname(abs).toLowerCase();
    if (ext === '.pdf' || ext === '.rtf') {
      record(sid, { base, kind: 'binary', ext });
      continue;
    }
    if (!core.PLAIN_EXTS.includes(ext) && !core.ARCHIVE_EXTS.includes(ext)) continue;

    let st;
    try {
      st = fs.statSync(abs);
    } catch (_) {
      record(sid, { base, kind: 'failed', reason: 'the file could not be read (not on disk)' });
      continue;
    }
    if (!st.isFile()) continue;

    const archive = core.ARCHIVE_EXTS.includes(ext);
    const cap = archive ? core.ARCHIVE_CAP_BYTES : core.PLAIN_CAP_BYTES;
    if (st.size > cap) {
      record(sid, { base, kind: 'skip', limitKB: archive ? core.ARCHIVE_CAP_KB : core.PLAIN_CAP_KB });
      continue;
    }

    const timeout = archive ? core.ARCHIVE_TIMEOUT_MS : core.PLAIN_TIMEOUT_MS;
    const r = core.scoreFile(root, abs, timeout);
    if (!r.ok) {
      record(sid, { base, kind: 'failed', reason: r.reason });
      continue;
    }
    const labels = r.findings.filter((f) => f.count > 0).map((f) => f.label);
    const flagged = r.score > threshold;
    record(sid, {
      base, kind: 'scored', score: r.score, band: r.band, phrase: core.hookPhrase(r.band),
      labels: labels.slice(0, core.GUARD_LABEL_CAP), flagged, truncated: r.truncated,
    });
    if (flagged) {
      const cov = r.truncated ? ', first ' + core.WINDOW_TEXT + ' characters only' : '';
      const list = labels.slice(0, core.GUARD_LABEL_CAP).join('; ') || 'see the report';
      lines.push('prosecheck: ' + base + ' ' + core.hookPhrase(r.band) + ' (score ' + r.score + ', band ' + r.band +
        cov + '). Flagged: ' + list + '. ' + ASK);
    }
  }
  if (!lines.length) return '';
  return JSON.stringify({
    hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
  });
}

try {
  const out = main();
  if (out) process.stdout.write(out);
} catch (_) {
  /* never fail the host */
}
process.exitCode = 0;
