#!/usr/bin/env node
'use strict';
// Stats helper. The /prosecheck router calls statsReply(); run directly it behaves as a
// prompt-submit hook that answers only `/prosecheck stats`.
const core = require('./lib/core');
const cmd = require('./lib/commands');

module.exports = { statsReply: cmd.statsReply };

if (require.main === module) {
  try {
    const input = core.readStdinJson();
    const prompt = typeof input.prompt === 'string' ? input.prompt.trim() : '';
    if (/^\/prosecheck(?::prosecheck)?\s+stats$/i.test(prompt)) {
      const root = core.pluginRoot(__dirname);
      const reply = cmd.statsReply(input, root, core.effectiveLevel());
      process.stdout.write(JSON.stringify({ decision: 'block', reason: reply }));
    }
  } catch (_) {
    /* never fail the host */
  }
  process.exitCode = 0;
}
