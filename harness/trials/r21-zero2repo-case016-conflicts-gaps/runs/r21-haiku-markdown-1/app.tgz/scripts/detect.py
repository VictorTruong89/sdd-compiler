#!/usr/bin/env python3
"""prosecheck detector: local, deterministic, standard library only.

Usage: python3 scripts/detect.py [--clean] [--ci] [--] [FILE]

Reads FILE (or standard input when no operand is given), extracts visible prose,
scores the first 262,144 characters against the prosecheck catalogue and prints
one JSON report on standard output.  With --clean it prints scrubbed text instead.
Errors go to standard error as one JSON object {"error": "..."}.
"""
import io
import json
import math
import os
import posixpath
import re
import sys
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

WINDOW = 262144
PLAIN_EXTS = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXTS = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NOTEBOOK_EXT = '.ipynb'
USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Score a prose file (or standard input) for AI-writing patterns.
  --clean   print the scrubbed text instead of the JSON report
  --ci      add a low/high interval on the score when there are enough sentences
  --        end of options; the next argument may be a file name starting with '-'
  -h, --help  print this message
FILE is one path. Plain text is read as UTF-8 (or UTF-16 with a byte-order mark).
Supported: .md .mdx .markdown .txt .text .rst .tex .org .adoc, zip-based
.docx .docm .pptx .pptm .xlsx .xlsm .odt .odp .ods .epub, and .ipynb.
"""


class CannotRead(Exception):
    pass


# ---------------------------------------------------------------- decoding

def decode_text(data):
    if data.startswith(b'\xef\xbb\xbf'):
        return data[3:].decode('utf-8', 'replace')
    if data.startswith(b'\xff\xfe') or data.startswith(b'\xfe\xff'):
        return data.decode('utf-16', 'replace')
    try:
        return data.decode('utf-8')
    except UnicodeDecodeError:
        return data.decode('utf-8', 'replace')


def normalize_newlines(text):
    return text.replace('\r\n', '\n').replace('\r', '\n').replace(' ', '\n').replace(' ', '\n')


# ---------------------------------------------------------------- extraction

def _local(tag):
    return tag.rsplit('}', 1)[-1] if isinstance(tag, str) else ''


def _parse_xml(data):
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


def _xml_text_fallback(data):
    s = decode_text(data)
    s = re.sub(r'<[^>]+>', ' ', s)
    return s


def _read_member(zf, name):
    try:
        return zf.read(name)
    except KeyError:
        return None


def _docx(zf):
    data = _read_member(zf, 'word/document.xml')
    if data is None:
        return ''
    root = _parse_xml(data)
    if root is None:
        return _xml_text_fallback(data)
    paras = []
    for p in root.iter():
        if _local(p.tag) != 'p':
            continue
        parts = []
        for el in p.iter():
            ln = _local(el.tag)
            if ln == 't' and el.text:
                parts.append(el.text)
            elif ln == 'tab':
                parts.append('\t')
            elif ln == 'br':
                parts.append('\n')
        paras.append(''.join(parts))
    return '\n'.join(paras)


def _pptx(zf):
    slides = []
    for name in zf.namelist():
        m = re.match(r'ppt/slides/slide(\d+)\.xml$', name)
        if m:
            slides.append((int(m.group(1)), name))
    slides.sort()
    out = []
    for _, name in slides:
        data = zf.read(name)
        root = _parse_xml(data)
        if root is None:
            out.append(_xml_text_fallback(data))
            continue
        paras = []
        for p in root.iter():
            if _local(p.tag) != 'p':
                continue
            parts = []
            for el in p.iter():
                ln = _local(el.tag)
                if ln == 't' and el.text:
                    parts.append(el.text)
                elif ln == 'br':
                    parts.append('\n')
            paras.append(''.join(parts))
        out.append('\n'.join(paras))
    return '\n'.join(out)


def _xlsx(zf):
    shared = []
    sst_data = _read_member(zf, 'xl/sharedStrings.xml')
    if sst_data is not None:
        root = _parse_xml(sst_data)
        if root is not None:
            for si in root.iter():
                if _local(si.tag) == 'si':
                    shared.append(''.join(t.text or '' for t in si.iter() if _local(t.tag) == 't'))
    sheets = []
    for name in zf.namelist():
        m = re.match(r'xl/worksheets/sheet(\d+)\.xml$', name)
        if m:
            sheets.append((int(m.group(1)), name))
    sheets.sort()
    out = []
    for _, name in sheets:
        root = _parse_xml(zf.read(name))
        if root is None:
            continue
        cells = []
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            kind = c.get('t')
            text = ''
            if kind == 's':
                v = None
                for ch in c:
                    if _local(ch.tag) == 'v':
                        v = ch.text or ''
                if v is not None and v.strip().isdigit():
                    idx = int(v.strip())
                    if idx < len(shared):
                        text = shared[idx]
            elif kind == 'inlineStr':
                text = ''.join(t.text or '' for t in c.iter() if _local(t.tag) == 't')
            elif kind == 'str':
                for ch in c:
                    if _local(ch.tag) == 'v':
                        text = ch.text or ''
            if text:
                cells.append(text)
        out.append('\n'.join(cells))
    return '\n'.join(x for x in out if x)


_ODF_SKIP = {'automatic-styles', 'font-face-decls', 'styles', 'meta', 'settings', 'scripts', 'master-styles'}


def _odf(zf):
    data = _read_member(zf, 'content.xml')
    if data is None:
        return ''
    root = _parse_xml(data)
    if root is None:
        return _xml_text_fallback(data)
    out = []

    def walk(el):
        ln = _local(el.tag)
        if ln in _ODF_SKIP:
            return
        if ln == 's':
            count = 1
            for k, v in el.attrib.items():
                if _local(k) == 'c':
                    try:
                        count = int(v)
                    except ValueError:
                        count = 1
            out.append(' ' * max(1, count))
        elif ln == 'tab':
            out.append('\t')
        elif ln == 'line-break':
            out.append('\n')
        if el.text:
            out.append(el.text)
        for ch in el:
            walk(ch)
            if ch.tail:
                out.append(ch.tail)
        if ln in ('p', 'h'):
            out.append('\n')

    walk(root)
    return ''.join(out)


class _HTMLText(HTMLParser):
    BLOCK = {'p', 'div', 'br', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'section',
             'blockquote', 'pre', 'table', 'ul', 'ol', 'hr', 'article', 'header', 'footer', 'dt', 'dd'}
    SKIP = {'script', 'style', 'head', 'title', 'nav'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.out.append('\n')

    def handle_startendtag(self, tag, attrs):
        if tag in self.BLOCK and tag not in self.SKIP:
            self.out.append('\n')

    def handle_endtag(self, tag):
        if tag in self.SKIP:
            if self.skip > 0:
                self.skip -= 1
        elif tag in self.BLOCK:
            self.out.append('\n')

    def handle_data(self, data):
        if self.skip == 0:
            self.out.append(re.sub(r'\s+', ' ', data))


def _html_to_text(data):
    p = _HTMLText()
    try:
        p.feed(decode_text(data))
        p.close()
    except Exception:
        pass
    lines = [ln.strip() for ln in ''.join(p.out).split('\n')]
    return '\n'.join(lines)


def _epub(zf):
    names = zf.namelist()
    opf_path = None
    cont = _read_member(zf, 'META-INF/container.xml')
    if cont is not None:
        m = re.search(r'full-path\s*=\s*"([^"]+)"', decode_text(cont))
        if m:
            opf_path = m.group(1)
    chapters = []
    if opf_path and opf_path in names:
        base = posixpath.dirname(opf_path)
        opf = decode_text(zf.read(opf_path))
        manifest = {}
        for tag in re.findall(r'<item\b[^>]*>', opf):
            attrs = dict(re.findall(r'([\w:-]+)\s*=\s*"([^"]*)"', tag))
            if 'id' in attrs and 'href' in attrs:
                if 'nav' in attrs.get('properties', '').split():
                    continue
                manifest[attrs['id']] = attrs
        spine = re.findall(r'<itemref\b[^>]*idref\s*=\s*"([^"]+)"', opf)
        for idref in spine:
            if idref in manifest:
                href = manifest[idref]['href']
                path = posixpath.normpath(posixpath.join(base, href)) if base else posixpath.normpath(href)
                chapters.append(path)
    if not chapters:
        chapters = sorted(n for n in names if re.search(r'\.(x?html?)$', n, re.I))
    out = []
    lower_map = {n.lower(): n for n in names}
    for path in chapters:
        real = path if path in names else lower_map.get(path.lower())
        if real is None:
            continue
        if not re.search(r'\.(x?html?)$', real, re.I):
            continue
        text = _html_to_text(zf.read(real))
        if text.strip():
            out.append(text)
    return '\n'.join(out)


def _ipynb(data):
    try:
        nb = json.loads(decode_text(data))
    except Exception:
        return ''
    if not isinstance(nb, dict):
        return ''
    cells = nb.get('cells')
    if not isinstance(cells, list):
        return ''
    out = []
    for c in cells:
        if not isinstance(c, dict):
            return ''
        if c.get('cell_type') != 'markdown':
            continue
        src = c.get('source', '')
        if isinstance(src, list):
            if not all(isinstance(x, str) for x in src):
                return ''
            src = ''.join(src)
        elif not isinstance(src, str):
            return ''
        src = src.strip('\n')
        if src.strip():
            out.append(src)
    return '\n'.join(out)


def extract(data, ext):
    if ext in PLAIN_EXTS or ext == '':
        return decode_text(data)
    if ext == NOTEBOOK_EXT:
        return _ipynb(data).strip()
    if ext in ('.pdf', '.rtf'):
        return ''
    if ext in ZIP_EXTS:
        try:
            zf = zipfile.ZipFile(io.BytesIO(data))
        except (zipfile.BadZipFile, OSError, ValueError):
            raise CannotRead('not a readable zip archive')
        try:
            with zf:
                if ext in ('.docx', '.docm'):
                    text = _docx(zf)
                elif ext in ('.pptx', '.pptm'):
                    text = _pptx(zf)
                elif ext in ('.xlsx', '.xlsm'):
                    text = _xlsx(zf)
                elif ext == '.epub':
                    text = _epub(zf)
                else:
                    text = _odf(zf)
        except (zipfile.BadZipFile, KeyError, OSError, ValueError, RuntimeError):
            raise CannotRead('not a readable zip archive')
        return text.strip()
    return decode_text(data)


# ---------------------------------------------------------------- character layer

RTL_RE = re.compile(r'[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]')


def _in(c, ranges):
    if not c:
        return False
    o = ord(c)
    return any(lo <= o <= hi for lo, hi in ranges)


JOIN_RANGES = [(0x0590, 0x05FF), (0x0600, 0x06FF), (0x0700, 0x074F), (0x0900, 0x0DFF), (0x1000, 0x109F), (0x1780, 0x17FF)]
NO_SPACE_RANGES = [(0x0E00, 0x0E7F), (0x0E80, 0x0EFF), (0x1780, 0x17FF), (0x1000, 0x109F),
                   (0x3040, 0x30FF), (0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF)]
CJK_RANGES = [(0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF)]
JOINING = lambda c: _in(c, JOIN_RANGES)
NO_SPACE_SCRIPT = lambda c: _in(c, NO_SPACE_RANGES)
CJK_IDEO = lambda c: _in(c, CJK_RANGES)
SYMBOLISH = lambda c: bool(c) and (ord(c) >= 0x1F000 or unicodedata.category(c) in ('So', 'Sm', 'Sk'))
BIDI_CODES = {0x200E, 0x200F, 0x061C, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E, 0x2066, 0x2067, 0x2068, 0x2069}


def is_invisible(ch):
    if ch in '\t\n\r':
        return False
    cp = ord(ch)
    cat = unicodedata.category(ch)
    if cat in ('Cc', 'Cf'):
        return True
    if 0xE0000 <= cp <= 0xE0FFF or 0xFE00 <= cp <= 0xFE0F:
        return True
    if cp in (0x034F, 0x115F, 0x1160, 0x3164, 0xFFA0, 0x17B4, 0x17B5, 0x180B, 0x180C, 0x180D, 0x180E, 0x180F):
        return True
    return False


def invisible_kept(text, i, rtl):
    """True when an invisible character does a job in its position (cleanup keeps it)."""
    ch = text[i]
    cp = ord(ch)
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if cp == 0x00AD:
        return prev.isalpha() and nxt.isalpha()
    if 0xE0020 <= cp <= 0xE007F:
        return prev == '\U0001F3F4' or (0xE0020 <= ord(prev or '\0') <= 0xE007F) or SYMBOLISH(prev)
    if 0xE0100 <= cp <= 0xE01EF:
        return CJK_IDEO(prev) or SYMBOLISH(prev)
    if 0xFE00 <= cp <= 0xFE0F:
        return SYMBOLISH(prev) or CJK_IDEO(prev) or nxt == '\u20e3'
    if cp == 0x200B:
        return NO_SPACE_SCRIPT(prev) or NO_SPACE_SCRIPT(nxt)
    if cp in (0x200C, 0x200D):
        return JOINING(prev) or JOINING(nxt) or SYMBOLISH(prev) or SYMBOLISH(nxt)
    if cp in BIDI_CODES:
        return rtl
    if 0x180B <= cp <= 0x180F:
        return bool(prev) and 0x1800 <= ord(prev) <= 0x18AF
    if cp in (0x17B4, 0x17B5):
        return (bool(prev) and 0x1780 <= ord(prev) <= 0x17FF) or (bool(nxt) and 0x1780 <= ord(nxt) <= 0x17FF)
    return False


def _nbsp_holds(text, i):
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if prev.isdigit() or nxt.isdigit():
        return True
    if nxt and nxt in ':;!?»›%€':
        return True
    if prev and prev in '«‹':
        return True
    return False


def nonstd_space_kept(text, i):
    ch = text[i]
    return ch in ('\u00a0', '\u202f') and _nbsp_holds(text, i)


def is_nonstd_space(ch):
    return ch != ' ' and unicodedata.category(ch) == 'Zs'


# Latin-looking letters of other scripts, mapped to the ASCII letter they imitate.
LOOKALIKES = {
    'а': 'a', 'с': 'c', 'ԁ': 'd', 'е': 'e', 'һ': 'h', 'і': 'i',
    'ј': 'j', 'о': 'o', 'р': 'p', 'ѕ': 's', 'у': 'y', 'х': 'x',
    'ѕ': 's', 'ѵ': 'v', 'ա': 'a', 'օ': 'o', 'ս': 'u',
    'ο': 'o', 'ν': 'v', 'ι': 'i', 'ρ': 'p', 'υ': 'u', 'ϲ': 'c',
    'ϳ': 'j', 'Α': 'A', 'Β': 'B', 'Ε': 'E', 'Ζ': 'Z', 'Η': 'H',
    'Ι': 'I', 'Κ': 'K', 'Μ': 'M', 'Ν': 'N', 'Ο': 'O', 'Ρ': 'P',
    'Τ': 'T', 'Χ': 'X', 'Υ': 'Y',
    'А': 'A', 'В': 'B', 'С': 'C', 'Е': 'E', 'Н': 'H', 'І': 'I',
    'Ј': 'J', 'К': 'K', 'М': 'M', 'О': 'O', 'Р': 'P', 'Ѕ': 'S',
    'Т': 'T', 'Х': 'X', 'У': 'Y', 'ԁ': 'd',
}
LETTER_RUN_RE = re.compile(r'[^\W\d_]+')


def fold_homoglyphs(text):
    """Return (folded_text, count) for mixed-script lookalike runs."""
    count = 0
    pieces = []
    last = 0
    for m in LETTER_RUN_RE.finditer(text):
        run = m.group(0)
        has_ascii = any(('a' <= c <= 'z') or ('A' <= c <= 'Z') for c in run)
        if not has_ascii:
            continue
        ok = True
        n_look = 0
        for c in run:
            if ord(c) < 128:
                continue
            if c in LOOKALIKES:
                n_look += 1
            else:
                ok = False
                break
        if not ok or n_look == 0:
            continue
        count += n_look
        pieces.append(text[last:m.start()])
        pieces.append(''.join(LOOKALIKES.get(c, c) for c in run))
        last = m.end()
    if not pieces:
        return text, 0
    pieces.append(text[last:])
    return ''.join(pieces), count


def count_trailing_ws(t):
    n = len(re.findall(r'[ \t]+(?=\n)', t))
    if re.search(r'[ \t]+$', t):
        n += 1
    if re.search(r'\n\n$', t):
        n += 1
    if t and t[0].isspace():
        n += 1
    return n


def scrub(text):
    """Cleanup: strip invisible characters, normalize spaces, fold lookalikes, trim."""
    text = normalize_newlines(text)
    ended_lf = text.rstrip(' \t').endswith('\n')
    rtl = bool(RTL_RE.search(text))
    out = []
    for i, ch in enumerate(text):
        if is_invisible(ch) and not invisible_kept(text, i, rtl):
            continue
        if is_nonstd_space(ch):
            out.append(ch if nonstd_space_kept(text, i) else ' ')
            continue
        out.append(ch)
    body = ''.join(out)
    body, _ = fold_homoglyphs(body)
    body = re.sub(r'[ \t]+(?=\n)', '', body)
    body = body.lstrip(' \t\n').rstrip(' \t\n')
    if body and ended_lf:
        body += '\n'
    return body


def char_layer(window, rtl):
    invis = []
    for i, ch in enumerate(window):
        if is_invisible(ch) and not invisible_kept(window, i, rtl):
            invis.append(i)
    nonstd = 0
    for i, ch in enumerate(window):
        if is_nonstd_space(ch) and not nonstd_space_kept(window, i):
            nonstd += 1
    _, homo = fold_homoglyphs(window)
    return invis, nonstd, homo


# ---------------------------------------------------------------- markdown masking

FENCE_OPEN = re.compile(r'^ {0,3}(`{3,}|~{3,})(.*)$')


def mask_markdown(text):
    """Blank out (keeping length and newlines) everything the detector must not score."""
    chars = list(text)
    lines = text.split('\n')
    starts = []
    pos = 0
    for ln in lines:
        starts.append(pos)
        pos += len(ln) + 1

    def blank(a, b):
        for k in range(a, min(b, len(chars))):
            if chars[k] != '\n':
                chars[k] = ' '

    def line_span(i):
        return starts[i], starts[i] + len(lines[i])

    # YAML front matter
    idx = 0
    if lines and lines[0].rstrip() == '---':
        for j in range(1, len(lines)):
            if lines[j].rstrip() in ('---', '...'):
                a, _ = line_span(0)
                _, b = line_span(j)
                blank(a, b)
                idx = j + 1
                break

    # fenced code blocks (CommonMark)
    i = idx
    in_fence = False
    fence_char, fence_len = '', 0
    while i < len(lines):
        ln = lines[i]
        if not in_fence:
            m = FENCE_OPEN.match(ln)
            if m:
                fence = m.group(1)
                info = m.group(2)
                if not (fence[0] == '`' and '`' in info):
                    in_fence = True
                    fence_char, fence_len = fence[0], len(fence)
                    blank(*line_span(i))
            i += 1
            continue
        blank(*line_span(i))
        m = re.match(r'^ {0,3}(`{3,}|~{3,})\s*$', ln)
        if m and m.group(1)[0] == fence_char and len(m.group(1)) >= fence_len:
            in_fence = False
        i += 1

    m_text = ''.join(chars)
    chars = list(m_text)

    # inline code spans
    for mm in re.finditer(r'(?<!`)(`+)(?!`)(.+?)(?<!`)\1(?!`)', m_text, re.S):
        blank(mm.start(), mm.end())
    m_text = ''.join(chars)
    lines = m_text.split('\n')
    chars = list(m_text)

    # blockquote runs of two or more lines, markdown table rows, badge lines
    i = 0
    while i < len(lines):
        ln = lines[i]
        if re.match(r'^\s*>', ln):
            j = i
            while j < len(lines) and re.match(r'^\s*>', lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    a, b = line_span_from(lines, k)
                    blank(a, b)
            i = j
            continue
        if re.match(r'^\s*\|.*\|', ln) or re.match(r'^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$', ln):
            a, b = line_span_from(lines, i)
            blank(a, b)
        elif re.match(r'^\s*(\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$', ln):
            a, b = line_span_from(lines, i)
            blank(a, b)
        i += 1
    return ''.join(chars)


def line_span_from(lines, k):
    a = 0
    for x in lines[:k]:
        a += len(x) + 1
    return a, a + len(lines[k])


WORD_RE = re.compile(r"[^\W_](?:[^\W_'\-]|['\-])*")
HEADING_RE = re.compile(r'^ {0,3}#{1,6}[ \t]+(.+?)[ \t]*#*[ \t]*$', re.M)


def words_of(s):
    return WORD_RE.findall(s)


def split_sentences(masked):
    out = []
    for line in masked.split('\n'):
        if re.match(r'^\s*#{1,6}\s', line) or not line.strip():
            continue
        for piece in re.split(r'(?<=[.!?])\s+', line.strip()):
            if words_of(piece):
                out.append(piece)
    return out


def split_paragraphs(masked):
    blocks = re.split(r'\n[ \t]*\n', masked)
    out = []
    for b in blocks:
        if not b.strip():
            continue
        lines = [ln for ln in b.split('\n') if ln.strip()]
        if all(re.match(r'^\s*#{1,6}\s', ln) for ln in lines):
            continue
        out.append(b)
    return out


def cv(values):
    if len(values) < 2:
        return None
    mean = sum(values) / len(values)
    if mean == 0:
        return None
    var = sum((v - mean) ** 2 for v in values) / len(values)
    return math.sqrt(var) / mean


# ---------------------------------------------------------------- pattern helpers

def P(s):
    """Phrase -> regex: spaces match any whitespace, apostrophes accept curly forms."""
    return re.escape(s).replace(r'\ ', r'\s+').replace("'", "['’]")


def ALT(phrases, flags=re.I):
    return re.compile(r'\b(?:' + '|'.join(P(p) for p in phrases) + r')\b', flags)


def INF(stem):
    if stem.endswith('e'):
        return re.escape(stem[:-1]) + r'(?:e|es|ed|ing|s)?'
    return re.escape(stem) + r'(?:s|es|ed|ing|d)?'


def RX(pattern, flags=re.I):
    return re.compile(pattern, flags)


# ---------------------------------------------------------------- catalogue detectors
# Each detector returns a list of (start, end) spans in the masked text, or a list of
# plain strings for structural matches (with the span stored as (start,end,text)).

def spans_rx(rx):
    def f(ctx):
        return [m.span() for m in rx.finditer(ctx.m)]
    return f


def combine(*fns):
    def f(ctx):
        out = []
        for fn in fns:
            out.extend(fn(ctx))
        return out
    return f


AI_VOCAB = RX(r'\b(?:' + '|'.join([
    r'additionally', r'align\s+with', r'crucial', INF('delve'), r'tapestry', r'pivotal', r'vibrant',
    INF('meticulous'), r'testament', INF('underscore'), r'intricacies', r'intricate', r'interplay',
    INF('garner'), INF('bolster'), INF('foster'), INF('showcase'), INF('emphasize'), r'enduring',
    INF('enhance'), INF('leverage'), INF('utilize'), INF('facilitate'), INF('encompass'), INF('harness'),
    r'holistic', INF('paradigm'), r'transformative', r'unprecedented', r'myriad', r'plethora', INF('robust'),
    INF('seamless'), INF('navigate'), INF('embark'), INF('craft'), INF('landscape'), INF('journey'),
    INF('realm'), r'multifaceted', INF('elevate'), INF('empower'), INF('unlock'),
    r'capture\s+the\s+(?:essence|spirit|imagination|heart|magic)',
]) + r')\b', re.I)
AI_VOCAB_DELVE = RX(r'\bdelv(?:e|es|ed|ing)\b', re.I)

MODEL_DIALECT_RXS = [
    ALT(['genuinely', 'fascinating', 'nuanced', 'thoughtfully', 'refreshingly', 'strikingly', 'compellingly']),
    RX(r'\bquietly\s+(?:powerful|profound|radical)\b'),
    RX(r'\bdeeply\s+(?:human|personal|felt|unsettling)\b'),
    RX(r'\bresonates?\s+deeply\b'),
    RX(r'\bgame[\s-]?chang(?:er|ers|ing)\b'),
    RX(r'\b' + INF('supercharge') + r'\b'),
    RX(r'\b' + INF('skyrocket') + r'\b'),
    RX(r'\b' + INF('turbocharge') + r'\b'),
    RX(r'\b' + INF('revolutionize') + r'\b'),
    RX(r'\bdouble\s+down\s+on\b'),
    RX(r'\bdive\s+deep(?:er)?\s+into\b'),
    RX(r'\bunlock(?:s|ed|ing)?\s+(?:the\s+)?(?:power|potential|value)\b'),
    RX(r'\btake\b[^.!?\n]{1,60}?\bto\s+the\s+next\s+level\b'),
]

PROMO_PHRASES = ['nestled', 'breathtaking', 'must-visit', 'stunning', 'picturesque', 'charming', 'idyllic',
                 'vibrant community', 'rich cultural heritage', 'in the heart of', 'world-class', 'top-tier',
                 'unparalleled', 'premier', 'esteemed organization', 'valuable asset', 'passion for excellence',
                 'proven track record', 'results-oriented', 'wealth of experience', 'dynamic team',
                 'fast-paced environment', 'deeply passionate', 'perfectly situated', 'close-knit team',
                 'tight-knit team', 'uniquely positioned to', 'i am excited to apply', 'i am excited to bring',
                 "i'm excited to apply", "i'm excited to bring"]
PROMO_RX = ALT(PROMO_PHRASES)
PROMO_LEADING = RX(r'\b(?:a|the)\s+leading\b')
IMPERATIVES = {'install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape', 'transform',
               'reclaim', 'unlock', 'elevate', 'boost', 'say', 'imagine', 'explore', 'meet', 'introducing',
               'upgrade', 'claim', 'unleash', 'supercharge', 'level', 'stop', 'start'}

HYPHEN_PAIRS = ALT(['cutting-edge', 'best-in-class', 'state-of-the-art', 'next-generation', 'results-driven',
                    'data-driven', 'customer-centric', 'client-centric', 'user-centric', 'value-driven',
                    'top-notch', 'one-stop-shop'])
SIMPLE_YET = RX(r'\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b')

ADJ_SUFFIX_RE = re.compile(r'(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$', re.I)
STOCK_ADJ = {'vibrant', 'robust', 'seamless', 'dynamic', 'innovative', 'comprehensive', 'powerful', 'elegant',
             'rich', 'bold', 'sleek', 'intuitive', 'scalable', 'cutting-edge', 'stunning', 'premier', 'unparalleled',
             'exceptional', 'seamlessly', 'meticulous', 'holistic', 'transformative', 'world-class'}
CHAIN_RE = re.compile(r"\b[A-Za-z][A-Za-z'\-]{2,}(?:(?:,\s+(?:and\s+)?|\s+and\s+)[A-Za-z][A-Za-z'\-]{2,}){3}\b")

SYNONYM_CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]
SYN_RX = []
for _cl in SYNONYM_CLUSTERS:
    SYN_RX.append([(w, re.compile(r'\b' + P(w) + r's?\b', re.I)) for w in _cl])

SIG_RXS = [
    RX(r'\b(?:stands?|stood|serves?|served)\s+as\s+an?\s+(?:testaments?|reminders?|symbols?|beacons?|cornerstones?|bridges?|gateways?|hallmarks?)\b'),
    RX(r'\b(?:underscor\w*|highlight\w*)\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b'),
    RX(r'\breflects?\s+a\s+broader\s+(?:trend|shift|pattern)\b'),
    RX(r'\bmarks?\s+an?\s+(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)\b'),
    RX(r'\bsymboli[sz](?:es|ed|ing)\b'),
    RX(r'\bsets?\s+the\s+stage\s+for\b'),
    RX(r'\bleft\s+an\s+indelible\s+mark\b'),
    RX(r'\bplays?\s+an?\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b'),
    RX(r'\bhas\s+(?:shaped|sparked)\b'),
    RX(r'\bhas\s+come\s+to\s+(?:define|symboli[sz]e)\b'),
]

NOTABILITY_CREDIT = RX(r'(?i:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?i:in|by)\s+'
                       r"[A-Z][\w&.']*(?:(?:,\s*|\s+and\s+)[A-Z][\w&.']*)+", 0)
NOTABILITY_FOLLOWERS = RX(r'\b\d[\d,.]*\s*[KkMm]?\+?\s+(?:followers|subscribers)\b')
NOTABILITY_STOCK = RX(r'\b(?:strong|active|robust|growing|significant)\s+(?:online|digital|social[\s-]media)\s+presence\b'
                      r'|\bwidely\s+covered\b|\bindependent\s+coverage\b|\bcoverage\s+by\s+independent\b')

VAGUE_RX = RX(r'\bexperts?\s+(?:argue|believe|say|claim|note|suggest)\b|\bindustry\s+(?:reports|observers|analysts)\b'
              r'|\bobservers\s+have\s+(?:cited|noted)\b|\bsome\s+critics\s+argue\b|\bresearchers\s+have\s+found\b'
              r'|\bstudies\s+suggest\b|\bit\s+is\s+widely\s+believed\b')
ARTICLE_TITLE_RX = re.compile(r'\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of \S+(?: \S+){0,8}? is (?:a|an|the)\b')

CONSERVATION_RX = RX(r'\bplays\s+an?\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b'
                     r'|\bconservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)\b'
                     r'|\bserves\s+as\s+an?\s+indicator\s+species\b'
                     r'|\bcontributes\s+to\s+biodiversity\b')
FALSE_RANGE_RXS = [
    RX(r'\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]{0,200}?'
       r'\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b'),
    RX(r'\bfrom\s+(?:the\s+)?humble\b[^.!?\n]{0,200}?\bto\s+(?:the\s+)?(?:mighty|towering|grand|sprawling)\b'),
]
ING_TAIL_RX = RX(r',\s*(?:highlighting|reflecting|symboli[sz]ing|emphasi[sz]ing|underscoring|showcasing|fostering|'
                 r'cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|indicating|'
                 r'reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b')

PARALLEL_RXS = [
    RX(r"\bit['’]s\s+not\s+(?:just|merely)\s+(?:about|an?)\b"),
    RX(r'\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b'),
    RX(r"\bdoesn['’]t\s+just\s+[^,.\n]{0,40}?\bit\b"),
]
TAILING_NEG_RX = RX(r',\s*no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b')
NOT_X_JUST_Y_RXS = [
    RX(r"\b(?:no|not)\s+[A-Za-z][\w'’-]*,\s*(?:just|only|simply)\s+[A-Za-z][\w'’-]*"),
    RX(r"\b(?:not|isn['’]t|aren['’]t|wasn['’]t|weren['’]t)\s+(?:just|merely)\s+(?:(?:a|an|the)\s+)?[A-Za-z][\w'’-]*"
       r"(?:,|\s[—–-]|[—–])\s*(?:it['’]s|it\s+is|it\s+was|they['’]re|they\s+are|they\s+were|that['’]s|but)\b"),
]
FILLER_RX = ALT(['in order to', 'due to the fact that', 'at this point in time', 'in the event that',
                 'has the ability to', 'it is important to note that', 'it should be mentioned that',
                 'needless to say'])
EMPTY_PIVOT_RX = RX(r"\bit['’]s\s+worth\s+(?:noting|mentioning)\s+that\b|\bit\s+bears\s+(?:noting|mentioning)\s+that\b"
                    r"|\bone\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is\b|\bit\s+is\s+interesting\s+to\s+note\s+that\b"
                    r"|\ba\s+key\s+consideration\s+is\b|\ba\s+point\s+to\s+(?:highlight|note)\s+is\b")
OUTCOME_TAIL_RX = RX(r',\s*(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about|'
                     r'with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for|'
                     r'signaling\s+a\s+shift\s+toward)')
AUTHORITY_TROPES = ALT(["here's the thing", 'make no mistake', 'the truth is', "let's be honest",
                        'the simple fact is', 'at its core', 'what really matters', 'more than anything',
                        'at the end of the day', 'the bottom line is', 'in reality', 'fundamentally,',
                        'the real question is', 'the heart of the matter', 'the deeper issue',
                        'when you get down to it', 'when all is said and done'])
EDITORIAL_RX = RX(r"\bit(?:['’]s|\s+is)\s+important\s+to\s+(?:remember|note|understand|recognize)\b"
                  r"|\bone\s+must\s+note\s+that\b|\bit\s+is\s+worth\s+pointing\s+out\b"
                  r"|\bit\s+cannot\s+be\s+overstated\s+that\b|\bit\s+must\s+be\s+emphasized\s+that\b")
SELF_THOROUGH_RX = RX(r'\bthis\s+comprehensive\s+(?:guide|overview|analysis)\b|\bthis\s+in-depth\s+(?:analysis|look|examination)\b'
                      r'|\bthis\s+complete\s+(?:guide|overview)\b|\ba\s+thorough\s+examination\s+of\b'
                      r'|\beverything\s+you\s+need\s+to\s+know\s+about\b')
QA_RX = re.compile(r'(?m)^[ \t]*(?:Is|Are|Was|Were|Do|Does|Did|Can|Could|Will|Would|Should|Has|Have|Had|May|Might|Must)\b'
                   r'[^.!?\n]{0,80}\?\s*(?i:yes|no|absolutely|never|maybe|probably|always)[.!]')
CONCRETE_RX = RX(r'\bwithout\s+concrete\s+(?:evidence|proof)\b|\bdo\s+you\s+have\s+concrete\s+(?:evidence|proof)\b'
                 r'|\bI\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples|proof)\s+to\b|\babsent\s+concrete\s+proof\b'
                 r'|\bprovide\s+concrete\s+evidence\b', 0)
INTRO_HOOK_RXS = [
    RX(r"\bin\s+today['’]s\s+(?:\w+\s+){0,2}?(?:world|landscape|environment|market)\b"),
    RX(r'\bin\s+a\s+world\s+where\b'),
    RX(r'\bin\s+an\s+era\s+of\b'),
    RX(r'\bin\s+recent\s+years,'),
    RX(r'\bmore\s+than\s+ever\s+before\b'),
    RX(r'\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b'),
    RX(r'\b(?:great|exciting|big)\s+news\s*[!:]'),
    RX(r'\bever\s+(?:wanted|wondered|dreamed|wished)\b[^.!?\n]{0,60}\?'),
    RX(r'\bin\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world\b'),
]
CHALLENGES_RXS = [
    RX(r'\bdespite\s+(?:these|its|the)\s+(?:challenges|obstacles)\b'),
    RX(r'\bchallenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)\b'),
    RX(r'\bcontinues\s+to\s+thrive\b'),
    RX(r'\btypical\s+of\s+(?:emerging|urban|modern)\b'),
    RX(r'\bfaces\s+(?:several|many|numerous)\s+challenges\b'),
]
TRANSITIONS = ['additionally', 'furthermore', 'moreover', 'however', 'nevertheless', 'consequently',
               'subsequently', 'notably']
TRANSITION_RX = RX(r'(?:^|(?<=[.!?])\s+|\n\s*)(' + '|'.join(TRANSITIONS) + r')\b')
CONCLUSION_LINE_RX = RX(r'^[ \t]*(?:in\s+conclusion|overall|in\s+summary|to\s+summarize|to\s+conclude|all\s+in\s+all|'
                        r'in\s+essence|ultimately)\b', re.M)
POSITIVE_CONCL_RXS = [
    RX(r'\bthe\s+future\s+looks\s+bright\b'),
    RX(r'\bexciting\s+times\s+lie\s+ahead\b'),
    RX(r'\bjourney\s+toward\s+excellence\b'),
    RX(r'\bstep\s+in\s+the\s+right\s+direction\b'),
    RX(r'\b(?:outlook|future)(?:\s+for\s+[^.!?\n]{0,40})?\s+(?:is|looks|remains)\s+bright\b'),
    RX(r'\bwell[\s-]positioned\s+for\s+(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)\b'),
]
PRAISE_RX = RX(r'\b(?:great|excellent|wonderful|fantastic|brilliant|thoughtful|insightful)\s+(?:question|point)\s*[!.,]')

CHATBOT_RXS = [
    RX(r'\bI\s+hope\s+this\s+helps\b'),
    RX(r'\bCertainly!'),
    RX(r'\bOf\s+course!'),
    RX(r'\blet\s+me\s+know\s+if\s+you\b'),
    RX(r'\bwould\s+you\s+like\s+me\s+to\b'),
    RX(r'\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b'),
    RX(r'\bhappy\s+to\s+help[.!]'),
    RX(r'\b(?:here|below)\s+is\s+(?:a\s+|an\s+|the\s+)?(?:overview|summary|rundown|recap|brief)\b'),
    RX(r'\bhere\s+(?:are|[\'’]s)\s+(?:a\s+few|some|two|three)\s+(?:options|drafts|versions|variations)\b'),
    RX(r'\bhere\s+(?:is|[\'’]s)\s+(?:or\s+here[\'’]s\s+)?a\s+draft\b'),
    RX(r'\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b'),
    RX(r'\bI\s+hope\s+(?:this\s+(?:email\s+)?)?finds\s+you\s+well\b'),
    RX(r'\bas\s+an?\s+(?:AI|LLM|AI\s+assistant|AI\s+language\s+model|large\s+language\s+model|language\s+model)\b'),
    RX(r'\bto\s+(?:answer|address)\s+your\s+question\b'),
    RX(r'\bin\s+(?:response|answer)\s+to\s+your\s+question\b'),
    RX(r'\byour\s+question\s+(?:about|regarding|concerning)\b'),
    RX(r'\bas\s+(?:you\s+)?(?:requested|asked),?\s+here\b'),
    RX(r'\bhere\s+is\s+(?:the\s+)?(?:draft|first\s+pass|revised\s+version\s+of|revised\s+version|for\s+your)\b'),
]
SYCOPHANT_RXS = [
    RX(r"\byou(?:['’]re|\s+are)\s+absolutely\s+right\b"),
    PRAISE_RX,
    RX(r'\bwhat\s+a\s+(?:thoughtful|great|wonderful|fantastic|brilliant)\s+question\b'),
    RX(r"\bthat['’]s\s+a\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\b"),
]
CUTOFF_RXS = [
    RX(r'\bas\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)\b'),
    RX(r'\bup\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)\b'),
    RX(r'\bwhile\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+extensively\s+(?:documented|widely\s+documented)|not\s+widely\s+documented)\b'),
    RX(r'\bbased\s+on\s+(?:the\s+)?available\s+information\b'),
    RX(r'\bas\s+of\s+my\s+knowledge\s+cutoff\b'),
    RX(r'\bmaintains\s+a\s+low\s+profile\b'),
    RX(r'\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b'),
]
COPULA_RXS = [
    RX(r'\b(?:serves?|stands?|functions?|acts?)\s+as\b'),
    RX(r'\b(?:represents?|marks?)\s+(?:a|the)\b'),
    RX(r'\bboasts\b'),
    RX(r'\bfeatures\s+(?:an?|the|\d[\d,.]*|several|many|numerous|multiple|two|three|four|five|six|seven|eight|nine|ten)\b'),
    RX(r'\boffers\s+a\b'),
    RX(r'\brefers\s+to\b'),
]
HEDGE_RX = re.compile(r'\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively|fairly|'
                      r'kind\s+of|sort\s+of|seems?\s+(?:to|like)|appears?\s+to)\b')
FULL_FORM_RX = re.compile(r"\b(?:do not|does not|did not|is not|are not|was not|were not|will not|would not|"
                          r"cannot|can not|I am|I have|I will|I would|we are|we have|we will|it is|that is|"
                          r"they are|there is|you are|let us|I do|we do|it does)\b", re.I)
CONTRACTION_RX = re.compile(r"\b\w+(?:n['’]t|['’](?:re|ve|ll|m|s|d))\b", re.I)
FIRST_PERSON = {'i', 'we', 'my', 'our', 'me', 'us', 'myself', 'ourselves'}
BOLD_RX = re.compile(r'\*\*[^*\n]+?\*\*')
INLINE_HEADER_RX = re.compile(r'(?m)^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]+?(?::\*\*|\*\*:)')
EMOJI_RX = re.compile('[\U0001F300-\U0001F5FF\U0001F600-\U0001F64F\U0001F680-\U0001F6FF\U0001F700-\U0001F7FF'
                      '\U0001F900-\U0001F9FF\U0001FA00-\U0001FAFF\u2600-\u26FF\u2700-\u27BF\U0001F1E6-\U0001F1FF]')
CURLY_RX = re.compile('[\u201c\u201d\u2018\u2019]')
YEAR_RANGE_RX = re.compile(r'\b(1[0-9]{3}|20[0-9]{2})-(1[0-9]{3}|20[0-9]{2})\b')
PLACEHOLDER_RXS = [
    RX(r'\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![\(\[])'),
    RX(r'\[(?:name|company|client|person|place|source|address|author|product)\](?![\(\[])', 0),
    RX(r'\[[A-Z][A-Z _-]{2,}\](?![\(\[])', 0),
    RX(r'\{\{[^{}\n]*\}\}', 0),
    RX(r'(?<![A-Za-z])x{3,}(?![A-Za-z])', 0),
    RX(r'\blorem\s+ipsum\b'),
]
CHAT_MARKUP_RXS = [
    RX(r'\bcite(?:turn|start|nav)\w*'),
    RX(r'\boai_citation\w*'),
    RX(r'contentReference', 0),
    RX(r'\bnavlist\b'),
    RX(r'【\d+†[^】\n]*】', 0),
]
UTM_RX = RX(r'utm_source=([A-Za-z0-9.\-]+)')
UTM_DOMAINS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai', 'gemini.google.com',
               'copilot.microsoft.com', 'poe.com'}
SLOP_RX = RX(r'\bunlock(?:ing)?\s+(?:its\s+|the\s+|your\s+|their\s+)?full\s+potential\b'
             r'|\bnavigat(?:e|es|ing)\s+the\s+complexities\b'
             r'|\ba\s+testament\s+to\s+the\s+(?:power|importance)\s+of\b'
             r'|\bstaying\s+ahead\s+of\s+the\s+curve\b'
             r'|\bturning\s+challenges\s+into\s+opportunities\b'
             r'|\btaking\s+(?:something|it|your\s+\w+|\w+)\s+to\s+the\s+next\s+level\b'
             r'|\bharnessing\s+the\s+power\s+of\b'
             r'|\bpaving\s+the\s+way\s+for\b'
             r'|\bsaying\s+goodbye\s+to\b'
             r'|\bimagining\s+a\s+world\s+where\b')
RULE_LINE_RX = re.compile(r'(?m)^[ \t]*(?:-{3,}|\*{3,}|_{3,})[ \t]*$')
MINOR_WORDS = {'a', 'an', 'the', 'and', 'or', 'but', 'nor', 'so', 'yet', 'for', 'of', 'in', 'on', 'at', 'to',
               'by', 'as', 'up', 'off', 'via', 'with', 'from', 'into', 'over', 'per', 'vs', 'if'}
STOP_SHORT = {'the', 'and', 'with', 'from', 'that', 'this', 'have', 'been', 'were', 'your', 'their', 'there'}


# ---------------------------------------------------------------- analysis context

class Ctx:
    def __init__(self, window):
        self.w = window
        self.rtl = bool(RTL_RE.search(window))
        self.m = mask_markdown(window)
        self.sents = split_sentences(self.m)
        self.paras = split_paragraphs(self.m)
        self.words = words_of(self.m)
        self.word_count = len(self.words)


def clip(s):
    s = ' '.join(s.split())
    return s if len(s) <= 80 else s[:77] + '...'


def dets(ctx, rx):
    return [m.span() for m in rx.finditer(ctx.m)]


def det_multi(ctx, rxs):
    out = []
    for rx in rxs:
        out.extend(dets(ctx, rx))
    return out


def d_ai_vocab(ctx):
    return dets(ctx, AI_VOCAB)


def d_model_dialect(ctx):
    return det_multi(ctx, MODEL_DIALECT_RXS)


def d_promo(ctx):
    out = dets(ctx, PROMO_RX) + dets(ctx, PROMO_LEADING)
    lead = [s for s in ctx.sents if words_of(s) and words_of(s)[0].lower() in IMPERATIVES]
    if len(lead) >= 3:
        out.extend((-1, -1, clip(s)) for s in lead)
    return out


def d_hyphen_pair(ctx):
    return dets(ctx, HYPHEN_PAIRS)


def d_simple_yet(ctx):
    return dets(ctx, SIMPLE_YET)


def d_adj_chain(ctx):
    out = []
    for m in CHAIN_RE.finditer(ctx.m):
        items = re.split(r',\s*(?:and\s+)?|\s+and\s+', m.group(0))
        adj = [x for x in items if x.lower() in STOCK_ADJ or ADJ_SUFFIX_RE.search(x)]
        if adj and len(items) >= 4:
            out.append(m.span())
    return out


def d_synonyms(ctx):
    out = []
    for cluster in SYN_RX:
        found = [w for w, rx in cluster if rx.search(ctx.m)]
        if len(found) >= 3:
            out.append((-1, -1, ', '.join(found)))
    return out


def d_sig_inflation(ctx):
    return det_multi(ctx, SIG_RXS)


def d_notability(ctx):
    return dets(ctx, NOTABILITY_CREDIT) + dets(ctx, NOTABILITY_FOLLOWERS) + dets(ctx, NOTABILITY_STOCK)


def d_vague(ctx):
    return dets(ctx, VAGUE_RX)


def d_article_title(ctx):
    return dets_rx(ctx, ARTICLE_TITLE_RX)


def dets_rx(ctx, rx):
    return [m.span() for m in rx.finditer(ctx.m)]


def d_conservation(ctx):
    return dets(ctx, CONSERVATION_RX)


def d_false_range(ctx):
    return det_multi(ctx, FALSE_RANGE_RXS)


def d_ing_tail(ctx):
    return dets(ctx, ING_TAIL_RX)


def d_parallel(ctx):
    return det_multi(ctx, PARALLEL_RXS)


def d_tailing_neg(ctx):
    return dets(ctx, TAILING_NEG_RX)


def d_not_x_just_y(ctx):
    return det_multi(ctx, NOT_X_JUST_Y_RXS)


def d_filler(ctx):
    return dets(ctx, FILLER_RX)


def d_empty_pivot(ctx):
    return dets(ctx, EMPTY_PIVOT_RX)


def d_outcome(ctx):
    return dets(ctx, OUTCOME_TAIL_RX)


def d_authority(ctx):
    return dets(ctx, AUTHORITY_TROPES)


def d_editorial(ctx):
    return dets(ctx, EDITORIAL_RX)


def d_self_thorough(ctx):
    return dets(ctx, SELF_THOROUGH_RX)


def d_qa(ctx):
    return [m.span() for m in QA_RX.finditer(ctx.m)]


def d_concrete(ctx):
    return dets(ctx, CONCRETE_RX)


def d_intro_hooks(ctx):
    return det_multi(ctx, INTRO_HOOK_RXS)


def d_challenges(ctx):
    return det_multi(ctx, CHALLENGES_RXS)


def d_transitions(ctx):
    out = []
    for para in ctx.paras:
        hits = list(TRANSITION_RX.finditer(para))
        if len(hits) >= 2:
            # locate the paragraph in the masked text for the sample
            base = ctx.m.find(para)
            for h in hits:
                out.append((base + h.start(1), base + h.end(1)))
    return out


def d_conclusion(ctx):
    return dets(ctx, CONCLUSION_LINE_RX)


def d_positive_concl(ctx):
    return det_multi(ctx, POSITIVE_CONCL_RXS)




def d_monotony(ctx):
    lens = [len(words_of(s)) for s in ctx.sents]
    if len(lens) >= 3:
        v = cv(lens)
        if v is not None and v < 0.35:
            return [(-1, -1, 'sentence lengths ' + ','.join(str(x) for x in lens[:8]))]
    return []


def d_alternation(ctx):
    lens = [len(words_of(s)) for s in ctx.sents]
    out = []
    run = 0
    prev = 0
    for i in range(1, len(lens)):
        d = lens[i] - lens[i - 1]
        big = abs(d) >= 5
        sign = (d > 0) - (d < 0)
        if big and prev and sign == -prev:
            run += 1
        elif big:
            run = 1
        else:
            run = 0
        prev = sign if big else 0
        if run == 5:  # six sentences in strict alternation
            out.append((-1, -1, 'alternating sentence lengths ' + ','.join(str(x) for x in lens[i - 5:i + 1])))
    return out


def d_opener_repetition(ctx):
    out = []
    for para in ctx.paras:
        sents = split_sentences(para)
        if len(sents) < 3:
            continue
        openers = {}
        for s in sents:
            ws = [w.lower() for w in words_of(s)[:2]]
            if len(ws) == 2:
                openers.setdefault(' '.join(ws), 0)
                openers[' '.join(ws)] += 1
        for k, n in openers.items():
            if n >= 3:
                out.append((-1, -1, 'opener "%s" x%d' % (k, n)))
    return out


def d_uniform_para(ctx):
    counts = [len(words_of(p)) for p in ctx.paras]
    counts = [c for c in counts if c > 0]
    if len(counts) >= 4:
        v = cv(counts)
        if v is not None and v < 0.4:
            return [(-1, -1, 'paragraph word counts ' + ','.join(str(c) for c in counts[:8]))]
    return []


def d_semicolon(ctx):
    if ctx.word_count < 300:
        return []
    if ';' in ctx.m:
        return []
    if ctx.m.count('(') > 1:
        return []
    return [(-1, -1, 'no semicolons, almost no parentheses')]


def d_chatbot(ctx):
    return det_multi(ctx, CHATBOT_RXS)


def d_sycophant(ctx):
    return det_multi(ctx, SYCOPHANT_RXS)


def d_cutoff(ctx):
    return det_multi(ctx, CUTOFF_RXS)


def d_copula(ctx):
    return det_multi(ctx, COPULA_RXS)


def d_hedges(ctx):
    out = []
    for s in ctx.sents:
        if len(HEDGE_RX.findall(s)) >= 2:
            out.append((-1, -1, clip(s)))
    return out


def d_contraction(ctx):
    words = ctx.words
    if len(words) < 20:
        return []
    fp = sum(1 for w in words if w.lower() in FIRST_PERSON)
    if fp / len(words) < 0.03:
        return []
    full = len(FULL_FORM_RX.findall(ctx.m))
    contr = len(CONTRACTION_RX.findall(ctx.m))
    if full >= 3 and full / (full + contr) >= 0.8:
        return [(-1, -1, '%d uncontracted forms' % full)] * 1
    return []


def d_bold(ctx):
    return dets(ctx, BOLD_RX)


def d_emoji(ctx):
    return [m.span() for m in EMOJI_RX.finditer(ctx.m)]


def d_em_dash(ctx):
    out = []
    for para in ctx.paras:
        if para.count('—') >= 2:
            out.append((-1, -1, clip(para)))
    return out


def d_title_case(ctx):
    out = []
    for m in HEADING_RE.finditer(ctx.m):
        text = m.group(1)
        if not text or not text[0].isalpha() or text.upper() == text:
            continue
        words = re.findall(r"[A-Za-z][A-Za-z'’-]*", text)
        if len(words) < 3:
            continue
        major = [w for w in words if w.lower() not in MINOR_WORDS]
        if len(major) >= 2 and all(w[0].isupper() for w in major):
            out.append(m.span())
    return out


def d_curly(ctx):
    return [m.span() for m in CURLY_RX.finditer(ctx.m)]


def d_year_range(ctx):
    return [m.span() for m in YEAR_RANGE_RX.finditer(ctx.m)]


def d_placeholder(ctx):
    return det_multi(ctx, PLACEHOLDER_RXS)


def d_chat_markup(ctx):
    return det_multi(ctx, CHAT_MARKUP_RXS)


def d_utm(ctx):
    out = []
    for m in UTM_RX.finditer(ctx.m):
        if m.group(1).rstrip('.').lower() in UTM_DOMAINS:
            out.append(m.span())
    return out


def d_slop(ctx):
    return dets(ctx, SLOP_RX)


def d_rules(ctx):
    lines = ctx.m.split('\n')
    spans = [m.span() for m in RULE_LINE_RX.finditer(ctx.m)]
    if len(spans) >= 3 and len(lines) >= 24:
        return spans
    return []


def d_bullet_injection(ctx):
    if re.search(r'(?m)^[ \t]{0,3}#{1,6}[ \t]', ctx.m):
        return []
    bullet = re.compile(r'^\s*(?:[-*+]|\d+[.)])\s+\S')
    list_paras = 0
    prose = 0
    for para in ctx.paras:
        lines = [ln for ln in para.split('\n') if ln.strip()]
        if not lines:
            continue
        if all(bullet.match(ln) for ln in lines):
            list_paras += 1
        else:
            prose += 1
    if list_paras >= 1 and prose >= 2:
        return [(-1, -1, 'bullet block between prose paragraphs')] * list_paras
    return []


def d_fragmented_headers(ctx):
    lines = ctx.m.split('\n')
    out = []
    for i, ln in enumerate(lines):
        m = re.match(r'^[ \t]{0,3}#{1,6}[ \t]+(.+?)[ \t]*#*[ \t]*$', ln)
        if not m:
            continue
        head_words = {w.lower() for w in words_of(m.group(1)) if len(w) >= 4 and w.lower() not in STOP_SHORT}
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if not nxt or re.match(r'^(#|[-*+>|]|\d+[.)]\s)', nxt):
            continue
        nw = words_of(nxt)
        if 0 < len(nw) <= 5 and any(w.lower() in head_words for w in nw):
            out.append((-1, -1, clip(nxt)))
    return out



def d_degenerate(ctx):
    words = [w.lower() for w in ctx.words]
    n = len(words)
    if n < 12:
        return []
    grams = [tuple(words[i:i + 6]) for i in range(n - 5)]
    counts = {}
    for g in grams:
        counts[g] = counts.get(g, 0) + 1
    repeated = sum(1 for g in grams if counts[g] > 1)
    if repeated and repeated / len(grams) >= 0.2:
        return [(-1, -1, 'repeated six-word runs')] * repeated
    return []


def d_diff_anchored(ctx):
    rxs = [
        RX(r'\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b'),
        RX(r'\bthe\s+(?:latest\s+|new\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b'),
        RX(r'\bthis\s+(?:latest\s+|new\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b'),
        RX(r'\b(?:has|have)\s+been\s+(?:updated|refactored|improved|enhanced|changed\s+to)\b'),
        RX(r'\bpreviously\b[^.!?\n]{0,120}?\bnow\b'),
        RX(r"\bwas(?:n['’]t|\s+not)\s+there\s+before\b|\bwere(?:n['’]t|\s+not)\s+there\s+before\b"),
        RX(r"\bwe(?:['’]ve|\s+have)\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b"),
    ]
    return det_multi(ctx, rxs)


def d_signposting(ctx):
    rx = RX(r"\blet['’]s\s+(?:dive|delve|explore)\b|\blet['’]s\s+break\s+(?:this|it)\s+down\b"
            r"|\bhere['’]s\s+what\s+you\s+need\s+to\s+know\b|\bwithout\s+further\s+ado\b"
            r"|\bnow\s+let['’]s\s+look\s+at\b|\bbuckle\s+up\b|\bstay\s+with\s+me\b|\b(?:are\s+you\s+)?ready\s+to\s+dive\s+in\b")
    return dets(ctx, rx)


def d_cataloguing(ctx):
    rxs = [
        RX(r'\b(?:used|uses|employs?|employed|relied\s+on|utilizes)\s+(?:several|various|a\s+number\s+of|multiple|different|many|numerous)\s+\w+'),
        RX(r'\bThese\s+(?:\w+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help)\s+(?:information|insight|understanding|details|data)\b', 0),
        RX(r'\b(?:is|are|was|were|remains|becomes)\s+(?:the\s+|a\s+)?(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b', 0),
    ]
    return det_multi(ctx, rxs)



# Build detector table: (number, key slug, label, detector, score_moving, min_hits)
DETECTORS = [
    (1, 'ai_vocabulary', 'AI vocabulary', d_ai_vocab, True, 1),
    (2, 'model_dialect', 'model-dialect vocabulary', d_model_dialect, True, 2),
    (3, 'promotional_language', 'promotional language', d_promo, True, 1),
    (4, 'hyphenated_pairs', 'hyphenated word-pair overuse', d_hyphen_pair, False, 1),
    (5, 'simple_yet', '"simple yet X" cliche', d_simple_yet, True, 1),
    (6, 'adjective_chains', 'stacked adjective chains', d_adj_chain, True, 1),
    (8, 'synonym_cycling', 'synonym cycling', d_synonyms, True, 1),
    (10, 'significance_inflation', 'significance inflation', d_sig_inflation, True, 1),
    (11, 'notability_name_dropping', 'notability name-dropping', d_notability, True, 1),
    (12, 'vague_attributions', 'vague attributions', d_vague, True, 1),
    (13, 'article_title_proper_noun', 'article title used as a proper noun', d_article_title, True, 1),
    (14, 'conservation_padding', 'conservation / ecosystem padding', d_conservation, True, 1),
    (15, 'false_ranges', 'false ranges', d_false_range, True, 1),
    (16, 'ing_tails', 'superficial -ing tail clauses', d_ing_tail, True, 1),
    (18, 'not_x_just_y', '"Not X, just Y" construction', d_not_x_just_y, True, 1),
    (19, 'filler_phrases', 'filler phrases', d_filler, False, 1),
    (20, 'empty_pivots', 'empty pivot phrases', d_empty_pivot, True, 1),
    (21, 'outcome_tails', 'outcome-speculation tails', d_outcome, True, 1),
    (22, 'authority_tropes', 'persuasive authority tropes', d_authority, False, 1),
    (23, 'editorial_interjections', 'editorial interjections', d_editorial, True, 1),
    (24, 'self_thoroughness', 'self-thoroughness phrases', d_self_thorough, True, 1),
    (25, 'question_answer', 'question-answer rhetorical pattern', d_qa, True, 1),
    (26, 'concrete_evidence', '"concrete evidence" defense phrase', d_concrete, True, 1),
    (27, 'intro_hooks', 'compulsive intro hooks', d_intro_hooks, True, 1),
    (30, 'diff_anchored', 'diff-anchored writing', d_diff_anchored, True, 1),
    (31, 'signposting', 'signposting and announcements', d_signposting, True, 1),
    (32, 'cataloguing_leadins', 'cataloguing lead-ins', d_cataloguing, True, 1),
    (33, 'inline_header_lists', 'inline-header vertical list', lambda c: dets(c, INLINE_HEADER_RX), True, 1),
    (34, 'bullet_injection', 'mid-essay bullet injection', d_bullet_injection, True, 1),
    (35, 'fragmented_headers', 'fragmented header', d_fragmented_headers, True, 1),
    (36, 'formulaic_challenges', 'formulaic challenges section', d_challenges, True, 1),
    (37, 'transition_cluster', 'transition-word cluster', d_transitions, True, 1),
    (38, 'compulsive_conclusions', 'compulsive conclusion phrase', d_conclusion, True, 1),
    (39, 'generic_positive_conclusion', 'generic positive conclusion', d_positive_concl, True, 1),
    (40, 'sentence_monotony', 'sentence-length monotony', d_monotony, True, 1),
    (41, 'mechanical_alternation', 'mechanical sentence-length alternation', d_alternation, False, 1),
    (42, 'opener_repetition', 'opener repetition', d_opener_repetition, False, 1),
    (44, 'uniform_paragraphs', 'uniform paragraph length', d_uniform_para, True, 1),
    (46, 'semicolon_underuse', 'semicolon and parenthesis underuse', d_semicolon, False, 1),
    (47, 'chatbot_artifacts', 'chatbot artifacts', d_chatbot, True, 1),
    (48, 'sycophantic_tone', 'sycophantic tone', d_sycophant, True, 1),
    (50, 'knowledge_cutoff', 'knowledge-cutoff disclaimer', d_cutoff, True, 1),
    (51, 'copula_avoidance', 'copula avoidance', d_copula, True, 1),
    (54, 'hedge_stacking', 'hedge stacking', d_hedges, False, 1),
    (55, 'contraction_absence', 'contraction absence', d_contraction, False, 1),
    (56, 'boldface_overuse', 'boldface overuse', d_bold, True, 1),
    (57, 'emoji', 'emoji', d_emoji, True, 1),
    (58, 'em_dash_overuse', 'em-dash overuse', d_em_dash, False, 1),
    (59, 'title_case_headings', 'title case in headings', d_title_case, True, 1),
    (60, 'curly_quotes', 'curly quotation marks', d_curly, False, 1),
    (61, 'year_range_hyphen', 'hyphen used for en dash in year ranges', d_year_range, False, 1),
    (63, 'placeholder_text', 'placeholder text', d_placeholder, True, 1),
    (64, 'chat_reference_markup', 'chatbot reference-markup leak', d_chat_markup, True, 1),
    (65, 'utm_tracking', 'AI tracking parameter', d_utm, True, 1),
    (69, 'marketing_slop', 'canonical marketing-slop phrase', d_slop, True, 1),
    (70, 'decorative_rules', 'decorative horizontal rules', d_rules, True, 1),
    (71, 'degenerate_repetition', 'degenerate repetition', d_degenerate, True, 1),
]
# Family 17 has two forms, reported as separate findings.
DETECTORS.append((17, 'negative_parallelism', 'negative parallelism', d_parallel, False, 1))
DETECTORS.append((17, 'tailing_negation', 'tailing negation', d_tailing_neg, True, 1))

ADVICE_NUMBERS = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
RHYTHM = {40, 44, 41, 55}
SHORT_FLOOR_SET = set(range(1, 40)) | set(range(47, 52)) | {69}
PHRASES = {
    'clean': 'reads clean',
    'light tells': 'reads mostly clean',
    'mixed': 'reads with some AI tells',
    'heavy tells': 'reads with heavy AI tells',
    'pervasive tells': 'reads with pervasive AI tells',
}


def band_of(score):
    if score <= 20:
        return 'clean'
    if score <= 40:
        return 'light tells'
    if score <= 60:
        return 'mixed'
    if score <= 80:
        return 'heavy tells'
    return 'pervasive tells'


def sample_for(ctx, span, n, label_fallback):
    if len(span) == 3:
        return clip(span[2])
    s, e = span
    if s < 0:
        return label_fallback
    raw = ctx.w[s:e] if e > s else ctx.w[s:s + 1]
    return clip(raw)


def analyze(window, full_len, ci=False):
    ctx = Ctx(window)
    rtl = ctx.rtl
    invis, nonstd, homo = char_layer(window, rtl)
    report = {}
    fam_hits = {}      # number -> hits for score-moving families
    slug_used = set()

    # Character layer (62, 66, 67, 68)
    layer_findings = []
    if invis:
        samples = []
        for i in invis[:3]:
            samples.append('U+%04X at offset %d' % (ord(window[i]), i))
        layer_findings.append((62, 'invisible_characters', 'invisible / zero-width characters', len(invis), samples))
    if homo:

        layer_findings.append((66, 'homoglyphs', 'homoglyph / mixed-script lookalikes', homo, ['mixed-script token']))
    if nonstd:
        layer_findings.append((67, 'nonstandard_spaces', 'non-standard spaces', nonstd, ['non-standard space']))
    trailing = count_trailing_ws(window)
    if trailing:
        layer_findings.append((68, 'trailing_whitespace', 'trailing / stray whitespace', trailing, ['trailing whitespace']))

    for number, slug, label, count, samples in layer_findings:
        key = '%d_%s' % (number, slug)
        report[key] = {'label': label, 'count': count, 'samples': samples[:3]}
        if number in DECISIVE or number not in ADVICE_NUMBERS:
            fam_hits[number] = count

    for number, slug, label, fn, score_moving, min_hits in DETECTORS:
        spans = fn(ctx)
        count = len(spans)
        if count < min_hits or count == 0:
            continue
        samples = []
        for sp in spans[:3]:
            samples.append(sample_for(ctx, sp, 3, label))
        key = '%d_%s' % (number, slug)
        report[key] = {'label': label, 'count': count, 'samples': samples}
        if score_moving and number not in ADVICE_NUMBERS:
            fam_hits[number] = fam_hits.get(number, 0) + count

    # Score-moving families (17 counts once; tailing form is score-moving).
    fams = {n: h for n, h in fam_hits.items() if h > 0 and n not in ADVICE_NUMBERS}
    # Decisive set limited to actual score-moving families (62/66/67 are fine; 67 is not decisive).
    fam_nums = set(fams)
    decisive_fams = fam_nums & DECISIVE

    # Raw points per family.
    points = 0
    for n, h in fams.items():
        if n in DECISIVE:
            pts = min(18, 10 + 2 * (h - 1))
        else:
            pts = min(12, 6 + 2 * (h - 1))
        points += pts
    raw = min(100, points)

    n_fam = len(fam_nums)
    if n_fam == 1:
        raw = min(raw, 40)
    if fam_nums and fam_nums <= {40, 44}:
        raw = min(raw, 20 if fam_nums == {40} else 40)

    score = raw
    words = ctx.word_count
    if words < 120:
        short_n = len(fam_nums & SHORT_FLOOR_SET)
        if short_n >= 3:
            score = max(score, 45)
        elif short_n >= 2:
            score = max(score, 25)
    if words >= 400:
        if n_fam >= 6:
            score = max(score, 45)
        elif n_fam >= 5:
            score = max(score, 25)

    # Confidence
    if words < 40:
        confidence = 'none'
        reason = 'fewer than 40 words'
    elif words < 120:
        confidence = 'low'
        reason = 'fewer than 120 words'
    elif words < 300 and n_fam <= 1:
        confidence = 'low'
        reason = 'fewer than 300 words with only one score-moving pattern family'
    elif words < 300:
        confidence = 'moderate'
        reason = 'fewer than 300 words'
    else:
        confidence = 'high'
        reason = ''

    if len(decisive_fams) >= 2:
        score = max(score, 65)
    elif len(decisive_fams) == 1 and confidence in ('moderate', 'high'):
        score = max(score, 45)

    score = max(0, min(100, int(score)))
    band = band_of(score)

    scanned = len(window)
    metrics = {
        'scanned_chars': scanned,
        'truncated': full_len > WINDOW,
        'ai_tell_score': score,
        'ai_tell_band': band,
        'confidence': confidence,
        'confidence_reason': reason,
        'patterns_flagged': len(report),
        'invisible_chars': len(invis),
        'nonstandard_spaces': nonstd,
        'homoglyphs': homo,
    }
    if ci:
        n = len(ctx.sents)
        if n >= 4:
            half = min(15, max(2, round(30 / math.sqrt(n))))
            metrics['score_ci'] = [max(0, score - half), min(100, score + half)]
            metrics['score_ci_note'] = ('heuristic interval of +/-%d points from %d sentences; '
                                        'not a resampled estimate' % (half, n))
        else:
            metrics['score_ci'] = None
            metrics['score_ci_note'] = 'too few sentences (%d; need at least 4) for an interval' % n


    report['_metrics'] = metrics
    return report


# ---------------------------------------------------------------- CLI

def _err(msg):
    sys.stderr.buffer.write((json.dumps({'error': msg}, ensure_ascii=False) + '\n').encode('utf-8'))
    sys.stderr.flush()


def _out(s):
    sys.stdout.buffer.write(s.encode('utf-8'))
    sys.stdout.flush()


def main(argv):
    clean = False
    ci = False
    operands = []
    end = False
    for a in argv:
        if end:
            operands.append(a)
            continue
        if a == '--':
            end = True
            continue
        if a in ('-h', '--help'):
            _out(USAGE)
            return 0
        if a == '--clean':
            clean = True
            continue
        if a == '--ci':
            ci = True
            continue
        if a.startswith('-'):
            _err("unknown option '%s'; see --help" % a)
            return 2
        operands.append(a)

    if operands:
        path = operands[0]
        if len(operands) > 1:
            sys.stderr.buffer.write(('prosecheck: note: only the first file was scanned: %s\n' % path)
                                    .encode('utf-8'))
        try:
            with open(path, 'rb') as fh:
                data = fh.read()
        except Exception:
            _err('cannot read input: %s' % path)
            return 1
        ext = os.path.splitext(path)[1].lower()
    else:
        data = sys.stdin.buffer.read()
        ext = ''

    try:
        text = extract(data, ext)
    except CannotRead as exc:
        _err('cannot read input: %s' % exc)
        return 1
    text = normalize_newlines(text)
    if text.strip() == '':
        _err('empty input')
        return 1

    if clean:
        _out(scrub(text))
        return 0

    window = text[:WINDOW]
    report = analyze(window, len(text), ci=ci)
    _out(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    return 0


if __name__ == '__main__':
    try:
        code = main(sys.argv[1:])
    except SystemExit:
        raise
    except Exception:
        _err('cannot read input: internal error')
        code = 1
    sys.exit(code)
