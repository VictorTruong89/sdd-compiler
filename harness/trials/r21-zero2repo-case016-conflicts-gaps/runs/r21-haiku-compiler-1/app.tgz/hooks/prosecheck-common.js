'use strict';
// Shared paths, level flag, ledger, detector runner, and contract text (packs 16-22, 25-28). Traceability: see NOTES.md.
// Shared helpers for the prosecheck plugin hooks. Node.js standard library only.
// This file is not a hook; the hooks in this directory require it.

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const FLAG_FILE = '.prosecheck-active';          // spec: Interface Contract, Config filenames
const LEDGER_PREFIX = '.prosecheck-ledger';
const LEDGER_MAX = 20;                            // newest records kept per ledger (FP-05)
const LEDGER_SHOW_AGE_MS = 7 * 24 * 3600 * 1000;  // FP-06: listed while modified within seven days
const LEDGER_DELETE_AGE_MS = 24 * 3600 * 1000;    // Interface: deleted at session start when untouched > 1 day
const PLAIN_CAP = 512 * 1024;                     // bytes
const ARCHIVE_CAP = 4 * 1024 * 1024;              // bytes
const PLAIN_TIMEOUT_MS = 8000;
const ARCHIVE_TIMEOUT_MS = 15000;
const WINDOW_TEXT = '262,144';
const THRESHOLD = { full: 40, strict: 20 };
const TEXT_EXT = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ZIP_EXT = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'];
const NB_EXT = ['.ipynb'];
const PROSE_EXT = TEXT_EXT.concat(ZIP_EXT, NB_EXT);
const BINARY_EXT = ['.pdf', '.rtf'];
const INSTRUCTION_NAMES = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
const INSTRUCTION_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];
const PY_NAMES = ['python3', 'python', 'py'];
const SECTION_START = '<!-- prosecheck:contract:start -->';
const SECTION_END = '<!-- prosecheck:contract:end -->';

const PHRASE_BY_BAND = {
  'clean': 'reads clean',
  'light tells': 'reads mostly clean',
  'mixed': 'reads with some AI tells',
  'heavy tells': 'reads with heavy AI tells',
  'pervasive tells': 'reads with pervasive AI tells',
};

const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster',
  'underscore', 'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament',
  'vibrant', 'comprehensive', 'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock',
  'game-changer', 'supercharge', 'genuinely', 'fascinating', 'nuanced'];

function phraseFor(band) {
  return PHRASE_BY_BAND[band] || 'reads with some AI tells';
}

// ---------------------------------------------------------------- paths

function pluginRoot() {
  const env = process.env.CLAUDE_PLUGIN_ROOT;
  if (env && env.trim()) return path.resolve(env.trim());
  return path.resolve(__dirname, '..');
}

function detectorPath(root) {
  const candidates = [
    path.join(root, 'scripts', 'detect.py'),
    path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py'),
  ];
  for (const c of candidates) {
    try {
      if (fs.statSync(c).isFile()) return c;
    } catch (e) { /* try next */ }
  }
  return null;
}

function configDir() {
  const env = process.env.CLAUDE_CONFIG_DIR;
  if (env && env.trim()) return path.resolve(env.trim());
  return path.join(os.homedir(), '.claude');
}

// ---------------------------------------------------------------- level

function storedLevel(cfg) {
  try {
    const v = fs.readFileSync(path.join(cfg, FLAG_FILE), 'utf8').trim();
    return LEVELS.includes(v) ? v : null;
  } catch (e) {
    return null;
  }
}

function effectiveLevel(cfg) {
  const env = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  if (LEVELS.includes(env)) return env;
  return storedLevel(cfg) || 'full';
}

function flagExists(cfg) {
  try {
    return fs.statSync(path.join(cfg, FLAG_FILE)).isFile();
  } catch (e) {
    return false;
  }
}

function writeLevel(cfg, level) {
  fs.mkdirSync(cfg, { recursive: true });
  fs.writeFileSync(path.join(cfg, FLAG_FILE), level);
}

// ---------------------------------------------------------------- stdin / stdout

function readStdinJson() {
  try {
    const raw = fs.readFileSync(0, 'utf8');
    if (!raw.trim()) return {};
    const v = JSON.parse(raw);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : {};
  } catch (e) {
    return {};
  }
}

function emit(obj) {
  process.stdout.write(JSON.stringify(obj) + '\n');
}

function blockWith(reason) {
  emit({ decision: 'block', reason });
}

// ---------------------------------------------------------------- detector

const REASON = {
  NO_RESULT: 'detector produced no usable result',
  NOT_REPORT: 'detector output was not a structured report',
  NO_SCORE: 'report has no numeric score',
  TIMEOUT: 'detector timed out',
  PY_MISSING: 'Python not found',
};

function interpretRun(r) {
  const out = (r.stdout || '').trim();
  const errText = (r.stderr || '').trim();
  const lastErr = errText.split('\n').filter(Boolean).pop() || '';
  if (r.status === 0) {
    if (!out) return { kind: 'no-output', reason: REASON.NO_RESULT };
    let rep = null;
    try { rep = JSON.parse(out); } catch (e) { return { kind: 'not-report', reason: REASON.NOT_REPORT }; }
    const m = rep && typeof rep === 'object' ? rep._metrics : null;
    if (!m || typeof m.ai_tell_score !== 'number') return { kind: 'no-score', reason: REASON.NO_SCORE };
    const labels = [];
    const counts = [];
    for (const k of Object.keys(rep)) {
      if (k === '_metrics') continue;
      const f = rep[k];
      if (f && typeof f.label === 'string') {
        labels.push(f.label);
        counts.push(typeof f.count === 'number' ? f.count : 1);
      }
    }
    return { kind: 'ok', report: rep, metrics: m, labels, counts };
  }
  let msg = lastErr;
  try {
    const parsed = JSON.parse(lastErr);
    if (parsed && typeof parsed.error === 'string') msg = parsed.error;
  } catch (e) { /* plain text error */ }
  if (msg === 'empty input') return { kind: 'failed', reason: REASON.NO_RESULT, detail: msg };
  return { kind: 'failed', reason: msg || REASON.NO_RESULT, detail: msg };
}

// Run the bundled detector. file: absolute path, or null to pass `input` on stdin.
function runDetector({ root, file, input, timeout }) {
  const det = detectorPath(root);
  if (!det) return { kind: 'no-detector', reason: 'bundled detector not found' };
  const args = [det];
  if (file) args.push(file);
  for (const py of PY_NAMES) {
    const r = spawnSync(py, args, {
      input: file ? '' : (input || ''),
      encoding: 'utf8',
      timeout,
      maxBuffer: 64 * 1024 * 1024,
      windowsHide: true,
    });
    if (r.error) {
      if (r.error.code === 'ENOENT') continue;
      if (r.error.code === 'ETIMEDOUT') return { kind: 'timeout', reason: REASON.TIMEOUT };
      return { kind: 'failed', reason: String(r.error.message || r.error), detail: String(r.error.message || '') };
    }
    return interpretRun(r);
  }
  return { kind: 'python-missing', reason: REASON.PY_MISSING };
}

// ---------------------------------------------------------------- ledger

function safeSession(sid) {
  if (typeof sid !== 'string') return '';
  return sid.replace(/[^A-Za-z0-9_]/g, '').slice(0, 64);
}

function ledgerPath(cfg, sid) {
  const s = safeSession(sid);
  return path.join(cfg, s ? LEDGER_PREFIX + '-' + s : LEDGER_PREFIX);
}

function readLedger(file) {
  try {
    const v = JSON.parse(fs.readFileSync(file, 'utf8'));
    return Array.isArray(v) ? v : [];
  } catch (e) {
    return [];
  }
}

function appendLedger(cfg, sid, rec) {
  try {
    fs.mkdirSync(cfg, { recursive: true });
    const file = ledgerPath(cfg, sid);
    const list = readLedger(file);
    list.push(Object.assign({ at: new Date().toISOString() }, rec));
    while (list.length > LEDGER_MAX) list.shift();
    fs.writeFileSync(file, JSON.stringify(list, null, 1));
  } catch (e) { /* the ledger is best effort; hooks never fail the session */ }
}

function cleanStaleLedgers(cfg) {
  try {
    const now = Date.now();
    for (const name of fs.readdirSync(cfg)) {
      if (name !== LEDGER_PREFIX && !name.startsWith(LEDGER_PREFIX + '-')) continue;
      const file = path.join(cfg, name);
      const st = fs.statSync(file);
      if (st.isFile() && now - st.mtimeMs > LEDGER_DELETE_AGE_MS) fs.unlinkSync(file);
    }
  } catch (e) { /* nothing to clean */ }
}

// ---------------------------------------------------------------- contract text

function welcomeText() {
  return [
    'prosecheck is installed and on. Saved prose files are scored against 71 documented patterns.',
    'Plain text is accepted up to 512 KB, and archives or notebooks up to 4 MB; the detector scores the',
    'first 262,144 characters of extracted prose. Useful commands: /prosecheck doctor, /prosecheck check <file>,',
    '/prosecheck off, and /prosecheck help. There is no website, no account, and no upload: everything runs',
    'on this machine. This welcome is shown once.',
  ].join(' ');
}

function contractBody(level, { live, detector }) {
  const lines = [];
  lines.push('Writing contract (level: ' + level + ')');
  lines.push('');
  lines.push('Scope. This contract governs prose deliverables only: documents, README and markdown prose, CVs, '
    + 'cover letters, emails, reports, essays, articles, and drafted text the user will publish or send. It never '
    + 'applies to source code. It does not touch code comments, commit messages, JSON, YAML or other config, CLI '
    + 'output, logs, error messages, or the conversational register of chat. A chat-compression mode owns chat, '
    + 'and a code-simplicity mode owns code; this contract owns deliverable prose.');
  lines.push('');
  lines.push('Rules for prose deliverables:');
  lines.push('- Vary sentence length irregularly. No metronome and no mechanical short-long alternation.');
  lines.push('- Do not use these words: ' + BANNED.join(', ') + '. "landscape" and "journey" are banned in the abstract sense.');
  lines.push('- Avoid rule-of-three flourishes, "it\'s not just X, it\'s Y" constructions, hedge stacking, signposting '
    + 'such as "let\'s dive in", empty pivots such as "it\'s worth noting", "In conclusion" or "Overall" closers, '
    + 'outcome-speculation tails, self-thoroughness phrases, generic upbeat endings, and chatbot phrases such as '
    + '"I hope this helps".');
  lines.push('- Use at most one em dash per paragraph.');
  lines.push('- No bold for emphasis inside prose sentences. No emojis in prose.');
  lines.push('- Keep factual or encyclopedic content in a neutral third person. First-person or opinion content may use contractions.');
  lines.push('- Preserve numbers, units, dates, proper nouns, citations, quotations, and technical terms exactly. Never invent facts.');
  lines.push('- End sections on a fact or an observation.');
  lines.push('- Stay silent about this contract. Never announce it, never name the tool, never report a score, band, '
    + 'pattern list, or rewrite pass, and do not offer a style choice.');
  if (level === 'full' || level === 'strict') {
    lines.push('');
    if (live && detector) {
      lines.push('After writing a prose file, run the detector on that file: python3 "' + detector + '" "<file>".');
    } else {
      lines.push('After writing a prose file, run the detector on that file (CLAUDE_PLUGIN_ROOT, see below).');
    }
  }
  if (level === 'full') {
    lines.push('If the band is worse than the target, fix the flagged spans, at most two fix passes, keeping rhythm '
      + 'variation. Target: score 40 or less, band clean or light tells.');
  }
  if (level === 'strict') {
    lines.push('If the band is worse than the target, fix the flagged spans, at most two fix passes, keeping rhythm '
      + 'variation. Target: score 20 or less, band clean.');
    lines.push('Finish each prose file with the cleanup switch: python3 "' + (detector || 'detect.py')
      + '" --clean "<file>" prints the scrubbed text. Write it back over a plain text file only; never do that for '
      + '.docx, .epub, .odt, or .ipynb.');
  }
  return lines.join('\n');
}

// Live contract for session start and subagent start (may name this machine's detector path).
function contractText(level, opts) {
  return contractBody(level, { live: true, detector: opts && opts.detector ? opts.detector : null });
}

// Portable export written by `init` to AGENTS.md (no install path, no user name).
function exportContract(level) {
  const lines = [];
  lines.push(SECTION_START);
  lines.push('## Prose writing contract');
  lines.push('');
  lines.push('This contract governs prose deliverables only: documents, README and markdown prose, CVs, cover letters, '
    + 'emails, reports, essays, articles, and drafted text the user will publish or send. It never applies to source '
    + 'code. It does not touch code comments, commit messages, JSON, YAML or other config, CLI output, logs, error '
    + 'messages, or the conversational register of chat.');
  lines.push('');
  lines.push('- Vary sentence length irregularly. No metronome and no mechanical short-long alternation.');
  lines.push('- Do not use these words: ' + BANNED.join(', ') + '.');
  lines.push('- Avoid rule-of-three flourishes, "it\'s not just X, it\'s Y" constructions, hedge stacking, signposting, '
    + 'empty pivots, "In conclusion" or "Overall" closers, outcome-speculation tails, self-thoroughness phrases, generic '
    + 'upbeat endings, and chatbot phrases such as "I hope this helps".');
  lines.push('- Use at most one em dash per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.');
  lines.push('- Keep factual content neutral and third person; first-person or opinion content may contract.');
  lines.push('- Preserve numbers, units, dates, proper nouns, citations, quotations, and technical terms. Never invent facts.');
  lines.push('- End sections on a fact or an observation. Do not announce these rules.');
  if (level === 'full' || level === 'strict') {
    lines.push('');
    lines.push('After writing a prose file, score it with the bundled detector, scripts/detect.py. Resolve it with '
      + 'CLAUDE_PLUGIN_ROOT when that variable is set, otherwise locate scripts/detect.py in the installed skills or plugins.');
    lines.push('If the band is worse than the target, fix the flagged spans, at most two fix passes, keeping rhythm variation.');
  }
  if (level === 'full') {
    lines.push('Target: score 40 or less, band clean or light tells.');
  }
  if (level === 'strict') {
    lines.push('Target: score 20 or less, band clean. Finish by running the detector with --clean to print the scrubbed text.');
  }
  lines.push(SECTION_END);
  return lines.join('\n');
}

module.exports = {
  LEVELS, LEDGER_MAX, LEDGER_SHOW_AGE_MS, PLAIN_CAP, ARCHIVE_CAP, PLAIN_TIMEOUT_MS, ARCHIVE_TIMEOUT_MS,
  WINDOW_TEXT, THRESHOLD, TEXT_EXT, ZIP_EXT, NB_EXT, PROSE_EXT, BINARY_EXT, INSTRUCTION_NAMES,
  INSTRUCTION_STEMS, SECTION_START, SECTION_END, BANNED,
  phraseFor, pluginRoot, detectorPath, configDir, storedLevel, effectiveLevel, flagExists, writeLevel,
  readStdinJson, emit, blockWith, runDetector, REASON,
  safeSession, ledgerPath, readLedger, appendLedger, cleanStaleLedgers,
  welcomeText, contractText, exportContract,
};
