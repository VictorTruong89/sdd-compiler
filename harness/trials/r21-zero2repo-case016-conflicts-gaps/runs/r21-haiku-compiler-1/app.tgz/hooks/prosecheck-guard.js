#!/usr/bin/env node
'use strict';
// Implements FP-05 saved-file guard and the post-tool-use reply (packs 14, 24, 29, 30). Traceability: see NOTES.md.
// prosecheck post-tool-use hook: the saved-file guard (FP-05).
// Fires after Write, Edit, MultiEdit, NotebookEdit, or apply_patch. Scores each
// just-saved prose file with the bundled detector and nudges when it is flagged.
// Always exits 0; prints nothing unless a file is flagged.

const fs = require('fs');
const path = require('path');
const common = require('./prosecheck-common.js');

const MAX_PATHS = 10;   // interface: at most ten paths of one apply_patch payload are scored
const PATCH_RX = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/;

function patchPaths(command) {
  const out = [];
  for (const raw of command.split('\n')) {
    const m = PATCH_RX.exec(raw.replace(/\r$/, ''));
    if (m) {
      const p = m[1].trim();
      if (p && !out.includes(p)) out.push(p);
    }
  }
  return out;
}

function candidatePaths(toolInput) {
  const paths = [];
  if (typeof toolInput.file_path === 'string' && toolInput.file_path.trim()) {
    paths.push(toolInput.file_path.trim());
  }
  if (typeof toolInput.notebook_path === 'string' && toolInput.notebook_path.trim()) {
    paths.push(toolInput.notebook_path.trim());
  }
  if (typeof toolInput.command === 'string') {
    for (const p of patchPaths(toolInput.command)) paths.push(p);
  }
  return paths.slice(0, MAX_PATHS);
}

function isSkipped(resolved, root) {
  const segments = resolved.split(/[\\/]/);
  if (segments.includes('node_modules') || segments.includes('.git')) return true;
  const rootWithSep = root.endsWith(path.sep) ? root : root + path.sep;
  if (resolved === root || resolved.startsWith(rootWithSep)) return true;
  const base = path.basename(resolved).toLowerCase();
  const ext = path.extname(base);
  const stem = ext ? base.slice(0, -ext.length) : base;
  if (common.INSTRUCTION_NAMES.includes(base)) return true;
  if (common.INSTRUCTION_STEMS.includes(stem) && !common.PROSE_EXT.includes(ext)) return true;
  return false;
}

function labelsOf(run) {
  return run.labels.slice(0, 5);
}

function scoreOne(p, cwd, root, cfg, sid, level, lines) {
  const resolved = path.isAbsolute(p) ? path.normalize(p) : path.resolve(cwd, p);
  if (isSkipped(resolved, root)) return;
  const base = path.basename(resolved);
  const ext = path.extname(resolved).toLowerCase();
  const isArchive = common.ZIP_EXT.includes(ext) || common.NB_EXT.includes(ext);
  const isProse = common.PROSE_EXT.includes(ext);
  const isBinary = common.BINARY_EXT.includes(ext);
  if (!isProse && !isBinary) return;             // other extensions: no nudge, no record

  let st;
  try {
    st = fs.statSync(resolved);
  } catch (e) {
    common.appendLedger(cfg, sid, { kind: 'failed', base, reason: 'cannot read the file (not found or unreadable)' });
    return;
  }
  if (!st.isFile()) return;                      // directories and other non-files are ignored

  if (isBinary) {
    common.appendLedger(cfg, sid, { kind: 'binary', base });
    return;
  }
  const cap = isArchive ? common.ARCHIVE_CAP : common.PLAIN_CAP;
  if (st.size > cap) {
    common.appendLedger(cfg, sid, { kind: 'skipped', base, limitKB: Math.floor(cap / 1024) });
    return;
  }
  const run = common.runDetector({
    root, file: resolved, timeout: isArchive ? common.ARCHIVE_TIMEOUT_MS : common.PLAIN_TIMEOUT_MS,
  });
  if (run.kind !== 'ok') {
    common.appendLedger(cfg, sid, { kind: 'failed', base, reason: run.reason });
    return;
  }
  const m = run.metrics;
  const threshold = common.THRESHOLD[level];
  const flagged = m.ai_tell_score > threshold;
  const labels = labelsOf(run);
  common.appendLedger(cfg, sid, {
    kind: 'scored', base, score: m.ai_tell_score, band: m.ai_tell_band,
    phrase: common.phraseFor(m.ai_tell_band), labels, flagged, truncated: !!m.truncated,
  });
  if (!flagged) return;
  const coverage = m.truncated ? ', first ' + common.WINDOW_TEXT + ' characters only' : '';
  lines.push('prosecheck: ' + base + ' ' + common.phraseFor(m.ai_tell_band) + ' (score ' + m.ai_tell_score
    + ', band ' + m.ai_tell_band + coverage + '). Flagged: ' + (labels.join('; ') || 'none listed')
    + '. Fix the flagged spans, keeping rhythm variation; at most two fix passes.');
}

function main() {
  const payload = common.readStdinJson();
  const cfg = common.configDir();
  const level = common.effectiveLevel(cfg);
  if (level !== 'full' && level !== 'strict') return;   // off and lite do not score
  const root = common.pluginRoot();
  const toolInput = payload.tool_input && typeof payload.tool_input === 'object' ? payload.tool_input : {};
  const cwd = typeof payload.cwd === 'string' && payload.cwd.trim() ? payload.cwd.trim() : process.cwd();
  const sid = payload.session_id;
  const paths = candidatePaths(toolInput);
  if (!paths.length) return;                    // no path named: nothing recorded, no nudge
  const lines = [];
  for (const p of paths) {
    scoreOne(p, cwd, root, cfg, sid, level, lines);
  }
  if (lines.length) {
    common.emit({
      hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
    });
  }
}

if (require.main === module) {
  try {
    main();
  } catch (e) {
    // hooks never fail the host session
  }
  process.exitCode = 0;
}

module.exports = { patchPaths, candidatePaths, isSkipped };
