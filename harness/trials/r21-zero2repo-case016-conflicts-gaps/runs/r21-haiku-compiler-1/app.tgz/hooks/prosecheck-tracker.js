#!/usr/bin/env node
'use strict';
// Implements FP-04 prompt reminder and FP-06 /prosecheck router (packs 13, 15, 31-38). Traceability: see NOTES.md.
// prosecheck prompt-submit hook and /prosecheck command router.
// Reads the host JSON object on stdin. Always exits 0.

const fs = require('fs');
const path = require('path');
const common = require('./prosecheck-common.js');
const stats = require('./prosecheck-stats.js');

const SUBCOMMANDS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];
const CMD_RX = /^\/prosecheck(:prosecheck)?(?=\s|$)/i;
const STOP_RX = /^(stop prosecheck|prosecheck off)$/i;
const DAY = 24 * 3600 * 1000;

// ---------------------------------------------------------------- help

function helpReply(form, level) {
  return [
    'prosecheck: live level is ' + level + '.',
    'Commands (type them as /prosecheck <word>):',
    '/prosecheck lite - writing contract only: contract on, no scoring of saved files.',
    '/prosecheck full - contract plus the saved-file guard, threshold 40 (default).',
    '/prosecheck strict - saved-file guard, threshold 20, plus the cleanup scrub.',
    '/prosecheck off | on - off turns the tool off (disable); on turns it back on (re-enable, full).',
    '/prosecheck status - one line naming the stored level.',
    '/prosecheck show - this session\'s scored files, newest first.',
    '/prosecheck check <path> - score one file; it is a report only and does not rewrite the file.',
    '/prosecheck doctor - health check of the install.',
    '/prosecheck stats - token use for this session and the score of its own prose.',
    '/prosecheck init - writes the contract into AGENTS.md for agents other than Claude Code.',
    'Code, commits, config, and chat are always left alone; prosecheck never touches them.',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

// ---------------------------------------------------------------- status

function statusReply(level) {
  return 'prosecheck status: level is ' + level + '.';
}

// ---------------------------------------------------------------- show

function showReply(cfg, sid, form) {
  const file = common.ledgerPath(cfg, sid);
  let fresh = true;
  try {
    const st = fs.statSync(file);
    if (Date.now() - st.mtimeMs > common.LEDGER_SHOW_AGE_MS) fresh = false;
  } catch (e) {
    fresh = false;
  }
  const recs = fresh ? common.readLedger(file) : [];
  if (!recs.length) {
    return 'nothing scored yet in this session. Rows appear after prose files, such as .docx and .pdf deliverables, are saved.';
  }
  const lines = ['Files in this session, newest first:'];
  for (const r of recs.slice().reverse()) {
    lines.push(rowFor(r));
  }
  return lines.join('\n');
}

function rowFor(r) {
  const base = r.base || '(unknown file)';
  if (r.kind === 'scored') {
    let body = r.phrase + ' (score ' + r.score + '/' + r.band
      + (r.truncated ? ', first ' + common.WINDOW_TEXT + ' characters only' : '') + ')';
    if (r.labels && r.labels.length) {
      body += ' - ' + (r.flagged ? 'flagged' : 'under threshold') + ': ' + r.labels.slice(0, 5).join('; ');
    }
    return base + ' - ' + body;
  }
  if (r.kind === 'skipped') {
    return base + ' - not scored: over ' + r.limitKB + ' KB limit';
  }
  if (r.kind === 'binary') {
    return base + ' - binary file, not re-scored';
  }
  return base + ' - not scored: ' + (r.reason || common.REASON.NO_RESULT);
}

// ---------------------------------------------------------------- check

function checkReply(rawArg, root, cwd) {
  let p = (rawArg || '').trim();
  if (p.startsWith('@')) p = p.slice(1);
  if (p.length >= 2 && ((p[0] === '"' && p[p.length - 1] === '"') || (p[0] === "'" && p[p.length - 1] === "'"))) {
    p = p.slice(1, -1);
  }
  if (!p) {
    return 'prosecheck check needs a file path: /prosecheck check <path>. No file was scored or changed.';
  }
  const resolved = path.isAbsolute(p) ? p : path.resolve(cwd, p);
  const base = path.basename(resolved);
  const ext = path.extname(resolved).toLowerCase();
  let st;
  try {
    st = fs.statSync(resolved);
  } catch (e) {
    return 'cannot read ' + p + ': file not found. The file was not changed.';
  }
  if (st.isDirectory() || !st.isFile()) {
    return p + ' is not a file. The file was not changed.';
  }
  if (common.BINARY_EXT.includes(ext)) {
    return base + ': no readable text (' + ext + ' is not scored). The file was not changed.';
  }
  const isArchive = common.ZIP_EXT.includes(ext) || common.NB_EXT.includes(ext);
  const cap = isArchive ? common.ARCHIVE_CAP : common.PLAIN_CAP;
  if (st.size > cap) {
    return base + ': over ' + Math.floor(cap / 1024) + ' KB, too large to score. The file was not changed.';
  }
  const run = common.runDetector({
    root, file: resolved, timeout: isArchive ? common.ARCHIVE_TIMEOUT_MS : common.PLAIN_TIMEOUT_MS,
  });
  switch (run.kind) {
    case 'ok': {
      const m = run.metrics;
      const lines = [];
      lines.push(base + ' - ' + common.phraseFor(m.ai_tell_band) + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')');
      let conf = 'confidence: ' + m.confidence;
      if (m.confidence !== 'high' && m.confidence_reason) conf += ' - ' + m.confidence_reason;
      lines.push(conf);
      if (m.truncated) lines.push('coverage: first ' + common.WINDOW_TEXT + ' characters only');
      if (run.labels.length) {
        const items = run.labels.slice(0, 8).map((l, i) => l + ' (x' + run.counts[i] + ')');
        lines.push('tells: ' + items.join('; '));
      } else {
        lines.push('tells: none');
      }
      lines.push('This is a report only; the file was not rewritten.');
      return lines.join('\n');
    }
    case 'python-missing':
      return base + ': detector unavailable (Python not found). The file was not changed.';
    case 'timeout':
      return base + ': failed (the detector timed out). The file was not changed.';
    case 'no-output':
      return base + ': no report (the detector printed nothing). The file was not changed.';
    case 'not-report':
    case 'no-score':
      return 'no report: the detector printed text that is not a structured report. The file was not changed.';
    default: {
      const detail = run.detail ? ' ' + run.detail : '';
      return base + ': failed.' + detail + ' The file was not changed.';
    }
  }
}

// ---------------------------------------------------------------- doctor

function writable(dir) {
  try {
    fs.mkdirSync(dir, { recursive: true });
    const probe = path.join(dir, '.prosecheck-probe-' + process.pid);
    fs.writeFileSync(probe, 'ok');
    fs.unlinkSync(probe);
    return true;
  } catch (e) {
    return false;
  }
}

function doctorReply(form, cfg, root) {
  const eff = common.effectiveLevel(cfg);
  const lines = ['prosecheck doctor'];
  let allOk = true;
  let modeOk = true;

  // (1) mode
  if (eff === 'off') {
    modeOk = false;
    lines.push('mode: off - this is not a fault of the install; run /prosecheck on to switch scoring back on.');
  } else {
    lines.push('[OK] mode: ' + eff);
  }

  // (2) detector
  const det = common.detectorPath(root);
  let detOk = !!det;
  if (det) {
    lines.push('[OK] detector: bundled scripts/detect.py found at ' + det);
  } else {
    lines.push('detector: bundled scripts/detect.py is missing from the plugin tree.');
  }

  // (3) python
  const sample = 'Doctor check. This short sentence confirms that the detector runs.';
  const run = common.runDetector({ root, input: sample, timeout: common.PLAIN_TIMEOUT_MS });
  let pyOk = false;
  if (run.kind === 'ok') {
    pyOk = true;
    lines.push('[OK] python: Python ran the bundled detector and returned score ' + run.metrics.ai_tell_score + '.');
  } else if (run.kind === 'python-missing') {
    lines.push('python not found: the detector cannot run, so saved files are not re-scored until Python is '
      + 'available. prose is still shaped by the writing contract.');
  } else {
    lines.push('python: Python ran but the detector did not return a numeric score (' + run.reason + ').');
  }

  // (4) settings
  const settingsOk = writable(cfg);
  if (settingsOk) {
    lines.push('[OK] settings: the settings folder ' + cfg + ' is writable.');
  } else {
    lines.push('settings: the settings folder ' + cfg + ' is not writable.');
  }

  allOk = modeOk && detOk && pyOk && settingsOk;
  const otherOk = detOk && pyOk && settingsOk;

  // closer
  if (allOk && eff !== 'off') {
    lines.push('prosecheck is active. Limits: plain text up to 512 KB, archives and notebooks up to 4 MB, and only the '
      + 'first ' + common.WINDOW_TEXT + ' characters are scored. Run ' + form + ' show to see files that were only partly '
      + 'scanned or skipped.');
  } else if (!otherOk || (!modeOk && eff !== 'off')) {
    lines.push('Some checks need attention. Fix the faulty checks above, then run /prosecheck doctor again.');
  } else {
    lines.push('Install is healthy. While prosecheck is off, saved files are not scored. Run ' + form + ' on to turn scoring back on.');
  }
  return lines.join('\n');
}

// ---------------------------------------------------------------- init

const CONTRACT_SECTION_MARK = common.SECTION_START;

function initReply(form, cfg, root, cwd) {
  const eff = common.effectiveLevel(cfg);
  if (eff === 'off') {
    return 'prosecheck is switched off, so no files were written. Run ' + form + ' on to allow the export.';
  }
  const lines = [];
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = '';
  let readErr = null;
  try {
    existing = fs.readFileSync(agents, 'utf8');
  } catch (e) {
    if (e.code !== 'ENOENT') readErr = e;
  }
  if (readErr) {
    lines.push('AGENTS.md: cannot read it (' + readErr.code + '), so the contract was not written.');
  } else if (existing.includes(CONTRACT_SECTION_MARK)) {
    lines.push('AGENTS.md already contains the prosecheck contract, so it was not duplicated.');
  } else {
    try {
      const sep = existing.length === 0 ? '' : (existing.endsWith('\n') ? '\n' : '\n\n');
      fs.writeFileSync(agents, existing + sep + common.exportContract(eff) + '\n');
      lines.push('AGENTS.md: the writing contract was added (' + eff + ' level).');
    } catch (e) {
      lines.push('AGENTS.md: cannot write it (' + (e.code || e.message) + '), so the contract was not written.');
    }
  }

  const src = path.join(root, '.cursor', 'rules', 'prosecheck.mdc');
  const dstDir = path.join(cwd, '.cursor', 'rules');
  const dst = path.join(dstDir, 'prosecheck.mdc');
  if (fs.existsSync(dst)) {
    lines.push('.cursor/rules/prosecheck.mdc already exists; it was left unchanged.');
  } else {
    try {
      fs.mkdirSync(dstDir, { recursive: true });
      fs.copyFileSync(src, dst);
      lines.push('.cursor/rules/prosecheck.mdc: the Cursor rule was copied.');
    } catch (e) {
      lines.push('cannot write .cursor/rules/prosecheck.mdc (' + (e.code || e.message) + '); the rule was not created.');
    }
  }
  return lines.join('\n');
}

// ---------------------------------------------------------------- router

function route(sub, arg, form, ctx) {
  const cfg = ctx.cfg;
  switch (sub) {
    case '':
    case 'help':
      return helpReply(form, common.effectiveLevel(cfg));
    case 'lite':
    case 'full':
    case 'strict':
      common.writeLevel(cfg, sub);
      return 'prosecheck level set to ' + sub + '. The writing contract applies at ' + sub + ' level.';
    case 'off':
      common.writeLevel(cfg, 'off');
      return 'prosecheck is off. Saved files are not scored. Run ' + form + ' on to switch it back on.';
    case 'on':
      common.writeLevel(cfg, 'full');
      return 'prosecheck is on (full). Saved prose files are scored again.';
    case 'status':
      return statusReply(common.effectiveLevel(cfg));
    case 'show':
      return showReply(cfg, ctx.sid, form);
    case 'check':
      return checkReply(arg, ctx.root, ctx.cwd);
    case 'doctor':
      return doctorReply(form, cfg, ctx.root);
    case 'stats':
      return stats.statsReply({ transcriptPath: ctx.transcriptPath, cfg, level: common.effectiveLevel(cfg), root: ctx.root });
    case 'init':
      return initReply(form, cfg, ctx.root, ctx.cwd);
    default:
      return 'prosecheck: unknown subcommand "' + sub + '". Valid subcommands: ' + SUBCOMMANDS.join(', ')
        + '. The stored level is unchanged.';
  }
}

function main() {
  const payload = common.readStdinJson();
  const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
  const trimmed = prompt.trim();
  const cfg = common.configDir();
  const root = common.pluginRoot();
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();

  const m = CMD_RX.exec(trimmed);
  if (m) {
    const form = m[0];
    const rest = trimmed.slice(m[0].length).trim();
    const parts = rest.split(/\s+/);
    const sub = (parts[0] || '').toLowerCase();
    const arg = rest.slice((parts[0] || '').length).trim();
    const reply = route(sub, arg, form, {
      cfg, root, cwd, sid: payload.session_id, transcriptPath: payload.transcript_path,
    });
    common.blockWith(reply);
    return;
  }

  if (STOP_RX.test(trimmed)) {
    common.writeLevel(cfg, 'off');
    common.blockWith('prosecheck is off. Saved files are not scored. Run /prosecheck on to switch it back on.');
    return;
  }

  const level = common.effectiveLevel(cfg);
  if (level === 'off') return;
  common.emit({
    hookSpecificOutput: {
      hookEventName: 'UserPromptSubmit',
      additionalContext: 'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.',
    },
  });
}

if (require.main === module) {
  try {
    main();
  } catch (e) {
    // Hooks must never fail the host session.
  }
  process.exitCode = 0;
}

module.exports = { route, checkReply, doctorReply, showReply, helpReply, rowFor, SUBCOMMANDS };
