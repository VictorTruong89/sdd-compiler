#!/usr/bin/env node
'use strict';
// Implements FP-06 stats (packs 15, 39, 40). Traceability: see NOTES.md.
// prosecheck stats: token figures from a session transcript and, when the
// assistant prose is long enough, the detector score of that prose.
// Used by the /prosecheck stats subcommand (prosecheck-tracker.js). Also runnable
// as a hook: reads the host JSON on stdin and prints a block decision.

const fs = require('fs');
const path = require('path');
const common = require('./prosecheck-common.js');

const PROSE_SLICE = 40000;    // last characters of assistant prose that are scored
const SCORE_MIN_CHARS = 500;  // the session score is printed only above this length

function newestTranscript(cfg) {
  const projects = path.join(cfg, 'projects');
  let best = null;
  const walk = (dir, depth) => {
    if (depth > 6) return;
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (e) {
      return;
    }
    for (const ent of entries) {
      const full = path.join(dir, ent.name);
      if (ent.isDirectory()) {
        walk(full, depth + 1);
      } else if (ent.isFile() && ent.name.endsWith('.jsonl')) {
        try {
          const st = fs.statSync(full);
          if (!best || st.mtimeMs > best.mtime) best = { file: full, mtime: st.mtimeMs };
        } catch (e) { /* skip */ }
      }
    }
  };
  walk(projects, 0);
  return best ? best.file : null;
}

// Returns { turns, outputTokens, cacheRead, prose } or null when unreadable.
function readTranscript(file) {
  let raw;
  try {
    raw = fs.readFileSync(file, 'utf8');
  } catch (e) {
    return null;
  }
  const seen = new Map();   // message id -> { usage, texts }
  let rowNo = 0;
  for (const line of raw.split('\n')) {
    rowNo += 1;
    if (!line.trim()) continue;
    let row;
    try { row = JSON.parse(line); } catch (e) { continue; }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const id = typeof msg.id === 'string' && msg.id ? msg.id : 'row-' + rowNo;
    if (!seen.has(id)) seen.set(id, { usage: null, texts: [] });
    const entry = seen.get(id);
    if (msg.usage && typeof msg.usage === 'object') entry.usage = msg.usage;
    if (Array.isArray(msg.content) && entry.texts.length === 0) {
      for (const part of msg.content) {
        if (part && part.type === 'text' && typeof part.text === 'string') entry.texts.push(part.text);
      }
    }
  }
  let outputTokens = 0;
  let cacheRead = 0;
  const prose = [];
  for (const entry of seen.values()) {
    if (entry.usage) {
      outputTokens += Number(entry.usage.output_tokens) || 0;
      cacheRead += Number(entry.usage.cache_read_input_tokens) || 0;
    }
    for (const t of entry.texts) prose.push(t);
  }
  return { turns: seen.size, outputTokens, cacheRead, prose: prose.join('\n') };
}

function statsReply({ transcriptPath, cfg, level, root }) {
  let file = null;
  if (typeof transcriptPath === 'string' && transcriptPath.trim()) {
    file = transcriptPath.trim();
  } else {
    file = newestTranscript(cfg);
  }
  const data = file ? readTranscript(file) : null;
  if (!data) {
    return 'No readable transcript was found for this session, so no token figures are shown.\nlevel: ' + level;
  }
  const lines = [
    'Session stats',
    'level: ' + level,
    'assistant turns: ' + data.turns,
    'output tokens: ' + data.outputTokens,
    'cache-read input tokens: ' + data.cacheRead,
  ];
  let slice = data.prose.replace(/```[\s\S]*?```/g, ' ');
  if (slice.length > PROSE_SLICE) slice = slice.slice(slice.length - PROSE_SLICE);
  slice = slice.trim();
  if (slice.length > SCORE_MIN_CHARS) {
    const run = common.runDetector({ root, input: slice, timeout: common.PLAIN_TIMEOUT_MS });
    if (run.kind === 'ok') {
      lines.push('session prose ai_tell_score: ' + run.metrics.ai_tell_score);
    } else {
      lines.push('session prose score: unavailable (' + run.reason + ')');
    }
  }
  return lines.join('\n');
}

module.exports = { statsReply, readTranscript, newestTranscript };

if (require.main === module) {
  try {
    const payload = common.readStdinJson();
    const cfg = common.configDir();
    const reply = statsReply({
      transcriptPath: payload.transcript_path,
      cfg,
      level: common.effectiveLevel(cfg),
      root: common.pluginRoot(),
    });
    common.blockWith(reply);
  } catch (e) {
    // hooks never fail the host session
  }
  process.exitCode = 0;
}
