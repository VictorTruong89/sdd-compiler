#!/usr/bin/env node
'use strict';
// Implements FP-04 subagent start (packs 13, 23). Traceability: see NOTES.md.
// prosecheck subagent-start hook. Returns the same writing contract as session
// start inside the JSON envelope the host keeps for a subagent-start event.
// Stored level off: prints nothing. Always exits 0.

const common = require('./prosecheck-common.js');

function main() {
  common.readStdinJson();
  const cfg = common.configDir();
  const root = common.pluginRoot();
  const level = common.effectiveLevel(cfg);
  if (level === 'off') return;
  common.emit({
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: common.contractText(level, { detector: common.detectorPath(root) }),
    },
  });
}

if (require.main === module) {
  try {
    main();
  } catch (e) {
    // hooks never fail the host session
  }
  process.exitCode = 0;
}

module.exports = { main };
