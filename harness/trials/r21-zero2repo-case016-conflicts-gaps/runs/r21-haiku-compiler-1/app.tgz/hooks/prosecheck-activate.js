#!/usr/bin/env node
'use strict';
// Implements FP-04 session start (packs 13, 22). Traceability: see NOTES.md.
// prosecheck session-start hook. Prints the writing contract as plain text.
// On the first start of a fresh install (no mode flag yet) the welcome comes first.
// Always exits 0. Stored level off: prints nothing.

const common = require('./prosecheck-common.js');

function main() {
  common.readStdinJson();                       // host JSON; not needed beyond validation
  const cfg = common.configDir();
  const root = common.pluginRoot();
  const firstRun = !common.flagExists(cfg);
  const level = common.effectiveLevel(cfg);
  if (firstRun) {
    try { common.writeLevel(cfg, level); } catch (e) { /* unwritable settings: contract still shown */ }
  }
  common.cleanStaleLedgers(cfg);
  if (level === 'off') return;
  const parts = [];
  if (firstRun) parts.push(common.welcomeText());
  parts.push(common.contractText(level, { detector: common.detectorPath(root) }));
  process.stdout.write(parts.join('\n\n') + '\n');
}

if (require.main === module) {
  try {
    main();
  } catch (e) {
    // hooks never fail the host session
  }
  process.exitCode = 0;
}

module.exports = { main };
