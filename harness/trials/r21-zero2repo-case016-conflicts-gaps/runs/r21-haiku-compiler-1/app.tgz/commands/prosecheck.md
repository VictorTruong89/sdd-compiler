---
description: prosecheck operator commands (levels, status, show, check, doctor, stats, init, help)
argument-hint: [lite|full|strict|off|on|status|show|check <path>|doctor|stats|init|help]
---
/prosecheck $ARGUMENTS
