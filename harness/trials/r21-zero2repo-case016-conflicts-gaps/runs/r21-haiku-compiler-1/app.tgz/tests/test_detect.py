"""Tests for scripts/detect.py. Run: python3 -m unittest discover -s /app/tests -v"""
import json
import os
import random
import subprocess
import sys
import tempfile
import unittest

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DETECT = os.path.join(ROOT, 'scripts', 'detect.py')
sys.path.insert(0, os.path.join(ROOT, 'scripts'))
import detect  # noqa: E402


def run(args, data=b''):
    if isinstance(data, str):
        data = data.encode('utf-8')
    p = subprocess.run([sys.executable, DETECT] + args, input=data, capture_output=True)
    return p.returncode, p.stdout.decode('utf-8', 'replace'), p.stderr.decode('utf-8', 'replace')


HUMAN = ("We walked the river path on Saturday. The water was low, so the rocks near the weir were dry and warm. "
         "My brother got ahead of us and waited by the old mill. He pointed at a heron that did not move for ten "
         "minutes.\n\nWe stopped for lunch under the willow. The bread was stale, honestly, but the cheese was good. "
         "Nobody talked much. I think we were all tired from the week, and the sun made everyone quiet.\n\n"
         "On the way back the path flooded near the footbridge. We took the lane instead and got muddy. It was fine. "
         "We laughed about it later, which is more than I can say for the car.")

AI = ("# Unlocking the Power of Collaborative Innovation\n\nIn today's fast-paced world, organizations must navigate a "
      "complex landscape. It's not just about technology, it's about people. Delve into this tapestry of ideas, and "
      "you'll discover a vibrant ecosystem.\n\nFurthermore, the solution is robust, seamless, and scalable. Moreover, "
      "it fosters growth. However, challenges remain. Additionally, stakeholders must leverage these insights to "
      "elevate outcomes.\n\nIn conclusion, this comprehensive guide underscores the pivotal role of collaboration. "
      "The future looks bright! I hope this helps. Let me know if you need anything else.")


class ScoringRules(unittest.TestCase):
    def test_bands(self):
        self.assertEqual(detect.band_of(0), 'clean')
        self.assertEqual(detect.band_of(20), 'clean')
        self.assertEqual(detect.band_of(21), 'light tells')
        self.assertEqual(detect.band_of(41), 'mixed')
        self.assertEqual(detect.band_of(61), 'heavy tells')
        self.assertEqual(detect.band_of(81), 'pervasive tells')

    def test_single_score_family_capped_at_40(self):
        self.assertLessEqual(detect._score({1: 50}, 1000), 40)

    def test_rhythm_only_is_capped(self):
        self.assertLessEqual(detect._score({40: 1}, 1000), 20)
        self.assertLessEqual(detect._score({40: 1, 44: 1}, 1000), 40)

    def test_two_decisive_families_floor_65(self):
        self.assertGreaterEqual(detect._score({47: 1, 50: 1}, 1000), 65)

    def test_single_decisive_floor_needs_confidence(self):
        self.assertGreaterEqual(detect._score({47: 1, 1: 1, 2: 1}, 500), 45)
        self.assertLess(detect._score({47: 1}, 30), 45)

    def test_short_document_floor(self):
        self.assertGreaterEqual(detect._score({1: 1, 10: 1, 12: 1}, 100), 45)
        self.assertGreaterEqual(detect._score({1: 1, 10: 1}, 100), 25)

    def test_advice_has_no_weight(self):
        r, _ = detect.analyze(HUMAN + "\n\nIt's worth noting - with a dash - and 2010-2012 here.")
        self.assertEqual(r['_metrics']['ai_tell_score'], 0)

    def test_confidence_levels(self):
        self.assertEqual(detect._confidence(10, 1)[0], 'none')
        self.assertEqual(detect._confidence(100, 1)[0], 'low')
        self.assertEqual(detect._confidence(200, 1)[0], 'low')
        self.assertEqual(detect._confidence(200, 2)[0], 'moderate')
        self.assertEqual(detect._confidence(300, 2)[0], 'high')


class Report(unittest.TestCase):
    def test_human_text_is_clean_and_reports_metrics(self):
        code, out, err = run([], HUMAN)
        self.assertEqual(code, 0, err)
        rep = json.loads(out)
        m = rep['_metrics']
        self.assertEqual(m['ai_tell_score'], 0)
        self.assertEqual(m['ai_tell_band'], 'clean')
        self.assertFalse(m['truncated'])
        self.assertIn(m['confidence'], ('none', 'low', 'moderate', 'high'))

    def test_ai_text_flags_families_with_keys_and_labels(self):
        code, out, _ = run([], AI)
        rep = json.loads(out)
        keys = [k for k in rep if k != '_metrics']
        self.assertIn('1_ai_vocabulary', keys)
        self.assertIn('47_chatbot_artifacts', keys)
        self.assertGreater(rep['_metrics']['ai_tell_score'], 40)
        for k in keys:
            self.assertLessEqual(len(rep[k]['samples']), 3)
        labels = [rep[k]['label'] for k in keys]
        self.assertEqual(len(labels), len(set(labels)))

    def test_nine_catalogue_numbers_never_appear(self):
        _, out, _ = run([], AI + " Certainly! Nested [TBD] text. " * 3)
        for key in json.loads(out):
            num = key.split('_', 1)[0]
            if num.isdigit():
                self.assertNotIn(int(num), detect.NO_DETECTOR)

    def test_empty_input_error(self):
        code, out, err = run([], '   \n')
        self.assertEqual(code, 1)
        self.assertEqual(out, '')
        self.assertEqual(json.loads(err.strip().splitlines()[-1]), {'error': 'empty input'})

    def test_unknown_option_exit_2(self):
        code, out, err = run(['--bogus'])
        self.assertEqual(code, 2)
        self.assertEqual(out, '')
        msg = json.loads(err.strip().splitlines()[-1])['error']
        self.assertIn('unknown option', msg)
        self.assertIn('--bogus', msg)
        self.assertIn('--help', msg)

    def test_unreadable_path(self):
        code, out, err = run(['/no/such/file.md'])
        self.assertEqual(code, 1)
        self.assertTrue(json.loads(err.strip().splitlines()[-1])['error'].startswith('cannot read input:'))

    def test_help_usage_first_line(self):
        code, out, _ = run(['--help'])
        self.assertEqual(code, 0)
        self.assertEqual(out.splitlines()[0], 'usage: detect.py [--clean] [--ci] [--] [FILE]')

    def test_two_files_scan_first_and_notice(self):
        with tempfile.TemporaryDirectory() as d:
            a = os.path.join(d, 'a.md')
            b = os.path.join(d, 'b.md')
            with open(a, 'w') as f:
                f.write(HUMAN)
            with open(b, 'w') as f:
                f.write(AI)
            code, out, err = run([a, b])
            self.assertEqual(code, 0)
            self.assertEqual(json.loads(out)['_metrics']['ai_tell_score'], 0)
            self.assertIn(a, err)

    def test_dash_filename_after_double_dash(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, '-odd.md')
            with open(p, 'w') as f:
                f.write(HUMAN)
            code, out, err = run(['--', p])
            self.assertEqual(code, 0, err)

    def test_ci_interval_and_null_when_short(self):
        code, out, _ = run(['--ci'], AI)
        m = json.loads(out)['_metrics']
        self.assertIn('score_ci', m)
        code, out, _ = run(['--ci'], 'Only one sentence here.')
        m = json.loads(out)['_metrics']
        self.assertIsNone(m['score_ci'])
        self.assertIn('too few sentences', m['score_ci_note'])

    def test_window_truncation(self):
        text = 'word ' * 60000 + 'a​'
        m = json.loads(run([], text)[1])['_metrics']
        self.assertTrue(m['truncated'])
        self.assertEqual(m['scanned_chars'], 262144)
        self.assertEqual(m['invisible_chars'], 0)

    def test_code_fence_and_inline_code_are_not_prose(self):
        text = "Plain prose here. " + "`It's worth noting that` in code.\n```\nIt's worth noting that\n```\n"
        rep = json.loads(run([], text)[1])
        self.assertNotIn('20_empty_pivot', rep)


class Cleanup(unittest.TestCase):
    def clean(self, s):
        code, out, _ = run(['--clean'], s)
        self.assertEqual(code, 0)
        return out

    def test_zero_width_removed_and_nbsp_between_digits_kept(self):
        self.assertEqual(self.clean('a​b'), 'ab')
        self.assertEqual(self.clean('1 000 and x y'), '1 000 and x y')

    def test_trailing_whitespace_and_blank_lines(self):
        self.assertEqual(self.clean('line one   \nline two\t\n\n\n'), 'line one\nline two\n')

    def test_homoglyph_fold(self):
        self.assertEqual(self.clean('tеst'), 'test')
        self.assertEqual(self.clean('Привет world'), 'Привет world')

    def test_rescan_is_clean(self):
        rnd = random.Random(7)
        pool = ['a', 'b', '1', ' ', ' ', '​', '‌', '‍', '﻿', '\xad', '\t', '\n', 'е',
                '\U0001F468', '\U0001F469', '\U000E0020', '\U000E007F', '️', '⃣', ' ', ' ',
                '⁦', '‮', '　', ':', '«', '»', 'ا', '.']
        for _ in range(300):
            s = ''.join(rnd.choice(pool) for _ in range(rnd.randint(5, 120)))
            if not s.strip():
                continue
            out = detect.clean_text(s)
            self.assertEqual(detect.invisible_indices(out), [], repr(s))
            self.assertEqual(detect.nonstandard_space_indices(out), [], repr(s))
            self.assertEqual(detect.homoglyph_runs(out)[0], 0, repr(s))


class Extraction(unittest.TestCase):
    def test_docx_and_bad_zip(self):
        import zipfile
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'doc.docx')
            with zipfile.ZipFile(p, 'w') as z:
                z.writestr('word/document.xml',
                           '<w:document xmlns:w="w"><w:body><w:p><w:r><w:t>Hello there.</w:t></w:r></w:p>'
                           '<w:p><w:r><w:t>Second.</w:t></w:r></w:p></w:body></w:document>')
            code, out, _ = run(['--clean', p])
            self.assertEqual(out, 'Hello there.\nSecond.')
            bad = os.path.join(d, 'bad.docx')
            with open(bad, 'wb') as f:
                f.write(b'nope')
            code, out, err = run([bad])
            self.assertEqual(code, 1)
            self.assertTrue(json.loads(err.strip().splitlines()[-1])['error'].startswith('cannot read input:'))

    def test_notebook_only_markdown_cells(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, 'n.ipynb')
            with open(p, 'w') as f:
                json.dump({'cells': [{'cell_type': 'code', 'source': ['print(1)']},
                                     {'cell_type': 'markdown', 'source': ['Prose cell.']}]}, f)
            code, out, _ = run(['--clean', p])
            self.assertEqual(out, 'Prose cell.')


if __name__ == '__main__':
    unittest.main()
