'use strict';
// Tests for the prosecheck hooks. Run: node --test /app/tests/hooks.test.js
const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const HOOKS = path.resolve(__dirname, '..', 'hooks');

function hook(name, payload, env) {
  const r = spawnSync(process.execPath, [path.join(HOOKS, name)], {
    input: payload === undefined ? '' : (typeof payload === 'string' ? payload : JSON.stringify(payload)),
    encoding: 'utf8',
    env: Object.assign({}, process.env, env),
  });
  assert.strictEqual(r.status, 0, 'hook must exit 0: ' + r.stderr);
  return r.stdout;
}

const AI_TEXT = "# Unlocking the Power of Collaborative Innovation\n\nIn today's fast-paced world, organizations must navigate a "
  + "complex landscape. It's not just about technology, it's about people. Delve into this tapestry of ideas, and "
  + "you'll discover a vibrant ecosystem.\n\nFurthermore, the solution is robust, seamless, and scalable. Moreover, "
  + "it fosters growth. However, challenges remain. Additionally, stakeholders must leverage these insights to "
  + "elevate outcomes.\n\nIn conclusion, this comprehensive guide underscores the pivotal role of collaboration. "
  + "The future looks bright! I hope this helps. Let me know if you need anything else.";

function tmpdir(prefix) {
  return fs.mkdtempSync(path.join(os.tmpdir(), prefix));
}

function reasonOf(out) {
  return JSON.parse(out).reason;
}

test('session start: welcome once, then contract only; off prints nothing', () => {
  const cfg = tmpdir('pc-cfg-');
  const env = { CLAUDE_CONFIG_DIR: cfg, PROSECHECK_DEFAULT_MODE: '' };
  const first = hook('prosecheck-activate.js', {}, env);
  assert.match(first, /prosecheck is installed and on/);
  assert.match(first, /71 documented patterns/);
  assert.match(first, /\/prosecheck doctor/);
  const second = hook('prosecheck-activate.js', {}, env);
  assert.doesNotMatch(second, /prosecheck is installed and on/);
  assert.match(second, /Writing contract/);
  fs.writeFileSync(path.join(cfg, '.prosecheck-active'), 'off');
  assert.strictEqual(hook('prosecheck-activate.js', {}, env), '');
  assert.strictEqual(hook('prosecheck-subagent.js', {}, env), '');
});

test('level-specific contract content', () => {
  const cfg = tmpdir('pc-cfg-');
  const env = { CLAUDE_CONFIG_DIR: cfg };
  fs.writeFileSync(path.join(cfg, '.prosecheck-active'), 'lite');
  const lite = hook('prosecheck-subagent.js', {}, env);
  const ctxLite = JSON.parse(lite).hookSpecificOutput.additionalContext;
  assert.doesNotMatch(ctxLite, /\b40\b/);
  assert.doesNotMatch(ctxLite, /light tells/);
  fs.writeFileSync(path.join(cfg, '.prosecheck-active'), 'strict');
  const ctxStrict = JSON.parse(hook('prosecheck-subagent.js', {}, env)).hookSpecificOutput.additionalContext;
  assert.match(ctxStrict, /--clean/);
  assert.match(ctxStrict, /\b20\b/);
  assert.match(ctxStrict, /source code/);
});

test('prompt router: help, unknown word keeps level, stop phrase, ordinary prompt', () => {
  const cfg = tmpdir('pc-cfg-');
  const env = { CLAUDE_CONFIG_DIR: cfg };
  fs.writeFileSync(path.join(cfg, '.prosecheck-active'), 'full');
  const help = reasonOf(hook('prosecheck-tracker.js', { prompt: '/prosecheck' }, env));
  assert.match(help.split('\n')[0], /full/);
  assert.doesNotMatch(help.split('\n')[0], /\blite\b|\bstrict\b/);
  const unk = reasonOf(hook('prosecheck-tracker.js', { prompt: '/prosecheck:prosecheck frob' }, env));
  assert.match(unk, /unknown/);
  assert.match(unk, /frob/);
  assert.strictEqual(fs.readFileSync(path.join(cfg, '.prosecheck-active'), 'utf8'), 'full');
  const ordinary = JSON.parse(hook('prosecheck-tracker.js', { prompt: 'write a letter' }, env));
  assert.match(ordinary.hookSpecificOutput.additionalContext, /full/);
  const stop = reasonOf(hook('prosecheck-tracker.js', { prompt: 'STOP PROSECHECK' }, env));
  assert.match(stop, /\boff\b/);
  assert.strictEqual(fs.readFileSync(path.join(cfg, '.prosecheck-active'), 'utf8'), 'off');
  assert.strictEqual(hook('prosecheck-tracker.js', { prompt: 'write a letter' }, env), '');
});

test('doctor: four successful checks on a healthy install', () => {
  const cfg = tmpdir('pc-cfg-');
  const env = { CLAUDE_CONFIG_DIR: cfg };
  fs.writeFileSync(path.join(cfg, '.prosecheck-active'), 'full');
  const reason = reasonOf(hook('prosecheck-tracker.js', { prompt: '/prosecheck doctor' }, env));
  const lines = reason.split('\n').filter(Boolean);
  assert.strictEqual(lines.filter((l) => l.includes('[OK]')).length, 4, reason);
  assert.match(lines[lines.length - 1], /512 KB/);
  assert.match(lines[lines.length - 1], /4 MB/);
  assert.match(lines[lines.length - 1], /262,144/);
  assert.match(lines[lines.length - 1], /\/prosecheck show/);
});

test('doctor: missing Python reports python not found and keeps prose line', () => {
  const cfg = tmpdir('pc-cfg-');
  const r = spawnSync(process.execPath, [path.join(HOOKS, 'prosecheck-tracker.js')], {
    input: JSON.stringify({ prompt: '/prosecheck doctor' }),
    encoding: 'utf8',
    env: { CLAUDE_CONFIG_DIR: cfg, PATH: '/nonexistent-dir' },
  });
  const reason = reasonOf(r.stdout);
  assert.match(reason, /python not found/);
  assert.match(reason, /not re-scored/);
  assert.match(reason, /prose/);
});

test('show: empty ledger message, then scored rows newest first; sessions are separate', () => {
  const cfg = tmpdir('pc-cfg-');
  const env = { CLAUDE_CONFIG_DIR: cfg };
  fs.writeFileSync(path.join(cfg, '.prosecheck-active'), 'full');
  const empty = reasonOf(hook('prosecheck-tracker.js', { prompt: '/prosecheck show', session_id: 'abc' }, env));
  assert.match(empty, /nothing scored yet/);
  assert.match(empty, /\.docx/);
  assert.match(empty, /\.pdf/);
  const dir = tmpdir('pc-proj-');
  fs.writeFileSync(path.join(dir, 'notes.md'), 'It is important to note that we delve into the tapestry. Certainly! Let me know if you need more.');
  hook('prosecheck-guard.js', { tool_name: 'Write', tool_input: { file_path: 'notes.md' }, session_id: 'abc', cwd: dir }, env);
  const shown = reasonOf(hook('prosecheck-tracker.js', { prompt: '/prosecheck show', session_id: 'abc' }, env));
  assert.match(shown, /notes\.md - /);
  const other = reasonOf(hook('prosecheck-tracker.js', { prompt: '/prosecheck show', session_id: 'zzz' }, env));
  assert.match(other, /nothing scored yet/);
});

test('guard: flags an AI-styled file, stays silent on clean prose and on lite', () => {
  const cfg = tmpdir('pc-cfg-');
  const dir = tmpdir('pc-proj-');
  const env = { CLAUDE_CONFIG_DIR: cfg };
  fs.writeFileSync(path.join(cfg, '.prosecheck-active'), 'full');
  fs.writeFileSync(path.join(dir, 'ai.md'), AI_TEXT);
  fs.writeFileSync(path.join(dir, 'ok.md'), 'We walked the river on Saturday. The water was low. My brother waited by the mill.');
  const flagged = hook('prosecheck-guard.js', { tool_name: 'Write', tool_input: { file_path: path.join(dir, 'ai.md') }, cwd: dir }, env);
  const ctx = JSON.parse(flagged).hookSpecificOutput.additionalContext;
  assert.match(ctx, /^prosecheck: ai\.md /);
  assert.match(ctx, /fix/i);
  assert.strictEqual(hook('prosecheck-guard.js', { tool_name: 'Write', tool_input: { file_path: path.join(dir, 'ok.md') }, cwd: dir }, env), '');
  fs.writeFileSync(path.join(cfg, '.prosecheck-active'), 'lite');
  assert.strictEqual(hook('prosecheck-guard.js', { tool_name: 'Write', tool_input: { file_path: path.join(dir, 'ai.md') }, cwd: dir }, env), '');
});

test('guard: apply_patch paths are scored one at a time; code files are ignored', () => {
  const cfg = tmpdir('pc-cfg-');
  const dir = tmpdir('pc-proj-');
  const env = { CLAUDE_CONFIG_DIR: cfg };
  fs.writeFileSync(path.join(cfg, '.prosecheck-active'), 'full');
  fs.writeFileSync(path.join(dir, 'ai.md'), AI_TEXT);
  const patch = '*** Begin Patch\n*** Update File: ai.md\n@@\n-x\n+y\n*** Add File: code.py\n*** End Patch';
  const out = hook('prosecheck-guard.js', { tool_name: 'apply_patch', tool_input: { command: patch }, cwd: dir }, env);
  assert.match(JSON.parse(out).hookSpecificOutput.additionalContext, /ai\.md/);
  fs.writeFileSync(path.join(dir, 'code.py'), 'Delve into the tapestry. Certainly! I hope this helps.');
  const py = hook('prosecheck-guard.js', { tool_name: 'Write', tool_input: { file_path: 'code.py' }, cwd: dir }, env);
  assert.strictEqual(py, '');
});

test('init: portable export, idempotent, and nothing written when off', () => {
  const cfg = tmpdir('pc-cfg-');
  const proj = tmpdir('pc-init-');
  const env = { CLAUDE_CONFIG_DIR: cfg };
  fs.writeFileSync(path.join(cfg, '.prosecheck-active'), 'full');
  fs.writeFileSync(path.join(proj, 'AGENTS.md'), '# Team notes\n');
  reasonOf(hook('prosecheck-tracker.js', { prompt: '/prosecheck init', cwd: proj }, env));
  const agents = fs.readFileSync(path.join(proj, 'AGENTS.md'), 'utf8');
  assert.match(agents, /^# Team notes/);
  assert.doesNotMatch(agents, new RegExp(os.homedir().replace(/[.*+?^${}()|[\]\\]/g, '\\$&')));
  assert.ok(fs.existsSync(path.join(proj, '.cursor', 'rules', 'prosecheck.mdc')));
  const again = reasonOf(hook('prosecheck-tracker.js', { prompt: '/prosecheck init', cwd: proj }, env));
  assert.match(again, /already/);
  assert.strictEqual(fs.readFileSync(path.join(proj, 'AGENTS.md'), 'utf8').split('prosecheck:contract:start').length, 2);
  fs.writeFileSync(path.join(cfg, '.prosecheck-active'), 'off');
  const off = tmpdir('pc-init-off-');
  const reason = reasonOf(hook('prosecheck-tracker.js', { prompt: '/prosecheck init', cwd: off }, env));
  assert.match(reason, /switched off/);
  assert.ok(!fs.existsSync(path.join(off, 'AGENTS.md')));
});

test('stats: named transcript counts assistant turns and tokens', () => {
  const cfg = tmpdir('pc-cfg-');
  const dir = tmpdir('pc-tr-');
  const file = path.join(dir, 't.jsonl');
  const rows = [
    { type: 'user', message: { content: 'hi' } },
    { type: 'assistant', message: { id: 'a1', usage: { output_tokens: 10, cache_read_input_tokens: 100 }, content: [{ type: 'text', text: 'Short reply.' }] } },
    { type: 'assistant', message: { id: 'a2', usage: { output_tokens: 20, cache_read_input_tokens: 200 }, content: [{ type: 'text', text: 'Another reply.' }] } },
  ];
  fs.writeFileSync(file, rows.map((r) => JSON.stringify(r)).join('\n') + '\n');
  const reason = reasonOf(hook('prosecheck-tracker.js', { prompt: '/prosecheck stats', transcript_path: file }, { CLAUDE_CONFIG_DIR: cfg }));
  assert.match(reason, /assistant turns: 2/);
  assert.match(reason, /output tokens: 30/);
  assert.match(reason, /cache-read input tokens: 300/);
  assert.doesNotMatch(reason, /ai_tell_score/);
});
