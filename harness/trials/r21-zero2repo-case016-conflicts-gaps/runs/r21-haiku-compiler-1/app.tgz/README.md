# prosecheck

prosecheck is a local detector for AI-writing patterns. It is a command-line tool and an agent plugin. There is no website and no hosted version. Nothing the user writes is uploaded; there is no account; no text leaves the machine.

It is a Python standard-library detector (`scripts/detect.py`, Python 3.9 or newer) plus Node.js plugin hooks (`hooks/`). There is no installable package, no compiled extension, and no runtime third-party dependency. There is no model and no random component in the default scan.

## Detector

    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
    python3 scripts/detect.py --help

With no FILE, standard input is read. Output is one JSON report: one member per fired pattern (keyed `<N>_<slug>`) and a `_metrics` member with the 0-100 score, band, and confidence. `--clean` prints scrubbed text instead; `--ci` adds a low/high interval on the score. Only the first 262,144 characters of extracted prose are scanned. Twenty formats are read: plain text (`.md`, `.mdx`, `.markdown`, `.txt`, `.text`, `.rst`, `.tex`, `.org`, `.adoc`), zip-based documents (`.docx`, `.docm`, `.pptx`, `.pptm`, `.xlsx`, `.xlsm`, `.odt`, `.odp`, `.ods`, `.epub`), and notebooks (`.ipynb`, markdown cells only).

## Plugin

`hooks/` contains the session-start, prompt-submit (`/prosecheck` router), subagent-start, post-tool-use (saved-file guard), and stats hooks. `commands/prosecheck.md` is the slash-command menu document. `.cursor/rules/prosecheck.mdc` is the shipped Cursor rule that `/prosecheck init` copies into a project. Settings live under `CLAUDE_CONFIG_DIR` (default `~/.claude`).

## What a score is

A score, a band, and a hook phrase describe prose. They do not name a person or a model as the author. The score is a triage heuristic on the writing in front of the detector, not a calibrated authorship classifier. It must not be used to accuse anyone.

## Tests

    python3 -m unittest discover -s tests -t tests
    node --test tests/hooks.test.js

Traceability to the specification is recorded in `NOTES.md`.
