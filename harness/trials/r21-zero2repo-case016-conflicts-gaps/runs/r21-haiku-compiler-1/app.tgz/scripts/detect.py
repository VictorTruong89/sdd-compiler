#!/usr/bin/env python3
"""prosecheck detector: a local, deterministic AI-writing pattern scanner.

Standard library only (Python 3.9+). Usage:

    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
    python3 scripts/detect.py --help

With no FILE, standard input is read. Success prints one JSON report on
standard output and exits 0. Failure prints nothing on standard output and
ends standard error with a one-line JSON object {"error": "..."}.
Exit codes: 0 success, 1 empty input / unreadable input, 2 unknown option.
"""

import codecs
import html.parser
import io
import json
import os
import random
import re
import statistics
import sys
import unicodedata
import xml.etree.ElementTree as ET
import zipfile
from collections import Counter

# spec: N-000094 N-000095 N-000096 N-000097 N-000098 N-000099
# spec: N-000226 N-000227 N-000228 N-000229 N-000230 N-000231 N-000232 N-000233 N-000234 N-000235
# spec: N-000236 N-000237 N-000238 N-000239 N-000240 N-000241 N-000242

WINDOW = 262144                 # scan window, characters of extracted prose
PLAIN_CAP = 512 * 1024          # plain-text size cap, bytes (enforced by the plugin)
ARCHIVE_CAP = 4 * 1024 * 1024   # zip-based document / notebook cap, bytes
USAGE_FIRST = "usage: detect.py [--clean] [--ci] [--] [FILE]"
USAGE = USAGE_FIRST + """

prosecheck detector: scores AI-writing patterns in prose (local, no network).

  FILE          a prose file (plain text, .docx, .pptx, .xlsx, .odt, .epub, .ipynb ...)
                or, with no FILE, standard input (UTF-8).
  --clean       cleanup switch: print the scrubbed text instead of the JSON report.
  --ci          interval switch: add a low/high interval on the score (needs >= 4 sentences).
  --            end of options; a file name may then begin with a dash.
  --help, -h    print this usage message and exit 0.

The report is one JSON object: one member per fired pattern (key "<N>_<slug>")
and a "_metrics" member. Only the first 262,144 characters of extracted prose
are scanned. Exit 0 on success, 1 on empty or unreadable input, 2 on an unknown option.
"""

TEXT_EXTS = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXTS = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NB_EXTS = {'.ipynb'}
PROSE_EXTS = TEXT_EXTS | ZIP_EXTS | NB_EXTS
NO_PROSE_EXTS = {'.pdf', '.rtf'}

BANDS = [(20, 'clean'), (40, 'light tells'), (60, 'mixed'), (80, 'heavy tells'), (100, 'pervasive tells')]


def band_of(score):
    for limit, name in BANDS:
        if score <= limit:
            return name
    return 'pervasive tells'


class InputError(Exception):
    """Raised for empty or unreadable input; carries the error text."""


class OptionError(Exception):
    pass


# ---------------------------------------------------------------------------
# Catalogue: titles (spec: N-000128..N-000130), advice set (N-000116..N-000122)
# ---------------------------------------------------------------------------

TITLES = {
    1: 'AI vocabulary', 2: 'Model-dialect vocabulary', 3: 'Promotional language',
    4: 'Hyphenated word-pair overuse', 5: '"Simple yet X" cliche', 6: 'Stacked adjective chains',
    7: 'Rule of three overuse', 8: 'Synonym cycling', 9: 'Generic character naming in fiction',
    10: 'Significance inflation', 11: 'Notability name-dropping', 12: 'Vague attributions',
    13: 'Article titles as proper nouns', 14: 'Conservation and ecosystem padding', 15: 'False ranges',
    16: 'Superficial -ing tail clauses', 17: 'Negative parallelisms and tailing negations',
    18: '"Not X, just Y" contrast', 19: 'Filler phrases', 20: 'Empty pivot phrases',
    21: 'Outcome-speculation tails', 22: 'Persuasive authority tropes', 23: 'Editorial interjections',
    24: 'Self-thoroughness phrases', 25: 'Question-answer rhetorical pattern',
    26: '"Concrete evidence" defense phrase', 27: 'Compulsive intro hooks', 28: 'Meandering intro',
    29: 'Prompt echo', 30: 'Diff-anchored writing', 31: 'Signposting and announcements',
    32: 'Cataloguing lead-ins', 33: 'Inline-header vertical lists', 34: 'Mid-essay bullet injection',
    35: 'Fragmented headers', 36: 'Formulaic challenges sections', 37: 'Transition cluster overuse',
    38: 'Compulsive conclusion phrases', 39: 'Generic positive conclusions',
    40: 'Sentence-length monotony', 41: 'Mechanical sentence-length alternation',
    42: 'Opener repetition', 43: 'Avoidance of fragments and run-ons', 44: 'Uniform paragraph length',
    45: 'Identical paragraph structure', 46: 'Semicolon and parenthesis underuse',
    47: 'Chatbot artifacts', 48: 'Sycophantic tone', 49: 'Helpful-assistant register',
    50: 'Knowledge-cutoff disclaimers', 51: 'Copula avoidance',
    52: 'Passive voice and subjectless fragments', 53: 'Two-way passive-voice drift',
    54: 'Excessive hedging', 55: 'Contraction absence', 56: 'Boldface overuse', 57: 'Emojis',
    58: 'Em-dash overuse', 59: 'Title case in headings', 60: 'Curly quotation marks',
    61: 'Hyphen for en dash in numeric ranges', 62: 'Invisible or zero-width characters',
    63: 'Placeholder text', 64: 'Chat reference-markup leak', 65: 'AI tracking parameters',
    66: 'Mixed-script homoglyphs', 67: 'Non-standard spaces', 68: 'Trailing or stray whitespace',
    69: 'Canonical marketing-slop phrases', 70: 'Decorative horizontal rules',
    71: 'Degenerate repetition',
}
NO_DETECTOR = {7, 9, 28, 29, 43, 45, 49, 52, 53}
ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}   # weight zero (writing advice)
DECISIVE = {13, 47, 48, 50, 62, 63, 64, 65, 66}
RHYTHM = {40, 41, 44, 55}
SHORT_DOC_FAMILIES = set(range(1, 40)) | set(range(47, 52)) | {69}


# ---------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------

WORD_RE = re.compile(r"[^\W_]+(?:['\u2019\-][^\W_]+)*")
SENT_SPLIT = re.compile(r"[.!?]+[\"'\)\]\u201d\u2019]*(?:\s+|$)|\n[ \t]*\n")
PARA_SPLIT = re.compile(r"\n[ \t]*\n")


def count_words(text):
    return len(WORD_RE.findall(text))


def split_sentences(text):
    return [s.strip() for s in SENT_SPLIT.split(text) if s and s.strip()]


def clip(s, limit=80):
    s = ' '.join(s.split())
    return s if len(s) <= limit else s[:limit - 3] + '...'


def _phrase(p):
    """Phrase -> regex: words separated by any whitespace (no newlines needed)."""
    return r'[ \t\r\n]+'.join(re.escape(w) for w in p.split())


def _infl(w):
    """Word -> regex matching the word and its common inflections."""
    e = re.escape(w)
    if ' ' in w:
        return _phrase(w)
    if w.endswith('e'):
        stem = re.escape(w[:-1])
        return '(?:%s|%ss|%sd|%sing)' % (e, e, e, stem)
    return '(?:%s|%ss|%ses|%sed|%sing)' % (e, e, e, e, e)


def _alt(words, inflect=False):
    parts = [(_infl(w) if inflect else _phrase(w)) for w in words]
    return r'\b(?:' + '|'.join(parts) + r')\b'


def rx(pattern, flags=re.I):
    return re.compile(pattern, flags)


def hits_of(regex, text):
    return [m.group(0) for m in regex.finditer(text)]


# ---------------------------------------------------------------------------
# Excluded regions inside the window: fenced code, inline code, blockquote runs,
# table rows, badge lines, YAML front matter (spec: N-000149)
# ---------------------------------------------------------------------------

FENCE_OPEN = re.compile(r'^ {0,3}(`{3,}|~{3,})(.*)$')
FENCE_CLOSE = re.compile(r'^ {0,3}(`{3,}|~{3,})[ \t]*$')
BADGE_LINE = re.compile(r'^[ \t]*(?:\[!\[[^\]\n]*\]\([^)\n]*\)\]\([^)\n]*\)[ \t]*)+$')
INLINE_CODE = re.compile(r'`[^`\n]+`')


def mask_excluded(text):  # spec: N-000149
    lines = text.split('\n')
    keep = [True] * len(lines)
    # YAML front matter at the very start
    if lines and lines[0].strip() == '---':
        for j in range(1, len(lines)):
            if lines[j].strip() in ('---', '...'):
                for k in range(0, j + 1):
                    keep[k] = False
                break
    # fenced code blocks, CommonMark-style closing
    fence = None
    for i, line in enumerate(lines):
        if fence is None:
            m = FENCE_OPEN.match(line)
            if m and not (m.group(1)[0] == '`' and '`' in m.group(2)):
                fence = (m.group(1)[0], len(m.group(1)))
                keep[i] = False
        else:
            keep[i] = False
            m = FENCE_CLOSE.match(line)
            if m and m.group(1)[0] == fence[0] and len(m.group(1)) >= fence[1]:
                fence = None
    # blockquote runs (two or more consecutive lines), table rows, badge lines
    i = 0
    while i < len(lines):
        if keep[i] and re.match(r'^ {0,3}>', lines[i]):
            j = i
            while j < len(lines) and keep[j] and re.match(r'^ {0,3}>', lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    keep[k] = False
            i = j
            continue
        i += 1
    for i, line in enumerate(lines):
        s = line.strip()
        if not keep[i]:
            continue
        if s.count('|') >= 2 and (s.startswith('|') or s.endswith('|')):
            keep[i] = False
        elif BADGE_LINE.match(line):
            keep[i] = False
    out = [lines[i] if keep[i] else '' for i in range(len(lines))]
    masked = '\n'.join(out)
    masked = INLINE_CODE.sub(lambda m: ' ' * len(m.group(0)), masked)
    return masked


# ---------------------------------------------------------------------------
# Character layer: invisible characters, non-standard spaces, homoglyphs
# (spec: N-000171..N-000181, N-000316..N-000330)
# ---------------------------------------------------------------------------

DEFAULT_IGNORABLE_EXTRA = (
    {0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x3164, 0xFFA0}
    | set(range(0xFE00, 0xFE10)) | set(range(0xFFF0, 0xFFF9))
    | set(range(0x1BCA0, 0x1BCA4)) | set(range(0x1D173, 0x1D17B))
)

# lookalike letters of other scripts -> ASCII letter (the letters listed in N-000177)
_CONF_PAIRS = (
    'a\u0430 c\u0441 d\u0501 e\u0435 g\u050d h\u04bb i\u0456 i\u03b9 j\u0458 j\u03f3 n\u043f o\u043e o\u03bf o\u0585 '
    'p\u0440 p\u03c1 s\u0455 u\u03c5 v\u0475 v\u03bd w\u051d x\u0445 x\u03c7 y\u0443 c\u03f2 a\u03b1 '
    'A\u0410 A\u0391 B\u0412 B\u0392 C\u0421 C\u03f9 E\u0415 E\u0395 H\u041d H\u0397 I\u0406 I\u0399 '
    'J\u0408 K\u041a K\u039a M\u041c M\u039c N\u039d O\u041e O\u039f P\u0420 P\u03a1 S\u0405 '
    'T\u0422 T\u03a4 X\u0425 X\u03a7 Y\u0423 Y\u03a5 Z\u0396 D\u0500 G\u050c'
)
CONFUSABLE = {}
for _pair in _CONF_PAIRS.split():
    CONFUSABLE[_pair[1]] = _pair[0]
LETTER_RUN = re.compile(r'[^\W\d_]+')


def is_invisible_candidate(ch):
    cp = ord(ch)
    if cp in (9, 10, 13):
        return False
    if cp < 32 or 0x7F <= cp <= 0x9F:
        return True
    if cp in DEFAULT_IGNORABLE_EXTRA or 0xE0000 <= cp <= 0xE0FFF or 0x180B <= cp <= 0x180F:
        return True
    return unicodedata.category(ch) == 'Cf'


def _joining(ch):
    cp = ord(ch)
    return (0x0590 <= cp <= 0x08FF or 0x0900 <= cp <= 0x0DFF or 0x1000 <= cp <= 0x109F
            or 0x1780 <= cp <= 0x17FF)


def _spaceless(ch):
    cp = ord(ch)
    return (0x0E00 <= cp <= 0x0EFF or 0x1000 <= cp <= 0x109F or 0x1780 <= cp <= 0x17FF
            or 0x3040 <= cp <= 0x30FF or 0x3400 <= cp <= 0x4DBF or 0x4E00 <= cp <= 0x9FFF
            or 0xF900 <= cp <= 0xFAFF or 0x20000 <= cp <= 0x3FFFF)


def _ideograph(ch):
    cp = ord(ch)
    return 0x3400 <= cp <= 0x4DBF or 0x4E00 <= cp <= 0x9FFF or 0xF900 <= cp <= 0xFAFF or 0x20000 <= cp <= 0x3FFFF


def _symbolish(ch):
    return unicodedata.category(ch).startswith('S') or ord(ch) >= 0x1F000 or 0x2600 <= ord(ch) <= 0x27BF


def keep_invisible(text, i, rtl_doc):
    """True when cleanup keeps this invisible character because it does a job here."""
    cp = ord(text[i])
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if 0xE0020 <= cp <= 0xE007F:                       # tag characters (emoji tag sequences)
        j = i - 1
        steps = 0
        while j >= 0 and 0xE0020 <= ord(text[j]) <= 0xE007F and steps < 16:
            j -= 1
            steps += 1
        return j >= 0 and ord(text[j]) == 0x1F3F4
    if 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF:   # variation selectors
        if prev and (_symbolish(prev) or _ideograph(prev)):
            return True
        return nxt == '\u20e3'
    if 0x180B <= cp <= 0x180F:                          # Mongolian selectors
        return bool(prev) and 0x1800 <= ord(prev) <= 0x18AF
    if cp == 0x200B:                                    # zero-width space
        return any(c and _spaceless(c) for c in (prev, nxt))
    if cp == 0xAD:                                      # soft hyphen between letters
        return bool(prev) and bool(nxt) and prev.isalpha() and nxt.isalpha()
    if cp in (0x200E, 0x200F, 0x061C) or 0x202A <= cp <= 0x202E or 0x2066 <= cp <= 0x2069:
        return rtl_doc
    if cp in (0x200C, 0x200D):                          # ZWNJ / ZWJ
        return any(c and (_joining(c) or _symbolish(c)) for c in (prev, nxt))
    if cp in (0x17B4, 0x17B5):                          # Khmer inherent vowels
        return any(c and 0x1780 <= ord(c) <= 0x17FF for c in (prev, nxt))
    return False


def _rtl_doc(text):
    return re.search('[\u0590-\u08ff]', text) is not None


def invisible_indices(text):  # spec: N-000171 N-000220
    rtl = _rtl_doc(text)
    out = []
    for i, ch in enumerate(text):
        if is_invisible_candidate(ch) and not keep_invisible(text, i, rtl):
            out.append(i)
    return out


def _nbsp_kept(text, i):
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    return ((prev and prev.isdigit()) or (nxt and nxt.isdigit()) or (nxt and nxt in ':;!?\u00bb\u203a%\u20ac')
            or (prev and prev in '\u00ab\u2039'))


def nonstandard_space_indices(text):  # spec: N-000178 N-000179
    out = []
    for i, ch in enumerate(text):
        if ch != ' ' and unicodedata.category(ch) == 'Zs':
            if ch in '\u00a0\u202f' and _nbsp_kept(text, i):
                continue
            out.append(i)
    return out


def homoglyph_runs(text):  # spec: N-000177 N-000316
    """Return (runs, lookalike_chars) for letter runs that mix Latin with lookalikes."""
    runs = 0
    chars = 0
    for m in LETTER_RUN.finditer(text):
        s = m.group(0)
        if s.isascii():
            continue
        has_latin = any(c.isascii() and c.isalpha() for c in s)
        conf = sum(1 for c in s if c in CONFUSABLE)
        other = any((not c.isascii()) and c not in CONFUSABLE for c in s)
        if has_latin and conf and not other:
            runs += 1
            chars += conf
    return runs, chars


def _fold_homoglyphs(text):
    def fix(m):
        s = m.group(0)
        if s.isascii():
            return s
        has_latin = any(c.isascii() and c.isalpha() for c in s)
        conf = any(c in CONFUSABLE for c in s)
        other = any((not c.isascii()) and c not in CONFUSABLE for c in s)
        if has_latin and conf and not other:
            return ''.join(CONFUSABLE.get(c, c) for c in s)
        return s
    return LETTER_RUN.sub(fix, text)


TRAIL_LINE = re.compile(r'[ \t]+\r?$', re.M)


def trailing_hits(text):  # spec: N-000180 N-000181
    """Count trailing-whitespace hits (N-000180, N-000181)."""
    n = len(TRAIL_LINE.findall(text))
    if text[:1] and text[:1].isspace():
        n += 1
    if re.search(r'\n[ \t\r]*\n\Z', text):
        n += 1
    return n


def _clean_once(text):
    rtl = _rtl_doc(text)
    out = []
    for i, ch in enumerate(text):
        if is_invisible_candidate(ch) and not keep_invisible(text, i, rtl):
            continue
        if ch in '\u2028\u2029':
            out.append('\n')
            continue
        if ch != ' ' and unicodedata.category(ch) == 'Zs':
            if ch in '\u00a0\u202f' and _nbsp_kept(text, i):
                out.append(ch)
            else:
                out.append(' ')
            continue
        out.append(ch)
    s = ''.join(out)
    s = _fold_homoglyphs(s)
    s = re.sub(r'[ \t]+(\r?)$', r'\1', s, flags=re.M)     # trailing blanks, incl. hard breaks
    s = re.sub(r'\A(?:[ \t\r]*\n)+', '', s)                 # leading blank lines
    ending = '\r\n' if text.endswith('\r\n') else ('\n' if text.endswith('\n') else '')
    s = s.rstrip()
    if ending and s:
        s += ending
    return s


def clean_text(text):  # spec: N-000312 N-000313 N-000314 N-000315 N-000316 N-000317 N-000318 N-000319 N-000320 N-000321 N-000322 N-000323 N-000324 N-000325 N-000326 N-000327 N-000328 N-000329 N-000330
    """Deterministic cleanup for the --clean switch (FP-03).

    Repeats the pass until the output is stable, so that a rescan of the output
    finds no invisible characters, non-standard spaces, or mixed-script runs
    (the keep rules depend on neighbouring characters).
    """
    s = text
    for _ in range(8):
        nxt = _clean_once(s)
        if nxt == s:
            break
        s = nxt
    return s


# ---------------------------------------------------------------------------
# Lexical families
# ---------------------------------------------------------------------------

FAM1_WORDS = ['additionally', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant', 'meticulous',
              'testament', 'underscore', 'intricate', 'intricacies', 'interplay', 'garner', 'bolster',
              'foster', 'showcase', 'emphasize', 'enduring', 'enhance', 'leverage', 'utilize',
              'facilitate', 'encompass', 'harness', 'holistic', 'paradigm', 'transformative',
              'unprecedented', 'myriad', 'plethora', 'robust', 'seamless', 'navigate', 'embark',
              'craft', 'landscape', 'journey', 'realm', 'multifaceted', 'elevate', 'empower', 'unlock']
FAM1_RX = rx(r'\b(?:' + '|'.join([_infl(w) for w in FAM1_WORDS] + [_phrase('align with')]) + r')\b'
             + r'|\bcapture (?:the )?(?:essence|spirit|imagination|heart|magic)\b')

FAM2_RX = rx('|'.join([
    r'\bgenuinely\b', r'\bfascinating\b', r'\bnuanced\b', r'\bthoughtfully\b', r'\brefreshingly\b',
    r'\bstrikingly\b', r'\bcompellingly\b', r'\bquietly (?:powerful|profound|radical)\b',
    r'\bdeeply (?:human|personal|felt|unsettling)\b', r'\bresonates deeply\b',
    r'\bgame[- ]chang(?:er|ers|ing)\b', r'\bsupercharg(?:e|es|ed|ing)\b',
    r'\bskyrocket(?:s|ed|ing)?\b', r'\bturbocharg(?:e|es|ed|ing)\b',
    r'\brevolutioni[sz](?:e|es|ed|ing)\b', r'\bdouble down on\b', r'\bdive deep(?:er)? into\b',
    r'\bunlock (?:the )?(?:power|potential|value)\b', r'\btake [^.!?\n]{1,40}? to the next level\b',
]))

FAM3_RX = rx(_alt([
    'nestled', 'breathtaking', 'must-visit', 'stunning', 'picturesque', 'charming', 'idyllic',
    'vibrant community', 'rich cultural heritage', 'in the heart of', 'world-class', 'top-tier',
    'unparalleled', 'premier', 'leading', 'esteemed organization', 'valuable asset',
    'passion for excellence', 'proven track record', 'results-oriented', 'wealth of experience',
    'dynamic team', 'fast-paced environment', 'deeply passionate', 'perfectly situated',
    'close-knit team', 'tight-knit team', 'I am excited to apply', 'I am excited to bring',
    'uniquely positioned to']))
MARKETING_VERBS = {'install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape',
                   'transform', 'reclaim', 'unlock', 'elevate', 'boost', 'say', 'imagine', 'explore',
                   'meet', 'introducing', 'upgrade', 'claim', 'unleash', 'supercharge', 'level',
                   'stop', 'start'}

ADJ_SUFFIX = ('ive', 'ous', 'able', 'ible', 'ic', 'ical', 'ant', 'ent', 'ful', 'less', 'al', 'ial',
              'ary', 'ory', 'ish')
ADJ_STOCK = {'vibrant', 'rich', 'robust', 'seamless', 'dynamic', 'innovative', 'comprehensive',
             'compelling', 'bold', 'elegant', 'stunning', 'timeless', 'powerful', 'intuitive',
             'unparalleled', 'premier', 'cutting-edge'}
ADJ_CHAIN_RX = re.compile(r"\b\w[\w'\u2019-]*(?:,\s+\w[\w'\u2019-]*){2,5}(?:,?\s+and\s+\w[\w'\u2019-]*)"
                          r"|\b\w[\w'\u2019-]*(?:,\s+\w[\w'\u2019-]*){3}")

CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]
CLUSTER_RX = [[(w, rx(r'\b' + _phrase(w) + r'(?:s|es)?\b')) for w in cl] for cl in CLUSTERS]

SIG_RX = rx('|'.join([
    r'\b(?:stands?|serves?|stood|served) as an? (?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b',
    r'\b(?:underscor(?:es|ed|ing)?|highlight(?:s|ed|ing)?) (?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b',
    r'\breflects? a broader (?:trend|shift|pattern)\b',
    r'\bmarks? a (?:turning point|milestone|watershed|new chapter|new era)\b',
    r'\bsymboliz(?:es|e|ed|ing)\b', r'\bsets the stage for\b', r'\bleft an indelible mark\b',
    r'\bplays? a (?:crucial|pivotal|vital|key|central|significant) role\b',
    r'\b(?:has|have) (?:shaped|sparked)\b', r'\b(?:has|have) come to (?:define|symbolize)\b',
]))
NOTABILITY_RX = re.compile(
    r'(?i:\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by)\b)[^.!?\n]{0,150}?'
    r'[A-Z][\w&.]+[^.!?\n]{0,150}?(?:,| and )[^.!?\n]{0,150}?[A-Z][\w&.]+')
NOTABILITY2_RX = rx(r'\b\d[\d,.]*\s*[KkMm]?\s+followers\b|\b(?:strong|active) (?:online|digital|social[- ]media) presence\b'
                    r'|\bwidely covered\b|\bindependent coverage\b')
VAGUE_RX = rx('|'.join([
    r'\bexperts? (?:argue|believe|say|claim|note|suggest)\b', r'\bindustry (?:reports|observers|analysts)\b',
    r'\bobservers have (?:cited|noted)\b', r'\bsome critics argue\b', r'\bresearchers have found\b',
    r'\bstudies suggest\b', r'\bit is widely believed\b']))
ARTICLE_TITLE_RX = rx(r'\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of '
                      r'(?:[\w\'\u2019&:-]+\s+){0,8}[\w\'\u2019&:-]+\s+(?:is|are|was|were)\s+(?:a|an|the)\b')
ECOSYSTEM_RX = rx('|'.join([
    r'\bplays? an? (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b',
    r'\bconservation efforts (?:are|is) (?:underway|ongoing|in place)\b',
    r'\bserves as an? indicator species\b', r'\bcontributes to biodiversity\b']))
FALSE_RANGE_RX = rx('|'.join([
    r'\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]{0,150}?'
    r'\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b',
    r'\bfrom (?:the )?humble\b[^.!?\n]{0,150}?\bto (?:the )?(?:mighty|towering|grand|sprawling)\b']))
ING_TAIL_RX = rx(r',\s*(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|'
                 r'cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|'
                 r'indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b')
PARALLEL_RX = rx('|'.join([
    r'\bit[\u2019\']s not (?:just|merely) (?:about|an?)\b',
    r'\bnot only\b[^.!?\n]{0,40}?\bbut\b',
    r'\bdoesn[\u2019\']t just\b[^,.!?\n]{0,40}?\bit\b']))
TAIL_NEG_RX = rx(r',\s*no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b')
NOT_X_RX = rx('|'.join([
    r'\b(?:no|not) [a-z]+, (?:just|only|simply) [a-z]+\b',
    r'\b(?:not|isn[\u2019\']t|aren[\u2019\']t|wasn[\u2019\']t|weren[\u2019\']t) (?:just|merely) (?:a |an |the )?\w+'
    r'[,\u2014\u2013-]\s*(?:it[\u2019\']s|it is|it was|they[\u2019\']re|they are|they were|that[\u2019\']s|but)\b']))
FILLER_RX = rx(_alt(['in order to', 'due to the fact that', 'at this point in time', 'in the event that',
                     'has the ability to', 'it is important to note that', 'it should be mentioned that',
                     'needless to say']))
EMPTY_PIVOT_RX = rx('|'.join([
    r'\bit[\u2019\']s worth (?:noting|mentioning) that\b', r'\bit bears (?:noting|mentioning) that\b',
    r'\bone thing to (?:consider|keep in mind) is\b', r'\bit is interesting to note that\b',
    r'\ba key consideration is\b', r'\ba point to highlight is\b']))
OUTCOME_RX = rx(r',\s*(?:raising questions about|prompting reflection on|sparking debate about|'
                r'with broader implications for|reshaping our understanding of|paving the way for|'
                r'signaling a shift toward)')
PERSUASIVE_RX = rx('|'.join([
    r'\bhere[\u2019\']s the thing\b', r'\bmake no mistake\b', r'\bthe truth is\b', r'\blet[\u2019\']s be honest\b',
    r'\bthe simple fact is\b', r'\bat its core\b', r'\bwhat really matters\b', r'\bmore than anything\b',
    r'\bat the end of the day\b', r'\bthe bottom line is\b', r'\bin reality\b', r'\bfundamentally,',
    r'\bthe real question is\b', r'\bthe heart of the matter\b', r'\bthe deeper issue\b',
    r'\bwhen you get down to it\b', r'\bwhen all is said and done\b']))
EDITORIAL_RX = rx('|'.join([
    r'\bit[\u2019\']s important to (?:remember|note|understand|recognize)\b',
    r'\bit is important to (?:remember|note|understand|recognize)\b',
    r'\bone must note that\b', r'\bit is worth pointing out\b',
    r'\bit cannot be overstated that\b', r'\bit must be emphasized that\b']))
SELF_THOR_RX = rx('|'.join([
    r'\bthis comprehensive (?:guide|overview|analysis)\b', r'\bthis in-depth (?:analysis|look|examination)\b',
    r'\bthis complete (?:guide|overview)\b', r'\ba thorough examination of\b',
    r'\beverything you need to know about\b']))
QA_RX = rx(r'(?<![^\s.!?])((?:Is|Are|Was|Were|Do|Does|Did|Can|Could|Will|Would|Should|Has|Have|Had|May|Might|Must)'
           r'\b[^?\n.!]{0,80}\?)\s+(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)\s*[.!]', re.I)
CONCRETE_RX = rx('|'.join([
    r'\bwithout concrete (?:evidence|proof)\b', r'\bdo you have concrete evidence\b',
    r'\bI (?:would )?need concrete (?:evidence|examples) to\b', r'\babsent concrete proof\b',
    r'\bprovide concrete evidence\b']))
HOOK_RX = rx('|'.join([
    r'\bin today[\u2019\']s(?: \S+){0,2}? (?:world|landscape|environment|market)\b',
    r'\bin a world where\b', r'\bin an era of\b', r'\bin recent years,', r'\bmore than ever before\b',
    r'\bwe live in a (?:time|world) when\b', r'\b(?:great|exciting|big) news\s*[!:]',
    r'\bever (?:wanted|wondered|dreamed|wished)\b[^?\n]{0,80}\?',
    r'\bin an increasingly (?:interconnected|digital|competitive|complex) world\b']))
DIFF_RX = rx('|'.join([
    r'\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b',
    r'\bthe (?:latest|new) (?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b',
    r'\bthis (?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b',
    r'\bhas been (?:updated|refactored|improved|enhanced|changed to)\b',
    r'\bhave been (?:updated|refactored|improved|enhanced|changed to)\b',
    r'\bpreviously\b[^.!?\n]{0,80}\bnow\b', r'\bwasn[\u2019\']t there before\b', r'\bweren[\u2019\']t there before\b',
    r'\bwe[\u2019\']ve (?:now )?(?:added|removed|replaced|refactored|migrated)\b',
    r'\bwe have (?:now )?(?:added|removed|replaced|refactored|migrated)\b']))
SIGNPOST_RX = rx('|'.join([
    r"\blet[\u2019\']s (?:dive|delve|explore)\b", r"\blet[\u2019\']s break (?:this|it) down\b",
    r"\bhere[\u2019\']s what you need to know\b", r'\bwithout further ado\b', r'\bnow let[\u2019\']s look at\b',
    r'\bbuckle up\b', r'\bstay with me\b', r'\bready to dive in\b']))
CATALOG_RX = [
    rx(r'\b(?:used|uses|employed|employs|relied on|utilizes) (?:several|various|a number of|multiple|different|many|numerous) \w+'),
    rx(r'^[ \t]*These(?:[ \t]+\w+)?[ \t]+(?:provide|offer|give|reveal|show|allow|enable|help)[ \t]+'
       r'(?:information|insight|understanding|details|data)\b', re.M),
    rx(r'\b(?:is|are|was|were|remains|becomes) (?:the |a )?(?:language|currency|architecture|heartbeat|lifeblood|DNA|'
       r'backbone|bedrock|engine|scaffolding|connective tissue) of\b'),
]
BOLD_LEAD_RX = re.compile(r'^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]+:\*\*'
                          r'|^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]+\*\*:', re.M)
OPENER_PAT = rx(r'^[ \t]*(?:[-*+]|\d+[.)])[ \t]+', re.M)
HEADING_RX = re.compile(r'^#{1,6}[ \t]+(.+?)[ \t]*#*[ \t]*$', re.M)
LIST_LINE = re.compile(r'^[ \t]*(?:[-*+]|\d+[.)])[ \t]+\S')
TRANSITION_RX = re.compile(r'(?:^|(?<=[.!?])[ \t]+|\n[ \t]*)(?:Additionally|Furthermore|Moreover|However|Nevertheless|'
                           r'Consequently|Subsequently|Notably)\b')
CONCLUSION_RX = rx(r'^[ \t]*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|ultimately)\b',
                   re.M)
POSITIVE_RX = rx('|'.join([
    r'\bthe future (?:for \S+ )?(?:looks|remains|is) bright\b', r'\bthe outlook (?:for \S+ )?(?:is|looks|remains) bright\b',
    r'\bexciting times lie ahead\b', r'\bjourney toward excellence\b', r'\bstep in the right direction\b',
    r'\bwell[- ]positioned (?:for|to) (?:whatever comes next|the future|the road ahead)\b']))
CHATBOT_RX = rx('|'.join([
    r'\bI hope this helps\b', r'\bCertainly!', r'\bOf course!', r'\blet me know if you\b',
    r'\bwould you like me to\b', r'\bfeel free to (?:ask|reach out)\b', r'\bhappy to help[.!]',
    r'\b(?:here|below) is (?:a |an |the )?(?:overview|summary|rundown|recap|brief)\b',
    r'\bhere are (?:a few|some|two|three) (?:options|drafts|versions|variations)\b',
    r'\bhere[\u2019\']s a few (?:options|drafts|versions|variations)\b', r'\bhere (?:is|[\u2019\']s) a draft\b',
    r'\bdepending on the (?:vibe|tone|style)\b', r'\bI hope (?:this email )?finds you well\b',
    r'\bas an? (?:AI assistant|AI language model|large language model|language model|AI|LLM)\b',
    r'\bto (?:answer|address) your question\b', r'\bin (?:response|answer) to your question\b',
    r'\byour question (?:about|regarding|concerning)\b', r'\bas (?:you )?(?:requested|asked), here\b',
    r'\bhere is (?:the )?(?:draft|first pass|revised version)\b']))
SYCOPHANT_RX = rx('|'.join([
    r'\byou(?:[\u2019\']re| are) absolutely right\b',
    r'\b(?:great|excellent|good|interesting|fantastic|wonderful|brilliant) (?:question|point)\s*[!.,]',
    r'\bwhat a (?:thoughtful|great|wonderful|fantastic) question\b',
    r'\bthat[\u2019\']s (?:a|an) (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b']))
CUTOFF_RX = rx('|'.join([
    r'\bas of my (?:last )?(?:training|knowledge)\b', r'\bup to my (?:last )?(?:training|knowledge)\b',
    r'\bwhile specific details are (?:limited|scarce|not extensively (?:documented)?|not widely documented)',
    r'\bbased on (?:the )?available information\b', r'\bas of my knowledge cutoff\b',
    r'\bmaintains a low profile\b', r'\bkeeps (?:his|her|their) personal life private\b']))
COPULA_RX = rx('|'.join([
    r'\b(?:serves|stands|functions|acts) as\b', r'\brepresents (?:a|the)\b', r'\bmarks (?:a|the)\b',
    r'\bboasts\b', r'\bfeatures (?:an?|the|\d+|several|many|numerous)\b', r'\boffers an?\b', r'\brefers to\b']))
HEDGE_WORDS = ['may', 'might', 'could', 'possibly', 'potentially', 'arguably', 'perhaps', 'seems', 'seem',
               'seems to', 'seems like', 'seem to', 'seem like', 'appears to', 'appear to', 'somewhat',
               'relatively', 'fairly', 'kind of', 'sort of']
HEDGE_RX = re.compile(r'\b(?:' + '|'.join(re.escape(h) for h in sorted(set(HEDGE_WORDS), key=len, reverse=True))
                      + r')\b')
BOLD_RX = re.compile(r'\*\*[^*\n]+?\*\*')
EMOJI_RX = re.compile('[\U0001F000-\U0001FAFF\u2600-\u27BF\u2B50\u2B55\u2190-\u21FF]')
EM_DASH = '\u2014'
CURLY_RX = re.compile('[\u2018\u2019\u201c\u201d]')
RANGE_RX = re.compile(r'\b(1[5-9]\d\d|20\d\d)-(1[5-9]\d\d|20\d\d)\b')
PLACEHOLDER_RXS = [
    rx(r'\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![\(\[])'),
    rx(r'\[(?:name|company|client|place|city|source|full name|first name|last name|company name|address|email|phone)\](?![\(\[])'),
    re.compile(r'\[[A-Z][A-Z0-9 _-]{2,}\](?![\(\[])'),
    re.compile(r'\{\{[^{}\n]*\}\}'),
    re.compile(r'(?<![A-Za-z])x{3,}(?![A-Za-z])', re.I),
    rx(r'\blorem ipsum\b'),
]
CHAT_MARKUP_RX = re.compile(r'cite(?:turn|start|nav)\d*|oai_citation|contentReference|navlist|\u3010[^\u3011\n]*\u2020[^\u3011\n]*\u3011')
UTM_RX = rx(r'utm_source=(?:chatgpt\.com|chat\.openai\.com|perplexity\.ai|claude\.ai|gemini\.google\.com|'
            r'copilot\.microsoft\.com|poe\.com)(?![A-Za-z0-9\-])(?!\.[A-Za-z0-9\-])')
MARKETING_RX = rx('|'.join([
    r'\bunlocking (?:its |the |your |their )?full potential\b', r'\bnavigating the complexities\b',
    r'\ba testament to the (?:power|importance) of\b', r'\bstaying ahead of the curve\b',
    r'\bturning challenges into opportunities\b', r'\bharnessing the power of\b', r'\bpaving the way for\b',
    r'\bsaying goodbye to\b', r'\bimagining a world where\b']))
HR_LINE = re.compile(r'^[ \t]{0,3}(?:(?:-[ \t]*){3,}|(?:\*[ \t]*){3,}|(?:_[ \t]*){3,})$', re.M)
MINOR_WORDS = {'a', 'an', 'the', 'and', 'or', 'but', 'nor', 'so', 'yet', 'for', 'of', 'in', 'on', 'at', 'to',
               'by', 'with', 'from', 'as', 'into', 'onto', 'over', 'via', 'up', 'off', 'per', 'than'}
MARKETING_IMPERATIVE_OK = MARKETING_VERBS


# ---------------------------------------------------------------------------
# Family functions: each returns a list of hit strings (empty = not fired)
# ---------------------------------------------------------------------------

def f1(c):  # spec: N-000152
    return hits_of(FAM1_RX, c.m)


def f2(c):  # spec: N-000153
    hits = hits_of(FAM2_RX, c.m)
    return hits if len(hits) >= 2 else []        # model-dialect family needs two hits


def f3(c):  # spec: N-000154
    hits = hits_of(FAM3_RX, c.m)
    starts = [s.split()[0].lower().strip('.,!?;:') for s in c.sents if s.split()]
    imperatives = [w for w in starts if w in MARKETING_VERBS]
    if len(imperatives) >= 3:
        hits.append('%d sentences open with marketing imperatives' % len(imperatives))
    return hits


def f5(c):
    return hits_of(rx(r'\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b'), c.m)


def f6(c):
    hits = []
    for m in ADJ_CHAIN_RX.finditer(c.m):
        items = re.findall(r"\w[\w'\u2019-]*", m.group(0))
        adj = sum(1 for w in items if w.lower() in ADJ_STOCK or w.lower().endswith(ADJ_SUFFIX))
        if len(items) >= 4 and adj >= 2:
            hits.append(m.group(0))
    return hits


def f8(c):
    fired = []
    for cluster in CLUSTER_RX:
        present = []
        for word, r in cluster:
            present.extend(hits_of(r, c.m))
        distinct = {w for w, r in cluster if r.search(c.m)}
        if len(distinct) >= 3:
            fired.extend(present)
    return fired


def f10(c):
    return hits_of(SIG_RX, c.m)


def f11(c):  # spec: N-000185 N-000186 N-000187
    hits = hits_of(NOTABILITY_RX, c.m) + hits_of(NOTABILITY2_RX, c.m)
    return hits


def f12(c):
    return hits_of(VAGUE_RX, c.m)


def f13(c):
    return hits_of(ARTICLE_TITLE_RX, c.m)


def f14(c):
    return hits_of(ECOSYSTEM_RX, c.m)


def f15(c):
    return hits_of(FALSE_RANGE_RX, c.m)


def f16(c):
    return hits_of(ING_TAIL_RX, c.m)


def f17_par(c):  # spec: N-000123 N-000124 N-000125 N-000126 N-000127
    return hits_of(PARALLEL_RX, c.m)


def f17_tail(c):  # spec: N-000127
    return hits_of(TAIL_NEG_RX, c.m)


def f18(c):  # spec: N-000155
    return hits_of(NOT_X_RX, c.m)


def f19(c):  # spec: N-000161
    return hits_of(FILLER_RX, c.m)


def f20(c):
    return hits_of(EMPTY_PIVOT_RX, c.m)


def f21(c):
    return hits_of(OUTCOME_RX, c.m)


def f22(c):  # spec: N-000162
    return hits_of(PERSUASIVE_RX, c.m)


def f23(c):  # spec: N-000188
    return hits_of(EDITORIAL_RX, c.m)


def f24(c):  # spec: N-000163
    return hits_of(SELF_THOR_RX, c.m)


def f25(c):  # spec: N-000189 N-000190
    return [m.group(0) for m in QA_RX.finditer(c.m)]


def f26(c):  # spec: N-000191
    return hits_of(CONCRETE_RX, c.m)


def f27(c):
    return hits_of(HOOK_RX, c.m)


def f30(c):  # spec: N-000192
    return hits_of(DIFF_RX, c.m)


def f31(c):  # spec: N-000193
    return hits_of(SIGNPOST_RX, c.m)


def f32(c):  # spec: N-000194 N-000195 N-000196
    out = []
    for r in CATALOG_RX:
        out.extend(hits_of(r, c.m))
    return out


def f33(c):  # spec: N-000197
    return hits_of(BOLD_LEAD_RX, c.m)


def f34(c):  # spec: N-000198 N-000199
    if HEADING_RX.search(c.m):
        return []
    paras = [p for p in PARA_SPLIT.split(c.m) if p.strip()]
    lists = [p for p in paras if all(LIST_LINE.match(l) for l in p.split('\n') if l.strip())]
    prose = [p for p in paras if p not in lists]
    if lists and len(prose) >= 2:
        return ['bulleted paragraph in prose: ' + clip(lists[0], 50)]
    return []


def f35(c):  # spec: N-000200
    out = []
    lines = c.m.split('\n')
    for i, line in enumerate(lines):
        h = HEADING_RX.match(line)
        if not h:
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if not nxt or nxt.startswith('#') or LIST_LINE.match(lines[j]) or nxt.startswith('|'):
            continue
        if count_words(nxt) > 4:
            continue
        head_words = {w.lower() for w in re.findall(r'[A-Za-z]{3,}', h.group(1))}
        next_words = {w.lower() for w in re.findall(r'[A-Za-z]{3,}', nxt)}
        if head_words & next_words:
            out.append(clip(line + ' / ' + nxt, 60))
    return out


def f36(c):  # spec: N-000156 N-000157
    return hits_of(rx('|'.join([
        r'\bdespite (?:these|its|the) (?:challenges|obstacles)\b',
        r'\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b',
        r'\bcontinues to thrive\b', r'\btypical of (?:emerging|urban|modern)\b',
        r'\bfaces (?:several|many|numerous) challenges\b'])), c.m)


def f37(c):  # spec: N-000158
    out = []
    for p in PARA_SPLIT.split(c.m):
        found = TRANSITION_RX.findall(p)
        if len(found) >= 2:
            out.extend(hits_of(TRANSITION_RX, p))
    return out


def f38(c):  # spec: N-000159
    return hits_of(CONCLUSION_RX, c.m)


def f39(c):  # spec: N-000160
    return hits_of(POSITIVE_RX, c.m)


def f40(c):  # spec: N-000140 N-000141
    lengths = [count_words(s) for s in c.sents]
    lengths = [n for n in lengths if n > 0]
    if len(lengths) >= 3 and _cv(lengths) < 0.35:
        return ['%d sentences of similar length' % len(lengths)]
    return []


def _cv(vals):
    mean = statistics.mean(vals)
    if mean == 0:
        return 0.0
    return statistics.pstdev(vals) / mean


def f41(c):  # spec: N-000207
    lengths = [count_words(s) for s in c.sents]
    lengths = [n for n in lengths if n > 0]
    out = []
    n = len(lengths)
    i = 0
    while i < n - 1:
        j = i
        while j < n - 1:
            d = lengths[j + 1] - lengths[j]
            if abs(d) < 4:
                break
            if j > i and ((lengths[j] - lengths[j - 1] > 0) == (d > 0)):
                break
            j += 1
        if j > i and j - i + 1 >= 6:
            out.append('%d sentences alternating in length' % (j - i + 1))
        i = j + 1 if j > i else i + 1
    return out


def f42(c):  # spec: N-000164
    out = []
    for p in PARA_SPLIT.split(c.m):
        sents = split_sentences(p)
        if len(sents) < 3:
            continue
        firsts = Counter(' '.join(s.split()[:2]).lower() for s in sents if len(s.split()) >= 2)
        for k, v in firsts.items():
            if v >= 3:
                out.append('%d sentences open with "%s"' % (v, k))
                break
    return out


def f44(c):  # spec: N-000142 N-000143
    paras = [count_words(p) for p in PARA_SPLIT.split(c.m) if p.strip()]
    paras = [n for n in paras if n > 0]
    if len(paras) >= 4 and _cv(paras) < 0.4:
        return ['%d paragraphs of similar length' % len(paras)]
    return []


def f46(c):  # spec: N-000201 N-000202 N-000203
    if c.words >= 300 and ';' not in c.m and c.m.count('(') <= 1:
        return ['no semicolons and almost no parentheses in a long document']
    return []


def f47(c):  # spec: N-000165
    return hits_of(CHATBOT_RX, c.m)


def f48(c):  # spec: N-000166 N-000167
    return hits_of(SYCOPHANT_RX, c.m)


def f50(c):  # spec: N-000168
    return hits_of(CUTOFF_RX, c.m)


def f51(c):  # spec: N-000169
    return hits_of(COPULA_RX, c.m)


def f54(c):  # spec: N-000170
    out = []
    for s in c.sents:
        hedges = set(HEDGE_RX.findall(s))
        if len(hedges) >= 2:
            out.append(clip(s, 60))
    return out


def f55(c):  # spec: N-000204 N-000205 N-000206
    words = [w.lower() for w in WORD_RE.findall(c.m)]
    if len(words) < 40:
        return []
    first = sum(1 for w in words if w in ('i', 'me', 'my', 'mine', 'we', 'our', 'ours', 'us', 'myself', 'ourselves'))
    if first / len(words) < 0.03:
        return []
    full = len(rx(r'\b(?:do|does|did|is|are|was|were|have|has|had|will|would|should|could|must) not\b').findall(c.m))
    full += len(rx(r'\bI am\b').findall(c.m))
    full += len(rx(r'\b(?:we|you|they) are\b').findall(c.m))
    full += len(rx(r'\b(?:it|that|there) is\b').findall(c.m))
    full += len(rx(r'\bI (?:have|will|would)\b').findall(c.m))
    contracted = len(rx(r"n['\u2019]t\b|['\u2019](?:m|re|ve|ll|d)\b").findall(c.m))
    if full >= 3 and full > contracted:
        return ['%d contractable forms written in full' % full]
    return []


def f56(c):
    return hits_of(BOLD_RX, c.m)


def f57(c):
    return hits_of(EMOJI_RX, c.m)


def f58(c):  # spec: N-000208
    return ['paragraph with %d em dashes' % p.count(EM_DASH)
            for p in PARA_SPLIT.split(c.m) if p.count(EM_DASH) >= 2]


def f59(c):  # spec: N-000209 N-000210
    out = []
    for m in HEADING_RX.finditer(c.m):
        text = m.group(1)
        if text.isupper() or not text[:1].isalpha():
            continue
        words = re.findall(r"[A-Za-z][A-Za-z'\u2019-]*", text)
        if len(words) < 3:
            continue
        majors = [w for w in words if w.lower() not in MINOR_WORDS]
        if len(majors) >= 2 and all(w[0].isupper() for w in majors):
            out.append(clip(text, 60))
    return out


def f60(c):  # spec: N-000211
    return ['curly quote %r' % m.group(0) for m in CURLY_RX.finditer(c.m)][:200]


def f61(c):  # spec: N-000212
    out = []
    for m in RANGE_RX.finditer(c.m):
        if int(m.group(1)) < int(m.group(2)):
            out.append(m.group(0))
    return out


def f63(c):  # spec: N-000172 N-000173
    out = []
    for r in PLACEHOLDER_RXS:
        out.extend(hits_of(r, c.m))
    return out


def f64(c):  # spec: N-000174
    return hits_of(CHAT_MARKUP_RX, c.m)


def f65(c):  # spec: N-000175 N-000176
    return hits_of(UTM_RX, c.m)


def f69(c):  # spec: N-000213 N-000214
    return hits_of(MARKETING_RX, c.m)


def f70(c):  # spec: N-000215 N-000216
    if len(c.raw_lines) >= 24:
        found = HR_LINE.findall(c.m)
        if len(found) >= 3:
            return ['%d decorative rules' % len(found)]
    return []


def f71(c):  # spec: N-000217 N-000218 N-000219
    toks = [t.lower() for t in WORD_RE.findall(c.m)]
    if len(toks) < 6:
        return []
    grams = [' '.join(toks[i:i + 6]) for i in range(len(toks) - 5)]
    counts = Counter(grams)
    rep = sum(1 for g in grams if counts[g] > 1)
    if rep and rep / len(grams) >= 0.2:
        return ['%d of %d six-word runs repeat' % (rep, len(grams))]
    return []


def f4(c):  # spec: N-000182 N-000183 N-000184
    return hits_of(rx('|'.join([
        r'\bcutting-edge\b', r'\bgame-changing\b', r'\bstate-of-the-art\b', r'\buser-friendly\b',
        r'\bresults-driven\b', r'\bbest-in-class\b', r'\bnext-generation\b', r'\bhigh-performing\b',
        r'\bwell-established\b', r'\bvalue-added\b', r'\bend-to-end\b', r'\btime-saving\b',
        r'\bindustry-leading\b', r'\bhigh-quality\b', r'\bfast-paced\b', r'\bdata-driven\b'])), c.m)


# ---------------------------------------------------------------------------
# Registry: (number, slug, family function, advice?)
# ---------------------------------------------------------------------------

REGISTRY = [
    (1, 'ai_vocabulary', f1, False),
    (2, 'model_dialect', f2, False),
    (3, 'promotional_language', f3, False),
    (4, 'hyphenated_pairs', f4, True),
    (5, 'simple_yet', f5, False),
    (6, 'stacked_adjectives', f6, False),
    (8, 'synonym_cycling', f8, False),
    (10, 'significance_inflation', f10, False),
    (11, 'notability_name_dropping', f11, False),
    (12, 'vague_attributions', f12, False),
    (13, 'article_title_proper_noun', f13, False),
    (14, 'ecosystem_padding', f14, False),
    (15, 'false_ranges', f15, False),
    (16, 'ing_tail_clauses', f16, False),
    (17, 'negative_parallelism', f17_par, True),
    (17, 'tailing_negation', f17_tail, False),
    (18, 'not_x_just_y', f18, False),
    (19, 'filler_phrases', f19, True),
    (20, 'empty_pivot', f20, False),
    (21, 'outcome_speculation', f21, False),
    (22, 'persuasive_tropes', f22, True),
    (23, 'editorial_interjections', f23, False),
    (24, 'self_thoroughness', f24, False),
    (25, 'question_answer', f25, False),
    (26, 'concrete_evidence', f26, False),
    (27, 'compulsive_intro_hooks', f27, False),
    (30, 'diff_anchored', f30, False),
    (31, 'signposting', f31, False),
    (32, 'cataloguing_lead_ins', f32, False),
    (33, 'inline_header_lists', f33, False),
    (34, 'mid_essay_bullets', f34, False),
    (35, 'fragmented_headers', f35, False),
    (36, 'formulaic_challenges', f36, False),
    (37, 'transition_clusters', f37, False),
    (38, 'compulsive_conclusions', f38, False),
    (39, 'generic_positive_conclusions', f39, False),
    (40, 'sentence_length_monotony', f40, False),
    (41, 'mechanical_alternation', f41, True),
    (42, 'opener_repetition', f42, True),
    (44, 'uniform_paragraph_length', f44, False),
    (46, 'semicolon_underuse', f46, True),
    (47, 'chatbot_artifacts', f47, False),
    (48, 'sycophantic_tone', f48, False),
    (50, 'knowledge_cutoff', f50, False),
    (51, 'copula_avoidance', f51, False),
    (54, 'hedge_stacking', f54, True),
    (55, 'contraction_absence', f55, True),
    (56, 'boldface_overuse', f56, False),
    (57, 'emojis', f57, False),
    (58, 'em_dash_overuse', f58, True),
    (59, 'title_case_headings', f59, False),
    (60, 'curly_quotes', f60, True),
    (61, 'hyphen_for_en_dash', f61, True),
    (63, 'placeholder_text', f63, False),
    (64, 'chat_reference_markup', f64, False),
    (65, 'ai_tracking_params', f65, False),
    (69, 'marketing_slop', f69, False),
    (70, 'decorative_rules', f70, False),
    (71, 'degenerate_repetition', f71, False),
]


class Ctx(object):
    pass


def build_ctx(window):  # spec: N-000150 N-000151
    c = Ctx()
    c.m = mask_excluded(window)
    c.raw_lines = window.split('\n')
    c.paras = [p for p in PARA_SPLIT.split(c.m) if p.strip()]
    c.sents = split_sentences(c.m)
    c.words = count_words(c.m)
    return c


def _confidence(words, families):  # spec: N-000145 N-000146 N-000147 N-000148
    if words < 40:
        return 'none', 'fewer than 40 words, too short to support a score'
    if words < 120:
        return 'low', 'fewer than 120 words'
    if words < 300 and families == 1:
        return 'low', 'fewer than 300 words with only one score-moving family'
    if words < 300:
        return 'moderate', 'fewer than 300 words'
    return 'high', ''


def _score(score_hits, words):  # spec: N-000131 N-000132 N-000133 N-000134 N-000135 N-000136 N-000137 N-000138 N-000139 N-000140 N-000141 N-000142 N-000143 N-000144
    """Score from families (N-000131..N-000148). score_hits: {number: hit count}."""
    fams = set(score_hits)
    raw = min(100, sum(min(14, 6 + 2 * min(h - 1, 4)) for h in score_hits.values()))
    cap = None
    floors = []
    decisive_n = len(fams & DECISIVE)
    conf, _ = _confidence(words, len(fams))
    if decisive_n >= 2:
        floors.append(65)
    elif decisive_n == 1 and conf in ('moderate', 'high'):
        floors.append(45)
    if len(fams) == 1 and 45 not in floors:
        cap = 40
    if fams and fams <= RHYTHM:
        cap = min(cap or 100, 20 if fams == {40} else 40)
    short = fams & SHORT_DOC_FAMILIES
    if words < 120:
        if len(short) >= 3:
            floors.append(45)
        elif len(short) >= 2:
            floors.append(25)
    if words >= 400:
        if len(fams) >= 6:
            floors.append(45)
        elif len(fams) >= 5:
            floors.append(25)
    score = raw
    if cap is not None:
        score = min(score, cap)
    if floors:
        score = max(score, max(floors))
    return max(0, min(100, int(score)))


def analyze(window, truncated=False):  # spec: N-000100 N-000101 N-000102 N-000103 N-000104 N-000105 N-000106 N-000107 N-000108 N-000109 N-000110 N-000111 N-000112 N-000113 N-000114 N-000236 N-000237 N-000238 N-000239 N-000240
    """Run the whole scan on the window. Returns the report dict."""
    c = build_ctx(window)
    findings = {}
    score_hits = {}
    fired = []

    inv = invisible_indices(window)
    ns = nonstandard_space_indices(window)
    homo_runs, homo_chars = homoglyph_runs(window)
    trail = trailing_hits(window)
    layer_counts = {62: len(inv), 66: homo_runs, 67: len(ns), 68: trail}

    for num, slug, fn, advice in REGISTRY:
        if num in NO_DETECTOR:
            continue
        if num in layer_counts:
            continue
        hits = fn(c)
        if not hits:
            continue
        key = '%d_%s' % (num, slug)
        findings[key] = {'label': TITLES[num], 'count': len(hits),
                         'samples': [clip(h) for h in hits[:3]]}
        if not advice:
            score_hits[num] = score_hits.get(num, 0) + len(hits)
        fired.append((num, advice))

    # character-layer findings
    if inv:
        findings['62_invisible_characters'] = {
            'label': TITLES[62], 'count': len(inv),
            'samples': ['U+%04X at character %d' % (ord(window[i]), i) for i in inv[:3]]}
        score_hits[62] = len(inv)
    if homo_runs:
        findings['66_homoglyphs'] = {
            'label': TITLES[66], 'count': homo_runs,
            'samples': ['mixed-script letter run (%d lookalike characters)' % homo_chars]}
        score_hits[66] = homo_runs
    if ns:
        findings['67_nonstandard_spaces'] = {
            'label': TITLES[67], 'count': len(ns),
            'samples': ['U+%04X at character %d' % (ord(window[i]), i) for i in ns[:3]]}
        score_hits[67] = len(ns)
    if trail:
        findings['68_trailing_whitespace'] = {
            'label': TITLES[68], 'count': trail,
            'samples': ['trailing or stray whitespace']}

    conf, reason = _confidence(c.words, len(score_hits))
    score = _score(score_hits, c.words)
    metrics = {
        'scanned_chars': len(window),
        'truncated': bool(truncated),
        'ai_tell_score': score,
        'ai_tell_band': band_of(score),
        'confidence': conf,
        'confidence_reason': reason,
        'patterns_flagged': len(findings),
        'invisible_chars': len(inv),
        'nonstandard_spaces': len(ns),
        'homoglyphs': homo_chars,
        'words': c.words,
        'sentences': len(c.sents),
    }
    report = dict(findings)
    report['_metrics'] = metrics
    return report, c


def score_of(text):
    report, _ = analyze(text[:WINDOW])
    return report['_metrics']['ai_tell_score']


def interval(sents, window_len, rounds=None, seed=0):  # spec: N-000221 N-000222 N-000223 N-000224 N-000225
    """Bootstrap interval over sentences (FP-01 resampled interval)."""
    if len(sents) < 4:
        return None, 'too few sentences for an interval (fewer than four sentences); the point score is unchanged'
    if rounds is None:
        rounds = 30 if window_len <= 20000 else 8
    rng = random.Random(seed)
    scores = []
    for _ in range(rounds):
        sample = [sents[rng.randrange(len(sents))] for _ in range(len(sents))]
        scores.append(score_of(' '.join(sample)))
    scores.sort()
    low = scores[int(0.05 * (len(scores) - 1))]
    high = scores[int(round(0.95 * (len(scores) - 1)))]
    return [min(low, high), max(low, high)], (
        'bootstrap over %d sentences, %d resamples, seed %d; the point score is unchanged'
        % (len(sents), rounds, seed))


# ---------------------------------------------------------------------------
# Input extraction (FP-02)
# ---------------------------------------------------------------------------

def decode_plain(data):  # spec: N-000241 N-000242
    if data[:2] in (codecs.BOM_UTF16_LE, codecs.BOM_UTF16_BE):
        text = data.decode('utf-16', errors='replace')
    else:
        if data.startswith(codecs.BOM_UTF8):
            data = data[3:]
        text = data.decode('utf-8', errors='replace')
    if text.startswith('\ufeff'):
        text = text[1:]
    return text


def _local(tag):
    return tag.rsplit('}', 1)[-1] if isinstance(tag, str) else ''


def _xml(data):
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


MAX_MEMBER = 32 * 1024 * 1024


def _member(z, name):
    try:
        info = z.getinfo(name)
    except KeyError:
        return None
    if info.file_size > MAX_MEMBER:
        return None
    return z.read(name)


def _names(z, pattern):
    return sorted([n for n in z.namelist() if re.match(pattern, n, re.I)])


def _para_text(el):
    parts = []
    for node in el.iter():
        tag = _local(node.tag)
        if tag == 't':
            parts.append(node.text or '')
        elif tag == 'tab':
            parts.append('\t')
        elif tag in ('br', 'cr'):
            parts.append('\n')
    return ''.join(parts)


def extract_docx(z):  # spec: N-000243
    paras = []
    data = _member(z, 'word/document.xml')
    root = _xml(data) if data else None
    if root is None:
        return ''
    for el in root.iter():
        if _local(el.tag) == 'p':
            t = _para_text(el)
            if t.strip():
                paras.append(t)
    return '\n'.join(paras)


def extract_pptx(z):  # spec: N-000244
    slides = _names(z, r'ppt/slides/slide\d+\.xml$')
    slides.sort(key=lambda n: int(re.search(r'(\d+)\.xml$', n).group(1)))
    paras = []
    for name in slides:
        root = _xml(_member(z, name) or b'')
        if root is None:
            continue
        for el in root.iter():
            if _local(el.tag) == 'p':
                t = _para_text(el)
                if t.strip():
                    paras.append(t)
    return '\n'.join(paras)


def _shared_strings(z):
    data = _member(z, 'xl/sharedStrings.xml')
    root = _xml(data) if data else None
    table = []
    if root is None:
        return table
    for si in root:
        if _local(si.tag) == 'si':
            table.append(''.join(n.text or '' for n in si.iter() if _local(n.tag) == 't'))
    return table


def extract_xlsx(z):  # spec: N-000245
    shared = _shared_strings(z)
    rels = {}
    rdata = _member(z, 'xl/_rels/workbook.xml.rels')
    rroot = _xml(rdata) if rdata else None
    if rroot is not None:
        for r in rroot.iter():
            if _local(r.tag) == 'Relationship':
                rels[r.get('Id')] = r.get('Target', '')
    sheets = []
    wdata = _member(z, 'xl/workbook.xml')
    wroot = _xml(wdata) if wdata else None
    if wroot is not None:
        for s in wroot.iter():
            if _local(s.tag) == 'sheet':
                rid = None
                for k, v in s.attrib.items():
                    if _local(k) == 'id':
                        rid = v
                target = rels.get(rid, '')
                if target:
                    target = target.lstrip('/')
                    if not target.startswith('xl/'):
                        target = 'xl/' + target
                    sheets.append(target)
    if not sheets:
        sheets = _names(z, r'xl/worksheets/sheet\d+\.xml$')
    cells = []
    for name in sheets:
        root = _xml(_member(z, name) or b'')
        if root is None:
            continue
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            t = c.get('t')
            text = None
            if t == 's':
                v = None
                for ch in c:
                    if _local(ch.tag) == 'v':
                        v = (ch.text or '').strip()
                if v is not None and re.fullmatch(r'\d+', v) and int(v) < len(shared):
                    text = shared[int(v)]
            elif t == 'inlineStr':
                text = ''.join(n.text or '' for n in c.iter() if _local(n.tag) == 't')
            elif t == 'str':
                for ch in c:
                    if _local(ch.tag) == 'v':
                        text = ch.text or ''
            if text and text.strip():
                cells.append(text)
    return '\n'.join(cells)


def _odf_text(el):
    parts = []
    if el.text:
        parts.append(el.text)
    for ch in el:
        tag = _local(ch.tag)
        if tag == 's':
            parts.append(' ' * int(ch.get('{urn:oasis:names:tc:opendocument:xmlns:text:1.0}c') or 1))
        elif tag == 'tab':
            parts.append('\t')
        elif tag == 'line-break':
            parts.append('\n')
        else:
            parts.append(_odf_text(ch))
        if ch.tail:
            parts.append(ch.tail)
    return ''.join(parts)


def extract_odf(z):  # spec: N-000246
    data = _member(z, 'content.xml')
    root = _xml(data) if data else None
    if root is None:
        return ''
    paras = []
    for el in root.iter():
        if _local(el.tag) in ('p', 'h'):
            t = _odf_text(el)
            if t.strip():
                paras.append(t)
    return '\n'.join(paras)


BLOCK_TAGS = {'p', 'div', 'br', 'li', 'tr', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'section', 'article', 'blockquote', 'table', 'ul', 'ol', 'dt', 'dd'}
SKIP_TAGS = {'script', 'style', 'nav', 'head', 'title'}


class _HTMLText(html.parser.HTMLParser):
    def __init__(self):
        html.parser.HTMLParser.__init__(self, convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in SKIP_TAGS:
            self.skip += 1
        if tag in BLOCK_TAGS:
            self.parts.append('\n')

    def handle_endtag(self, tag):
        if tag in SKIP_TAGS and self.skip:
            self.skip -= 1
        if tag in BLOCK_TAGS:
            self.parts.append('\n')

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def extract_epub(z):  # spec: N-000247
    chapters = []
    for name in sorted(z.namelist()):
        low = name.lower()
        if not low.endswith(('.xhtml', '.html', '.htm')):
            continue
        base = os.path.basename(low)
        if 'nav' in base or 'toc' in base:
            continue
        data = _member(z, name)
        if not data:
            continue
        p = _HTMLText()
        try:
            p.feed(decode_plain(data))
            p.close()
        except Exception:
            continue
        lines = [' '.join(l.split()) for l in ''.join(p.parts).split('\n')]
        text = '\n'.join(l for l in lines if l)
        if text:
            chapters.append(text)
    return '\n'.join(chapters)


def extract_ipynb(data):  # spec: N-000248
    try:
        nb = json.loads(decode_plain(data))
    except ValueError:
        return ''
    cells = nb.get('cells') if isinstance(nb, dict) else None
    if not isinstance(cells, list):
        return ''
    out = []
    for cell in cells:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source', '')
        if isinstance(src, list) and all(isinstance(s, str) for s in src):
            src = ''.join(src)
        if not isinstance(src, str):
            return ''
        if src.strip():
            out.append(src)
    return '\n'.join(out)


def read_prose(path):  # spec: N-000226 N-000227 N-000228 N-000229 N-000230 N-000241 N-000246 N-000247 N-000248 N-000249 N-000250
    """Return the extracted prose for PATH (None = standard input)."""
    if path is None:
        return decode_plain(sys.stdin.buffer.read())
    ext = os.path.splitext(path)[1].lower()
    if ext in NO_PROSE_EXTS:
        return ''
    try:
        with open(path, 'rb') as fh:
            data = fh.read()
    except OSError as exc:
        raise InputError('cannot read input: %s: %s' % (path, exc.strerror or exc))
    if ext in ZIP_EXTS or ext in NB_EXTS:
        if ext in NB_EXTS:
            return extract_ipynb(data).strip()
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
        except (zipfile.BadZipFile, OSError, ValueError):
            raise InputError('cannot read input: %s: not a readable zip archive' % path)
        with z:
            try:
                if ext in ('.docx', '.docm'):
                    text = extract_docx(z)
                elif ext in ('.pptx', '.pptm'):
                    text = extract_pptx(z)
                elif ext in ('.xlsx', '.xlsm'):
                    text = extract_xlsx(z)
                elif ext == '.epub':
                    text = extract_epub(z)
                else:
                    text = extract_odf(z)
            except Exception:
                text = ''
        return text.strip()
    return decode_plain(data)


# ---------------------------------------------------------------------------
# Command line
# ---------------------------------------------------------------------------

def parse_args(argv):  # spec: N-000231
    opts = {'clean': False, 'ci': False, 'help': False, 'files': []}
    end = False
    for a in argv:
        if end:
            opts['files'].append(a)
            continue
        if a == '--':
            end = True
        elif a in ('-h', '--help'):
            opts['help'] = True
        elif a == '--clean':
            opts['clean'] = True
        elif a == '--ci':
            opts['ci'] = True
        elif a.startswith('-') and len(a) > 1:
            raise OptionError(a)
        else:
            opts['files'].append(a)
    return opts


def _err(msg):
    sys.stderr.write(json.dumps({'error': msg}, ensure_ascii=False) + '\n')
    sys.stderr.flush()


def _write_out(text):
    sys.stdout.buffer.write(text.encode('utf-8'))
    sys.stdout.flush()


def main(argv=None):  # spec: N-000094 N-000095 N-000096 N-000097 N-000098 N-000099 N-000231 N-000232 N-000233 N-000234 N-000235 N-000242
    if argv is None:
        argv = sys.argv[1:]
    try:
        opts = parse_args(argv)
    except OptionError as exc:
        _err('unknown option %s; see --help' % exc)
        return 2
    if opts['help']:
        _write_out(USAGE + '\n')
        return 0
    files = opts['files']
    path = None
    if files:
        path = files[0]
        if len(files) > 1:
            sys.stderr.write('detect.py: scanning only the first file "%s"; %d other operand(s) ignored\n'
                             % (files[0], len(files) - 1))
    try:
        prose = read_prose(path)
    except InputError as exc:
        _err(str(exc))
        return 1
    if prose.strip() == '':
        _err('empty input')
        return 1
    if opts['clean']:
        _write_out(clean_text(prose))
        return 0
    window = prose[:WINDOW]
    truncated = len(prose) > WINDOW
    report, ctx = analyze(window, truncated)
    if opts['ci']:
        ci, note = interval(ctx.sents, len(window))
        report['_metrics']['score_ci'] = ci
        report['_metrics']['score_ci_note'] = note
    if report['_metrics']['confidence'] == 'high':
        report['_metrics']['confidence_reason'] = ''
    _write_out(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main())
    except BrokenPipeError:
        sys.exit(0)
    except Exception as exc:  # never print a traceback
        _err('internal error: %s' % (exc.__class__.__name__,))
        sys.exit(1)
