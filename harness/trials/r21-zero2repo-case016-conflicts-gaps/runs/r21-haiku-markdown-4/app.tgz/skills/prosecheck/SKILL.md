---
name: prosecheck
description: Rewrite prose flagged by prosecheck when the user asks to "prosecheck this" or "humanize this".
---

# prosecheck rewrite guidance

The detector is `scripts/detect.py` (Python standard library only). Run it on a prose file with `python3 scripts/detect.py <file>`; it prints a JSON report with `ai_tell_score`, `ai_tell_band`, and one entry per fired pattern.

When asked for a deep rewrite, fix the flagged spans without changing facts, numbers, names, quotations, or citations. Keep sentence rhythm varied. Do not add a summary of the changes; do not mention the detector in the prose itself.
