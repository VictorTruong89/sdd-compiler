---
description: prosecheck - writing-contract level, saved-file check, doctor, show, init, stats, help
argument-hint: [lite|full|strict|off|on|status|show|check <path>|doctor|stats|init|help]
---
/prosecheck $ARGUMENTS
