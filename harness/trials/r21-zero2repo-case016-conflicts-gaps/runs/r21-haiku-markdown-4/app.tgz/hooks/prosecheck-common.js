'use strict';
// Shared logic for the prosecheck plugin hooks. Standard library only; no network.

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const SUBCOMMANDS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor',
  'stats', 'init', 'help'];
const WINDOW = 262144;
const WINDOW_TEXT = '262,144';
const PLAIN_CAP = 524288;      // 512 KB in bytes
const ARCHIVE_CAP = 4194304;   // 4 MB in bytes
const PLAIN_EXT = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ZIP_EXT = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'];
const NB_EXT = ['.ipynb'];
const BINARY_EXT = ['.pdf', '.rtf'];
const PROSE_EXT = new Set(PLAIN_EXT.concat(ZIP_EXT, NB_EXT));
const LEDGER_MAX = 20;
const LEDGER_AGE_MS = 7 * 24 * 60 * 60 * 1000;
const MAX_LABELS = 5;
const CHECK_LABELS = 8;
const MODE_FILE = '.prosecheck-active';
const LEDGER_PREFIX = '.prosecheck-ledger';
const MARK_START = '<!-- prosecheck:contract:start -->';
const MARK_END = '<!-- prosecheck:contract:end -->';
const INSTR_EXACT = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
const INSTR_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];
const BANDS = [
  [20, 'clean', 'reads clean'],
  [40, 'light tells', 'reads mostly clean'],
  [60, 'mixed', 'reads with some AI tells'],
  [80, 'heavy tells', 'reads with heavy AI tells'],
  [100, 'pervasive tells', 'reads with pervasive AI tells'],
];

// ------------------------------------------------------------------ plumbing

function pluginRoot() {
  if (process.env.CLAUDE_PLUGIN_ROOT && process.env.CLAUDE_PLUGIN_ROOT.trim()) {
    return path.resolve(process.env.CLAUDE_PLUGIN_ROOT.trim());
  }
  return path.resolve(__dirname, '..');
}

function configDir() {
  if (process.env.CLAUDE_CONFIG_DIR && process.env.CLAUDE_CONFIG_DIR.trim()) {
    return path.resolve(process.env.CLAUDE_CONFIG_DIR.trim());
  }
  return path.join(os.homedir(), '.claude');
}

function readInput() {
  let raw = '';
  try {
    raw = fs.readFileSync(0, 'utf8');
  } catch (e) {
    raw = '';
  }
  try {
    const obj = JSON.parse(raw);
    return obj && typeof obj === 'object' && !Array.isArray(obj) ? obj : {};
  } catch (e) {
    return {};
  }
}

function bandFor(score) {
  for (const [top, name, phrase] of BANDS) {
    if (score <= top) return { band: name, phrase };
  }
  return { band: BANDS[BANDS.length - 1][1], phrase: BANDS[BANDS.length - 1][2] };
}

function phraseForBand(name) {
  const hit = BANDS.find((b) => b[1] === name);
  return hit ? hit[2] : BANDS[0][2];
}

// ------------------------------------------------------------------ level

function readStoredLevel() {
  try {
    const v = fs.readFileSync(path.join(configDir(), MODE_FILE), 'utf8').trim().toLowerCase();
    return LEVELS.includes(v) ? v : null;
  } catch (e) {
    return null;
  }
}

function writeStoredLevel(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(path.join(configDir(), MODE_FILE), level + '\n', 'utf8');
    return true;
  } catch (e) {
    return false;
  }
}

function modeFileExists() {
  try {
    return fs.existsSync(path.join(configDir(), MODE_FILE));
  } catch (e) {
    return false;
  }
}

function effectiveLevel() {
  const env = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  if (LEVELS.includes(env)) return env;
  return readStoredLevel() || 'full';
}

// ------------------------------------------------------------------ detector

function detectorPath() {
  const root = pluginRoot();
  const primary = path.join(root, 'scripts', 'detect.py');
  if (fs.existsSync(primary)) return primary;
  const fallback = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  if (fs.existsSync(fallback)) return fallback;
  return primary;
}

// Runs the bundled detector with the first Python interpreter that can be launched.
// Returns {notFound}, {timedOut}, or {status, stdout, stderr}.
function runDetector(args, opts) {
  const options = opts || {};
  const timeout = options.timeoutMs || 8000;
  const detector = detectorPath();
  for (const name of ['python3', 'python', 'py']) {
    const res = spawnSync(name, [detector].concat(args), {
      input: options.input,
      encoding: 'utf8',
      timeout,
      maxBuffer: 64 * 1024 * 1024,
      windowsHide: true,
    });
    if (res.error) {
      if (res.error.code === 'ENOENT') continue;
      if (res.error.code === 'ETIMEDOUT') return { timedOut: true };
      return { notFound: true };
    }
    if (res.signal === 'SIGTERM' && res.status === null) return { timedOut: true };
    return { status: res.status, stdout: res.stdout || '', stderr: res.stderr || '' };
  }
  return { notFound: true };
}

function parseReport(stdout) {
  let obj;
  try {
    obj = JSON.parse(stdout);
  } catch (e) {
    return null;
  }
  if (!obj || typeof obj !== 'object' || !obj._metrics || typeof obj._metrics !== 'object') return null;
  if (typeof obj._metrics.ai_tell_score !== 'number') return null;
  return obj;
}

function findingsOf(report) {
  return Object.keys(report)
    .filter((k) => k !== '_metrics')
    .map((k) => ({ key: k, label: String((report[k] && report[k].label) || k), count: report[k].count || 0 }));
}

function lastErrorLine(stderr) {
  const lines = String(stderr || '').split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (!lines.length) return '';
  const last = lines[lines.length - 1];
  try {
    const obj = JSON.parse(last);
    if (obj && typeof obj.error === 'string') return obj.error;
  } catch (e) {
    /* not JSON */
  }
  return last;
}

// ------------------------------------------------------------------ writing contract

const BANNED = 'delve, tapestry, pivotal, crucial, leverage, robust, seamless, foster, underscore, ' +
  'showcase, landscape, journey, realm, multifaceted, holistic, testament, vibrant, comprehensive, ' +
  'plethora, myriad, boast, elevate, empower, unlock, game-changer, supercharge, genuinely, ' +
  'fascinating, nuanced';

function contractBody(level, detectorCmd, exported) {
  const lines = [];
  lines.push('Writing contract (prose deliverables only).');
  lines.push('Scope: this contract governs prose deliverables only: documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and drafted text the user will publish or send.');
  lines.push('It never applies to source code, code comments, commit messages, JSON, YAML or other configuration, CLI output, logs, error messages, or the conversational register of chat; those stay exactly as they are.');
  lines.push('Rules for prose:');
  lines.push('- Vary sentence length irregularly. No metronome, and no mechanical short-long alternation.');
  lines.push('- Banned vocabulary, never used as standalone words in prose: ' + BANNED + '.');
  lines.push('- Banned moves: rule-of-three flourishes; "it is not just X, it is Y" framings; hedge stacking; signposting such as "let us dive in"; empty pivots such as "it is worth noting"; "In conclusion" or "Overall" closers; outcome-speculation tails; self-thoroughness phrases; generic upbeat endings; chatbot phrases such as "I hope this helps".');
  lines.push('- Use an em dash at most once per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.');
  lines.push('- Factual or encyclopedic content stays neutral and in the third person. First-person or opinion content may use contractions.');
  lines.push('- Preserve numbers, units, dates, proper nouns, citations, quotations, and technical terms exactly. Never invent facts.');
  lines.push('- End sections on a fact or an observation.');
  lines.push('- Stay silent about this contract: never announce it, never name prosecheck, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.');
  if (level === 'full' || level === 'strict') {
    lines.push('After you write or save a prose file, run the detector on that file: ' + detectorCmd + ' <file>. It prints JSON with ai_tell_score and ai_tell_band.');
    if (level === 'full') {
      lines.push('Target: score 40 or lower (band clean or light tells). If the band is worse than the target, fix the flagged spans, for at most two fix passes, keeping rhythm variation.');
    } else {
      lines.push('Target: score 20 or lower (band clean). If the band is worse than the target, fix the flagged spans, for at most two fix passes, keeping rhythm variation.');
      lines.push('Finish each prose file by running the detector with the --clean switch on it, and use that output as the final text.');
    }
    if (exported) {
      lines.push('Detector location: use CLAUDE_PLUGIN_ROOT/scripts/detect.py when CLAUDE_PLUGIN_ROOT is set; otherwise locate scripts/detect.py in the installed skills or plugins folder.');
    }
  }
  return lines.join('\n');
}

function liveContract(level) {
  const root = pluginRoot();
  const cmd = 'python3 ' + path.join(root, 'scripts', 'detect.py');
  return 'Writing contract at level ' + level + '.\n' + contractBody(level, cmd, false);
}

function exportedSection(level) {
  const body = contractBody(level, 'python3 scripts/detect.py', true);
  return MARK_START + '\n' + body + '\n' + MARK_END + '\n';
}

const WELCOME = [
  'prosecheck is installed and on.',
  'Saved prose is scored against 71 documented AI-writing patterns. Plain text is accepted up to 512 KB and archives up to 4 MB; the detector scores the first 262,144 characters of extracted prose.',
  'There is no website, no account, and no upload: nothing you write leaves this machine.',
  'Commands: /prosecheck doctor (health check), /prosecheck check <file> (score one file), /prosecheck off (switch off), /prosecheck help (all commands).',
  'This welcome is shown once.',
].join('\n');

// ------------------------------------------------------------------ ledger

function ledgerFile(sessionId) {
  const sid = typeof sessionId === 'string' ? sessionId.trim() : '';
  const name = sid ? LEDGER_PREFIX + '-' + sid.replace(/[^A-Za-z0-9_-]/g, '_') : LEDGER_PREFIX;
  return path.join(configDir(), name);
}

function readLedger(file) {
  try {
    const arr = JSON.parse(fs.readFileSync(file, 'utf8'));
    return Array.isArray(arr) ? arr : [];
  } catch (e) {
    return [];
  }
}

function appendLedger(sessionId, record) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    const file = ledgerFile(sessionId);
    let arr = readLedger(file);
    arr.push(record);
    arr = arr.slice(-LEDGER_MAX);
    fs.writeFileSync(file, JSON.stringify(arr, null, 1), 'utf8');
  } catch (e) {
    /* ledger is best effort */
  }
}

function pruneLedgers() {
  try {
    const dir = configDir();
    for (const name of fs.readdirSync(dir)) {
      if (name !== LEDGER_PREFIX && !name.startsWith(LEDGER_PREFIX + '-')) continue;
      const full = path.join(dir, name);
      const st = fs.statSync(full);
      if (Date.now() - st.mtimeMs > LEDGER_AGE_MS) fs.unlinkSync(full);
    }
  } catch (e) {
    /* nothing to prune */
  }
}

// ------------------------------------------------------------------ replies

function block(reason) {
  return { decision: 'block', reason };
}

function helpReply(level) {
  return [
    'prosecheck is set to ' + level + '.',
    'Subcommands (type /prosecheck <word>):',
    '/prosecheck lite - writing contract on; no saved-file scoring.',
    '/prosecheck full - writing contract plus the saved-file guard, threshold 40 (default).',
    '/prosecheck strict - saved-file guard threshold 20 and the cleanup scrub.',
    '/prosecheck off | on - off: disable the tool. on: re-enable it (stores full).',
    '/prosecheck check <path> - score one file; report only, it never rewrites the file.',
    '/prosecheck doctor - health check of the install.',
    '/prosecheck stats - session token totals and the score of the session\'s own prose.',
    '/prosecheck init - export the writing contract to ./AGENTS.md for agents other than Claude Code.',
    '/prosecheck status - show the current level in one line.',
    '/prosecheck show - list files scored in this session.',
    'Code, commits, config, and chat are always left alone, and the contract never touches them.',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function unknownReply(word) {
  return 'unknown subcommand "' + word + '". Valid subcommands: ' + SUBCOMMANDS.join(', ') + '. Level unchanged.';
}

function stripPathArg(raw) {
  let p = String(raw || '').trim();
  if (p.length >= 2 && ((p[0] === '"' && p[p.length - 1] === '"') || (p[0] === "'" && p[p.length - 1] === "'"))) {
    p = p.slice(1, -1);
  }
  if (p.startsWith('@')) p = p.slice(1);
  if (p.length >= 2 && ((p[0] === '"' && p[p.length - 1] === '"') || (p[0] === "'" && p[p.length - 1] === "'"))) {
    p = p.slice(1, -1);
  }
  return p.trim();
}

function kbOf(bytes) {
  return Math.round(bytes / 1024);
}

function checkReply(rawArg, cwd) {
  const shown = stripPathArg(rawArg);
  if (!shown) {
    return 'check needs a file path: /prosecheck check <path>. No score is given without a path, and the file is unchanged.';
  }
  const abs = path.resolve(cwd || process.cwd(), shown);
  const base = path.basename(abs);
  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    return 'cannot read ' + shown + ': the path does not exist or cannot be opened. Nothing was scored; the file is unchanged.';
  }
  if (st.isDirectory()) {
    return shown + ' is not a file. Nothing was scored; the file is unchanged.';
  }
  const ext = path.extname(abs).toLowerCase();
  if (BINARY_EXT.includes(ext)) {
    return base + ': no readable text in this format (PDF and RTF are not scored). The file is unchanged.';
  }
  const archive = ZIP_EXT.includes(ext) || NB_EXT.includes(ext);
  const cap = archive ? ARCHIVE_CAP : PLAIN_CAP;
  if (st.size > cap) {
    return base + ': over ' + kbOf(cap) + ' KB, the size limit for this format. Not scored; the file is unchanged.';
  }
  const res = runDetector([abs], { timeoutMs: archive ? 15000 : 8000 });
  if (res.notFound) {
    return base + ': detector unavailable (Python could not be launched). Nothing was scored; the file is unchanged.';
  }
  if (res.timedOut) {
    return base + ' failed: the detector timed out. The file is unchanged.';
  }
  if (res.status === 0) {
    if (!String(res.stdout).trim()) {
      return base + ': no report (the detector printed nothing). The file is unchanged.';
    }
    const report = parseReport(res.stdout);
    if (!report) {
      return 'no report: the detector output was not a structured report. The file is unchanged.';
    }
    const m = report._metrics;
    const phrase = phraseForBand(m.ai_tell_band);
    const lines = [];
    lines.push(base + ' - ' + phrase + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')');
    let conf = 'confidence: ' + m.confidence;
    if (m.confidence !== 'high' && m.confidence_reason) conf += ' - ' + m.confidence_reason;
    lines.push(conf);
    if (m.truncated) lines.push('coverage: first ' + WINDOW_TEXT + ' characters only');
    const f = findingsOf(report).slice(0, CHECK_LABELS);
    lines.push(f.length ? 'tells: ' + f.map((x) => x.label + ' (x' + x.count + ')').join('; ') : 'tells: none');
    lines.push('This is a report only; the file was not changed.');
    return lines.join('\n');
  }
  const why = lastErrorLine(res.stderr);
  return base + ' failed' + (why ? ': ' + why : '') + '. The file is unchanged.';
}

function doctorReply(form) {
  const level = effectiveLevel();
  const root = pluginRoot();
  const cfg = configDir();

  let modeLine;
  const modeOk = level !== 'off';
  if (modeOk) {
    modeLine = '[OK] mode: ' + level + ' - the tool is on.';
  } else {
    modeLine = '[--] mode: off - the tool is switched off (not a fault of the install); run /prosecheck on to re-enable.';
  }

  const det = detectorPath();
  const detOk = fs.existsSync(det);
  const detLine = detOk
    ? '[OK] detector: bundled detector found at ' + det + '.'
    : '[!!] detector: bundled detector not found under the plugin root ' + root + '.';

  const probe = runDetector([], { input: 'Probe sentence for the health check.', timeoutMs: 8000 });
  let pyOk = false;
  let pyLine;
  if (probe.notFound) {
    pyLine = '[!!] python not found: Python cannot be launched, so saved files are not re-scored until Python is available; prose is still shaped by the writing contract.';
  } else {
    const report = probe.status === 0 ? parseReport(probe.stdout) : null;
    if (report) {
      pyOk = true;
      pyLine = '[OK] python: Python ran the bundled detector and returned score ' + report._metrics.ai_tell_score + '.';
    } else {
      pyLine = '[!!] python: the detector run returned no numeric score.';
    }
  }

  let setOk = false;
  let setLine;
  try {
    fs.mkdirSync(cfg, { recursive: true });
    fs.accessSync(cfg, fs.constants.W_OK);
    setOk = true;
    setLine = '[OK] settings: folder ' + cfg + ' is writable.';
  } catch (e) {
    setLine = '[!!] settings: folder ' + cfg + ' is not writable.';
  }

  const allOk = detOk && pyOk && setOk;
  let closer;
  if (!allOk) {
    closer = 'Fix the faulty checks marked [!!] above, then run /prosecheck doctor again.';
  } else if (modeOk) {
    closer = 'prosecheck is active. Plain text up to 512 KB and archives up to 4 MB are scored, and only the first 262,144 characters are read. Run ' + form + ' show to see files that were only partly scanned or skipped.';
  } else {
    closer = 'Everything else is healthy. Saving files is not scored while the tool is off. Run ' + form + ' on to turn it back on.';
  }
  return ['prosecheck doctor', modeLine, detLine, pyLine, setLine, closer].join('\n');
}

function showReply(sessionId) {
  const file = ledgerFile(sessionId);
  let rows = [];
  try {
    const st = fs.statSync(file);
    if (Date.now() - st.mtimeMs <= LEDGER_AGE_MS) rows = readLedger(file);
  } catch (e) {
    rows = [];
  }
  if (!rows.length) {
    return 'nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const out = ['Session ledger (newest first):'];
  for (const r of rows.slice().reverse()) {
    const base = String(r.base || '?');
    if (r.kind === 'scored') {
      const trunc = r.truncated ? ', first ' + WINDOW_TEXT + ' characters only' : '';
      let row = base + ' - ' + phraseForBand(r.band) + ' (score ' + r.score + '/' + r.band + trunc + ')';
      if (Array.isArray(r.labels) && r.labels.length) {
        const state = r.flagged ? 'flagged' : 'under the threshold';
        row += ' - ' + state + ': ' + r.labels.slice(0, MAX_LABELS).join('; ');
      }
      out.push(row);
    } else if (r.kind === 'skipped') {
      out.push(base + ' - not scored: the file is over the ' + r.capKb + ' KB limit.');
    } else if (r.kind === 'binary') {
      out.push(base + ' - not re-scored (binary format with no readable text).');
    } else {
      out.push(base + ' - not scored: ' + (r.reason || 'unknown reason'));
    }
  }
  return out.join('\n');
}

function initReply(form, cwd, level) {
  if (level === 'off') {
    return 'prosecheck is switched off, so nothing was written (no AGENTS.md and no Cursor rule). Run ' + form + ' on to allow the export.';
  }
  const lines = [];
  const agents = path.join(cwd || process.cwd(), 'AGENTS.md');
  let existing = null;
  let readable = true;
  try {
    if (fs.existsSync(agents)) existing = fs.readFileSync(agents, 'utf8');
  } catch (e) {
    readable = false;
  }
  if (!readable) {
    lines.push('cannot read AGENTS.md; the contract was not written there.');
  } else if (existing !== null && existing.includes(MARK_START)) {
    lines.push('AGENTS.md already contains the prosecheck contract section; it was left unchanged.');
  } else {
    try {
      const section = exportedSection(level);
      let text;
      if (existing === null) {
        text = section;
      } else {
        const sep = existing.length === 0 || existing.endsWith('\n') ? '\n' : '\n\n';
        text = existing + sep + section;
      }
      fs.writeFileSync(agents, text, 'utf8');
      lines.push('AGENTS.md: the prosecheck writing contract was written.');
    } catch (e) {
      lines.push('cannot write AGENTS.md; the contract was not written there.');
    }
  }

  const src = path.join(pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
  const destDir = path.join(cwd || process.cwd(), '.cursor', 'rules');
  const dest = path.join(destDir, 'prosecheck.mdc');
  try {
    if (fs.existsSync(dest)) {
      lines.push('.cursor/rules/prosecheck.mdc already exists; it was left unchanged.');
    } else if (!fs.existsSync(src)) {
      lines.push('cannot write .cursor/rules/prosecheck.mdc: the shipped rule was not found.');
    } else {
      fs.mkdirSync(destDir, { recursive: true });
      fs.copyFileSync(src, dest);
      lines.push('.cursor/rules/prosecheck.mdc was written.');
    }
  } catch (e) {
    lines.push('cannot write .cursor/rules/prosecheck.mdc.');
  }
  return lines.join('\n');
}

function newestTranscript() {
  const root = path.join(configDir(), 'projects');
  let best = null;
  const walk = (dir, depth) => {
    if (depth > 6) return;
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (e) {
      return;
    }
    for (const ent of entries) {
      const full = path.join(dir, ent.name);
      if (ent.isDirectory()) walk(full, depth + 1);
      else if (ent.isFile() && ent.name.endsWith('.jsonl')) {
        try {
          const mt = fs.statSync(full).mtimeMs;
          if (!best || mt > best.mt) best = { file: full, mt };
        } catch (e) {
          /* skip */
        }
      }
    }
  };
  walk(root, 0);
  return best ? best.file : null;
}

function statsReply(transcriptPath, level) {
  const named = typeof transcriptPath === 'string' && transcriptPath.trim() ? transcriptPath.trim() : null;
  const file = named || newestTranscript();
  let raw = null;
  if (file) {
    try {
      raw = fs.readFileSync(file, 'utf8');
    } catch (e) {
      raw = null;
    }
  }
  if (raw === null) {
    return ['prosecheck stats: the session transcript could not be read, so no turn or token counts are available.', 'level: ' + level].join('\n');
  }
  const msgs = new Map();
  const seenText = new Set();
  const texts = [];
  let rowIndex = 0;
  for (const line of raw.split(/\r?\n/)) {
    if (!line.trim()) continue;
    let row;
    try {
      row = JSON.parse(line);
    } catch (e) {
      continue;
    }
    rowIndex += 1;
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const id = typeof msg.id === 'string' && msg.id ? msg.id : (row.uuid || 'row-' + rowIndex);
    const usage = msg.usage && typeof msg.usage === 'object' ? msg.usage : null;
    if (!msgs.has(id)) msgs.set(id, { output: 0, cache: 0 });
    if (usage) {
      const rec = msgs.get(id);
      rec.output = Number(usage.output_tokens) || 0;
      rec.cache = Number(usage.cache_read_input_tokens) || 0;
    }
    if (Array.isArray(msg.content)) {
      for (const c of msg.content) {
        if (c && c.type === 'text' && typeof c.text === 'string') {
          const key = id + '\u0000' + c.text;
          if (!seenText.has(key)) {
            seenText.add(key);
            texts.push(c.text);
          }
        }
      }
    }
  }
  let outTokens = 0;
  let cacheTokens = 0;
  for (const rec of msgs.values()) {
    outTokens += rec.output;
    cacheTokens += rec.cache;
  }
  const lines = [
    'prosecheck stats',
    'level: ' + level,
    'assistant turns: ' + msgs.size,
    'output tokens: ' + outTokens,
    'cache-read input tokens: ' + cacheTokens,
  ];
  let prose = texts.join('\n\n').replace(/```[\s\S]*?```/g, ' ').replace(/~~~[\s\S]*?~~~/g, ' ');
  if (prose.length > 40000) prose = prose.slice(prose.length - 40000);
  prose = prose.trim();
  if (prose.length > 200) {
    const res = runDetector([], { input: prose, timeoutMs: 8000 });
    const report = res.status === 0 ? parseReport(res.stdout) : null;
    if (report) lines.push('session prose ai_tell_score: ' + report._metrics.ai_tell_score);
  }
  return lines.join('\n');
}

module.exports = {
  LEVELS, SUBCOMMANDS, WINDOW, PLAIN_CAP, ARCHIVE_CAP, PLAIN_EXT, ZIP_EXT, NB_EXT, BINARY_EXT,
  PROSE_EXT, LEDGER_MAX, LEDGER_AGE_MS, INSTR_EXACT, INSTR_STEMS, MODE_FILE, MARK_START, MARK_END,
  WELCOME, pluginRoot, configDir, readInput, bandFor, phraseForBand, readStoredLevel,
  writeStoredLevel, modeFileExists, effectiveLevel, detectorPath, runDetector, parseReport,
  findingsOf, lastErrorLine, liveContract, exportedSection, ledgerFile, readLedger, appendLedger,
  pruneLedgers, block, helpReply, unknownReply, checkReply, doctorReply, showReply, initReply,
  statsReply, stripPathArg,
};
