#!/usr/bin/env node
'use strict';
// Stats hook: reads the prompt-submit object on standard input and returns the stats reply
// as a block decision (the same reply the /prosecheck router gives for "stats").
const common = require('./prosecheck-common.js');

function main() {
  const input = common.readInput();
  const reply = common.statsReply(input.transcript_path, common.effectiveLevel());
  process.stdout.write(JSON.stringify(common.block(reply)));
}

try {
  main();
} catch (e) {
  /* never fail the host session */
}
process.exitCode = 0;
