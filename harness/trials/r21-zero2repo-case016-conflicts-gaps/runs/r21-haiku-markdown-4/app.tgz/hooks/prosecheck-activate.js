#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract in context (and a one-time welcome).
const fs = require('fs');
const path = require('path');
const common = require('./prosecheck-common.js');

function main() {
  common.readInput();
  const firstRun = !common.modeFileExists();
  if (firstRun) {
    // Store the level that applies now (default full) so later hooks see it.
    const resolved = common.effectiveLevel();
    common.writeStoredLevel(resolved === 'off' ? 'full' : resolved);
  }
  common.pruneLedgers();
  const level = common.effectiveLevel();
  if (level === 'off') return;
  let out = '';
  if (firstRun) out += common.WELCOME + '\n\n';
  out += common.liveContract(level) + '\n';
  process.stdout.write(out);
}

try {
  main();
} catch (e) {
  /* never fail the host session */
}
process.exitCode = 0;
