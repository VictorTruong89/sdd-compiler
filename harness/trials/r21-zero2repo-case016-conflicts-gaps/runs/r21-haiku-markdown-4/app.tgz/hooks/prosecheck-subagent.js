#!/usr/bin/env node
'use strict';
// Subagent-start hook: returns the same writing contract inside the SubagentStart envelope.
const common = require('./prosecheck-common.js');

function main() {
  common.readInput();
  const level = common.effectiveLevel();
  if (level === 'off') return;
  const envelope = {
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: common.liveContract(level),
    },
  };
  process.stdout.write(JSON.stringify(envelope));
}

try {
  main();
} catch (e) {
  /* never fail the host session */
}
process.exitCode = 0;
