#!/usr/bin/env node
'use strict';
// Prompt-submit hook: routes /prosecheck commands (blocked, with a reply) and adds the
// writing-contract reminder to ordinary prompts.
const path = require('path');
const common = require('./prosecheck-common.js');

function route(input) {
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const trimmed = prompt.trim();
  const lower = trimmed.toLowerCase();
  const sessionId = typeof input.session_id === 'string' ? input.session_id : '';
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();

  // Whole-prompt stop phrases switch the tool off.
  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    common.writeStoredLevel('off');
    return common.block('prosecheck is off: the writing contract and saved-file scoring are switched off. Run /prosecheck on to re-enable.');
  }

  const m = trimmed.match(/^\/prosecheck(?::prosecheck)?(?=\s|$)/i);
  if (!m) {
    const level = common.effectiveLevel();
    if (level === 'off') return null;
    return {
      hookSpecificOutput: {
        hookEventName: 'UserPromptSubmit',
        additionalContext: 'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.',
      },
    };
  }

  const form = m[0].toLowerCase();
  const rest = trimmed.slice(m[0].length).trim();
  const words = rest.split(/\s+/);
  const sub = (words[0] || '').toLowerCase();
  const arg = rest.slice((words[0] || '').length).trim();

  if (!sub || sub === 'help') {
    return common.block(common.helpReply(common.effectiveLevel()));
  }
  if (!common.SUBCOMMANDS.includes(sub)) {
    return common.block(common.unknownReply(words[0]));
  }

  switch (sub) {
    case 'lite':
    case 'full':
    case 'strict':
      common.writeStoredLevel(sub);
      if (sub === 'lite') return common.block('prosecheck level set to lite: the writing contract is on; saved files are not scored.');
      if (sub === 'full') return common.block('prosecheck level set to full: the writing contract is on and saved prose files are scored.');
      return common.block('prosecheck level set to strict: the writing contract is on, saved files are scored at the strict threshold, and the cleanup scrub is asked for.');
    case 'off':
      common.writeStoredLevel('off');
      return common.block('prosecheck is off: the writing contract and saved-file scoring are switched off. Run ' + form + ' on to re-enable.');
    case 'on':
      common.writeStoredLevel('full');
      return common.block('prosecheck is on: level full.');
    case 'status':
      return common.block('prosecheck level: ' + common.effectiveLevel());
    case 'show':
      return common.block(common.showReply(sessionId));
    case 'check':
      return common.block(common.checkReply(arg, cwd));
    case 'doctor':
      return common.block(common.doctorReply(form));
    case 'stats':
      return common.block(common.statsReply(input.transcript_path, common.effectiveLevel()));
    case 'init':
      return common.block(common.initReply(form, cwd, common.effectiveLevel()));
    default:
      return common.block(common.unknownReply(words[0]));
  }
}

function main() {
  const input = common.readInput();
  const out = route(input);
  if (out) process.stdout.write(JSON.stringify(out));
}

try {
  main();
} catch (e) {
  /* never fail the host session */
}
process.exitCode = 0;
