#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when it is flagged.
const fs = require('fs');
const path = require('path');
const common = require('./prosecheck-common.js');

const EDIT_TOOLS = new Set(['write', 'edit', 'multiedit', 'notebookedit', 'apply_patch']);
const MAX_PATCH_PATHS = 16;

function patchPaths(command) {
  const out = [];
  const seen = new Set();
  for (const line of String(command || '').split(/\r?\n/)) {
    const m = line.match(/^\*\*\* (Add File|Update File|Move to):(.*)$/);
    if (!m) continue;
    const p = m[2].trim();
    if (!p || seen.has(p)) continue;
    seen.add(p);
    out.push(p);
    if (out.length >= MAX_PATCH_PATHS) break;
  }
  return out;
}

function targetsOf(toolName, toolInput, input) {
  const name = toolName.toLowerCase();
  if (name === 'apply_patch') {
    const cmd = typeof toolInput.command === 'string' ? toolInput.command : '';
    return patchPaths(cmd);
  }
  if (name === 'notebookedit') {
    const p = typeof toolInput.notebook_path === 'string' && toolInput.notebook_path.trim()
      ? toolInput.notebook_path : toolInput.file_path;
    return typeof p === 'string' && p.trim() ? [p.trim()] : [];
  }
  const p = toolInput.file_path;
  return typeof p === 'string' && p.trim() ? [p.trim()] : [];
}

function insidePluginTree(abs) {
  const rel = path.relative(common.pluginRoot(), abs);
  return rel !== '' && !rel.startsWith('..') && !path.isAbsolute(rel);
}

function skipForPath(abs) {
  const segments = abs.split(/[\\/]/);
  if (segments.includes('node_modules') || segments.includes('.git')) return true;
  if (insidePluginTree(abs)) return true;
  const base = path.basename(abs).toLowerCase();
  if (common.INSTR_EXACT.includes(base)) return true;
  const ext = path.extname(base);
  const stem = ext ? base.slice(0, -ext.length) : base;
  if (common.INSTR_STEMS.includes(stem) && !common.PROSE_EXT.has(ext)) return true;
  return false;
}

function scoreOne(abs, sessionId, threshold) {
  const base = path.basename(abs);
  const ext = path.extname(abs).toLowerCase();
  const at = Date.now();
  const record = (rec) => common.appendLedger(sessionId, Object.assign({ base, at }, rec));

  if (common.BINARY_EXT.includes(ext)) {
    record({ kind: 'binary' });
    return null;
  }
  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    record({ kind: 'failed', reason: 'cannot read the file' });
    return null;
  }
  if (!st.isFile()) return null;

  const archive = common.ZIP_EXT.includes(ext) || common.NB_EXT.includes(ext);
  const cap = archive ? common.ARCHIVE_CAP : common.PLAIN_CAP;
  if (st.size > cap) {
    record({ kind: 'skipped', capKb: Math.round(cap / 1024) });
    return null;
  }

  const res = common.runDetector([abs], { timeoutMs: archive ? 15000 : 8000 });
  if (res.notFound) {
    record({ kind: 'failed', reason: 'Python cannot be found' });
    return null;
  }
  if (res.timedOut) {
    record({ kind: 'failed', reason: 'the detector timed out' });
    return null;
  }
  if (res.status !== 0) {
    const why = common.lastErrorLine(res.stderr);
    record({ kind: 'failed', reason: why ? 'the detector failed: ' + why : 'no usable result from the detector' });
    return null;
  }
  if (!String(res.stdout).trim()) {
    record({ kind: 'failed', reason: 'no usable result from the detector' });
    return null;
  }
  const report = common.parseReport(res.stdout);
  if (!report) {
    const parsedOk = (() => { try { JSON.parse(res.stdout); return true; } catch (e) { return false; } })();
    record({ kind: 'failed', reason: parsedOk ? 'the report has no numeric score' : 'the detector output is not a structured report' });
    return null;
  }

  const m = report._metrics;
  const labels = common.findingsOf(report).map((f) => f.label);
  const flagged = m.ai_tell_score > threshold;
  record({
    kind: 'scored', score: m.ai_tell_score, band: m.ai_tell_band,
    labels: labels.slice(0, common.MAX_LABELS), flagged, truncated: !!m.truncated,
  });
  if (!flagged) return null;

  const phrase = common.phraseForBand(m.ai_tell_band);
  const coverage = m.truncated ? ', first ' + common.WINDOW_TEXT + ' characters only' : '';
  const shown = labels.slice(0, common.MAX_LABELS);
  return 'prosecheck: ' + base + ' ' + phrase + ' (score ' + m.ai_tell_score + ', band ' + m.ai_tell_band + coverage + '). '
    + 'Flagged: ' + (shown.length ? shown.join('; ') : 'none listed') + '. '
    + 'Fix the flagged spans in ' + base + ', keeping sentence rhythm varied.';
}

function main() {
  const input = common.readInput();
  const level = common.effectiveLevel();
  if (level === 'off' || level === 'lite') return;

  const toolName = typeof input.tool_name === 'string' ? input.tool_name : '';
  if (!EDIT_TOOLS.has(toolName.toLowerCase())) return;
  const toolInput = input.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const sessionId = typeof input.session_id === 'string' ? input.session_id : '';
  const threshold = level === 'strict' ? 20 : 40;

  const nudges = [];
  for (const raw of targetsOf(toolName, toolInput, input)) {
    const abs = path.resolve(cwd, raw);
    if (skipForPath(abs)) continue;
    const ext = path.extname(abs).toLowerCase();
    if (!common.PROSE_EXT.has(ext) && !common.BINARY_EXT.includes(ext)) continue;
    const line = scoreOne(abs, sessionId, threshold);
    if (line) nudges.push(line);
  }
  if (nudges.length) {
    const envelope = {
      hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: nudges.join('\n') },
    };
    process.stdout.write(JSON.stringify(envelope));
  }
}

try {
  main();
} catch (e) {
  /* never fail the host session */
}
process.exitCode = 0;
