#!/usr/bin/env python3
"""prosecheck detector: a local, standard-library-only AI-writing pattern scanner.

Usage: detect.py [--clean] [--ci] [--] [FILE]
       detect.py --help | -h

With no FILE the detector reads standard input. Reports are JSON on standard
output; failures write one JSON object {"error": ...} as the last stderr line.
"""
import codecs
import json
import math
import os
import re
import sys
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from collections import Counter
from html.parser import HTMLParser
from posixpath import dirname, normpath, join as pjoin

WINDOW = 262144
PLAIN_CAP = 512 * 1024
ARCHIVE_CAP = 4 * 1024 * 1024
PLAIN_EXT = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXT = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NB_EXT = {'.ipynb'}
BINARY_EXT = {'.pdf', '.rtf'}

USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Scan a prose file (or standard input) for AI-writing patterns.

  --clean   print the cleaned text instead of the JSON report
  --ci      add a low/high interval on the score (needs at least 4 sentences)
  --        end option parsing (so FILE may begin with a dash)
  -h, --help  show this message

Supported formats: .md .mdx .markdown .txt .text .rst .tex .org .adoc (plain text),
.docx .docm .pptx .pptm .xlsx .xlsm .odt .odp .ods .epub (zip), .ipynb (notebook).
Only the first 262144 characters of extracted prose are scanned.
"""

TITLES = {
    1: 'AI vocabulary', 2: 'model-dialect vocabulary', 3: 'promotional language',
    4: 'hyphenated word-pair overuse', 5: 'simple yet X cliche', 6: 'stacked adjective chains',
    7: 'rule of three overuse', 8: 'synonym cycling', 9: 'generic character naming',
    10: 'significance inflation', 11: 'notability name-dropping', 12: 'vague attributions',
    13: 'article titles as proper nouns', 14: 'conservation ecosystem padding', 15: 'false ranges',
    16: 'superficial -ing tail clauses', 17: 'negative parallelisms and tailing negations',
    18: 'Not X, just Y framing', 19: 'filler phrases', 20: 'empty pivot phrases',
    21: 'outcome speculation tails', 22: 'persuasive authority tropes', 23: 'editorial interjections',
    24: 'self-thoroughness phrases', 25: 'question-answer rhetorical pattern',
    26: 'concrete evidence defense phrase', 27: 'compulsive intro hooks', 28: 'meandering intro',
    29: 'prompt echo', 30: 'diff-anchored writing', 31: 'signposting and announcements',
    32: 'cataloguing lead-ins', 33: 'inline-header vertical lists', 34: 'mid-essay bullet injection',
    35: 'fragmented headers', 36: 'formulaic challenges sections', 37: 'transition cluster overuse',
    38: 'compulsive conclusion phrases', 39: 'generic positive conclusions',
    40: 'sentence-length monotony', 41: 'mechanical sentence-length alternation',
    42: 'opener repetition', 43: 'avoidance of fragments and run-ons', 44: 'uniform paragraph length',
    45: 'identical paragraph structure', 46: 'semicolon and parenthesis underuse',
    47: 'chatbot artifacts', 48: 'sycophantic tone', 49: 'helpful-assistant register',
    50: 'knowledge-cutoff disclaimers', 51: 'copula avoidance', 52: 'passive voice and subjectless fragments',
    53: 'two-way passive-voice drift', 54: 'excessive hedging', 55: 'contraction absence',
    56: 'boldface overuse', 57: 'emoji', 58: 'em-dash overuse', 59: 'title case in headings',
    60: 'curly quotation marks', 61: 'hyphen-for-en-dash in numeric ranges',
    62: 'invisible or zero-width characters', 63: 'placeholder text', 64: 'chat reference markup leak',
    65: 'AI tracking parameters', 66: 'mixed-script lookalike characters', 67: 'non-standard spaces',
    68: 'trailing or stray whitespace', 69: 'canonical marketing-slop phrases',
    70: 'decorative horizontal rules', 71: 'degenerate repetition',
}

NO_DETECTOR = {7, 9, 28, 29, 43, 45, 49, 52, 53}
ADVICE_NUMS = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
DECISIVE_NUMS = {13, 47, 48, 50, 62, 63, 64, 65, 66}
RHYTHM_NUMS = {40, 41, 44, 55}
SHORT_FLOOR_SET = set(range(1, 40)) | set(range(47, 52)) | {69}
SHORT_FLOOR_WORDS = 120
LONG_FLOOR_WORDS = 400

BANDS = [(20, 'clean', 'reads clean'), (40, 'light tells', 'reads mostly clean'),
         (60, 'mixed', 'reads with some AI tells'), (80, 'heavy tells', 'reads with heavy AI tells'),
         (100, 'pervasive tells', 'reads with pervasive AI tells')]


class Fail(Exception):
    def __init__(self, code, message):
        Exception.__init__(self, message)
        self.code = code
        self.message = message


# ---------------------------------------------------------------- bands

def band_for(score):
    for top, name, phrase in BANDS:
        if score <= top:
            return name, phrase
    return BANDS[-1][1], BANDS[-1][2]


def phrase_for_band(name):
    for _, n, phrase in BANDS:
        if n == name:
            return phrase
    return BANDS[0][2]


# ---------------------------------------------------------------- decoding and extraction

def decode_bytes(data):
    if data.startswith(codecs.BOM_UTF8):
        return data[len(codecs.BOM_UTF8):].decode('utf-8', 'replace')
    if data.startswith(codecs.BOM_UTF16_LE):
        return data[2:].decode('utf-16-le', 'replace')
    if data.startswith(codecs.BOM_UTF16_BE):
        return data[2:].decode('utf-16-be', 'replace')
    return data.decode('utf-8', 'replace')


def _local(tag):
    if not isinstance(tag, str):
        return ''
    return tag.rsplit('}', 1)[-1]


def _parse_xml(data):
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


def _docx_text(z):
    root = _parse_xml(z.read('word/document.xml'))
    if root is None:
        return ''
    paras = []
    for p in root.iter():
        if _local(p.tag) != 'p':
            continue
        parts = []
        for node in p.iter():
            tag = _local(node.tag)
            if tag == 't' and node.text:
                parts.append(node.text)
            elif tag == 'tab':
                parts.append('\t')
            elif tag == 'br':
                parts.append('\n')
        paras.append(''.join(parts))
    return '\n'.join(paras)


def _pptx_text(z):
    names = [n for n in z.namelist() if re.match(r'ppt/slides/slide\d+\.xml$', n)]
    names.sort(key=lambda n: int(re.search(r'(\d+)\.xml$', n).group(1)))
    slides = []
    for name in names:
        root = _parse_xml(z.read(name))
        if root is None:
            continue
        paras = []
        for p in root.iter():
            if _local(p.tag) != 'p':
                continue
            parts = []
            for node in p.iter():
                if _local(node.tag) == 't' and node.text:
                    parts.append(node.text)
            paras.append(''.join(parts))
        slides.append('\n'.join(x for x in paras if x.strip()))
    return '\n'.join(s for s in slides if s.strip())


def _xlsx_text(z):
    shared = []
    if 'xl/sharedStrings.xml' in z.namelist():
        root = _parse_xml(z.read('xl/sharedStrings.xml'))
        if root is not None:
            for si in root:
                if _local(si.tag) == 'si':
                    shared.append(''.join(t.text or '' for t in si.iter() if _local(t.tag) == 't'))
    sheet_names = sorted((n for n in z.namelist() if re.match(r'xl/worksheets/sheet\d+\.xml$', n)),
                         key=lambda n: int(re.search(r'(\d+)\.xml$', n).group(1)))
    out_sheets = []
    for name in sheet_names:
        root = _parse_xml(z.read(name))
        if root is None:
            continue
        cells = []
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            t = c.get('t', '')
            text = None
            if t == 's':
                v = None
                for ch in c:
                    if _local(ch.tag) == 'v':
                        v = (ch.text or '').strip()
                if v is not None and v.isdigit() and int(v) < len(shared):
                    text = shared[int(v)]
            elif t == 'inlineStr':
                text = ''.join(x.text or '' for x in c.iter() if _local(x.tag) == 't')
            elif t == 'str':
                text = ''.join(x.text or '' for x in c if _local(x.tag) == 'v')
            if text and text.strip():
                cells.append(text)
        out_sheets.append('\n'.join(cells))
    return '\n'.join(s for s in out_sheets if s.strip())


def _odf_walk(el, out):
    tag = _local(el.tag)
    if tag == 's':
        n = 1
        for k, v in el.attrib.items():
            if _local(k) == 'c' and str(v).isdigit():
                n = int(v)
        out.append(' ' * n)
    elif tag == 'tab':
        out.append('\t')
    elif tag == 'line-break':
        out.append('\n')
    if el.text:
        out.append(el.text)
    for ch in el:
        _odf_walk(ch, out)
        if ch.tail:
            out.append(ch.tail)
    if tag in ('p', 'h'):
        out.append('\n')


def _odf_text(z):
    root = _parse_xml(z.read('content.xml'))
    if root is None:
        return ''
    out = []
    _odf_walk(root, out)
    lines = [ln.rstrip() for ln in ''.join(out).split('\n')]
    return '\n'.join(ln for ln in lines if ln.strip())


class _HTMLText(HTMLParser):
    SKIP = {'script', 'style', 'head', 'title', 'nav'}
    BLOCK = {'p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'tr', 'section', 'blockquote',
             'pre', 'article', 'header', 'footer', 'figure', 'figcaption', 'dt', 'dd', 'table',
             'ul', 'ol', 'aside', 'main'}

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag == 'br':
            self.parts.append('\n')
        elif tag in self.BLOCK:
            self.parts.append('\n')

    def handle_endtag(self, tag):
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
        elif tag in self.BLOCK:
            self.parts.append('\n')

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def _html_to_text(raw):
    p = _HTMLText()
    try:
        p.feed(raw.decode('utf-8', 'replace'))
        p.close()
    except Exception:
        pass
    lines = []
    for ln in ''.join(p.parts).split('\n'):
        ln = re.sub(r'[ \t\r\f\v ]+', ' ', ln).strip()
        if ln:
            lines.append(ln)
    return '\n'.join(lines)


def _epub_text(z):
    names = z.namelist()
    chapters = []
    try:
        container = _parse_xml(z.read('META-INF/container.xml'))
        opf_path = None
        for el in container.iter():
            if _local(el.tag) == 'rootfile' and el.get('full-path'):
                opf_path = el.get('full-path')
                break
        opf = _parse_xml(z.read(opf_path))
        base = dirname(opf_path)
        manifest = {}
        spine = []
        for el in opf.iter():
            tag = _local(el.tag)
            if tag == 'item':
                props = el.get('properties', '') or ''
                if 'nav' in props.split():
                    continue
                manifest[el.get('id')] = (el.get('href'), el.get('media-type', ''))
            elif tag == 'itemref':
                if (el.get('linear') or 'yes').lower() != 'no':
                    spine.append(el.get('idref'))
        for idref in spine:
            if idref in manifest:
                href, mt = manifest[idref]
                if href is None:
                    continue
                path = normpath(pjoin(base, href)) if base else normpath(href)
                chapters.append(path)
    except Exception:
        chapters = []
    if not chapters:
        chapters = sorted(n for n in names if n.lower().endswith(('.xhtml', '.html', '.htm'))
                          and 'nav' not in os.path.basename(n).lower())
    texts = []
    for path in chapters:
        if path not in names:
            continue
        t = _html_to_text(z.read(path))
        if t.strip():
            texts.append(t)
    return '\n'.join(texts)


def _ipynb_text(data):
    try:
        nb = json.loads(data.decode('utf-8', 'replace'))
    except (ValueError, UnicodeDecodeError):
        return ''
    cells = nb.get('cells') if isinstance(nb, dict) else None
    if not isinstance(cells, list):
        return ''
    out = []
    for cell in cells:
        if not isinstance(cell, dict) or cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source', '')
        if isinstance(src, list):
            if not all(isinstance(x, str) for x in src):
                continue
            src = ''.join(src)
        elif not isinstance(src, str):
            continue
        out.append(src.rstrip('\n'))
    return '\n'.join(out)


def read_document(path):
    """Return extracted prose for a path, raising Fail on unreadable input."""
    if not os.path.exists(path):
        raise Fail(1, 'cannot read input: %s: no such file' % path)
    if os.path.isdir(path):
        raise Fail(1, 'cannot read input: %s: is a directory' % path)
    try:
        with open(path, 'rb') as fh:
            data = fh.read()
    except OSError as exc:
        raise Fail(1, 'cannot read input: %s: %s' % (path, exc.strerror or exc))
    ext = os.path.splitext(path)[1].lower()
    if ext in ZIP_EXT:
        import io
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
        except zipfile.BadZipFile:
            raise Fail(1, 'cannot read input: %s: not a readable zip archive' % path)
        try:
            names = set(z.namelist())
            if ext in ('.docx', '.docm'):
                text = _docx_text(z) if 'word/document.xml' in names else ''
            elif ext in ('.pptx', '.pptm'):
                text = _pptx_text(z)
            elif ext in ('.xlsx', '.xlsm'):
                text = _xlsx_text(z)
            elif ext in ('.odt', '.odp', '.ods'):
                text = _odf_text(z) if 'content.xml' in names else ''
            else:
                text = _epub_text(z)
        except (KeyError, ET.ParseError, zipfile.BadZipFile, ValueError):
            text = ''
        return text.strip()
    if ext in NB_EXT:
        return _ipynb_text(data).strip()
    if ext in BINARY_EXT:
        return ''
    return decode_bytes(data)


# ---------------------------------------------------------------- character layer

def _is_ideo(c):
    o = ord(c)
    return (0x4E00 <= o <= 0x9FFF or 0x3400 <= o <= 0x4DBF or 0xF900 <= o <= 0xFAFF
            or 0x20000 <= o <= 0x2FFFF or 0x3005 <= o <= 0x3007)


def _is_emojiish(c):
    return unicodedata.category(c) in ('So', 'Sk') or ord(c) >= 0x1F000


def _is_joining(c):
    o = ord(c)
    return (0x0590 <= o <= 0x08FF or 0x0900 <= o <= 0x0DFF or 0x1000 <= o <= 0x109F
            or 0x1780 <= o <= 0x17FF or 0xFB1D <= o <= 0xFDFF or 0xFE70 <= o <= 0xFEFF)


def _is_nospace_script(c):
    o = ord(c)
    return (0x0E00 <= o <= 0x0EFF or 0x1000 <= o <= 0x109F or 0x1780 <= o <= 0x17FF
            or 0x3040 <= o <= 0x30FF or _is_ideo(c))


def _is_rtl(c):
    o = ord(c)
    return 0x0590 <= o <= 0x08FF or 0xFB1D <= o <= 0xFDFF or 0xFE70 <= o <= 0xFEFF


def _is_khmer(c):
    return 0x1780 <= ord(c) <= 0x17FF


def _is_mongolian(c):
    return 0x1800 <= ord(c) <= 0x18AF


def _is_tag(c):
    return 0xE0000 <= ord(c) <= 0xE007F


def _is_vs(c):
    o = ord(c)
    return 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF or o in (0x180B, 0x180C, 0x180D, 0x180F)


def _tag_kept(text, i):
    j = i - 1
    while j >= 0 and _is_tag(text[j]):
        j -= 1
    if j < 0:
        return False
    return ord(text[j]) >= 0x1F000


def _invisible_removed(text, i, rtl):
    c = text[i]
    o = ord(c)
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if o == 0x00AD:
        return not (prev.isalpha() and nxt.isalpha())
    if o in (0x200C, 0x200D):
        return not any(x and (_is_joining(x) or _is_emojiish(x)) for x in (prev, nxt))
    if o == 0x200B:
        return not any(x and _is_nospace_script(x) for x in (prev, nxt))
    if o in (0x200E, 0x200F, 0x061C) or 0x202A <= o <= 0x202E or 0x2066 <= o <= 0x2069:
        return not rtl
    if _is_tag(c):
        return not _tag_kept(text, i)
    if _is_vs(c):
        if 0x180B <= o <= 0x180F:
            return not (prev and _is_mongolian(prev))
        if prev and (_is_emojiish(prev) or _is_ideo(prev)):
            return False
        if nxt == '\u20e3':
            return False
        return True
    if o in (0x17B4, 0x17B5):
        return not any(x and _is_khmer(x) for x in (prev, nxt))
    cat = unicodedata.category(c)
    if cat in ('Cc', 'Cf'):
        return True
    if o in (0x034F, 0x115F, 0x1160, 0x3164, 0xFFA0):
        return True
    return False


def _nbsp_kept(text, i):
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if (prev and prev.isdigit()) or (nxt and nxt.isdigit()):
        return True
    if nxt and nxt in ':;!?»›%€':
        return True
    if prev and prev in '«‹':
        return True
    return False


CONFUSABLE = {}
for _src, _dst in [
    ('а', 'a'), ('с', 'c'), ('ԁ', 'd'), ('е', 'e'), ('һ', 'h'),
    ('і', 'i'), ('ј', 'j'), ('о', 'o'), ('р', 'p'), ('ѕ', 's'),
    ('ѵ', 'v'), ('ԝ', 'w'), ('х', 'x'), ('у', 'y'), ('ο', 'o'),
    ('ρ', 'p'), ('ι', 'i'), ('ν', 'v'), ('ϲ', 'c'), ('օ', 'o'),
    ('ս', 'u'),
    ('А', 'A'), ('В', 'B'), ('С', 'C'), ('Е', 'E'), ('Н', 'H'),
    ('І', 'I'), ('Ј', 'J'), ('К', 'K'), ('М', 'M'), ('О', 'O'),
    ('Р', 'P'), ('Ѕ', 'S'), ('Т', 'T'), ('Х', 'X'), ('У', 'Y'),
    ('Α', 'A'), ('Β', 'B'), ('Ε', 'E'), ('Ζ', 'Z'), ('Η', 'H'),
    ('Ι', 'I'), ('Κ', 'K'), ('Μ', 'M'), ('Ν', 'N'), ('Ο', 'O'),
    ('Ρ', 'P'), ('Τ', 'T'), ('Χ', 'X'), ('Υ', 'Y')]:
    CONFUSABLE[_src] = _dst

_LETTER_RUN = re.compile(r'[^\W\d_]+')


def _fold_runs(text):
    """Fold qualifying mixed-script runs to ASCII. Returns (text, count, samples)."""
    count = [0]
    samples = []

    def repl(m):
        s = m.group(0)
        has_ascii = any(('a' <= ch <= 'z') or ('A' <= ch <= 'Z') for ch in s)
        has_conf = any(ch in CONFUSABLE for ch in s)
        if has_ascii and has_conf and all(ord(ch) < 128 or ch in CONFUSABLE for ch in s):
            count[0] += 1
            if len(samples) < 3:
                samples.append(s)
            return ''.join(CONFUSABLE.get(ch, ch) for ch in s)
        return s

    return _LETTER_RUN.sub(repl, text), count[0], samples


def scrub(text):
    """Apply the character layer. Returns (scrubbed_text, stats)."""
    rtl = any(_is_rtl(c) for c in text)
    out = []
    inv = 0
    inv_samples = []
    nons = 0
    for i, c in enumerate(text):
        o = ord(c)
        if 0x20 <= o < 0x7F:
            out.append(c)
            continue
        if c in '\t\n\r':
            out.append(c)
            continue
        if o in (0x2028, 0x2029):
            out.append('\n')
            continue
        cat = unicodedata.category(c)
        if cat == 'Zs':
            if c == ' ':
                out.append(c)
            elif o in (0xA0, 0x202F) and _nbsp_kept(text, i):
                out.append(c)
            else:
                out.append(' ')
                nons += 1
            continue
        if _invisible_removed(text, i, rtl):
            inv += 1
            if len(inv_samples) < 3:
                inv_samples.append('U+%04X' % o)
            continue
        out.append(c)
    s = ''.join(out)
    s, hg, hg_samples = _fold_runs(s)
    stats = {'invisible': inv, 'invisible_samples': inv_samples, 'nonstandard': nons,
             'homoglyph': hg, 'homoglyph_samples': hg_samples}
    return s, stats


def finish_clean(s, ended_lf):
    out = []
    for ln in s.split('\n'):
        if ln.endswith('\r'):
            out.append(ln[:-1].rstrip(' \t') + '\r')
        else:
            out.append(ln.rstrip(' \t'))
    while out and out[0].strip(' \t\r') == '':
        out.pop(0)
    res = '\n'.join(out).rstrip()
    if ended_lf and res:
        res += '\n'
    return res


# ---------------------------------------------------------------- body preparation

def _blank(s):
    return re.sub(r'[^\n]', ' ', s)


def make_body(win):
    """Same-length copy of the window with code, quotes, tables and badges blanked."""
    lines = win.split('\n')
    n = len(lines)
    skip = [False] * n
    # YAML front matter
    if n > 1 and lines[0].strip() == '---':
        for j in range(1, n):
            if lines[j].strip() == '---':
                for k in range(0, j + 1):
                    skip[k] = True
                break
    # fenced code blocks (CommonMark)
    i = 0
    open_re = re.compile(r'^ {0,3}(`{3,}|~{3,})(.*)$')
    while i < n:
        m = open_re.match(lines[i])
        if m and not skip[i]:
            fence = m.group(1)
            if fence[0] == '`' and '`' in m.group(2):
                i += 1
                continue
            j = i + 1
            closed = n
            close_re = re.compile(r'^ {0,3}(' + re.escape(fence[0]) + r'{' + str(len(fence)) + r',})\s*$')
            while j < n:
                if close_re.match(lines[j]):
                    closed = j
                    break
                j += 1
            end = min(closed, n - 1)
            for k in range(i, end + 1):
                skip[k] = True
            i = end + 1
            continue
        i += 1
    # blockquote runs (2+ consecutive lines)
    i = 0
    while i < n:
        if not skip[i] and re.match(r'^\s{0,3}>', lines[i]):
            j = i
            while j < n and not skip[j] and re.match(r'^\s{0,3}>', lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    skip[k] = True
            i = j
        else:
            i += 1
    badge = re.compile(r'^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$')
    for k in range(n):
        if skip[k]:
            continue
        ln = lines[k]
        if ln.count('|') >= 2 and (ln.strip().startswith('|') or ln.strip().endswith('|')):
            skip[k] = True
        elif badge.match(ln) and ln.strip():
            skip[k] = True
    body = '\n'.join(_blank(lines[k]) if skip[k] else lines[k] for k in range(n))
    body = re.sub(r'`[^`\n]*`', lambda m: ' ' * len(m.group(0)), body)
    return body


def _paragraphs(body):
    res = []
    cur = None
    pos = 0
    cur_end = 0
    for line in body.split('\n'):
        if line.strip():
            if cur is None:
                cur = pos
            cur_end = pos + len(line)
        else:
            if cur is not None:
                res.append((cur, cur_end))
                cur = None
        pos += len(line) + 1
    if cur is not None:
        res.append((cur, cur_end))
    return res


_WORD = re.compile(r"(?:[^\W_]|['’-])+")
_SENT = re.compile(r"(?:[^.!?]|[.!?](?!\s|$))+[.!?]*")


def _words(s):
    return [w for w in _WORD.findall(s) if re.search(r'[^\W_]', w)]


def _sentences(body, paras):
    spans = []
    for ps, pe in paras:
        ptxt = body[ps:pe]
        for m in _SENT.finditer(ptxt):
            seg = m.group(0)
            if re.match(r'\s*#', seg) or not _words(seg):
                continue
            spans.append((ps + m.start(), ps + m.end()))
    return spans


def _sample(win, s, e):
    a = max(0, s - 40)
    b = min(len(win), e + 40)
    return win[a:b].replace('\n', ' ').replace('\r', ' ').strip()


def _cv(vals):
    if len(vals) < 2:
        return None
    mean = sum(vals) / float(len(vals))
    if mean <= 0:
        return None
    var = sum((v - mean) ** 2 for v in vals) / float(len(vals))
    return math.sqrt(var) / mean


def _infl(w):
    e = re.escape(w)
    alts = [e + r'(?:s|es|d|ed)?']
    if w.endswith('e'):
        alts.append(re.escape(w[:-1]) + 'ing')
    elif w.endswith('y'):
        alts.append(re.escape(w[:-1]) + r'(?:ies|ied|ying)')
    else:
        alts.append(e + 'ing')
    return '(?:' + '|'.join(alts) + ')'


def _phrase(p):
    return r'\s+'.join(re.escape(x) for x in p.split(' '))


def _rx(pattern, s, flags=re.I):
    return [(m.start(), m.end()) for m in re.finditer(pattern, s, flags)]


# ---------------------------------------------------------------- family rules

WORDS_AI = ['additionally', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant', 'meticulous',
            'testament', 'underscore', 'intricate', 'intricacies', 'interplay', 'garner', 'bolster',
            'foster', 'showcase', 'emphasize', 'enduring', 'enhance', 'leverage', 'utilize',
            'facilitate', 'encompass', 'harness', 'holistic', 'paradigm', 'transformative',
            'unprecedented', 'myriad', 'plethora', 'robust', 'seamless', 'navigate', 'embark',
            'craft', 'landscape', 'journey', 'realm', 'multifaceted', 'elevate', 'empower', 'unlock']

PAT_AI = (r'\b(?:' + '|'.join(_infl(w) for w in WORDS_AI)
          + r'|align(?:s|ed|ing)? with|capture(?:s|d)? the (?:essence|spirit|imagination|heart|magic))\b')

PAT_DIALECT = (r'\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly'
               r'|quietly (?:powerful|profound|radical)|deeply (?:human|personal|felt|unsettling)'
               r'|resonates deeply|game[- ]chang\w*|supercharg\w*|skyrocket\w*|turbocharg\w*'
               r'|revolutioniz\w*|double down on|dive deep(?:er)? into'
               r'|unlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)'
               r'|take\b[^.!?\n]{0,60}?\bto the next level)\b')

PAT_PROMO = (r'\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic'
             r'|vibrant community|rich cultural heritage|in the heart of|world[- ]class|top[- ]tier'
             r'|unparalleled|premier|leading|esteemed organization|valuable asset|passion for excellence'
             r'|proven track record|results[- ]oriented|wealth of experience|dynamic team'
             r'|fast[- ]paced environment|deeply passionate|perfectly situated'
             r'|(?:close|tight)[- ]knit (?:team|community)|I am excited to (?:apply|bring)'
             r'|uniquely positioned to)\b')

PROMO_VERBS = {'install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape',
               'transform', 'reclaim', 'unlock', 'elevate', 'boost', 'say', 'imagine', 'explore',
               'meet', 'introducing', 'upgrade', 'claim', 'unleash', 'supercharge', 'level', 'stop',
               'start'}

PAT_HYPHEN = (r'\b(?:cutting[- ]edge|state[- ]of[- ]the[- ]art|best[- ]in[- ]class|next[- ]generation'
              r'|results[- ]driven|top[- ]notch|forward[- ]thinking|customer[- ]centric'
              r'|industry[- ]leading|world[- ]leading|battle[- ]tested|mission[- ]critical)\b')

PAT_SIMPLE_YET = r'\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b'

STOCK_ADJ = {'comprehensive', 'innovative', 'powerful', 'vibrant', 'seamless', 'robust', 'elegant',
             'intuitive', 'premier', 'dynamic', 'bold', 'stunning', 'modern', 'efficient', 'effective',
             'cohesive', 'scalable', 'reliable', 'secure', 'fast', 'smart', 'cutting-edge', 'world-class',
             'clean', 'simple', 'flexible', 'seamless', 'thoughtful', 'rich', 'bright'}
ADJ_END = re.compile(r'(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$', re.I)
PAT_CHAIN = re.compile(r"\b[A-Za-z][A-Za-z'’-]*(?:,\s*[A-Za-z][A-Za-z'’-]*){1,8}"
                       r"(?:,?\s+(?:and|or)\s+[A-Za-z][A-Za-z'’-]*)?(?=\s+[A-Za-z])")

CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]

PAT_SIG = [
    r'\b(?:stands?|serves?|stood|served) as (?:an? )?(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)s?\b',
    r'\b(?:underscor\w*|highlight\w*) (?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b',
    r'\breflects a broader (?:trend|shift|pattern)\b',
    r'\bmarks a (?:turning point|milestone|watershed|new chapter|new era)\b',
    r'\bsymbolizes\b',
    r'\bsets the stage for\b',
    r'\bleft an indelible mark\b',
    r'\bplays a (?:crucial|pivotal|vital|key|central|significant) role\b',
    r'\b(?:has|have) (?:shaped|sparked)\b',
    r'\b(?:has|have) come to (?:define|symbolize)\b',
]

PAT_NOTABILITY = [
    r'(?i:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?i:in|by)\s+[^.!?\n]{0,200}?\b[A-Z][\w&.]+[^.!?\n]{0,200}?(?:\band\b|,)\s+[A-Z][\w&.]+',
    r'\b\d[\d,.]*\s*[KkMm]?\s+(?:followers|subscribers)\b',
    r'\b(?:strong|active|significant|growing)\s+(?:online|digital|social[- ]media)\s+presence\b',
    r'\bwidely (?:covered|reported|cited)\b',
    r'\bindependent (?:media )?coverage\b',
]

PAT_VAGUE = (r'\bexperts? (?:argue|believe|say|claim|note|suggest)\b|\bindustry (?:reports|observers|analysts)\b'
             r'|\bobservers have (?:cited|noted)\b|\bsome critics argue\b|\bresearchers have found\b'
             r'|\bstudies suggest\b|\bit is widely believed\b')

PAT_CONSERVE = (r'\bplays an? (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b'
                r'|\bconservation efforts are (?:underway|ongoing|in place)\b'
                r'|\bserves as an indicator species\b|\bcontributes to biodiversity\b')

PAT_FALSE_RANGE = [
    r'\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]{0,200}?\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b',
    r'\bfrom (?:the )?humble\b[^.!?\n]{0,200}?\bto (?:the )?(?:mighty|towering|grand|sprawling)\b',
]

PAT_ING_TAIL = (r',\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering'
                r'|cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting'
                r'|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b')

PAT_TAIL_NEG = r'\w[^,.!?\n]{0,200},\s*no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b'
PAT_PARALLEL = [
    r"\bit[’']s not (?:just|merely) (?:about|an?)\b",
    r'\bnot only\b[^.!?\n]{0,40}?\bbut\b',
    r"\bdoesn[’']t just\b[^,.]{0,40}?\bit\b",
]

PAT_NOT_X = [
    r'\b(?:no|not) \w+, (?:just|only|simply) \w+',
    r"\b(?:not|isn[’']t|aren[’']t|wasn[’']t|weren[’']t) (?:just|merely) (?:a |an |the )?\w+(?:,|\s*[—–-])\s*(?:it[’']s|it is|it was|they[’']re|they are|they were|that[’']s|but)\b",
]

PAT_FILLER = (r'\bin order to\b|\bdue to the fact that\b|\bat this point in time\b|\bin the event that\b'
              r'|\bhas the ability to\b|\bit is important to note that\b|\bit should be mentioned that\b'
              r'|\bneedless to say\b')

PAT_PIVOT = (r"\bit[’']s worth (?:noting|mentioning) that\b|\bit bears (?:noting|mentioning) that\b"
             r"|\bone thing to (?:consider|keep in mind) is\b|\bit is interesting to note that\b"
             r"|\ba key consideration is\b|\ba point to highlight is\b")

PAT_OUTCOME = (r',\s+(?:raising questions about|prompting reflection on|sparking debate about'
               r'|with broader implications for|reshaping our understanding of|paving the way for'
               r'|signaling a shift toward)\b')

PAT_PERSUADE = (r"\bhere[’']s the thing\b|\bmake no mistake\b|\bthe truth is\b|\blet[’']s be honest\b"
                r"|\bthe simple fact is\b|\bat its core\b|\bwhat really matters\b|\bmore than anything\b"
                r"|\bat the end of the day\b|\bthe bottom line is\b|\bin reality\b|\bfundamentally,"
                r"|\bthe real question is\b|\bthe heart of the matter\b|\bthe deeper issue\b"
                r"|\bwhen you get down to it\b|\bwhen all is said and done\b")

PAT_EDITORIAL = (r"\bit(?:[’']s| is) important to (?:remember|note|understand|recognize)\b"
                 r"|\bone must note that\b|\bit is worth pointing out\b|\bit cannot be overstated that\b"
                 r"|\bit must be emphasized that\b")

PAT_SELF_THOROUGH = (r'\bthis comprehensive (?:guide|overview|analysis)\b|\bthis in-depth (?:analysis|look|examination)\b'
                     r'|\bthis complete (?:guide|overview)\b|\ba thorough examination of\b'
                     r'|\beverything you need to know about\b')

PAT_QA = (r'(?:^|[.!?\n]\s*)((?:Is|Are|Do|Does|Did|Can|Could|Will|Would|Should|Has|Have|Had|Was|Were'
          r'|May|Might|Must|Shall)\b[^?.!\n]{0,80}\?)\s+(?:yes|no|absolutely|never|maybe|probably|always)[.!]')

PAT_CONCRETE = (r'\bwithout concrete (?:evidence|proof)\b|\bdo you have concrete (?:evidence|proof)\b'
                r'|\bI (?:would )?need concrete (?:evidence|examples) to\b|\babsent concrete (?:proof|evidence)\b'
                r'|\bprovide concrete (?:evidence|proof)\b')

PAT_INTRO = [
    r"\bin today[’']s(?:\s+\S+){0,2}\s+(?:world|landscape|environment|market)\b",
    r'\bin a world where\b', r'\bin an era of\b', r'\bin recent years,',
    r'\bmore than ever before\b', r'\bwe live in a (?:time|world) when\b',
    r'\b(?:great|exciting|big) news\s*[!:]',
    r'\bever (?:wanted|wondered|dreamed|wished) to\b[^?\n]{0,200}\?',
    r'\bin an increasingly (?:interconnected|digital|competitive|complex) world\b',
]

PAT_DIFF = (r'\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)s?\b'
            r'|\b(?:the|this) (?:latest |new )?(?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b'
            r'|\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b'
            r'|\bpreviously\b[^.!?\n]{0,200}\bnow\b'
            r"|\bwasn[’']t there before\b|\bweren[’']t there before\b"
            r"|\bwe[’']ve (?:now )?(?:added|removed|replaced|refactored|migrated)\b"
            r'|\bwe have (?:now )?(?:added|removed|replaced|refactored|migrated)\b')

PAT_SIGNPOST = (r"\blet[’']s (?:dive|delve|explore)\b|\blet[’']s break (?:this|it) down\b"
                r"|\bhere[’']s what you need to know\b|\bwithout further ado\b|\bnow let[’']s look at\b"
                r"|\bbuckle up\b|\bstay with me\b|\b(?:are you )?ready to dive in\b")

PAT_CATALOG = [
    r'\b(?:used|uses|employs?|employed|relied on|utilizes)\s+(?:several|various|a number of|multiple|different|many|numerous)\s+\w+',
    r'\bThese\s+(?:\w+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help)\s+(?:information|insight|understanding|details|data)\b',
    r'\b(?:is|are|was|were|remains|becomes)\s+(?:a |the )?(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue)\s+of\b',
]

PAT_FORMULAIC = (r'\bdespite (?:these|its|the) (?:challenges|obstacles)\b'
                 r'|\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b|\bcontinues to thrive\b'
                 r'|\btypical of (?:emerging|urban|modern)\b|\bfaces (?:several|many|numerous) challenges\b')

PAT_CONCLUDE = (r'(?m)^[ \t>*#\-\d.)]*(?:in conclusion|overall|in summary|to summarize|to conclude'
                r'|all in all|in essence|ultimately)\b')

PAT_GENERIC_POS = (r'\bthe future looks bright\b|\bexciting times lie ahead\b|\bjourney toward excellence\b'
                   r'|\bstep in the right direction\b|\b(?:outlook|future)(?: for [^.!?\n]{1,40})? (?:is|looks|remains) bright\b'
                   r'|\bwell[- ]positioned for (?:whatever comes next|the future|the road ahead)\b')

PAT_CHATBOT = (r"\bI hope this helps\b|\bCertainly!|\bOf course!|\blet me know if you\b|\bwould you like me to\b"
               r"|\bfeel free to (?:ask|reach out)\b|\bhappy to help[.!]|\b(?:here|below) is (?:a |an |the )?(?:overview|summary|rundown|recap|brief)\b"
               r"|\bhere (?:are|[’']s a few|[’']s some|[’']s two|[’']s three) (?:options|drafts|versions|variations)\b"
               r"|\bhere (?:is|[’']s) (?:a |the )?draft\b|\bdepending on the (?:vibe|tone|style)\b"
               r"|\bI hope (?:this email )?finds you well\b"
               r"|\bas an? (?:AI|LLM|AI assistant|AI language model|large language model|language model)\b"
               r"|\bto (?:answer|address) your question\b|\bin (?:response|answer) to your question\b"
               r"|\byour question (?:about|regarding|concerning)\b|\bas (?:you )?(?:requested|asked),? here\b"
               r"|\bhere (?:is|[’']s) (?:the )?(?:draft|first pass|revised version)\b")

PAT_SYCO = (r"\byou(?:[’']re| are) absolutely right\b"
            r"|\b(?:great|excellent|thoughtful|wonderful|fantastic|brilliant) (?:question|point)\s*[!.,]"
            r"|\bwhat a (?:thoughtful|great|wonderful|fantastic) question\b"
            r"|\bthat[’']s a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b")

PAT_CUTOFF = (r'\bas of my (?:last )?(?:training|knowledge)\b|\bup to my (?:last )?(?:training|knowledge)\b'
              r'|\bwhile specific details (?:are|is) (?:limited|scarce|not (?:extensively |widely )?documented)\b'
              r'|\bbased on (?:the )?available information\b|\bas of my (?:knowledge )?cutoff\b'
              r'|\bmaintains a low profile\b|\bkeeps (?:his|her|their) personal life private\b')

PAT_COPULA = (r'\b(?:serves|stands|functions|acts) as\b|\b(?:represents|marks) (?:a|the)\b|\bboasts\b'
              r'|\bfeatures (?:a|an|the|\d[\d,.]*|several|many|numerous|multiple|various|some|two|three|four'
              r'|five|six|seven|eight|nine|ten)\b|\boffers a\b|\brefers to\b')

HEDGE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems? (?:to|like)"
                   r"|appears? to|somewhat|relatively|fairly|kind of|sort of)\b")

PAT_PLACEHOLDER = [
    r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])",
    r"\[(?:name|company|client|place|source|person|organization|customer|product|city|address|date)\](?![(\[])",
    r"\[(?=[A-Z0-9 _-]*[A-Z])[A-Z][A-Z0-9 _-]{2,}\](?![(\[])",
    r"\{\{[^{}\n]*\}\}",
    r"\b[xX]{3,}\b",
    r"\blorem ipsum\b",
]

PAT_CHATMARK = r"\bcite(?:turn|start|nav)\w*|\boai_citation\w*|contentReference|\bnavlist\b|【\d+†[^】\n]*】"

PAT_UTM = (r"utm_source=(?:chatgpt\.com|chat\.openai\.com|perplexity\.ai|claude\.ai|gemini\.google\.com"
           r"|copilot\.microsoft\.com|poe\.com)(?![A-Za-z0-9-]|\.[A-Za-z0-9])")

PAT_SLOP = [
    r'unlocking (?:its |their |your |the )?full potential', r'navigating the complexities',
    r'a testament to the (?:power|importance) of', r'staying ahead of the curve',
    r'turning challenges into opportunities', r'taking (?:\w+ ){0,2}to the next level',
    r'harnessing the power of', r'paving the way for', r'saying goodbye to',
    r'imagining a world where',
]

MINOR_WORDS = {'a', 'an', 'the', 'of', 'in', 'on', 'at', 'to', 'for', 'by', 'with', 'from', 'up',
               'as', 'into', 'over', 'via', 'per', 'and', 'but', 'or', 'nor', 'so', 'yet'}

def _is_emoji_char(c):
    o = ord(c)
    return (0x1F300 <= o <= 0x1FAFF or 0x1F000 <= o <= 0x1F2FF or 0x2600 <= o <= 0x27BF
            or 0x2B50 <= o <= 0x2B55 or 0x1F1E6 <= o <= 0x1F1FF)


def _families(win, body, paras):
    """Return list of finding dicts for the lexical and structural families."""
    fs = []

    def add(num, slug, spans, advice=False, decisive=False, min_count=1, samples=None, label=None):
        if len(spans) < min_count or not spans:
            return
        smp = samples if samples is not None else [_sample(win, s, e) for s, e in spans[:3]]
        fs.append({'num': num, 'slug': slug, 'label': label or TITLES[num], 'count': len(spans),
                   'samples': smp[:3], 'advice': advice, 'decisive': decisive})

    sents = _sentences(body, paras)
    sent_words = [len(_words(body[s:e])) for s, e in sents]
    sent_texts = [body[s:e] for s, e in sents]
    words_all = _words(body)
    nwords = len(words_all)

    add(1, 'ai_vocabulary', _rx(PAT_AI, body))
    add(2, 'model_dialect', _rx(PAT_DIALECT, body), min_count=2)
    promo = _rx(PAT_PROMO, body)
    imperative = 0
    for st in sent_texts:
        w = _words(st)
        if w and w[0].lower() in PROMO_VERBS:
            imperative += 1
    if imperative >= 3:
        promo.extend([(0, 0)] * imperative)
    add(3, 'promotional', promo)
    add(4, 'hyphen_cliche', _rx(PAT_HYPHEN, body), advice=True)
    add(5, 'simple_yet', _rx(PAT_SIMPLE_YET, body))

    chains = []
    for m in PAT_CHAIN.finditer(body):
        seg = m.group(0)
        ws = re.findall(r"[A-Za-z][A-Za-z'’-]*", seg)
        if len(ws) < 4:
            continue
        if any(w.lower() in STOCK_ADJ or ADJ_END.search(w) for w in ws):
            chains.append((m.start(), m.end()))
    add(6, 'stacked_adjectives', chains)

    cluster_spans = []
    for cl in CLUSTERS:
        found = []
        distinct = 0
        for member in cl:
            pat = r'\b' + _phrase(member) + r'(?:e?s)?\b'
            sp = _rx(pat, body)
            if sp:
                distinct += 1
                found.extend(sp)
        if distinct >= 3:
            cluster_spans.extend(found)
    add(8, 'synonym_cycling', cluster_spans)

    sig = []
    for p in PAT_SIG:
        sig.extend(_rx(p, body))
    add(10, 'significance_inflation', sig)

    notab = []
    for p in PAT_NOTABILITY:
        notab.extend(_rx(p, body, 0))
    add(11, 'notability', notab)

    add(12, 'vague_attribution', _rx(PAT_VAGUE, body))
    add(13, 'article_title_noun', _rx(r'\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of [^.!?\n]{2,80}? (?:is|are) (?:a|an|the)\b', body, 0), decisive=True)
    add(14, 'conservation_padding', _rx(PAT_CONSERVE, body))
    fr = []
    for p in PAT_FALSE_RANGE:
        fr.extend(_rx(p, body))
    add(15, 'false_range', fr)
    add(16, 'ing_tail', _rx(PAT_ING_TAIL, body))

    add(17, 'tailing_negation', _rx(PAT_TAIL_NEG, body), label='tailing negation (clause, no guessing)')
    par = []
    for p in PAT_PARALLEL:
        par.extend(_rx(p, body))
    add(17, 'negative_parallelism', par, advice=True, label='negative parallelism (it is not just X, it is Y)')
    notx = []
    for p in PAT_NOT_X:
        notx.extend(_rx(p, body))
    add(18, 'not_x_just_y', notx)

    add(19, 'filler_phrase', _rx(PAT_FILLER, body), advice=True)
    add(20, 'empty_pivot', _rx(PAT_PIVOT, body))
    add(21, 'outcome_tail', _rx(PAT_OUTCOME, body))
    add(22, 'persuasive_trope', _rx(PAT_PERSUADE, body), advice=True)
    add(23, 'editorial_interjection', _rx(PAT_EDITORIAL, body))
    add(24, 'self_thoroughness', _rx(PAT_SELF_THOROUGH, body))
    add(25, 'question_answer', _rx(PAT_QA, body))
    add(26, 'concrete_evidence', _rx(PAT_CONCRETE, body))
    intro = []
    for p in PAT_INTRO:
        intro.extend(_rx(p, body))
    add(27, 'intro_hook', intro)
    add(30, 'diff_anchored', _rx(PAT_DIFF, body))
    add(31, 'signposting', _rx(PAT_SIGNPOST, body))
    cat = []
    for p in PAT_CATALOG:
        cat.extend(_rx(p, body, 0 if p.startswith(r'\bThese') else re.I))
    add(32, 'cataloguing', cat)

    # 33: inline-header vertical lists
    inl = _rx(r"^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?\*\*[^*\n]{1,80}?:\*\*"
              r"|^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?\*\*[^*\n]{1,80}?\*\*:", body, re.M)
    add(33, 'inline_header_list', inl)

    # 34: mid-essay bullet injection (documents without any heading)
    if not re.search(r'(?m)^\s{0,3}#{1,6}\s', body):
        list_pars = 0
        prose_pars = 0
        for ps, pe in paras:
            lines = [ln for ln in body[ps:pe].split('\n') if ln.strip()]
            if lines and all(re.match(r'^\s*(?:[-*+]|\d+[.)])\s+', ln) for ln in lines):
                list_pars += 1
            else:
                prose_pars += 1
        if list_pars and prose_pars >= 2:
            add(34, 'bullet_injection', [(0, 0)] * list_pars,
                samples=['%d list block(s) in a document without headings' % list_pars])

    # 35: fragmented headers
    frag = 0
    lines = body.split('\n')
    stop = {'the', 'and', 'for', 'with', 'from', 'that', 'this', 'your', 'about', 'into'}
    for i, ln in enumerate(lines):
        m = re.match(r'^\s{0,3}#{1,6}\s+(.*\S)', ln)
        if not m:
            continue
        head_words = {w.lower() for w in re.findall(r'[A-Za-z]{3,}', m.group(1))} - stop
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if re.match(r'^(?:#|[-*+]\s|\d+[.)]\s|\|)', nxt) or not nxt:
            continue
        nw = re.findall(r"[A-Za-z']+", nxt)
        if 0 < len(nw) <= 4 and any(w.lower() in head_words for w in nw):
            frag += 1
    add(35, 'fragmented_header', [(0, 0)] * frag,
        samples=['short line repeating a heading word'] * min(frag, 3))

    add(36, 'formulaic_challenges', _rx(PAT_FORMULAIC, body))

    # 37: transition clusters (two or more sentence-opening transitions in one paragraph)
    trans = []
    for ps, pe in paras:
        ptxt = body[ps:pe]
        ops = [m for m in re.finditer(r'(?:^|(?<=[.!?])\s+)(Additionally|Furthermore|Moreover|However'
                                      r'|Nevertheless|Consequently|Subsequently|Notably)\b', ptxt, re.M)]
        if len(ops) >= 2:
            trans.extend((ps + m.start(1), ps + m.end(1)) for m in ops)
    add(37, 'transition_cluster', trans)

    add(38, 'compulsive_conclusion', _rx(PAT_CONCLUDE, body))
    add(39, 'generic_positive_conclusion', _rx(PAT_GENERIC_POS, body))

    # 40 / 41 / 44 / 46 / 55: rhythm kinds
    if len(sent_words) >= 3:
        cv = _cv(sent_words)
        if cv is not None and cv < 0.35:
            add(40, 'sentence_length_monotony', [(0, 0)],
                samples=['%d sentences, length coefficient of variation %.2f' % (len(sent_words), cv)])
    if len(sent_words) >= 6:
        runs = 0
        run = 1
        prev_dir = 0
        for k in range(1, len(sent_words)):
            diff = sent_words[k] - sent_words[k - 1]
            d = 1 if diff > 0 else (-1 if diff < 0 else 0)
            if d != 0 and abs(diff) >= 6 and (prev_dir == 0 or d == -prev_dir):
                run += 1
                prev_dir = d
            else:
                run = 2 if (d != 0 and abs(diff) >= 6) else 1
                prev_dir = d if (d != 0 and abs(diff) >= 6) else 0
            if run >= 6:
                runs += 1
                run = 1
                prev_dir = 0
        add(41, 'alternation', [(0, 0)] * runs, advice=True,
            samples=['alternating sentence lengths'] * min(runs, 3))

    # 42: opener repetition
    op_hits = 0
    for ps, pe in paras:
        pz = [s for s in sents if ps <= s[0] < pe]
        if len(pz) < 3:
            continue
        openers = Counter()
        for s, e in pz:
            w = [x.lower() for x in _words(body[s:e])[:2]]
            if len(w) == 2:
                openers[tuple(w)] += 1
        for k, v in openers.items():
            if v >= 3:
                op_hits += v
    add(42, 'opener_repetition', [(0, 0)] * op_hits, advice=True,
        samples=['repeated sentence openers'] * min(op_hits, 3))

    paragraph_words = [len(_words(body[ps:pe])) for ps, pe in paras]
    paragraph_words = [w for w in paragraph_words if w > 0]
    if len(paragraph_words) >= 4:
        cv = _cv(paragraph_words)
        if cv is not None and cv < 0.4:
            add(44, 'uniform_paragraphs', [(0, 0)],
                samples=['%d paragraphs, length coefficient of variation %.2f' % (len(paragraph_words), cv)])

    if nwords >= 300 and ';' not in body and body.count('(') <= 1:
        add(46, 'semicolon_parenthesis_underuse', [(0, 0)], advice=True,
            samples=['no semicolons and almost no parentheses in a long document'])

    add(47, 'chatbot_artifact', _rx(PAT_CHATBOT, body, 0), decisive=True)
    add(48, 'sycophancy', _rx(PAT_SYCO, body), decisive=True)
    add(50, 'knowledge_cutoff', _rx(PAT_CUTOFF, body), decisive=True)
    add(51, 'copula_avoidance', _rx(PAT_COPULA, body))

    hedged = 0
    for s, e in sents:
        if len(HEDGE.findall(body[s:e].lower())) >= 2:
            hedged += 1
    add(54, 'hedge_stacking', [(0, 0)] * hedged, advice=True,
        samples=['sentences with stacked hedges'] * min(hedged, 3))

    # 55: contraction absence (first-person writing only)
    fp = len(re.findall(r"\bI\b|\b(?i:me|my|we|our|us)\b", body))
    full = len(re.findall(r"\b(?i:I am|I have|I will|I would|do not|does not|did not|is not|are not|was not"
                          r"|were not|it is|that is|we are|we have|they are|you are|will not|cannot)\b", body))
    contr = len(re.findall(r"\b(?i:I'm|I've|I'll|I'd|don't|doesn't|didn't|isn't|aren't|wasn't|weren't"
                           r"|it's|that's|we're|we've|they're|you're|can't|won't)\b", body.replace('’', "'")))
    if nwords and fp / float(nwords) >= 0.02 and full >= 3 and full >= 0.8 * (full + contr):
        add(55, 'contraction_absence', [(0, 0)], advice=True,
            samples=['first-person prose with most contractable forms written in full'])

    add(56, 'boldface_overuse', _rx(r'\*\*[^*\n]+?\*\*', body))
    emo = [(i, i + 1) for i, c in enumerate(body) if _is_emoji_char(c)]
    add(57, 'emoji', emo)

    dash_spans = []
    for ps, pe in paras:
        ptxt = body[ps:pe]
        ds = [m.start() for m in re.finditer('—', ptxt)]
        if len(ds) >= 2:
            dash_spans.extend((ps + d, ps + d + 1) for d in ds)
    add(58, 'em_dash_overuse', dash_spans, advice=True)

    heads = 0
    for ln in lines:
        m = re.match(r'^\s{0,3}#{1,6}\s+(.*\S)', ln)
        if not m:
            continue
        text = m.group(1).strip()
        words = text.split()
        if len(words) < 3 or not words[0][:1].isalpha() or text.isupper():
            continue
        if not words[0][0].isalpha():
            continue
        majors = [w for w in words if w.lower().strip('.,:;!?') not in MINOR_WORDS]
        majors = [w for w in majors if re.search(r'[A-Za-z]', w)]
        if len(majors) >= 2 and all(w[0].isupper() for w in majors):
            heads += 1
    add(59, 'title_case_heading', [(0, 0)] * heads,
        samples=['title-cased heading'] * min(heads, 3))

    curly = [(m.start(), m.end()) for m in re.finditer('[‘’“”]', body)]
    add(60, 'curly_quotes', curly, advice=True)

    years = []
    for m in re.finditer(r'(?<![\d-])(1[5-9]\d\d|20\d\d)-(1[5-9]\d\d|20\d\d)(?![\d-])', body):
        if int(m.group(1)) < int(m.group(2)):
            years.append((m.start(), m.end()))
    add(61, 'year_range_hyphen', years, advice=True)

    add(63, 'placeholder', [sp for p in PAT_PLACEHOLDER for sp in _rx(p, body, 0)], decisive=True)
    add(64, 'chat_markup', _rx(PAT_CHATMARK, body, 0), decisive=True)
    add(65, 'ai_tracking_param', _rx(PAT_UTM, body), decisive=True)
    slop = []
    for p in PAT_SLOP:
        slop.extend(_rx(p, body))
    add(69, 'marketing_slop', slop)

    rules = [m for m in re.finditer(r'(?m)^\s*(?:-{3,}|\*{3,}|_{3,})\s*$', body)]
    nonempty = sum(1 for ln in win.split('\n') if ln.strip())
    if len(rules) >= 3 and nonempty >= 24:
        add(70, 'decorative_rules', [(m.start(), m.end()) for m in rules])

    # 71: degenerate repetition
    toks = [w.lower() for w in words_all]
    if len(toks) >= 20:
        grams = [tuple(toks[i:i + 6]) for i in range(len(toks) - 5)]
        cnt = Counter(grams)
        rep = sum(1 for g in grams if cnt[g] > 1)
        if rep / float(len(grams)) >= 0.2 and len(grams) >= 20:
            add(71, 'degenerate_repetition', [(0, 0)] * rep,
                samples=['%d of %d six-word runs repeat' % (rep, len(grams))])

    return fs, sents, sent_words, nwords


# ---------------------------------------------------------------- scoring

def _score_findings(findings, words, sent_count):
    moving = [f for f in findings if not f['advice']]
    fams = {}
    for f in moving:
        fams[f['num']] = fams.get(f['num'], 0) + f['count']
    raw = 0
    for num, total in fams.items():
        base = 16 if any(f['decisive'] for f in moving if f['num'] == num) else 8
        contrib = min(base + 2 * (min(total, 10) - 1), base + 8)
        raw += contrib
    raw = min(100, raw)
    nfam = len(fams)
    rhythm_only = nfam > 0 and all(n in RHYTHM_NUMS for n in fams)
    cap = 100
    if nfam == 1 or rhythm_only:
        cap = 40
    if set(fams) <= {40} and fams:
        cap = 20
    score = min(raw, cap)

    floors = []
    if words < SHORT_FLOOR_WORDS:
        n2 = len([n for n in fams if n in SHORT_FLOOR_SET])
        if n2 >= 3:
            floors.append(45)
        elif n2 >= 2:
            floors.append(25)
    if words >= LONG_FLOOR_WORDS:
        if nfam >= 6:
            floors.append(45)
        elif nfam >= 5:
            floors.append(25)

    decisive_nums = {f['num'] for f in moving if f['decisive']}
    confidence, reason = _confidence(words, nfam)
    if len(decisive_nums) >= 2:
        floors.append(65)
    elif len(decisive_nums) == 1 and confidence not in ('none', 'low'):
        floors.append(45)
    if floors:
        score = max(score, max(floors))
    score = max(0, min(100, int(score)))
    return score, nfam, confidence, reason


def _confidence(words, nfam):
    if words < 40:
        return 'none', 'fewer than 40 words were scanned'
    if words < 120:
        return 'low', 'fewer than 120 words were scanned'
    if words < 300 and nfam <= 1:
        return 'low', 'under 300 words with only one score-moving pattern family'
    if words < 300:
        return 'moderate', 'under 300 words; 300 or more are needed for high confidence'
    return 'high', ''


# ---------------------------------------------------------------- top-level analysis

def analyze(text, ci=False):
    total = len(text)
    truncated = total > WINDOW
    win = text[:WINDOW]
    scrubbed, st = scrub(win)
    body = make_body(win)
    paras = _paragraphs(body)

    findings, sents, sent_words, nwords = _families(win, body, paras)

    # character layer (window-wide, consistent with cleanup)
    if st['invisible']:
        findings.append({'num': 62, 'slug': 'invisible_characters', 'label': TITLES[62],
                         'count': st['invisible'], 'decisive': True, 'advice': False,
                         'samples': ['removable %s' % ', '.join(st['invisible_samples'])]})
    if st['homoglyph']:
        findings.append({'num': 66, 'slug': 'homoglyphs', 'label': TITLES[66],
                         'count': st['homoglyph'], 'decisive': True, 'advice': False,
                         'samples': ['mixed-script run: %s' % s for s in st['homoglyph_samples']]})
    if st['nonstandard']:
        findings.append({'num': 67, 'slug': 'nonstandard_spaces', 'label': TITLES[67],
                         'count': st['nonstandard'], 'decisive': False, 'advice': False,
                         'samples': ['non-standard space separator']})
    trailing = _trailing_ws_count(win)
    if trailing:
        findings.append({'num': 68, 'slug': 'trailing_whitespace', 'label': TITLES[68],
                         'count': trailing, 'decisive': False, 'advice': True,
                         'samples': ['trailing or stray whitespace']})

    findings.sort(key=lambda f: (f['num'], f['slug']))
    words = nwords
    score, nfam, confidence, reason = _score_findings(findings, words, len(sents))
    band, phrase = band_for(score)

    report = {}
    used = set()
    for f in findings:
        key = '%d_%s' % (f['num'], f['slug'])
        base = key
        k = 2
        while key in used:
            key = '%s_%d' % (base, k)
            k += 1
        used.add(key)
        report[key] = {'label': f['label'], 'count': int(f['count']), 'samples': list(f['samples'])[:3]}

    metrics = {
        'scanned_chars': len(win),
        'truncated': truncated,
        'ai_tell_score': score,
        'ai_tell_band': band,
        'confidence': confidence,
        'confidence_reason': reason,
        'patterns_flagged': len(findings),
        'invisible_chars': st['invisible'],
        'nonstandard_spaces': st['nonstandard'],
        'homoglyphs': st['homoglyph'],
        'words': words,
        'sentences': len(sents),
        'score_families': nfam,
    }
    if ci:
        n = len(sents)
        if n >= 4:
            half = min(15, max(2, int(round(30.0 / math.sqrt(n)))))
            metrics['score_ci'] = [max(0, score - half), min(100, score + half)]
            metrics['score_ci_note'] = ('heuristic interval (half-width %d) from %d sentences; '
                                        'the point score is unchanged' % (half, n))
        else:
            metrics['score_ci'] = None
            metrics['score_ci_note'] = ('too few sentences for an interval (%d found, at least 4 needed); '
                                        'the point score is unchanged' % n)
    report['_metrics'] = metrics
    return report


def _trailing_ws_count(win):
    hits = 0
    if win[:1].isspace():
        hits += 1
    lines = win.split('\n')
    for ln in lines:
        core = ln[:-1] if ln.endswith('\r') else ln
        if core.endswith(' ') or core.endswith('\t'):
            hits += 1
    if win.endswith('\n\n'):
        hits += 1
    return hits


# ---------------------------------------------------------------- CLI

def _err(msg):
    sys.stderr.write(json.dumps({'error': msg}, ensure_ascii=True) + '\n')
    sys.stderr.flush()


def _out(text):
    sys.stdout.buffer.write(text.encode('utf-8'))
    sys.stdout.flush()


def main(argv):
    clean = False
    ci = False
    operands = []
    opts_done = False
    for a in argv:
        if opts_done:
            operands.append(a)
            continue
        if a == '--':
            opts_done = True
            continue
        if a in ('--help', '-h'):
            _out(USAGE)
            return 0
        if a == '--clean':
            clean = True
            continue
        if a == '--ci':
            ci = True
            continue
        if a.startswith('-'):
            _err('unknown option %s; see --help' % a)
            return 2
        operands.append(a)

    try:
        if operands:
            if len(operands) > 1:
                sys.stderr.write('detect.py: scanning only the first file: %s (ignored %d more)\n'
                                 % (operands[0], len(operands) - 1))
            text = read_document(operands[0])
        else:
            text = decode_bytes(sys.stdin.buffer.read())
    except Fail as exc:
        _err(exc.message)
        return exc.code

    if not text.strip():
        _err('empty input')
        return 1

    if clean:
        ended_lf = text.endswith('\n')
        scrubbed, _ = scrub(text)
        _out(finish_clean(scrubbed, ended_lf))
        return 0

    report = analyze(text, ci=ci)
    _out(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv[1:]))
    except BrokenPipeError:
        sys.exit(0)
