#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract in the session.
const lib = require('./prosecheck-lib');

function main() {
  lib.parseInput(lib.readStdin());
  lib.cleanOldLedgers();
  const stored = lib.readStoredLevel();
  const first = !require('fs').existsSync(lib.flagFile());
  const level = stored || lib.envDefault() || 'full';
  if (level === 'off') return '';
  if (!stored) lib.writeLevel(level);
  let out = '';
  if (first) out += lib.welcomeText() + '\n';
  out += lib.contractText(level, { detector: lib.detectorPath() }) + '\n';
  return out;
}

try {
  const out = main();
  if (out) process.stdout.write(out);
} catch (e) { /* never fail the host */ }
process.exit(0);
