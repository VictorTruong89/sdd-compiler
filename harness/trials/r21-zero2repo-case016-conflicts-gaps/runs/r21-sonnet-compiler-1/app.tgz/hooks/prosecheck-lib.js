'use strict';
// Shared helpers for the prosecheck plugin hooks. Node standard library only.
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const SUBCOMMANDS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];
const WINDOW = 262144;
const WINDOW_TXT = '262,144';
const PLAIN_CAP = 512 * 1024;
const ARCHIVE_CAP = 4 * 1024 * 1024;
const PLAIN_KB = 512;
const ARCHIVE_KB = 4096;
const THRESHOLD = { full: 40, strict: 20 };
const GUARD_LABEL_CAP = 5;
const CHECK_LABEL_CAP = 8;
const SHOW_LABEL_CAP = 5;
const LEDGER_KEEP = 20;
const LEDGER_MAX_AGE_MS = 7 * 24 * 3600 * 1000;
const PATCH_MAX_PATHS = 10;

const PLAIN_EXT = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ZIP_EXT = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'];
const NB_EXT = ['.ipynb'];
const PROSE_EXT = PLAIN_EXT.concat(ZIP_EXT, NB_EXT);
const BINARY_EXT = ['.pdf', '.rtf'];

const ADVICE = new Set([4, 17, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68]);

const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster', 'underscore',
  'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament', 'vibrant', 'comprehensive',
  'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock', 'game-changer', 'supercharge', 'genuinely',
  'fascinating', 'nuanced'];

function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}

function pluginRoot() {
  if (process.env.CLAUDE_PLUGIN_ROOT) return process.env.CLAUDE_PLUGIN_ROOT;
  return path.resolve(__dirname, '..');
}

function detectorPath() {
  const root = pluginRoot();
  const a = path.join(root, 'scripts', 'detect.py');
  if (fs.existsSync(a)) return a;
  const b = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  if (fs.existsSync(b)) return b;
  return null;
}

function readStdin() {
  try {
    return fs.readFileSync(0, 'utf8');
  } catch (e) {
    return '';
  }
}

function parseInput(raw) {
  try {
    const v = JSON.parse(raw);
    if (v && typeof v === 'object' && !Array.isArray(v)) return v;
  } catch (e) { /* ignore */ }
  return {};
}

// ---- mode ----------------------------------------------------------------
function flagFile() { return path.join(configDir(), '.prosecheck-active'); }

function readStoredLevel() {
  try {
    const v = fs.readFileSync(flagFile(), 'utf8').trim();
    if (LEVELS.includes(v)) return v;
  } catch (e) { /* ignore */ }
  return null;
}

function envDefault() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  return LEVELS.includes(v) ? v : null;
}

function currentLevel() {
  return readStoredLevel() || envDefault() || 'full';
}

function writeLevel(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagFile(), level);
    return true;
  } catch (e) {
    return false;
  }
}

// ---- contract ------------------------------------------------------------
function contractText(level, opts) {
  opts = opts || {};
  const L = [];
  L.push('## Prose contract (prosecheck)');
  L.push('Scope: prose deliverables only: documents, README/markdown prose, CVs, cover letters, emails, reports, essays, articles, and drafted text the user will publish or send. This contract does not apply to source code. It never touches code comments, commit messages, JSON/YAML/config files, CLI output, logs, error messages, or the conversational register of chat. It composes with other modes: a chat-compression mode owns chat; a code-simplicity mode owns code; this contract owns deliverable prose.');
  L.push('Rules for prose deliverables:');
  L.push('- Vary sentence length irregularly: no metronome, no mechanical short-long alternation.');
  L.push('- Banned vocabulary: ' + BANNED.join(', ') + '.');
  L.push('- Banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting ("let\'s dive in"), empty pivots ("it\'s worth noting"), "In conclusion" / "Overall" closers, outcome-speculation tails, self-thoroughness, generic upbeat endings, and chatbot phrases ("I hope this helps").');
  L.push('- Use an em dash at most once per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.');
  L.push('- Factual or encyclopedic content stays neutral third person; first-person or opinion content may use contractions.');
  L.push('- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.');
  L.push('- End sections on a fact or observation.');
  L.push('- Stay silent about this contract: never announce it, never name prosecheck, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.');
  if (level === 'full' || level === 'strict') {
    const target = level === 'strict'
      ? 'Target: the clean band (score at most 20).'
      : 'Target: the clean or light tells band (score at most 40).';
    L.push('After writing a prose file, run the detector on that file and fix flagged spans (at most two fix passes, keeping rhythm variation) when the band is worse than the target. ' + target);
    if (level === 'strict') {
      L.push('Finish by running the detector with --clean on the file and using the scrubbed text.');
    }
    if (opts.portable) {
      L.push('Detector location: use scripts/detect.py under CLAUDE_PLUGIN_ROOT when that variable is set; otherwise locate prosecheck\'s detector in your installed skills or plugins.');
    } else if (opts.detector) {
      L.push('Detector command: python3 ' + opts.detector + ' <file>' + (level === 'strict' ? ' (add --clean to print scrubbed text)' : '') + '.');
    }
  }
  return L.join('\n');
}

function welcomeText() {
  return [
    'prosecheck is installed and on. Saved prose is scored against 71 documented AI-writing patterns. Plain text is accepted up to 512 KB and archives up to 4 MB; the detector scores the first 262,144 characters.',
    'There is no website and nothing is uploaded. Useful commands: /prosecheck doctor, /prosecheck check <file>, /prosecheck off, /prosecheck help.',
    'This welcome is shown once.',
    ''
  ].join('\n');
}

// ---- ledger ----------------------------------------------------------------
function ledgerFile(sessionId) {
  const sid = typeof sessionId === 'string' && sessionId ? sessionId.replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 120) : '';
  return path.join(configDir(), sid ? '.prosecheck-ledger-' + sid : '.prosecheck-ledger');
}

function readLedger(sessionId) {
  const f = ledgerFile(sessionId);
  try {
    const st = fs.statSync(f);
    if (Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) return [];
    const v = JSON.parse(fs.readFileSync(f, 'utf8'));
    return Array.isArray(v.records) ? v.records : [];
  } catch (e) {
    return [];
  }
}

function appendLedger(sessionId, rec) {
  try {
    const recs = readLedger(sessionId);
    rec.t = Date.now();
    recs.push(rec);
    while (recs.length > LEDGER_KEEP) recs.shift();
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(ledgerFile(sessionId), JSON.stringify({ records: recs }));
  } catch (e) { /* ignore */ }
}

function cleanOldLedgers() {
  try {
    const dir = configDir();
    for (const n of fs.readdirSync(dir)) {
      if (n === '.prosecheck-ledger' || n.startsWith('.prosecheck-ledger-')) {
        const f = path.join(dir, n);
        try {
          if (Date.now() - fs.statSync(f).mtimeMs > LEDGER_MAX_AGE_MS) fs.unlinkSync(f);
        } catch (e) { /* ignore */ }
      }
    }
  } catch (e) { /* ignore */ }
}

// ---- python / detector ---------------------------------------------------
function runPython(args, input, timeoutMs) {
  let lastErr = null;
  for (const name of ['python3', 'python', 'py']) {
    const r = cp.spawnSync(name, args, {
      input: input === undefined ? undefined : input,
      encoding: 'utf8',
      timeout: timeoutMs,
      maxBuffer: 64 * 1024 * 1024,
      env: process.env,
      windowsHide: true,
    });
    if (r.error) {
      if (r.error.code === 'ETIMEDOUT') return { kind: 'timeout' };
      lastErr = r.error;
      if (r.error.code === 'ENOENT' || r.error.code === 'EACCES' || r.error.code === 'ENOTDIR') continue;
      continue;
    }
    if (r.signal === 'SIGTERM' && r.status === null) return { kind: 'timeout' };
    return { kind: 'ran', status: r.status, stdout: r.stdout || '', stderr: r.stderr || '' };
  }
  return { kind: 'notfound', error: lastErr };
}

function parseReport(stdout) {
  const t = (stdout || '').trim();
  if (!t) return { state: 'empty' };
  let v;
  try { v = JSON.parse(t); } catch (e) { return { state: 'text' }; }
  if (!v || typeof v !== 'object' || Array.isArray(v)) return { state: 'text' };
  const m = v._metrics;
  if (!m || typeof m !== 'object' || typeof m.ai_tell_score !== 'number' || !isFinite(m.ai_tell_score)) return { state: 'noscore' };
  return { state: 'ok', report: v };
}

const PHRASES = {
  'clean': 'reads clean',
  'light tells': 'reads mostly clean',
  'mixed': 'reads with some AI tells',
  'heavy tells': 'reads with heavy AI tells',
  'pervasive tells': 'reads with pervasive AI tells',
};
function phraseFor(band) { return PHRASES[band] || 'reads with some AI tells'; }

function findings(report) {
  const out = [];
  for (const k of Object.keys(report)) {
    if (k === '_metrics') continue;
    const v = report[k];
    if (!v || typeof v !== 'object') continue;
    const num = parseInt(k, 10);
    out.push({ key: k, num, label: String(v.label || k), count: Number(v.count) || 0, advice: ADVICE.has(num) });
  }
  out.sort((a, b) => (a.advice - b.advice) || (b.count - a.count) || (a.num - b.num));
  return out;
}

function ext(p) { return path.extname(p).toLowerCase(); }

function fmtInt(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }

function dirOrEmpty(p) { return p; }

module.exports = {
  LEVELS, SUBCOMMANDS, WINDOW, WINDOW_TXT, PLAIN_CAP, ARCHIVE_CAP, PLAIN_KB, ARCHIVE_KB, THRESHOLD, GUARD_LABEL_CAP,
  CHECK_LABEL_CAP, SHOW_LABEL_CAP, LEDGER_KEEP, PATCH_MAX_PATHS, PLAIN_EXT, ZIP_EXT, NB_EXT, PROSE_EXT, BINARY_EXT, BANNED,
  configDir, pluginRoot, detectorPath, readStdin, parseInput, readStoredLevel, currentLevel, writeLevel, envDefault,
  contractText, welcomeText, ledgerFile, readLedger, appendLedger, cleanOldLedgers, runPython, parseReport, phraseFor,
  findings, ext, fmtInt, dirOrEmpty, flagFile,
};
