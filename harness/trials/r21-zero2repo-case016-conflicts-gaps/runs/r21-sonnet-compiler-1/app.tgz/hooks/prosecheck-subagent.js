#!/usr/bin/env node
'use strict';
// Subagent-start hook: places the same writing contract inside a subagent.
const lib = require('./prosecheck-lib');

try {
  lib.parseInput(lib.readStdin());
  const level = lib.currentLevel();
  if (level !== 'off') {
    const env = {
      hookSpecificOutput: {
        hookEventName: 'SubagentStart',
        additionalContext: lib.contractText(level, { detector: lib.detectorPath() }),
      },
    };
    process.stdout.write(JSON.stringify(env) + '\n');
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
