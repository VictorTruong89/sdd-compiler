#!/usr/bin/env node
'use strict';
// Prompt-submit hook and /prosecheck command router.
const fs = require('fs');
const os = require('os');
const path = require('path');
const lib = require('./prosecheck-lib');

function block(reason) {
  return JSON.stringify({ decision: 'block', reason }) + '\n';
}

function stripPath(arg) {
  let s = (arg || '').trim();
  if (s.startsWith('@')) s = s.slice(1);
  if (s.length >= 2 && ((s[0] === '"' && s[s.length - 1] === '"') || (s[0] === "'" && s[s.length - 1] === "'"))) {
    s = s.slice(1, -1);
  }
  if (s.startsWith('@')) s = s.slice(1);
  return s.trim();
}

// ---- subcommands -----------------------------------------------------------
function helpReply() {
  const level = lib.currentLevel();
  return [
    'prosecheck level: ' + level,
    'Code, commits, config, and chat are never touched; only prose deliverables follow the contract.',
    '/prosecheck lite - writing contract only, no scoring of saved files',
    '/prosecheck full - contract plus the saved-file guard, flags a file scoring above 40 (default)',
    '/prosecheck strict - contract plus a stricter guard at 20, and a --clean scrub finish',
    '/prosecheck off | on - disable prosecheck, or re-enable it',
    '/prosecheck status - show the current level',
    '/prosecheck show - list files scored in this session',
    '/prosecheck check <file> - score one file, report only, never a rewrite',
    '/prosecheck doctor - health check of the install',
    '/prosecheck stats - token figures for the session and the score of its own prose',
    '/prosecheck init - export the contract to ./AGENTS.md for agents other than Claude Code',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function setLevel(level, word) {
  const ok = lib.writeLevel(level);
  if (!ok) return 'prosecheck: could not store the level ' + level + ' (settings folder not writable).';
  switch (word) {
    case 'lite': return 'prosecheck level set to lite: the writing contract is on; saved files are not scored.';
    case 'full': return 'prosecheck level set to full: contract plus the saved-file guard (default).';
    case 'strict': return 'prosecheck level set to strict: contract plus the stricter guard and the scrub finish.';
    case 'off': return 'prosecheck is off: no contract, no scoring. Use /prosecheck on to switch it back.';
    case 'on': return 'prosecheck is on (level full).';
    default: return 'prosecheck level set to ' + level + '.';
  }
}

function checkReply(arg, data) {
  const p = stripPath(arg);
  if (!p) return 'prosecheck check: give a file path, for example /prosecheck check notes.md. This is a report only.';
  const cwd = typeof data.cwd === 'string' && data.cwd ? data.cwd : process.cwd();
  const abs = path.resolve(cwd, p);
  const base = path.basename(abs);
  let st;
  try { st = fs.statSync(abs); } catch (e) { return 'prosecheck check: cannot read ' + p; }
  if (st.isDirectory() || !st.isFile()) return 'prosecheck check: ' + p + ' is not a file';
  const e = lib.ext(abs);
  if (lib.BINARY_EXT.includes(e)) return 'prosecheck check: ' + base + ' has no readable text (binary format)';
  const isPlain = !lib.ZIP_EXT.includes(e) && !lib.NB_EXT.includes(e);
  if (isPlain && st.size > lib.PLAIN_CAP) return 'prosecheck check: ' + base + ' is over ' + lib.PLAIN_KB + ' KB and was not scored';
  if (!isPlain && st.size > lib.ARCHIVE_CAP) return 'prosecheck check: ' + base + ' is over ' + lib.ARCHIVE_KB + ' KB and was not scored';
  try { fs.accessSync(abs, fs.constants.R_OK); } catch (err) { return 'prosecheck check: cannot read ' + p; }
  const det = lib.detectorPath();
  if (!det) return 'prosecheck check: detector unavailable (the bundled detector was not found)';
  const r = lib.runPython([det, '--', abs], undefined, isPlain ? 8000 : 15000);
  if (r.kind === 'notfound') return 'prosecheck check: detector unavailable (Python was not found)';
  if (r.kind === 'timeout') return 'prosecheck check: ' + base + ' failed: the detector timed out';
  if (r.status !== 0) {
    const errText = (r.stderr || '').trim();
    return 'prosecheck check: ' + base + ' failed' + (errText ? ': ' + errText : ' (the detector reported a failure)');
  }
  if (!r.stdout.trim()) return 'prosecheck check: ' + base + ' produced no report';
  const pr = lib.parseReport(r.stdout);
  if (pr.state !== 'ok') return 'prosecheck check: the detector gave no report';
  const m = pr.report._metrics;
  const score = Math.round(m.ai_tell_score);
  const band = String(m.ai_tell_band);
  const lines = [];
  lines.push(base + ' - ' + lib.phraseFor(band) + ' (score ' + score + '/100, band: ' + band + ')');
  const conf = String(m.confidence || '');
  let cl = 'confidence: ' + conf;
  if (conf !== 'high' && m.confidence_reason) cl += ' - ' + m.confidence_reason;
  lines.push(cl);
  if (m.truncated === true) lines.push('coverage: first ' + lib.WINDOW_TXT + ' characters only');
  const fs_ = lib.findings(pr.report).slice(0, lib.CHECK_LABEL_CAP);
  if (fs_.length) lines.push('tells: ' + fs_.map((f) => f.label + ' (x' + f.count + ')').join('; '));
  else lines.push('tells: none');
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

function doctorReply(typed) {
  const level = lib.currentLevel();
  const lines = ['prosecheck doctor'];
  const modeOk = level !== 'off';
  lines.push(modeOk ? '[OK] mode: ' + level : '[--] mode: off - switched off; turn it back on with /prosecheck on');
  const det = lib.detectorPath();
  lines.push(det ? '[OK] detector: bundled detector found in the plugin tree' : '[!!] detector: bundled detector is missing from the plugin tree');
  let pyOk = false;
  if (!det) {
    lines.push('[!!] python: cannot run, the bundled detector is missing');
  } else {
    const r = lib.runPython([det], 'This is a plain sentence used to check that the detector runs. It has a few more words in it.', 15000);
    if (r.kind === 'notfound') {
      lines.push('[!!] python not found - prose is still shaped by the writing contract, but saved files are not re-scored until Python is available');
    } else {
      const pr = r.kind === 'ran' && r.status === 0 ? lib.parseReport(r.stdout) : { state: 'bad' };
      if (pr.state === 'ok') { pyOk = true; lines.push('[OK] python: ran the bundled detector and got a numeric score'); }
      else lines.push('[!!] python: the detector run did not return a numeric score');
    }
  }
  let setOk = false;
  try {
    const dir = lib.configDir();
    fs.mkdirSync(dir, { recursive: true });
    fs.accessSync(dir, fs.constants.W_OK);
    const probe = path.join(dir, '.prosecheck-probe-' + process.pid);
    fs.writeFileSync(probe, '');
    fs.unlinkSync(probe);
    setOk = true;
  } catch (e) { setOk = false; }
  lines.push(setOk ? '[OK] settings: the settings folder is writable' : '[!!] settings: the settings folder is not writable');
  const otherOk = !!det && pyOk && setOk;
  if (otherOk && modeOk) {
    lines.push('prosecheck is active. Plain text is scored up to ' + lib.PLAIN_KB + ' KB and archives up to 4 MB, reading the first ' +
      lib.WINDOW_TXT + ' characters. Run ' + typed + ' show to see files that were only partly scanned or skipped.');
  } else if (otherOk && !modeOk) {
    lines.push('The install is healthy, but the mode is off: saving files triggers no scoring, so nothing is scored. Run ' + typed + ' on to turn it back on.');
  } else {
    lines.push('Please fix the faulty checks above, then run /prosecheck doctor again.');
  }
  return lines.join('\n');
}

function showReply(data) {
  const recs = lib.readLedger(typeof data.session_id === 'string' ? data.session_id : '');
  if (!recs.length) {
    return 'prosecheck show: nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const lines = ['prosecheck show: files seen this session, newest first'];
  for (const r of recs.slice().reverse()) {
    const b = r.base || 'file';
    if (r.kind === 'scored') {
      let s = '  ' + b + ' - ' + lib.phraseFor(r.band) + ' (score ' + r.score + '/' + r.band;
      if (r.truncated) s += ', first ' + lib.WINDOW_TXT + ' characters only';
      s += ')';
      const labels = (r.labels || []).slice(0, lib.SHOW_LABEL_CAP);
      if (labels.length) s += ' - ' + (r.flagged ? 'flagged' : 'under the threshold') + ': ' + labels.join('; ');
      lines.push(s);
    } else if (r.kind === 'skipped') {
      lines.push('  ' + b + ' - not scored: larger than the ' + r.cap_kb + ' KB limit');
    } else if (r.kind === 'binary') {
      lines.push('  ' + b + ' - binary file, not re-scored');
    } else {
      lines.push('  ' + b + ' - not scored: ' + String(r.reason || 'the check failed').replace(/\b\d+\s*KB\b/gi, 'size'));
    }
  }
  return lines.join('\n');
}

function initReply(typed) {
  const level = lib.currentLevel();
  if (level === 'off') {
    return 'prosecheck is switched off, so init wrote no files. Run ' + typed + ' on to allow the export.';
  }
  const lines = [];
  const cwd = process.cwd();
  const agents = path.join(cwd, 'AGENTS.md');
  const MARK = '## Prose contract (prosecheck)';
  let existing = '';
  let readOk = true;
  let exists = false;
  try {
    existing = fs.readFileSync(agents, 'utf8');
    exists = true;
  } catch (e) {
    if (e.code !== 'ENOENT') readOk = false;
  }
  if (!readOk) {
    lines.push('prosecheck init: cannot read AGENTS.md, so it cannot write the contract there.');
  } else if (existing.includes(MARK)) {
    lines.push('AGENTS.md already contains the prosecheck contract; it was left unchanged.');
  } else {
    const section = '<!-- prosecheck:begin -->\n' + lib.contractText(level, { portable: true }) + '\n<!-- prosecheck:end -->\n';
    let prefix = '';
    if (exists && existing.length && !existing.endsWith('\n')) prefix = '\n';
    if (exists && existing.length) prefix += '\n';
    try {
      fs.appendFileSync(agents, prefix + section);
      lines.push('Wrote the prosecheck writing contract (' + level + ') to AGENTS.md.');
    } catch (e) {
      lines.push('prosecheck init: cannot write AGENTS.md.');
    }
  }
  const dest = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(dest)) {
    lines.push('.cursor/rules/prosecheck.mdc already exists (prosecheck.mdc was not overwritten).');
  } else {
    try {
      const src = path.join(lib.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
      const body = fs.readFileSync(src);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, body, { flag: 'wx' });
      lines.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      lines.push('prosecheck init: cannot write .cursor/rules/prosecheck.mdc.');
    }
  }
  return lines.join('\n');
}

function route(data) {
  const raw = typeof data.prompt === 'string' ? data.prompt : '';
  const prompt = raw.trim();
  const lower = prompt.toLowerCase();
  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    lib.writeLevel('off');
    return block('prosecheck is off: no contract, no scoring. Use /prosecheck on to switch it back.');
  }
  const m = /^\/prosecheck(:prosecheck)?(?=\s|$)/i.exec(prompt);
  if (!m) {
    const level = lib.currentLevel();
    if (level === 'off') return '';
    return JSON.stringify({
      hookSpecificOutput: {
        hookEventName: 'UserPromptSubmit',
        additionalContext: 'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.',
      },
    }) + '\n';
  }
  const typed = m[1] ? '/prosecheck:prosecheck' : '/prosecheck';
  const rest = prompt.slice(m[0].length).trim();
  const sm = /^(\S+)\s*([\s\S]*)$/.exec(rest);
  const word = sm ? sm[1].toLowerCase() : 'help';
  const arg = sm ? sm[2].trim() : '';
  if (!lib.SUBCOMMANDS.includes(word)) {
    return block('prosecheck: unknown subcommand "' + (sm ? sm[1] : word) + '". Valid subcommands: ' + lib.SUBCOMMANDS.join(', ') + '.');
  }
  switch (word) {
    case 'lite': case 'full': case 'strict': case 'off':
      return block(setLevel(word, word));
    case 'on':
      return block(setLevel('full', 'on'));
    case 'status':
      return block('prosecheck level: ' + lib.currentLevel());
    case 'help':
      return block(helpReply());
    case 'check':
      return block(checkReply(arg, data));
    case 'doctor':
      return block(doctorReply(typed));
    case 'show':
      return block(showReply(data));
    case 'init':
      return block(initReply(typed));
    case 'stats':
      return block(require('./prosecheck-stats').statsReply(data));
    default:
      return block(helpReply());
  }
}

try {
  const data = lib.parseInput(lib.readStdin());
  const out = route(data);
  if (out) process.stdout.write(out);
} catch (e) { /* never fail the host */ }
process.exit(0);
