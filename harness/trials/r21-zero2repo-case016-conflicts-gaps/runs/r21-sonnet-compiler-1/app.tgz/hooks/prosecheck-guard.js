#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when flagged.
const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib');

const TOOLS = ['Write', 'Edit', 'MultiEdit', 'NotebookEdit', 'apply_patch'];
const INSTRUCTION_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];

function pathsFromInput(data) {
  const ti = data.tool_input && typeof data.tool_input === 'object' ? data.tool_input : {};
  const tool = data.tool_name;
  const out = [];
  if (tool === 'apply_patch') {
    const body = typeof ti.command === 'string' ? ti.command : (typeof ti.input === 'string' ? ti.input : '');
    for (const line of body.split(/\r?\n/)) {
      const m = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/.exec(line);
      if (m && m[1].trim()) {
        const p = m[1].trim();
        if (!out.includes(p)) out.push(p);
      }
    }
    return out.slice(0, lib.PATCH_MAX_PATHS);
  }
  if (tool === 'NotebookEdit') {
    const p = typeof ti.notebook_path === 'string' && ti.notebook_path.trim() ? ti.notebook_path : ti.file_path;
    if (typeof p === 'string' && p.trim()) out.push(p.trim());
    return out;
  }
  if (typeof ti.file_path === 'string' && ti.file_path.trim()) out.push(ti.file_path.trim());
  return out;
}

function isSkipped(abs) {
  const parts = abs.split(/[\\/]+/);
  if (parts.includes('node_modules') || parts.includes('.git')) return true;
  const root = path.resolve(lib.pluginRoot());
  if (abs === root || abs.startsWith(root + path.sep)) return true;
  const base = path.basename(abs).toLowerCase();
  const e = path.extname(base);
  const stem = e ? base.slice(0, -e.length) : base;
  if (base === 'claude.md' || base === 'claude.local.md' || base === 'agents.md' || base === 'agents.local.md' ||
      base === 'skill.md' || base === 'memory.md') return true;
  // stems without a prose extension
  if (INSTRUCTION_STEMS.includes(base) ) return true;
  if (INSTRUCTION_STEMS.includes(stem) && !lib.PROSE_EXT.includes(e)) return true;
  return false;
}

function failReason(kind, r) {
  switch (kind) {
    case 'notfound': return 'python not found';
    case 'text': return 'detector printed text that is not a structured report';
    case 'noscore': return 'report had no numeric score';
    case 'timeout': return 'detector timed out';
    default: return 'detector produced no output or no usable result';
  }
}

function scoreFile(abs, level, sid) {
  const base = path.basename(abs);
  const e = lib.ext(abs);
  if (lib.BINARY_EXT.includes(e)) {
    lib.appendLedger(sid, { base, kind: 'binary' });
    return null;
  }
  if (!lib.PROSE_EXT.includes(e)) return null;
  let st;
  try {
    st = fs.statSync(abs);
  } catch (err) {
    lib.appendLedger(sid, { base, kind: 'failed', reason: 'file not readable' });
    return null;
  }
  if (!st.isFile()) return null;
  const isPlain = lib.PLAIN_EXT.includes(e);
  const cap = isPlain ? lib.PLAIN_CAP : lib.ARCHIVE_CAP;
  if (st.size > cap) {
    lib.appendLedger(sid, { base, kind: 'skipped', cap_kb: cap / 1024 });
    return null;
  }
  const det = lib.detectorPath();
  if (!det) {
    lib.appendLedger(sid, { base, kind: 'failed', reason: 'detector not found' });
    return null;
  }
  const r = lib.runPython([det, '--', abs], undefined, isPlain ? 8000 : 15000);
  if (r.kind !== 'ran') {
    lib.appendLedger(sid, { base, kind: 'failed', reason: failReason(r.kind) });
    return null;
  }
  const pr = lib.parseReport(r.stdout);
  if (pr.state !== 'ok' || r.status !== 0) {
    const k = pr.state === 'text' ? 'text' : pr.state === 'noscore' ? 'noscore' : 'empty';
    lib.appendLedger(sid, { base, kind: 'failed', reason: failReason(r.status !== 0 && pr.state !== 'ok' ? 'empty' : k) });
    return null;
  }
  const m = pr.report._metrics;
  const score = Math.round(m.ai_tell_score);
  const band = String(m.ai_tell_band || '');
  const labels = lib.findings(pr.report).map((f) => f.label).slice(0, lib.GUARD_LABEL_CAP);
  const threshold = level === 'strict' ? lib.THRESHOLD.strict : lib.THRESHOLD.full;
  const flagged = score > threshold;
  const truncated = m.truncated === true;
  lib.appendLedger(sid, { base, kind: 'scored', score, band, labels, flagged, truncated });
  if (!flagged) return null;
  const phrase = lib.phraseFor(band);
  const cov = truncated ? ', first ' + lib.WINDOW_TXT + ' characters only' : '';
  return 'prosecheck: ' + base + ' ' + phrase + ' (score ' + score + ', band ' + band + cov + '). Flagged: ' +
    (labels.length ? labels.join('; ') : 'see score') + '. Please fix the flagged spans and keep sentence rhythm varied.';
}

function main() {
  const data = lib.parseInput(lib.readStdin());
  if (!TOOLS.includes(data.tool_name)) return '';
  const level = lib.currentLevel();
  if (level !== 'full' && level !== 'strict') return '';
  const sid = typeof data.session_id === 'string' ? data.session_id : '';
  const cwd = typeof data.cwd === 'string' && data.cwd ? data.cwd : process.cwd();
  const lines = [];
  for (const p of pathsFromInput(data)) {
    const abs = path.resolve(cwd, p);
    if (isSkipped(abs)) continue;
    let st = null;
    try { st = fs.statSync(abs); } catch (e) { /* missing */ }
    if (st && !st.isFile()) continue;
    const line = scoreFile(abs, level, sid);
    if (line) lines.push(line);
  }
  if (!lines.length) return '';
  return JSON.stringify({
    hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
  }) + '\n';
}

try {
  const out = main();
  if (out) process.stdout.write(out);
} catch (e) { /* never fail the host */ }
process.exit(0);
