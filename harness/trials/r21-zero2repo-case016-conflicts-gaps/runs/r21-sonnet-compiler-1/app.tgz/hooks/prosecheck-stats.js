#!/usr/bin/env node
'use strict';
// Session statistics: token figures from the transcript and the score of the session's own prose.
const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib');

function newestTranscript(dir) {
  let best = null;
  let bestT = -1;
  const walk = (d, depth) => {
    let ents;
    try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    for (const e of ents) {
      const f = path.join(d, e.name);
      if (e.isDirectory()) { if (depth < 4) walk(f, depth + 1); }
      else if (e.isFile() && e.name.endsWith('.jsonl')) {
        try {
          const t = fs.statSync(f).mtimeMs;
          if (t > bestT) { bestT = t; best = f; }
        } catch (err) { /* ignore */ }
      }
    }
  };
  walk(dir, 0);
  return best;
}

function statsReply(data) {
  const level = lib.currentLevel();
  let file = null;
  if (typeof data.transcript_path === 'string' && data.transcript_path) file = data.transcript_path;
  else file = newestTranscript(path.join(lib.configDir(), 'projects'));
  const head = 'prosecheck stats\nlevel: ' + level;
  let raw = null;
  if (file) {
    try {
      if (fs.statSync(file).isFile()) raw = fs.readFileSync(file, 'utf8');
    } catch (e) { raw = null; }
  }
  if (raw === null) {
    return head + '\nNo readable transcript was found, so there are no session figures to report.';
  }
  const msgs = new Map();
  let anon = 0;
  const texts = [];
  for (const line of raw.split(/\r?\n/)) {
    if (!line.trim()) continue;
    let row;
    try { row = JSON.parse(line); } catch (e) { continue; }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const id = typeof msg.id === 'string' && msg.id ? msg.id : '#anon' + (anon++);
    let rec = msgs.get(id);
    if (!rec) { rec = { out: 0, cache: 0 }; msgs.set(id, rec); }
    const u = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    if (Number.isFinite(u.output_tokens)) rec.out = Math.max(rec.out, u.output_tokens);
    if (Number.isFinite(u.cache_read_input_tokens)) rec.cache = Math.max(rec.cache, u.cache_read_input_tokens);
    if (Array.isArray(msg.content)) {
      for (const c of msg.content) {
        if (c && c.type === 'text' && typeof c.text === 'string') texts.push(c.text);
      }
    } else if (typeof msg.content === 'string') {
      texts.push(msg.content);
    }
  }
  let out = 0;
  let cache = 0;
  for (const r of msgs.values()) { out += r.out; cache += r.cache; }
  const lines = [head,
    'assistant turns: ' + msgs.size,
    'output tokens: ' + out,
    'cache-read input tokens: ' + cache];
  let prose = texts.join('\n\n').replace(/```[\s\S]*?(```|$)/g, '');
  if (prose.length > 40000) prose = prose.slice(-40000);
  if (prose.trim().length > 500) {
    const det = lib.detectorPath();
    if (det) {
      const r = lib.runPython([det], prose, 15000);
      if (r.kind === 'ran') {
        const pr = lib.parseReport(r.stdout);
        if (pr.state === 'ok') lines.push('session prose ai_tell_score: ' + Math.round(pr.report._metrics.ai_tell_score));
      }
    }
  }
  return lines.join('\n');
}

module.exports = { statsReply };

if (require.main === module) {
  try {
    const data = lib.parseInput(lib.readStdin());
    process.stdout.write(statsReply(data) + '\n');
  } catch (e) { /* never fail */ }
  process.exit(0);
}
