---
name: prosecheck
description: Rewrite flagged prose to remove AI-writing patterns when the user asks to "prosecheck this" or "humanize this".
---
# prosecheck

When asked to "prosecheck this" or "humanize this", run `python3 scripts/detect.py <file>` from the plugin root,
read the flagged labels and samples, rewrite only the flagged spans, keep numbers, names, quotes and citations,
and re-run the detector (at most two passes). The score describes the prose, never its author.
