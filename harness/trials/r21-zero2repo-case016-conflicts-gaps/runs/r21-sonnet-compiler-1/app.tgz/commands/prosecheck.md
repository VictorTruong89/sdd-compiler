---
description: Control prosecheck (levels, status, show, check, doctor, stats, init, help)
argument-hint: [lite|full|strict|off|on|status|show|check|doctor|stats|init|help] [path]
---
/prosecheck $ARGUMENTS
