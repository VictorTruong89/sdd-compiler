#!/usr/bin/env python3
"""prosecheck detector: local, standard-library prose-pattern scanner.

usage: detect.py [--clean] [--ci] [--] [FILE]
"""
import io
import json
import math
import os
import random
import re
import statistics
import sys
import unicodedata
import zipfile

USAGE = "usage: detect.py [--clean] [--ci] [--] [FILE]"
USAGE_FULL = USAGE + """

Scores prose for AI-writing patterns (local, no network, no model).
  --clean   print scrubbed text (invisible characters removed, spaces
            normalized, lookalikes folded, whitespace trimmed) instead of a report
  --ci      add a resampled low/high interval on the score
  --        stop option parsing (a file name may begin with a dash)
  FILE      one file operand; with none, standard input is read
"""

WINDOW = 262144

PLAIN_EXT = {".md", ".mdx", ".markdown", ".txt", ".text", ".rst", ".tex", ".org", ".adoc"}
ZIP_EXT = {".docx", ".docm", ".pptx", ".pptm", ".xlsx", ".xlsm", ".odt", ".odp", ".ods", ".epub"}
NB_EXT = {".ipynb"}


class InputError(Exception):
    pass


# --------------------------------------------------------------------------
# decoding / extraction
# --------------------------------------------------------------------------

def decode_bytes(b):
    if b[:3] == b"\xef\xbb\xbf":
        return b[3:].decode("utf-8", "replace")
    if b[:2] in (b"\xff\xfe", b"\xfe\xff"):
        try:
            return b.decode("utf-16")
        except Exception:
            return b[2:].decode("utf-16", "replace") if False else b.decode("utf-16", "replace")
    if b[:4] in (b"\xff\xfe\x00\x00", b"\x00\x00\xfe\xff"):
        try:
            return b.decode("utf-32")
        except Exception:
            pass
    t = b.decode("utf-8", "replace")
    if t[:1] == "﻿":
        t = t[1:]
    return t


MEMBER_CAP = 64 * 1024 * 1024


def _read_member(z, name):
    info = z.getinfo(name)
    if info.file_size > MEMBER_CAP:
        return b""
    return z.read(name)


def _local(tag):
    if "}" in tag:
        tag = tag.rsplit("}", 1)[1]
    if ":" in tag:
        tag = tag.rsplit(":", 1)[1]
    return tag


def _parse_xml(data):
    import xml.etree.ElementTree as ET
    return ET.fromstring(data)


def _num_key(name):
    m = re.findall(r"\d+", name)
    return (int(m[-1]) if m else 0, name)


def _para_text(p, text_tags=("t",)):
    out = []

    def walk(e):
        n = _local(e.tag)
        if n in text_tags:
            out.append(e.text or "")
            return
        if n == "tab":
            out.append("\t")
        elif n in ("br", "cr"):
            out.append("\n")
        for c in e:
            walk(c)
    walk(p)
    return "".join(out)


def _paragraphs(root, ptag="p", text_tags=("t",)):
    res = []
    for e in root.iter():
        if _local(e.tag) == ptag:
            res.append(_para_text(e, text_tags))
    return res


def extract_docx(z):
    names = [n for n in z.namelist() if n == "word/document.xml"]
    if not names:
        names = sorted(n for n in z.namelist() if n.startswith("word/") and n.endswith(".xml") and "document" in n)
    parts = []
    for n in names[:1]:
        root = _parse_xml(_read_member(z, n))
        body = None
        for e in root.iter():
            if _local(e.tag) == "body":
                body = e
                break
        parts = [p for p in _paragraphs(body if body is not None else root)]
    return "\n".join(p for p in parts if p.strip() != "" or False)


def extract_pptx(z):
    slides = sorted((n for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)), key=_num_key)
    out = []
    for n in slides:
        root = _parse_xml(_read_member(z, n))
        for p in _paragraphs(root, "p", ("t",)):
            if p.strip():
                out.append(p)
    return "\n".join(out)


def extract_xlsx(z):
    shared = []
    if "xl/sharedStrings.xml" in z.namelist():
        root = _parse_xml(_read_member(z, "xl/sharedStrings.xml"))
        for si in root:
            if _local(si.tag) != "si":
                continue
            txt = []
            for c in si:
                n = _local(c.tag)
                if n == "t":
                    txt.append(c.text or "")
                elif n == "r":
                    for t in c:
                        if _local(t.tag) == "t":
                            txt.append(t.text or "")
            shared.append("".join(txt))
    sheets = sorted((n for n in z.namelist() if re.match(r"xl/worksheets/[^/]+\.xml$", n)), key=_num_key)
    out = []
    for n in sheets:
        root = _parse_xml(_read_member(z, n))
        for c in root.iter():
            if _local(c.tag) != "c":
                continue
            t = c.get("t")
            val = None
            if t == "s":
                v = None
                for ch in c:
                    if _local(ch.tag) == "v":
                        v = (ch.text or "").strip()
                if v is not None and re.fullmatch(r"\d+", v):
                    i = int(v)
                    if i < len(shared):
                        val = shared[i]
            elif t == "inlineStr":
                parts = []
                for ch in c.iter():
                    if _local(ch.tag) == "t":
                        parts.append(ch.text or "")
                val = "".join(parts)
            elif t == "str":
                for ch in c:
                    if _local(ch.tag) == "v":
                        val = ch.text or ""
            if val is not None and val.strip():
                out.append(val)
    return "\n".join(out)


def extract_odf(z):
    if "content.xml" not in z.namelist():
        return ""
    root = _parse_xml(_read_member(z, "content.xml"))
    out = []

    def inline(e, buf):
        n = _local(e.tag)
        if n == "s":
            try:
                buf.append(" " * int(e.get("{urn:oasis:names:tc:opendocument:xmlns:text:1.0}c") or e.get("c") or 1))
            except ValueError:
                buf.append(" ")
            return
        if n == "tab":
            buf.append("\t")
            return
        if n == "line-break":
            buf.append("\n")
            return
        if n in ("annotation", "note-citation"):
            return
        if e.text:
            buf.append(e.text)
        for c in e:
            inline(c, buf)
            if c.tail:
                buf.append(c.tail)

    def walk(e):
        n = _local(e.tag)
        if n in ("p", "h"):
            buf = []
            if e.text:
                buf.append(e.text)
            for c in e:
                inline(c, buf)
                if c.tail:
                    buf.append(c.tail)
            s = "".join(buf)
            if s.strip():
                out.append(s)
            return
        for c in e:
            walk(c)
    walk(root)
    return "\n".join(out)


BLOCK_TAGS = {"p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "br", "tr", "blockquote",
              "section", "article", "ul", "ol", "table", "pre", "hr", "dt", "dd", "figcaption", "td", "th", "title"}


def extract_html(raw):
    from html.parser import HTMLParser

    class P(HTMLParser):
        def __init__(self):
            super().__init__(convert_charrefs=True)
            self.buf = []
            self.skip = 0
            self.skiptags = []

        def handle_starttag(self, tag, attrs):
            tag = tag.lower().split(":")[-1]
            if tag in ("style", "script", "nav", "head"):
                self.skip += 1
                self.skiptags.append(tag)
                return
            if tag in ("title",):
                return
            if tag in BLOCK_TAGS:
                self.buf.append("\n")

        def handle_startendtag(self, tag, attrs):
            tag = tag.lower().split(":")[-1]
            if tag in BLOCK_TAGS:
                self.buf.append("\n")

        def handle_endtag(self, tag):
            tag = tag.lower().split(":")[-1]
            if self.skiptags and tag == self.skiptags[-1]:
                self.skiptags.pop()
                self.skip -= 1
                return
            if tag in BLOCK_TAGS and not self.skip:
                self.buf.append("\n")

        def handle_data(self, data):
            if not self.skip:
                self.buf.append(data)

    p = P()
    try:
        p.feed(raw)
        p.close()
    except Exception:
        pass
    text = "".join(p.buf)
    lines = [re.sub(r"[ \t\r\f\v\n]+", " ", ln).strip() for ln in text.split("\n")]
    return "\n".join(ln for ln in lines if ln)


def extract_epub(z):
    names = z.namelist()
    order = []
    try:
        container = _parse_xml(_read_member(z, "META-INF/container.xml"))
        opf = None
        for e in container.iter():
            if _local(e.tag) == "rootfile":
                opf = e.get("full-path")
        if opf and opf in names:
            root = _parse_xml(_read_member(z, opf))
            base = opf.rsplit("/", 1)[0] + "/" if "/" in opf else ""
            manifest = {}
            for e in root.iter():
                if _local(e.tag) == "item":
                    manifest[e.get("id")] = e.get("href")
            for e in root.iter():
                if _local(e.tag) == "itemref":
                    h = manifest.get(e.get("idref"))
                    if h:
                        from urllib.parse import unquote
                        order.append(base + unquote(h))
    except Exception:
        order = []
    html_names = [n for n in names if n.lower().endswith((".xhtml", ".html", ".htm"))]
    seq = [n for n in order if n in names and n in html_names]
    for n in sorted(html_names):
        if n not in seq:
            seq.append(n)
    out = []
    for n in seq:
        base = n.rsplit("/", 1)[-1].lower()
        if base.startswith("nav.") or base.startswith("toc."):
            continue
        raw = decode_bytes(_read_member(z, n))
        t = extract_html(raw)
        if t.strip():
            out.append(t)
    return "\n".join(out)


def extract_ipynb(data):
    try:
        nb = json.loads(decode_bytes(data))
    except Exception:
        return ""
    cells = nb.get("cells") if isinstance(nb, dict) else None
    if not isinstance(cells, list):
        return ""
    out = []
    for c in cells:
        if not isinstance(c, dict) or c.get("cell_type") != "markdown":
            continue
        s = c.get("source")
        if isinstance(s, str):
            pass
        elif isinstance(s, list) and all(isinstance(x, str) for x in s):
            s = "".join(s)
        else:
            continue
        if s.strip():
            out.append(s)
    return "\n".join(out)


def extract(path, data):
    ext = os.path.splitext(path)[1].lower() if path else ""
    if ext in (".pdf", ".rtf"):
        return ""
    if ext in ZIP_EXT:
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
        except Exception as e:
            raise InputError("%s is not a readable zip archive" % os.path.basename(path))
        try:
            if ext in (".docx", ".docm"):
                t = extract_docx(z)
            elif ext in (".pptx", ".pptm"):
                t = extract_pptx(z)
            elif ext in (".xlsx", ".xlsm"):
                t = extract_xlsx(z)
            elif ext == ".epub":
                t = extract_epub(z)
            else:
                t = extract_odf(z)
        except InputError:
            raise
        except Exception:
            t = ""
        return t.strip()
    if ext in NB_EXT:
        return extract_ipynb(data).strip()
    return decode_bytes(data)


# --------------------------------------------------------------------------
# character layer
# --------------------------------------------------------------------------

def _in(c, ranges):
    for a, b in ranges:
        if a <= c <= b:
            return True
    return False


INVIS_EXTRA = [(0x034F, 0x034F), (0x115F, 0x1160), (0x17B4, 0x17B5), (0x180B, 0x180F),
               (0x200B, 0x200F), (0x202A, 0x202E), (0x2060, 0x206F), (0x3164, 0x3164),
               (0xFE00, 0xFE0F), (0xFEFF, 0xFEFF), (0xFFA0, 0xFFA0), (0xFFF0, 0xFFF8),
               (0x1BCA0, 0x1BCA3), (0x1D173, 0x1D17A), (0xE0000, 0xE0FFF), (0x00AD, 0x00AD),
               (0x061C, 0x061C)]

NOSPACE_SCRIPTS = [(0x0E00, 0x0E7F), (0x0E80, 0x0EFF), (0x1780, 0x17FF), (0x1000, 0x109F),
                   (0x3040, 0x30FF), (0x31F0, 0x31FF), (0x3400, 0x4DBF), (0x4E00, 0x9FFF),
                   (0xF900, 0xFAFF), (0x20000, 0x2FA1F), (0xFF66, 0xFF9F)]
CJK = [(0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x2FA1F), (0x3005, 0x3007)]
JOINING = [(0x0590, 0x05FF), (0x0600, 0x06FF), (0x0750, 0x077F), (0x08A0, 0x08FF), (0xFB1D, 0xFDFF),
           (0xFE70, 0xFEFC), (0x0900, 0x0DFF), (0x1000, 0x109F), (0x1780, 0x17FF)]
RTL = [(0x0590, 0x08FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFC), (0x10800, 0x10FFF), (0x1E800, 0x1EFFF)]
MONGOLIAN = [(0x1820, 0x1878), (0x1880, 0x18AA)]
KHMER = [(0x1780, 0x17FF)]
BIDI = {0x200E, 0x200F, 0x061C, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E, 0x2066, 0x2067, 0x2068, 0x2069}
EMOJI_RANGES = [(0x1F000, 0x1FAFF), (0x2600, 0x27BF), (0x2300, 0x23FF), (0x2B00, 0x2BFF), (0x2190, 0x21FF)]


def is_invisible_char(ch):
    o = ord(ch)
    if o < 0x20:
        return o not in (9, 10, 13)
    if o < 0x7F:
        return False
    if 0x7F <= o <= 0x9F:
        return True
    if o < 0xAD:
        return False
    if _in(o, INVIS_EXTRA):
        return True
    return unicodedata.category(ch) == "Cf"


def _symbolish(ch):
    o = ord(ch)
    if _in(o, EMOJI_RANGES):
        return True
    return unicodedata.category(ch) in ("So", "Sk", "Sm", "Sc")


def has_rtl(text):
    for ch in text:
        o = ord(ch)
        if o >= 0x0590 and _in(o, RTL) and unicodedata.category(ch)[0] == "L":
            return True
    return False


def _keep_invisible(text, i, rtl, tag_keep):
    ch = text[i]
    o = ord(ch)
    prev = text[i - 1] if i > 0 else ""
    nxt = text[i + 1] if i + 1 < len(text) else ""
    po = ord(prev) if prev else -1
    no = ord(nxt) if nxt else -1
    if 0xE0000 <= o <= 0xE0FFF:
        if i in tag_keep:
            return True
        if 0xE0100 <= o <= 0xE01EF and prev and _in(po, CJK):
            return True
        if 0xE0100 <= o <= 0xE01EF and prev and _symbolish(prev):
            return True
        return False
    if 0xFE00 <= o <= 0xFE0F:
        if prev and (_symbolish(prev) or _in(po, CJK)):
            return True
        if nxt == "⃣":
            return True
        if prev and (prev.isdigit() or prev in "#*") and nxt == "⃣":
            return True
        return False
    if o == 0x200B:
        return (prev and _in(po, NOSPACE_SCRIPTS)) or (nxt and _in(no, NOSPACE_SCRIPTS)) or False
    if o == 0x00AD:
        return bool(prev and nxt and prev.isalpha() and nxt.isalpha())
    if o in BIDI:
        return rtl
    if 0x180B <= o <= 0x180D or o == 0x180F:
        return bool(prev and _in(po, MONGOLIAN))
    if o in (0x17B4, 0x17B5):
        return bool((prev and _in(po, KHMER)) or (nxt and _in(no, KHMER)))
    if o in (0x200C, 0x200D):
        for c, oc in ((prev, po), (nxt, no)):
            if c and ((_in(oc, JOINING) and c.isalpha()) or (_symbolish(c) and oc > 0x7F) or
                      (0x1F000 <= oc <= 0x1FAFF)):
                return True
        return False
    return False


def _tag_keep_set(text):
    keep = set()
    i = 0
    n = len(text)
    while True:
        i = text.find("\U0001F3F4", i)
        if i < 0:
            break
        j = i + 1
        while j < n and 0xE0020 <= ord(text[j]) <= 0xE007E:
            j += 1
        if j > i + 1 and j < n and ord(text[j]) == 0xE007F:
            for k in range(i + 1, j + 1):
                keep.add(k)
        i += 1
    return keep


def find_invisible(text, rtl=None):
    """Return list of indices of invisible chars that cleanup removes."""
    cand = [m.start() for m in re.finditer(r"[^\x20-\x7e\t\n\r]", text)]
    cand = [i for i in cand if is_invisible_char(text[i])]
    if not cand:
        return []
    if rtl is None:
        rtl = has_rtl(text)
    tag_keep = _tag_keep_set(text) if any(ord(text[i]) >= 0xE0000 for i in cand) else set()
    return [i for i in cand if not _keep_invisible(text, i, rtl, tag_keep)]


def find_nonstd_spaces(text):
    """Return list of (index, replacement) for non-standard spaces normalized."""
    res = []
    for m in re.finditer(r"[^\x00-\x7f]", text):
        i = m.start()
        ch = text[i]
        o = ord(ch)
        if o in (0x2028, 0x2029):
            res.append((i, "\n"))
            continue
        if unicodedata.category(ch) != "Zs":
            continue
        if o in (0xA0, 0x202F):
            prev = text[i - 1] if i > 0 else ""
            nxt = text[i + 1] if i + 1 < len(text) else ""
            if (prev and prev.isdigit()) or (nxt and nxt.isdigit()):
                continue
            if nxt and nxt in ":;!?\u00bb\u203a%\u20ac":
                continue
            if prev and prev in "\u00ab\u2039":
                continue
        res.append((i, " "))
    return res


LOOK = {}
for _a, _b in [
    ("а", "a"), ("с", "c"), ("е", "e"), ("о", "o"), ("р", "p"), ("х", "x"), ("у", "y"), ("і", "i"),
    ("ј", "j"), ("ѕ", "s"), ("ԁ", "d"), ("һ", "h"), ("ԝ", "w"), ("ԍ", "g"), ("ո", "n"), ("օ", "o"),
    ("ս", "u"), ("ց", "g"), ("հ", "h"), ("ɡ", "g"),
    ("А", "A"), ("В", "B"), ("С", "C"), ("Е", "E"), ("Н", "H"), ("І", "I"), ("Ј", "J"), ("К", "K"),
    ("М", "M"), ("О", "O"), ("Р", "P"), ("Ѕ", "S"), ("Т", "T"), ("Х", "X"), ("У", "Y"),
    ("ο", "o"), ("ν", "v"), ("υ", "u"), ("ι", "i"), ("ρ", "p"), ("α", "a"), ("γ", "y"), ("ɑ", "a"),
    ("Α", "A"), ("Β", "B"), ("Ε", "E"), ("Ζ", "Z"), ("Η", "H"), ("Ι", "I"), ("Κ", "K"), ("Μ", "M"),
    ("Ν", "N"), ("Ο", "O"), ("Ρ", "P"), ("Τ", "T"), ("Υ", "Y"), ("Χ", "X"),
    ("ﻩ", "o"), ("ﻫ", "o"), ("ﮬ", "o"), ("ﮪ", "o"), ("ھ", "o"),
]:
    LOOK[_a] = _b

_TOKEN = re.compile(r"\S+")


def find_homoglyphs(text):
    """Return list of (index, ascii) for lookalike chars inside qualifying runs."""
    res = []
    if not any(ord(c) > 0x7F for c in text[:0]) and text.isascii():
        return res
    for m in _TOKEN.finditer(text):
        tok = m.group(0)
        if tok.isascii():
            continue
        others = False
        for ch in tok:
            if ord(ch) > 0x7F and ch.isalpha() and ch not in LOOK:
                others = True
                break
        if others:
            continue
        base = m.start()
        for rm in re.finditer(r"[^\W\d_]+", tok):
            run = rm.group(0)
            has_ascii = any(c.isascii() for c in run)
            looks = [k for k, c in enumerate(run) if c in LOOK]
            if has_ascii and looks:
                for k in looks:
                    res.append((base + rm.start() + k, LOOK[run[k]]))
    return res


def _rs(ln):
    cr = ln.endswith("\r")
    core = ln[:-1] if cr else ln
    core = core.rstrip(" \t")
    return core + ("\r" if cr else "")


def clean_text(text):
    inv = set(find_invisible(text))
    sp = dict(find_nonstd_spaces(text))
    hg = dict(find_homoglyphs(text))
    if inv or sp or hg:
        out = []
        for i, ch in enumerate(text):
            if i in inv:
                continue
            if i in sp:
                out.append(sp[i])
            elif i in hg:
                out.append(hg[i])
            else:
                out.append(ch)
        text = "".join(out)
    ended_lf = text.endswith("\n")
    crlf = text.endswith("\r\n")
    text = "\n".join(_rs(ln) for ln in text.split("\n"))
    text = re.sub(r"\A(?:[ \t]*\r?\n)+", "", text)
    text = text.rstrip(" \t\r\n\f\v")
    if ended_lf and text:
        text += "\r\n" if crlf else "\n"
    return text


# --------------------------------------------------------------------------
# masking of non-prose regions
# --------------------------------------------------------------------------

def mask_text(t):
    """Blank out code, quotes, tables, badges and front matter; offsets preserved."""
    lines = t.split("\n")
    n = len(lines)
    mask = [False] * n
    i = 0
    # front matter
    if n and lines[0].strip() == "---":
        for j in range(1, n):
            if lines[j].strip() in ("---", "..."):
                for k in range(0, j + 1):
                    mask[k] = True
                i = j + 1
                break
    fence = None
    while i < n:
        ln = lines[i].rstrip("\r")
        if fence is None:
            m = re.match(r"^ {0,3}(`{3,}|~{3,})(.*)$", ln)
            if m and not (m.group(1)[0] == "`" and "`" in m.group(2)):
                fence = (m.group(1)[0], len(m.group(1)))
                mask[i] = True
        else:
            mask[i] = True
            m = re.match(r"^ {0,3}(`{3,}|~{3,})\s*$", ln)
            if m and m.group(1)[0] == fence[0] and len(m.group(1)) >= fence[1]:
                fence = None
        i += 1
    # blockquote runs
    i = 0
    while i < n:
        if not mask[i] and re.match(r"^ {0,3}>", lines[i]):
            j = i
            while j < n and not mask[j] and re.match(r"^ {0,3}>", lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    mask[k] = True
            i = j
        else:
            i += 1
    for i in range(n):
        if mask[i]:
            continue
        ln = lines[i]
        s = ln.strip()
        if re.match(r"^\|.*\|$", s) or re.match(r"^\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)+\|?$", s):
            mask[i] = True
        elif s and re.fullmatch(r"(?:\[?!\[[^\]]*\]\([^)]*\)\]?(?:\([^)]*\))?\s*)+", s):
            mask[i] = True
    out = []
    for i, ln in enumerate(lines):
        if mask[i]:
            out.append(re.sub(r"[^\r]", " ", ln))
        else:
            out.append(ln)
    res = "\n".join(out)
    # inline code spans
    def blank(m):
        return re.sub(r"[^\n]", " ", m.group(0))
    res = re.sub(r"(?<!`)(`+)(?!`)(.+?)(?<!`)\1(?!`)", blank, res, flags=re.S)
    return res


# --------------------------------------------------------------------------
# pattern definitions
# --------------------------------------------------------------------------

def forms(w):
    if w.endswith("e"):
        return [w, w + "s", w + "d", w[:-1] + "ing", w + "r"]
    if w.endswith("y"):
        if len(w) > 1 and w[-2] in "aeiou":
            return [w, w + "s", w + "ed", w + "ing"]
        return [w, w[:-1] + "ies", w[:-1] + "ied", w + "ing"]
    return [w, w + "s", w + "es", w + "ed", w + "ing", w + "ings"]


def alt(words, infl=True):
    parts = []
    for w in words:
        w = w.strip()
        if not w:
            continue
        if " " in w:
            first, rest = w.split(" ", 1)
            fs = forms(first) if infl else [first]
            parts.append("(?:%s) %s" % ("|".join(re.escape(f) for f in fs), re.escape(rest)))
        elif "-" in w and infl:
            parts.append(re.escape(w) + "s?")
        else:
            fs = forms(w) if infl else [w]
            parts.append("|".join(re.escape(f) for f in fs))
    return "|".join(parts)


AI_WORDS = ("additionally, align with, crucial, delve, tapestry, pivotal, vibrant, meticulous, testament, "
            "underscore, intricate, intricacies, interplay, garner, bolster, foster, showcase, emphasize, "
            "enduring, enhance, leverage, utilize, facilitate, encompass, harness, holistic, paradigm, "
            "transformative, unprecedented, myriad, plethora, robust, seamless, navigate, embark, craft, "
            "landscape, journey, realm, multifaceted, elevate, empower, unlock").split(", ")
RX_AI1 = re.compile(r"\b(?:%s|intricac(?:y|ies)|captur(?:e|es|ed|ing) the (?:essence|spirit|imagination|heart|magic))\b"
                    % alt(AI_WORDS), re.I)
DIALECT_WORDS = ["genuinely", "fascinating", "nuanced", "thoughtfully", "refreshingly", "strikingly", "compellingly",
                 "supercharge", "skyrocket", "turbocharge", "revolutionize"]
RX_DIALECT = re.compile(
    r"\b(?:%s|game[- ]chang(?:er|ers|ing)|quietly (?:powerful|profound|radical)|deeply (?:human|personal|felt|unsettling)|"
    r"resonates? deeply|resonat(?:ed|ing) deeply|doubl(?:e|es|ed|ing) down on|div(?:e|es|ed|ing) deep(?:er)? into|"
    r"unlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)|tak(?:e|es|ing|ken) [^.!?\n]{1,30}? to the next level)\b"
    % alt(DIALECT_WORDS), re.I)
PROMO = ("nestled, breathtaking, must-visit, stunning, picturesque, charming, idyllic, vibrant community, "
         "rich cultural heritage, in the heart of, world-class, top-tier, unparalleled, premier, esteemed organization, "
         "valuable asset, passion for excellence, proven track record, results-oriented, wealth of experience, "
         "dynamic team, fast-paced environment, deeply passionate, perfectly situated, close-knit team, tight-knit team, "
         "uniquely positioned to").split(", ")
RX_PROMO = re.compile(r"\b(?:%s|leading (?:provider|company|firm|brand|platform|source|expert|authority|player|manufacturer|supplier|solution|institution)s?|"
                      r"I am excited to (?:apply|bring)|I(?:'|’)m excited to (?:apply|bring))\b"
                      % "|".join(re.escape(p) for p in PROMO), re.I)
IMPERATIVES = ("install, join, grab, download, try, discover, experience, escape, transform, reclaim, unlock, elevate, "
               "boost, say, imagine, explore, meet, introducing, upgrade, claim, unleash, supercharge, level, stop, start").split(", ")
RX_IMPERATIVE = re.compile(r"(?:^|(?<=[.!?])\s+|\n)\s*(?:%s)\b" % "|".join(IMPERATIVES), re.I)

HYPH = ("data-driven, results-driven, cutting-edge, state-of-the-art, best-in-class, forward-thinking, game-changing, "
        "customer-centric, mission-critical, end-to-end, high-quality, well-rounded, detail-oriented, cross-functional, "
        "value-added, next-generation, user-friendly, thought-provoking, results-focused, client-focused, "
        "data-informed, future-proof, world-leading, high-performing, hard-working, self-motivated, "
        "team-oriented, goal-oriented, solution-oriented, innovative-minded, forward-looking, industry-leading, "
        "action-oriented, fast-growing, ever-evolving, ever-changing, high-impact, full-service, one-stop, "
        "cost-effective, time-saving, game-changer, hands-on, big-picture, outside-the-box, win-win").split(", ")
RX_HYPH = re.compile(r"\b(?:%s)\b" % "|".join(re.escape(h) for h in HYPH), re.I)

STOCK_ADJ = set("""sleek modern innovative powerful seamless robust scalable intuitive dynamic comprehensive flexible reliable
efficient elegant stunning vibrant rich bold beautiful fast secure simple clean smart rapid advanced critical
transformative engaging compelling impactful strategic holistic cutting-edge versatile lightweight lively thoughtful""".split())
ADJ_END = re.compile(r"(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$", re.I)

SYN_CLUSTERS = [
    ["protagonist", "main character", "central figure", "hero", "heroine"],
    ["company", "firm", "organization", "enterprise", "business"],
    ["author", "writer", "novelist", "scribe"],
    ["report", "study", "analysis", "investigation", "examination"],
    ["technology", "tool", "system", "platform", "solution"],
    ["technique", "method", "approach", "strategy", "tactic"],
    ["challenge", "obstacle", "difficulty", "hurdle", "barrier"],
    ["benefit", "advantage", "upside", "strength"],
]


def _plural(w):
    if w.endswith("y") and w[-2:-1] not in "aeiou":
        return w[:-1] + "ies"
    if w.endswith(("s", "x", "ch", "sh")):
        return w + "es"
    return w + "s"


SYN_RX = []
for _cl in SYN_CLUSTERS:
    SYN_RX.append([re.compile(r"\b(?:%s|%s)\b" % (re.escape(w), re.escape(_plural(w))), re.I) for w in _cl])

RX = {}


def _c(name, pat, flags=re.I):
    RX[name] = re.compile(pat, flags)


_c("sig", r"\b(?:(?:stand|stands|stood|standing|serve|serves|served|serving) as an? (?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)|"
         r"(?:underscor|highlight)(?:e|es|ed|ing|s)? (?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)|"
         r"reflects? a broader (?:trend|shift|pattern)|marks? a (?:turning point|milestone|watershed|new chapter|new era)|"
         r"symbolizes|symbolizing|sets? the stage for|left an indelible mark|"
         r"plays? an? (?:crucial|pivotal|vital|key|central|significant) role|"
         r"has (?:shaped|sparked)|has come to (?:define|symbolize))\b")
_c("vague", r"\b(?:experts (?:argue|believe|say|claim|note|suggest)|industry (?:reports|observers|analysts)|"
            r"observers have (?:cited|noted)|some critics argue|researchers have found|studies suggest|it is widely believed)\b")
_c("conserv", r"\b(?:plays? an? (?:vital|crucial|key|significant) role in (?:its|the) ecosystem|conservation efforts are (?:underway|ongoing|in place)|"
              r"serves as an indicator species|contributes? to biodiversity)\b")
_c("frange", r"\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]{0,120}?\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering|grand|sprawling)\b")
_c("ingtail", r",\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b")
_c("notxjusty", r"\b(?:(?:no|not) \w+, (?:just|only|simply) \w+|(?:not|isn(?:'|’)t|aren(?:'|’)t|wasn(?:'|’)t|weren(?:'|’)t) (?:just|merely)(?: (?:a|an|the))? [\w-]+(?:,|\s+[—–-]+)\s*(?:it(?:'|’)s|it is|it was|they(?:'|’)re|they are|they were|that(?:'|’)s|but))")
_c("pivot", r"\b(?:it(?:'|’)s worth (?:noting|mentioning) that|it bears (?:noting|mentioning) that|one thing to (?:consider|keep in mind) is|it is interesting to note that|a key consideration is|a point to highlight is)")
_c("outcome", r",\s+(?:raising questions about|prompting reflection on|sparking debate about|with broader implications for|reshaping our understanding of|paving the way for|signaling a shift toward)\b")
_c("hook", r"\b(?:in today(?:'|’)s (?:\w+ ){0,2}(?:world|landscape|environment|market)|in a world where|in an era of|in recent years,|more than ever before|"
           r"we live in a (?:time|world) when|(?:great|exciting|big) news\s*[!:]|ever (?:wanted|wondered|dreamed|wished) to\b[^.!?\n]*\?|"
           r"in an increasingly (?:interconnected|digital|competitive|complex) world)")
_c("challenges", r"\b(?:despite (?:these|its|the) (?:challenges|obstacles)|challenges and (?:future )?(?:prospects|outlook|legacy)|continues to thrive|typical of (?:emerging|urban|modern)|faces (?:several|many|numerous) challenges)\b")
_c("posconc", r"\b(?:the future looks bright|exciting times (?:lie|lay) ahead|journey toward excellence|step in the right direction|"
              r"(?:the )?(?:outlook|future)(?: for [^.!?\n]{1,40})? (?:is|looks|remains) bright|well[- ]positioned for (?:whatever comes next|the future|the road ahead))")
_c("filler", r"\b(?:in order to|due to the fact that|at this point in time|in the event that|has the ability to|it is important to note that|it should be mentioned that|needless to say)\b")
_c("authority", r"\b(?:here(?:'|’)s the thing|make no mistake|the truth is|let(?:'|’)s be honest|the simple fact is|at its core|what really matters|more than anything|at the end of the day|the bottom line is|in reality|the real question is|the heart of the matter|the deeper issue|when you get down to it|when all is said and done)\b|\bfundamentally,")
_c("editorial", r"\b(?:it(?:'|’)s|it is) important to (?:remember|note|understand|recognize)\b|\bone must note that\b|\bit is worth pointing out\b|\bit cannot be overstated that\b|\bit must be emphasized that\b")
_c("selfthor", r"\b(?:this (?:comprehensive|complete) (?:guide|overview|analysis)|this in-depth (?:analysis|look|examination)|this complete (?:guide|overview)|a thorough examination of|everything you need to know about)\b")
_c("concrete", r"\b(?:without concrete (?:evidence|proof)|do you have concrete (?:evidence|proof)|I (?:would )?need concrete (?:evidence|examples) to|absent concrete (?:evidence|proof)|provide concrete (?:evidence|proof))")
_c("diff", r"\b(?:unlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)|"
           r"(?:the|this) (?:(?:latest|new) )?(?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)|"
           r"(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to|previously\b[^.!?\n]{0,80}\bnow\b|(?:wasn(?:'|’)t|weren(?:'|’)t) there before|"
           r"we(?:'|’)ve (?:now )?(?:added|removed|replaced|refactored|migrated)|we have (?:now )?(?:added|removed|replaced|refactored|migrated))")
_c("signpost", r"\b(?:let(?:'|’)s (?:dive|delve|explore)|let(?:'|’)s break (?:this|it) down|here(?:'|’)s what you need to know|without further ado|now let(?:'|’)s look at|buckle up|stay with me|(?:are you )?ready to dive in)\b")
_c("catalog", r"\b(?:(?:used|uses|employs|employed|relied on|utilizes) (?:several|various|a number of|multiple|different|many|numerous) \w+|"
              r"(?:is|are|was|were|remains|becomes) (?:the|a) (?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue) of)\b")
_c("catalog2", r"(?:^|[.!?]\s+|\n)These(?: \w+)? (?:provide|offer|give|reveal|show|allow|enable|help) (?:information|insight|insights|understanding|details|data)\b")
_c("conclusion", r"^[ \t>*_-]*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|ultimately)\b", re.I | re.M)
_c("chatbot", r"(?:\bI hope this helps\b|\b(?:Certainly|Of course)!|\blet me know if you\b|\bwould you like me to\b|\bfeel free to (?:ask|reach out)\b|"
              r"\bhappy to help(?=\s*[.!?]|\s*$)|\b(?:here|below) is (?:an?|the) (?:overview|summary|rundown|recap|brief)\b|"
              r"\bhere (?:are|is)(?:\s+a)?\s+(?:few|some|two|three)?\s*(?:options|drafts|versions|variations)\b|\bhere(?:'|’)s (?:a )?(?:few|some|two|three) (?:options|drafts|versions|variations)\b|"
              r"\bhere(?:'|’)?s? (?:is )?a draft\b|\bdepending on the (?:vibe|tone|style)\b|\bI hope (?:this email )?finds you well\b|"
              r"\bas an? (?:AI|LLM|AI assistant|AI language model|large language model|language model)\b|"
              r"\bto (?:answer|address) your question\b|\bin (?:response|answer) to your question\b|\byour question (?:about|regarding|concerning)\b|"
              r"\bas (?:you )?(?:requested|asked), here\b|\bhere is (?:the )?(?:draft|first pass|revised version of|for your)\b)", re.I)
_c("sycophant", r"(?:\byou(?:'|’)re absolutely right\b|\byou are absolutely right\b|\b(?:great question|excellent point)\s*[!.,]|"
                r"\bwhat an? (?:thoughtful|great|wonderful|fantastic) question\b|\bthat(?:'|’)s an? (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b)")
_c("cutoff", r"\b(?:as of my (?:last )?(?:training|knowledge)|up to my (?:last )?(?:training|knowledge)|"
             r"while specific details are (?:limited|scarce|not (?:extensively|widely) documented)|based on (?:the )?available information|"
             r"as of my (?:knowledge )?cutoff|maintains a low profile|keeps (?:his|her|their) personal life private)\b")
_c("copula", r"\b(?:serves as|stands as|functions as|acts as|represents (?:a|the)|marks (?:a|the)|boasts|features (?:an?|the|\d+|several|many|numerous|multiple|a number of|a variety of)|offers an?|refers to)\b")
_c("cite", r"\b(?:cite(?:turn|start|nav)\w*|oai_citation\w*|contentReference\w*|navlist\w*)|【\s*\d+\s*†[^】]*】")
_c("lorem", r"\blorem ipsum\b")
_c("slop", r"\b(?:unlock(?:ing)? (?:its |their |your |the )?full potential|navigating the complexit(?:y|ies)|a testament to the (?:power|importance)|"
           r"stay(?:ing)? ahead of the curve|turning challenges into opportunities|tak(?:e|es|ing) (?:\w+ ){1,3}to the next level|"
           r"harness(?:ing|es)? the power of|paving the way for|saying goodbye to|imagin(?:e|ing) a world where|"
           r"in the ever-evolving (?:world|landscape) of|unleash(?:ing)? the (?:power|potential) of|elevat(?:e|ing) your \w+)\b")
_c("notab", r"\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by) [A-Z][\w&.'’-]*(?: [A-Z][\w&.'’-]*)*(?:,| and| or) [^.!?\n]{0,60}[A-Z][\w&.'’-]*|"
              r"\b\d[\d,.]*[kKmM]? (?:followers|subscribers)\b|\b(?:strong|active) (?:online|digital|social[- ]media) presence\b|\bwidely covered\b|\bindependent coverage\b", 0)

TRANSITIONS = re.compile(r"(?:^|(?<=[.!?])\s+|(?<=\n))\s*(?:Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably)\b", re.M)
HEDGES = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems?(?: to| like)|appears? to|somewhat|relatively|fairly|kind of|sort of)\b")
WORD = re.compile(r"(?:[^\W_]|['’-])+")

LABELS = {
    1: ("ai_vocabulary", "AI vocabulary"), 2: ("model_dialect", "Model-dialect vocabulary"),
    3: ("promotional", "Promotional language"), 4: ("hyphenated_pairs", "Hyphenated word-pair overuse"),
    5: ("simple_yet", "\"Simple yet X\" cliche"), 6: ("adjective_chains", "Stacked adjective chains"),
    8: ("synonym_cycling", "Synonym cycling"), 10: ("significance_inflation", "Significance inflation"),
    11: ("notability", "Notability name-dropping"), 12: ("vague_attributions", "Vague attributions"),
    13: ("title_proper_noun", "Article titles as proper nouns"), 14: ("conservation_padding", "Conservation / ecosystem padding"),
    15: ("false_ranges", "False ranges"), 17: ("negative_parallelism", "Negative parallelism"), 16: ("ing_tails", "Superficial -ing tail clauses"),
    18: ("not_x_just_y", "\"Not X, just Y\" construction"), 19: ("filler_phrases", "Filler phrases"),
    20: ("empty_pivots", "Empty pivot phrases"), 21: ("outcome_tails", "Outcome speculation tails"),
    22: ("authority_tropes", "Persuasive authority tropes"), 23: ("editorial_interjections", "Editorial interjections"),
    24: ("self_thoroughness", "Self-thoroughness phrases"), 25: ("question_answer", "Question-answer rhetorical pattern"),
    26: ("concrete_evidence", "\"Concrete evidence\" defense phrase"), 27: ("intro_hooks", "Compulsive intro hooks"),
    30: ("diff_anchored", "Diff-anchored writing"), 31: ("signposting", "Signposting and announcements"),
    32: ("cataloguing", "Cataloguing lead-ins"), 33: ("inline_header_lists", "Inline-header vertical lists"),
    34: ("bullet_injection", "Mid-essay bullet injection"), 35: ("fragmented_headers", "Fragmented headers"),
    36: ("formulaic_challenges", "Formulaic challenges sections"), 37: ("transition_clusters", "Transition cluster overuse"),
    38: ("compulsive_conclusions", "Compulsive conclusion phrases"), 39: ("positive_conclusions", "Generic positive conclusions"),
    40: ("sentence_monotony", "Sentence-length monotony"), 41: ("mechanical_alternation", "Mechanical sentence-length alternation"),
    42: ("opener_repetition", "Opener repetition"), 44: ("uniform_paragraphs", "Uniform paragraph length"),
    46: ("semicolon_underuse", "Semicolon and parenthesis underuse"), 47: ("chatbot_artifacts", "Chatbot artifacts"),
    48: ("sycophantic_tone", "Sycophantic / servile tone"), 50: ("knowledge_cutoff", "Knowledge-cutoff disclaimers"),
    51: ("copula_avoidance", "Copula avoidance"), 54: ("hedge_stacking", "Excessive hedging"),
    55: ("contraction_absence", "Contraction absence"), 56: ("boldface", "Boldface overuse"),
    57: ("emojis", "Emojis"), 58: ("em_dash", "Em-dash overuse"), 59: ("title_case_headings", "Title case in headings"),
    60: ("curly_quotes", "Curly quotation marks"), 61: ("hyphen_ranges", "Hyphen-for-en-dash in ranges"),
    62: ("invisible_chars", "Invisible / zero-width characters"), 63: ("placeholders", "Placeholder / Mad-Libs text"),
    64: ("chat_markup", "Chatbot reference-markup leak"), 65: ("tracking_params", "AI tracking params"),
    66: ("homoglyphs", "Homoglyph / mixed-script confusables"), 67: ("nonstandard_spaces", "Non-standard spaces"),
    68: ("trailing_whitespace", "Trailing / stray whitespace"), 69: ("marketing_slop", "Canonical marketing-slop phrases"),
    70: ("horizontal_rules", "Decorative horizontal rules"), 71: ("degenerate_repetition", "Degenerate repetition"),
}

ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
RHYTHM = {40, 41, 44, 55}
SHORT_SET = set(range(1, 40)) | {47, 48, 49, 50, 51, 69}
AI_TRACK = {"chatgpt.com", "chat.openai.com", "perplexity.ai", "claude.ai", "gemini.google.com",
            "copilot.microsoft.com", "poe.com"}


def _clip(s, n=90):
    s = re.sub(r"\s+", " ", s).strip()
    return s if len(s) <= n else s[: n - 1] + "…"


class Hits:
    def __init__(self):
        self.count = 0
        self.samples = []

    def add(self, sample, n=1):
        self.count += n
        if len(self.samples) < 3 and sample:
            s = _clip(sample)
            if s not in self.samples:
                self.samples.append(s)


def rx_hits(rx, text):
    h = Hits()
    for m in rx.finditer(text):
        h.add(m.group(0))
    return h


def excerpt(text, m, pad=30):
    a = max(0, m.start() - pad)
    b = min(len(text), m.end() + pad)
    s = text[a:b].replace("\n", " ").replace("\r", " ")
    s = re.sub(r" {2,}", " ", s) if False else s
    if a > 0:
        s = "..." + s
    if b < len(text):
        s = s + "..."
    return s


def split_paragraphs(m):
    return [p for p in re.split(r"\n[ \t\r]*\n", m) if p.strip()]


def is_structural(line):
    s = line.strip()
    return bool(re.match(r"^(#{1,6}\s|[-*+]\s|\d+[.)]\s|\|)", s))


def sentences_of(m):
    sents = []
    for para in split_paragraphs(m):
        for ln_block in [para]:
            lines = [ln for ln in ln_block.split("\n") if ln.strip() and not re.match(r"^\s*#{1,6}\s", ln)]
            blk = " ".join(lines)
            for s in re.split(r"(?<=[.!?])[\"”’')\]]*\s+", blk):
                if len(WORD.findall(s)) > 0:
                    sents.append(s)
    return sents


def cv(vals):
    mean = sum(vals) / len(vals)
    if mean == 0:
        return 1.0
    return statistics.pstdev(vals) / mean


def analyze_prose(window, raw_for_chars=None):
    """Return (findings, metrics-lite) for the window text."""
    m = mask_text(window)
    F = {}

    def put(num, h, key=None):
        if h.count > 0:
            F[key or num] = (num, h)

    words = WORD.findall(m)
    nwords = len(words)

    # 1
    h = Hits()
    for mm in RX_AI1.finditer(m):
        h.add(excerpt(window, mm))
    put(1, h)
    # 2
    h = rx_hits(RX_DIALECT, m)
    if h.count >= 2:
        put(2, h)
    # 3
    h = rx_hits(RX_PROMO, m)
    imp_lines = RX_IMPERATIVE.findall(m)
    if len(imp_lines) >= 3:
        h.add("; ".join(x.strip() for x in imp_lines[:3]), len(imp_lines))
    put(3, h)
    put(4, rx_hits(RX_HYPH, m))
    put(5, rx_hits(re.compile(r"\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b", re.I), m))
    # 6
    h = Hits()
    for mm in re.finditer(r"\b[A-Za-z][A-Za-z-]*(?:,\s+(?:and\s+)?[A-Za-z][A-Za-z-]*){3,}\b|\b[A-Za-z][A-Za-z-]*(?:,\s+[A-Za-z][A-Za-z-]*){2,},?\s+and\s+[A-Za-z][A-Za-z-]*\b", m):
        items = re.split(r",\s+(?:and\s+)?|\s+and\s+", mm.group(0))
        if len(items) >= 4 and any((w.lower() in STOCK_ADJ or ADJ_END.search(w)) for w in items):
            h.add(mm.group(0))
    put(6, h)
    # 8
    h = Hits()
    for cl in SYN_RX:
        present = [rxx for rxx in cl if rxx.search(m)]
        if len(present) >= 3:
            h.add(", ".join(rxx.search(m).group(0).lower() for rxx in present))
    put(8, h)
    put(10, rx_hits(RX["sig"], m))
    put(11, rx_hits(RX["notab"], m))
    put(12, rx_hits(RX["vague"], m))
    h = Hits()
    for mm in re.finditer(r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Catalog|Guide|Overview) of [A-Z][\w'’:,&.-]*(?: [\w'’:,&.-]+){0,8}? (?:is|was|are) (?:a|an|the)\b", m):
        h.add(mm.group(0))
    put(13, h)
    put(14, rx_hits(RX["conserv"], m))
    put(15, rx_hits(RX["frange"], m))
    put(16, rx_hits(RX["ingtail"], m))
    # 17
    h = Hits()
    for mm in re.finditer(r"\bit(?:'|’)s not (?:just|merely) (?:about|an?)\b", m, re.I):
        h.add(mm.group(0))
    for mm in re.finditer(r"\bnot only\b[^.!?\n]{0,40}?\bbut\b", m, re.I):
        h.add(mm.group(0))
    for mm in re.finditer(r"\bdoesn(?:'|’)t just\b[^,.\n]{0,40}?\bit\b", m, re.I):
        h.add(mm.group(0))
    if h.count:
        F["17a"] = (17, h)
    h = Hits()
    for mm in re.finditer(r"(?<=[^\s,.!?;:]),\s+no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b", m, re.I):
        h.add(m[max(0, mm.start() - 30):mm.end()])
    if h.count:
        F["17b"] = (17, h)
    put(18, rx_hits(RX["notxjusty"], m))
    put(19, rx_hits(RX["filler"], m))
    put(20, rx_hits(RX["pivot"], m))
    put(21, rx_hits(RX["outcome"], m))
    put(22, rx_hits(RX["authority"], m))
    put(23, rx_hits(RX["editorial"], m))
    put(24, rx_hits(RX["selfthor"], m))
    # 25
    h = Hits()
    for mm in re.finditer(r"(?:^|(?<=[.!?])\s+|\n)\s*((?:Is|Are|Was|Were|Do|Does|Did|Can|Could|Will|Would|Should|Shall|Must|May|Might|Has|Have|Had)\b[^.!?\n]{0,100}\?)\s+(?:yes|no|absolutely|never|maybe|probably|always|definitely|certainly|sometimes)[.!](?=\s|$)", m, re.I):
        h.add(mm.group(0))
    put(25, h)
    put(26, rx_hits(RX["concrete"], m))
    put(27, rx_hits(RX["hook"], m))
    put(30, rx_hits(RX["diff"], m))
    put(31, rx_hits(RX["signpost"], m))
    h = rx_hits(RX["catalog"], m)
    for mm in RX["catalog2"].finditer(m):
        h.add(mm.group(0))
    put(32, h)
    h = Hits()
    for mm in re.finditer(r"^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]+?(?::\*\*|\*\*[ \t]*:)", m, re.M):
        h.add(mm.group(0))
    put(33, h)
    # 34
    if not re.search(r"^ {0,3}#{1,6}\s", m, re.M):
        paras = split_paragraphs(m)
        listp = 0
        prose = 0
        for p in paras:
            lines = [ln for ln in p.split("\n") if ln.strip()]
            if lines and all(re.match(r"^\s*(?:[-*+]|\d+[.)])\s+", ln) for ln in lines):
                listp += 1
            elif any(not re.match(r"^\s*(?:[-*+]|\d+[.)])\s+", ln) for ln in lines):
                prose += 1
        if listp >= 1 and prose >= 2:
            h = Hits()
            h.add("bulleted list among prose paragraphs", listp)
            put(34, h)
    # 35
    h = Hits()
    mlines = m.split("\n")
    for i, ln in enumerate(mlines):
        hm = re.match(r"^ {0,3}#{1,6}\s+(.+?)\s*#*\s*$", ln)
        if not hm:
            continue
        j = i + 1
        while j < len(mlines) and not mlines[j].strip():
            j += 1
        if j < len(mlines):
            nl = mlines[j].strip()
            if nl and not re.match(r"^(#{1,6}\s|[-*+]\s|\d+[.)]\s|\|)", nl):
                nw = WORD.findall(nl)
                if 0 < len(nw) <= 5:
                    hw = {w.lower() for w in WORD.findall(hm.group(1)) if len(w) >= 3}
                    if any(w.lower() in hw for w in nw if len(w) >= 3):
                        h.add(hm.group(1) + " / " + nl)
    put(35, h)
    put(36, rx_hits(RX["challenges"], m))
    # 37
    h = Hits()
    for p in split_paragraphs(m):
        found = TRANSITIONS.findall(p)
        if len(found) >= 2:
            h.add(", ".join(x.strip() for x in found[:3]), len(found))
    put(37, h)
    put(38, rx_hits(RX["conclusion"], m))
    put(39, rx_hits(RX["posconc"], m))
    # rhythm
    sents = sentences_of(m)
    slens = [len(WORD.findall(s)) for s in sents]
    if len(slens) >= 3 and cv(slens) < 0.35:
        h = Hits()
        h.add("sentence lengths nearly uniform (n=%d)" % len(slens), len(slens))
        put(40, h)
    if len(slens) >= 6:
        mean = sum(slens) / len(slens)
        best = 1
        run = 1
        prev_sign = 0
        for i in range(1, len(slens)):
            d = slens[i] - slens[i - 1]
            sign = (d > 0) - (d < 0)
            if sign != 0 and abs(d) >= max(4, 0.4 * mean) and (prev_sign == 0 or sign == -prev_sign):
                run = run + 1 if prev_sign != 0 else 2
                prev_sign = sign
            else:
                run = 1
                prev_sign = 0
                if sign != 0 and abs(d) >= max(4, 0.4 * mean):
                    run = 2
                    prev_sign = sign
            best = max(best, run)
        if best >= 6:
            h = Hits()
            h.add("alternating long/short sentences", 1)
            put(41, h)
    # 42
    h = Hits()
    for p in split_paragraphs(m):
        ps = [s for s in re.split(r"(?<=[.!?])[\"”’')\]]*\s+", " ".join(p.split("\n"))) if WORD.findall(s)]
        if len(ps) >= 3:
            openers = {}
            for s in ps:
                w = [x.lower() for x in WORD.findall(s)[:2]]
                if len(w) == 2:
                    openers.setdefault(tuple(w), []).append(s)
            for k, v in openers.items():
                if len(v) >= 3:
                    h.add(" ".join(k) + " ...", len(v))
    put(42, h)
    # 44
    pl = []
    for p in split_paragraphs(m):
        lines = [ln for ln in p.split("\n") if ln.strip()]
        if lines and all(re.match(r"^\s*#{1,6}\s", ln) for ln in lines):
            continue
        n = len(WORD.findall(p))
        if n:
            pl.append(n)
    if len(pl) >= 4 and cv(pl) < 0.4:
        h = Hits()
        h.add("paragraph word counts nearly uniform (n=%d)" % len(pl), len(pl))
        put(44, h)
    # 46
    if nwords >= 300 and ";" not in m and len(re.findall(r"\([^()\n]{1,200}\)", m)) <= 1:
        h = Hits()
        h.add("no semicolons and almost no parentheticals", 1)
        put(46, h)
    put(47, rx_hits(RX["chatbot"], m))
    put(48, rx_hits(RX["sycophant"], m))
    put(50, rx_hits(RX["cutoff"], m))
    put(51, rx_hits(RX["copula"], m))
    # 54
    h = Hits()
    for s in re.split(r"(?<=[.!?])\s+", m):
        hs = HEDGES.findall(s)
        if len(hs) >= 2:
            h.add(s)
    put(54, h)
    # 55
    fp = len(re.findall(r"\b(?:I|me|my|mine|myself|we|our|ours|us|ourselves|I(?:'|’)m|I(?:'|’)ve)\b", m, re.I))
    if nwords >= 30 and fp / max(nwords, 1) >= 0.02:
        unc = re.findall(r"\b(?:I am|I have|I will|I would|I had|do not|does not|did not|is not|are not|was not|were not|cannot|can not|will not|would not|should not|could not|have not|has not|had not|it is|that is|there is|they are|we are|you are|we have|they have|let us)\b", m, re.I)
        con = re.findall(r"\b\w+n(?:'|’)t\b|\b(?:I|we|you|they|it|that|there|he|she|who)(?:'|’)(?:m|re|ve|ll|d|s)\b", m, re.I)
        if len(unc) >= 3 and len(unc) > 2 * len(con):
            h = Hits()
            for u in unc[:3]:
                h.add(u)
            h.count = len(unc)
            put(55, h)
    h = Hits()
    for mm in re.finditer(r"\*\*[^*\n]+?\*\*", m):
        h.add(mm.group(0))
    put(56, h)
    h = Hits()
    for mm in re.finditer("[\U0001F000-\U0001FAFF☀-➿⭐⭕⬛⬜⌚⌛⏩-⏳⏸-⏺⤴⤵]", m):
        h.add(mm.group(0))
    put(57, h)
    # 58
    h = Hits()
    for p in split_paragraphs(m):
        c = p.count("—")
        if c >= 2:
            h.add(_clip(p, 60), c)
    put(58, h)
    # 59
    h = Hits()
    minor = set("a an the and or but nor for so yet of in on at to by up as is it if via with from into over per vs off out".split())
    for mm in re.finditer(r"^ {0,3}#{1,6}[ \t]+(.+?)[ \t]*#*[ \t]*$", m, re.M):
        title = mm.group(1)
        ws = WORD.findall(title)
        if len(ws) < 3 or not title[0].isalpha() or title.upper() == title:
            continue
        major = [w for w in ws if w.lower() not in minor]
        if len(major) >= 2 and all(w[0].isupper() for w in major):
            h.add(title)
    put(59, h)
    h = Hits()
    for mm in re.finditer("[‘’“”]", m):
        h.add(excerpt(m, mm, 12))
    put(60, h)
    h = Hits()
    for mm in re.finditer(r"(?<![\d-])((?:1[0-9]|20)\d\d)-((?:1[0-9]|20)\d\d)(?![\d-])", m):
        if int(mm.group(1)) < int(mm.group(2)):
            h.add(mm.group(0))
    put(61, h)

    # character layer (raw window)
    inv = find_invisible(window)
    if inv:
        h = Hits()
        for i in inv[:3]:
            h.add("U+%04X" % ord(window[i]))
        h.count = len(inv)
        F[62] = (62, h)
    # 63
    h = Hits()
    short_lab = re.compile(r"^[A-Z]{1,2}\d{0,2}$|^\d+$")
    for mm in re.finditer(r"\[([^\[\]\n]{1,80})\](?![(\[])", m):
        inner = mm.group(1).strip()
        low = inner.lower()
        if re.match(r"^(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b", low):
            h.add(mm.group(0))
        elif inner.upper() == inner and re.search(r"[A-Z]", inner) and not short_lab.match(inner) and len(inner) >= 3:
            h.add(mm.group(0))
        elif len(inner.split()) <= 5 and re.search(r"\b(?:name|company|client|person|place|city|source|location|recipient|employer|organization|contact)\b", low) and "http" not in low:
            h.add(mm.group(0))
        elif low in ("todo", "tbd", "tk"):
            h.add(mm.group(0))
    for mm in re.finditer(r"\{\{[^{}\n]{1,80}\}\}", m):
        h.add(mm.group(0))
    for mm in re.finditer(r"(?<![A-Za-z])(?:x{3,}|X{4,}|XXX(?=[-.)\s]?[X\d]))(?![A-Za-z])", m):
        if mm.group(0) == "XXX" and not re.match(r"XXX[-.)]?X", m[mm.start():mm.start() + 6]):
            continue
        h.add(mm.group(0))
    for mm in RX["lorem"].finditer(m):
        h.add(mm.group(0))
    put(63, h)
    put(64, rx_hits(RX["cite"], m))
    h = Hits()
    for mm in re.finditer(r"utm_source=([A-Za-z0-9.-]+)", m, re.I):
        host = mm.group(1).rstrip(".").lower()
        if host in AI_TRACK:
            h.add(mm.group(0))
    put(65, h)
    hg = find_homoglyphs(window)
    if hg:
        h = Hits()
        toks = []
        for mm in _TOKEN.finditer(window):
            if any(mm.start() <= i < mm.end() for i, _ in hg[:6]):
                toks.append(mm.group(0))
        for t_ in toks[:3]:
            h.add(t_)
        h.count = len(hg)
        F[66] = (66, h)
    sp = find_nonstd_spaces(window)
    if sp:
        h = Hits()
        h.count = len(sp)
        h.samples = ["U+%04X" % ord(window[sp[0][0]])]
        F[67] = (67, h)
    # 68
    h = Hits()
    n68 = 0
    wl = window.split("\n")
    for k, ln in enumerate(wl[:-1]):
        c = ln[:-1] if ln.endswith("\r") else ln
        if c != c.rstrip(" \t"):
            n68 += 1
    if window[-1:] in (" ", "\t"):
        n68 += 1
    if window.endswith("\n\n") or window.endswith("\r\n\r\n"):
        n68 += 1
    if window[:1].isspace():
        n68 += 1
    if n68:
        h.add("stray whitespace", n68)
        put(68, h)
    put(69, rx_hits(RX["slop"], m))
    # 70
    mls = m.split("\n")
    if len(mls) >= 24:
        h = Hits()
        for i, ln in enumerate(mls):
            if re.match(r"^\s{0,3}(?:-{3,}|\*{3,}|_{3,}|(?:\*[ \t]+){2,}\*|(?:-[ \t]+){2,}-)\s*$", ln):
                if i == 0 or not mls[i - 1].strip():
                    h.add(ln.strip())
        if h.count >= 3:
            put(70, h)
    # 71
    lw = [w.lower() for w in words]
    if len(lw) >= 18:
        grams = [tuple(lw[i:i + 6]) for i in range(len(lw) - 5)]
        cnt = {}
        for g in grams:
            cnt[g] = cnt.get(g, 0) + 1
        rep = sum(1 for g in grams if cnt[g] > 1)
        if rep / len(grams) >= 0.2:
            h = Hits()
            top = max(cnt, key=lambda g: cnt[g])
            h.add(" ".join(top), rep)
            put(71, h)
    return F, nwords, slens


def build_score(F, nwords):
    fam = {}
    for key, (num, h) in F.items():
        if num in ADVICE or num == 17:
            continue
        fam[num] = fam.get(num, 0) + h.count
    if nwords < 40:
        conf = "none"
    elif nwords < 120:
        conf = "low"
    elif nwords < 300:
        conf = "low" if len(fam) == 1 else "moderate"
    else:
        conf = "high"
    if conf == "high":
        reason = ""
    elif conf == "none":
        reason = "fewer than 40 words, too little text to score reliably"
    elif nwords < 120:
        reason = "fewer than 120 words, so the score is only a rough signal"
    else:
        reason = "fewer than 300 words and only one pattern family fired"
    if not fam:
        return 0, conf, reason, fam
    raw = 0.0
    for num, c in fam.items():
        raw += 9 + min(c - 1, 4) * 1.5
    score = int(round(raw))
    score = max(1, score)
    nf = len(fam)
    if nf == 1:
        only = next(iter(fam))
        if only == 40:
            score = min(score, 20)
        else:
            score = min(score, 40)
    elif set(fam) <= RHYTHM:
        score = min(score, 40)
    dec = [n for n in fam if n in DECISIVE]
    if len(dec) >= 2:
        score = max(score, 65)
    elif len(dec) == 1 and conf in ("moderate", "high"):
        score = max(score, 45)
    if nwords < 120:
        k = len([n for n in fam if n in SHORT_SET])
        if k >= 3:
            score = max(score, 45)
        elif k >= 2:
            score = max(score, 25)
    elif nwords >= 400:
        if nf >= 6:
            score = max(score, 45)
        elif nf >= 5:
            score = max(score, 25)
    # single-family cap re-applied unless decisive floor applies
    if nf == 1 and not (len(dec) == 1 and conf in ("moderate", "high")):
        score = min(score, 20 if next(iter(fam)) == 40 else 40)
    score = max(0, min(100, score))
    return score, conf, reason, fam


def band_of(score):
    if score <= 20:
        return "clean"
    if score <= 40:
        return "light tells"
    if score <= 60:
        return "mixed"
    if score <= 80:
        return "heavy tells"
    return "pervasive tells"


def score_only(text):
    F, nw, _ = analyze_prose(text)
    s, _, _, _ = build_score(F, nw)
    return s


def analyze(text, ci=False):
    window = text[:WINDOW]
    F, nwords, slens = analyze_prose(window)
    score, conf, reason, fam = build_score(F, nwords)
    out = {}
    used = {}
    for key, (num, h) in F.items():
        slug, label = LABELS[num]
        if num == 17:
            if key == "17a":
                k = "17_negative_parallelism"
                label = "Negative parallelism"
            else:
                k = "17_tailing_negation"
                label = "Tailing negation"
        else:
            k = "%d_%s" % (num, slug)
        out[k] = {"label": label, "count": h.count, "samples": h.samples[:3]}
    metrics = {
        "scanned_chars": len(window),
        "truncated": len(text) > WINDOW,
        "ai_tell_score": score,
        "ai_tell_band": band_of(score),
        "confidence": conf,
        "confidence_reason": reason,
        "patterns_flagged": len(out),
        "invisible_chars": F[62][1].count if 62 in F else 0,
        "nonstandard_spaces": F[67][1].count if 67 in F else 0,
        "homoglyphs": F[66][1].count if 66 in F else 0,
        "word_count": nwords,
    }
    if ci:
        sents = sentences_of(mask_text(window))
        if len(sents) >= 4:
            rng = random.Random(1234)
            iters = 40 if len(window) < 40000 else 10
            vals = []
            for _ in range(iters):
                pick = [sents[rng.randrange(len(sents))] for _ in sents]
                vals.append(score_only(" ".join(pick)))
            vals.sort()
            lo = vals[int(0.05 * (len(vals) - 1))]
            hi = vals[int(math.ceil(0.95 * (len(vals) - 1)))]
            lo = min(lo, score)
            hi = max(hi, score)
            metrics["score_ci"] = [float(lo), float(hi)]
            metrics["score_ci_note"] = "bootstrap interval over resampled sentences (%d resamples, fixed seed)" % iters
        else:
            metrics["score_ci"] = None
            metrics["score_ci_note"] = "too few sentences for an interval (need at least 4)"
    out["_metrics"] = metrics
    return out


# --------------------------------------------------------------------------
# command line
# --------------------------------------------------------------------------

def err(msg, code):
    sys.stderr.write(json.dumps({"error": msg}) + "\n")
    sys.stderr.flush()
    sys.exit(code)


def main(argv):
    clean = False
    ci = False
    operands = []
    show_help = False
    unknown = None
    i = 0
    endopts = False
    while i < len(argv):
        a = argv[i]
        i += 1
        if endopts:
            operands.append(a)
            continue
        if a == "--":
            endopts = True
        elif a == "--clean":
            clean = True
        elif a == "--ci":
            ci = True
        elif a in ("--help", "-h"):
            show_help = True
        elif a.startswith("-") and a != "":
            if unknown is None:
                unknown = a
        else:
            operands.append(a)
    if unknown is not None:
        err("unknown option %s (see --help)" % unknown, 2)
    if show_help:
        sys.stdout.buffer.write(USAGE_FULL.encode("utf-8"))
        sys.stdout.flush()
        return 0
    if len(operands) >= 2:
        sys.stderr.write("prosecheck: multiple files given; only the first file was scanned: %s\n" % operands[0])
    path = operands[0] if operands else None
    try:
        if path is None:
            data = sys.stdin.buffer.read()
        else:
            try:
                with open(path, "rb") as f:
                    data = f.read()
            except Exception as e:
                raise InputError("cannot read input: %s" % (e.strerror or e.__class__.__name__ if hasattr(e, "strerror") else e))
        try:
            text = extract(path, data)
        except InputError as e:
            raise InputError("cannot read input: %s" % e)
    except InputError as e:
        msg = str(e)
        if not msg.startswith("cannot read input:"):
            msg = "cannot read input: " + msg
        err(msg, 1)
    if not text.strip():
        err("empty input", 1)
    if clean:
        out = clean_text(text)
        sys.stdout.buffer.write(out.encode("utf-8", "replace"))
        sys.stdout.flush()
        return 0
    rep = analyze(text, ci)
    sys.stdout.buffer.write((json.dumps(rep, indent=2) + "\n").encode("utf-8"))
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    try:
        code = main(sys.argv[1:])
    except SystemExit:
        raise
    except BrokenPipeError:
        code = 0
    except Exception as e:  # never a traceback
        sys.stderr.write(json.dumps({"error": "cannot read input: internal error: %s" % e.__class__.__name__}) + "\n")
        code = 1
    sys.exit(code)
