#!/usr/bin/env node
'use strict';
// Session-start hook: prints the welcome (first run only) and the writing contract.
const core = require('./lib/core');

try {
  core.readStdinJson();
  const hadFlag = core.flagExists();
  const lvl = core.effectiveLevel();
  if (lvl !== 'off') {
    if (!hadFlag) core.writeLevel(lvl);
    core.pruneLedgers();
    let out = '';
    if (!hadFlag) out += core.welcomeText() + '\n\n';
    out += core.contractText(lvl, { detector: core.detectorPath() });
    process.stdout.write(out);
  }
} catch (e) {
  // A hook must never fail the host session.
}
process.exit(0);
