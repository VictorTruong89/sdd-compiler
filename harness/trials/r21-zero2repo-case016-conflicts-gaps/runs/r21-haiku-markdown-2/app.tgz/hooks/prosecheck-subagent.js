#!/usr/bin/env node
'use strict';
// Subagent-start hook: returns the same writing contract for the stored level.
const core = require('./lib/core');

try {
  core.readStdinJson();
  const lvl = core.effectiveLevel();
  if (lvl !== 'off') {
    const ctx = core.contractText(lvl, { detector: core.detectorPath() });
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext: ctx },
    }) + '\n');
  }
} catch (e) {
  // Never fail the host session.
}
process.exit(0);
