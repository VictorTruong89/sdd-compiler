#!/usr/bin/env node
'use strict';
// Prompt-submit hook: /prosecheck command router, stop phrases, and the level reminder.
const core = require('./lib/core');
const { route } = require('./lib/commands');

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }) + '\n');
}

try {
  const input = core.readStdinJson();
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const reply = route(prompt, input.session_id, input.transcript_path);
  if (reply !== null) {
    block(reply);
  } else {
    const t = prompt.trim().toLowerCase();
    if (t === 'stop prosecheck' || t === 'prosecheck off') {
      core.writeLevel('off');
      block('prosecheck is off: stored level off. /prosecheck on re-enables it.');
    } else {
      const lvl = core.effectiveLevel();
      if (lvl !== 'off') {
        const ctx = 'prosecheck: level ' + lvl + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.';
        process.stdout.write(JSON.stringify({
          hookSpecificOutput: { hookEventName: 'UserPromptSubmit', additionalContext: ctx },
        }) + '\n');
      }
    }
  }
} catch (e) {
  // Never fail the host session.
}
process.exit(0);
