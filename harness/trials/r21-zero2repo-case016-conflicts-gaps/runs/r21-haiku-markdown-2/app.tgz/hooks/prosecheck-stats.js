#!/usr/bin/env node
'use strict';
// Stats hook: answers /prosecheck stats from the host transcript (or the newest one).
const core = require('./lib/core');
const { statsReply } = require('./lib/stats');

try {
  const input = core.readStdinJson();
  const reply = statsReply(input.transcript_path);
  process.stdout.write(JSON.stringify({ decision: 'block', reason: reply }) + '\n');
} catch (e) {
  // Never fail the host session.
}
process.exit(0);
