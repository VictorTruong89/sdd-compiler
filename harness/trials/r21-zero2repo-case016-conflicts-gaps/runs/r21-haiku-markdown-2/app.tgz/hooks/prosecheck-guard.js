#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores prose files just saved by Write, Edit, MultiEdit,
// NotebookEdit, or apply_patch, and nudges when a file is flagged.
const fs = require('fs');
const path = require('path');
const core = require('./lib/core');

const INSTRUCTION_EXACT = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
const INSTRUCTION_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];
const PATCH_MAX = 10;

function isSkippedInstruction(base, ext) {
  const lower = base.toLowerCase();
  if (INSTRUCTION_EXACT.includes(lower)) return true;
  const stem = lower.slice(0, lower.length - ext.length);
  return INSTRUCTION_STEMS.includes(stem) && !core.PROSE_EXT.includes(ext);
}

function pathsFromInput(input) {
  const ti = input.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  if (typeof ti.command === 'string' && /^\*\*\* (?:Add File|Update File|Move to):/m.test(ti.command)) {
    const found = [];
    const re = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/gm;
    let m;
    while ((m = re.exec(ti.command)) !== null) {
      const p = m[1].trim();
      if (p && !found.includes(p)) found.push(p);
    }
    return found.slice(0, PATCH_MAX);
  }
  const p = ti.file_path || ti.notebook_path;
  if (typeof p === 'string' && p.trim()) return [p.trim()];
  return [];
}

function phraseLabels(report) {
  const m = report._metrics;
  const keys = Array.isArray(m.score_moving_keys) ? m.score_moving_keys : [];
  const source = keys.length ? keys : Object.keys(report).filter((k) => k !== '_metrics');
  return source.filter((k) => report[k]).map((k) => report[k].label).slice(0, 5);
}

function main() {
  const input = core.readStdinJson();
  const lvl = core.effectiveLevel();
  if (lvl === 'off' || lvl === 'lite') return;
  const threshold = lvl === 'strict' ? core.STRICT_THRESHOLD : core.FULL_THRESHOLD;
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const sid = input.session_id;
  const plugin = core.pluginRoot();
  const lines = [];

  for (const raw of pathsFromInput(input)) {
    const abs = path.resolve(cwd, raw);
    const base = path.basename(abs);
    const ext = core.extOf(abs);
    const segs = abs.split(path.sep);
    if (segs.includes('node_modules') || segs.includes('.git')) continue;
    if (abs.startsWith(path.resolve(plugin) + path.sep)) continue;
    if (isSkippedInstruction(base, ext)) continue;
    if (core.NO_PROSE_EXT.includes(ext)) {
      core.appendLedger(sid, { base, kind: 'binary', ext });
      continue;
    }
    if (!core.PROSE_EXT.includes(ext)) continue;

    let st;
    try {
      st = fs.statSync(abs);
    } catch (e) {
      core.appendLedger(sid, { base, kind: 'failed', reason: 'file cannot be read' });
      continue;
    }
    if (!st.isFile()) continue;

    const cap = core.capFor(ext);
    if (st.size > cap.bytes) {
      core.appendLedger(sid, { base, kind: 'skipped', limitKb: cap.kb });
      continue;
    }

    const r = core.runDetector(abs, cap.bytes === core.PLAIN_CAP_BYTES ? 8000 : 15000);
    if (r.kind !== 'ok') {
      const reason = {
        notfound: 'Python not found',
        timeout: 'detector timed out',
        failed: 'detector failed' + (r.stderr ? ': ' + r.stderr : ''),
        empty: 'detector produced no usable result',
        notreport: 'detector output was not a structured report',
        noscore: 'report has no numeric score',
      }[r.kind] || 'detector produced no usable result';
      core.appendLedger(sid, { base, kind: 'failed', reason });
      continue;
    }

    const rep = r.report;
    const m = rep._metrics;
    const flagged = m.ai_tell_score > threshold;
    const labels = phraseLabels(rep);
    core.appendLedger(sid, {
      base, kind: 'scored', score: m.ai_tell_score, band: m.ai_tell_band,
      labels, flagged, truncated: !!m.truncated,
    });
    if (flagged) {
      const cov = m.truncated ? ', first ' + core.WINDOW_TEXT + ' characters only' : '';
      lines.push('prosecheck: ' + base + ' ' + core.phraseFor(m.ai_tell_band) + ' (score ' + m.ai_tell_score +
        ', band ' + m.ai_tell_band + cov + '). Flagged: ' + labels.join('; ') +
        '. Fix the flagged spans: rewrite those sentences in plain, specific prose and keep the meaning.');
    }
  }

  if (lines.length) {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
    }) + '\n');
  }
}

try {
  main();
} catch (e) {
  // A hook must never fail the host; malformed input prints nothing.
}
process.exit(0);
