"""prosecheck extraction: turn a supported file (or stdin) into visible prose.

Standard library only. Errors are raised as ExtractError(code, message).
"""
import io
import json
import os
import re
import zipfile
from html.parser import HTMLParser
from xml.etree import ElementTree

PLAIN_EXT = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXT = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NOTEBOOK_EXT = {'.ipynb'}
NO_PROSE_EXT = {'.pdf', '.rtf'}
PROSE_EXT = PLAIN_EXT | ZIP_EXT | NOTEBOOK_EXT
MEMBER_LIMIT = 64 * 1024 * 1024


class ExtractError(Exception):
    def __init__(self, code, message):
        Exception.__init__(self, message)
        self.code = code
        self.message = message


def _local(tag):
    if not isinstance(tag, str):
        return ''
    return tag.rsplit('}', 1)[-1]


def decode_plain(data):
    if data.startswith(b'\xff\xfe') or data.startswith(b'\xfe\xff'):
        return data.decode('utf-16', errors='replace')
    if data.startswith(b'\xef\xbb\xbf'):
        data = data[3:]
    try:
        return data.decode('utf-8')
    except UnicodeDecodeError:
        return data.decode('utf-8', errors='replace')


def _read_member(z, name):
    try:
        info = z.getinfo(name)
    except KeyError:
        return None
    if info.file_size > MEMBER_LIMIT:
        return None
    return z.read(name)


def _para_text(el):
    """Visible text of a paragraph-like element: t/tab/br, skipping deleted text."""
    parts = []

    def walk(e):
        name = _local(e.tag)
        if name in ('delText', 'instrText', 'rPh'):
            return
        if name == 't':
            if e.text:
                parts.append(e.text)
        elif name == 'tab':
            parts.append('\t')
        elif name in ('br', 'cr'):
            parts.append('\n')
        for c in e:
            walk(c)

    walk(el)
    return ''.join(parts)


def _docx(z):
    data = _read_member(z, 'word/document.xml')
    if data is None:
        return ''
    root = ElementTree.fromstring(data)
    paras = []
    for el in root.iter():
        if _local(el.tag) == 'p':
            t = _para_text(el).strip()
            if t:
                paras.append(t)
    return '\n'.join(paras)


def _pptx(z):
    slides = []
    for name in z.namelist():
        m = re.match(r'^ppt/slides/slide(\d+)\.xml$', name)
        if m:
            slides.append((int(m.group(1)), name))
    slides.sort()
    out = []
    for _, name in slides:
        root = ElementTree.fromstring(z.read(name))
        paras = []
        for el in root.iter():
            if _local(el.tag) == 'p':
                t = _para_text(el).strip()
                if t:
                    paras.append(t)
        if paras:
            out.append('\n'.join(paras))
    return '\n'.join(out)


def _xlsx(z):
    shared = []
    sdata = _read_member(z, 'xl/sharedStrings.xml')
    if sdata is not None:
        sroot = ElementTree.fromstring(sdata)
        for si in sroot:
            if _local(si.tag) == 'si':
                shared.append(_para_text(si))
    sheets = []
    for name in z.namelist():
        m = re.match(r'^xl/worksheets/sheet(\d+)\.xml$', name)
        if m:
            sheets.append((int(m.group(1)), name))
    sheets.sort()
    out = []
    for _, name in sheets:
        root = ElementTree.fromstring(z.read(name))
        cells = []
        for el in root.iter():
            if _local(el.tag) != 'c':
                continue
            kind = el.get('t')
            text = None
            if kind == 's':
                v = None
                for ch in el:
                    if _local(ch.tag) == 'v':
                        v = ch.text
                if v is not None and v.strip().isdigit():
                    idx = int(v.strip())
                    if idx < len(shared):
                        text = shared[idx]
            elif kind == 'inlineStr':
                for ch in el:
                    if _local(ch.tag) == 'is':
                        text = _para_text(ch)
            elif kind == 'str':
                for ch in el:
                    if _local(ch.tag) == 'v':
                        text = ch.text
            if text and text.strip():
                cells.append(text.strip())
        if cells:
            out.append('\n'.join(cells))
    return '\n'.join(out)


_ODF_SKIP = {'annotation', 'automatic-styles', 'styles', 'font-face-decls',
             'meta', 'settings', 'scripts', 'sequence-decls', 'tracked-changes'}


def _odf_text(root):
    parts = []

    def walk(e, in_text):
        name = _local(e.tag)
        if name in _ODF_SKIP:
            return
        if name in ('p', 'h'):
            in_text = True
        if in_text:
            if name == 's':
                n = 1
                for k, v in e.attrib.items():
                    if _local(k) == 'c':
                        try:
                            n = int(v)
                        except ValueError:
                            n = 1
                parts.append(' ' * n)
            elif name == 'tab':
                parts.append('\t')
            elif name == 'line-break':
                parts.append('\n')
            if e.text:
                parts.append(e.text)
        for c in e:
            walk(c, in_text)
            if in_text and c.tail:
                parts.append(c.tail)
        if in_text and name in ('p', 'h'):
            parts.append('\n')

    walk(root, False)
    return ''.join(parts)


def _odf(z):
    data = _read_member(z, 'content.xml')
    if data is None:
        return ''
    return _odf_text(ElementTree.fromstring(data))


class _HTMLProse(HTMLParser):
    BLOCK = {'p', 'div', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'br', 'tr',
             'section', 'article', 'blockquote', 'figcaption', 'dt', 'dd', 'pre',
             'table', 'ul', 'ol', 'header', 'footer', 'aside', 'hr'}
    SKIP = {'script', 'style', 'head', 'nav', 'title'}

    def __init__(self):
        HTMLParser.__init__(self, convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        if tag in self.SKIP:
            self.skip += 1
            return
        if tag in self.BLOCK:
            self.parts.append('\n')

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in self.SKIP:
            if self.skip > 0:
                self.skip -= 1
            return
        if tag in self.BLOCK:
            self.parts.append('\n')

    def handle_data(self, data):
        if self.skip:
            return
        self.parts.append(re.sub(r'[ \t\r\n\f]+', ' ', data))

    def text(self):
        raw = ''.join(self.parts)
        raw = re.sub(r'[ \t]*\n[ \t]*', '\n', raw)
        raw = re.sub(r'\n{3,}', '\n\n', raw)
        return raw.strip()


def _epub(z):
    chapters = []
    for name in sorted(z.namelist()):
        low = name.lower()
        base = os.path.basename(low)
        if not low.endswith(('.xhtml', '.html', '.htm')):
            continue
        if 'nav' in base or 'toc' in base:
            continue
        data = _read_member(z, name)
        if data is None:
            continue
        p = _HTMLProse()
        try:
            p.feed(decode_plain(data))
            p.close()
        except Exception:
            continue
        t = p.text()
        if t:
            chapters.append(t)
    return '\n'.join(chapters)


def extract_zip(data, ext, path):
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise ExtractError(1, 'cannot read input: %s is not a readable zip archive' % path)
    try:
        with z:
            if ext in ('.docx', '.docm'):
                text = _docx(z)
            elif ext in ('.pptx', '.pptm'):
                text = _pptx(z)
            elif ext in ('.xlsx', '.xlsm'):
                text = _xlsx(z)
            elif ext in ('.odt', '.odp', '.ods'):
                text = _odf(z)
            else:
                text = _epub(z)
    except zipfile.BadZipFile:
        raise ExtractError(1, 'cannot read input: %s is not a readable zip archive' % path)
    except (ElementTree.ParseError, KeyError, ValueError, OSError, RuntimeError,
            zipfile.LargeZipFile) as e:
        raise ExtractError(1, 'cannot read input: %s (%s)' % (path, type(e).__name__))
    return text.strip()


def extract_notebook(data):
    try:
        nb = json.loads(decode_plain(data))
    except ValueError:
        return ''
    if not isinstance(nb, dict):
        return ''
    cells = nb.get('cells')
    if not isinstance(cells, list):
        return ''
    out = []
    for cell in cells:
        if not isinstance(cell, dict):
            return ''
        if cell.get('cell_type') != 'markdown':
            continue
        src = cell.get('source', '')
        if isinstance(src, list):
            if not all(isinstance(s, str) for s in src):
                return ''
            src = ''.join(src)
        elif not isinstance(src, str):
            return ''
        out.append(src)
    return '\n'.join(out).strip()


def load_prose(path):
    """Return the extracted prose for a path, or for stdin when path is None."""
    if path is None:
        import sys
        return decode_plain(sys.stdin.buffer.read())
    ext = os.path.splitext(path)[1].lower()
    try:
        if os.path.isdir(path):
            raise IsADirectoryError(21, 'is a directory')
        with open(path, 'rb') as f:
            data = f.read()
    except OSError as e:
        raise ExtractError(1, 'cannot read input: %s (%s)' % (path, e.strerror or type(e).__name__))
    if ext in ZIP_EXT:
        return extract_zip(data, ext, path)
    if ext in NOTEBOOK_EXT:
        return extract_notebook(data)
    if ext in NO_PROSE_EXT:
        return ''
    return decode_plain(data)
