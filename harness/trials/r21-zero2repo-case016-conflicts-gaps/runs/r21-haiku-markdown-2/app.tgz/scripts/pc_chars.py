"""prosecheck character layer: invisible characters, non-standard spaces,
mixed-script homoglyphs, trailing whitespace, and the cleanup scrub.

Detection and cleanup share the same functions so they always agree.
All non-ASCII characters in this file are written as escapes.
"""
import re
import unicodedata

SPACELESS = [(0x0E00, 0x0E7F), (0x0E80, 0x0EFF), (0x1000, 0x109F), (0x1780, 0x17FF),
             (0x3040, 0x30FF), (0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF),
             (0x20000, 0x2FA1F)]
CJK_IDEO = [(0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x2FA1F)]
JOINING = [(0x0590, 0x05FF), (0x0600, 0x06FF), (0x0750, 0x077F), (0x08A0, 0x08FF),
           (0xFB50, 0xFDFF), (0xFE70, 0xFEFF), (0x0900, 0x0DFF), (0x1000, 0x109F),
           (0x1780, 0x17FF)]
MONGOLIAN = [(0x1800, 0x18AF)]
KHMER = [(0x1780, 0x17FF)]
BIDI = {0x061C, 0x200E, 0x200F, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E,
        0x2066, 0x2067, 0x2068, 0x2069}
INVIS_EXTRA = {0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x180B, 0x180C, 0x180D,
               0x180E, 0x180F, 0x3164, 0xFFA0}
VISIBLE_FORMAT = {0x0600, 0x0601, 0x0602, 0x0603, 0x0604, 0x0605, 0x06DD, 0x070F,
                  0x08E2, 0x110BD, 0x110CD}
COMBINING_KEYCAP = '⃣'
NBSP = ' '
NNBSP = ' '
LINE_SEPS = (' ', ' ')
KEPT_NEXT = ':;!?»›%€'
KEPT_PREV = '«‹'

# Latin-looking letters from other scripts -> ASCII letter.
_CONF_PAIRS = [
    (0x0430, 'a'), (0x0441, 'c'), (0x0501, 'd'), (0x0435, 'e'), (0x0453, 'g'),
    (0x04BB, 'h'), (0x0456, 'i'), (0x0458, 'j'), (0x0578, 'n'), (0x043E, 'o'),
    (0x0440, 'p'), (0x0455, 's'), (0x057D, 'u'), (0x03BD, 'v'), (0x0475, 'v'),
    (0x051D, 'w'), (0x0445, 'x'), (0x0443, 'y'), (0x04AF, 'y'), (0x03B1, 'a'),
    (0x03BF, 'o'), (0x03C1, 'p'), (0x03C5, 'u'),
    (0x0410, 'A'), (0x0412, 'B'), (0x0421, 'C'), (0x0415, 'E'), (0x041D, 'H'),
    (0x0406, 'I'), (0x0408, 'J'), (0x041A, 'K'), (0x041C, 'M'), (0x041E, 'O'),
    (0x0420, 'P'), (0x0405, 'S'), (0x0422, 'T'), (0x0425, 'X'), (0x0423, 'Y'),
    (0x0391, 'A'), (0x0392, 'B'), (0x0395, 'E'), (0x0396, 'Z'), (0x0397, 'H'),
    (0x0399, 'I'), (0x039A, 'K'), (0x039C, 'M'), (0x039D, 'N'), (0x039F, 'O'),
    (0x03A1, 'P'), (0x03A4, 'T'), (0x03A5, 'Y'), (0x03A7, 'X'),
    (0x0555, 'O'), (0x054D, 'U'),
]
CONFUSABLE = {chr(cp): ch for cp, ch in _CONF_PAIRS}

_LETTER_RUN = re.compile(r'[^\W\d_]+')
_RTL_RE = re.compile('[֐-ࣿיִ-﷿ﹰ-﻿]')


def _inr(ch, ranges):
    if not ch:
        return False
    o = ord(ch)
    for a, b in ranges:
        if a <= o <= b:
            return True
    return False


def _sym(ch):
    if not ch:
        return False
    return ord(ch) >= 0x1F000 or unicodedata.category(ch) in ('So', 'Sm', 'Sk', 'Sc')


def _is_invisible_base(cp):
    if cp in (9, 10, 13):
        return False
    if cp in VISIBLE_FORMAT or 0x1D173 <= cp <= 0x1D17A:
        return False
    if cp < 32 or 0x7F <= cp <= 0x9F:
        return True
    if cp in INVIS_EXTRA or cp in BIDI:
        return True
    if 0xFE00 <= cp <= 0xFE0F or 0xE0000 <= cp <= 0xE0FFF:
        return True
    return unicodedata.category(chr(cp)) == 'Cf'


def _keep_invisible(text, i, rtl):
    cp = ord(text[i])
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if 0xE0020 <= cp <= 0xE007F:
        j = i - 1
        while j >= 0 and 0xE0020 <= ord(text[j]) <= 0xE007F:
            j -= 1
        return j >= 0 and ord(text[j]) == 0x1F3F4
    if 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF:
        if nxt == COMBINING_KEYCAP:
            return True
        return _sym(prev) or _inr(prev, CJK_IDEO)
    if cp == 0x200B:
        return _inr(prev, SPACELESS) or _inr(nxt, SPACELESS)
    if cp == 0xAD:
        return prev.isalpha() and nxt.isalpha()
    if cp in BIDI:
        return rtl
    if cp in (0x180B, 0x180C, 0x180D, 0x180F):
        return _inr(prev, MONGOLIAN)
    if cp in (0x17B4, 0x17B5):
        return _inr(prev, KHMER) or _inr(nxt, KHMER)
    if cp in (0x200C, 0x200D):
        for c in (prev, nxt):
            if c and (_inr(c, JOINING) or _sym(c)):
                return True
        return False
    return False


def invisible_positions(text):
    """Indexes of invisible characters that cleanup removes."""
    rtl = bool(_RTL_RE.search(text))
    res = []
    for i, ch in enumerate(text):
        cp = ord(ch)
        if 32 <= cp < 0x7F or cp in (9, 10, 13):
            continue
        if _is_invisible_base(cp) and not _keep_invisible(text, i, rtl):
            res.append(i)
    return res


def _nbsp_kept(text, i):
    prev = text[i - 1] if i > 0 else ''
    nxt = text[i + 1] if i + 1 < len(text) else ''
    if prev.isdigit() or nxt.isdigit():
        return True
    if nxt and nxt in KEPT_NEXT:
        return True
    if prev and prev in KEPT_PREV:
        return True
    return False


def space_positions(text):
    """Indexes of space separators that cleanup normalizes to U+0020."""
    res = []
    for i, ch in enumerate(text):
        if ord(ch) < 0x80:
            continue
        if unicodedata.category(ch) == 'Zs':
            if ch in (NBSP, NNBSP) and _nbsp_kept(text, i):
                continue
            res.append(i)
    return res


def _qualifies(run):
    has_ascii = False
    has_conf = False
    for c in run:
        if c.isascii():
            if c.isalpha():
                has_ascii = True
            continue
        if c in CONFUSABLE:
            has_conf = True
        else:
            return False
    return has_ascii and has_conf


def homoglyph_runs(text):
    """Letter runs mixing ASCII Latin with lookalike letters only."""
    out = []
    for m in _LETTER_RUN.finditer(text):
        if _qualifies(m.group(0)):
            out.append(m)
    return out


def fold_homoglyphs(text):
    def repl(m):
        run = m.group(0)
        if _qualifies(run):
            return ''.join(CONFUSABLE.get(c, c) for c in run)
        return run
    return _LETTER_RUN.sub(repl, text)


def trailing_count(text):
    """Count of trailing/stray whitespace findings (catalogue 68)."""
    if not text:
        return 0
    n = 0
    for line in text.split('\n'):
        if line.endswith(' ') or line.endswith('\t'):
            n += 1
    if text[:1].isspace():
        n += 1
    if text.endswith('\n\n'):
        n += 1
    return n


def scrub(text):
    """Cleanup: remove invisible characters, normalize spaces, fold homoglyphs, trim."""
    folded = fold_homoglyphs(text)
    rm = set(invisible_positions(folded))
    sp = set(space_positions(folded))
    out = []
    for i, ch in enumerate(folded):
        if i in rm:
            continue
        if i in sp:
            out.append(' ')
        elif ch in LINE_SEPS:
            out.append('\n')
        else:
            out.append(ch)
    s = ''.join(out)
    lines = [ln.rstrip(' \t') for ln in s.split('\n')]
    while lines and lines[0] == '':
        lines.pop(0)
    result = '\n'.join(lines).rstrip()
    if text.endswith('\n') and result:
        result += '\n'
    return result
