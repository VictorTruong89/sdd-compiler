"""prosecheck pattern families: the machine-checked catalogue rules.

run_families(window, view_lines) returns (findings, counts, words, sentences).
findings: key -> {'n', 'label', 'count', 'samples'}; counts: score-moving n -> hits.
Written with ASCII source; curly apostrophes are written as \\u2019 escapes.
"""
import math
import re
from collections import Counter

from pc_chars import (invisible_positions, homoglyph_runs, space_positions,
                      trailing_count)

AP = "['’]"  # apostrophe, straight or curly

ADVICE_NUMBERS = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
ADVICE_KEYS = {'17_negative_parallelism'}
DECISIVE = {13, 47, 48, 50, 62, 63, 64, 65, 66}

WORD_RE = re.compile(r"[^\W_](?:[^\W_]|['’\-])*")
HEAD_RE = re.compile(r'^\s{0,3}#{1,6}\s+\S')
LIST_RE = re.compile(r'^\s*(?:[-*+]|\d+[.)])\s+')
FENCE_OPEN = re.compile(r'^ {0,3}(`{3,}|~{3,})(.*)$')
BLOCKQUOTE_RE = re.compile(r'^\s{0,3}>')
TABLE_RE = re.compile(r'^\s*\|.*\|\s*$')
TABLE_SEP_RE = re.compile(r'^\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$')
BADGE_RE = re.compile(r'^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$')
INLINE_CODE_RE = re.compile(r'`[^`\n]+`')
HR_RE = re.compile(r'^\s*(?:-{3,}|\*{3,}|_{3,})\s*$')
EMOJI_RE = re.compile('[\U0001F000-\U0001FAFF☀-➿]')
TRANS = {'additionally', 'furthermore', 'moreover', 'however', 'nevertheless',
         'consequently', 'subsequently', 'notably'}
ADJ_SUFFIX = re.compile(r'(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$')
STOCK_ADJ = {'stunning', 'vibrant', 'elegant', 'seamless', 'robust', 'innovative',
             'powerful', 'beautiful', 'dynamic', 'modern', 'rich', 'lush', 'bold'}
SMALL_WORDS = {'a', 'an', 'the', 'of', 'in', 'on', 'at', 'to', 'for', 'by', 'with',
               'from', 'up', 'as', 'into', 'onto', 'off', 'over', 'and', 'or', 'but',
               'nor', 'so', 'yet'}


def I(w):
    """Single word with common inflections."""
    if w.endswith('e'):
        return re.escape(w[:-1]) + '(?:e|es|ed|ing)'
    return re.escape(w) + '(?:s|es|ed|ing)?'


def P(s):
    """Phrase: spaces match any whitespace; apostrophes match either form."""
    toks = s.split(' ')
    return r'\s+'.join(re.escape(t).replace("'", AP) for t in toks)


def WB(parts):
    return r'\b(?:' + '|'.join(parts) + r')\b'


CLUSTERS = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]

_AI_WORDS = ['additionally', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant',
             'meticulous', 'testament', 'underscore', 'intricate', 'intricacies',
             'interplay', 'garner', 'bolster', 'foster', 'showcase', 'emphasize',
             'enduring', 'enhance', 'leverage', 'utilize', 'facilitate', 'encompass',
             'harness', 'holistic', 'paradigm', 'transformative', 'unprecedented',
             'myriad', 'plethora', 'robust', 'seamless', 'navigate', 'embark', 'craft',
             'landscape', 'journey', 'realm', 'multifaceted', 'elevate', 'empower',
             'unlock']
_AI_PHRASES = [P('align with'), r'capture the (?:essence|spirit|imagination|heart|magic)']
_MODEL_WORDS = ['genuinely', 'fascinating', 'nuanced', 'thoughtfully', 'refreshingly',
                'strikingly', 'compellingly', 'supercharge', 'skyrocket', 'turbocharge',
                'revolutionize']
_MODEL_PHRASES = [r'quietly (?:powerful|profound|radical)',
                  r'deeply (?:human|personal|felt|unsettling)', P('resonates deeply'),
                  r'game[- ]chang(?:er|ing)s?', P('double down on'),
                  r'dive deep(?:er)? into', r'unlock (?:the )?(?:power|potential|value)',
                  r'take\b[^.!?\n]{0,60}?\bto the next level']
_PROMO = [P(x) for x in [
    'vibrant community', 'rich cultural heritage', 'in the heart of', 'world-class',
    'top-tier', 'unparalleled', 'premier', 'esteemed organization', 'valuable asset',
    'passion for excellence', 'proven track record', 'results-oriented',
    'wealth of experience', 'dynamic team', 'fast-paced environment', 'deeply passionate',
    'perfectly situated', 'uniquely positioned to', 'nestled', 'breathtaking',
    'must-visit', 'stunning', 'picturesque', 'charming', 'idyllic']] + [
    r'(?:close|tight)[- ]knit team', r'I am excited to (?:apply|bring)',
    r'\b(?:a|an|the|is|as) leading\b']
IMPERATIVE = {'install', 'join', 'grab', 'download', 'try', 'discover', 'experience',
              'escape', 'transform', 'reclaim', 'unlock', 'elevate', 'boost', 'say',
              'imagine', 'explore', 'meet', 'introducing', 'upgrade', 'claim', 'unleash',
              'supercharge', 'level', 'stop', 'start'}
_HYPHEN = [P(x) for x in [
    'cutting-edge', 'state-of-the-art', 'best-in-class', 'next-generation', 'top-notch',
    'user-friendly', 'high-quality', 'long-term', 'results-driven', 'detail-oriented',
    'data-driven', 'forward-thinking', 'well-rounded', 'customer-centric', 'value-driven']]
_SIG = [
    r'\b(?:stands?|serves?|stood|served) as (?:an? |the )?(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)s?\b',
    r'\b(?:underscor|highlight)\w*\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b',
    r'\breflects? a broader (?:trend|shift|pattern)\b',
    r'\bmarks? a (?:turning point|milestone|watershed|new chapter|new era)\b',
    r'\bsymboli[sz]\w*',
    r'\bsets? the stage for\b',
    r'\bleft an indelible mark\b',
    r'\bplays? a (?:crucial|pivotal|vital|key|central|significant) role\b',
    r'\bhas (?:shaped|sparked)\b',
    r'\bhas come to (?:define|symbolize)\b',
]
_VAGUE = [
    r'\bexperts? (?:argue|believe|say|claim|note|suggest)\b',
    r'\bindustry (?:reports|observers|analysts)\b',
    r'\bobservers (?:have cited|noted)\b',
    r'\bsome critics argue\b',
    r'\bresearchers have found\b',
    r'\bstudies suggest\b',
    r'\bit is widely believed\b',
]
_CONSERV = [
    r'\bplays? a (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b',
    r'\bconservation efforts are (?:underway|ongoing|in place)\b',
    r'\bserves as an indicator species\b',
    r'\bcontributes? to biodiversity\b',
]
_FALSE_RANGE = [
    r'\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]*?\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b',
    r'\bfrom (?:the )?humble\b[^.!?\n]*?\bto (?:the )?(?:mighty|towering|grand|sprawling)\b',
]
_TAIL_ING = [r',\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b']
_NEG_PARALLEL = [
    r"\bit" + AP + r"s not (?:just|merely) (?:about|an?)\b",
    r'\bnot only\b[^.!?\n]{0,40}?\bbut\b',
    r"\bdoesn" + AP + r"t just\b[^,.\n]{0,40}?\bit\b",
]
_TAIL_NEG = [r',\s+no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b']
_NOT_JUST = [
    r'\b(?:no|not) \w+,\s+(?:just|only|simply)\s+\w+',
    r"\b(?:not|isn" + AP + r"t|aren" + AP + r"t|wasn" + AP + r"t|weren" + AP + r"t) (?:just|merely) (?:a|an|the) \w+(?:,|\s*[-–—])\s*(?:it" + AP + r"s|it is|it was|they" + AP + r"re|they are|they were|that" + AP + r"s|but)\b",
]
_PIVOT = [
    r"\bit" + AP + r"s worth (?:noting|mentioning) that\b",
    r'\bit bears (?:noting|mentioning) that\b',
    r'\bone thing to (?:consider|keep in mind) is\b',
    r'\bit is interesting to note that\b',
    r'\ba key consideration is\b',
    r'\ba point to highlight is\b',
]
_OUTCOME = [r',\s+(?:raising questions about|prompting reflection on|sparking debate about|with broader implications for|reshaping our understanding of|paving the way for|signaling a shift toward)\b']
_HOOKS = [
    r"\bin today" + AP + r"s (?:\w+\s+){0,2}?(?:world|landscape|environment|market)\b",
    r'\bin a world where\b',
    r'\bin an era of\b',
    r'\bin recent years,',
    r'\bmore than ever before\b',
    r'\bwe live in a (?:time|world) when\b',
    r'\b(?:great|exciting|big) news\s*[!:]',
    r"\bever (?:wanted|wondered|dreamed|wished to)\b[^?\n]*\?",
    r'\bin an increasingly (?:interconnected|digital|competitive|complex) world\b',
]
_CHALLENGE = [
    r'\bdespite (?:these|its|the) (?:challenges|obstacles)\b',
    r'\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b',
    r'\bcontinues to thrive\b',
    r'\btypical of (?:emerging|urban|modern)\b',
    r'\bfaces (?:several|many|numerous) challenges\b',
]
_GENERIC_POS = [
    r'\bthe future looks bright\b',
    r'\bexciting times lie ahead\b',
    r'\bjourney toward excellence\b',
    r'\bstep in the right direction\b',
    r'\b(?:the )?(?:outlook|future)(?: for [^.,\n]+)? (?:is|looks|remains) bright\b',
    r'\bwell[- ]positioned (?:for (?:whatever comes next|the future|the road ahead))\b',
]
_FILLER = [P(x) for x in [
    'in order to', 'due to the fact that', 'at this point in time', 'in the event that',
    'has the ability to', 'it is important to note that', 'it should be mentioned that',
    'needless to say']]
_PERSUASIVE = [P(x) for x in [
    "here's the thing", 'make no mistake', 'the truth is', "let's be honest",
    'the simple fact is', 'at its core', 'what really matters', 'more than anything',
    'at the end of the day', 'the bottom line is', 'in reality', 'the real question is',
    'the heart of the matter', 'the deeper issue', 'when you get down to it',
    'when all is said and done']] + [r'\bfundamentally,']
_SELF_THOR = [
    r'\bthis comprehensive (?:guide|overview|analysis)\b',
    r'\bthis in-depth (?:analysis|look|examination)\b',
    r'\bthis complete (?:guide|overview)\b',
    r'\ba thorough examination of\b',
    r'\beverything you need to know about\b',
]
_EDITORIAL = [
    r"\bit(?:" + AP + r"s| is) important to (?:remember|note|understand|recognize)\b",
    r'\bone must note that\b',
    r'\bit is worth pointing out\b',
    r'\bit cannot be overstated that\b',
    r'\bit must be emphasized that\b',
]
_QA = [r"(?:^|[.!?\n]\s*)((?:Is|Are|Was|Were|Do|Does|Did|Can|Could|Will|Would|Should|Has|Have|Had|May|Might|Must|Shall)\s[^?\n]{0,80}\?)\s*\n?\s*(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)[.!]"]
_CONCRETE = [
    r'\bwithout concrete (?:evidence|proof)\b',
    r'\bdo you have concrete evidence\b',
    r'\bI (?:would )?need concrete (?:evidence|examples) to\b',
    r'\babsent concrete proof\b',
    r'\bprovide concrete evidence\b',
]
_NOTABILITY = [
    r'(?i:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+[A-Z][\w&.\-]*(?:\s+[A-Z][\w&.\-]*)*(?:,\s*|\s+and\s+)[A-Z][\w&.\-]*',
    r'\b\d[\d,.]*\s*(?:[kKmM]|million|thousand)?\s+(?:followers|subscribers)\b',
    r'\bstrong (?:online|digital|social[- ]media) presence\b',
    r'\bactive (?:online|digital|social[- ]media) presence\b',
    r'\bwidely covered\b',
    r'\bindependent coverage\b',
]
_DIFF = [
    r'\bunlike the (?:previous|prior|old|earlier) (?:versions?|releases?|implementations?|approach(?:es)?)\b',
    r'\b(?:the|this) (?:latest |new )?(?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b',
    r'\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed) to\b',
    r'\bpreviously\b[^.!?\n]*\bnow\b',
    r"\b(?:wasn|weren)" + AP + r"t there before\b",
    r"\bwe(?:" + AP + r"ve| have)(?: now)? (?:added|removed|replaced|refactored|migrated)\b",
]
_SIGNPOST = [
    r"\blet" + AP + r"s (?:dive|delve|explore)\b",
    r"\blet" + AP + r"s break (?:this|it) down\b",
    P("here's what you need to know"),
    r'\bwithout further ado\b',
    r"\bnow let" + AP + r"s look at\b",
    r'\bbuckle up\b',
    r'\bstay with me\b',
    r'\b(?:are you )?ready to dive in\b',
]
_CATALOG = [
    r'\b(?:used|uses|employs|employed|relied on|utilizes)\s+(?:several|various|a number of|multiple|different|many|numerous)\s+\w+',
    r'(?:^|[.!?]\s+)These(?:\s+\w+)?\s+(?:provide|offer|give|reveal|show|allow|enable|help)\s+(?:\w+\s+)?(?:information|insight|understanding|details|data)\b',
    r'\b(?:is|are|was|were|remains|becomes)\s+(?:the\s+|a\s+)(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue)\s+of\b',
]
_CONCLUDE_LINE = r'^\s*(?:[-*]\s+)?(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|ultimately)\b'
_CHATBOT = [
    r'\bI hope this helps\b',
    r'\bCertainly!',
    r'\bOf course!',
    r'\blet me know if you\b',
    r'\bwould you like me to\b',
    r'\bfeel free to (?:ask|reach out)\b',
    r'(?:^|[.!?]\s+)happy to help[.!]',
    r'\b(?:here|below) is (?:a|an|the) (?:overview|summary|rundown|recap|brief)\b',
    r"\bhere (?:are|is|['’]s) (?:a few|some|two|three) (?:options|drafts|versions|variations)\b",
    r"\bhere (?:is|['’]s) a draft\b",
    r'\bdepending on the (?:vibe|tone|style)\b',
    r'\bI hope (?:this email )?finds you well\b',
    r'\bas an? (?:AI|LLM|AI assistant|AI language model|large language model|language model)\b',
    r'\bto (?:answer|address) your question\b',
    r'\bin (?:response|answer) to your question\b',
    r'\byour question (?:about|regarding|concerning)\b',
    r'\bas (?:you )?(?:requested|asked), here\b',
    r'\bhere is (?:the )?(?:draft|first pass|revised version)\b',
]
_SYCO = [
    r"\byou(?:" + AP + r"re| are) absolutely right\b",
    r'\b(?:great|excellent|fantastic|wonderful|brilliant|thoughtful|insightful) (?:question|point)\s*[!.,]',
    r'\bwhat a (?:thoughtful|great|wonderful|fantastic) question\b',
    r"\bthat" + AP + r"s a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b",
]
_CUTOFF = [
    r'\bas of my (?:last )?(?:training|knowledge)\b',
    r'\bup to my (?:last )?(?:training|knowledge)\b',
    r'\bas of my (?:knowledge )?cutoff\b',
    r'\bwhile specific details are (?:limited|scarce|not (?:extensively |widely )?documented)\b',
    r'\bbased on (?:the )?available information\b',
    r'\bmaintains a low profile\b',
    r'\bkeeps (?:his|her|their) personal life private\b',
]
_COPULA = [
    r'\b(?:serves|stands|functions|acts) as\b',
    r'\brepresents (?:a|the)\b',
    r'\bmarks (?:a|the)\b',
    r'\bboasts\b',
    r'\bfeatures (?:an?|the|\d+|one|two|three|four|five|six|seven|eight|nine|ten|several|many|numerous|multiple|some)\b',
    r'\boffers a\b',
    r'\brefers to\b',
]
_HEDGE = r'\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems? (?:to|like)|appears? to|somewhat|relatively|fairly|kind of|sort of)\b'
_PLACEHOLDER = [
    (r'\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])', re.I),
    (r'\[(?:name|company|client|place|source|person|organi[sz]ation)\b[^\]\n]*\](?![(\[])', re.I),
    (r'\[(?=[A-Z0-9 _.\-]*[A-Z]{3})[A-Z][A-Z0-9 _.\-]*\](?![(\[])', 0),
    (r'\{\{[^{}\n]*\}\}', 0),
    (r'(?<![A-Za-z])x{3,}(?![A-Za-z])', re.I),
    (r'\blorem ipsum\b', re.I),
]
_CHATMARK = [
    (r'\bcite(?:turn|start|nav)\w*', re.I),
    (r'\boai_citation\w*', re.I),
    (r'\bcontentReference\w*', 0),
    (r'\bnavlist\w*', re.I),
    (r'【\d+†[^】\n]*】', 0),
]
_UTM = [(r'utm_source=(?:chatgpt\.com|chat\.openai\.com|perplexity\.ai|claude\.ai|gemini\.google\.com|copilot\.microsoft\.com|poe\.com)(?![\w\-]|\.[\w\-])', re.I)]
_MARKETING = [P(x) for x in [
    'navigating the complexities', 'staying ahead of the curve',
    'turning challenges into opportunities', 'harnessing the power of',
    'paving the way for', 'saying goodbye to', 'imagining a world where']] + [
    r'unlocking (?:its |their |your |the )?full potential',
    r'a testament to the (?:power|importance) of']
_CURLY = re.compile('[‘’“”]')
_EM = '—'
_YEAR_RANGE = re.compile(r'\b(1[0-9]{3}|2[0-9]{3})-(1[0-9]{3}|2[0-9]{3})\b')
_BOLD = re.compile(r'\*\*[^*\n]+?\*\*')
_BOLD_HEAD = [
    r'^\s*(?:[-*+]\s+|\d+[.)]\s+)?\*\*[^*\n]+?:\*\*',
    r'^\s*(?:[-*+]\s+|\d+[.)]\s+)?\*\*[^*\n]+?\*\*:',
]


def _family_table():
    """(n, key, label, [compiled patterns]) for pattern-only families."""
    t = []

    def add(n, key, label, pats, flags=re.I):
        comp = []
        for p in pats:
            if isinstance(p, tuple):
                comp.append(re.compile(p[0], p[1]))
            else:
                comp.append(re.compile(p, flags))
        t.append((n, key, label, comp))

    add(1, '1_ai_vocabulary', 'AI vocabulary',
        [WB([I(w) for w in _AI_WORDS] + _AI_PHRASES)])
    add(2, '2_model_dialect_vocabulary', 'model-dialect vocabulary',
        [WB([I(w) for w in _MODEL_WORDS] + _MODEL_PHRASES)])
    add(3, '3_promotional_language', 'promotional language', [WB(_PROMO)])
    add(4, '4_hyphenated_word_pairs', 'hyphenated word-pair overuse', [WB(_HYPHEN)])
    add(5, '5_simple_yet', '"simple yet" cliche',
        [r'\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b'])
    add(10, '10_significance_inflation', 'significance inflation', _SIG)
    add(11, '11_notability_name_dropping', 'notability name-dropping', _NOTABILITY, 0)
    add(12, '12_vague_attributions', 'vague attribution', _VAGUE)
    add(13, '13_article_title_proper_noun', 'article title used as a proper noun',
        [r'\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of [^.!?\n]+? is (?:a|an|the)\b'], 0)
    add(14, '14_conservation_padding', 'conservation padding', _CONSERV)
    add(15, '15_false_ranges', 'false range', _FALSE_RANGE)
    add(16, '16_ing_tail_clauses', 'superficial -ing tail clause', _TAIL_ING)
    add(17, '17_negative_parallelism', 'negative parallelism', _NEG_PARALLEL)
    add(17, '17_tailing_negation', 'tailing negation', _TAIL_NEG)
    add(18, '18_not_x_just_y', '"Not X, just Y" construction', _NOT_JUST)
    add(19, '19_filler_phrases', 'filler phrase', _FILLER)
    add(20, '20_empty_pivots', 'empty pivot phrase', _PIVOT)
    add(21, '21_outcome_speculation_tails', 'outcome-speculation tail', _OUTCOME)
    add(22, '22_persuasive_authority_tropes', 'persuasive authority trope', _PERSUASIVE)
    add(23, '23_editorial_interjections', 'editorial interjection', _EDITORIAL)
    add(24, '24_self_thoroughness', 'self-thoroughness phrase', _SELF_THOR)
    add(25, '25_question_answer_pattern', 'question-answer rhetorical pattern', _QA, 0)
    add(26, '26_concrete_evidence_defense', '"concrete evidence" defense phrase', _CONCRETE)
    add(27, '27_compulsive_intro_hooks', 'compulsive intro hook', _HOOKS)
    add(30, '30_diff_anchored_writing', 'diff-anchored writing', _DIFF)
    add(31, '31_signposting', 'signposting or announcement', _SIGNPOST)
    add(32, '32_cataloguing_lead_ins', 'cataloguing lead-in', _CATALOG)
    add(33, '33_inline_header_list', 'inline-header vertical list', _BOLD_HEAD, re.M)
    add(36, '36_formulaic_challenges', 'formulaic challenges section', _CHALLENGE)
    add(38, '38_compulsive_conclusion', 'compulsive conclusion opener', [_CONCLUDE_LINE], re.I | re.M)
    add(39, '39_generic_positive_conclusion', 'generic positive conclusion', _GENERIC_POS)
    add(47, '47_chatbot_artifacts', 'chatbot artifact', _CHATBOT)
    add(48, '48_sycophantic_tone', 'sycophantic tone', _SYCO)
    add(50, '50_knowledge_cutoff_disclaimer', 'knowledge-cutoff disclaimer', _CUTOFF)
    add(51, '51_copula_avoidance', 'copula avoidance', _COPULA)
    add(56, '56_boldface_overuse', 'boldface overuse', [_BOLD.pattern], 0)
    add(63, '63_placeholder_text', 'placeholder text', _PLACEHOLDER)
    add(64, '64_chat_reference_markup', 'chat reference markup', _CHATMARK)
    add(65, '65_ai_tracking_parameter', 'AI tracking parameter', _UTM)
    add(69, '69_marketing_slop', 'stock marketing phrase', _MARKETING)
    return t


_FAMILIES = None


def families():
    global _FAMILIES
    if _FAMILIES is None:
        _FAMILIES = _family_table()
    return _FAMILIES


def _excerpt(text, start, end, pad=40):
    s = max(0, start - pad)
    e = min(len(text), end + pad)
    frag = re.sub(r'\s+', ' ', text[s:e]).strip()
    return ('...' if s > 0 else '') + frag + ('...' if e < len(text) else '')


def view_lines(text):
    """Lines of the scanned prose with code, quotes, tables, badges and front matter blanked."""
    lines = text.split('\n')
    n = len(lines)
    excl = [False] * n
    if n > 1 and lines[0].strip() == '---':
        for j in range(1, n):
            if lines[j].strip() == '---':
                for k in range(j + 1):
                    excl[k] = True
                break
    i = 0
    while i < n:
        if excl[i]:
            i += 1
            continue
        m = FENCE_OPEN.match(lines[i])
        if m and not (m.group(1)[0] == '`' and '`' in m.group(2)):
            fence = m.group(1)
            close = re.compile(r'^ {0,3}' + re.escape(fence[0]) + '{%d,}\\s*$' % len(fence))
            j = i + 1
            while j < n and not close.match(lines[j]):
                j += 1
            end = min(j, n - 1)
            for k in range(i, end + 1):
                excl[k] = True
            i = end + 1
        else:
            i += 1
    i = 0
    while i < n:
        if not excl[i] and BLOCKQUOTE_RE.match(lines[i]):
            j = i
            while j < n and not excl[j] and BLOCKQUOTE_RE.match(lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    excl[k] = True
            i = j
        else:
            i += 1
    for k in range(n):
        ln = lines[k]
        if TABLE_RE.match(ln) or TABLE_SEP_RE.match(ln) or BADGE_RE.match(ln):
            excl[k] = True
    return ['' if excl[k] else INLINE_CODE_RE.sub(' ', lines[k]) for k in range(n)]


def _paragraph_blocks(lines):
    blocks = []
    cur = []
    for ln in lines:
        if not ln.strip():
            if cur:
                blocks.append((False, cur))
                cur = []
            continue
        if HEAD_RE.match(ln):
            if cur:
                blocks.append((False, cur))
                cur = []
            blocks.append((True, [ln]))
            continue
        cur.append(ln)
    if cur:
        blocks.append((False, cur))
    return blocks


def _sentences_of(text):
    out = []
    for line in text.split('\n'):
        s = line.strip()
        if not s or HEAD_RE.match(line):
            continue
        s = re.sub(r'^(?:[-*+]\s+|\d+[.)]\s+|>\s*)', '', s)
        for part in re.split(r'(?<=[.!?])\s+', s):
            part = part.strip()
            if part:
                out.append(part)
    return out


def _first_word(s):
    m = re.match(r'[A-Za-z]+', s)
    return m.group(0).lower() if m else ''


def _cv(vals):
    m = sum(vals) / float(len(vals))
    if m == 0:
        return 0.0
    var = sum((v - m) ** 2 for v in vals) / float(len(vals))
    return math.sqrt(var) / m


def _degenerate(words):
    if len(words) < 30:
        return 0
    grams = [tuple(words[i:i + 6]) for i in range(len(words) - 5)]
    c = Counter(grams)
    rep = sum(1 for g in grams if c[g] > 1)
    if grams and rep / float(len(grams)) >= 0.2:
        return rep
    return 0


def run_families(window, lines):
    """Score every machine-checked family. Returns (findings, counts, words, sentences)."""
    view = '\n'.join(lines)
    findings = {}
    counts = Counter()

    def emit(key, n, label, count, samples):
        if count <= 0:
            return
        findings[key] = {'n': n, 'label': label, 'count': count, 'samples': list(samples)[:3]}
        if not (n in ADVICE_NUMBERS or key in ADVICE_KEYS):
            counts[n] += count

    def matches_of(pats, text):
        ms = []
        for comp in pats:
            ms.extend(comp.finditer(text))
        ms.sort(key=lambda m: m.start())
        return ms

    # Pattern-only families.
    for n, key, label, pats in families():
        ms = matches_of(pats, view)
        emit(key, n, label, len(ms), [_excerpt(view, m.start(), m.end()) for m in ms])

    # Model-dialect vocabulary fires only with two or more hits.
    if findings.get('2_model_dialect_vocabulary', {}).get('count', 0) < 2:
        findings.pop('2_model_dialect_vocabulary', None)
        counts.pop(2, None)

    # Promotional: imperative sentence openers, three or more.
    blocks = _paragraph_blocks(lines)
    para_sents = []
    all_sents = []
    for is_head, pl in blocks:
        if is_head:
            continue
        ss = _sentences_of('\n'.join(pl))
        para_sents.append((pl, ss))
        all_sents.extend(ss)
    imp = [s for s in all_sents if _first_word(s) in IMPERATIVE]
    if len(imp) >= 3:
        pm = findings.get('3_promotional_language', {'count': 0, 'samples': []})
        emit('3_promotional_language', 3, 'promotional language',
             pm['count'] + len(imp), pm['samples'] + [s[:80] for s in imp[:3]])

    # Stacked adjective chains.
    chain_re = re.compile(r'\b[A-Za-z][\w\-]*(?:,\s+[A-Za-z][\w\-]*){3,}\b|\b[A-Za-z][\w\-]*(?:,\s+[A-Za-z][\w\-]*){2},?\s+and\s+[A-Za-z][\w\-]*\b')
    chains = []
    for m in chain_re.finditer(view):
        items = [x for x in re.split(r',\s+|,?\s+and\s+', m.group(0)) if x]
        if len(items) >= 4 and any(ADJ_SUFFIX.search(x.lower()) or x.lower() in STOCK_ADJ for x in items):
            chains.append(m)
    emit('6_stacked_adjectives', 6, 'stacked adjective chain', len(chains),
         [_excerpt(view, m.start(), m.end()) for m in chains])

    # Synonym cycling: three or more distinct members of one cluster.
    syn_count = 0
    syn_samples = []
    for cluster in CLUSTERS:
        occ = []
        present = 0
        for member in cluster:
            ms = list(re.finditer(r'\b' + P(member) + r'(?:s|es)?\b', view, re.I))
            if ms:
                present += 1
                occ.extend(ms)
        if present >= 3:
            syn_count += len(occ)
            syn_samples.extend(_excerpt(view, m.start(), m.end()) for m in occ[:1])
    emit('8_synonym_cycling', 8, 'synonym cycling', syn_count, syn_samples)

    # Transition clusters (37).
    trans_total = 0
    for pl, ss in para_sents:
        k = [s for s in ss if _first_word(s) in TRANS]
        if len(k) >= 2:
            trans_total += len(k)
    for s in all_sents:
        if _first_word(s) in TRANS and re.search(r'\b(?:despite (?:these|its|the) (?:challenges|obstacles)|challenges and|continues to thrive|typical of|faces (?:several|many|numerous) challenges)\b', s, re.I):
            trans_total += 1
    emit('37_transition_clusters', 37, 'transition cluster', trans_total,
         ['sentence opener: ' + s[:60] for s in all_sents if _first_word(s) in TRANS][:3])

    # Opener repetition (42, advice).
    op = 0
    for pl, ss in para_sents:
        if len(ss) >= 3:
            c = Counter(' '.join(WORD_RE.findall(s.lower())[:2]) for s in ss)
            top = max(c.values()) if c else 0
            if top >= 3:
                op += top
    emit('42_opener_repetition', 42, 'opener repetition', op, [])

    # Hedge stacking (54, advice).
    hedge_sents = [s for s in all_sents if len(re.findall(_HEDGE, s)) >= 2]
    emit('54_hedge_stacking', 54, 'stacked hedges', len(hedge_sents), [s[:80] for s in hedge_sents[:3]])

    # Rhythm kinds.
    sent_wc = [len(WORD_RE.findall(s)) for s in all_sents]
    sent_wc = [w for w in sent_wc if w > 0]
    if len(sent_wc) >= 3 and _cv(sent_wc) < 0.35:
        emit('40_sentence_length_monotony', 40, 'sentence-length monotony', len(sent_wc),
             ['%d sentences, mean %.1f words' % (len(sent_wc), sum(sent_wc) / float(len(sent_wc)))])
    if len(sent_wc) >= 6:
        mean_l = sum(sent_wc) / float(len(sent_wc))
        thr = max(3.0, 0.3 * mean_l)
        run = 1
        last = None
        alt = 0
        for i in range(1, len(sent_wc)):
            d = sent_wc[i] - sent_wc[i - 1]
            sub = abs(d) >= thr
            if sub and last is not None and last[0] and ((d > 0) != (last[1] > 0)):
                run += 1
            elif sub:
                run = 2
            else:
                run = 1
            last = (sub, d)
            if run >= 6:
                alt += 1
        emit('41_mechanical_alternation', 41, 'mechanical sentence-length alternation', alt, [])
    para_wc = [len(WORD_RE.findall('\n'.join(pl))) for is_head, pl in blocks if not is_head]
    para_wc = [w for w in para_wc if w > 0]
    if len(para_wc) >= 4 and _cv(para_wc) < 0.4:
        emit('44_uniform_paragraph_length', 44, 'uniform paragraph length', len(para_wc),
             ['%d paragraphs, mean %.1f words' % (len(para_wc), sum(para_wc) / float(len(para_wc)))])

    words = WORD_RE.findall(view)
    nwords = len(words)
    if nwords >= 300 and ';' not in view and view.count('(') <= 1:
        emit('46_semicolon_parenthesis_underuse', 46, 'semicolon and parenthesis underuse', 1, [])

    fp = len(re.findall(r"\b(?:I|me|my|mine|we|our|us)\b", view, re.I))
    if nwords >= 50 and fp / float(nwords) >= 0.03:
        contr = len(re.findall(r"\b\w+(?:n['’]t|['’](?:re|m|ll|ve|d))\b", view, re.I))
        expanded = len(re.findall(r"\b(?:I am|I will|I have|I would|I had|we are|we have|we will|we would|they are|they have|they will|it is|that is|do not|does not|did not|cannot|is not|are not|was not|were not|will not|have not|has not|would not|should not|could not)\b", view, re.I))
        if expanded >= 3 and expanded >= 0.7 * (expanded + contr):
            emit('55_contraction_absence', 55, 'contraction absence', expanded, [])

    # Boldface and inline-header lists are in the table; emoji, dashes, quotes.
    emit('57_emoji', 57, 'emoji', len(EMOJI_RE.findall(view)),
         [_excerpt(view, m.start(), m.end(), 10) for m in list(EMOJI_RE.finditer(view))[:3]])
    em_total = 0
    for pl, ss in para_sents:
        t = '\n'.join(pl)
        if t.count(_EM) >= 2:
            em_total += t.count(_EM)
    emit('58_em_dash_overuse', 58, 'em-dash overuse', em_total, [])
    emit('60_curly_quotes', 60, 'curly quotation marks', len(_CURLY.findall(view)), [])
    yr = []
    for m in _YEAR_RANGE.finditer(view):
        if int(m.group(1)) < int(m.group(2)):
            yr.append(m)
    emit('61_hyphen_en_dash_range', 61, 'hyphen instead of en dash in year range', len(yr),
         [_excerpt(view, m.start(), m.end(), 10) for m in yr[:3]])

    # Title case in headings.
    tc = []
    for is_head, pl in blocks:
        if not is_head:
            continue
        text = pl[0].strip().lstrip('#').strip()
        words_h = text.split()
        if len(words_h) < 3 or not text or not text[0].isalpha() or text.isupper():
            continue
        major = [w.strip('.,:;!?()"\'') for w in words_h]
        major = [w for w in major if w and w.lower() not in SMALL_WORDS]
        if len(major) >= 2 and all(w[0].isupper() for w in major):
            tc.append(text)
    emit('59_title_case_headings', 59, 'title case in heading', len(tc), tc[:3])

    # Inline-header lists (33) are in the table. Mid-essay bullet injection (34).
    has_head = any(is_head for is_head, _ in blocks)
    if not has_head:
        list_p = 0
        prose_p = 0
        for is_head, pl in blocks:
            if all(LIST_RE.match(ln) for ln in pl):
                list_p += 1
            else:
                prose_p += 1
        if list_p >= 1 and prose_p >= 2:
            emit('34_mid_essay_bullets', 34, 'mid-essay bullet injection', list_p, [])

    # Fragmented headers (35).
    frag = []
    for idx, (is_head, pl) in enumerate(blocks):
        if not is_head or idx + 1 >= len(blocks):
            continue
        nh, npl = blocks[idx + 1]
        if nh or not npl:
            continue
        line = npl[0].strip()
        if re.match(r'^(?:[-*+]\s|\d+[.)]\s|\|)', line) or line.startswith('#'):
            continue
        if len(line.split()) > 4:
            continue
        hw = set(re.findall(r'[a-z]{4,}', pl[0].lower()))
        nw = set(re.findall(r'[a-z]{4,}', line.lower()))
        if hw & nw:
            frag.append(line)
    emit('35_fragmented_headers', 35, 'fragmented header', len(frag), frag[:3])

    # Invisible characters, homoglyphs, non-standard spaces, trailing whitespace (window).
    inv = invisible_positions(window) if window else []
    emit('62_invisible_characters', 62, 'invisible or zero-width characters', len(inv),
         ['U+%04X' % ord(window[i]) for i in inv[:3]])
    hg = homoglyph_runs(window) if window else []
    emit('66_homoglyphs', 66, 'mixed-script homoglyphs', len(hg), [m.group(0) for m in hg[:3]])
    ns = space_positions(window) if window else []
    emit('67_nonstandard_spaces', 67, 'non-standard spaces', len(ns),
         ['U+%04X' % ord(window[i]) for i in ns[:3]])
    emit('68_trailing_whitespace', 68, 'trailing or stray whitespace', trailing_count(window) if window else 0, [])

    # Placeholder/markup/tracking are in the table; decorative rules (70).
    hr = sum(1 for ln in lines if HR_RE.match(ln))
    if hr >= 3 and len(window.split('\n')) >= 24:
        emit('70_decorative_rules', 70, 'decorative horizontal rules', hr, [])

    # Degenerate repetition (71).
    deg = _degenerate([w.lower() for w in words])
    emit('71_degenerate_repetition', 71, 'degenerate repetition', deg, [])

    # Excerpts for the chat-markup and tracking families are already emitted by the table.
    return findings, counts, nwords, all_sents
