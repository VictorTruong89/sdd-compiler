#!/usr/bin/env python3
"""prosecheck detector: a local, standard-library-only scanner for AI-writing patterns.

usage: detect.py [--clean] [--ci] [--] [FILE]
"""
import json
import os
import random
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from pc_extract import ExtractError, load_prose  # noqa: E402
from pc_chars import scrub  # noqa: E402
from pc_rules import (run_families, view_lines, WORD_RE, DECISIVE,  # noqa: E402
                      ADVICE_NUMBERS, ADVICE_KEYS)

WINDOW = 262144
USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Scores prose for AI-writing patterns. Reads FILE, or standard input when no
FILE is given. Output is a JSON report on standard output.

  --clean   print the scrubbed text instead of the report
  --ci      add a low/high interval on the score (needs at least 4 sentences)
  --        end option parsing, so FILE may begin with a dash
  -h, --help  print this message

Only the first FILE is scanned when several are given.
"""


def fail(code, message):
    sys.stderr.write(json.dumps({'error': message}, ensure_ascii=False) + '\n')
    sys.exit(code)


def prepare(text):
    text = text.lstrip('﻿')
    return text.replace('\r\n', '\n').replace('\r', '\n')


def band_of(score):
    if score <= 20:
        return 'clean'
    if score <= 40:
        return 'light tells'
    if score <= 60:
        return 'mixed'
    if score <= 80:
        return 'heavy tells'
    return 'pervasive tells'


def confidence_of(words, families):
    if words < 40:
        return 'none', 'fewer than 40 words; too little prose to score'
    if words < 120:
        return 'low', 'fewer than 120 words; the score is a rough guide'
    if words < 300 and families == 1:
        return 'low', 'fewer than 300 words with only one score-moving family'
    if words < 300:
        return 'moderate', 'fewer than 300 words'
    return 'high', ''


SHORT_FAMILY_SET = set(range(1, 40)) | set(range(47, 52)) | {69}


def score_counts(counts, words):
    """Turn per-family hit counts into the 0-100 score, applying the PRD caps and floors."""
    fired = {n: c for n, c in counts.items() if c > 0}
    families = set(fired)
    raw = 0.0
    for n, c in fired.items():
        weight = 14.0 if n in DECISIVE else 10.0
        raw += weight * min(2.0, 1.0 + 0.25 * (c - 1))
    score = min(100.0, raw)
    dec = families & DECISIVE
    conf, _ = confidence_of(words, len(families))
    dec_floor = len(dec) == 1 and conf in ('moderate', 'high')
    if len(families) == 1 and not dec_floor:
        score = min(score, 40.0)
    if families and families <= {40, 44}:
        score = min(score, 20.0 if families == {40} else 40.0)
    floors = []
    if words < 120:
        s1 = families & SHORT_FAMILY_SET
        if len(s1) >= 3:
            floors.append(45)
        elif len(s1) >= 2:
            floors.append(25)
    if words >= 400:
        if len(families) >= 6:
            floors.append(45)
        elif len(families) >= 5:
            floors.append(25)
    if len(dec) >= 2:
        floors.append(65)
    elif dec_floor:
        floors.append(45)
    if floors:
        score = max(score, float(max(floors)))
    return int(round(max(0.0, min(100.0, score))))


def _key_sort(key):
    head = key.split('_', 1)[0]
    return (int(head) if head.isdigit() else 0, key)


def analyze(full, ci=False):
    window = full[:WINDOW]
    truncated = len(full) > WINDOW
    lines = view_lines(window)
    findings, counts, words, sentences = run_families(window, lines)
    score = score_counts(counts, words)
    band = band_of(score)
    conf, reason = confidence_of(words, len(set(counts) & set(n for n, c in counts.items() if c > 0)))
    sm_keys = sorted(k for k, f in findings.items()
                     if not (f['n'] in ADVICE_NUMBERS or k in ADVICE_KEYS))

    report = {}
    for key in sorted(findings, key=_key_sort):
        f = findings[key]
        report[key] = {'label': f['label'], 'count': f['count'], 'samples': f['samples']}

    from pc_chars import invisible_positions, space_positions, homoglyph_runs
    inv = len(invisible_positions(window)) if window else 0
    ns = len(space_positions(window)) if window else 0
    hg = len(homoglyph_runs(window)) if window else 0

    if ci:
        if len(sentences) < 4:
            ci_val = None
            note = 'too few sentences (%d); an interval needs at least 4' % len(sentences)
        else:
            ci_val, note = interval(sentences)
    else:
        ci_val = None
        note = None

    metrics = {
        'scanned_chars': len(window),
        'truncated': truncated,
        'ai_tell_score': score,
        'ai_tell_band': band,
        'confidence': conf,
        'confidence_reason': reason,
        'patterns_flagged': len(findings),
        'invisible_chars': inv,
        'nonstandard_spaces': ns,
        'homoglyphs': hg,
        'words': words,
        'score_moving_keys': sm_keys,
    }
    if ci:
        metrics['score_ci'] = ci_val
        metrics['score_ci_note'] = note or ''
    report['_metrics'] = metrics
    return report


def interval(sentences, resamples=20):
    """Bootstrap over sentences with a fixed seed; 10th to 90th percentile of the score."""
    rng = random.Random(0)
    n = len(sentences)
    scores = []
    for _ in range(resamples):
        pick = [sentences[rng.randrange(n)] for _ in range(n)]
        view = view_lines('\n'.join(pick))
        _, counts, words, _ = run_families('', view)
        scores.append(score_counts(counts, words))
    scores.sort()
    lo = scores[int(round(0.1 * (len(scores) - 1)))]
    hi = scores[int(round(0.9 * (len(scores) - 1)))]
    if lo > hi:
        lo, hi = hi, lo
    return [lo, hi], 'bootstrap over sentences: %d resamples, seed 0; 10th to 90th percentile' % resamples


def main(argv):
    clean = False
    ci = False
    operands = []
    end = False
    for arg in argv:
        if end:
            operands.append(arg)
            continue
        if arg == '--':
            end = True
        elif arg in ('-h', '--help'):
            sys.stdout.write(USAGE)
            return 0
        elif arg == '--clean':
            clean = True
        elif arg == '--ci':
            ci = True
        elif arg.startswith('-'):
            fail(2, 'unknown option %s; see --help' % arg)
        else:
            operands.append(arg)

    path = operands[0] if operands else None
    if len(operands) > 1:
        sys.stderr.write('notice: only the first file was scanned: %s\n' % operands[0])

    try:
        text = prepare(load_prose(path))
    except ExtractError as e:
        fail(e.code, e.message)
    if not text.strip():
        fail(1, 'empty input')

    if clean:
        sys.stdout.buffer.write(scrub(text).encode('utf-8'))
        return 0

    report = analyze(text, ci=ci)
    out = json.dumps(report, ensure_ascii=False, indent=2) + '\n'
    sys.stdout.buffer.write(out.encode('utf-8'))
    return 0


if __name__ == '__main__':
    sys.exit(main(sys.argv[1:]))
