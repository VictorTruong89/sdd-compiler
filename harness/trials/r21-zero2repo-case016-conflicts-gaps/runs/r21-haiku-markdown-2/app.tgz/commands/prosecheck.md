---
description: prosecheck: levels, check, doctor, show, stats, init, help
argument-hint: [lite|full|strict|off|on|status|show|check PATH|doctor|stats|init|help]
---
/prosecheck $ARGUMENTS
