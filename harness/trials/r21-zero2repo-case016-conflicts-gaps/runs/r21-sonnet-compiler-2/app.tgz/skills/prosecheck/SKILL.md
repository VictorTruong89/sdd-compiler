---
name: prosecheck
description: Rewrite flagged prose so it reads naturally; run when asked to "prosecheck this" or "humanize this".
---

Run `python3 scripts/detect.py <file>` from the plugin root, then rewrite the flagged spans.
Keep numbers, names, quotes, and meaning. Prose only; never code. A score describes writing, not an author.
