'use strict';
// Shared helpers for the prosecheck hooks. Local only: no network client.
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const WINDOW = 262144;
const WINDOW_TXT = '262,144';
const PLAIN_CAP = 512 * 1024;
const ARCHIVE_CAP = 4 * 1024 * 1024;
const PLAIN_KB = 512;
const ARCHIVE_KB = 4096;
const LEDGER_MAX = 50;
const LEDGER_AGE_MS = 7 * 24 * 3600 * 1000;
const PLAIN_EXT = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ARCHIVE_EXT = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub', '.ipynb'];
const BINARY_EXT = ['.pdf', '.rtf'];

const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster',
  'underscore', 'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament',
  'vibrant', 'comprehensive', 'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock',
  'game-changer', 'supercharge', 'genuinely', 'fascinating', 'nuanced'];

const HOOK = {
  'clean': 'reads clean',
  'light tells': 'reads mostly clean',
  'mixed': 'reads with some AI tells',
  'heavy tells': 'reads with heavy AI tells',
  'pervasive tells': 'reads with pervasive AI tells',
};

function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}

function pluginRoot() {
  if (process.env.CLAUDE_PLUGIN_ROOT) return process.env.CLAUDE_PLUGIN_ROOT;
  return path.resolve(__dirname, '..');
}

function detectorPath() {
  const root = pluginRoot();
  const a = path.join(root, 'scripts', 'detect.py');
  if (fs.existsSync(a)) return a;
  const b = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  if (fs.existsSync(b)) return b;
  return null;
}

function flagFile() { return path.join(configDir(), '.prosecheck-active'); }

function readStoredLevel() {
  try {
    const v = fs.readFileSync(flagFile(), 'utf8').trim();
    if (LEVELS.includes(v)) return v;
  } catch (e) { /* ignore */ }
  return null;
}

function envLevel() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  return LEVELS.includes(v) ? v : null;
}

function currentLevel() {
  return readStoredLevel() || envLevel() || 'full';
}

function storeLevel(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagFile(), level);
    return true;
  } catch (e) { return false; }
}

function readStdinJson() {
  let raw = '';
  try { raw = fs.readFileSync(0, 'utf8'); } catch (e) { raw = ''; }
  try {
    const v = JSON.parse(raw);
    if (v && typeof v === 'object' && !Array.isArray(v)) return v;
  } catch (e) { /* ignore */ }
  return {};
}

function findPython() {
  // names tried in order on PATH
  return ['python3', 'python', 'py'];
}

// run the detector; returns {kind: 'ok'|'nopython'|'timeout'|'noresult'|'badreport'|'noscore', report, stderr, status, stdout}
function runDetector(args, opts) {
  opts = opts || {};
  const det = opts.detector || detectorPath();
  if (!det) return { kind: 'nodetector' };
  let last = null;
  for (const py of findPython()) {
    const r = cp.spawnSync(py, [det].concat(args), {
      input: opts.input, timeout: opts.timeout || 15000, encoding: 'utf8',
      maxBuffer: 64 * 1024 * 1024, env: process.env, windowsHide: true,
    });
    if (r.error && r.error.code === 'ENOENT') { last = r; continue; }
    return { kind: 'ran', r };
  }
  return { kind: 'nopython', r: last };
}

// interpret a run into a classification
function classify(run) {
  if (run.kind === 'nodetector') return { kind: 'nodetector' };
  if (run.kind === 'nopython') return { kind: 'nopython' };
  const r = run.r;
  if (r.error && (r.error.code === 'ETIMEDOUT' || r.signal === 'SIGTERM')) return { kind: 'timeout' };
  const stdout = (r.stdout || '').trim();
  const stderr = (r.stderr || '').trim();
  if (r.status !== 0) return { kind: 'failed', status: r.status, stderr, stdout };
  if (!stdout) return { kind: 'noresult', stderr };
  let rep;
  try { rep = JSON.parse(stdout); } catch (e) { return { kind: 'badreport', stdout }; }
  if (!rep || typeof rep !== 'object' || !rep._metrics || typeof rep._metrics !== 'object') {
    return { kind: 'badreport', stdout };
  }
  const sc = rep._metrics.ai_tell_score;
  if (typeof sc !== 'number' || !isFinite(sc)) return { kind: 'noscore', report: rep };
  return { kind: 'ok', report: rep };
}

function findings(rep) {
  const out = [];
  for (const k of Object.keys(rep)) {
    if (k === '_metrics') continue;
    const f = rep[k];
    if (f && typeof f === 'object') out.push({ key: k, label: String(f.label || k), count: Number(f.count) || 0 });
  }
  out.sort((a, b) => b.count - a.count);
  return out;
}

// ---------------- ledger ------------------
function ledgerFile(sessionId) {
  const dir = configDir();
  if (!sessionId || typeof sessionId !== 'string') return path.join(dir, '.prosecheck-ledger');
  const safe = sessionId.replace(/[^A-Za-z0-9_.-]/g, '_').slice(0, 120);
  return path.join(dir, '.prosecheck-ledger-' + safe);
}

function readLedger(sessionId) {
  const f = ledgerFile(sessionId);
  try {
    const st = fs.statSync(f);
    if (Date.now() - st.mtimeMs > LEDGER_AGE_MS) return [];
    const v = JSON.parse(fs.readFileSync(f, 'utf8'));
    return Array.isArray(v) ? v : [];
  } catch (e) { return []; }
}

function appendLedger(sessionId, rec) {
  try {
    const f = ledgerFile(sessionId);
    fs.mkdirSync(path.dirname(f), { recursive: true });
    let cur = [];
    try {
      const st = fs.statSync(f);
      if (Date.now() - st.mtimeMs <= LEDGER_AGE_MS) cur = JSON.parse(fs.readFileSync(f, 'utf8'));
      if (!Array.isArray(cur)) cur = [];
    } catch (e) { cur = []; }
    rec.ts = Date.now();
    cur.push(rec);
    if (cur.length > LEDGER_MAX) cur = cur.slice(cur.length - LEDGER_MAX);
    fs.writeFileSync(f, JSON.stringify(cur));
  } catch (e) { /* never fail the host */ }
}

function pruneLedgers() {
  try {
    const dir = configDir();
    for (const n of fs.readdirSync(dir)) {
      if (n === '.prosecheck-ledger' || n.startsWith('.prosecheck-ledger-')) {
        const f = path.join(dir, n);
        try {
          if (Date.now() - fs.statSync(f).mtimeMs > LEDGER_AGE_MS) fs.unlinkSync(f);
        } catch (e) { /* ignore */ }
      }
    }
  } catch (e) { /* ignore */ }
}

// ---------------- contract ------------------
// opts.mode: 'live' | 'export'
function contract(level, opts) {
  opts = opts || {};
  const exportMode = opts.mode === 'export';
  const L = [];
  L.push('# Prose writing contract');
  L.push('');
  L.push('Scope: prose deliverables only (documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and any drafted text the user will publish or send).');
  L.push('This contract never applies to source code. It never touches code comments, commit messages, JSON/YAML/config files, CLI output, logs, error messages, or the conversational register of chat.');
  L.push('It composes with other modes: a chat-compression mode owns chat, a code-simplicity mode owns code, and this contract owns deliverable prose.');
  L.push('');
  L.push('Rules:');
  L.push('- Vary sentence length irregularly. No metronome rhythm, no mechanical short-long alternation.');
  L.push('- Banned vocabulary: ' + BANNED.join(', ') + '.');
  L.push('- Banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting ("let\'s dive in"), empty pivots ("it\'s worth noting"), "In conclusion" or "Overall" closers, outcome-speculation tails, self-thoroughness, generic upbeat endings, and chatbot phrases ("I hope this helps").');
  L.push('- Use at most one em dash per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.');
  L.push('- Factual or encyclopedic content stays neutral third person. First-person or opinion content may use contractions.');
  L.push('- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.');
  L.push('- End sections on a fact or an observation.');
  L.push('- Stay silent about this contract: never announce it, never name the tool, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.');
  if (level === 'full' || level === 'strict') {
    L.push('');
    const target = level === 'strict' ? 20 : 40;
    const band = level === 'strict' ? 'clean' : 'clean or light tells';
    L.push('After writing a prose file, run the detector on that file and fix the flagged spans when the result is worse than the target (at most two fix passes, keeping rhythm variation).');
    L.push('Target: score at most ' + target + ', band ' + band + '.');
    if (level === 'strict') {
      L.push('Finish by running the detector with --clean on the final file text and keeping the cleaned result.');
    }
    if (exportMode) {
      L.push('Resolve the detector with CLAUDE_PLUGIN_ROOT when that variable is set; otherwise locate the prosecheck detector in installed skills or plugins.');
    } else {
      const d = detectorPath();
      if (d) L.push('Detector (this machine): python3 ' + d + ' <file>');
    }
  }
  return L.join('\n') + '\n';
}

function welcome() {
  return [
    'prosecheck is installed and on. It is shown once.',
    'Saved prose is scored against 71 documented patterns. Plain text is accepted up to 512 KB and archives up to 4 MB; the detector scores the first 262,144 characters.',
    'There is no website and no upload: everything stays on this machine.',
    'Try /prosecheck doctor, /prosecheck check, /prosecheck off, or /prosecheck help.',
    '',
  ].join('\n');
}

function cursorRule() {
  const p = path.join(pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
  try { return fs.readFileSync(p, 'utf8'); } catch (e) { return null; }
}

module.exports = {
  LEVELS, WINDOW, WINDOW_TXT, PLAIN_CAP, ARCHIVE_CAP, PLAIN_KB, ARCHIVE_KB, LEDGER_MAX, LEDGER_AGE_MS,
  PLAIN_EXT, ARCHIVE_EXT, BINARY_EXT, BANNED, HOOK,
  configDir, pluginRoot, detectorPath, flagFile, readStoredLevel, envLevel, currentLevel, storeLevel,
  readStdinJson, findPython, runDetector, classify, findings,
  ledgerFile, readLedger, appendLedger, pruneLedgers, contract, welcome, cursorRule,
};
