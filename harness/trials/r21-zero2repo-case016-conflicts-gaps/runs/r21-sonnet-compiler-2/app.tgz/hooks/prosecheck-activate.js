#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract in the session.
const fs = require('fs');
const lib = require('./prosecheck-lib');

function main() {
  const first = !fs.existsSync(lib.flagFile());
  lib.readStdinJson();
  lib.pruneLedgers();
  const level = lib.currentLevel();
  if (level === 'off') return;
  if (first) lib.storeLevel(level);
  let out = '';
  if (first) out += lib.welcome() + '\n';
  out += lib.contract(level, { mode: 'live' });
  process.stdout.write(out);
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
