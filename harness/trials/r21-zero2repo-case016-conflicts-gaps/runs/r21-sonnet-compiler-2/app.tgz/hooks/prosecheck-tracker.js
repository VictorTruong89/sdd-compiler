#!/usr/bin/env node
'use strict';
// Prompt-submit hook: /prosecheck command router and the per-prompt reminder.
const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib');

const SUBS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];
const SHOW_MAX = 20;
const SHOW_LABELS = 5;
const CHECK_LABELS = 8;
const MARKER = '<!-- prosecheck:prose-contract -->';
const MARKER_END = '<!-- /prosecheck:prose-contract -->';

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }));
}

function stripPathArg(s) {
  s = (s || '').trim();
  if (s.startsWith('@')) s = s.slice(1).trim();
  const q = s[0];
  if ((q === '"' || q === "'")) {
    if (s.length >= 2 && s.endsWith(q)) s = s.slice(1, -1);
    else s = s.slice(1);
  }
  return s;
}

function helpReply(level) {
  return [
    'prosecheck help (level: ' + level + ')',
    'Code, commits, config, and chat are never touched; prose deliverables only.',
    '/prosecheck lite - writing contract only, no scoring of saved files',
    '/prosecheck full - contract plus saved-file guard, threshold 40 (default)',
    '/prosecheck strict - stricter guard, threshold 20, plus a scrub (cleanup) finish',
    '/prosecheck off | on - disable / re-enable the tool',
    '/prosecheck status - show the current level',
    '/prosecheck show - list files scored in this session',
    '/prosecheck check <file> - score one file (report only, never rewrite)',
    '/prosecheck doctor - health check of the install',
    '/prosecheck stats - token figures and the score of the session prose',
    '/prosecheck init - export the contract to ./AGENTS.md for other agents',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function checkReply(argRaw, cwd) {
  const arg = stripPathArg(argRaw);
  if (!arg) {
    return 'Give a file to check, for example: /prosecheck check notes.md. It scores the file and never rewrites it.';
  }
  const full = path.isAbsolute(arg) ? arg : path.resolve(cwd, arg);
  const base = path.basename(full);
  let st;
  try { st = fs.statSync(full); } catch (e) {
    return 'cannot read ' + arg + ': no such file on disk.';
  }
  if (!st.isFile()) return arg + ' is not a file.';
  const ext = path.extname(full).toLowerCase();
  if (lib.BINARY_EXT.includes(ext)) return base + ' has no readable text for the detector (' + ext.slice(1) + ' is not read).';
  const archive = lib.ARCHIVE_EXT.includes(ext);
  const cap = archive ? lib.ARCHIVE_CAP : lib.PLAIN_CAP;
  if (st.size > cap) {
    return base + ' is over ' + (archive ? lib.ARCHIVE_KB : lib.PLAIN_KB) + ' KB, so it was not scored.';
  }
  const run = lib.runDetector(['--', full], { timeout: archive ? 15000 : 8000 });
  const c = lib.classify(run);
  switch (c.kind) {
    case 'nopython':
    case 'nodetector':
      return 'detector unavailable: Python or the bundled detector could not be run, so no score is given.';
    case 'timeout': return base + ': the detector failed (timed out).';
    case 'failed': return base + ': the detector failed' + (c.stderr ? ': ' + c.stderr : '.');
    case 'noresult': return base + ': the detector gave no report.';
    case 'badreport':
    case 'noscore': return 'The detector gave no report (its output was not a report).';
    default: break;
  }
  const m = c.report._metrics;
  const score = Math.round(m.ai_tell_score);
  const phrase = lib.HOOK[m.ai_tell_band] || 'reads with some AI tells';
  const lines = [];
  lines.push(base + ' - ' + phrase + ' (score ' + score + '/100, band: ' + m.ai_tell_band + ')');
  let conf = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && m.confidence_reason) conf += ' - ' + m.confidence_reason;
  lines.push(conf);
  if (m.truncated === true) lines.push('coverage: first ' + lib.WINDOW_TXT + ' characters only');
  const f = lib.findings(c.report).slice(0, CHECK_LABELS);
  lines.push('tells: ' + (f.length ? f.map((x) => x.label + ' (x' + x.count + ')').join('; ') : 'none'));
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

function doctorReply(form, level) {
  const lines = ['prosecheck doctor'];
  let allOk = true;
  const modeOk = level !== 'off';
  lines.push(modeOk ? '[OK] mode: ' + level
    : '[off] mode: off - the tool is switched off; run /prosecheck on to turn it back on');
  const det = lib.detectorPath();
  const detOk = !!det;
  lines.push(detOk ? '[OK] detector: bundled detector present' : '[!!] detector: bundled detector is missing');
  if (!detOk) allOk = false;
  let pyLine;
  if (!detOk) {
    pyLine = '[!!] python: cannot run the bundled scorer because it is missing';
    allOk = false;
  } else {
    const c = lib.classify(lib.runDetector([], { input: 'This is a short sentence for the health check. It has a few plain words in it.', timeout: 15000 }));
    if (c.kind === 'ok') pyLine = '[OK] python: ran the bundled scorer and got a numeric score';
    else if (c.kind === 'nopython') {
      pyLine = '[!!] python not found - prose is still shaped by the writing contract, but saved files are not re-scored until Python is available';
      allOk = false;
    } else {
      pyLine = '[!!] python: ran, but the result was not a numeric score';
      allOk = false;
    }
  }
  lines.push(pyLine);
  let writable = false;
  try {
    fs.mkdirSync(lib.configDir(), { recursive: true });
    fs.accessSync(lib.configDir(), fs.constants.W_OK);
    writable = true;
  } catch (e) { writable = false; }
  lines.push(writable ? '[OK] settings: folder is writable' : '[!!] settings: folder is not writable');
  if (!writable) allOk = false;
  if (!allOk) {
    lines.push('Please fix the faulty checks, then run /prosecheck doctor again.');
  } else if (!modeOk) {
    lines.push('The install is healthy. In this mode saving files triggers no scoring; nothing is scored until you run ' + form + ' on.');
  } else {
    lines.push('prosecheck is active. Plain text up to ' + lib.PLAIN_KB + ' KB and archives up to 4 MB are scored, reading the first ' + lib.WINDOW_TXT
      + ' characters. Run ' + form + ' show to see files that were only partly scanned or skipped.');
  }
  return lines.join('\n');
}

function showReply(session) {
  const rows = lib.readLedger(session).slice().reverse().slice(0, SHOW_MAX);
  if (!rows.length) {
    return 'nothing scored yet in this session. Rows appear after prose files (including .docx and .pdf deliverables) are saved.';
  }
  const out = ['Session ledger, newest first:'];
  for (const r of rows) {
    const base = String(r.name || '');
    let body;
    if (r.kind === 'scored') {
      const phrase = lib.HOOK[r.band] || 'reads with some AI tells';
      body = phrase + ' (score ' + r.score + '/' + r.band + (r.truncated ? ', first ' + lib.WINDOW_TXT + ' characters only' : '') + ')';
      const labels = Array.isArray(r.labels) ? r.labels.slice(0, SHOW_LABELS) : [];
      if (labels.length) {
        body += ' - ' + (r.flagged ? 'flagged' : 'under the threshold') + ': ' + labels.join('; ');
      }
    } else if (r.kind === 'skipped') {
      body = 'not scored: larger than the ' + r.limitKB + ' KB limit';
    } else if (r.kind === 'binary') {
      body = 'binary file, not re-scored';
    } else {
      body = 'not scored: ' + String(r.reason || 'the check failed').replace(/\d+\s*KB/gi, 'size');
    }
    out.push('  ' + base + ' - ' + body);
  }
  return out.join('\n');
}

function initReply(form) {
  const level = lib.currentLevel();
  if (level === 'off') {
    return 'prosecheck is switched off, so init wrote no files. Run ' + form + ' on to allow the export.';
  }
  const cwd = process.cwd();
  const lines = [];
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = '';
  let readOk = true;
  try { existing = fs.readFileSync(agents, 'utf8'); } catch (e) {
    if (e.code !== 'ENOENT') readOk = false;
  }
  if (!readOk) {
    lines.push('cannot read AGENTS.md, so cannot write the contract there.');
  } else if (existing.includes('prosecheck:prose-contract') || existing.includes('# Prose writing contract')) {
    lines.push('The contract is already present in AGENTS.md; the file was not changed.');
  } else {
    const section = MARKER + '\n' + lib.contract(level, { mode: 'export' }) + MARKER_END + '\n';
    let sep = '';
    if (existing.length) sep = existing.endsWith('\n\n') ? '' : (existing.endsWith('\n') ? '\n' : '\n\n');
    try {
      fs.appendFileSync(agents, sep + section);
      lines.push('Wrote the writing contract to AGENTS.md.');
    } catch (e) {
      lines.push('cannot write AGENTS.md.');
    }
  }
  const dest = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(dest)) {
    lines.push('The Cursor rule is already there (.cursor/rules/prosecheck.mdc); it was not overwritten.');
  } else {
    const rule = lib.cursorRule();
    if (rule === null) {
      lines.push('cannot write .cursor/rules/prosecheck.mdc: the shipped rule was not found.');
    } else {
      try {
        fs.mkdirSync(path.dirname(dest), { recursive: true });
        fs.writeFileSync(dest, rule);
        lines.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
      } catch (e) {
        lines.push('cannot write .cursor/rules/prosecheck.mdc.');
      }
    }
  }
  return lines.join('\n');
}

function handle(input) {
  const raw = typeof input.prompt === 'string' ? input.prompt : '';
  const prompt = raw.trim();
  const lower = prompt.toLowerCase();
  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    lib.storeLevel('off');
    return block('prosecheck is now off. Use /prosecheck on to re-enable it.');
  }
  const m = /^(\/prosecheck(?::prosecheck)?)(?:\s+([\s\S]*))?$/.exec(prompt);
  if (!m) {
    const level = lib.currentLevel();
    if (level === 'off') return;
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: {
        hookEventName: 'UserPromptSubmit',
        additionalContext: 'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.',
      },
    }));
    return;
  }
  const form = m[1];
  const rest = (m[2] || '').trim();
  const sp = /^(\S+)(?:\s+([\s\S]*))?$/.exec(rest);
  const word = sp ? sp[1] : '';
  const arg = sp && sp[2] ? sp[2] : '';
  const sub = word.toLowerCase();
  const level = lib.currentLevel();
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  if (!word || sub === 'help') return block(helpReply(level));
  switch (sub) {
    case 'lite': case 'full': case 'strict': case 'off':
      lib.storeLevel(sub);
      return block(sub === 'off' ? 'prosecheck is off. Use /prosecheck on to re-enable it.' : 'prosecheck level set to ' + sub + '.');
    case 'on':
      lib.storeLevel('full');
      return block('prosecheck is on (full).');
    case 'status':
      return block('prosecheck level: ' + level);
    case 'show':
      return block(showReply(typeof input.session_id === 'string' ? input.session_id : ''));
    case 'check':
      return block(checkReply(arg, cwd));
    case 'doctor':
      return block(doctorReply(form, level));
    case 'stats':
      return block(require('./prosecheck-stats').stats(input.transcript_path));
    case 'init':
      return block(initReply(form));
    default:
      return block('unknown subcommand: ' + word + '. Valid subcommands: ' + SUBS.join(', ') + '.');
  }
}

try { handle(lib.readStdinJson()); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
