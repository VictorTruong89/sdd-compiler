#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when flagged.
const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib');

const MAX_PATCH_PATHS = 10;
const LABEL_CAP = 5;
const INSTR_NAMES = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
const INSTR_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];

function patchPaths(cmd) {
  const out = [];
  if (typeof cmd !== 'string') return out;
  for (const line of cmd.split(/\r?\n/)) {
    const m = /^\*\*\* (Add File|Update File|Move to):(.*)$/.exec(line);
    if (m) {
      const p = m[2].trim();
      if (p && !out.includes(p)) out.push(p);
    }
  }
  return out;
}

function isInstructionFile(base) {
  const lower = base.toLowerCase();
  if (INSTR_NAMES.includes(lower)) return true;
  const ext = path.extname(lower);
  const stem = ext ? lower.slice(0, -ext.length) : lower;
  if (INSTR_STEMS.includes(stem) && !lib.PLAIN_EXT.concat(lib.ARCHIVE_EXT).includes(ext)) return true;
  return false;
}

function skipped(full) {
  const parts = full.split(/[\\/]+/);
  if (parts.includes('node_modules') || parts.includes('.git')) return true;
  const root = path.resolve(lib.pluginRoot());
  const rel = path.relative(root, path.resolve(full));
  if (rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel))) return true;
  if (isInstructionFile(path.basename(full))) return true;
  return false;
}

function scoreFile(full, level, session) {
  const base = path.basename(full);
  const ext = path.extname(full).toLowerCase();
  const isArchive = lib.ARCHIVE_EXT.includes(ext);
  const isPlain = lib.PLAIN_EXT.includes(ext);
  const isBinary = lib.BINARY_EXT.includes(ext);
  if (!isArchive && !isPlain && !isBinary) return null;
  if (skipped(full)) return null;
  let st;
  try { st = fs.statSync(full); } catch (e) {
    lib.appendLedger(session, { name: base, kind: 'failed', reason: 'file unreadable (not found on disk)' });
    return null;
  }
  if (!st.isFile()) return null;
  if (isBinary) {
    lib.appendLedger(session, { name: base, kind: 'binary' });
    return null;
  }
  const cap = isArchive ? lib.ARCHIVE_CAP : lib.PLAIN_CAP;
  if (st.size > cap) {
    lib.appendLedger(session, { name: base, kind: 'skipped', limitKB: isArchive ? lib.ARCHIVE_KB : lib.PLAIN_KB });
    return null;
  }
  const run = lib.runDetector(['--', full], { timeout: isArchive ? 15000 : 8000 });
  const c = lib.classify(run);
  const fail = (reason) => { lib.appendLedger(session, { name: base, kind: 'failed', reason }); return null; };
  switch (c.kind) {
    case 'nopython': return fail('Python could not be found');
    case 'nodetector': return fail('the detector is missing');
    case 'timeout': return fail('the detector timed out');
    case 'badreport': return fail('the detector printed text that is not a structured report');
    case 'noscore': return fail('the report has no numeric score');
    case 'noresult': return fail('the detector produced no output or no usable result');
    case 'failed': return fail('the detector produced no output or no usable result');
    case 'ok': break;
    default: return fail('the detector produced no output or no usable result');
  }
  const m = c.report._metrics;
  const score = Math.round(m.ai_tell_score);
  const band = String(m.ai_tell_band || '');
  const threshold = level === 'strict' ? 20 : 40;
  const flagged = score > threshold;
  const labels = lib.findings(c.report).map((f) => f.label).slice(0, LABEL_CAP);
  const truncated = m.truncated === true;
  lib.appendLedger(session, { name: base, kind: 'scored', score, band, labels, flagged, truncated });
  if (!flagged) return null;
  const phrase = lib.HOOK[band] || 'reads with some AI tells';
  const cov = truncated ? ', first ' + lib.WINDOW_TXT + ' characters only' : '';
  return 'prosecheck: ' + base + ' ' + phrase + ' (score ' + score + ', band ' + band + cov + '). Flagged: '
    + labels.join('; ') + '. Please fix the flagged spans.';
}

function main() {
  const input = lib.readStdinJson();
  const level = lib.currentLevel();
  if (level === 'off' || level === 'lite') return;
  const tool = input.tool_name;
  const ti = (input.tool_input && typeof input.tool_input === 'object') ? input.tool_input : {};
  const session = typeof input.session_id === 'string' ? input.session_id : '';
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  let paths = [];
  if (tool === 'Write' || tool === 'Edit' || tool === 'MultiEdit') {
    if (typeof ti.file_path === 'string') paths = [ti.file_path];
  } else if (tool === 'NotebookEdit') {
    const p = typeof ti.notebook_path === 'string' ? ti.notebook_path : ti.file_path;
    if (typeof p === 'string') paths = [p];
  } else if (tool === 'apply_patch') {
    let body = ti.command;
    if (Array.isArray(body)) body = body.join('\n');
    if (typeof body !== 'string') body = typeof ti.patch === 'string' ? ti.patch : ti.input;
    paths = patchPaths(body).slice(0, MAX_PATCH_PATHS);
  } else {
    return;
  }
  paths = paths.map((p) => p.trim()).filter((p) => p);
  const lines = [];
  for (const p of paths) {
    const full = path.isAbsolute(p) ? p : path.resolve(cwd, p);
    try {
      const line = scoreFile(full, level, session);
      if (line) lines.push(line);
    } catch (e) { /* ignore */ }
  }
  if (lines.length) {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
    }));
  }
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
