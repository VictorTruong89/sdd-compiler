#!/usr/bin/env node
'use strict';
// Subagent-start hook: the same contract inside the SubagentStart envelope.
const lib = require('./prosecheck-lib');

function main() {
  lib.readStdinJson();
  const level = lib.currentLevel();
  if (level === 'off') return;
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: lib.contract(level, { mode: 'live' }),
    },
  }));
}

try { main(); } catch (e) { /* never fail the host */ }
process.exitCode = 0;
