#!/usr/bin/env node
'use strict';
// stats: session token use and own-prose score from a transcript.
const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib');

function newestTranscript() {
  const dir = path.join(lib.configDir(), 'projects');
  let best = null;
  function walk(d, depth) {
    let ents;
    try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    for (const e of ents) {
      const f = path.join(d, e.name);
      if (e.isDirectory()) { if (depth < 4) walk(f, depth + 1); }
      else if (e.name.endsWith('.jsonl')) {
        try {
          const m = fs.statSync(f).mtimeMs;
          if (!best || m > best.m) best = { f, m };
        } catch (err) { /* ignore */ }
      }
    }
  }
  walk(dir, 0);
  return best && best.f;
}

function fmt(n) { return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }

function stats(transcriptPath) {
  const level = lib.currentLevel();
  let file = transcriptPath && typeof transcriptPath === 'string' ? transcriptPath : null;
  if (!file) file = newestTranscript();
  let raw = null;
  if (file) { try { raw = fs.readFileSync(file, 'utf8'); } catch (e) { raw = null; } }
  if (raw === null) {
    return 'No readable session transcript was found, so there are no token figures to show.\nlevel: ' + level;
  }
  const byId = new Map();
  let anon = 0;
  for (const line of raw.split(/\r?\n/)) {
    if (!line.trim()) continue;
    let row;
    try { row = JSON.parse(line); } catch (e) { continue; }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const id = typeof msg.id === 'string' && msg.id ? msg.id : '__anon' + (anon++);
    const u = msg.usage || {};
    let text = '';
    if (typeof msg.content === 'string') text = msg.content;
    else if (Array.isArray(msg.content)) {
      text = msg.content.filter((c) => c && c.type === 'text' && typeof c.text === 'string').map((c) => c.text).join('\n');
    }
    const prev = byId.get(id);
    byId.set(id, {
      out: Number(u.output_tokens) || (prev ? prev.out : 0) || 0,
      cache: Number(u.cache_read_input_tokens) || (prev ? prev.cache : 0) || 0,
      text: text || (prev ? prev.text : ''),
    });
  }
  let turns = 0, out = 0, cache = 0;
  const texts = [];
  for (const v of byId.values()) { turns++; out += v.out; cache += v.cache; if (v.text) texts.push(v.text); }
  const lines = [
    'prosecheck stats',
    'level: ' + level,
    'assistant turns: ' + fmt(turns),
    'output tokens: ' + fmt(out),
    'cache-read input tokens: ' + fmt(cache),
  ];
  let slice = texts.join('\n\n').replace(/```[\s\S]*?(```|$)/g, '');
  if (slice.length > 40000) slice = slice.slice(slice.length - 40000);
  if (slice.trim().length > 500) {
    const run = lib.runDetector([], { input: slice.trim(), timeout: 15000 });
    const c = lib.classify(run);
    if (c.kind === 'ok') lines.push('session prose ai_tell_score: ' + Math.round(c.report._metrics.ai_tell_score));
  }
  return lines.join('\n');
}

module.exports = { stats };

if (require.main === module) {
  try {
    const input = lib.readStdinJson();
    process.stdout.write(stats(input.transcript_path) + '\n');
  } catch (e) { /* never fail */ }
  process.exitCode = 0;
}
