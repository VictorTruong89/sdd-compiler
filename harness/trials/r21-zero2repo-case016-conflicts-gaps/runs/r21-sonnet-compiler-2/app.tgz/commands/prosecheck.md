---
description: prosecheck - writing contract and saved-file guard (lite, full, strict, off, on, status, show, check, doctor, stats, init, help)
argument-hint: "[subcommand] [argument]"
---
/prosecheck $ARGUMENTS
