"""Character layer: detection and cleanup share one scrub routine so they agree."""
import re
import unicodedata

# spec: N-000303 N-000307 cleanup agrees with detection

LOOK = {}


def _add(script_chars, ascii_chars):
    for a, b in zip(script_chars, ascii_chars):
        LOOK[a] = b


# Cyrillic lowercase lookalikes
_add("асԁеһіјорѕԛхуԍ", "acdehijopsqxyg")
# Cyrillic uppercase
_add("АВСЕНІЈКМОРЅТХУЗ", "ABCEHIJKMOPSTXYZ")
# Greek
_add("ΑΒΕΖΗΙΚΜΝΟΡΤΥΧ", "ABEZHIKMNOPTYX")
_add("οινυρ", "oivup")
LOOK["ν"] = "v"
# Armenian
_add("օսոցվ", "ounqv")
LOOK["ց"] = "g"
LOOK["ս"] = "u"
LOOK["ո"] = "n"
# Arabic presentation / digits that look like letters (kept small)
LOOK["ه"] = "o"

_RTL_RE = re.compile(
    "[֐-ࣿיִ-﷿ﹰ-﻿\U00010800-\U00010fff]"
)
_INTEREST = re.compile(r"[^\x20-\x7e\n\r\t]")
_TAGSEQ = re.compile("\U0001F3F4[\U000E0020-\U000E007E]+\U000E007F")
_RUN = re.compile(r"[^\W\d_]+")

_EXTRA_INVIS = {0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x3164, 0xFFA0}


def is_invisible(c):
    o = ord(c)
    if o < 0x80:
        return (o < 32 and c not in "\t\n\r") or o == 0x7F
    if o in _EXTRA_INVIS:
        return True
    if 0x180B <= o <= 0x180F or 0xFE00 <= o <= 0xFE0F:
        return True
    if 0xE0000 <= o <= 0xE0FFF:
        return True
    cat = unicodedata.category(c)
    return cat in ("Cf", "Cc")


def _script_nospace(c):
    o = ord(c)
    return (
        0x0E00 <= o <= 0x0EFF  # Thai, Lao
        or 0x1000 <= o <= 0x109F  # Myanmar
        or 0x1780 <= o <= 0x17FF  # Khmer
        or 0x3040 <= o <= 0x30FF  # kana
        or 0x3400 <= o <= 0x4DBF
        or 0x4E00 <= o <= 0x9FFF
        or 0xF900 <= o <= 0xFAFF
        or 0x20000 <= o <= 0x2FFFF
        or 0x3005 <= o <= 0x3007
    )


def _is_cjk(c):
    o = ord(c)
    return (
        0x3400 <= o <= 0x4DBF
        or 0x4E00 <= o <= 0x9FFF
        or 0xF900 <= o <= 0xFAFF
        or 0x20000 <= o <= 0x2FFFF
    )


def _joining_script(c):
    o = ord(c)
    return (
        0x0590 <= o <= 0x06FF
        or 0x0700 <= o <= 0x08FF
        or 0xFB1D <= o <= 0xFDFF
        or 0xFE70 <= o <= 0xFEFF
        or 0x0900 <= o <= 0x0DFF
        or 0x1000 <= o <= 0x109F
        or 0x1780 <= o <= 0x17FF
    )


def _emoji_or_symbol(c):
    o = ord(c)
    if 0x1F000 <= o <= 0x1FAFF or 0x2600 <= o <= 0x27BF or 0x2190 <= o <= 0x23FF:
        return True
    if 0x2B00 <= o <= 0x2BFF or o in (0x00A9, 0x00AE, 0x203C, 0x2049, 0x2122, 0x2139, 0x3030, 0x303D):
        return True
    cat = unicodedata.category(c)
    return cat in ("So", "Sm", "Sc", "Sk")


def _is_mongolian_letter(c):
    o = ord(c)
    return 0x1820 <= o <= 0x18AF or 0x1800 <= o <= 0x180A


def _is_letter(c):
    return c.isalpha()


def _keep_invisible(t, i, c, o, doc_rtl, keep_tags):
    prev = t[i - 1] if i > 0 else ""
    nxt = t[i + 1] if i + 1 < len(t) else ""
    if 0xE0000 <= o <= 0xE0FFF:
        return i in keep_tags
    if 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF:
        if nxt == "⃣":
            return True
        if prev and (_is_cjk(prev) or _emoji_or_symbol(prev) or prev == "⃣"):
            return True
        # keycap base: digit, # or * followed by VS16
        if prev and prev in "0123456789#*" and o == 0xFE0F:
            return True
        return False
    if o == 0x200B:
        return bool((prev and _script_nospace(prev)) or (nxt and _script_nospace(nxt)))
    if o == 0x00AD:
        return bool(prev and nxt and _is_letter(prev) and _is_letter(nxt))
    if o in (0x200E, 0x200F, 0x061C) or 0x202A <= o <= 0x202E or 0x2066 <= o <= 0x2069:
        return doc_rtl
    if 0x180B <= o <= 0x180F:
        return bool(prev and _is_mongolian_letter(prev))
    if o in (0x17B4, 0x17B5):
        return bool(
            (prev and 0x1780 <= ord(prev) <= 0x17FF)
            or (nxt and 0x1780 <= ord(nxt) <= 0x17FF)
        )
    if o in (0x200C, 0x200D):
        for n in (prev, nxt):
            if n and (
                (_joining_script(n) and (n.isalpha() or unicodedata.category(n).startswith("M")))
                or _emoji_or_symbol(n)
            ):
                return True
        return False
    return False


def _nbsp_keep(t, i, o):
    prev = t[i - 1] if i > 0 else ""
    nxt = t[i + 1] if i + 1 < len(t) else ""
    if (prev and prev.isdigit()) or (nxt and nxt.isdigit()):
        return True
    if nxt and nxt in ":;!?»›%€":
        return True
    if prev and prev in "«‹":
        return True
    return False


def _fold_homoglyphs(s):
    """Return (folded text, number of folded runs)."""
    if s.isascii():
        return s, 0
    count = 0
    out = []
    last = 0
    for m in _RUN.finditer(s):
        run = m.group(0)
        if run.isascii():
            continue
        has_ascii = False
        has_look = False
        other = False
        for ch in run:
            if ch.isascii():
                has_ascii = True
            elif ch in LOOK:
                has_look = True
            else:
                other = True
                break
        if has_ascii and has_look and not other:
            out.append(s[last:m.start()])
            out.append("".join(LOOK.get(ch, ch) for ch in run))
            last = m.end()
            count += 1
    out.append(s[last:])
    return "".join(out), count


def scrub_chars(t):
    """Character-layer scrub (no trimming).

    Returns (text, invisible_removed, spaces_normalized, homoglyph_runs)."""
    doc_rtl = bool(_RTL_RE.search(t)) if not t.isascii() else False
    keep_tags = set()
    if "\U0001F3F4" in t:
        for m in _TAGSEQ.finditer(t):
            for k in range(m.start() + 1, m.end()):
                keep_tags.add(k)
    out = []
    last = 0
    inv = sp = 0
    for m in _INTEREST.finditer(t):
        i = m.start()
        c = t[i]
        o = ord(c)
        repl = None
        if is_invisible(c):
            if _keep_invisible(t, i, c, o, doc_rtl, keep_tags):
                continue
            repl = ""
            inv += 1
        elif o in (0x2028, 0x2029):
            repl = "\n"
            sp += 1
        elif unicodedata.category(c) == "Zs":
            if o in (0xA0, 0x202F) and _nbsp_keep(t, i, o):
                continue
            repl = " "
            sp += 1
        else:
            continue
        out.append(t[last:i])
        out.append(repl)
        last = i + 1
    out.append(t[last:])
    s = "".join(out)
    s, hg = _fold_homoglyphs(s)
    return s, inv, sp, hg


_TRAIL = re.compile(r"[ \t]+(?=\r?$)", re.M)
_LEAD_BLANK = re.compile(r"\A(?:[ \t\r\f\v]*\n)+")


def cleanup(t):
    s, _, _, _ = scrub_chars(t)
    s = _TRAIL.sub("", s)
    s = _LEAD_BLANK.sub("", s)
    ended_lf = t.endswith("\n") or s.endswith("\n")
    ended_crlf = t.endswith("\r\n")
    s = s.rstrip(" \t\r\n\f\v")
    if ended_lf:
        s += "\r\n" if ended_crlf else "\n"
    return s
