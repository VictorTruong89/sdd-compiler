#!/usr/bin/env python3
"""prosecheck detector: local, standard-library AI-writing-pattern scan."""
import json
import os
import random
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import charlayer  # noqa: E402
import extract  # noqa: E402
import patterns  # noqa: E402

WINDOW = 262144
USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Scores prose for AI-writing patterns and prints a JSON report.
  --clean   print the cleaned text (invisible characters removed, spaces
            normalized, lookalike letters folded, whitespace trimmed)
  --ci      add a resampled low/high interval on the score
  --        stop option parsing (so FILE may begin with a dash)
  FILE      one file to scan; with no FILE, read standard input
"""

BANDS = [(20, "clean"), (40, "light tells"), (60, "mixed"), (80, "heavy tells"), (100, "pervasive tells")]


def band_of(score):
    for hi, name in BANDS:
        if score <= hi:
            return name
    return "pervasive tells"


def fail(msg, code):
    sys.stderr.write(json.dumps({"error": msg}) + "\n")
    sys.stderr.flush()
    sys.exit(code)


def out_bytes(s):
    sys.stdout.flush()
    sys.stdout.buffer.write(s.encode("utf-8", errors="replace"))
    sys.stdout.buffer.flush()


def confidence_of(nwords, nfam):
    if nwords < 40:
        return "none", "fewer than 40 words; too short to score reliably"
    if nwords < 120:
        return "low", "fewer than 120 words; short documents give a weak signal"
    if nwords < 300 and nfam == 1:
        return "low", "fewer than 300 words and only one pattern family fired"
    if nwords < 300:
        return "moderate", "fewer than 300 words; a longer sample gives a firmer score"
    return "high", ""


def family_points(count):
    return 8.0 + 1.2 * min(max(count - 1, 0), 8)


def compute_score(found, nwords, conf):
    moving = {}
    for key, (num, slug, label, count, smp, advice) in found.items():
        if advice:
            continue
        moving[key] = (num, count)
    nums = set(n for n, _ in moving.values())
    nfam = len(nums)
    total = 0.0
    for key, (num, count) in moving.items():
        total += family_points(count)
    score = int(round(min(total, 100)))
    if nfam == 0:
        return 0, nfam
    only_rhythm = nums <= patterns.RHYTHM
    if only_rhythm:
        score = min(score, 20 if nums == {40} else 40)
    elif nfam == 1:
        score = min(score, 40)
    # floors
    decisive = nums & patterns.DECISIVE
    if nwords < 120:
        early = nums & patterns.EARLY
        if len(early) >= 3:
            score = max(score, 45)
        elif len(early) >= 2:
            score = max(score, 25)
    if nwords >= 400:
        if nfam >= 6:
            score = max(score, 45)
        elif nfam >= 5:
            score = max(score, 25)
    if len(decisive) >= 2:
        score = max(score, 65)
    elif len(decisive) == 1 and conf in ("moderate", "high"):
        score = max(score, 45)
    return max(0, min(100, score)), nfam


def analyze(text, want_ci=False):
    truncated = len(text) > WINDOW
    win = text[:WINDOW].replace("\r\n", "\n")
    scanned = min(len(text), WINDOW)
    prose = patterns.mask(win)
    found = patterns.run_checks(win, prose)

    # character layer on the raw window
    _, inv, sp, hg = charlayer.scrub_chars(win)
    if inv:
        found[62] = (62, "invisible_chars", "Invisible / zero-width characters", inv,
                     ["%d invisible character(s)" % inv], False)
    if sp:
        found[67] = (67, "nonstandard_spaces", "Non-standard spaces", sp,
                     ["%d non-standard space(s)" % sp], False)
    if hg:
        found[66] = (66, "homoglyphs", "Homoglyph / mixed-script confusables", hg,
                     ["%d mixed-script run(s)" % hg], False)
    # 68 trailing whitespace
    tw = len(re.findall(r"[ \t]+(?=\n)", win))
    if win and win[-1] in " \t":
        tw += 1
    m = re.search(r"\n{2,}\Z", win)
    if m:
        tw += 1
    if win and win[0] in " \t\n\r\f\v":
        tw += 1
    if tw:
        found[68] = (68, "trailing_whitespace", "Trailing / stray whitespace", tw,
                     ["stray whitespace"], True)

    nwords = len(patterns.words(prose))
    # words for thresholds use the unmasked-but-readable prose; use window words for confidence
    nwords_conf = len(patterns.words(win))
    nwords = nwords_conf
    # confidence needs the family count first
    prelim_nfam = len({v[0] for v in found.values() if not v[5]})
    conf, reason = confidence_of(nwords, prelim_nfam)
    score, nfam = compute_score(found, nwords, conf)

    metrics = {
        "scanned_chars": scanned,
        "truncated": truncated,
        "ai_tell_score": score,
        "ai_tell_band": band_of(score),
        "confidence": conf,
        "confidence_reason": reason,
        "patterns_flagged": len(found),
        "invisible_chars": inv,
        "nonstandard_spaces": sp,
        "homoglyphs": hg,
        "word_count": nwords,
    }
    if want_ci:
        sents = patterns.sentences_of(prose)
        if len(sents) >= 4:
            rng = random.Random(1234)
            scores = []
            for _ in range(30):
                sample = [rng.choice(sents) for _ in sents]
                sp_ = "\n\n".join(sample) if False else " ".join(sample)
                sprose = sp_
                f2 = patterns.run_checks(sp_, sprose)
                for k in (62, 66, 67, 68):
                    if k in found:
                        f2[k] = found[k]
                nw2 = len(patterns.words(sprose))
                c2, _r = confidence_of(nw2, len({v[0] for v in f2.values() if not v[5]}))
                scores.append(compute_score(f2, nw2, c2)[0])
            scores.sort()
            lo = scores[int(0.05 * (len(scores) - 1))]
            hi = scores[int(round(0.95 * (len(scores) - 1)))]
            lo = min(lo, score)
            hi = max(hi, score)
            metrics["score_ci"] = [lo, hi]
            metrics["score_ci_note"] = "resampled 90% interval over sentences (30 draws, fixed seed)"
        else:
            metrics["score_ci"] = None
            metrics["score_ci_note"] = "too few sentences for an interval (need at least 4)"

    report = {}
    for key, (num, slug, label, count, smp, advice) in sorted(
            found.items(), key=lambda kv: (kv[1][0], str(kv[0]))):
        report["%d_%s" % (num, slug)] = {"label": label, "count": int(count),
                                         "samples": [str(s)[:120] for s in smp[:3]]}
    report["_metrics"] = metrics
    return report


def main(argv):
    clean = False
    ci = False
    operands = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == "--":
            operands.extend(argv[i + 1:])
            break
        if a in ("--help", "-h"):
            out_bytes(USAGE)
            return 0
        if a == "--clean":
            clean = True
        elif a == "--ci":
            ci = True
        elif a.startswith("-") and a != "-":
            fail("unknown option: %s (see --help)" % a, 2)
        else:
            operands.append(a)
        i += 1

    if len(operands) >= 2:
        sys.stderr.write("prosecheck: only the first file was scanned: %s\n" % operands[0])
        sys.stderr.flush()

    if operands:
        path = operands[0]
        try:
            with open(path, "rb") as f:
                data = f.read()
        except (OSError, ValueError) as e:
            fail("cannot read input: %s" % (getattr(e, "strerror", None) or e), 1)
        try:
            text = extract.extract(path, data)
        except extract.NotZip:
            fail("cannot read input: %s is not a readable zip archive" % path, 1)
        except Exception as e:  # defensive: never a traceback
            fail("cannot read input: %s" % e, 1)
    else:
        try:
            data = sys.stdin.buffer.read()
        except Exception as e:
            fail("cannot read input: %s" % e, 1)
        text = extract.decode_bytes(data)

    if not text or not text.strip():
        fail("empty input", 1)

    if clean:
        out_bytes(charlayer.cleanup(text))
        return 0

    report = analyze(text, ci)
    out_bytes(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main(sys.argv[1:]))
    except SystemExit:
        raise
    except BrokenPipeError:
        sys.exit(0)
    except BaseException as e:  # never print a traceback
        try:
            sys.stderr.write(json.dumps({"error": "cannot read input: internal error: %s" % e}) + "\n")
        except Exception:
            pass
        sys.exit(1)
