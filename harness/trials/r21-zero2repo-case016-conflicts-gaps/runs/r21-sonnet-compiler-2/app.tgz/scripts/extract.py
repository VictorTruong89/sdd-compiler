"""Prose extraction from the twenty supported formats."""
import io
import json
import os
import re
import zipfile
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

PLAIN_EXT = {".md", ".mdx", ".markdown", ".txt", ".text", ".rst", ".tex", ".org", ".adoc"}
ZIP_EXT = {".docx", ".docm", ".pptx", ".pptm", ".xlsx", ".xlsm", ".odt", ".odp", ".ods", ".epub"}
NB_EXT = {".ipynb"}
MEMBER_LIMIT = 64 * 1024 * 1024


class NotZip(Exception):
    pass


def decode_bytes(b):
    if b.startswith(b"\xef\xbb\xbf"):
        return b[3:].decode("utf-8", errors="replace")
    if b.startswith(b"\xff\xfe") or b.startswith(b"\xfe\xff"):
        return b.decode("utf-16", errors="replace")
    t = b.decode("utf-8", errors="replace")
    if t.startswith("﻿"):
        t = t[1:]
    return t


def _local(tag):
    return tag.rsplit("}", 1)[-1] if "}" in tag else tag


def _read(z, name):
    info = z.getinfo(name)
    if info.file_size > MEMBER_LIMIT:
        return b""
    return z.read(name)


def _parse(b):
    try:
        return ET.fromstring(b)
    except ET.ParseError:
        return None


def _natkey(s):
    return [int(p) if p.isdigit() else p for p in re.split(r"(\d+)", s)]


def _para_text(p, ptag, ttag, tabtag, brtags):
    parts = []

    def walk(e):
        for ch in e:
            n = _local(ch.tag)
            if n == ptag and e is not p:
                continue
            if n == ttag:
                parts.append(ch.text or "")
            elif n == tabtag:
                parts.append("\t")
            elif n in brtags:
                parts.append("\n")
            else:
                walk(ch)

    walk(p)
    return "".join(parts)


def _docx(z):
    out = []
    for name in ("word/document.xml",):
        if name not in z.namelist():
            continue
        root = _parse(_read(z, name))
        if root is None:
            continue
        for e in root.iter():
            if _local(e.tag) == "p":
                t = _para_text(e, "p", "t", "tab", ("br", "cr"))
                if t.strip():
                    out.append(t)
    return "\n".join(out)


def _pptx(z):
    names = [n for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)]
    names.sort(key=_natkey)
    out = []
    for n in names:
        root = _parse(_read(z, n))
        if root is None:
            continue
        for e in root.iter():
            if _local(e.tag) == "p":
                t = _para_text(e, "p", "t", "\0", ("br",))
                if t.strip():
                    out.append(t)
    return "\n".join(out)


def _si_text(si):
    parts = []

    def walk(e):
        for ch in e:
            n = _local(ch.tag)
            if n == "rPh":
                continue
            if n == "t":
                parts.append(ch.text or "")
            else:
                walk(ch)

    walk(si)
    return "".join(parts)


def _xlsx(z):
    names = z.namelist()
    shared = []
    if "xl/sharedStrings.xml" in names:
        root = _parse(_read(z, "xl/sharedStrings.xml"))
        if root is not None:
            for si in root:
                if _local(si.tag) == "si":
                    shared.append(_si_text(si))
    sheets = [n for n in names if re.match(r"xl/worksheets/[^/]+\.xml$", n)]
    sheets.sort(key=_natkey)
    out = []
    for n in sheets:
        root = _parse(_read(z, n))
        if root is None:
            continue
        for c in root.iter():
            if _local(c.tag) != "c":
                continue
            t = c.get("t")
            v = None
            isel = None
            for ch in c:
                ln = _local(ch.tag)
                if ln == "v":
                    v = ch.text
                elif ln == "is":
                    isel = ch
            txt = None
            if t == "s":
                if v is not None and re.fullmatch(r"\d+", v.strip()):
                    idx = int(v.strip())
                    if idx < len(shared):
                        txt = shared[idx]
            elif t == "inlineStr":
                if isel is not None:
                    txt = _si_text(isel)
            elif t == "str":
                txt = v
            if txt is not None and txt.strip():
                out.append(txt)
    return "\n".join(out)


_ODF_TEXT = "{urn:oasis:names:tc:opendocument:xmlns:text:1.0}"


def _odf_para(p):
    parts = []

    def walk(e):
        if e.text:
            parts.append(e.text)
        for ch in e:
            n = _local(ch.tag)
            if n == "s":
                try:
                    parts.append(" " * int(ch.get(_ODF_TEXT + "c", "1")))
                except ValueError:
                    parts.append(" ")
            elif n == "tab":
                parts.append("\t")
            elif n == "line-break":
                parts.append("\n")
            elif n in ("annotation", "note"):
                pass
            else:
                walk(ch)
            if ch.tail:
                parts.append(ch.tail)

    walk(p)
    return "".join(parts)


def _odf(z):
    if "content.xml" not in z.namelist():
        return ""
    root = _parse(_read(z, "content.xml"))
    if root is None:
        return ""
    out = []

    def walk(e):
        for ch in e:
            n = _local(ch.tag)
            if n in ("p", "h"):
                t = _odf_para(ch)
                if t.strip():
                    out.append(t)
            else:
                walk(ch)

    body = root
    walk(body)
    return "\n".join(out)


class _Html(HTMLParser):
    BLOCK = {"p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "br", "tr", "blockquote",
             "section", "article", "pre", "ul", "ol", "table", "dt", "dd", "figcaption", "hr"}
    SKIP = {"script", "style", "nav", "head", "title"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.depth = 0

    def handle_starttag(self, tag, attrs):
        tag = tag.split(":")[-1].lower()
        if tag in self.SKIP:
            self.depth += 1
        elif tag in self.BLOCK:
            self.parts.append("\n")

    def handle_startendtag(self, tag, attrs):
        tag = tag.split(":")[-1].lower()
        if tag in self.BLOCK:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        tag = tag.split(":")[-1].lower()
        if tag in self.SKIP:
            self.depth = max(0, self.depth - 1)
        elif tag in self.BLOCK:
            self.parts.append("\n")

    def handle_data(self, data):
        if self.depth == 0:
            self.parts.append(data)


def _html_text(b):
    p = _Html()
    try:
        p.feed(b.decode("utf-8", errors="replace"))
        p.close()
    except Exception:
        pass
    text = "".join(p.parts)
    lines = [re.sub(r"[ \t\r\f\v\n]+", " ", ln).strip() for ln in text.split("\n")]
    return "\n".join(ln for ln in lines if ln)


def _epub(z):
    names = z.namelist()
    ordered = []
    try:
        cont = _parse(_read(z, "META-INF/container.xml"))
        opf_path = None
        if cont is not None:
            for e in cont.iter():
                if _local(e.tag) == "rootfile":
                    opf_path = e.get("full-path")
                    break
        if opf_path and opf_path in names:
            opf = _parse(_read(z, opf_path))
            base = os.path.dirname(opf_path)
            manifest = {}
            for e in opf.iter():
                if _local(e.tag) == "item":
                    manifest[e.get("id")] = (e.get("href"), e.get("properties") or "")
            for e in opf.iter():
                if _local(e.tag) == "itemref":
                    item = manifest.get(e.get("idref"))
                    if item and "nav" not in item[1].split():
                        href = item[0] or ""
                        from urllib.parse import unquote
                        full = os.path.normpath(os.path.join(base, unquote(href))).replace("\\", "/")
                        if full in names and full not in ordered:
                            ordered.append(full)
    except Exception:
        ordered = []
    if not ordered:
        ordered = sorted(
            (n for n in names if re.search(r"\.(x?html?)$", n, re.I)
             and not re.search(r"(^|/)(nav|toc)[^/]*$", n, re.I)),
            key=_natkey,
        )
    out = []
    for n in ordered:
        t = _html_text(_read(z, n))
        if t.strip():
            out.append(t)
    return "\n".join(out)


def _notebook(b):
    try:
        data = json.loads(decode_bytes(b))
    except Exception:
        return ""
    cells = data.get("cells") if isinstance(data, dict) else None
    if not isinstance(cells, list):
        return ""
    out = []
    for c in cells:
        if not isinstance(c, dict) or c.get("cell_type") != "markdown":
            continue
        src = c.get("source")
        if isinstance(src, list):
            if not all(isinstance(x, str) for x in src):
                continue
            src = "".join(src)
        if not isinstance(src, str):
            continue
        if src.strip():
            out.append(src)
    return "\n".join(out)


def extract(path, data):
    """Return extracted prose for bytes `data` read from `path`.

    Raises NotZip for a zip-type extension with non-zip bytes."""
    ext = os.path.splitext(path)[1].lower()
    if ext in ZIP_EXT:
        try:
            z = zipfile.ZipFile(io.BytesIO(data))
        except (zipfile.BadZipFile, ValueError, OSError):
            raise NotZip()
        try:
            if ext in (".docx", ".docm"):
                t = _docx(z)
            elif ext in (".pptx", ".pptm"):
                t = _pptx(z)
            elif ext in (".xlsx", ".xlsm"):
                t = _xlsx(z)
            elif ext == ".epub":
                t = _epub(z)
            else:
                t = _odf(z)
        except (zipfile.BadZipFile, KeyError, ValueError, RuntimeError, OSError):
            t = ""
        return t.strip()
    if ext in NB_EXT:
        return _notebook(data).strip()
    if ext in (".pdf", ".rtf"):
        return ""
    return decode_bytes(data)
