"""Pattern catalogue: lexical families and structural checks."""
import math
import re

I = re.IGNORECASE


def vb(base):
    if base.endswith("e"):
        return "%s(?:e|es|ed|ing)" % base[:-1]
    return "%s(?:s|es|ed|ing)?" % base


def nn(base):
    if base.endswith("y"):
        return "(?:%s|%sies)" % (base, base[:-1])
    return "%s(?:s|es)?" % base


def alt(words):
    return "(?:%s)" % "|".join(words)


W = r"\b"

# ---- family 1 -----------------------------------------------------------
_AI_VERBS = ["delve", "align", "garner", "bolster", "foster", "showcase", "emphasize", "enhance",
             "leverage", "utilize", "facilitate", "encompass", "harness", "navigate", "embark",
             "craft", "elevate", "empower", "unlock", "underscore", "underscor"]
_AI_VERBS = [v for v in _AI_VERBS if v != "underscor"]
_AI_NOUNS = ["tapestry", "testament", "interplay", "intricacy", "paradigm", "plethora",
             "myriad", "landscape", "journey", "realm"]
_AI_ADJ = ["additionally", "crucial", "pivotal", "vibrant", "meticulous", "intricate",
           "intricacies", "enduring", "holistic", "transformative", "unprecedented", "robust",
           "seamless", "multifaceted"]
_AI1 = (
    W + "(?:" + "|".join(
        [vb(v) if v != "align" else r"align(?:s|ed|ing)? with" for v in _AI_VERBS]
        + [nn(n) for n in _AI_NOUNS]
        + _AI_ADJ
        + [r"captur(?:e|es|ed|ing) the (?:essence|spirit|imagination|heart|magic)"]
    ) + r")\b"
)
_DIALECT = (
    W + "(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly"
    r"|quietly (?:powerful|profound|radical)|deeply (?:human|personal|felt|unsettling)"
    r"|resonates? deeply|game[- ]?chang(?:er|ers|ing)|supercharg(?:e|es|ed|ing)"
    r"|skyrocket(?:s|ed|ing)?|turbocharg(?:e|es|ed|ing)|revolutioniz(?:e|es|ed|ing)"
    r"|double(?:s|d)? down on|div(?:e|es|ed|ing) deep(?:er)? into"
    r"|unlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)"
    r"|tak(?:e|es|ing|en)\b[^.\n]{0,40}?\bto the next level)\b"
)

_PROMO = (
    W + "(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|vibrant community"
    r"|rich cultural heritage|in the heart of|world-class|top-tier|unparalleled|premier"
    r"|leading (?=(?:provider|company|expert|authority|firm|brand|platform|organization|manufacturer|solution|industry|name))"
    r"|esteemed organization|valuable asset|passion for excellence|proven track record"
    r"|results-oriented|wealth of experience|dynamic team|fast-paced environment"
    r"|deeply passionate|perfectly situated|(?:close|tight)-knit team"
    r"|i am excited to (?:apply|bring)|uniquely positioned to)\b"
)

_CLUSTERS = [
    ["protagonist", "main character", "central figure", "hero", "heroine"],
    ["company", "firm", "organization", "enterprise", "business"],
    ["author", "writer", "novelist", "scribe"],
    ["report", "study", "analysis", "investigation", "examination"],
    ["technology", "tool", "system", "platform", "solution"],
    ["technique", "method", "approach", "strategy", "tactic"],
    ["challenge", "obstacle", "difficulty", "hurdle", "barrier"],
    ["benefit", "advantage", "upside", "strength"],
]

_ADJ_STOCK = set("""innovative dynamic robust seamless powerful scalable comprehensive cutting-edge
innovative reliable efficient effective flexible intuitive modern secure fast simple elegant
creative collaborative strategic passionate dedicated engaging impactful vibrant compelling
stunning beautiful rich diverse unique exceptional""".split())
_ADJ_END = re.compile(r"(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$", I)

SIGNS = {}

# (num, slug, label, advice, regex, min_count)
LEX = []


def L(num, slug, label, pattern, advice=False, flags=I, min_count=1):
    LEX.append((num, slug, label, advice, re.compile(pattern, flags), min_count))


L(1, "ai_vocabulary", "AI vocabulary", _AI1)
L(2, "model_dialect", "Model-dialect vocabulary", _DIALECT, min_count=2)
L(3, "promotional_language", "Promotional language", _PROMO)
L(4, "hyphenated_pairs", "Hyphenated word-pair overuse",
  W + r"(?:cutting-edge|state-of-the-art|best-in-class|data-driven|results-driven|forward-thinking"
  r"|game-changing|world-class|high-quality|user-friendly|fast-paced|well-rounded|detail-oriented"
  r"|self-starter|team-player|mission-critical|next-generation|end-to-end|customer-centric"
  r"|value-added|thought-provoking|ever-evolving|ever-changing|groundbreaking|results-oriented)" + W,
  advice=True)
L(5, "simple_yet", "\"Simple yet X\" cliché",
  W + r"simple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b")
L(10, "significance_inflation", "Significance inflation",
  r"(?:\b(?:stand|stands|stood|serve|serves|served)\s+as\s+(?:a|an)\s+(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b"
  r"|\b(?:underscor|highlight)(?:es|ed|ing|s)?e?\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b"
  r"|\breflects?\s+a\s+broader\s+(?:trend|shift|pattern)\b"
  r"|\bmarks?\s+a\s+(?:turning point|milestone|watershed|new chapter|new era)\b"
  r"|\bsymboli[sz](?:es|ed|ing)\b"
  r"|\bsets?\s+the\s+stage\s+for\b"
  r"|\bleft\s+an\s+indelible\s+mark\b"
  r"|\bplays?\s+an?\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b"
  r"|\bhas\s+(?:shaped|sparked)\b|\bhas\s+come\s+to\s+(?:define|symbolize|symbolise)\b)")
L(12, "vague_attributions", "Vague attributions",
  r"(?:\bexperts?\s+(?:argue|believe|say|claim|note|suggest)\b"
  r"|\bindustry\s+(?:reports|observers|analysts)\b"
  r"|\bobservers\s+have\s+(?:cited|noted)\b|\bsome\s+critics\s+argue\b"
  r"|\bresearchers\s+have\s+found\b|\bstudies\s+suggest\b|\bit\s+is\s+widely\s+believed\b)")
L(13, "article_title_proper_noun", "Article title as proper noun",
  r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of (?:[\w'’-]+ ){1,8}?(?:is|was) (?:an?|the)\b",
  flags=0)
L(14, "ecosystem_padding", "Conservation / ecosystem padding",
  r"(?:\bplays?\s+an?\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b"
  r"|\bconservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)\b"
  r"|\bserves?\s+as\s+an\s+indicator\s+species\b|\bcontributes?\s+to\s+biodiversity\b)")
L(15, "false_ranges", "False ranges",
  r"(?:\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]{0,120}?"
  r"\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering|grand|sprawling)\b)")
L(16, "ing_tails", "Superficial -ing tail clauses",
  r",\s+(?:highlighting|reflecting|symbolizing|symbolising|emphasizing|emphasising|underscoring|showcasing"
  r"|fostering|cultivating|encompassing|signaling|signalling|demonstrating|illustrating|representing"
  r"|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b")
L(18, "not_x_just_y", "\"Not X, just Y\"",
  r"(?:\b(?:no|not)\s+[\w'’-]+,\s*(?:just|only|simply)\s+[\w'’-]+"
  r"|\b(?:not|isn['’]t|aren['’]t|wasn['’]t|weren['’]t)\s+(?:just|merely)\s+(?:(?:an?|the)\s+)?[\w'’-]+\s*(?:,|\s[—–-]+\s*|[—–])\s*"
  r"(?:it['’]s|it is|it was|they['’]re|they are|they were|that['’]s|but)\b)")
L(19, "filler_phrases", "Filler phrases",
  r"\b(?:in order to|due to the fact that|at this point in time|in the event that|has the ability to"
  r"|it is important to note that|it should be mentioned that|needless to say)\b", advice=True)
L(20, "empty_pivots", "Empty pivot phrases",
  r"\b(?:it['’]s\s+worth\s+(?:noting|mentioning)\s+that|it\s+bears\s+(?:noting|mentioning)\s+that"
  r"|one\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is|it\s+is\s+interesting\s+to\s+note\s+that"
  r"|a\s+key\s+consideration\s+is|a\s+point\s+to\s+highlight\s+is|it\s+is\s+worth\s+(?:noting|mentioning)\s+that)")
L(21, "speculation_tails", "Outcome-speculation tails",
  r",\s+(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about"
  r"|with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for"
  r"|signaling\s+a\s+shift\s+toward|signalling\s+a\s+shift\s+toward)\b")
L(22, "authority_tropes", "Persuasive authority tropes",
  r"(?:\bhere['’]s\s+the\s+thing\b|\bmake\s+no\s+mistake\b|\bthe\s+truth\s+is\b|\blet['’]s\s+be\s+honest\b"
  r"|\bthe\s+simple\s+fact\s+is\b|\bat\s+its\s+core\b|\bwhat\s+really\s+matters\b|\bmore\s+than\s+anything\b"
  r"|\bat\s+the\s+end\s+of\s+the\s+day\b|\bthe\s+bottom\s+line\s+is\b|\bin\s+reality\b|\bfundamentally,"
  r"|\bthe\s+real\s+question\s+is\b|\bthe\s+heart\s+of\s+the\s+matter\b|\bthe\s+deeper\s+issue\b"
  r"|\bwhen\s+you\s+get\s+down\s+to\s+it\b|\bwhen\s+all\s+is\s+said\s+and\s+done\b)", advice=True)
L(23, "editorial_interjections", "Editorial interjections",
  r"\b(?:it['’]s|it\s+is)\s+important\s+to\s+(?:remember|note|understand|recognize|recognise)\b"
  r"|\bone\s+must\s+note\s+that\b|\bit\s+is\s+worth\s+pointing\s+out\b|\bit\s+cannot\s+be\s+overstated\s+that\b"
  r"|\bit\s+must\s+be\s+emphasized\s+that\b")
L(24, "self_thoroughness", "Self-thoroughness phrases",
  r"\b(?:this\s+comprehensive\s+(?:guide|overview|analysis)|this\s+in-depth\s+(?:analysis|look|examination)"
  r"|this\s+complete\s+(?:guide|overview)|a\s+thorough\s+examination\s+of|everything\s+you\s+need\s+to\s+know\s+about)\b")
L(26, "concrete_evidence", "\"Concrete evidence\" defense phrase",
  r"\b(?:without\s+concrete\s+evidence|do\s+you\s+have\s+concrete\s+evidence"
  r"|i\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples)\s+to|absent\s+concrete\s+proof"
  r"|provide\s+concrete\s+evidence)")
L(27, "intro_hooks", "Compulsive intro hooks",
  r"(?:\bin\s+today['’]s\s+(?:[\w-]+\s+){0,2}(?:world|landscape|environment|market)\b|\bin\s+a\s+world\s+where\b"
  r"|\bin\s+an\s+era\s+of\b|\bin\s+recent\s+years,|\bmore\s+than\s+ever\s+before\b"
  r"|\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b|\b(?:great|exciting|big)\s+news\s*[!:]"
  r"|\bever\s+(?:wanted|wondered|dreamed|wished)\s+to\b[^.!?\n]*\?"
  r"|\bin\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world\b)")
L(30, "diff_anchored", "Diff-anchored writing",
  r"(?:\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b"
  r"|\b(?:the|this)\s+(?:(?:latest|new)\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b"
  r"|\b(?:has|have)\s+been\s+(?:updated|refactored|improved|enhanced|changed)\s+to\b"
  r"|\bpreviously\b[^.!?\n]{0,120}?\bnow\b|\b(?:wasn['’]t|weren['’]t)\s+there\s+before\b"
  r"|\bwe['’]ve\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b"
  r"|\bwe\s+have\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b)")
L(31, "signposting", "Signposting and announcements",
  r"\b(?:let['’]s\s+(?:dive|delve|explore)|let['’]s\s+break\s+(?:this|it)\s+down|here['’]s\s+what\s+you\s+need\s+to\s+know"
  r"|without\s+further\s+ado|now\s+let['’]s\s+look\s+at|buckle\s+up|stay\s+with\s+me|ready\s+to\s+dive\s+in)")
L(32, "cataloguing_leadins", "Cataloguing lead-ins",
  r"(?:\b(?:used|uses|employs|employed|relied\s+on|utilizes|utilises)\s+(?:several|various|a\s+number\s+of|multiple|different|many|numerous)\s+\w+"
  r"|(?:^|(?<=[.!?]\s))These\s+(?:\w+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help)\s+(?:information|insight|understanding|details|data)\b"
  r"|\b(?:is|are|was|were|remains|becomes)\s+(?:the|a)\s+(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b)")
L(36, "formulaic_challenges", "Formulaic challenges sections",
  r"\b(?:despite\s+(?:these|its|the)\s+(?:challenges|obstacles)|challenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)"
  r"|continues\s+to\s+thrive|typical\s+of\s+(?:emerging|urban|modern)|faces\s+(?:several|many|numerous)\s+challenges)")
L(38, "compulsive_conclusions", "Compulsive conclusion phrases",
  r"^[ \t>*#_-]*(?:in\s+conclusion|overall|in\s+summary|to\s+summarize|to\s+conclude|all\s+in\s+all|in\s+essence|ultimately)\b",
  flags=I | re.M)
L(39, "generic_positive_conclusions", "Generic positive conclusions",
  r"\b(?:the\s+future\s+looks\s+bright|exciting\s+times\s+lie\s+ahead|journey\s+toward\s+excellence"
  r"|step\s+in\s+the\s+right\s+direction|(?:the\s+)?(?:outlook|future)(?:\s+for\s+[\w\s]{1,30}?)?\s+(?:is|looks|remains)\s+bright"
  r"|well[- ]positioned\s+for\s+(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead))")
L(47, "chatbot_artifacts", "Chatbot artifacts",
  r"(?:\bi\s+hope\s+this\s+helps\b|\bCertainly!|\bOf\s+course!|\blet\s+me\s+know\s+if\s+you\b|\bwould\s+you\s+like\s+me\s+to\b"
  r"|\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b|\bhappy\s+to\s+help\s*(?:[.!?]|$)"
  r"|\b(?:here|below)\s+is\s+(?:an?|the)\s+(?:overview|summary|rundown|recap|brief)\b"
  r"|\bhere\s+(?:are|['’]s)\s+(?:a\s+)?(?:few|some|two|three)\s+(?:options|drafts|versions|variations)\b"
  r"|\bhere\s+(?:is|['’]s)\s+a\s+draft\b|\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b"
  r"|\bi\s+hope\s+(?:this\s+email\s+)?finds\s+you\s+well\b"
  r"|\bas\s+an?\s+(?:AI|LLM|AI\s+assistant|AI\s+language\s+model|large\s+language\s+model|language\s+model)\b"
  r"|\bto\s+(?:answer|address)\s+your\s+question\b|\bin\s+(?:response|answer)\s+to\s+your\s+question\b"
  r"|\byour\s+question\s+(?:about|regarding|concerning)\b|\bas\s+(?:you\s+)?(?:requested|asked),\s+here\b"
  r"|\bhere\s+is\s+(?:the\s+)?(?:draft|first\s+pass|revised\s+version\s+of|for\s+your)\b)")
L(48, "sycophantic_tone", "Sycophantic tone",
  r"(?:\byou(?:['’]re|\s+are)\s+absolutely\s+right\b"
  r"|\b(?:great\s+question|excellent\s+point)\s*[!.,]"
  r"|\bwhat\s+an?\s+(?:thoughtful|great|wonderful|fantastic)\s+question\s*[!.,]"
  r"|\bthat['’]s\s+an?\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\s*[!.,])")
L(50, "knowledge_cutoff", "Knowledge-cutoff disclaimers",
  r"(?:\bas\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)\b|\bup\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)\b"
  r"|\bwhile\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+(?:extensively|widely)\s+documented)\b"
  r"|\bbased\s+on\s+(?:the\s+)?available\s+information\b|\bas\s+of\s+my\s+(?:knowledge\s+)?cutoff\b"
  r"|\bmaintains\s+a\s+low\s+profile\b|\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b)")
L(51, "copula_avoidance", "Copula avoidance",
  r"\b(?:serves\s+as|stands\s+as|functions\s+as|acts\s+as|represents\s+(?:a|the)\b|marks\s+(?:a|the)\b"
  r"|boasts?\b|features\s+(?:an?|the|\d+|several|many|numerous|multiple|various|over|more)\b|offers\s+a\b|refers\s+to\b)")
L(69, "marketing_slop", "Canonical marketing-slop phrases",
  r"\b(?:unlocking\s+(?:its\s+|their\s+|your\s+)?full\s+potential|navigating\s+the\s+complexit(?:y|ies)"
  r"|a\s+testament\s+to\s+the\s+(?:power|importance)|staying\s+ahead\s+of\s+the\s+curve"
  r"|turning\s+challenges\s+into\s+opportunities|tak(?:e|es|ing)\s+\w+(?:\s+\w+)?\s+to\s+the\s+next\s+level"
  r"|harnessing\s+the\s+power\s+of|paving\s+the\s+way\s+for|saying\s+goodbye\s+to|imagining\s+a\s+world\s+where"
  r"|unlock\s+(?:the\s+)?full\s+potential|take\s+it\s+to\s+the\s+next\s+level)")
L(63, "placeholder_text", "Placeholder text",
  r"(?:\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]{0,60}\](?![(\[])"
  r"|\[(?:[A-Za-z]+ ){0,2}(?:name|company|client|city|place|location|source|person|address|date)(?: [A-Za-z]+){0,2}\](?![(\[])"
  r"|\[(?:todo|tbd|tk)\](?![(\[])"
  r"|\[[A-Z][A-Z _/-]{2,}[A-Z]\](?![(\[])"
  r"|\{\{[^{}\n]{1,80}\}\}|\bx{3,}\b|\blorem\s+ipsum\b)")
L(64, "chat_reference_markup", "Chatbot reference-markup leak",
  r"(?:\bcite(?:turn|start|nav)\w*|\boai_citation\w*|contentReference|\bnavlist\b|【\d+[^】]*†[^】]*】)",
  flags=I)
L(70, "decorative_rules", "Decorative horizontal rules", r"(?!)")

# --- structural / other checks implemented in code --------------------------

HOOK = {
    "clean": "reads clean",
    "light tells": "reads mostly clean",
    "mixed": "reads with some AI tells",
    "heavy tells": "reads with heavy AI tells",
    "pervasive tells": "reads with pervasive AI tells",
}

LABELS = {
    6: ("stacked_adjectives", "Stacked adjective chains"),
    8: ("synonym_cycling", "Synonym cycling"),
    11: ("notability_namedropping", "Notability name-dropping"),
    17: ("negative_parallelism", "Negative parallelism"),
    "17t": ("tailing_negation", "Tailing negation"),
    25: ("question_answer", "Question-answer rhetorical pattern"),
    33: ("inline_header_lists", "Inline-header vertical lists"),
    34: ("mid_essay_bullets", "Mid-essay bullet injection"),
    35: ("fragmented_headers", "Fragmented headers"),
    37: ("transition_clusters", "Transition cluster overuse"),
    40: ("sentence_length_monotony", "Sentence-length monotony"),
    41: ("mechanical_alternation", "Mechanical sentence-length alternation"),
    42: ("opener_repetition", "Opener repetition"),
    44: ("uniform_paragraphs", "Uniform paragraph length"),
    46: ("semicolon_underuse", "Semicolon and parenthesis underuse"),
    54: ("hedge_stacking", "Excessive hedging"),
    55: ("contraction_absence", "Contraction absence"),
    56: ("boldface", "Boldface overuse"),
    57: ("emojis", "Emojis"),
    58: ("em_dash_overuse", "Em-dash overuse"),
    59: ("title_case_headings", "Title case in headings"),
    60: ("curly_quotes", "Curly quotation marks"),
    61: ("hyphen_ranges", "Hyphen for en dash in ranges"),
    62: ("invisible_chars", "Invisible / zero-width characters"),
    65: ("tracking_params", "AI tracking parameters"),
    66: ("homoglyphs", "Homoglyph / mixed-script confusables"),
    67: ("nonstandard_spaces", "Non-standard spaces"),
    68: ("trailing_whitespace", "Trailing / stray whitespace"),
    70: ("decorative_rules", "Decorative horizontal rules"),
    71: ("degenerate_repetition", "Degenerate repetition"),
}

ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68, "17", "17p"}
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
RHYTHM = {40, 41, 44, 55}
EARLY = set(range(1, 40)) | {47, 48, 49, 50, 51, 69}

WORD_RE = re.compile(r"[\w'’-]+")


def words(s):
    return [w for w in WORD_RE.findall(s) if re.search(r"[^\W_]", w)]


def cv(vals):
    m = sum(vals) / len(vals)
    if m == 0:
        return 0.0
    var = sum((v - m) ** 2 for v in vals) / len(vals)
    return math.sqrt(var) / m


# ---- masking ---------------------------------------------------------------

_FENCE_OPEN = re.compile(r"^( {0,3})(`{3,}|~{3,})(.*)$")
_BADGE = re.compile(r"^\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$")
_TABLE = re.compile(r"^\s*\|.*\|?\s*$|^\s*:?-{3,}:?\s*(?:\|\s*:?-{3,}:?\s*)+\|?\s*$")
_INLINE = re.compile(r"(`+)(?!`)(.+?)(?<!`)\1(?!`)")


def mask(text):
    lines = text.split("\n")
    n = len(lines)
    dead = [False] * n
    i = 0
    if n and lines[0].rstrip() == "---":
        for j in range(1, n):
            if lines[j].rstrip() in ("---", "..."):
                for k in range(0, j + 1):
                    dead[k] = True
                i = j + 1
                break
    while i < n:
        m = _FENCE_OPEN.match(lines[i])
        if m and not (m.group(2)[0] == "`" and "`" in m.group(3)):
            ch = m.group(2)[0]
            ln = len(m.group(2))
            dead[i] = True
            j = i + 1
            while j < n:
                dead[j] = True
                cm = re.match(r"^ {0,3}(%s{%d,})[ \t]*$" % (re.escape(ch), ln), lines[j])
                if cm:
                    break
                j += 1
            i = j + 1
            continue
        i += 1
    # blockquote runs
    i = 0
    while i < n:
        if not dead[i] and lines[i].lstrip().startswith(">"):
            j = i
            while j < n and not dead[j] and lines[j].lstrip().startswith(">"):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    dead[k] = True
            i = j
        else:
            i += 1
    for i in range(n):
        if dead[i]:
            continue
        ln = lines[i]
        if _BADGE.match(ln) or (ln.lstrip().startswith("|") and ln.count("|") >= 2) or re.match(
                r"^\s*\|?\s*:?-{3,}:?\s*(\|\s*:?-{3,}:?\s*)+\|?\s*$", ln):
            dead[i] = True
    out = []
    for i in range(n):
        if dead[i]:
            out.append(" " * len(lines[i]))
        else:
            out.append(_INLINE.sub(lambda m: " " * len(m.group(0)), lines[i]))
    return "\n".join(out)


def excerpt(text, s, e, pad=30):
    a = max(0, s - pad)
    b = min(len(text), e + pad)
    ex = text[a:b].replace("\n", " ").replace("\r", " ")
    return ("..." if a > 0 else "") + ex + ("..." if b < len(text) else "")


def sentences_of(prose):
    out = []
    for para in re.split(r"\n\s*\n", prose):
        for line_block in [para]:
            lines = [l for l in line_block.split("\n") if l.strip()]
            if not lines:
                continue
            if all(re.match(r"^\s*(?:#{1,6}\s|[-*+]\s|\d+[.)]\s|[-*_]{3,}\s*$)", l) for l in lines):
                continue
            joined = " ".join(l.strip() for l in lines if not re.match(r"^\s*#{1,6}\s", l))
            for s in re.split(r"(?<=[.!?])[\"')\]”’]*\s+", joined):
                if s.strip():
                    out.append(s.strip())
    return out


def paragraphs_of(prose):
    out = []
    for para in re.split(r"\n\s*\n", prose):
        p = para.strip()
        if not p:
            continue
        if re.match(r"^#{1,6}\s", p) and "\n" not in p:
            continue
        out.append(p)
    return out


EMOJI_RE = re.compile(
    "[\U0001F300-\U0001FAFF\U00002600-\U000027BF\U0001F000-\U0001F2FF\U00002B50\U00002B55"
    "\U0000231A\U0000231B\U000023E9-\U000023F3\U00002705\U0000274C\U00002728]"
)
CONTRACTED = re.compile(
    r"\b\w+n['’]t\b|\b(?:I|we|you|they|it|that|there|he|she|who|what|let)['’](?:m|re|ve|ll|d|s)\b", re.I)
FULL_FORMS = re.compile(
    r"\b(?:(?:do|does|did|is|are|was|were|have|has|had|will|would|could|should|can|must) not|cannot"
    r"|(?:it|that|there|what|who|he|she) is|(?:i) am|(?:i|we|you|they) (?:have|will|would)"
    r"|(?:we|you|they) are|let us)\b", re.I)
FIRST_PERSON = re.compile(r"\b(?:i|me|my|mine|myself|we|our|ours|us|i['’](?:m|ve|ll|d)|we['’](?:re|ve|ll))\b", re.I)
TRANSITION = re.compile(r"^(?:Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably)\b")
MARKETING_IMP = set("""install join grab download try discover experience escape transform reclaim unlock elevate
boost say imagine explore meet introducing upgrade claim unleash supercharge level stop start""".split())
HEDGES = re.compile(
    r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems?\s+(?:to|like)|appears?\s+to"
    r"|somewhat|relatively|fairly|kind of|sort of)\b")
PARALLEL = re.compile(
    r"(?:\bit['’]s\s+not\s+(?:just|merely)\s+(?:about|an?)\b"
    r"|\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b"
    r"|\bdoesn['’]t\s+just\b[^,.\n]{0,40}?\bit\b)", I)
TAILING = re.compile(
    r",\s+no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b", I)
UTM = re.compile(r"utm_source=([A-Za-z0-9.\-]+)", I)
UTM_HOSTS = {"chatgpt.com", "chat.openai.com", "perplexity.ai", "claude.ai", "gemini.google.com",
             "copilot.microsoft.com", "poe.com"}
OUTLETS = r"(?:The\s+)?(?:New\s+York\s+Times|Forbes|Wired|TechCrunch|BBC|CNN|Bloomberg|Reuters|Guardian|Wall\s+Street\s+Journal|Washington\s+Post|NPR|Business\s+Insider|Fortune|Time)"
NOTABILITY = re.compile(
    r"(?:\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+" + OUTLETS +
    r"(?:\s*(?:,|and|&)\s*(?:and\s+)?" + OUTLETS + r")+"
    r"|\b\d[\d,.]*[kKmM]?\s+followers\b"
    r"|\b(?:strong|active)\s+(?:online|digital|social[- ]media)\s+presence\b"
    r"|\bwidely\s+covered\b|\bindependent\s+coverage\b)")
QA = re.compile(
    r"(?:^|(?<=[.!?]\s)|(?<=\n))((?:Is|Are|Was|Were|Do|Does|Did|Can|Could|Will|Would|Should|Has|Have|Had|May|Might|Must)\b[^.!?\n]{0,80}\?)\s+"
    r"(?:Yes|No|Absolutely|Never|Maybe|Probably|Always|Definitely|Certainly|Sometimes)\s*[.!](?=\s|$)")
HRULE = re.compile(r"^\s*(?:(?:-\s*){3,}|(?:\*\s*){3,}|(?:_\s*){3,})$")


def run_checks(win, prose):
    """Return dict key -> (num, slug, label, count, samples, advice) for fired checks."""
    found = {}

    def add(num, slug, label, count, samples, advice, key=None):
        if count > 0:
            found[key or num] = (num, slug, label, count, samples[:3], advice)

    # lexical
    for num, slug, label, advice, rx, minc in LEX:
        if num == 70:
            continue
        ms = list(rx.finditer(prose))
        if num == 3:
            cnt = len(ms)
            sents = sentences_of(prose)
            imp = [s for s in sents if re.match(r"^\W*([A-Za-z]+)", s) and
                   re.match(r"^\W*([A-Za-z]+)", s).group(1).lower() in MARKETING_IMP]
            smp = [excerpt(prose, m.start(), m.end(), 0) for m in ms[:3]]
            if len(imp) >= 3:
                cnt += len(imp)
                smp += imp[:1]
            if cnt >= 1:
                add(num, slug, label, cnt, smp, advice)
            continue
        if len(ms) < minc:
            continue
        if num == 1:
            smp = [excerpt(prose, m.start(), m.end()) for m in ms[:3]]
            smp = [excerpt(win, m.start(), m.end()) for m in ms[:3]]
        else:
            smp = [m.group(0).strip()[:80] for m in ms[:3]]
        add(num, slug, label, len(ms), smp, advice)

    # 6 stacked adjectives
    chain = re.compile(r"(?:\b[A-Za-z][A-Za-z-]*,\s+){2,}(?:and\s+)?[A-Za-z][A-Za-z-]*(?:\s+[A-Za-z][A-Za-z-]*)?")
    c6, s6 = 0, []
    for m in chain.finditer(prose):
        toks = [t for t in re.split(r",\s+(?:and\s+)?|\s+and\s+|\s+", m.group(0)) if t]
        if len(toks) < 4:
            continue
        low = [t.lower() for t in toks]
        if any(t in _ADJ_STOCK or _ADJ_END.search(t) for t in low[:-1]) or any(t in _ADJ_STOCK for t in low):
            if low[-1] in _ADJ_STOCK and False:
                continue
            c6 += 1
            s6.append(m.group(0))
    if c6:
        found[6] = (6, LABELS[6][0], LABELS[6][1], c6, s6[:3], False)

    # 8 synonym cycling
    c8, s8 = 0, []
    for cl in _CLUSTERS:
        present = []
        for w in cl:
            if re.search(r"\b%s(?:s|es|ies)?\b" % (w[:-1] if w.endswith("y") and False else w), prose, I):
                present.append(w)
            elif w.endswith("y") and re.search(r"\b%sies\b" % w[:-1], prose, I):
                present.append(w)
        if len(present) >= 3:
            c8 += 1
            s8.append("/".join(present))
    if c8:
        found[8] = (8, LABELS[8][0], LABELS[8][1], c8, s8[:3], False)

    # 11 notability
    ms = list(NOTABILITY.finditer(prose))
    if ms:
        found[11] = (11, LABELS[11][0], LABELS[11][1], len(ms), [m.group(0)[:80] for m in ms[:3]], False)

    # 17 forms
    ms = list(PARALLEL.finditer(prose))
    if ms:
        found["17p"] = (17, "negative_parallelism", "Negative parallelisms", len(ms),
                        [m.group(0)[:80] for m in ms[:3]], True)
    ms = list(TAILING.finditer(prose))
    if ms:
        found["17t"] = (17, "tailing_negation", "Tailing negations", len(ms),
                        [m.group(0)[:80] for m in ms[:3]], False)

    # 25 question-answer
    ms = list(QA.finditer(prose))
    if ms:
        found[25] = (25, LABELS[25][0], LABELS[25][1], len(ms), [m.group(0)[:80] for m in ms[:3]], False)

    lines = prose.split("\n")
    # 33 inline-header lists
    ih = re.compile(r"^\s*(?:[-*+]\s+|\d+[.)]\s+)?\*\*[^*\n]+?(?::\*\*|\*\*\s*:)")
    ms = [l.strip() for l in lines if ih.match(l)]
    if ms:
        found[33] = (33, LABELS[33][0], LABELS[33][1], len(ms), ms[:3], False)

    # 34 mid-essay bullets
    has_heading = any(re.match(r"^\s{0,3}#{1,6}\s", l) for l in lines)
    if not has_heading:
        paras = [p for p in re.split(r"\n\s*\n", prose) if p.strip()]
        listp = [p for p in paras if all(re.match(r"^\s*(?:[-*+]|\d+[.)])\s+\S", l) for l in p.split("\n") if l.strip())]
        proseP = [p for p in paras if p not in listp and not re.match(r"^\s*(?:[-*_]{3,})\s*$", p)]
        if listp and len(proseP) >= 2:
            found[34] = (34, LABELS[34][0], LABELS[34][1], len(listp), [listp[0][:60]], False)

    # 35 fragmented headers
    c35, s35 = 0, []
    for i, l in enumerate(lines):
        hm = re.match(r"^\s{0,3}#{1,6}\s+(.*?)\s*#*\s*$", l)
        if not hm:
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if re.match(r"^(?:#|[-*+]\s|\d+[.)]\s|\|)", nxt):
            continue
        nw = words(nxt)
        if len(nw) > 5 or not nw:
            continue
        hw = {w.lower() for w in words(hm.group(1)) if len(w) > 3}
        if any(w.lower().strip("'’-") in hw for w in nw if len(w) > 3):
            c35 += 1
            s35.append(hm.group(1) + " / " + nxt)
    if c35:
        found[35] = (35, LABELS[35][0], LABELS[35][1], c35, s35[:3], False)

    # 37 transitions
    c37 = 0
    s37 = []
    for para in re.split(r"\n\s*\n", prose):
        starts = []
        for seg in re.split(r"(?:(?<=[.!?])\s+|\n)", para.strip()):
            seg = seg.strip().lstrip("*_>-# ")
            if TRANSITION.match(seg):
                starts.append(seg.split()[0])
        if len(starts) >= 2:
            c37 += 1
            s37.append(", ".join(starts))
    if c37:
        found[37] = (37, LABELS[37][0], LABELS[37][1], c37, s37[:3], False)

    sents = sentences_of(prose)
    # 40 monotony
    if len(sents) >= 3:
        wc = [len(words(s)) for s in sents]
        if all(wc) and cv(wc) < 0.35:
            found[40] = (40, LABELS[40][0], LABELS[40][1], 1, ["cv=%.2f over %d sentences" % (cv(wc), len(wc))], False)
        # 41 alternation
        wc2 = wc
        best = 0
        run = 1
        prev_sign = 0
        for k in range(1, len(wc2)):
            d = wc2[k] - wc2[k - 1]
            sign = 1 if d > 0 else (-1 if d < 0 else 0)
            if sign != 0 and abs(d) >= 5 and (prev_sign == 0 or sign == -prev_sign):
                run += 1
            else:
                run = 2 if sign != 0 and abs(d) >= 5 else 1
            prev_sign = sign if abs(d) >= 5 else 0
            best = max(best, run)
        if best >= 6:
            found[41] = (41, LABELS[41][0], LABELS[41][1], 1, ["%d alternating sentences" % best], True)

    paras = paragraphs_of(prose)
    # 42 opener repetition
    c42, s42 = 0, []
    for p in paras:
        ss = sentences_of(p)
        if len(ss) >= 3:
            cnt = {}
            for s in ss:
                w = [x.lower() for x in words(s)[:2]]
                if len(w) == 2:
                    cnt[tuple(w)] = cnt.get(tuple(w), 0) + 1
            top = [(k, v) for k, v in cnt.items() if v >= 3]
            if top:
                c42 += 1
                s42.append(" ".join(top[0][0]))
    if c42:
        found[42] = (42, LABELS[42][0], LABELS[42][1], c42, s42[:3], True)

    # 44 uniform paragraphs
    pp = [p for p in paras if not re.match(r"^\s*(?:[-*+]|\d+[.)])\s", p)]
    if len(pp) >= 4:
        wc = [len(words(p)) for p in pp]
        if all(wc) and cv(wc) < 0.4:
            found[44] = (44, LABELS[44][0], LABELS[44][1], 1, ["cv=%.2f over %d paragraphs" % (cv(wc), len(wc))], False)

    allw = words(prose)
    nwords = len(allw)
    # 46
    if nwords >= 300 and ";" not in prose and len(re.findall(r"\([^)\n]*\)", prose)) <= 1:
        found[46] = (46, LABELS[46][0], LABELS[46][1], 1, ["no semicolons"], True)

    # 54 hedge stacking
    c54, s54 = 0, []
    for s in sents:
        hs = HEDGES.findall(s)
        if len(hs) >= 2:
            c54 += 1
            s54.append(s[:80])
    if c54:
        found[54] = (54, LABELS[54][0], LABELS[54][1], c54, s54[:3], True)

    # 55 contraction absence
    if nwords >= 30:
        fp = len(FIRST_PERSON.findall(prose))
        if fp / nwords >= 0.015:
            full = len(FULL_FORMS.findall(prose))
            con = len(CONTRACTED.findall(prose))
            if full >= 3 and full > 2 * con:
                found[55] = (55, LABELS[55][0], LABELS[55][1], full, ["%d uncontracted forms" % full], True)

    # 56 bold
    ms = re.findall(r"\*\*[^*\n]+\*\*", prose)
    if ms:
        found[56] = (56, LABELS[56][0], LABELS[56][1], len(ms), ms[:3], False)
    # 57 emoji
    ms = EMOJI_RE.findall(prose)
    if ms:
        found[57] = (57, LABELS[57][0], LABELS[57][1], len(ms), ms[:3], False)
    # 58 em dash
    c58 = 0
    for p in re.split(r"\n\s*\n", prose):
        if p.count("—") >= 2:
            c58 += 1
    if c58:
        found[58] = (58, LABELS[58][0], LABELS[58][1], c58, ["two or more em dashes in a paragraph"], True)
    # 59 title case headings
    SMALL = {"a", "an", "the", "and", "but", "or", "nor", "for", "so", "yet", "of", "in", "on", "at", "to",
             "by", "up", "as", "is", "if", "off", "per", "via", "with", "from", "into", "over", "than", "vs"}
    c59, s59 = 0, []
    for l in lines:
        hm = re.match(r"^\s{0,3}#{1,6}\s+(.*?)\s*#*\s*$", l)
        if not hm:
            continue
        h = hm.group(1)
        if not h or not h[0].isalpha() or h.upper() == h:
            continue
        hw = [w for w in h.split() if re.search(r"[^\W\d_]", w)]
        if len(hw) < 3:
            continue
        major = [w for w in hw if w.lower().strip(".,:;!?") not in SMALL]
        if len(major) >= 2 and all(w[0].isupper() for w in major) and \
                all(re.sub(r"^\W+", "", w)[:1].isupper() for w in major):
            c59 += 1
            s59.append(h)
    if c59:
        found[59] = (59, LABELS[59][0], LABELS[59][1], c59, s59[:3], False)
    # 60 curly quotes
    ms = re.findall("[‘’“”]", prose)
    if ms:
        found[60] = (60, LABELS[60][0], LABELS[60][1], len(ms), ms[:3], True)
    # 61 hyphen ranges
    ms = [m for m in re.finditer(r"\b(1[0-9]{3}|20[0-9]{2})-(1[0-9]{3}|20[0-9]{2})\b", prose)
          if int(m.group(1)) < int(m.group(2))]
    if ms:
        found[61] = (61, LABELS[61][0], LABELS[61][1], len(ms), [m.group(0) for m in ms[:3]], True)
    # 65 tracking
    ms = [m for m in UTM.finditer(prose) if m.group(1).rstrip(".").lower() in UTM_HOSTS]
    if ms:
        found[65] = (65, LABELS[65][0], LABELS[65][1], len(ms), [m.group(0) for m in ms[:3]], False)
    # 70 rules
    rules = [l for l in lines if HRULE.match(l)]
    nonblank = len([l for l in lines if l.strip()])
    if len(rules) >= 3 and len(lines) >= 24:
        found[70] = (70, LABELS[70][0], LABELS[70][1], len(rules), ["---"], False)
    # 71 degenerate repetition
    if nwords >= 12:
        lw = [w.lower() for w in allw]
        grams = [tuple(lw[i:i + 6]) for i in range(len(lw) - 5)]
        if grams:
            cnt = {}
            for g in grams:
                cnt[g] = cnt.get(g, 0) + 1
            rep = sum(1 for g in grams if cnt[g] > 1)
            if rep / len(grams) >= 0.2:
                top = max(cnt, key=cnt.get)
                found[71] = (71, LABELS[71][0], LABELS[71][1], rep, [" ".join(top)], False)
    return found
