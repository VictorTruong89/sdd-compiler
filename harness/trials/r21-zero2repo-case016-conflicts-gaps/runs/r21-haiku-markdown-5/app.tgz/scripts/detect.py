#!/usr/bin/env python3
"""prosecheck detector: a local, standard-library-only scanner for AI-writing patterns.

Usage:
    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
    python3 scripts/detect.py --help

With no FILE the text is read from standard input. The default output is one
JSON report object on standard output. --clean prints scrubbed text instead.
Errors are a single JSON object {"error": ...} as the last line of standard error.

The score is a triage heuristic on prose. It is not an authorship test.
"""
import html as _html
import io
import json
import math
import os
import posixpath
import random
import re
import sys
import unicodedata
import zipfile
import xml.etree.ElementTree as ET
from collections import Counter

WINDOW = 262144
PLAIN_EXTS = frozenset(['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'])
ZIP_EXTS = frozenset(['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'])
NOTEBOOK_EXTS = frozenset(['.ipynb'])
NO_TEXT_EXTS = frozenset(['.pdf', '.rtf'])

USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Scores prose for AI-writing patterns. A triage heuristic, not an authorship test.
  FILE          a text file or a supported document (.md .txt .docx .pptx .xlsx
                .odt .epub .ipynb and others). Omit it to read standard input.
  --clean       print the scrubbed text (invisible characters removed, unusual
                spaces normalized, lookalike letters folded, trailing spaces
                trimmed) instead of the JSON report.
  --ci          add a low/high interval on the score (needs at least four sentences).
  --            end option parsing, so a file name may begin with a dash.
  -h, --help    print this message and exit.
Only the first of several FILE operands is scanned.
"""

DECISIVE = frozenset([13, 47, 48, 50, 62, 63, 64, 65, 66])
SHORT_DOC_SET = frozenset(list(range(1, 40)) + list(range(47, 52)) + [69])
RHYTHM = frozenset([40, 44])
BANDS = [(20, 'clean'), (40, 'light tells'), (60, 'mixed'), (80, 'heavy tells'), (100, 'pervasive tells')]
PHRASES = {
    'clean': 'reads clean',
    'light tells': 'reads mostly clean',
    'mixed': 'reads with some AI tells',
    'heavy tells': 'reads with heavy AI tells',
    'pervasive tells': 'reads with pervasive AI tells',
}


# ---------------------------------------------------------------- utilities

def _err_line(text):
    sys.stderr.buffer.write((text + "\n").encode("utf-8", "replace"))
    sys.stderr.flush()


def _fail(message, code):
    sys.stderr.write(json.dumps({"error": message}) + "\n")
    sys.stderr.flush()
    sys.exit(code)


def _decode(data):
    if data[:3] == b"\xef\xbb\xbf":
        text = data[3:].decode("utf-8", "replace")
    elif data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        text = data.decode("utf-16", "replace")
    else:
        text = data.decode("utf-8", "replace")
    if text.startswith("\ufeff"):
        text = text[1:]
    return text.replace("\r\n", "\n")


def _local(tag):
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def _parse_xml(data):
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


def _cp_label(ch):
    return "U+%04X %s" % (ord(ch), unicodedata.name(ch, "UNKNOWN"))


def _excerpt(s):
    s = re.sub(r"\s+", " ", s).strip()
    return s if len(s) <= 80 else s[:77] + "..."


def _cv(vals):
    if not vals:
        return None
    mean = sum(vals) / float(len(vals))
    if mean <= 0:
        return None
    var = sum((v - mean) ** 2 for v in vals) / float(len(vals))
    return math.sqrt(var) / mean


# ---------------------------------------------------------------- extraction

def _docx_paragraph(p):
    parts = []
    for el in p.iter():
        ln = _local(el.tag)
        if ln == "t" and el.text:
            parts.append(el.text)
        elif ln == "tab":
            parts.append("\t")
        elif ln in ("br", "cr"):
            parts.append("\n")
    return "".join(parts)


def _extract_docx(zf):
    if "word/document.xml" not in zf.namelist():
        return ""
    root = _parse_xml(zf.read("word/document.xml"))
    if root is None:
        return ""
    paras = []
    for el in root.iter():
        if _local(el.tag) == "p":
            t = _docx_paragraph(el)
            if t.strip():
                paras.append(t)
    return "\n".join(paras)


def _extract_pptx(zf):
    names = [n for n in zf.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)]
    names.sort(key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
    slides = []
    for n in names:
        root = _parse_xml(zf.read(n))
        if root is None:
            continue
        paras = []
        for el in root.iter():
            if _local(el.tag) == "p":
                t = _docx_paragraph(el)
                if t.strip():
                    paras.append(t)
        if paras:
            slides.append("\n".join(paras))
    return "\n".join(slides)


def _extract_xlsx(zf):
    names = zf.namelist()
    sst = []
    if "xl/sharedStrings.xml" in names:
        root = _parse_xml(zf.read("xl/sharedStrings.xml"))
        if root is not None:
            for si in root.iter():
                if _local(si.tag) == "si":
                    sst.append("".join((t.text or "") for t in si.iter() if _local(t.tag) == "t"))
    sheets = [n for n in names if re.match(r"xl/worksheets/sheet\d+\.xml$", n)]
    sheets.sort(key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
    out = []
    for n in sheets:
        root = _parse_xml(zf.read(n))
        if root is None:
            continue
        for c in root.iter():
            if _local(c.tag) != "c":
                continue
            kind = c.get("t")
            v_text = None
            for ch in c:
                if _local(ch.tag) == "v":
                    v_text = ch.text or ""
            if kind == "s":
                if v_text is not None and re.fullmatch(r"\d+", v_text.strip()):
                    idx = int(v_text.strip())
                    if idx < len(sst):
                        out.append(sst[idx])
            elif kind == "inlineStr":
                txt = "".join((t.text or "") for t in c.iter() if _local(t.tag) == "t")
                out.append(txt)
            elif kind == "str":
                if v_text:
                    out.append(v_text)
    return "\n".join(s for s in out if s.strip())


def _odf_walk(el, out):
    ln = _local(el.tag)
    if ln == "annotation":
        return
    if ln == "s":
        n = 1
        for k, v in el.attrib.items():
            if _local(k) == "c":
                try:
                    n = int(v)
                except ValueError:
                    n = 1
        out.append(" " * max(n, 0))
        return
    if ln == "tab":
        out.append("\t")
        return
    if ln == "line-break":
        out.append("\n")
        return
    if el.text:
        out.append(el.text)
    for ch in el:
        _odf_walk(ch, out)
        if ch.tail:
            out.append(ch.tail)
    if ln in ("p", "h"):
        out.append("\n")


def _extract_odf(zf):
    if "content.xml" not in zf.namelist():
        return ""
    root = _parse_xml(zf.read("content.xml"))
    if root is None:
        return ""
    out = []
    _odf_walk(root, out)
    lines = [l for l in "".join(out).split("\n") if l.strip()]
    return "\n".join(lines)


_BLOCK_TAG = re.compile(
    r"</?(?:p|div|h[1-6]|li|br|tr|td|th|section|article|blockquote|pre|ul|ol|table|"
    r"header|footer|figure|figcaption|dt|dd|body)\b[^>]*>", re.I)


def _html_text(raw):
    s = re.sub(r"<!--.*?-->", " ", raw, flags=re.S)
    s = re.sub(r"<(script|style|head|nav|title)\b[^>]*>.*?</\1\s*>", " ", s, flags=re.S | re.I)
    s = _BLOCK_TAG.sub("\n", s)
    s = re.sub(r"<[^>]*>", "", s)
    s = _html.unescape(s)
    lines = [re.sub(r"[ \t\r\f\v]+", " ", l).strip() for l in s.split("\n")]
    return "\n".join(l for l in lines if l)


def _extract_epub(zf):
    names = zf.namelist()
    order = []
    opf = None
    if "META-INF/container.xml" in names:
        m = re.search(r"full-path\s*=\s*[\"']([^\"']+)[\"']", zf.read("META-INF/container.xml").decode("utf-8", "replace"))
        if m:
            opf = m.group(1)
    if opf and opf in names:
        s = zf.read(opf).decode("utf-8", "replace")
        manifest = {}
        for m in re.finditer(r"<item\b([^>]*)>", s):
            attrs = dict(re.findall(r"([\w:.-]+)\s*=\s*[\"']([^\"']*)[\"']", m.group(1)))
            if "id" in attrs and "href" in attrs:
                manifest[attrs["id"]] = attrs["href"]
        base = posixpath.dirname(opf)
        for idref in re.findall(r"<itemref\b[^>]*idref\s*=\s*[\"']([^\"']+)[\"']", s):
            href = manifest.get(idref)
            if href:
                order.append(posixpath.normpath(posixpath.join(base, href)))
    candidates = [n for n in order if n in names]
    if not candidates:
        candidates = sorted(n for n in names if n.lower().endswith((".xhtml", ".html", ".htm")))
    chapters = []
    for n in candidates:
        raw = zf.read(n).decode("utf-8", "replace")
        if re.search(r"epub:type\s*=\s*[\"'][^\"']*\bnav\b", raw):
            continue
        text = _html_text(raw)
        if text:
            chapters.append(text)
    return "\n".join(chapters)


def _notebook_text(data):
    try:
        nb = json.loads(_decode(data))
    except ValueError:
        return ""
    if not isinstance(nb, dict):
        return ""
    cells = nb.get("cells")
    if not isinstance(cells, list):
        return ""
    out = []
    for cell in cells:
        if not isinstance(cell, dict):
            return ""
        if cell.get("cell_type") != "markdown":
            continue
        src = cell.get("source", "")
        if isinstance(src, list):
            if not all(isinstance(x, str) for x in src):
                return ""
            src = "".join(src)
        if not isinstance(src, str):
            return ""
        if src.strip():
            out.append(src.rstrip())
    return "\n".join(out)


def read_source(path):
    """Return the extracted prose for a path (or standard input when path is None)."""
    if path is None:
        return _decode(sys.stdin.buffer.read())
    ext = os.path.splitext(path)[1].lower()
    if os.path.isdir(path):
        _fail("cannot read input: %s (is a directory)" % path, 1)
    try:
        with open(path, "rb") as fh:
            data = fh.read()
    except OSError as exc:
        _fail("cannot read input: %s (%s)" % (path, exc.strerror or "unreadable"), 1)
    if ext in NO_TEXT_EXTS:
        return ""
    if ext in NOTEBOOK_EXTS:
        return _notebook_text(data).strip()
    if ext in ZIP_EXTS:
        try:
            zf = zipfile.ZipFile(io.BytesIO(data))
        except (zipfile.BadZipFile, OSError):
            _fail("cannot read input: %s (not a readable zip archive)" % path, 1)
        try:
            with zf:
                if ext in (".docx", ".docm"):
                    text = _extract_docx(zf)
                elif ext in (".pptx", ".pptm"):
                    text = _extract_pptx(zf)
                elif ext in (".xlsx", ".xlsm"):
                    text = _extract_xlsx(zf)
                elif ext == ".epub":
                    text = _extract_epub(zf)
                else:
                    text = _extract_odf(zf)
        except Exception:  # corrupt member data counts as an unreadable archive
            _fail("cannot read input: %s (not a readable zip archive)" % path, 1)
        return text.strip()
    return _decode(data)


# ---------------------------------------------------------------- character layer

_RTL = re.compile(u"[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]")


def _is_cjk(cp):
    return (0x3040 <= cp <= 0x30FF or 0x3400 <= cp <= 0x4DBF or 0x4E00 <= cp <= 0x9FFF
            or 0xF900 <= cp <= 0xFAFF or 0x20000 <= cp <= 0x2FFFF)


def _is_nospace_script(cp):
    return (0x0E00 <= cp <= 0x0EFF or 0x1000 <= cp <= 0x109F or 0x1780 <= cp <= 0x17FF
            or 0x3040 <= cp <= 0x30FF or _is_cjk(cp))


def _is_joining(cp):
    return (0x0590 <= cp <= 0x06FF or 0x0750 <= cp <= 0x077F or 0x08A0 <= cp <= 0x08FF
            or 0x0900 <= cp <= 0x0DFF or 0x1000 <= cp <= 0x109F or 0x1780 <= cp <= 0x17FF
            or 0xFB50 <= cp <= 0xFDFF or 0xFE70 <= cp <= 0xFEFF)


def _is_pictographic(cp):
    return (cp in (0xA9, 0xAE, 0x203C, 0x2049, 0x2122, 0x2139, 0x3030, 0x303D)
            or 0x2194 <= cp <= 0x21AA or 0x231A <= cp <= 0x23FF or 0x25AA <= cp <= 0x25FE
            or 0x2600 <= cp <= 0x27BF or 0x2B05 <= cp <= 0x2B55
            or 0x1F000 <= cp <= 0x1FAFF)


def _is_symbolish(ch):
    if not ch:
        return False
    cp = ord(ch)
    return _is_pictographic(cp) or unicodedata.category(ch) in ("So", "Sk")


def _is_tag(cp):
    return 0xE0020 <= cp <= 0xE007F


def _invisible_candidate(cp):
    if cp in (9, 10, 13):
        return False
    if cp < 32 or 127 <= cp <= 159:
        return True
    if 0xE0000 <= cp <= 0xE0FFF or 0xFE00 <= cp <= 0xFE0F:
        return True
    if cp in (0x115F, 0x1160, 0x3164, 0xFFA0, 0x034F, 0x17B4, 0x17B5):
        return True
    if 0x180B <= cp <= 0x180F:
        return True
    return unicodedata.category(chr(cp)) == "Cf"


def _invisible_kept(s, i, doc_rtl):
    cp = ord(s[i])
    prev = s[i - 1] if i > 0 else ""
    nxt = s[i + 1] if i + 1 < len(s) else ""
    pcp = ord(prev) if prev else -1
    ncp = ord(nxt) if nxt else -1
    if cp == 0x00AD:
        return bool(prev) and bool(nxt) and prev.isalpha() and nxt.isalpha()
    if cp == 0x200B:
        return (pcp >= 0 and _is_nospace_script(pcp)) or (ncp >= 0 and _is_nospace_script(ncp))
    if cp in (0x200C, 0x200D):
        return ((pcp >= 0 and _is_joining(pcp)) or (ncp >= 0 and _is_joining(ncp))
                or _is_symbolish(prev) or _is_symbolish(nxt))
    if cp in (0x200E, 0x200F, 0x061C) or 0x202A <= cp <= 0x202E or 0x2066 <= cp <= 0x2069:
        return doc_rtl
    if 0x180B <= cp <= 0x180F:
        return 0x1800 <= pcp <= 0x18AF
    if cp in (0x17B4, 0x17B5):
        return (0x1780 <= pcp <= 0x17FF) or (0x1780 <= ncp <= 0x17FF)
    if 0xE0100 <= cp <= 0xE01EF:
        return _is_cjk(pcp)
    if 0xFE00 <= cp <= 0xFE0F:
        return _is_symbolish(prev) or _is_cjk(pcp) or ncp == 0x20E3
    if _is_tag(cp):
        j = i - 1
        while j >= 0 and _is_tag(ord(s[j])):
            j -= 1
        return j >= 0 and ord(s[j]) == 0x1F3F4
    return False


def _invisible_indices(s):
    doc_rtl = bool(_RTL.search(s))
    removed = []
    for i, ch in enumerate(s):
        cp = ord(ch)
        if 32 <= cp < 127:
            continue
        if _invisible_candidate(cp) and not _invisible_kept(s, i, doc_rtl):
            removed.append(i)
    return removed


def _nbsp_kept(s, i):
    prev = s[i - 1] if i > 0 else ""
    nxt = s[i + 1] if i + 1 < len(s) else ""
    return ((prev and prev.isdigit()) or (nxt and nxt.isdigit())
            or (nxt and nxt in ":;!?\u00bb\u203a%\u20ac") or (prev and prev in "\u00ab\u2039"))


def _nonstandard_space_hits(s):
    hits = []
    for i, ch in enumerate(s):
        if ord(ch) < 128:
            continue
        if unicodedata.category(ch) == "Zs":
            if ord(ch) in (0xA0, 0x202F) and _nbsp_kept(s, i):
                continue
            hits.append(_cp_label(ch))
    return hits


_CONFUSABLE = {}
for _cp, _latin in [
    (0x0430, "a"), (0x0441, "c"), (0x0501, "d"), (0x0435, "e"), (0x04BB, "h"), (0x0456, "i"),
    (0x0458, "j"), (0x043E, "o"), (0x0440, "p"), (0x0455, "s"), (0x0443, "y"), (0x0475, "v"),
    (0x0445, "x"), (0x0585, "o"), (0x057D, "u"), (0x03BF, "o"), (0x03F2, "c"), (0x03F3, "j"),
    (0x03C1, "p"), (0x03BD, "v"), (0x0410, "A"), (0x0412, "B"), (0x0421, "C"), (0x0415, "E"),
    (0x041D, "H"), (0x0406, "I"), (0x0408, "J"), (0x041A, "K"), (0x041C, "M"), (0x041E, "O"),
    (0x0420, "P"), (0x0405, "S"), (0x0422, "T"), (0x0425, "X"), (0x04AE, "Y"), (0x04C0, "I"),
    (0x0391, "A"), (0x0392, "B"), (0x0395, "E"), (0x0396, "Z"), (0x0397, "H"), (0x0399, "I"),
    (0x039A, "K"), (0x039C, "M"), (0x039D, "N"), (0x039F, "O"), (0x03A1, "P"), (0x03A4, "T"),
    (0x03A7, "X"), (0x03A5, "Y")]:
    _CONFUSABLE[_cp] = _latin


def _fold_token(tok):
    """Return (folded token, lookalike count); a token is folded only if it qualifies."""
    if not re.search(r"[A-Za-z]", tok):
        return tok, 0
    n = 0
    other = False
    for ch in tok:
        if ord(ch) < 128:
            continue
        if ord(ch) in _CONFUSABLE:
            n += 1
        elif ch.isalpha():
            other = True
    if n == 0 or other:
        return tok, 0
    return "".join(_CONFUSABLE.get(ord(c), c) for c in tok), n


def _homoglyph_hits(s):
    hits = []
    for m in re.finditer(r"\S+", s):
        _, n = _fold_token(m.group(0))
        if n:
            hits.append(m.group(0)[:40])
    return hits


def scrub(text):
    """Cleanup: scrubbed text for --clean."""
    had_lf = text.endswith("\n")
    s = text.replace("\r\n", "\n").replace("\r", "\n")
    removed = set(_invisible_indices(s))
    out = []
    for i, ch in enumerate(s):
        if i in removed:
            continue
        cp = ord(ch)
        if cp < 128:
            out.append(ch)
            continue
        cat = unicodedata.category(ch)
        if cat == "Zs":
            if cp in (0xA0, 0x202F) and _nbsp_kept(s, i):
                out.append(ch)
            else:
                out.append(" ")
        elif cat in ("Zl", "Zp"):
            out.append("\n")
        else:
            out.append(ch)
    folded = re.sub(r"\S+", lambda m: _fold_token(m.group(0))[0], "".join(out))
    lines = [l.rstrip(" \t") for l in folded.split("\n")]
    while lines and lines[0] == "":
        lines.pop(0)
    body = "\n".join(lines).rstrip()
    if body and had_lf:
        body += "\n"
    return body


# ---------------------------------------------------------------- structure

HEAD_RE = re.compile(r"^\s{0,3}#{1,6}\s+(.*?)\s*#*\s*$")
LIST_RE = re.compile(r"^\s*(?:[-*+]|\d+[.)])\s+")
HR_RE = re.compile(r"^ {0,3}([-*_])(?:[ \t]*\1){2,}[ \t]*$")
FENCE_OPEN_RE = re.compile(r"^ {0,3}(`{3,}|~{3,})(.*)$")
FENCE_CLOSE_RE = re.compile(r"^ {0,3}(`{3,}|~{3,})[ \t]*$")
BLOCKQUOTE_RE = re.compile(r"^\s{0,3}>")
BADGE_RE = re.compile(r"^\s*(?:\[!\[[^\]\n]*\]\([^)\n]*\)\]\([^)\n]*\)\s*)+$")
TABLE_SEP_RE = re.compile(r"^\s*\|?\s*:?-{2,}:?\s*(?:\|\s*:?-{2,}:?\s*)+\|?\s*$")
WORD_RE = re.compile(r"[^\W_]+(?:['\u2019-]+[^\W_]+)*")
SENT_SPLIT_RE = re.compile(r"(?<=[.!?])\s+")


def build_view(text):
    """Blank out spans that never yield findings: front matter, fenced code,
    blockquote runs, table rows, badge lines; blank inline code spans."""
    lines = text.split("\n")
    n = len(lines)
    excluded = [False] * n
    if n >= 2 and lines[0].strip() == "---":
        for j in range(1, n):
            if lines[j].strip() in ("---", "..."):
                for k in range(0, j + 1):
                    excluded[k] = True
                break
    i = 0
    while i < n:
        m = FENCE_OPEN_RE.match(lines[i])
        if m and not (m.group(1)[0] == "`" and "`" in m.group(2)):
            fence = m.group(1)
            ch, flen = fence[0], len(fence)
            end = n - 1
            j = i + 1
            while j < n:
                cm = FENCE_CLOSE_RE.match(lines[j])
                if cm and cm.group(1)[0] == ch and len(cm.group(1)) >= flen:
                    end = j
                    break
                j += 1
            for k in range(i, end + 1):
                excluded[k] = True
            i = end + 1
        else:
            i += 1
    i = 0
    while i < n:
        if BLOCKQUOTE_RE.match(lines[i]) and not excluded[i]:
            j = i
            while j < n and BLOCKQUOTE_RE.match(lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    excluded[k] = True
            i = j
        else:
            i += 1
    for k, l in enumerate(lines):
        s = l.strip()
        if s.startswith("|") and s.count("|") >= 2:
            excluded[k] = True
        elif TABLE_SEP_RE.match(l) and "|" in l:
            excluded[k] = True
        elif BADGE_RE.match(l):
            excluded[k] = True
    out = []
    for k, l in enumerate(lines):
        if excluded[k]:
            out.append("")
        else:
            out.append(re.sub(r"`[^`\n]+`", lambda m: " " * len(m.group(0)), l))
    return "\n".join(out)


class _Ctx(object):
    pass


def make_ctx(view, raw):
    c = _Ctx()
    c.view = view
    c.raw = raw
    c.lines = view.split("\n")
    c.word_count = len(WORD_RE.findall(view))
    c.paras = [p for p in re.split(r"\n\s*\n", view) if p.strip()]
    c.para_wc = []
    c.para_sents = []
    c.sents = []
    for p in c.paras:
        c.para_wc.append(len(WORD_RE.findall(p)))
        prose = [l.strip() for l in p.split("\n")
                 if l.strip() and not HEAD_RE.match(l) and not LIST_RE.match(l)
                 and not l.lstrip().startswith(("|", ">")) and not HR_RE.match(l)]
        ps = []
        for s in SENT_SPLIT_RE.split(" ".join(prose)):
            if WORD_RE.search(s):
                ps.append(s)
        c.para_sents.append(ps)
        c.sents.extend(ps)
    c.sent_wc = [len(WORD_RE.findall(s)) for s in c.sents]
    return c


# ---------------------------------------------------------------- pattern rules

def _alt(words):
    return "|".join(re.escape(w) for w in sorted(words, key=len, reverse=True))


def _wb(words, flags=re.I):
    return re.compile(r"\b(?:" + _alt(words) + r")\b", flags)


def _hits(rx, text):
    return [m.group(0) for m in rx.finditer(text)]


A1_WORDS = [
    "additionally", "align with", "aligns with", "aligned with", "crucial", "delve", "delves", "delved",
    "delving", "tapestry", "pivotal", "vibrant", "meticulous", "meticulously", "testament", "underscore",
    "underscores", "underscored", "underscoring", "intricate", "intricacies", "interplay", "garner",
    "garners", "garnered", "garnering", "bolster", "bolsters", "bolstered", "bolstering", "foster",
    "fosters", "fostered", "fostering", "showcase", "showcases", "showcased", "showcasing", "emphasize",
    "emphasizes", "emphasized", "emphasizing", "enduring", "enhance", "enhances", "enhanced", "enhancing",
    "leverage", "leverages", "leveraged", "leveraging", "utilize", "utilizes", "utilized", "utilizing",
    "facilitate", "facilitates", "facilitated", "facilitating", "encompass", "encompasses", "encompassed",
    "encompassing", "harness", "harnesses", "harnessed", "harnessing", "holistic", "paradigm", "paradigms",
    "transformative", "unprecedented", "myriad", "plethora", "robust", "seamless", "seamlessly", "navigate",
    "navigates", "navigating", "navigated", "embark", "embarks", "embarked", "embarking", "craft", "crafts",
    "crafted", "crafting", "landscape", "landscapes", "journey", "journeys", "realm", "realms",
    "multifaceted", "elevate", "elevates", "elevated", "elevating", "empower", "empowers", "empowered",
    "empowering", "unlock", "unlocks", "unlocked", "unlocking",
]
R1 = _wb(A1_WORDS)
R1_ESSENCE = re.compile(r"\bcaptur(?:e|es|ed|ing) the (?:essence|spirit|imagination|heart|magic)\b", re.I)

R2 = [re.compile(p, re.I) for p in [
    r"\bgenuinely\b", r"\bfascinating\b", r"\bnuanced\b", r"\bthoughtfully\b", r"\brefreshingly\b",
    r"\bstrikingly\b", r"\bcompellingly\b", r"\bquietly (?:powerful|profound|radical)\b",
    r"\bdeeply (?:human|personal|felt|unsettling)\b", r"\bresonates? deeply\b", r"\bgame-chang\w*",
    r"\bsupercharg\w*", r"\bskyrocket\w*", r"\bturbocharg\w*", r"\brevolutioniz\w*", r"\bdouble down on\b",
    r"\bdive deep(?:er)? into\b", r"\bunlock(?:s|ed|ing)? (?:the )?(?:power|potential|value)\b",
    r"\btakes? [\w' ,-]{1,40}? to the next level\b"]]

R3_PHRASES = re.compile(r"(?i:\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|"
                        r"vibrant community|rich cultural heritage|in the heart of|world-class|top-tier|"
                        r"unparalleled|premier|leading|esteemed organization|valuable asset|passion for excellence|"
                        r"proven track record|results-oriented|wealth of experience|dynamic team|"
                        r"fast-paced environment|deeply passionate|perfectly situated|close-knit team|"
                        r"tight-knit team|i am excited to apply|i am excited to bring|i'm excited to apply|"
                        r"i'm excited to bring|uniquely positioned to)\b)")
R3_IMPERATIVE = re.compile(r"^(?:install|join|grab|download|try|discover|experience|escape|transform|reclaim|"
                           r"unlock|elevate|boost|say|imagine|explore|meet|introducing|upgrade|claim|unleash|"
                           r"supercharge|level|stop|start)\b", re.I)

R4 = _wb(["cutting-edge", "state-of-the-art", "best-in-class", "next-gen", "next-generation",
          "results-driven", "data-driven", "customer-centric", "client-centric", "user-centric",
          "industry-leading", "forward-thinking", "high-performing", "top-notch"])

R5 = re.compile(r"\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b", re.I)

STOCK_ADJ = frozenset(["robust", "seamless", "comprehensive", "powerful", "innovative", "dynamic", "elegant",
                       "vibrant", "intuitive", "scalable", "efficient", "reliable", "premier", "unparalleled",
                       "transformative", "holistic", "meticulous", "pivotal", "crucial", "essential",
                       "engaging", "compelling", "cutting-edge"])
ADJ_SUFFIX = re.compile(r"(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$", re.I)
CHAIN_RE = re.compile(r"\b[A-Za-z][\w'-]*(?:,\s+(?:and\s+)?[A-Za-z][\w'-]*){3}\b")

CLUSTERS = [
    ["protagonist", "main character", "central figure", "hero", "heroine"],
    ["company", "firm", "organization", "enterprise", "business"],
    ["author", "writer", "novelist", "scribe"],
    ["report", "study", "analysis", "investigation", "examination"],
    ["technology", "tool", "system", "platform", "solution"],
    ["technique", "method", "approach", "strategy", "tactic"],
    ["challenge", "obstacle", "difficulty", "hurdle", "barrier"],
    ["benefit", "advantage", "upside", "strength"],
]
CLUSTER_RX = [[(w, re.compile(r"\b" + re.escape(w) + r"s?\b", re.I)) for w in cl] for cl in CLUSTERS]

R10 = [re.compile(p, re.I) for p in [
    r"\b(?:stands?|serves?|stood|served) as an? (?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b",
    r"\b(?:underscor\w*|highlight\w*) (?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b",
    r"\breflects? a broader (?:trend|shift|pattern)\b",
    r"\bmarks? an? (?:turning point|milestone|watershed|new chapter|new era)\b",
    r"\bsymboli[sz]es\b", r"\bsets? the stage for\b", r"\bleft an indelible mark\b",
    r"\bplays? an? (?:crucial|pivotal|vital|key|central|significant) role\b",
    r"\bhas (?:shaped|sparked)\b", r"\bhas come to (?:define|symboli[sz]e)\b"]]

R11 = [
    re.compile(r"(?i:\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by)) "
               r"(?:[A-Z][\w&.'-]*(?:,\s*|\s+and\s+|\s+or\s+)){1,}[A-Z][\w&.'-]*"),
    re.compile(r"\b\d[\d,.]*\s*[kKmM]?\+?\s+(?:followers|subscribers)\b"),
    re.compile(r"(?i:\bstrong (?:online|digital|social media|social) presence\b|"
               r"\bactive (?:online|digital|social media) presence\b|\bwidely covered\b|\bindependent coverage\b)"),
]

R12 = re.compile(r"(?i:\bexperts? (?:argue|believe|say|claim|note|suggest)\b|\bindustry (?:reports|observers|analysts)\b|"
                 r"\bobservers have (?:cited|noted)\b|\bsome critics argue\b|\bresearchers have found\b|"
                 r"\bstudies suggest\b|\bit is widely believed\b)")

R13 = re.compile(r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of (?:[\w'\u2019-]+\s+){0,6}?(?:is|are) (?:a|an|the)\b")

R14 = re.compile(r"(?i:\bplays? a (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b|"
                 r"\bconservation efforts are (?:underway|ongoing|in place)\b|\bserves as an indicator species\b|"
                 r"\bcontributes to biodiversity\b)")

R15 = [re.compile(r"(?i:\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]*?"
                  r"\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b)"),
       re.compile(r"(?i:\bfrom (?:the )?humble\b[^.!?\n]*?\bto (?:the )?(?:mighty|towering|grand|sprawling)\b)")]

R16 = re.compile(r"(?i:,\s+(?:highlighting|reflecting|symboli[sz]ing|emphasi[sz]ing|underscoring|showcasing|"
                 r"fostering|cultivating|encompassing|signaling|demonstrating|illustrating|representing|"
                 r"suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b)")

R17_PARALLEL = [re.compile(p, re.I) for p in [
    r"\bit['\u2019]s not (?:just|merely) (?:about|an?)\b",
    r"\bnot only\b[^.!?\n]{0,40}\bbut\b",
    r"\bdoesn['\u2019]t just\b[^,.\n]{0,40}\bit\b"]]
R17_TAIL = re.compile(r"(?i:,\s+no\s+(?:guessing|wasted motion|waste|hassle|fluff|stress|jargon)\b)")

R18 = [re.compile(p, re.I) for p in [
    r"\b(?:no|not) \w+,\s+(?:just|only|simply) \w+",
    r"\b(?:not|isn['\u2019]t|aren['\u2019]t|wasn['\u2019]t|weren['\u2019]t) (?:just|merely) (?:(?:a|an|the) )?\w+"
    r"(?:,|\s*[\u2014\u2013-])\s*(?:it['\u2019]s|it is|it was|they['\u2019]re|they are|they were|that['\u2019]s|but)\b"]]

R19 = re.compile(r"(?i:\bin order to\b|\bdue to the fact that\b|\bat this point in time\b|\bin the event that\b|"
                 r"\bhas the ability to\b|\bit is important to note that\b|\bit should be mentioned that\b|\bneedless to say\b)")

R20 = re.compile(r"(?i:\bit['\u2019]s worth (?:noting|mentioning) that\b|\bit bears (?:noting|mentioning) that\b|"
                 r"\bone thing to (?:consider|keep in mind) is\b|\bit is interesting to note that\b|"
                 r"\ba key consideration is\b|\ba point to highlight is\b)")

R21 = re.compile(r"(?i:,\s+(?:raising questions about|prompting reflection on|sparking debate about|"
                 r"with broader implications for|reshaping our understanding of|paving the way for|"
                 r"signaling a shift toward)\b)")

R22 = re.compile(r"(?i:\bhere['\u2019]s the thing\b|\bmake no mistake\b|\bthe truth is\b|\blet['\u2019]s be honest\b|"
                 r"\bthe simple fact is\b|\bat its core\b|\bwhat really matters\b|\bmore than anything\b|"
                 r"\bat the end of the day\b|\bthe bottom line is\b|\bin reality\b|\bfundamentally,|"
                 r"\bthe real question is\b|\bthe heart of the matter\b|\bthe deeper issue\b|"
                 r"\bwhen you get down to it\b|\bwhen all is said and done\b)")

R23 = re.compile(r"(?i:\bit(?:['\u2019]s| is) important to (?:remember|note|understand|recognize)\b|"
                 r"\bone must note that\b|\bit is worth pointing out\b|\bit cannot be overstated that\b|"
                 r"\bit must be emphasi[sz]ed that\b)")

R24 = re.compile(r"(?i:\bthis comprehensive (?:guide|overview|analysis)\b|\bthis in-depth (?:analysis|look|examination)\b|"
                 r"\bthis complete (?:guide|overview)\b|\ba thorough examination of\b|"
                 r"\beverything you need to know about\b)")

R25 = re.compile(r"(?:^|(?<=[.!?]\s))(?:Is|Are|Can|Could|Do|Does|Did|Will|Would|Should|Has|Have|Was|Were|Am|May|Might|Must)"
                 r"\s[^.?!\n]{1,80}\?\s+(?i:yes|no|absolutely|never|maybe|probably|always)[.!]", re.M)

R26 = re.compile(r"(?i:\bwithout concrete (?:evidence|proof)\b|\bdo you have concrete evidence\b|"
                 r"\bi (?:would )?need concrete (?:evidence|examples)\b|\babsent concrete proof\b|"
                 r"\bprovide concrete evidence\b)")

R27 = re.compile(r"(?i:\bin today['\u2019]s (?:\w+\s+){0,2}?(?:world|landscape|environment|market)\b|"
                 r"\bin a world where\b|\bin an era of\b|\bin recent years,|\bmore than ever before\b|"
                 r"\bwe live in a (?:time|world) when\b|\b(?:great|exciting|big) news\s*[!:]|"
                 r"\bever (?:wanted|wondered|dreamed|wished)\b[^?\n]{0,80}\?|"
                 r"\bin an increasingly (?:interconnected|digital|competitive|complex) world\b)")

R30 = [re.compile(p, re.I) for p in [
    r"\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b",
    r"\b(?:the|this) (?:latest |new )?(?:update|release|version|change|patch|design) "
    r"(?:adds|introduces|brings|delivers|includes|provides|improves)\b",
    r"\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed to)\b",
    r"\bpreviously\b[^.!?\n]*\bnow\b",
    r"\b(?:wasn['\u2019]t|weren['\u2019]t) there before\b",
    r"\bwe(?:['\u2019]ve| have) (?:now )?(?:added|removed|replaced|refactored|migrated)\b"]]

R31 = re.compile(r"(?i:\blet['\u2019]s (?:dive|delve|explore)\b|\blet['\u2019]s break (?:this|it) down\b|"
                 r"\bhere['\u2019]s what you need to know\b|\bwithout further ado\b|\bnow let['\u2019]s look at\b|"
                 r"\bbuckle up\b|\bstay with me\b|\bready to dive in\b)")

R32 = [re.compile(r"\b(?:used|uses|employs|employed|relied on|utili[sz]es)\s+(?:several|various|a number of|multiple|"
                  r"different|many|numerous)\s+\w+", re.I),
       re.compile(r"(?:^|(?<=[.!?]\s))These\s+(?:\w+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help)\s+"
                  r"(?:\w+\s+)?(?:information|insight|understanding|details|data)\b", re.M),
       re.compile(r"\b(?:is|are|was|were|remains|becomes)\s+(?:the\s+|a\s+)?(?:language|currency|architecture|"
                  r"heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue)\s+of\b", re.I)]

R33 = re.compile(r"(?m)^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?\*\*[^*\n]+(?::\*\*|\*\*:)")

R36 = re.compile(r"(?i:\bdespite (?:these|its|the) (?:challenges|obstacles)\b|"
                 r"\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b|\bcontinues to thrive\b|"
                 r"\btypical of (?:emerging|urban|modern)\b|\bfaces (?:several|many|numerous) challenges\b)")

TRANS_RE = re.compile(r"(?:^|(?<=[.!?]\s))(?:Additionally|Furthermore|Moreover|However|Nevertheless|"
                      r"Consequently|Subsequently|Notably)\b", re.M)

R38 = re.compile(r"(?im)^\s*(?:in conclusion|overall|in summary|to summari[sz]e|to conclude|all in all|"
                 r"in essence|ultimately)\b")

R39 = re.compile(r"(?i:\bthe future looks bright\b|\bexciting times lie ahead\b|\bjourney toward excellence\b|"
                 r"\bstep in the right direction\b|\b(?:the )?(?:outlook|future)(?: for [\w ]{1,30})? (?:is|looks|remains) bright\b|"
                 r"\bwell[- ]positioned (?:for|to) (?:whatever comes next|the future|the road ahead)\b)")

R40_NONE = None

R42_ADV = None

R47 = [re.compile(p, re.I) for p in [
    r"\bI hope this helps\b", r"\bI hope (?:this email )?finds you well\b", r"\blet me know if you\b",
    r"\bwould you like me to\b", r"\bfeel free to (?:ask|reach out)\b", r"\bhappy to help[.!]",
    r"\bhere (?:is|are|['\u2019]s) (?:a|an|the) (?:overview|summary|rundown|recap|brief)\b",
    r"\bhere (?:are|['\u2019]s) (?:a few |some |two |three )?(?:options|drafts|versions|variations)\b",
    r"\bhere (?:is|['\u2019]s) (?:a )?draft\b", r"\bdepending on the (?:vibe|tone|style)\b",
    r"\bas an (?:AI|LLM|AI assistant|AI language model|large language model|language model)\b",
    r"\bto (?:answer|address) your question\b", r"\bin (?:response|answer) to your question\b",
    r"\byour question (?:about|regarding|concerning)\b", r"\bas (?:you )?(?:requested|asked),? here\b",
    r"\bhere is (?:the )?(?:draft|first pass|revised version) (?:of|for your)\b"]]
R47_CAP = re.compile(r"(?:Certainly|Of course)!")

R48 = [re.compile(p, re.I) for p in [
    r"\byou(?:['\u2019]re| are) absolutely right\b",
    r"\b(?:great|excellent|good|fantastic|wonderful|brilliant|thoughtful|interesting) (?:question|point)[!.,]",
    r"\bwhat a (?:thoughtful|great|wonderful|fantastic) question\b",
    r"\bthat['\u2019]s a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b"]]

R50 = [re.compile(p, re.I) for p in [
    r"\bas of my (?:last )?(?:training|knowledge)\b", r"\bup to my (?:last )?(?:training|knowledge)\b",
    r"\bwhile specific details are (?:limited|scarce|not (?:extensively |widely )?documented)\b",
    r"\bbased on (?:the )?available information\b", r"\bmaintains a low profile\b",
    r"\bkeeps (?:his|her|their) personal life private\b"]]

R51 = [re.compile(p, re.I) for p in [
    r"\b(?:serves|stands|functions|acts) as\b", r"\b(?:represents|marks) (?:an?|the)\b", r"\bboasts\b",
    r"\bfeatures (?:an?|the|\d+|several|many|numerous)\b", r"\boffers an? ", r"\brefers to\b"]]

HEDGE_RE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively|fairly)\b"
                      r"|\bseems? (?:to|like)\b|\bappears? to\b|\bkind of\b|\bsort of\b")

FP_RE = re.compile(r"\b(?:I|me|my|we|us|our)\b")
FULL_FORMS_RE = re.compile(r"\b(?:I am|I have|I will|I would|I do not|I did not|I cannot|do not|does not|did not|"
                           r"is not|are not|was not|were not|will not|would not|cannot|it is|that is|there is|"
                           r"we are|we have|we will|they are|you are|let us|I had|it has|that has|I want|I need)\b", re.I)
CONTR_RE = re.compile(r"\b\w+['\u2019](?:t|s|re|ve|ll|d|m)\b", re.I)

BOLD_RE = re.compile(r"\*\*[^*\n]+?\*\*")
EMOJI_RE = re.compile(u"[\U0001F000-\U0001FAFF\u2600-\u27BF\u2B50\u2B55]")
CURLY_RE = re.compile(u"[\u201C\u201D\u2018\u2019]")
YEAR_RANGE_RE = re.compile(r"\b(1[89]\d\d|20\d\d|21\d\d)-(1[89]\d\d|20\d\d|21\d\d)\b")

PLACEHOLDER_RES = [
    re.compile(r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]{0,80}\](?![(\[])", re.I),
    re.compile(r"\[(?:company|client|person|name|place|source|product|organi[sz]ation|customer|author)\b[^\]\n]{0,40}\](?![(\[])", re.I),
    re.compile(r"\[(?=[A-Z0-9 _-]*[A-Z]{3})[A-Z0-9 _-]+\](?![(\[])"),
    re.compile(r"\{\{[^{}\n]*\}\}"),
    re.compile(r"(?<![A-Za-z])[xX]{3,}(?![A-Za-z])"),
    re.compile(r"lorem ipsum", re.I),
]
CHAT_MARKUP_RES = [
    re.compile(r"\bcite(?:turn|start|nav)\w*", re.I),
    re.compile(r"\boai_citation\w*"),
    re.compile(r"contentReference"),
    re.compile(r"navlist"),
    re.compile(u"\u3010\\d+\u2020[^\u3011\n]*\u3011"),
]
UTM_RE = re.compile(r"utm_source=(?:chatgpt\.com|chat\.openai\.com|perplexity\.ai|claude\.ai|gemini\.google\.com|"
                    r"copilot\.microsoft\.com|poe\.com)(?![A-Za-z0-9-]|\.[A-Za-z0-9-])", re.I)

R69 = re.compile(r"(?i:\bunlocking (?:full )?potential\b|\bnavigating the complexities\b|"
                 r"\ba testament to the (?:power|importance) of\b|\bstaying ahead of the curve\b|"
                 r"\bturning challenges into opportunities\b|\btaking (?:\w+ )?to the next level\b|"
                 r"\bharnessing the power of\b|\bpaving the way for\b|\bsaying goodbye to\b|"
                 r"\bimagining a world where\b)")

MINOR_WORDS = frozenset(["a", "an", "the", "and", "but", "or", "nor", "for", "so", "yet", "at", "by", "in", "of",
                         "on", "to", "up", "as", "via", "vs", "per", "from", "with", "into", "onto", "off", "over"])


def _r1(c):
    return _hits(R1, c.view) + _hits(R1_ESSENCE, c.view)


def _r2(c):
    hits = []
    for rx in R2:
        hits.extend(_hits(rx, c.view))
    return hits if len(hits) >= 2 else []


def _r3(c):
    hits = _hits(R3_PHRASES, c.view)
    imperative = [s for s in c.sents if R3_IMPERATIVE.match(s)]
    if len(imperative) >= 3:
        hits.extend(imperative)
    return hits


def _r4(c):
    return _hits(R4, c.view)


def _r5(c):
    return _hits(R5, c.view)


def _r6(c):
    hits = []
    for m in CHAIN_RE.finditer(c.view):
        words = re.split(r",\s+(?:and\s+)?", m.group(0))
        if any(w.lower() in STOCK_ADJ or ADJ_SUFFIX.search(w) for w in words):
            hits.append(m.group(0))
    return hits


def _r8(c):
    hits = []
    for cluster in CLUSTER_RX:
        used = [w for w, rx in cluster if rx.search(c.view)]
        if len(used) >= 3:
            hits.append(" / ".join(used))
    return hits


def _r10(c):
    hits = []
    for rx in R10:
        hits.extend(_hits(rx, c.view))
    return hits


def _r11(c):
    hits = []
    for rx in R11:
        hits.extend(_hits(rx, c.view))
    return hits


def _r12(c):
    return _hits(R12, c.view)


def _r13(c):
    return _hits(R13, c.raw)


def _r14(c):
    return _hits(R14, c.view)


def _r15(c):
    hits = []
    for rx in R15:
        hits.extend(_hits(rx, c.view))
    return hits


def _r16(c):
    return _hits(R16, c.view)


def _r17_parallel(c):
    hits = []
    for rx in R17_PARALLEL:
        hits.extend(_hits(rx, c.view))
    return hits


def _r17_tail(c):
    return _hits(R17_TAIL, c.view)


def _r18(c):
    hits = []
    for rx in R18:
        hits.extend(_hits(rx, c.view))
    return hits


def _r19(c):
    return _hits(R19, c.view)


def _r20(c):
    return _hits(R20, c.view)


def _r21(c):
    return _hits(R21, c.view)


def _r22(c):
    return _hits(R22, c.view)


def _r23(c):
    return _hits(R23, c.view)


def _r24(c):
    return _hits(R24, c.view)


def _r25(c):
    return _hits(R25, c.view)


def _r26(c):
    return _hits(R26, c.view)


def _r27(c):
    return _hits(R27, c.view)


def _r30(c):
    hits = []
    for rx in R30:
        hits.extend(_hits(rx, c.view))
    return hits


def _r31(c):
    return _hits(R31, c.view)


def _r32(c):
    hits = []
    for rx in R32:
        hits.extend(_hits(rx, c.view))
    return hits


def _r33(c):
    return _hits(R33, c.view)


def _r34(c):
    if any(HEAD_RE.match(l) for l in c.lines):
        return []
    list_paras = 0
    prose_paras = 0
    for p in c.paras:
        ls = [l for l in p.split("\n") if l.strip()]
        if ls and all(LIST_RE.match(l) for l in ls):
            list_paras += 1
        else:
            prose_paras += 1
    if list_paras >= 1 and prose_paras >= 2:
        return ["bulleted list paragraph"] * list_paras
    return []


def _r35(c):
    hits = []
    lines = c.lines
    for i, l in enumerate(lines):
        m = HEAD_RE.match(l)
        if not m:
            continue
        head_words = set(w.lower() for w in WORD_RE.findall(m.group(1)) if len(w) >= 3)
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if HEAD_RE.match(lines[j]) or LIST_RE.match(lines[j]) or nxt.startswith(("|", ">")):
            continue
        nw = WORD_RE.findall(nxt)
        if not nw or len(nw) > 4:
            continue
        if head_words & set(w.lower() for w in nw if len(w) >= 3):
            hits.append(nxt)
    return hits


def _r36(c):
    return _hits(R36, c.view)


def _r37(c):
    hits = []
    for p in c.paras:
        found = [m.group(0) for m in TRANS_RE.finditer(p)]
        if len(found) >= 2:
            hits.extend(found)
    return hits


def _r38(c):
    return _hits(R38, c.view)


def _r39(c):
    return _hits(R39, c.view)


def _r40(c):
    wc = c.sent_wc
    if len(wc) < 3:
        return []
    cv = _cv(wc)
    if cv is not None and cv < 0.35:
        return ["%d sentences of similar length" % len(wc)]
    return []


def _r41(c):
    wc = c.sent_wc
    hits = []
    n = len(wc)
    i = 0
    while i < n - 1:
        j = i
        while j + 1 < n:
            d = wc[j + 1] - wc[j]
            if abs(d) < 6:
                break
            if j > i and (d > 0) == (wc[j] - wc[j - 1] > 0):
                break
            j += 1
        if j - i + 1 >= 6:
            hits.append("%d sentences alternating in length" % (j - i + 1))
            i = j + 1
        else:
            i += 1
    return hits


def _r42(c):
    hits = []
    for ps in c.para_sents:
        if len(ps) < 3:
            continue
        firsts = Counter(" ".join(w.lower() for w in WORD_RE.findall(s)[:2]) for s in ps)
        for k, v in firsts.items():
            if v >= 3 and k:
                hits.append(k)
    return hits


def _r44(c):
    wc = [n for n in c.para_wc if n > 0]
    if len(wc) < 4:
        return []
    cv = _cv(wc)
    if cv is not None and cv < 0.4:
        return ["%d paragraphs of similar length" % len(wc)]
    return []


def _r46(c):
    if c.word_count < 300:
        return []
    if ";" in c.view or c.view.count("(") >= 2:
        return []
    return ["no semicolons and almost no parentheses"]


def _r47(c):
    hits = []
    for rx in R47:
        hits.extend(_hits(rx, c.view))
    hits.extend(_hits(R47_CAP, c.view))
    return hits


def _r48(c):
    hits = []
    for rx in R48:
        hits.extend(_hits(rx, c.view))
    return hits


def _r50(c):
    hits = []
    for rx in R50:
        hits.extend(_hits(rx, c.view))
    return hits


def _r51(c):
    hits = []
    for rx in R51:
        hits.extend(_hits(rx, c.view))
    return hits


def _r54(c):
    return [s for s in c.sents if len(HEDGE_RE.findall(s)) >= 2]


def _r55(c):
    if c.word_count < 50:
        return []
    if len(FP_RE.findall(c.view)) / float(c.word_count) < 0.02:
        return []
    full = len(FULL_FORMS_RE.findall(c.view))
    contr = len(CONTR_RE.findall(c.view))
    if full >= 3 and (contr == 0 or full / float(full + contr) >= 0.8):
        return ["%d uncontracted forms" % full]
    return []


def _r56(c):
    hits = BOLD_RE.findall(c.view)
    return hits if len(hits) >= 3 else []


def _r57(c):
    return EMOJI_RE.findall(c.view)


def _r58(c):
    return ["paragraph with %d em dashes" % p.count(u"\u2014") for p in c.paras if p.count(u"\u2014") >= 2]


def _r59(c):
    hits = []
    for l in c.lines:
        m = HEAD_RE.match(l)
        if not m:
            continue
        t = m.group(1)
        words = re.findall(r"[A-Za-z][A-Za-z'\u2019-]*", t)
        if len(words) < 3 or not t[:1].isalpha():
            continue
        if t.upper() == t:
            continue
        major = [w for w in words if w.lower() not in MINOR_WORDS]
        if len(major) >= 2 and all(w[0].isupper() for w in major):
            hits.append(t)
    return hits


def _r60(c):
    return CURLY_RE.findall(c.view)


def _r61(c):
    hits = []
    for m in YEAR_RANGE_RE.finditer(c.view):
        if int(m.group(1)) < int(m.group(2)):
            hits.append(m.group(0))
    return hits


def _r62(c):
    return c.inv_hits


def _r63(c):
    hits = []
    for rx in PLACEHOLDER_RES:
        hits.extend(_hits(rx, c.view))
    return hits


def _r64(c):
    hits = []
    for rx in CHAT_MARKUP_RES:
        hits.extend(_hits(rx, c.view))
    return hits


def _r65(c):
    return _hits(UTM_RE, c.view)


def _r66(c):
    return c.homo_hits


def _r67(c):
    return c.nbsp_hits


def _r68(c):
    hits = []
    for i, l in enumerate(c.view.split("\n")):
        if re.search(r"[ \t]+$", l):
            hits.append("trailing space on line %d" % (i + 1))
    raw = c.raw
    if raw and raw[-1] in " \t":
        hits.append("trailing space at end of text")
    tail = raw[len(raw.rstrip()):]
    if tail.count("\n") >= 2:
        hits.append("blank lines at end of text")
    if raw and raw[0].isspace():
        hits.append("whitespace before first character")
    return hits


def _r69(c):
    return _hits(R69, c.view)


def _r70(c):
    hrs = [l for l in c.lines if HR_RE.match(l)]
    nonempty = sum(1 for l in c.lines if l.strip())
    if len(hrs) >= 3 and nonempty >= 24:
        return hrs
    return []


def _r71(c):
    toks = [w.lower() for w in WORD_RE.findall(c.view)]
    n = len(toks) - 5
    if n < 6:
        return []
    grams = [" ".join(toks[i:i + 6]) for i in range(n)]
    cnt = Counter(grams)
    rep = sum(v for v in cnt.values() if v > 1)
    if rep > 0 and rep / float(n) >= 0.2:
        return ["%d repeated six-word runs" % rep]
    return []


# (catalogue number, key slug, label, advisory (weight zero), function)
RULES = [
    (1, "ai_vocabulary", "AI vocabulary", False, _r1),
    (2, "model_dialect_vocabulary", "model-dialect vocabulary", False, _r2),
    (3, "promotional_language", "promotional language", False, _r3),
    (4, "hyphenated_pair_overuse", "hyphenated word-pair overuse", True, _r4),
    (5, "simple_yet_cliche", "\"simple yet X\" cliche", False, _r5),
    (6, "stacked_adjective_chains", "stacked adjective chains", False, _r6),
    (8, "synonym_cycling", "synonym cycling", False, _r8),
    (10, "significance_inflation", "significance inflation", False, _r10),
    (11, "notability_name_dropping", "notability name-dropping", False, _r11),
    (12, "vague_attributions", "vague attributions", False, _r12),
    (13, "article_title_as_proper_noun", "article title used as proper noun", False, _r13),
    (14, "ecosystem_padding", "conservation / ecosystem padding", False, _r14),
    (15, "false_ranges", "false range", False, _r15),
    (16, "superficial_ing_tail", "superficial -ing tail clause", False, _r16),
    (17, "negative_parallelism", "negative parallelism (advice)", True, _r17_parallel),
    (17, "tailing_negation", "tailing negation", False, _r17_tail),
    (18, "not_x_just_y", "\"not X, just Y\" framing", False, _r18),
    (19, "filler_phrases", "filler phrases (advice)", True, _r19),
    (20, "empty_pivot_phrases", "empty pivot phrase", False, _r20),
    (21, "outcome_speculation_tail", "outcome speculation tail", False, _r21),
    (22, "persuasive_authority_tropes", "persuasive authority trope (advice)", True, _r22),
    (23, "editorial_interjections", "editorial interjection", False, _r23),
    (24, "self_thoroughness", "self-thoroughness phrase", False, _r24),
    (25, "question_answer_pattern", "question-answer rhetorical pattern", False, _r25),
    (26, "concrete_evidence_defense", "\"concrete evidence\" defense phrase", False, _r26),
    (27, "compulsive_intro_hook", "compulsive intro hook", False, _r27),
    (30, "diff_anchored_writing", "diff-anchored writing", False, _r30),
    (31, "signposting", "signposting and announcement", False, _r31),
    (32, "cataloguing_lead_in", "cataloguing lead-in", False, _r32),
    (33, "inline_header_list", "inline-header vertical list", False, _r33),
    (34, "mid_essay_bullets", "mid-essay bullet injection", False, _r34),
    (35, "fragmented_header", "fragmented header", False, _r35),
    (36, "formulaic_challenges", "formulaic challenges section", False, _r36),
    (37, "transition_cluster", "transition cluster", False, _r37),
    (38, "compulsive_conclusion", "compulsive conclusion phrase", False, _r38),
    (39, "generic_positive_conclusion", "generic positive conclusion", False, _r39),
    (40, "sentence_length_monotony", "sentence-length monotony", False, _r40),
    (41, "mechanical_alternation", "mechanical sentence-length alternation (advice)", True, _r41),
    (42, "opener_repetition", "opener repetition (advice)", True, _r42),
    (44, "uniform_paragraph_length", "uniform paragraph length", False, _r44),
    (46, "semicolon_paren_underuse", "semicolon and parenthesis underuse (advice)", True, _r46),
    (47, "chatbot_artifacts", "chatbot artifact", False, _r47),
    (48, "sycophantic_tone", "sycophantic tone", False, _r48),
    (50, "knowledge_cutoff_disclaimer", "knowledge-cutoff disclaimer", False, _r50),
    (51, "copula_avoidance", "copula avoidance", False, _r51),
    (54, "hedge_stacking", "hedge stacking (advice)", True, _r54),
    (55, "contraction_absence", "contraction absence (advice)", True, _r55),
    (56, "boldface_overuse", "boldface overuse", False, _r56),
    (57, "emoji", "emoji", False, _r57),
    (58, "em_dash_overuse", "em-dash overuse (advice)", True, _r58),
    (59, "title_case_heading", "title-case heading", False, _r59),
    (60, "curly_quotes", "curly quotation marks (advice)", True, _r60),
    (61, "hyphen_for_en_dash", "hyphen for en dash in year range (advice)", True, _r61),
    (62, "invisible_characters", "invisible or zero-width characters", False, _r62),
    (63, "placeholder_text", "placeholder text", False, _r63),
    (64, "chat_reference_markup", "chat reference markup", False, _r64),
    (65, "ai_tracking_parameter", "AI tracking parameter", False, _r65),
    (66, "homoglyphs", "mixed-script lookalike letters", False, _r66),
    (67, "nonstandard_spaces", "non-standard spaces", False, _r67),
    (68, "trailing_whitespace", "trailing or stray whitespace (advice)", True, _r68),
    (69, "marketing_slop_phrase", "canonical marketing phrase", False, _r69),
    (70, "decorative_rules", "decorative horizontal rules", False, _r70),
    (71, "degenerate_repetition", "degenerate repetition", False, _r71),
]


def _char_layer(window):
    inv_idx = _invisible_indices(window)
    return inv_idx


def _confidence(words, families):
    if words < 40:
        return "none", "fewer than 40 words scanned"
    if words < 120:
        return "low", "fewer than 120 words scanned"
    if words < 300 and families == 1:
        return "low", "fewer than 300 words and only one score-moving pattern family fired"
    if words < 300:
        return "moderate", "fewer than 300 words scanned"
    return "high", ""


def _band_for(score):
    for limit, name in BANDS:
        if score <= limit:
            return name
    return "pervasive tells"


def _run_rules(ctx):
    results = []
    for num, slug, label, advisory, fn in RULES:
        try:
            hits = fn(ctx)
        except re.error:
            hits = []
        results.append((num, slug, label, advisory, hits))
    return results


def _score(ctx, results):
    words = ctx.word_count
    fired = [r for r in results if r[4]]
    score_fams = set(r[0] for r in fired if not r[3])
    n = len(score_fams)
    decisive = score_fams & DECISIVE
    conf, _ = _confidence(words, n)
    points = 0.0
    for num, slug, label, advisory, hits in fired:
        if advisory or num not in score_fams:
            continue
        if num in RHYTHM:
            points += 6
        else:
            rate = len(hits) * 100.0 / max(words, 100)
            points += min(25.0, 6.0 + 8.0 * rate)
    score = int(round(min(100.0, points)))
    if n == 1 and not (decisive and conf in ("moderate", "high")):
        score = min(score, 40)
    if score_fams and score_fams <= frozenset([40]):
        score = min(score, 20)
    floors = []
    if words < 120:
        k = len(score_fams & SHORT_DOC_SET)
        if k >= 3:
            floors.append(45)
        elif k >= 2:
            floors.append(25)
    if words >= 400:
        if n >= 6:
            floors.append(45)
        elif n >= 5:
            floors.append(25)
    if len(decisive) >= 2:
        floors.append(65)
    elif len(decisive) == 1 and conf in ("moderate", "high"):
        floors.append(45)
    if floors:
        score = max(score, max(floors))
    return max(0, min(100, score)), score_fams


def _sample_for(num, hits):
    return [_excerpt(h) for h in hits[:3]]


def _report(ctx, results, score, families):
    report = {}
    fired = []
    for num, slug, label, advisory, hits in results:
        if hits:
            fired.append((num, slug, label, advisory, hits))
    fired.sort(key=lambda r: (r[0], r[1]))
    for num, slug, label, advisory, hits in fired:
        key = "%d_%s" % (num, slug)
        report[key] = {"label": label, "count": len(hits), "samples": _sample_for(num, hits)}
    conf, reason = _confidence(ctx.word_count, len(families))
    band = _band_for(score)
    report["_metrics"] = {
        "scanned_chars": ctx.scanned_chars,
        "truncated": ctx.truncated,
        "ai_tell_score": score,
        "ai_tell_band": band,
        "hook_phrase": PHRASES[band],
        "confidence": conf,
        "confidence_reason": reason,
        "patterns_flagged": len(fired),
        "invisible_chars": len(ctx.inv_hits),
        "nonstandard_spaces": len(ctx.nbsp_hits),
        "homoglyphs": len(ctx.homo_hits),
        "words": ctx.word_count,
        "sentences": len(ctx.sents),
    }
    return report


def _score_text(text):
    view = build_view(text)
    ctx = make_ctx(view, text)
    ctx.inv_hits = []
    ctx.nbsp_hits = []
    ctx.homo_hits = []
    results = _run_rules(ctx)
    return _score(ctx, results)[0]


def analyze(full, want_ci=False):
    window = full[:WINDOW]
    truncated = len(full) > WINDOW
    inv_idx = _char_layer(window)
    inv_hits = ["%s at %d" % (_cp_label(window[i]), i) for i in inv_idx]
    nbsp_hits = _nonstandard_space_hits(window)
    homo_hits = _homoglyph_hits(window)
    view = build_view(window)
    ctx = make_ctx(view, window)
    ctx.inv_hits = inv_hits
    ctx.nbsp_hits = nbsp_hits
    ctx.homo_hits = homo_hits
    ctx.scanned_chars = len(window)
    ctx.truncated = truncated
    results = _run_rules(ctx)
    score, families = _score(ctx, results)
    report = _report(ctx, results, score, families)
    if want_ci:
        if len(ctx.sents) < 4:
            report["_metrics"]["score_ci"] = None
            report["_metrics"]["score_ci_note"] = "too few sentences for an interval (%d; at least 4 needed)" % len(ctx.sents)
        else:
            rnd = random.Random(20240601)
            sample_scores = []
            for _ in range(30):
                pick = [rnd.choice(ctx.sents) for _ in ctx.sents]
                sample_scores.append(_score_text(" ".join(pick)))
            sample_scores.sort()
            lo = sample_scores[int(0.05 * (len(sample_scores) - 1))]
            hi = sample_scores[int(math.ceil(0.95 * (len(sample_scores) - 1)))]
            lo = min(lo, score)
            hi = max(hi, score)
            report["_metrics"]["score_ci"] = [lo, hi]
            report["_metrics"]["score_ci_note"] = "low/high of 30 sentence resamples; the point score is unchanged"
    return report


# ---------------------------------------------------------------- command line

def main(argv):
    clean = False
    want_ci = False
    operands = []
    options_done = False
    for arg in argv:
        if options_done:
            operands.append(arg)
        elif arg == "--":
            options_done = True
        elif arg in ("-h", "--help"):
            sys.stdout.buffer.write(USAGE.encode("utf-8"))
            return 0
        elif arg == "--clean":
            clean = True
        elif arg == "--ci":
            want_ci = True
        elif arg.startswith("-"):
            _fail("unknown option '%s' (see --help)" % arg, 2)
        else:
            operands.append(arg)
    path = operands[0] if operands else None
    if len(operands) > 1:
        _err_line("detect.py: only the first file was scanned: %s" % operands[0])
    text = read_source(path)
    if not text.strip():
        _fail("empty input", 1)
    if clean:
        sys.stdout.buffer.write(scrub(text).encode("utf-8"))
        return 0
    report = analyze(text, want_ci)
    sys.stdout.buffer.write((json.dumps(report, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
