#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract in context (plain text on stdout).
const c = require('./prosecheck-common');

function main() {
  c.readStdinJson();
  const level = c.resolveLevel();
  if (level === 'off') {
    c.pruneLedgers();
    return;
  }
  // A fresh install has no mode flag yet: prepend the one-time welcome.
  const firstStart = !c.flagExists();
  // Store the level so later hooks on this install see it.
  if (!c.readStored()) {
    c.writeStored(level);
  }
  c.pruneLedgers();
  const detector = c.detectorPath() || require('path').join(c.pluginRoot(), 'scripts', 'detect.py');
  const parts = [];
  if (firstStart) parts.push(c.welcomeText(level), '');
  parts.push('Writing contract (' + level + '):');
  parts.push(c.contractBody(level, detector, false));
  process.stdout.write(parts.join('\n') + '\n');
}

try {
  main();
} catch (e) {
  // Never fail the host session.
}
process.exitCode = 0;
