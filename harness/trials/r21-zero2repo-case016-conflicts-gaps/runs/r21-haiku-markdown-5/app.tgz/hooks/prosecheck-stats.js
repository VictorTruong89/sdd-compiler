#!/usr/bin/env node
'use strict';
// Stats: token totals from a session transcript and the score of the session's own prose.
// Used by the prompt-submit router; also runnable as a hook (JSON in, block decision out).
const fs = require('fs');
const path = require('path');
const c = require('./prosecheck-common');

const PROSE_SLICE = 40000;
const PROSE_MIN = 500;

// Newest .jsonl under <config>/projects (depth-limited).
function newestTranscript() {
  const root = path.join(c.configDir(), 'projects');
  let best = null;
  function walk(dir, depth) {
    if (depth > 4) return;
    let entries;
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (e) {
      return;
    }
    for (const ent of entries) {
      const p = path.join(dir, ent.name);
      if (ent.isDirectory()) {
        walk(p, depth + 1);
      } else if (ent.isFile() && ent.name.endsWith('.jsonl')) {
        try {
          const m = fs.statSync(p).mtimeMs;
          if (!best || m > best.mtime) best = { file: p, mtime: m };
        } catch (e) {
          // ignore
        }
      }
    }
  }
  walk(root, 0);
  return best ? best.file : null;
}

function statsReply(input, level) {
  const named = typeof input.transcript_path === 'string' ? input.transcript_path.trim() : '';
  const file = named || newestTranscript();
  let raw = null;
  if (file) {
    try {
      raw = fs.readFileSync(file, 'utf8');
    } catch (e) {
      raw = null;
    }
  }
  const head = ['prosecheck stats', 'level: ' + level];
  if (raw === null) {
    return head.concat(['No readable session transcript was found, so there are no turn or token counts.']).join('\n');
  }
  const seen = new Set();
  let turns = 0;
  let outTokens = 0;
  let cacheRead = 0;
  const texts = [];
  let anon = 0;
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    let obj;
    try {
      obj = JSON.parse(line);
    } catch (e) {
      continue;
    }
    if (!obj || obj.type !== 'assistant' || !obj.message || typeof obj.message !== 'object') continue;
    const msg = obj.message;
    let id = msg.id;
    if (typeof id !== 'string' || !id) {
      anon += 1;
      id = '__anon' + anon;
    }
    if (seen.has(id)) continue;
    seen.add(id);
    turns += 1;
    const usage = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    outTokens += Number(usage.output_tokens) || 0;
    cacheRead += Number(usage.cache_read_input_tokens) || 0;
    if (Array.isArray(msg.content)) {
      for (const part of msg.content) {
        if (part && part.type === 'text' && typeof part.text === 'string') texts.push(part.text);
      }
    }
  }
  const out = head.concat([
    'assistant turns: ' + turns,
    'output tokens: ' + outTokens,
    'cache-read input tokens: ' + cacheRead,
  ]);
  let prose = texts.join('\n');
  prose = prose.replace(/```[\s\S]*?```/g, ' ').replace(/~~~[\s\S]*?~~~/g, ' ');
  prose = prose.slice(-PROSE_SLICE).trim();
  if (prose.length > PROSE_MIN) {
    const r = c.runDetector([], prose, c.PLAIN_TIMEOUT_MS);
    if (r.kind === 'ran' && r.status === 0) {
      const parsed = c.parseReport(r.stdout);
      if (parsed.report) out.push('session prose ai_tell_score: ' + parsed.report._metrics.ai_tell_score);
    }
  }
  return out.join('\n');
}

module.exports = { statsReply };

if (require.main === module) {
  try {
    const input = c.readStdinJson();
    const level = c.resolveLevel();
    process.stdout.write(JSON.stringify({ decision: 'block', reason: statsReply(input, level) }) + '\n');
  } catch (e) {
    // Never fail the host session.
  }
  process.exitCode = 0;
}
