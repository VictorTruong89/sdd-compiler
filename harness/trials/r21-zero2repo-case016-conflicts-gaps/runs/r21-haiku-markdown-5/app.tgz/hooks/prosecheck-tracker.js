#!/usr/bin/env node
'use strict';
// Prompt-submit hook and /prosecheck command router.
const fs = require('fs');
const path = require('path');
const c = require('./prosecheck-common');
const { statsReply } = require('./prosecheck-stats');

const CMD_RE = /^\/prosecheck(?::prosecheck)?(?=\s|$)/i;
const STOP_RE = /^(?:stop prosecheck|prosecheck off)$/i;
const CHECK_CAP = 8;
const SHOW_LABEL_CAP = 5;
const WINDOW_TEXT = '262,144';

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }) + '\n');
}

function helpReply(level) {
  return [
    'prosecheck help. Live level: ' + level + '.',
    'Code, commits, config, and chat are never touched; the contract covers prose deliverables only.',
    '/prosecheck lite - turns on the writing contract without scoring saved files (contract, scoring).',
    '/prosecheck full - the default: adds the saved-file guard with its threshold of 40 (contract, guard, 40, default).',
    '/prosecheck strict - lowers the guard threshold to 20 and adds the cleanup scrub (guard, 20, scrub).',
    '/prosecheck off | /prosecheck on - switch the tool off, and back on (on restores full; disable, re-enable).',
    '/prosecheck check <file> - scores one file and reports only; it never rewrites the file (score, rewrite).',
    '/prosecheck doctor - checks the install (health).',
    '/prosecheck stats - session token figures and the score of the session\'s own prose (token, prose).',
    '/prosecheck init - writes the contract into ./AGENTS.md for agents other than Claude Code (AGENTS.md, contract).',
    '/prosecheck show - lists the files scored in this session, newest first.',
    '/prosecheck status - one line naming the live level.',
    'A bare /prosecheck also shows this help. For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function setLevelReply(word) {
  if (!c.writeStored(word)) {
    return 'cannot write the level setting; nothing changed.';
  }
  if (word === 'lite') return 'prosecheck set to lite: writing contract on, saved files not scored.';
  if (word === 'full') return 'prosecheck set to full: writing contract on, saved files scored (threshold 40).';
  if (word === 'strict') return 'prosecheck set to strict: writing contract on, saved files scored (threshold 20), cleanup scrub on.';
  return 'prosecheck set to off: nothing is scored or placed until you run /prosecheck on.';
}

function onReply() {
  if (!c.writeStored('full')) {
    return 'cannot write the level setting; nothing changed.';
  }
  return 'prosecheck is on (full): the writing contract is on and saved files are scored.';
}

// Parses the one-token path argument: optional leading @, one pair of quotes.
function parsePathArg(rest) {
  let s = rest.trim();
  if (s.startsWith('@')) s = s.slice(1);
  if (s.length >= 2 && (s[0] === '"' || s[0] === "'")) {
    const end = s.indexOf(s[0], 1);
    if (end > 0) return s.slice(1, end);
    return s.slice(1);
  }
  return s.split(/\s+/)[0] || '';
}

function checkReply(rest, input) {
  const typed = parsePathArg(rest);
  if (!typed) {
    return 'Give a file to check: /prosecheck check <path>. Nothing was scored.';
  }
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const abs = path.isAbsolute(typed) ? typed : path.resolve(cwd, typed);
  const base = path.basename(abs);
  const ext = path.extname(abs).toLowerCase();
  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    return 'cannot read ' + typed + ': no such file.';
  }
  if (st.isDirectory() || !st.isFile()) {
    return typed + ' is not a file.';
  }
  if (c.BINARY_EXTS.has(ext)) {
    return base + ': no readable text (' + ext + ' files are not read); nothing was scored.';
  }
  const isArchive = c.ARCHIVE_EXTS.has(ext);
  const cap = isArchive ? c.ARCHIVE_CAP : c.PLAIN_CAP;
  if (st.size > cap) {
    return base + ' is over ' + Math.round(cap / 1024) + ' KB, so it was not scored.';
  }
  const r = c.runDetector([abs], undefined, isArchive ? c.ARCHIVE_TIMEOUT_MS : c.PLAIN_TIMEOUT_MS);
  if (r.kind === 'missing') {
    return 'detector unavailable: Python cannot be launched, so ' + base + ' was not scored.';
  }
  if (r.kind === 'timeout') {
    return base + ' - failed: the detector timed out.';
  }
  if (r.status !== 0) {
    const errLine = r.stderr.trim().split('\n').filter((l) => l.trim()).pop() || '';
    return base + ' - failed (exit ' + r.status + ')' + (errLine ? ': ' + errLine : '') + '.';
  }
  if (r.stdout.trim() === '') {
    return 'no report from the detector for this file.';
  }
  const parsed = c.parseReport(r.stdout);
  if (!parsed.report) {
    return 'no report from the detector: its output was not a scored report.';
  }
  const rep = parsed.report;
  const m = rep._metrics;
  const band = m.ai_tell_band;
  const lines = [];
  lines.push(base + ' - ' + c.bandPhrase(band) + ' (score ' + m.ai_tell_score + '/100, band: ' + band + ')');
  lines.push('confidence: ' + m.confidence + (m.confidence !== 'high' && m.confidence_reason ? ' - ' + m.confidence_reason : ''));
  if (m.truncated) {
    lines.push('coverage: first ' + WINDOW_TEXT + ' characters only (the scan window; the rest was not read).');
  }
  const items = c.findingLabels(rep).slice(0, CHECK_CAP);
  if (items.length) {
    lines.push('tells: ' + items.map((x) => x.label + ' (x' + x.count + ')').join('; '));
  } else {
    lines.push('tells: none');
  }
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

function doctorReply(form, level) {
  const root = c.pluginRoot();
  const configDir = c.configDir();
  const lines = [];
  lines.push('prosecheck doctor');

  if (level === 'off') {
    lines.push('mode: off - the tool is off, which is not a fault of the install. Run /prosecheck on to re-enable it.');
  } else {
    lines.push('[OK] mode: ' + level + ' - the tool is on.');
  }

  const dp = c.detectorPath();
  if (dp) {
    lines.push('[OK] detector: bundled scripts/detect.py found at ' + dp);
  } else {
    lines.push('[FAIL] detector: bundled scripts/detect.py was not found under the plugin root ' + root);
  }

  const probe = c.runDetector([], 'A short sentence for the doctor check. It has two sentences.', 20000);
  let pyOk = false;
  if (probe.kind === 'missing') {
    lines.push('[FAIL] python not found: Python cannot be launched, so saved files are not re-scored until Python is available; the writing contract still shapes new prose.');
  } else if (probe.kind === 'timeout') {
    lines.push('[FAIL] python: the detector run timed out.');
  } else {
    const parsed = c.parseReport(probe.stdout);
    if (parsed.report) {
      pyOk = true;
      lines.push('[OK] python: Python ran the bundled detector and returned a numeric score.');
    } else {
      lines.push('[FAIL] python: the detector run returned text that is not a numeric score.');
    }
  }

  let settingsOk = false;
  try {
    if (c.ensureDir(configDir)) {
      fs.accessSync(configDir, fs.constants.W_OK);
      settingsOk = true;
    }
  } catch (e) {
    settingsOk = false;
  }
  if (settingsOk) {
    lines.push('[OK] settings: folder ' + configDir + ' is writable.');
  } else {
    lines.push('[FAIL] settings: folder ' + configDir + ' is not writable.');
  }

  const detectorOk = Boolean(dp);
  const allOk = detectorOk && pyOk && settingsOk;
  if (allOk && level !== 'off') {
    lines.push('prosecheck is active. Plain text up to 512 KB and archives up to 4 MB are scored; the first ' + WINDOW_TEXT +
      ' characters are scanned. Run ' + form + ' show to see files that were only partly scanned or skipped.');
  } else if (!allOk) {
    lines.push('Fix the faulty checks above, then run /prosecheck doctor again.');
  } else {
    lines.push('Saved files are not scored while the tool is off. Run ' + form + ' on to turn scoring back on.');
  }
  return lines.join('\n');
}

function showReply(sid) {
  const ledger = c.readLedger(sid);
  const fresh = ledger.mtimeMs && Date.now() - ledger.mtimeMs <= c.LEDGER_SHOW_MS;
  if (!fresh || ledger.rows.length === 0) {
    return 'prosecheck show: nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const out = ['prosecheck show (this session, newest first):'];
  for (const row of ledger.rows.slice().reverse()) {
    const base = row.base || '(unnamed)';
    if (row.kind === 'scored') {
      const cover = row.truncated ? ', first ' + WINDOW_TEXT + ' characters only' : '';
      let tail = '';
      const labels = Array.isArray(row.labels) ? row.labels.slice(0, SHOW_LABEL_CAP) : [];
      if (labels.length) {
        tail = ' - ' + (row.flagged ? 'flagged' : 'under the threshold') + ': ' + labels.join('; ');
      }
      out.push(base + ' - ' + row.phrase + ' (score ' + row.score + '/' + row.band + cover + ')' + tail);
    } else if (row.kind === 'skipped') {
      out.push(base + ' - not scored: over the ' + Math.round(row.limit / 1024) + ' KB limit');
    } else if (row.kind === 'binary') {
      out.push(base + ' - not re-scored (binary file; PDF and RTF are not read)');
    } else {
      out.push(base + ' - not scored: ' + (row.reason || 'unknown reason'));
    }
  }
  return out.join('\n');
}

const START = '<!-- prosecheck:contract:start -->';
const END = '<!-- prosecheck:contract:end -->';

function initReply(form, level, input) {
  if (level === 'off') {
    return 'prosecheck is switched off, so nothing was written. Run ' + form + ' on to allow the export.';
  }
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const replies = [];
  const agentsPath = path.join(cwd, 'AGENTS.md');
  const section = START + '\n## Prose writing contract\n\n' +
    c.contractBody(level, '$CLAUDE_PLUGIN_ROOT/scripts/detect.py', true) + '\n' + END + '\n';
  let existing = null;
  let readOk = true;
  try {
    existing = fs.readFileSync(agentsPath, 'utf8');
  } catch (e) {
    if (e.code !== 'ENOENT') readOk = false;
  }
  if (!readOk) {
    replies.push('cannot read AGENTS.md; no contract was written there.');
  } else if (existing !== null && (existing.includes(START) || existing.includes('## Prose writing contract'))) {
    replies.push('AGENTS.md already contains the prosecheck contract; left unchanged.');
  } else {
    try {
      const next = existing === null ? section
        : existing + (existing.endsWith('\n') ? '\n' : '\n\n') + section;
      fs.writeFileSync(agentsPath, next, 'utf8');
      replies.push('Wrote the prosecheck contract to AGENTS.md.');
    } catch (e) {
      replies.push('cannot write AGENTS.md; no contract was written there.');
    }
  }

  const dst = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (c.fileExists(dst)) {
    replies.push('The Cursor rule is already there (prosecheck.mdc); it was not overwritten.');
  } else {
    try {
      const src = fs.readFileSync(path.join(c.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc'), 'utf8');
      if (!c.ensureDir(path.dirname(dst))) throw new Error('mkdir failed');
      fs.writeFileSync(dst, src, 'utf8');
      replies.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      replies.push('cannot write .cursor/rules/prosecheck.mdc; the Cursor rule was not created.');
    }
  }
  return replies.join('\n');
}

function routeCommand(trimmed, input) {
  const m = CMD_RE.exec(trimmed);
  const form = /:prosecheck/i.test(m[0]) ? '/prosecheck:prosecheck' : '/prosecheck';
  const rest = trimmed.slice(m[0].length).trim();
  const tokens = rest.split(/\s+/);
  const word = (tokens[0] || '').toLowerCase();
  const after = rest.slice(tokens[0] ? tokens[0].length : 0).trim();
  const level = c.resolveLevel();

  if (!word || word === 'help') return helpReply(level);
  if (['lite', 'full', 'strict', 'off'].includes(word)) return setLevelReply(word);
  if (word === 'on') return onReply();
  if (word === 'status') return 'prosecheck level: ' + level + '.';
  if (word === 'show') return showReply(input.session_id);
  if (word === 'check') return checkReply(after, input);
  if (word === 'doctor') return doctorReply(form, level);
  if (word === 'stats') return statsReply(input, level);
  if (word === 'init') return initReply(form, level, input);
  return 'unknown subcommand "' + tokens[0] + '". Valid subcommands: ' + c.SUBCOMMANDS.join(', ') +
    '. The stored level is unchanged.';
}

function main() {
  const input = c.readStdinJson();
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const trimmed = prompt.trim();

  if (CMD_RE.test(trimmed)) {
    block(routeCommand(trimmed, input));
    return;
  }
  if (STOP_RE.test(trimmed)) {
    c.writeStored('off');
    block('prosecheck set to off: nothing is scored or placed until you run /prosecheck on.');
    return;
  }
  const level = c.resolveLevel();
  if (level === 'off') return;
  const reminder = 'prosecheck is on at the ' + level + ' level. Prose deliverables follow the writing contract; ' +
    'code, config, and commits are untouched.';
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: { hookEventName: 'UserPromptSubmit', additionalContext: reminder },
  }) + '\n');
}

try {
  main();
} catch (e) {
  // Never fail the host session.
}
process.exitCode = 0;
