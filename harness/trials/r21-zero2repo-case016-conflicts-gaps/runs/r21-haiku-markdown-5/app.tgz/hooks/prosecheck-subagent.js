#!/usr/bin/env node
'use strict';
// Subagent-start hook: returns the same writing contract inside the SubagentStart envelope.
const path = require('path');
const c = require('./prosecheck-common');

function main() {
  c.readStdinJson();
  const level = c.resolveLevel();
  if (level === 'off') return;
  const detector = c.detectorPath() || path.join(c.pluginRoot(), 'scripts', 'detect.py');
  const additionalContext = 'Writing contract (' + level + '):\n' + c.contractBody(level, detector, false);
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext },
  }) + '\n');
}

try {
  main();
} catch (e) {
  // Never fail the host session.
}
process.exitCode = 0;
