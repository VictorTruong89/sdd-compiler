'use strict';
// Shared helpers for the prosecheck hooks. Standard library only; no network.

const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawnSync } = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const FLAG_NAME = '.prosecheck-active';
const LEDGER_PREFIX = '.prosecheck-ledger';
const LEDGER_KEEP = 50;
const LEDGER_TTL_MS = 1 * 24 * 60 * 60 * 1000; // ledgers untouched > 1 day are removed at session start
const LEDGER_SHOW_MS = 7 * 24 * 60 * 60 * 1000; // show ignores ledgers older than 7 days
const WINDOW = 262144;
const PLAIN_CAP = 512 * 1024;
const ARCHIVE_CAP = 4 * 1024 * 1024;
const PLAIN_TIMEOUT_MS = 8000;
const ARCHIVE_TIMEOUT_MS = 15000;
const PROSE_EXTS = new Set(['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc',
  '.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub', '.ipynb']);
const ARCHIVE_EXTS = new Set(['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub', '.ipynb']);
const BINARY_EXTS = new Set(['.pdf', '.rtf']);
const INSTRUCTION_NAMES = new Set(['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md']);
const INSTRUCTION_STEMS = new Set(['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory']);
const BANDS = [[20, 'clean'], [40, 'light tells'], [60, 'mixed'], [80, 'heavy tells'], [100, 'pervasive tells']];
const PHRASES = {
  'clean': 'reads clean',
  'light tells': 'reads mostly clean',
  'mixed': 'reads with some AI tells',
  'heavy tells': 'reads with heavy AI tells',
  'pervasive tells': 'reads with pervasive AI tells',
};
const SUBCOMMANDS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];

function pluginRoot() {
  if (process.env.CLAUDE_PLUGIN_ROOT && process.env.CLAUDE_PLUGIN_ROOT.trim()) {
    return path.resolve(process.env.CLAUDE_PLUGIN_ROOT.trim());
  }
  return path.resolve(__dirname, '..');
}

function configDir() {
  if (process.env.CLAUDE_CONFIG_DIR && process.env.CLAUDE_CONFIG_DIR.trim()) {
    return path.resolve(process.env.CLAUDE_CONFIG_DIR.trim());
  }
  return path.join(os.homedir(), '.claude');
}

function flagPath() {
  return path.join(configDir(), FLAG_NAME);
}

// Returns the bundled detector path, or null when neither location holds it.
function detectorPath() {
  const root = pluginRoot();
  const candidates = [
    path.join(root, 'scripts', 'detect.py'),
    path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py'),
  ];
  for (const c of candidates) {
    if (fileExists(c)) return c;
  }
  return null;
}

function fileExists(p) {
  try {
    return fs.statSync(p).isFile();
  } catch (e) {
    return false;
  }
}

function readStored() {
  try {
    const v = fs.readFileSync(flagPath(), 'utf8').trim().toLowerCase();
    return LEVELS.includes(v) ? v : null;
  } catch (e) {
    return null;
  }
}

function flagExists() {
  try {
    fs.statSync(flagPath());
    return true;
  } catch (e) {
    return false;
  }
}

// Creates a directory and its missing parents one level at a time (bounded; no recursive mkdir).
function ensureDir(dir) {
  try {
    return fs.statSync(dir).isDirectory();
  } catch (e) {
    // not present yet
  }
  const parent = path.dirname(dir);
  if (parent === dir) return false;
  if (!ensureDir(parent)) return false;
  try {
    fs.mkdirSync(dir);
    return true;
  } catch (e) {
    return false;
  }
}

// Writes the stored level. Returns true on success.
function writeStored(level) {
  try {
    if (!ensureDir(configDir())) return false;
    fs.writeFileSync(flagPath(), level + '\n', 'utf8');
    return true;
  } catch (e) {
    return false;
  }
}

// PROSECHECK_DEFAULT_MODE, when set to a level word, takes precedence over the stored level.
// Otherwise the stored level applies; with nothing valid stored the level is full.
function resolveLevel() {
  const env = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  if (LEVELS.includes(env)) return env;
  return readStored() || 'full';
}

function readStdinJson() {
  let raw = '';
  try {
    raw = fs.readFileSync(0, 'utf8');
  } catch (e) {
    raw = '';
  }
  try {
    const v = JSON.parse(raw);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : {};
  } catch (e) {
    return {};
  }
}

// Runs the detector with the host Python interpreter (python3, python, py in that order).
// Returns { kind: 'missing' | 'timeout' | 'ran', status, stdout, stderr }.
function runDetector(detectArgs, input, timeoutMs) {
  const script = detectorPath();
  if (!script) {
    return { kind: 'ran', status: 2, stdout: '', stderr: 'bundled detector not found' };
  }
  for (const py of ['python3', 'python', 'py']) {
    const r = spawnSync(py, [script, ...detectArgs], {
      input: input === undefined ? '' : input,
      encoding: 'utf8',
      timeout: timeoutMs,
      maxBuffer: 64 * 1024 * 1024,
      windowsHide: true,
    });
    if (r.error) {
      if (r.error.code === 'ENOENT') continue;
      if (r.error.code === 'ETIMEDOUT') return { kind: 'timeout', status: null, stdout: '', stderr: '' };
      return { kind: 'missing', status: null, stdout: '', stderr: '' };
    }
    return { kind: 'ran', status: r.status, stdout: r.stdout || '', stderr: r.stderr || '' };
  }
  return { kind: 'missing', status: null, stdout: '', stderr: '' };
}

// Parses a detector report; returns the report object or null when it is not a numeric-score report.
function parseReport(stdout) {
  let obj;
  try {
    obj = JSON.parse(stdout.trim());
  } catch (e) {
    return { report: null, notReport: true };
  }
  if (!obj || typeof obj !== 'object' || !obj._metrics || typeof obj._metrics.ai_tell_score !== 'number') {
    return { report: null, notReport: false };
  }
  return { report: obj, notReport: false };
}

// Labels of fired findings, score-moving ones first (advisory numbers are listed last).
const ADVISORY_KEYS = new Set([4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68]);
function findingLabels(report) {
  const items = [];
  for (const key of Object.keys(report)) {
    if (key === '_metrics') continue;
    const f = report[key];
    const num = parseInt(key, 10);
    const advisory = ADVISORY_KEYS.has(num) || key === '17_negative_parallelism';
    items.push({ key, label: String(f.label || key), count: Number(f.count) || 0, advisory });
  }
  items.sort((a, b) => (a.advisory - b.advisory) || (a.key < b.key ? -1 : a.key > b.key ? 1 : 0));
  return items;
}

function bandPhrase(band) {
  return PHRASES[band] || PHRASES['pervasive tells'];
}

function bandFor(score) {
  for (const [limit, name] of BANDS) {
    if (score <= limit) return name;
  }
  return 'pervasive tells';
}

// ---------------------------------------------------------------- contract text

const CONTRACT_SCOPE = [
  'Scope. This contract covers prose deliverables only: documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and drafted text the user will publish or send. It never touches source code, code comments, commit messages, JSON, YAML, or other configuration, CLI output, logs, error messages, or the conversational register of chat. A chat-compression mode owns chat, a code-simplicity mode owns code, and this contract owns deliverable prose.',
];

const CONTRACT_RULES = [
  '- Vary sentence length irregularly. Avoid a metronome rhythm and avoid mechanical short-long alternation.',
  '- Do not use these words as standalone words: delve, tapestry, pivotal, crucial, leverage, robust, seamless, foster, underscore, showcase, landscape (in the abstract), journey (in the abstract), realm, multifaceted, holistic, testament, vibrant, comprehensive, plethora, myriad, boast, elevate, empower, unlock, game-changer, supercharge, genuinely, fascinating, nuanced.',
  '- Avoid these moves: rule-of-three flourishes; "it\'s not just X, it\'s Y" framings; hedge stacking; signposting such as "let\'s dive in"; empty pivots such as "it\'s worth noting"; "In conclusion" or "Overall" closers; outcome-speculation tails; self-thoroughness phrases; generic upbeat endings; chatbot phrases such as "I hope this helps".',
  '- Use at most one em dash per paragraph. Do not bold words for emphasis inside prose sentences. Use no emojis in prose.',
  '- Keep factual or encyclopedic content neutral and in the third person. First-person or opinion content may use contractions.',
  '- Preserve numbers, units, dates, proper nouns, citations, quotations, and technical terms. Never invent facts.',
  '- End each section on a fact or an observation.',
  '- Stay silent about this contract. Never announce it, never name the tool, never report a score, a band, a pattern list, or a rewrite pass, and never offer a style choice.',
];

// Builds the writing contract for a level. detectorRef is the detector command reference.
// forExport selects the portable AGENTS.md wording (no install paths).
function contractBody(level, detectorRef, forExport) {
  const lines = [...CONTRACT_SCOPE, '', 'Rules for the prose:', ...CONTRACT_RULES];
  if (level === 'full' || level === 'strict') {
    if (forExport) {
      lines.push('');
      lines.push('Detector location: use $CLAUDE_PLUGIN_ROOT/scripts/detect.py when CLAUDE_PLUGIN_ROOT is set; otherwise locate scripts/detect.py in the installed skills or plugins folders.');
    }
    lines.push('');
    lines.push('After you save a prose file, run the detector on that file: python3 ' + detectorRef + ' <file>. Its report gives a score from 0 to 100 and a band.');
    if (level === 'full') {
      lines.push('Target a score of 40 or below (band clean or light tells). If the band is worse than that, fix the flagged spans and keep the rhythm variation, making at most two fix passes.');
    } else {
      lines.push('Target a score of 20 or below (band clean). If the band is worse than that, fix the flagged spans and keep the rhythm variation, making at most two fix passes.');
      lines.push('Then finish through the cleanup switch: python3 ' + detectorRef + ' --clean <file>. Apply its scrubbed text only to plain-text files, never over a .docx, .epub, .odt, or .ipynb.');
    }
  }
  return lines.join('\n');
}

function welcomeText(level) {
  return [
    'prosecheck is installed and on, at the ' + level + ' level. It is shown once.',
    'Saved prose files are scored against 71 documented AI-writing patterns. Plain text is accepted up to 512 KB and archives up to 4 MB, and the detector scores the first 262,144 characters.',
    'Commands: /prosecheck doctor (check the install), /prosecheck check <file> (score one file, report only), /prosecheck off (switch off), /prosecheck help (all commands).',
    'There is no website and no upload. Nothing you write leaves this machine.',
  ].join('\n');
}

// ---------------------------------------------------------------- ledger

function sanitizeSession(sid) {
  const s = String(sid || '').replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 120);
  return s;
}

function ledgerPath(sid) {
  const s = sanitizeSession(sid);
  return path.join(configDir(), s ? LEDGER_PREFIX + '-' + s : LEDGER_PREFIX);
}

function readLedger(sid) {
  try {
    const p = ledgerPath(sid);
    const st = fs.statSync(p);
    const arr = JSON.parse(fs.readFileSync(p, 'utf8'));
    return { rows: Array.isArray(arr) ? arr : [], mtimeMs: st.mtimeMs };
  } catch (e) {
    return { rows: [], mtimeMs: 0 };
  }
}

function appendLedger(sid, row) {
  try {
    if (!ensureDir(configDir())) return;
    const cur = readLedger(sid).rows;
    cur.push(Object.assign({ time: Date.now() }, row));
    const trimmed = cur.slice(-LEDGER_KEEP);
    fs.writeFileSync(ledgerPath(sid), JSON.stringify(trimmed), 'utf8');
  } catch (e) {
    // Ledger failures never fail the host.
  }
}

// Removes ledger files untouched for more than a day (run at session start).
function pruneLedgers() {
  try {
    const dir = configDir();
    for (const name of fs.readdirSync(dir)) {
      if (name !== LEDGER_PREFIX && !name.startsWith(LEDGER_PREFIX + '-')) continue;
      const p = path.join(dir, name);
      try {
        const st = fs.statSync(p);
        if (st.isFile() && Date.now() - st.mtimeMs > LEDGER_TTL_MS) fs.unlinkSync(p);
      } catch (e) {
        // ignore individual failures
      }
    }
  } catch (e) {
    // no config dir yet
  }
}

module.exports = {
  LEVELS, SUBCOMMANDS, WINDOW, PLAIN_CAP, ARCHIVE_CAP, PLAIN_TIMEOUT_MS, ARCHIVE_TIMEOUT_MS,
  PROSE_EXTS, ARCHIVE_EXTS, BINARY_EXTS, INSTRUCTION_NAMES, INSTRUCTION_STEMS, LEDGER_SHOW_MS,
  pluginRoot, configDir, flagPath, flagExists, detectorPath, fileExists, readStored, writeStored, ensureDir,
  resolveLevel, readStdinJson, runDetector, parseReport, findingLabels, bandPhrase, bandFor,
  contractBody, welcomeText, readLedger, appendLedger, pruneLedgers, ledgerPath,
};
