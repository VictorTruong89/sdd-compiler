#!/usr/bin/env node
'use strict';
// Post-tool-use hook (saved-file guard). Scores a just-saved prose file and nudges when flagged.
const fs = require('fs');
const path = require('path');
const c = require('./prosecheck-common');

const TOOLS = new Set(['Write', 'Edit', 'MultiEdit', 'NotebookEdit', 'apply_patch']);
const MAX_PATHS = 10;
const LABEL_CAP = 5;

function isInside(child, parent) {
  const rel = path.relative(parent, child);
  return rel !== '' && !rel.startsWith('..') && !path.isAbsolute(rel);
}

function extractPaths(tool, ti) {
  const out = [];
  if (tool === 'apply_patch') {
    const body = typeof ti.command === 'string' ? ti.command : '';
    const re = /^\*\*\* (?:Add File|Update File|Move to):\s*(.+?)\s*$/gm;
    let m;
    while ((m = re.exec(body)) !== null) {
      if (m[1]) out.push(m[1]);
    }
  } else {
    const p = tool === 'NotebookEdit' ? (ti.notebook_path || ti.file_path) : ti.file_path;
    if (typeof p === 'string' && p.trim()) out.push(p.trim());
  }
  return [...new Set(out)];
}

function main() {
  const input = c.readStdinJson();
  const level = c.resolveLevel();
  if (level === 'off' || level === 'lite') return;
  const threshold = level === 'strict' ? 20 : 40;
  const tool = input.tool_name;
  if (!TOOLS.has(tool)) return;
  const ti = input.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
  const sid = input.session_id;
  const root = c.pluginRoot();
  const lines = [];

  for (const raw of extractPaths(tool, ti).slice(0, MAX_PATHS)) {
    const line = scorePath(raw, cwd, sid, root, threshold);
    if (line) lines.push(line);
  }
  if (lines.length) {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
    }) + '\n');
  }
}

// Returns a nudge line when the file is flagged, otherwise null. Records the attempt on the ledger.
function scorePath(raw, cwd, sid, root, threshold) {
  const abs = path.isAbsolute(raw) ? raw : path.resolve(cwd, raw);
  const base = path.basename(abs);
  const lower = base.toLowerCase();
  const ext = path.extname(abs).toLowerCase();
  const stem = lower.slice(0, lower.length - ext.length);

  if (/(^|[\\/])(node_modules|\.git)([\\/]|$)/.test(abs)) return null;
  if (isInside(abs, root)) return null;
  if (c.INSTRUCTION_NAMES.has(lower)) return null;
  if (c.INSTRUCTION_STEMS.has(stem) && !c.PROSE_EXTS.has(ext)) return null;

  if (c.BINARY_EXTS.has(ext)) {
    if (c.fileExists(abs)) c.appendLedger(sid, { base, kind: 'binary' });
    return null;
  }
  if (!c.PROSE_EXTS.has(ext)) return null;

  let st;
  try {
    st = fs.statSync(abs);
  } catch (e) {
    c.appendLedger(sid, { base, kind: 'failed', reason: 'file could not be read (not found on disk)' });
    return null;
  }
  if (!st.isFile()) return null;

  const isArchive = c.ARCHIVE_EXTS.has(ext);
  const cap = isArchive ? c.ARCHIVE_CAP : c.PLAIN_CAP;
  if (st.size > cap) {
    c.appendLedger(sid, { base, kind: 'skipped', limit: cap });
    return null;
  }

  const timeout = isArchive ? c.ARCHIVE_TIMEOUT_MS : c.PLAIN_TIMEOUT_MS;
  const r = c.runDetector([abs], undefined, timeout);
  if (r.kind === 'missing') {
    c.appendLedger(sid, { base, kind: 'failed', reason: 'Python not found' });
    return null;
  }
  if (r.kind === 'timeout') {
    c.appendLedger(sid, { base, kind: 'failed', reason: 'the detector timed out' });
    return null;
  }
  if (r.stdout.trim() === '') {
    c.appendLedger(sid, { base, kind: 'failed', reason: 'no usable result from the detector' });
    return null;
  }
  const parsed = c.parseReport(r.stdout);
  if (!parsed.report) {
    const reason = parsed.notReport ? 'the detector output was not a report' : 'the report had no numeric score';
    c.appendLedger(sid, { base, kind: 'failed', reason });
    return null;
  }
  if (r.status !== 0) {
    c.appendLedger(sid, { base, kind: 'failed', reason: 'no usable result from the detector' });
    return null;
  }

  const metrics = parsed.report._metrics;
  const score = metrics.ai_tell_score;
  const band = c.bandFor(score);
  const phrase = c.bandPhrase(band);
  const truncated = Boolean(metrics.truncated);
  const labels = c.findingLabels(parsed.report).slice(0, LABEL_CAP).map((x) => x.label);
  const flagged = score > threshold;
  c.appendLedger(sid, { base, kind: 'scored', score, band, phrase, labels, flagged, truncated });
  if (!flagged) return null;
  const coverage = truncated ? ', first 262,144 characters only' : '';
  const shown = labels.length ? labels.join('; ') : 'pattern families fired';
  return 'prosecheck: ' + base + ' ' + phrase + ' (score ' + score + ', band ' + band + coverage + '). Flagged: ' +
    shown + '. Fix the flagged spans, keeping the sentence rhythm varied.';
}

try {
  main();
} catch (e) {
  // Never fail the host session.
}
process.exitCode = 0;
