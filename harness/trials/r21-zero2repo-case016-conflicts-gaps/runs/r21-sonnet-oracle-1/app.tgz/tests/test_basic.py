import json, subprocess, sys, os
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DET = os.path.join(ROOT, 'scripts', 'detect.py')


def run(args, inp=b''):
    return subprocess.run([sys.executable, DET] + args, input=inp, capture_output=True)


def test_usage_first_line():
    r = run(['--help'])
    assert r.returncode == 0 and r.stdout.decode().splitlines()[0] == 'usage: detect.py [--clean] [--ci] [--] [FILE]'


def test_empty_input():
    r = run([], b'  \n')
    assert r.returncode == 1 and json.loads(r.stderr.strip().splitlines()[-1]) == {'error': 'empty input'}


def test_unknown_option():
    r = run(['--bogus'])
    assert r.returncode == 2 and b'unknown option' in r.stderr and b'--bogus' in r.stderr


def test_report_and_cleanup():
    r = run([], 'We delve into the robust tapestry​ of it.'.encode())
    d = json.loads(r.stdout)
    assert d['_metrics']['invisible_chars'] == 1 and '1_ai_vocabulary' in d
    assert run(['--clean'], 'a​b\n'.encode()).stdout == b'ab\n'
