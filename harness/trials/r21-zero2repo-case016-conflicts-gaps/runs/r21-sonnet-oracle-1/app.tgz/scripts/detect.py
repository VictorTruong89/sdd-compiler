#!/usr/bin/env python3
"""prosecheck detector: local AI-writing-pattern scan. Python standard library only."""
import json
import math
import os
import random
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import patterns as P  # noqa: E402
import charlayer as CL  # noqa: E402
import extract as EX  # noqa: E402

WINDOW = 262144
USAGE = "usage: detect.py [--clean] [--ci] [--] [FILE]"
USAGE_FULL = USAGE + """

Scores prose for AI-writing patterns (0-100) and prints a JSON report.
  --clean   print scrubbed text (invisible characters, odd spaces, lookalikes) instead of the report
  --ci      add a resampled low/high interval on the score
  --        stop option parsing (a file name may start with a dash)
  FILE      one file; with no FILE, standard input is read
  -h, --help  print this message
"""

BANDS = [(20, 'clean'), (40, 'light tells'), (60, 'mixed'), (80, 'heavy tells'), (100, 'pervasive tells')]


def band_of(score):
    for hi, name in BANDS:
        if score <= hi:
            return name
    return 'pervasive tells'


def fail(msg, code):
    sys.stderr.write(json.dumps({"error": msg}) + "\n")
    sys.stderr.flush()
    sys.exit(code)


# ---------------------------------------------------------------- masking
def _mask(text, a, b, chars):
    chars[a:b] = [(' ' if c not in '\n\r' else c) for c in chars[a:b]]


def build_mask(text):
    """Return text with excluded regions blanked (same length, newlines kept)."""
    chars = list(text)
    lines = text.split('\n')
    pos = 0
    offs = []
    for ln in lines:
        offs.append(pos)
        pos += len(ln) + 1
    n = len(lines)
    masked_line = [False] * n
    # front matter
    if n > 1 and lines[0].rstrip() == '---':
        for j in range(1, n):
            if lines[j].rstrip() in ('---', '...'):
                for k in range(0, j + 1):
                    masked_line[k] = True
                break
    # fences
    i = 0
    fence_re = re.compile(r'^( {0,3})(`{3,}|~{3,})(.*)$')
    while i < n:
        if masked_line[i]:
            i += 1
            continue
        m = fence_re.match(lines[i].rstrip('\r'))
        if m and not (m.group(2)[0] == '`' and '`' in m.group(3)):
            ch = m.group(2)[0]
            ln = len(m.group(2))
            j = i + 1
            close = None
            while j < n:
                mm = re.match(r'^ {0,3}(' + re.escape(ch) + '{%d,})[ \t]*$' % ln, lines[j].rstrip('\r'))
                if mm:
                    close = j
                    break
                j += 1
            end = close if close is not None else n - 1
            for k in range(i, end + 1):
                masked_line[k] = True
            i = end + 1
        else:
            i += 1
    # blockquote runs
    i = 0
    while i < n:
        if not masked_line[i] and re.match(r'^ {0,3}>', lines[i]):
            j = i
            while j < n and not masked_line[j] and re.match(r'^ {0,3}>', lines[j]):
                j += 1
            if j - i >= 2:
                for k in range(i, j):
                    masked_line[k] = True
            i = j
        else:
            i += 1
    badge = re.compile(r'^\s*(?:!?\[(?:!\[[^\]]*\]\([^)]*\))?[^\]]*\](?:\([^)]*\))?\s*)+$')
    for i in range(n):
        if masked_line[i]:
            continue
        s = lines[i]
        if re.match(r'^\s*\|.*\|\s*$', s) or re.match(r'^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)+\|?\s*$', s):
            masked_line[i] = True
        elif '![' in s and badge.match(s):
            masked_line[i] = True
    for i in range(n):
        if masked_line[i]:
            _mask(text, offs[i], offs[i] + len(lines[i]), chars)
    m = ''.join(chars)
    # inline code spans
    if '`' in m:
        runs = [(x.start(), x.end()) for x in re.finditer(r'`+', m)]
        out = list(m)
        i = 0
        while i < len(runs):
            a, b = runs[i]
            ln = b - a
            j = i + 1
            found = None
            while j < len(runs):
                if '\n' in m[runs[j - 1][1]:runs[j][0]] and re.search(r'\n[ \t]*\n', m[runs[j - 1][1]:runs[j][0]]):
                    break
                if runs[j][1] - runs[j][0] == ln:
                    found = j
                    break
                j += 1
                if j - i > 400:
                    break
            if found is not None:
                for k in range(a, runs[found][1]):
                    if out[k] not in '\n\r':
                        out[k] = ' '
                i = found + 1
            else:
                i += 1
        m = ''.join(out)
    return m


# ---------------------------------------------------------------- helpers
WORD_RUN = re.compile(r"(?:[^\W_]|['’-])+")


def count_words(text):
    return sum(1 for w in WORD_RUN.findall(text) if any(c.isalnum() for c in w))


def wcount(s):
    return count_words(s)


SENT_SPLIT = re.compile(r'(?<=[.!?])["\')\]]*\s+|\n[ \t]*\n+')


def sentences(masked):
    out = []
    for s in SENT_SPLIT.split(masked):
        if s and s.strip():
            # headings/list lines count as own units
            for part in s.split('\n'):
                if part.strip() and wcount(part) > 0:
                    out.append(part)
    return out


def paragraphs(masked):
    return [p for p in re.split(r'\n[ \t]*\n', masked) if p.strip()]


def cv(vals):
    if not vals:
        return None
    mean = sum(vals) / len(vals)
    if mean == 0:
        return None
    var = sum((v - mean) ** 2 for v in vals) / len(vals)
    return math.sqrt(var) / mean


def excerpt(text, s, e):
    a = max(0, s - 25)
    b = min(len(text), e + 25)
    ex = text[a:b].replace('\n', ' ').replace('\r', ' ').strip()
    if a > 0:
        ex = '...' + ex
    if b < len(text):
        ex = ex + '...'
    return ex


def snip(m):
    return m.group(0).replace('\n', ' ')[:80]


ADJ_END = re.compile(r'(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$', re.I)
STOCK_ADJ = {'innovative', 'dynamic', 'passionate', 'driven', 'reliable', 'scalable', 'robust', 'powerful', 'seamless',
             'flexible', 'efficient', 'elegant', 'modern', 'sleek', 'stunning', 'beautiful', 'intuitive', 'fast',
             'simple', 'clean', 'secure', 'smart', 'comprehensive', 'versatile', 'exciting', 'vibrant', 'lively',
             'engaging', 'rich', 'unique', 'bold', 'cutting-edge', 'user-friendly', 'effective', 'professional'}
CHAIN = re.compile(r"[A-Za-z][A-Za-z-]*(?:,\s+[A-Za-z][A-Za-z-]*){2,10}(?:,?\s+and)?\s+[A-Za-z][A-Za-z-]*(?:\s+[A-Za-z][A-Za-z-]*)?")

MOV_W = {}
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
REPORT_ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
NOSCORE_17 = True

WEIGHTS = {1: 8, 2: 10, 3: 10, 5: 10, 6: 8, 8: 7, 10: 12, 11: 10, 12: 10, 14: 10, 15: 10, 16: 9, 17: 8,
           18: 10, 20: 10, 21: 10, 23: 9, 24: 10, 25: 8, 26: 8, 27: 10, 30: 9, 31: 10, 32: 8, 33: 8, 34: 8,
           35: 8, 36: 10, 37: 9, 38: 9, 39: 10, 40: 8, 44: 6, 51: 8, 56: 4, 57: 6, 59: 4, 63: 24, 64: 24,
           65: 24, 66: 24, 62: 24, 13: 22, 47: 22, 48: 22, 50: 22, 69: 12, 70: 6, 71: 12}


def _ws_repl(mo):
    s = mo.group(0)
    k = s.count('\n')
    return '\n\n' if k >= 2 else ('\n' if k == 1 else ' ')


def _collapse(m):
    return re.sub(r'\s{4,}', _ws_repl, m)


def analyze(text):
    """Return list of findings (key,num,label,count,samples) and aux info for the window text."""
    raw = text
    m = build_mask(raw)
    F = []  # (num, slug, label, count, samples, advice)

    def add(num, slug, label, count, samples, advice=False):
        if count > 0:
            F.append((num, slug, label, count, samples[:3], advice))

    def simple(num, slug, label, rxp, advice=False, minhits=1, src=None, ex=False):
        s = src if src is not None else m
        ms = list(rxp.finditer(s))
        if len(ms) >= minhits:
            samples = [excerpt(raw, x.start(), x.end()) if ex else snip(x) for x in ms[:3]]
            add(num, slug, label, len(ms), samples, advice)
        return len(ms)

    simple(1, 'ai_vocabulary', 'AI vocabulary', P.FAM1, ex=True)
    m = _collapse(m)
    simple(2, 'model_dialect', 'Model-dialect vocabulary', P.FAM2, minhits=2)
    ms = list(P.FAM3.finditer(m))
    imp = list(P.IMPER_RX.finditer(m))
    n3 = len(ms) + (len(imp) if len(imp) >= 3 else 0)
    if n3:
        add(3, 'promotional', 'Promotional language', n3, [snip(x) for x in (ms + (imp if len(imp) >= 3 else []))[:3]])
    simple(4, 'hyphenated_pairs', 'Hyphenated word-pair overuse', P.FAM4, advice=True)
    simple(5, 'simple_yet', '"Simple yet X" cliché', P.FAM5)
    # 6 stacked adjectives
    c6 = []
    for x in P.CHAIN_RUN(m) if hasattr(P, 'CHAIN_RUN') else CHAIN.finditer(m):
        words = re.findall(r"[A-Za-z][A-Za-z-]*", x.group(0))
        words = [w for w in words if w.lower() != 'and']
        if len(words) < 4:
            continue
        last = words[-1].lower()
        if ADJ_END.search(last) or last in STOCK_ADJ:
            continue
        if any(ADJ_END.search(w) or w.lower() in STOCK_ADJ for w in words[:-1]):
            c6.append(x)
    if c6:
        add(6, 'stacked_adjectives', 'Stacked adjective chains', len(c6), [snip(x) for x in c6[:3]])
    # 8 synonym cycling
    c8 = 0
    s8 = []
    for cl in SYN_CLUSTERS:
        found = set()
        for w, r in cl:
            if r.search(m):
                found.add(w)
        if len(found) >= 3:
            c8 += 1
            s8.append('/'.join(sorted(found)))
    add(8, 'synonym_cycling', 'Synonym cycling', c8, s8)
    simple(10, 'significance_inflation', 'Significance inflation', P.FAM10)
    ms = list(P.FAM11.finditer(raw)) if False else list(P.FAM11.finditer(m)) + list(P.FAM11B.finditer(m))
    if ms:
        add(11, 'notability_name_dropping', 'Notability name-dropping', len(ms), [snip(x) for x in ms[:3]])
    simple(12, 'vague_attributions', 'Vague attributions', P.FAM12)
    simple(13, 'article_title_proper_noun', 'Article title as proper noun', P.FAM13)
    simple(14, 'conservation_padding', 'Conservation / ecosystem padding', P.FAM14)
    simple(15, 'false_ranges', 'False ranges', P.FAM15)
    simple(16, 'ing_tails', 'Superficial -ing tail clauses', P.FAM16)
    # 17
    ms = []
    for r in P.FAM17P:
        ms += list(r.finditer(m))
    if ms:
        add(17, 'negative_parallelism', 'Negative parallelisms', len(ms), [snip(x) for x in ms[:3]], True)
    mt = list(P.FAM17T.finditer(m))
    if mt:
        add(17, 'tailing_negation', 'Tailing negations', len(mt), [snip(x) for x in mt[:3]], False)
    simple(18, 'not_x_just_y', '"Not X, just Y" construction', P.FAM18)
    simple(19, 'filler_phrases', 'Filler phrases', P.FAM19, advice=True)
    simple(20, 'empty_pivots', 'Empty pivot phrases', P.FAM20)
    simple(21, 'outcome_speculation', 'Outcome-speculation tails', P.FAM21)
    simple(22, 'authority_tropes', 'Persuasive authority tropes', P.FAM22, advice=True)
    simple(23, 'editorial_interjections', 'Editorial interjections', P.FAM23)
    simple(24, 'self_thoroughness', 'Self-thoroughness phrases', P.FAM24)
    simple(25, 'question_answer', 'Question-answer rhetorical pattern', P.FAM25)
    simple(26, 'concrete_evidence', '"Concrete evidence" defense phrase', P.FAM26)
    simple(27, 'intro_hooks', 'Compulsive intro hooks', P.FAM27)
    simple(30, 'diff_anchored', 'Diff-anchored writing', P.FAM30)
    simple(31, 'signposting', 'Signposting and announcements', P.FAM31)
    simple(32, 'cataloguing_leadins', 'Cataloguing lead-ins', P.FAM32)
    simple(33, 'inline_header_lists', 'Inline-header vertical lists', P.FAM33)
    # 34
    has_heading = re.search(r'^ {0,3}#{1,6}[ \t]+\S', m, re.M) is not None
    if not has_heading:
        paras = paragraphs(m)
        lp = 0
        pp = 0
        li = re.compile(r'^\s*(?:[-*+]|\d+[.)])\s+\S')
        for p in paras:
            ls = [l for l in p.split('\n') if l.strip()]
            if ls and all(li.match(l) for l in ls):
                lp += 1
            else:
                pp += 1
        if lp >= 1 and pp >= 2:
            add(34, 'bullet_injection', 'Mid-essay bullet injection', lp, ['bulleted paragraph'])
    # 35
    ls = m.split('\n')
    c35 = 0
    s35 = []
    for i, l in enumerate(ls):
        hm = re.match(r'^ {0,3}#{1,6}[ \t]+(.+?)[ \t#]*$', l)
        if not hm:
            continue
        j = i + 1
        while j < len(ls) and not ls[j].strip():
            j += 1
        if j >= len(ls):
            continue
        nx = ls[j].strip()
        if re.match(r'^(#|[-*+]\s|\d+[.)]\s|\|)', nx):
            continue
        nw = re.findall(r"[A-Za-z0-9']+", nx)
        if 0 < len(nw) <= 5:
            hw = {w.lower() for w in re.findall(r"[A-Za-z0-9']+", hm.group(1)) if len(w) > 3}
            if any(w.lower() in hw for w in nw):
                c35 += 1
                s35.append(hm.group(1)[:60])
    add(35, 'fragmented_headers', 'Fragmented headers', c35, s35)
    simple(36, 'formulaic_challenges', 'Formulaic challenges sections', P.FAM36)
    # 37
    c37 = 0
    s37 = []
    for p in paragraphs(m):
        ts = list(P.TRANS.finditer(p))
        if len(ts) >= 2:
            c37 += len(ts)
            s37.append(ts[0].group(0).strip())
    add(37, 'transition_clusters', 'Transition cluster overuse', c37, s37)
    simple(38, 'compulsive_conclusions', 'Compulsive conclusion phrases', P.FAM38)
    simple(39, 'generic_positive_conclusions', 'Generic positive conclusions', P.FAM39)
    # rhythm
    sents = sentences(m)
    lens = [wcount(s) for s in sents]
    if len(lens) >= 3:
        c = cv(lens)
        if c is not None and c < 0.35:
            add(40, 'sentence_length_monotony', 'Sentence-length monotony', 1, ['%d sentences, cv %.2f' % (len(lens), c)])
    # 41
    c41 = 0
    i = 0
    while i + 5 < len(lens):
        w = lens[i:i + 6]
        ok = all(abs(w[k] - w[k + 1]) >= 5 for k in range(5)) and \
            all(((w[k + 1] - w[k]) > 0) != ((w[k + 2] - w[k + 1]) > 0) for k in range(4))
        if ok:
            c41 += 1
            i += 6
        else:
            i += 1
    add(41, 'mechanical_alternation', 'Mechanical sentence-length alternation', c41, ['alternating lengths'], True)
    paras = paragraphs(m)
    # 42
    c42 = 0
    s42 = []
    for p in paras:
        ss = [s.strip() for s in SENT_SPLIT.split(p) if s and s.strip()]
        if len(ss) >= 3:
            cnt = {}
            for s in ss:
                w = re.findall(r"[A-Za-z']+", s.lower())[:2]
                if len(w) == 2:
                    cnt[' '.join(w)] = cnt.get(' '.join(w), 0) + 1
            for k, v in cnt.items():
                if v >= 3:
                    c42 += 1
                    s42.append(k)
    add(42, 'opener_repetition', 'Opener repetition', c42, s42, True)
    # 44
    if len(paras) >= 4:
        pl = [wcount(p) for p in paras]
        c = cv(pl)
        if c is not None and c < 0.4:
            add(44, 'uniform_paragraphs', 'Uniform paragraph length', 1, ['%d paragraphs, cv %.2f' % (len(pl), c)])
    # 46
    nwords = count_words(raw)
    if nwords >= 300 and ';' not in m and m.count('(') <= 1:
        add(46, 'semicolon_paren_underuse', 'Semicolon and parenthesis underuse', 1, ['no semicolons'], True)
    simple(47, 'chatbot_artifacts', 'Chatbot artifacts', P.FAM47)
    simple(48, 'sycophantic_tone', 'Sycophantic tone', P.FAM48)
    simple(50, 'knowledge_cutoff', 'Knowledge-cutoff disclaimers', P.FAM50)
    simple(51, 'copula_avoidance', 'Copula avoidance', P.FAM51)
    # 54
    c54 = 0
    s54 = []
    for s in sentences(m):
        hs = P.FAM54_HEDGE.findall(s)
        if len(hs) >= 2:
            c54 += 1
            s54.append(s.strip()[:60])
    add(54, 'hedge_stacking', 'Excessive hedging', c54, s54, True)
    # 55
    fp = len(re.findall(r"\b(?:i|me|my|mine|myself|we|our|ours|us)\b", m, re.I))
    if nwords and fp / max(nwords, 1) >= 0.02:
        full = len(re.findall(r"\b(?:do not|does not|did not|is not|are not|was not|were not|have not|has not|had not|will not|would not|should not|could not|cannot|can not|it is|that is|there is|i am|i have|i will|i would|we are|we have|we will|they are|you are|let us)\b", m, re.I))
        con = len(re.findall(r"\b\w+n['’]t\b|\b(?:i|we|you|they)['’](?:m|re|ve|ll|d)\b|\b(?:it|that|there|he|she|what|who)['’]s\b", m, re.I))
        if full + con >= 4 and full / (full + con) > 0.6:
            add(55, 'contraction_absence', 'Contraction absence', full, ['written-out forms: %d' % full], True)
    # 56
    simple(56, 'boldface', 'Boldface overuse', P.FAM56)
    simple(57, 'emojis', 'Emojis', P.FAM57)
    # 58
    c58 = 0
    for p in paras:
        k = p.count('—')
        if k >= 2:
            c58 += k
    add(58, 'em_dash_overuse', 'Em-dash overuse', c58, ['—'], True)
    # 59
    c59 = 0
    s59 = []
    minor = {'a', 'an', 'the', 'and', 'but', 'or', 'nor', 'for', 'so', 'yet', 'of', 'in', 'on', 'at', 'to', 'by',
             'up', 'as', 'is', 'if', 'it', 'off', 'per', 'via', 'with', 'from', 'into', 'over', 'out'}
    for l in m.split('\n'):
        hm = re.match(r'^ {0,3}#{1,6}[ \t]+(.+?)[ \t#]*$', l)
        if not hm:
            continue
        h = hm.group(1)
        ws = h.split()
        if len(ws) < 3 or not h[0].isalpha() or h.upper() == h:
            continue
        major = [w for w in ws if w.lower().strip('.,:;!?') not in minor]
        if len(major) >= 2 and all(w[0].isupper() for w in major if w[0].isalpha()):
            c59 += 1
            s59.append(h[:60])
    add(59, 'title_case_headings', 'Title case in headings', c59, s59)
    simple(60, 'curly_quotes', 'Curly quotation marks', P.FAM60, advice=True, src=m)
    c61 = [x for x in P.FAM61.finditer(m) if int(x.group(1)) < int(x.group(2))]
    add(61, 'hyphen_year_range', 'Hyphen for en dash in ranges', len(c61), [snip(x) for x in c61[:3]], True)
    # 63
    c63 = []
    for x in P.FAM63A.finditer(m):
        inner = x.group(1).strip()
        if re.match(r'^(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b', inner, re.I):
            c63.append(x)
        elif len(inner.split()) <= 5 and re.search(r'\b(?:name|company|client|person|place|city|source|employer|recipient|position|address)\b', inner, re.I) and not re.match(r'^\d', inner):
            c63.append(x)
        elif re.match(r'^[A-Z][A-Z0-9 _/&-]*$', inner) and not re.match(r'^[A-Z]{1,3}\d{0,3}$', inner) and re.search(r'[A-Z]{2}', inner):
            c63.append(x)
    c63 += list(P.FAM63B.finditer(m))
    c63 += list(P.FAM63C.finditer(m))
    add(63, 'placeholder_text', 'Placeholder / Mad-Libs text', len(c63), [snip(x) for x in c63[:3]])
    simple(64, 'chat_markup', 'Chatbot reference-markup leak', P.FAM64)
    c65 = []
    for x in P.FAM65.finditer(m):
        host = x.group(1).rstrip('.').lower()
        if host in P.AI_HOSTS:
            c65.append(x)
    add(65, 'tracking_params', 'AI tracking parameters', len(c65), [snip(x) for x in c65[:3]])
    simple(69, 'marketing_slop', 'Canonical marketing-slop phrases', P.FAM69)
    # 70
    nl = raw.count('\n') + 1
    hrs = list(P.HR.finditer(m))
    if len(hrs) >= 3 and nl >= 24:
        add(70, 'decorative_rules', 'Decorative horizontal rules', len(hrs), ['---'])
    # 71
    ws = [w.lower() for w in re.findall(r"[^\W_]+(?:['’-][^\W_]+)*", m)]
    if len(ws) >= 12:
        sh = {}
        keys = []
        for i in range(len(ws) - 5):
            k = tuple(ws[i:i + 6])
            keys.append(k)
            sh[k] = sh.get(k, 0) + 1
        rep = sum(1 for k in keys if sh[k] > 1)
        if rep >= 5 and rep / len(keys) >= 0.2:
            add(71, 'degenerate_repetition', 'Degenerate repetition', rep, [' '.join(next(k for k in keys if sh[k] > 1))])
    return F


SYN_CLUSTERS = []
for _cl in P.SYN:
    SYN_CLUSTERS.append([(w, re.compile(r'\b' + w.replace(' ', r'\s+') + r'(?:s|es)?\b' if not w.endswith('y') else r'\b' + w[:-1] + r'(?:y|ies)\b', re.I)) for w in _cl])


def char_findings(win):
    F = []
    inv, spaces = CL.analyze(win)
    if inv:
        idx = sorted(inv)[:3]
        F.append((62, 'invisible_chars', 'Invisible / zero-width characters', len(inv),
                  ['U+%04X' % ord(win[i]) for i in idx], False))
    runs = CL.homoglyph_runs(win)
    hg = sum(sum(1 for ch in win[a:b] if not ch.isascii()) for a, b in runs)
    if runs:
        F.append((66, 'homoglyphs', 'Homoglyph / mixed-script confusables', len(runs),
                  [win[a:b] for a, b in runs[:3]], False))
    if spaces:
        idx = sorted(spaces)[:3]
        F.append((67, 'nonstandard_spaces', 'Non-standard spaces', len(spaces),
                  ['U+%04X' % ord(win[i]) for i in idx], False))
    c68 = 0
    c68 += len(CL.trailing_spans(win))
    tail = win[len(win.rstrip(' \t\r\n\f\v')):]
    if tail.count('\n') >= 2:
        c68 += 1
    if win[:1].isspace():
        c68 += 1
    if c68:
        F.append((68, 'trailing_whitespace', 'Trailing / stray whitespace', c68, ['whitespace'], True))
    return F, len(inv), len(spaces), hg


def compute_score(F, words):
    """F: list of (num,slug,label,count,samples,advice). Returns score, confidence, reason, families."""
    mov = {}
    for num, slug, label, count, samples, advice in F:
        if advice:
            continue
        w = WEIGHTS.get(num, 8)
        pts = w * (1 + min(count - 1, 4) * 0.25)
        mov[num] = mov.get(num, 0) + pts
    fams = set(mov)
    # confidence
    if words < 40:
        conf, reason = 'none', 'fewer than 40 words; too short to score reliably'
    elif words < 120:
        conf, reason = 'low', 'fewer than 120 words; short text'
    elif words < 300 and len(fams) == 1:
        conf, reason = 'low', 'under 300 words with only one score-moving pattern family'
    elif words < 300:
        conf, reason = 'moderate', 'under 300 words'
    else:
        conf, reason = 'high', ''
    if not fams:
        return 0, conf, reason, fams
    score = min(100.0, sum(mov.values()))
    dec = fams & DECISIVE
    single_dec_floor = len(fams) == 1 and len(dec) == 1 and conf in ('moderate', 'high')
    if len(fams) == 1 and not single_dec_floor:
        score = min(score, 40)
    if fams <= {40, 44}:
        score = min(score, 40)
    if fams == {40}:
        score = min(score, 20)
    floor = 0
    if len(dec) >= 2:
        floor = max(floor, 65)
    elif len(dec) == 1 and conf in ('moderate', 'high'):
        floor = max(floor, 45)
    if words < 120:
        k = len([f for f in fams if (1 <= f <= 39) or (47 <= f <= 51) or f == 69])
        if k >= 3:
            floor = max(floor, 45)
        elif k >= 2:
            floor = max(floor, 25)
    if words >= 400:
        if len(fams) >= 6:
            floor = max(floor, 45)
        elif len(fams) >= 5:
            floor = max(floor, 25)
    score = int(round(max(score, floor)))
    return max(0, min(100, score)), conf, reason, fams


def build_report(text, ci=False):
    truncated = len(text) > WINDOW
    win = text[:WINDOW]
    F, ninv, nsp, nhg = char_findings(win)
    F += analyze(win)
    words = count_words(win)
    score, conf, reason, fams = compute_score(F, words)
    rep = {}
    seen_keys = set()
    for num, slug, label, count, samples, advice in sorted(F, key=lambda f: (f[0], f[1])):
        key = '%d_%s' % (num, slug)
        if key in seen_keys:
            continue
        seen_keys.add(key)
        rep[key] = {'label': label, 'count': int(count), 'samples': [str(s) for s in samples]}
    met = {
        'scanned_chars': len(win),
        'truncated': truncated,
        'ai_tell_score': score,
        'ai_tell_band': band_of(score),
        'confidence': conf,
        'confidence_reason': reason if conf != 'high' else '',
        'patterns_flagged': len(rep),
        'invisible_chars': ninv,
        'nonstandard_spaces': nsp,
        'homoglyphs': nhg,
        'words': words,
    }
    if ci:
        sents = sentences(build_mask(win))
        if len(sents) >= 4:
            rng = random.Random(1729)
            n = 40 if len(win) < 30000 else 8
            vals = []
            for _ in range(n):
                samp = [sents[rng.randrange(len(sents))] for _ in sents]
                t = '. '.join(s.strip().rstrip('.!?') for s in samp) + '.'
                Fs, _, _, _ = char_findings(t)
                Fs += analyze(t)
                sc, _, _, _ = compute_score(Fs, count_words(t))
                vals.append(sc)
            vals.sort()
            lo = vals[int(0.05 * (len(vals) - 1))]
            hi = vals[int(math.ceil(0.95 * (len(vals) - 1)))]
            lo = min(lo, score)
            hi = max(hi, score)
            met['score_ci'] = [lo, hi]
            met['score_ci_note'] = 'resampled over %d sentences (%d resamples)' % (len(sents), n)
        else:
            met['score_ci'] = None
            met['score_ci_note'] = 'too few sentences (need at least 4) for an interval'
    rep['_metrics'] = met
    return rep


def read_input(path):
    if path is None:
        raw = sys.stdin.buffer.read()
        return EX.decode_bytes(raw)
    ext = os.path.splitext(path)[1].lower()
    try:
        with open(path, 'rb') as f:
            raw = f.read()
    except (OSError, ValueError) as e:
        fail('cannot read input: %s' % (getattr(e, 'strerror', None) or e), 1)
    try:
        return EX.extract_bytes(raw, ext)
    except EX.NotZip:
        fail('cannot read input: %s is not a readable zip archive' % path, 1)


def main(argv):
    clean = False
    ci = False
    operands = []
    i = 0
    while i < len(argv):
        a = argv[i]
        if a == '--':
            operands.extend(argv[i + 1:])
            break
        if a in ('-h', '--help'):
            sys.stdout.write(USAGE_FULL)
            return 0
        if a == '--clean':
            clean = True
        elif a == '--ci':
            ci = True
        elif a.startswith('-'):
            fail('unknown option: %s (see --help)' % a, 2)
        else:
            operands.append(a)
        i += 1
    path = operands[0] if operands else None
    if len(operands) > 1:
        sys.stderr.write('note: only the first file was scanned: %s\n' % operands[0])
    text = read_input(path)
    if not text.strip():
        fail('empty input', 1)
    if clean:
        out = CL.scrub(text)
        sys.stdout.buffer.write(out.encode('utf-8', errors='replace'))
        sys.stdout.buffer.flush()
        return 0
    rep = build_report(text, ci)
    sys.stdout.buffer.write((json.dumps(rep, ensure_ascii=False, indent=2) + '\n').encode('utf-8', errors='replace'))
    sys.stdout.buffer.flush()
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv[1:]))
    except SystemExit:
        raise
    except BrokenPipeError:
        sys.exit(0)
    except Exception as e:  # never a traceback
        sys.stderr.write(json.dumps({"error": "cannot read input: internal error: %s" % e}) + "\n")
        sys.exit(1)
