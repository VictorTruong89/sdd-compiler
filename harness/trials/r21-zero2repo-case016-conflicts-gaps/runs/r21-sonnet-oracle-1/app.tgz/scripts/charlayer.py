"""Character layer: invisible characters, non-standard spaces, homoglyphs, cleanup.
# spec: N-000300 (cleanup) / catalogue 62, 66, 67, 68"""
import re
import unicodedata

NON_CF_VISIBLE = set(list(range(0x600, 0x606)) + [0x6DD, 0x70F, 0x8E2, 0x110BD, 0x110CD])
EXTRA_INVIS = {0x034F, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x3164, 0xFFA0}
CAND = re.compile(r'[^\x20-\x7e\t\n\r]')

TAG_SEQ = re.compile('\U0001F3F4[\U000E0020-\U000E007E]+\U000E007F')


def is_invisible(c):
    cp = ord(c)
    if cp < 0x80:
        return (cp < 32 and c not in '\t\n\r') or cp == 0x7F
    if 0xE0000 <= cp <= 0xE0FFF:
        return True
    if cp in EXTRA_INVIS or 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF or 0x180B <= cp <= 0x180F:
        return True
    cat = unicodedata.category(c)
    if cat == 'Cc':
        return True
    if cat == 'Cf':
        return cp not in NON_CF_VISIBLE
    return False


def is_space_sep(c):
    cp = ord(c)
    if cp == 0x20 or cp < 0x80:
        return False
    return unicodedata.category(c) in ('Zs', 'Zl', 'Zp')


def _in(cp, ranges):
    for a, b in ranges:
        if a <= cp <= b:
            return True
    return False


NOSPACE = [(0x0E00, 0x0E7F), (0x0E80, 0x0EFF), (0x1780, 0x17FF), (0x1000, 0x109F), (0x3040, 0x30FF),
           (0x31F0, 0x31FF), (0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x3FFFF),
           (0xFF66, 0xFF9F)]
CJK = [(0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x3FFFF), (0x3005, 0x3007)]
RTL = [(0x0590, 0x08FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF), (0x10800, 0x10FFF), (0x1E800, 0x1EFFF)]
JOINING = [(0x0590, 0x06FF), (0x0700, 0x074F), (0x0750, 0x077F), (0x08A0, 0x08FF), (0x0900, 0x0DFF),
           (0x1000, 0x109F), (0x1780, 0x17FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF)]
MONGOLIAN = [(0x1820, 0x18AF)]
KHMER = [(0x1780, 0x17FF)]
BIDI = {0x200E, 0x200F, 0x061C, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E, 0x2066, 0x2067, 0x2068, 0x2069}


def _emoji_or_symbol(c):
    cp = ord(c)
    if _in(cp, [(0x1F000, 0x1FAFF), (0x2190, 0x21FF), (0x2300, 0x23FF), (0x2600, 0x27BF), (0x2B00, 0x2BFF),
                (0x2100, 0x214F), (0x3030, 0x3030), (0x303D, 0x303D), (0x3297, 0x3299)]):
        return True
    if c in '#*0123456789©®‼⁉':
        return True
    return unicodedata.category(c).startswith('S')


def _is_vs(cp):
    return 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF


def _letter(c):
    return c.isalpha()


def analyze(text):
    """Return (invisible_removed_indices:set, space_actions:dict idx->str, kept_count info)."""
    inv = set()
    spaces = {}
    cands = [m.start() for m in CAND.finditer(text)]
    if not cands:
        return inv, spaces
    n = len(text)
    # tag sequences
    keep_tags = set()
    if '\U0001F3F4' in text:
        for m in TAG_SEQ.finditer(text):
            keep_tags.update(range(m.start() + 1, m.end()))
    has_rtl = None
    for i in cands:
        c = text[i]
        cp = ord(c)
        if is_invisible(c):
            prev = text[i - 1] if i > 0 else ''
            nxt = text[i + 1] if i + 1 < n else ''
            pcp = ord(prev) if prev else -1
            ncp = ord(nxt) if nxt else -1
            keep = False
            if 0xE0000 <= cp <= 0xE0FFF and i in keep_tags:
                keep = True
            elif _is_vs(cp):
                if prev and (_in(pcp, CJK) or _emoji_or_symbol(prev)):
                    keep = True
                elif ncp == 0x20E3:
                    keep = True
                elif 0x180B <= cp <= 0x180D:
                    keep = False
            elif cp == 0x200B:
                if (prev and _in(pcp, NOSPACE)) or (nxt and _in(ncp, NOSPACE)):
                    keep = True
            elif cp == 0x00AD:
                if prev and nxt and _letter(prev) and _letter(nxt):
                    keep = True
            elif cp in BIDI:
                if has_rtl is None:
                    has_rtl = any(_in(ord(ch), RTL) for ch in text if ord(ch) > 0x58F)
                keep = has_rtl
            elif 0x180B <= cp <= 0x180F:
                if prev and _in(pcp, MONGOLIAN):
                    keep = True
            elif cp in (0x17B4, 0x17B5):
                if (prev and _in(pcp, KHMER)) or (nxt and _in(ncp, KHMER)):
                    keep = True
            elif cp in (0x200C, 0x200D):
                for nb, ncp_ in ((prev, pcp), (nxt, ncp)):
                    if nb and ((_letter(nb) and _in(ncp_, JOINING)) or _emoji_or_symbol(nb) and not nb.isalnum()):
                        keep = True
            if not keep:
                inv.add(i)
        elif is_space_sep(c):
            if cp in (0xA0, 0x202F):
                prev = text[i - 1] if i > 0 else ''
                nxt = text[i + 1] if i + 1 < n else ''
                if (prev and prev.isdigit()) or (nxt and nxt.isdigit()) or (nxt and nxt in ':;!?»›%€') \
                        or (prev and prev in '«‹'):
                    continue
            spaces[i] = '\n' if cp in (0x2028, 0x2029) else ' '
    return inv, spaces


LOOK = {}
for _src, _dst in [
    ('асеорхуіјѕԁԍһԝѵ', 'acepxyijsdghwv'),
    ('АВСЕНІЈКМОРЅТХУ', 'ABCEHIJKMOPSTXY'),
    ('οανυιρχγη', 'oavuipxyn'),
    ('ΑΒΕΖΗΙΚΜΝΟΡΤΥΧ', 'ABEZHIKMNOPTYX'),
    ('օսոցհյ', 'ounghj'),
    ('ՍՕ', 'SO'),
]:
    for a, b in zip(_src, _dst):
        LOOK[a] = b

RUN = re.compile(r'[^\W\d_]+')


def homoglyph_runs(text):
    """Yield (start, end) of mixed-script letter runs meeting the homoglyph condition."""
    res = []
    if text.isascii():
        return res
    for m in RUN.finditer(text):
        s = m.group()
        if s.isascii():
            continue
        has_ascii = False
        has_look = False
        ok = True
        for ch in s:
            if ch.isascii():
                has_ascii = True
            elif ch in LOOK:
                has_look = True
            else:
                ok = False
                break
        if ok and has_ascii and has_look:
            # skip web addresses
            ts = text.rfind(' ', 0, m.start()) + 1
            tn = len(text)
            te = m.end()
            while te < tn and not text[te].isspace():
                te += 1
            tok = text[ts:te]
            if '://' in tok or tok.lower().startswith('www.'):
                continue
            res.append((m.start(), m.end()))
    return res


def counts(text):
    inv, spaces = analyze(text)
    hg = sum(sum(1 for ch in text[a:b] if not ch.isascii()) for a, b in homoglyph_runs(text))
    return len(inv), len(spaces), hg


_WS_RUN = re.compile(r'[ \t]+')


def trailing_spans(text):
    n = len(text)
    res = []
    for m in _WS_RUN.finditer(text):
        e = m.end()
        if e < n and not (text[e] == '\n' or (text[e] == '\r' and text[e + 1:e + 2] == '\n')):
            continue
        if e < n and text[e] == '\r' and text[e + 1:e + 2] != '\n':
            continue
        res.append((m.start(), e))
    return res


def strip_line_trailing(text):
    spans = [(a, b) for a, b in trailing_spans(text) if b < len(text)]
    if not spans:
        return text
    out = []
    last = 0
    for a, b in spans:
        out.append(text[last:a])
        last = b
    out.append(text[last:])
    return ''.join(out)


def scrub(text):
    inv, spaces = analyze(text)
    runs = homoglyph_runs(text)
    fold = {}
    for a, b in runs:
        for i in range(a, b):
            if text[i] in LOOK:
                fold[i] = LOOK[text[i]]
    if inv or spaces or fold:
        out = []
        for i, ch in enumerate(text):
            if i in inv:
                continue
            if i in spaces:
                out.append(spaces[i])
            elif i in fold:
                out.append(fold[i])
            else:
                out.append(ch)
        text = ''.join(out)
    ended_lf = text.endswith('\n')
    crlf = text.endswith('\r\n')
    text = strip_line_trailing(text)
    text = re.sub(r'\A(?:[ \t]*\r?\n)+', '', text)
    text = re.sub(r'\A[ \t]+', '', text)
    text = text.rstrip(' \t\r\n\f\v')
    if ended_lf and text:
        text += '\r\n' if crlf else '\n'
    return text
