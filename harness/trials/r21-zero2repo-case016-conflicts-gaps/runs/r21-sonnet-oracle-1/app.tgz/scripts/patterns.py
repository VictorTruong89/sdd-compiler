"""Lexical catalogue families. Each entry: (num, slug, label, kind, weight, spec)
kind: 'adv' (writing advice, weight 0) or 'mov' (score-moving)."""
import re

A = "['’]"
I = re.I


def infl(w):
    w = w.strip()
    if ' ' in w:
        first, rest = w.split(' ', 1)
        return infl(first) + r'\s+' + rest.replace(' ', r'\s+')
    if w.endswith('e'):
        s = w[:-1]
        return s + '(?:e|es|ed|ing|er|ers)'
    if w.endswith('y') and len(w) > 2 and w[-2] not in 'aeiou':
        s = w[:-1]
        return s + '(?:y|ies|ied|ying)'
    return w + '(?:s|es|ed|ing)?'


def words(lst, inflect=True):
    parts = [infl(w) if inflect else re.escape(w).replace(r'\ ', r'\s+') for w in lst]
    return r'\b(?:' + '|'.join(parts) + r')\b'


def rx(p, flags=I):
    return re.compile(p, flags)


F1 = ['additionally', 'align with', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant', 'meticulous',
      'testament', 'underscore', 'intricate', 'intricacy', 'intricacies', 'interplay', 'garner', 'bolster',
      'foster', 'showcase', 'emphasize', 'enduring', 'enhance', 'leverage', 'utilize', 'facilitate',
      'encompass', 'harness', 'holistic', 'paradigm', 'transformative', 'unprecedented', 'myriad',
      'plethora', 'robust', 'seamless', 'navigate', 'embark', 'craft', 'landscape', 'journey', 'realm',
      'multifaceted', 'elevate', 'empower', 'unlock']
FAM1 = rx(words(F1) + r'|\bseamlessly\b|\brobustly\b|\bcapture[sd]?\s+(?:the\s+)?(?:essence|spirit|imagination|heart|magic)\b|\bcapturing\s+(?:the\s+)?(?:essence|spirit|imagination|heart|magic)\b|\bemphasi[sz]e[sd]?\b|\bemphasi[sz]ing\b')

FAM2 = rx(r'\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly)\b'
          r'|\bquietly\s+(?:powerful|profound|radical)\b|\bdeeply\s+(?:human|personal|felt|unsettling)\b'
          r'|\bresonates?\s+deeply\b|\bgame[- ]chang(?:er|ers|ing)\b|\bsupercharg(?:e|es|ed|ing)\b'
          r'|\bskyrocket(?:s|ed|ing)?\b|\bturbocharg(?:e|es|ed|ing)\b|\brevolutioni[sz](?:e|es|ed|ing)\b'
          r'|\bdoubl(?:e|es|ed|ing)\s+down\s+on\b|\bdiv(?:e|es|ed|ing)\s+deep(?:er)?\s+into\b'
          r'|\bunlock(?:s|ed|ing)?\s+(?:the\s+)?(?:power|potential|value)\b|\btake[sn]?\s+.{1,40}?\s+to\s+the\s+next\s+level\b')

FAM3 = rx(r'\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|vibrant community|rich cultural heritage|'
          r'in the heart of|world-class|top-tier|unparalleled|premier|esteemed organi[sz]ation|valuable asset|'
          r'passion for excellence|proven track record|results-oriented|wealth of experience|dynamic team|'
          r'fast-paced environment|deeply passionate|perfectly situated|close-knit team|tight-knit team|'
          r'uniquely positioned to)\b|\bleading\s+(?:provider|company|firm|brand|expert|authority|player|platform|manufacturer|supplier|organi[sz]ation)\b'
          r'|\bi am excited to (?:apply|bring)\b|\bi' + A + r'm excited to (?:apply|bring)\b')
IMPER = ['install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape', 'transform', 'reclaim',
         'unlock', 'elevate', 'boost', 'say', 'imagine', 'explore', 'meet', 'introducing', 'upgrade', 'claim',
         'unleash', 'supercharge', 'level', 'stop', 'start']
IMPER_RX = re.compile(r'(?:^|(?<=[.!?])\s+|\n)\s*(?:' + '|'.join(IMPER) + r')\b', re.I | re.M)

HYPH = ['results-oriented', 'detail-oriented', 'goal-oriented', 'fast-paced', 'cutting-edge', 'state-of-the-art',
        'best-in-class', 'world-class', 'top-tier', 'data-driven', 'customer-centric', 'game-changing',
        'mission-critical', 'forward-thinking', 'end-to-end', 'next-generation', 'high-performing',
        'results-driven', 'value-added', 'well-rounded', 'hands-on', 'user-friendly', 'cross-functional',
        'thought-provoking', 'wide-ranging', 'far-reaching', 'long-standing', 'ever-evolving', 'ever-changing',
        'fast-growing', 'one-of-a-kind', 'time-tested', 'high-quality', 'results-focused', 'client-focused',
        'solution-oriented', 'team-oriented', 'self-motivated', 'results-proven', 'future-proof', 'game-changer',
        'tried-and-true', 'cutting edge', 'big-picture', 'ever-growing', 'trail-blazing', 'groundbreaking']
FAM4 = rx(r'(?<![\w-])(?:' + '|'.join(re.escape(h).replace(r'\ ', r'\s+') for h in HYPH if ' ' not in h) + r')(?![\w-])')

FAM5 = rx(r'\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b')

SYN = [['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
       ['company', 'firm', 'organization', 'organisation', 'enterprise', 'business'],
       ['author', 'writer', 'novelist', 'scribe'],
       ['report', 'study', 'analysis', 'investigation', 'examination'],
       ['technology', 'tool', 'system', 'platform', 'solution'],
       ['technique', 'method', 'approach', 'strategy', 'tactic'],
       ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
       ['benefit', 'advantage', 'upside', 'strength']]
SYN_RX = []
for cl in SYN:
    SYN_RX.append([re.compile(r'\b' + (w.replace(' ', r'\s+')) + r'(?:s|es)?\b' if not w.endswith('y') else r'\b' + w[:-1] + r'(?:y|ies)\b', I) for w in cl])
SYN_RX = [[re.compile(r'\b(?:' + (('|'.join([w.replace(' ', r'\s+') for w in cl]))) + r')(?:s|es)?\b', I)] for cl in SYN]

FAM10 = rx(r'\b(?:stand(?:s|ing)?|stood|serv(?:e|es|ed|ing))\s+as\s+(?:a|an)\s+(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b'
           r'|\b(?:underscor|highlight)(?:es|ed|ing|s|e)\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b'
           r'|\breflects?\s+a\s+broader\s+(?:trend|shift|pattern)\b'
           r'|\bmarks?\s+a\s+(?:turning point|milestone|watershed|new chapter|new era)\b'
           r'|\bsymboli[sz]es\b|\bsets?\s+the\s+stage\s+for\b|\bleft\s+an\s+indelible\s+mark\b'
           r'|\bplays?\s+a\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b'
           r'|\bhas\s+(?:shaped|sparked)\b|\bhas\s+come\s+to\s+(?:define|symboli[sz]e)\b')
FAM11 = rx(r'\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+(?:[A-Z][\w&.\']+(?:\s+[A-Z][\w&.\']+)*)\s*(?:,|and|&)\s*(?:and\s+)?[A-Z][\w&.\']+', 0) 
FAM11B = rx(r'\b\d[\d,.]*\s*[kKmM]?\+?\s+(?:followers|subscribers)\b|\b(?:strong|active|robust|notable)\s+(?:online|digital|social[- ]media)\s+presence\b'
            r'|\bwidely\s+(?:covered|reported)\b|\bindependent\s+coverage\b|\bsocial[- ]media\s+presence\b')
FAM12 = rx(r'\bexperts?\s+(?:argue|believe|say|claim|note|suggest)\b|\bindustry\s+(?:reports|observers|analysts)\b'
           r'|\bobservers\s+have\s+(?:cited|noted)\b|\bsome\s+critics\s+argue\b|\bresearchers\s+have\s+found\b'
           r'|\bstudies\s+suggest\b|\bit\s+is\s+widely\s+believed\b')
FAM13 = re.compile(r'\b[Tt]he\s+(?:List|Index|Compilation|Collection|Catalogue|Guide|Overview)\s+of\s+[^.!?\n]{1,80}?\s+(?:is|are)\s+(?:an?|the)\b')
FAM14 = rx(r'\bplays?\s+a\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b'
           r'|\bconservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)\b|\bserves?\s+as\s+an\s+indicator\s+species\b'
           r'|\bcontributes?\s+to\s+biodiversity\b')
FAM15 = rx(r'\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]{0,120}?\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering|grand|sprawling)\b')
FAM16 = rx(r',\s+(?:highlighting|reflecting|symbolizing|symbolising|emphasizing|emphasising|underscoring|showcasing|fostering|cultivating|encompassing|signaling|signalling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing|epitomising)\b')
FAM17P = [rx(r'\bit' + A + r's\s+not\s+(?:just|merely)\s+(?:about|an?)\b'),
          rx(r'\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b'),
          rx(r'\bdoesn' + A + r't\s+just\b[^.,\n]{0,40}?\bit\b')]
FAM17T = rx(r',\s+no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b')
FAM18 = rx(r'\b(?:no|not)\s+\w+,\s+(?:just|only|simply)\s+\w+'
           r'|\b(?:not|isn' + A + r't|aren' + A + r't|wasn' + A + r't|weren' + A + r't)\s+(?:just|merely)\s+(?:(?:a|an|the)\s+)?\w+\s*(?:,|[—–-]+)\s*(?:it' + A + r's|it\s+is|it\s+was|they' + A + r're|they\s+are|they\s+were|that' + A + r's|but)\b')
FAM19 = rx(r'\b(?:in\s+order\s+to|due\s+to\s+the\s+fact\s+that|at\s+this\s+point\s+in\s+time|in\s+the\s+event\s+that|has\s+the\s+ability\s+to|it\s+is\s+important\s+to\s+note\s+that|it\s+should\s+be\s+mentioned\s+that|needless\s+to\s+say)\b')
FAM20 = rx(r'\bit(?:' + A + r's|\s+is)\s+worth\s+(?:noting|mentioning)\s+that\b|\bit\s+bears\s+(?:noting|mentioning)\s+that\b'
           r'|\bone\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is\b|\bit\s+is\s+interesting\s+to\s+note\s+that\b'
           r'|\ba\s+key\s+consideration\s+is\b|\ba\s+point\s+to\s+highlight\s+is\b')
FAM21 = rx(r',\s+(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about|with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for|signaling\s+a\s+shift\s+toward|signalling\s+a\s+shift\s+toward)\b')
FAM22 = rx(r'\b(?:here' + A + r's\s+the\s+thing|make\s+no\s+mistake|the\s+truth\s+is|let' + A + r's\s+be\s+honest|the\s+simple\s+fact\s+is|at\s+its\s+core|what\s+really\s+matters|more\s+than\s+anything|at\s+the\s+end\s+of\s+the\s+day|the\s+bottom\s+line\s+is|in\s+reality|the\s+real\s+question\s+is|the\s+heart\s+of\s+the\s+matter|the\s+deeper\s+issue|when\s+you\s+get\s+down\s+to\s+it|when\s+all\s+is\s+said\s+and\s+done)\b|\bfundamentally,')
FAM23 = rx(r'\bit(?:' + A + r's|\s+is)\s+important\s+to\s+(?:remember|note|understand|recognize|recognise)\b|\bone\s+must\s+note\s+that\b|\bit\s+is\s+worth\s+pointing\s+out\b|\bit\s+cannot\s+be\s+overstated\s+that\b|\bit\s+must\s+be\s+emphasi[sz]ed\s+that\b')
FAM24 = rx(r'\b(?:this\s+(?:comprehensive\s+(?:guide|overview|analysis)|in-depth\s+(?:analysis|look|examination)|complete\s+(?:guide|overview))|a\s+thorough\s+examination\s+of|everything\s+you\s+need\s+to\s+know\s+about)\b')
FAM25 = rx(r'(?:^|(?<=[.!?])\s+|\n)\s*(?:Is|Are|Do|Does|Did|Can|Could|Will|Would|Should|Shall|Must|Have|Has|Was|Were|May|Might)\b[^.!?\n]{0,80}\?\s+(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)\s*[.!]', re.M)
FAM26 = rx(r'\b(?:without\s+concrete\s+(?:evidence|proof)|do\s+you\s+have\s+concrete\s+(?:evidence|proof)|i\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples)\s+to|absent\s+concrete\s+(?:proof|evidence)|provide\s+concrete\s+(?:evidence|proof))\b')
FAM27 = rx(r'\bin\s+today' + A + r's\s+(?:\w+\s+)?(?:\w+\s+)?(?:world|landscape|environment|market)\b|\bin\s+a\s+world\s+where\b|\bin\s+an\s+era\s+of\b|\bin\s+recent\s+years,|\bmore\s+than\s+ever\s+before\b|\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b'
           r'|\b(?:great|exciting|big)\s+news\s*[!:]|\bever\s+(?:wanted|wondered|dreamed|wished)\s+to\b[^.!\n]*\?|\bin\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world\b')
FAM30 = rx(r'\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b'
           r'|\b(?:the|this)\s+(?:(?:latest|new)\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b'
           r'|\b(?:has|have)\s+been\s+(?:updated|refactored|improved|enhanced|changed)\s+to\b|\bpreviously\b[^.!?\n]*\bnow\b'
           r'|\b(?:wasn' + A + r't|weren' + A + r't)\s+there\s+before\b|\bwe(?:' + A + r've|\s+have)\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b')
FAM31 = rx(r'\blet' + A + r's\s+(?:dive|delve|explore)\b|\blet' + A + r's\s+break\s+(?:this|it)\s+down\b|\bhere' + A + r's\s+what\s+you\s+need\s+to\s+know\b|\bwithout\s+further\s+ado\b|\bnow\s+let' + A + r's\s+look\s+at\b|\bbuckle\s+up\b|\bstay\s+with\s+me\b|\bready\s+to\s+dive\s+in\b')
FAM32 = rx(r'\b(?:used|uses|employs|employed|relied\s+on|utili[sz]es)\s+(?:several|various|a\s+number\s+of|multiple|different|many|numerous)\s+\w+'
           r'|(?:^|(?<=[.!?])\s+|\n)\s*These(?:\s+\w+)?\s+(?:provide|offer|give|reveal|show|allow|enable|help)s?\s+(?:information|insights?|understanding|details|data)\b'
           r'|\b(?:is|are|was|were|remains|becomes)\s+(?:the|a)\s+(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b', re.I | re.M)
FAM33 = re.compile(r'^[ \t]*(?:(?:[-*+]|\d+[.)])[ \t]+)?\*\*[^*\n]+?(?::\*\*|\*\*:)', re.M)
FAM36 = rx(r'\bdespite\s+(?:these|its|the)\s+(?:challenges|obstacles)\b|\bchallenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)\b|\bcontinues\s+to\s+thrive\b|\btypical\s+of\s+(?:emerging|urban|modern)\b|\bfaces\s+(?:several|many|numerous)\s+challenges\b')
TRANS = rx(r'(?:^|(?<=[.!?])\s+)(?:Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably)\b', re.M)
TRANS = re.compile(r'(?:^|(?<=[.!?])[ \t]+)\s*(?:Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably)\b', re.M)
FAM38 = rx(r'^[ \t]*(?:in\s+conclusion|overall|in\s+summary|to\s+summari[sz]e|to\s+conclude|all\s+in\s+all|in\s+essence|ultimately)\b', re.I | re.M)
FAM39 = rx(r'\bthe\s+future\s+looks\s+bright\b|\bexciting\s+times\s+lie\s+ahead\b|\bjourney\s+toward\s+excellence\b|\bstep\s+in\s+the\s+right\s+direction\b|\b(?:the\s+)?(?:outlook|future)(?:\s+for\s+[^.!?\n]{1,40}?)?\s+(?:is|looks|remains)\s+bright\b|\bwell[- ]positioned\s+for\s+(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)\b')
FAM47 = rx(r'\bi\s+hope\s+this\s+helps\b|\b(?:certainly|of\s+course)!|\blet\s+me\s+know\s+if\s+you\b|\bwould\s+you\s+like\s+me\s+to\b|\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b|\bhappy\s+to\s+help\s*[.!]'
           r'|\b(?:here|below)\s+is\s+(?:an?|the)\s+(?:overview|summary|rundown|recap|brief)\b|\bhere(?:\s+are|' + A + r's)\s+(?:a\s+few|some|two|three)\s+(?:options|drafts|versions|variations)\b'
           r'|\bhere(?:\s+is|' + A + r's)\s+a\s+draft\b|\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b|\bi\s+hope\s+(?:this\s+email\s+)?finds\s+you\s+well\b'
           r'|\bas\s+an\s+(?:ai|llm|ai\s+assistant|ai\s+language\s+model|large\s+language\s+model|language\s+model)\b'
           r'|\bto\s+(?:answer|address)\s+your\s+question\b|\bin\s+(?:response|answer)\s+to\s+your\s+question\b|\byour\s+question\s+(?:about|regarding|concerning)\b'
           r'|\bas\s+(?:you\s+)?(?:requested|asked),\s+here\b|\bhere\s+is\s+(?:the\s+)?(?:draft|first\s+pass|revised\s+version\s+of|for\s+your)\b')
FAM48 = rx(r'\byou(?:' + A + r're|\s+are)\s+absolutely\s+right\b|\b(?:great\s+question|excellent\s+point)\s*[!.,]|\bwhat\s+an?\s+(?:thoughtful|great|wonderful|fantastic)\s+question\b'
           r'|\bthat' + A + r's\s+(?:a\s+)?(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\b')
FAM50 = rx(r'\bas\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)\b|\bup\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)\b'
           r'|\bwhile\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+(?:extensively|widely)\s+documented)\b|\bbased\s+on\s+(?:the\s+)?available\s+information\b'
           r'|\bas\s+of\s+my\s+(?:knowledge\s+)?cutoff\b|\bmaintains\s+a\s+low\s+profile\b|\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b')
FAM51 = rx(r'\b(?:serves|stands|functions|acts)\s+as\b|\brepresents\s+(?:a|the)\b|\bmarks\s+(?:a|the)\b|\bboasts?\b|\bfeatures\s+(?:an?|the|\d+|several|many|numerous|multiple|various)\b|\boffers\s+a\b|\brefers\s+to\b')
FAM54_HEDGE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively|fairly)\b|\bseems?\s+(?:to|like)\b|\bappears?\s+to\b|\bkind\s+of\b|\bsort\s+of\b")
FAM56 = re.compile(r'\*\*[^*\n]+\*\*')
FAM57 = re.compile('[\U0001F000-\U0001FAFF☀-➿⭐⭕⌚⌛⏩-⏳✅❌✨]')
FAM60 = re.compile('[‘’“”]')
FAM61 = re.compile(r'(?<![\d-])(1[5-9]\d\d|20\d\d)\s?-\s?(1[5-9]\d\d|20\d\d)(?![\d-])')
FAM63A = re.compile(r'\[([^\[\]\n]{1,80})\](?![(\[])')
FAM63B = re.compile(r'\{\{[^{}\n]*\}\}')
FAM63C = re.compile(r'(?<![A-Za-z])[xX]{3,}(?![A-Za-z])|\blorem\s+ipsum\b', re.I)
FAM64 = re.compile(r'\bcite(?:turn|start|nav)\w*|\boai_citation|contentReference|\bnavlist\b|【\d+†[^】\n]*】', re.I)
FAM65 = re.compile(r'utm_source=([A-Za-z0-9.\-]+)', re.I)
AI_HOSTS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai', 'gemini.google.com', 'copilot.microsoft.com', 'poe.com'}
FAM69 = rx(r'\bunlocking\s+(?:its\s+|their\s+|your\s+|the\s+)?full\s+potential\b|\bnavigating\s+the\s+complexities\b|\ba\s+testament\s+to\s+the\s+(?:power|importance)\b'
           r'|\bstaying\s+ahead\s+of\s+the\s+curve\b|\bturning\s+challenges\s+into\s+opportunities\b|\btaking\s+\w+\s+to\s+the\s+next\s+level\b'
           r'|\bharnessing\s+the\s+power\s+of\b|\bpaving\s+the\s+way\s+for\b|\bsaying\s+goodbye\s+to\b|\bimagining\s+a\s+world\s+where\b'
           r'|\bunlock(?:s|ed|ing)?\s+(?:the\s+)?full\s+potential\b|\bnavigat(?:e|es|ed|ing)\s+the\s+(?:ever-changing|complex)\s+landscape\b'
           r'|\bin\s+the\s+ever-evolving\s+(?:world|landscape)\b')
HR = re.compile(r'^[ ]{0,3}(?:-{3,}|\*{3,}|_{3,}|(?:-[ ]){2,}-)[ \t]*$', re.M)
