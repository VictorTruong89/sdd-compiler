"""Prose extraction for the twenty supported formats. # spec: N-000246"""
import json
import re
import zipfile
import posixpath
import xml.etree.ElementTree as ET
from html.parser import HTMLParser

PLAIN_EXT = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXT = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NOTEBOOK_EXT = {'.ipynb'}
MEMBER_CAP = 64 * 1024 * 1024


class NotZip(Exception):
    pass


def decode_bytes(b):
    if b[:2] in (b'\xff\xfe', b'\xfe\xff'):
        try:
            return b.decode('utf-16')
        except UnicodeDecodeError:
            return b[2:].decode('utf-16-le' if b[:2] == b'\xff\xfe' else 'utf-16-be', errors='replace')
    if b[:3] == b'\xef\xbb\xbf':
        b = b[3:]
    return b.decode('utf-8', errors='replace')


def _local(tag):
    return tag.rsplit('}', 1)[-1] if isinstance(tag, str) else ''


def _read(z, name):
    try:
        info = z.getinfo(name)
    except KeyError:
        return None
    if info.file_size > MEMBER_CAP:
        return None
    try:
        return z.read(name)
    except Exception:
        return None


def _parse(data):
    if data is None:
        return None
    try:
        return ET.fromstring(data)
    except ET.ParseError:
        return None


def _num_key(name):
    return [int(t) if t.isdigit() else t for t in re.split(r'(\d+)', name)]


def _word_para(p):
    out = []
    for el in p.iter():
        t = _local(el.tag)
        if t == 't' and el.text:
            out.append(el.text)
        elif t == 'tab':
            out.append('\t')
        elif t in ('br', 'cr'):
            out.append('\n')
    return ''.join(out)


def _paras(root, ptag, ttag='t'):
    res = []
    for p in root.iter():
        if _local(p.tag) == ptag:
            s = _word_para(p)
            if s.strip():
                res.append(s)
    return res


def _docx(z):
    root = _parse(_read(z, 'word/document.xml'))
    if root is None:
        return ''
    return '\n'.join(_paras(root, 'p'))


def _pptx(z):
    names = [n for n in z.namelist() if re.match(r'ppt/slides/slide\d+\.xml$', n)]
    names.sort(key=_num_key)
    out = []
    for n in names:
        root = _parse(_read(z, n))
        if root is not None:
            out.extend(_paras(root, 'p'))
    return '\n'.join(out)


def _xlsx(z):
    shared = []
    root = _parse(_read(z, 'xl/sharedStrings.xml'))
    if root is not None:
        for si in root:
            if _local(si.tag) != 'si':
                continue
            parts = []
            for el in si.iter():
                if _local(el.tag) == 't' and el.text is not None:
                    # skip phonetic runs
                    parts.append(el.text)
            # remove phonetic text
            ph = []
            for rph in si.iter():
                if _local(rph.tag) == 'rPh':
                    for t in rph.iter():
                        if _local(t.tag) == 't' and t.text:
                            ph.append(t.text)
            s = ''.join(parts)
            for x in ph:
                s = s.replace(x, '', 1)
            shared.append(s)
    names = [n for n in z.namelist() if re.match(r'xl/worksheets/[^/]+\.xml$', n)]
    names.sort(key=_num_key)
    out = []
    for n in names:
        root = _parse(_read(z, n))
        if root is None:
            continue
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            t = c.get('t')
            text = None
            if t == 's':
                v = None
                for ch in c:
                    if _local(ch.tag) == 'v':
                        v = (ch.text or '').strip()
                if v is not None and re.fullmatch(r'\d+', v) and int(v) < len(shared):
                    text = shared[int(v)]
            elif t == 'inlineStr':
                text = ''.join((e.text or '') for e in c.iter() if _local(e.tag) == 't')
            elif t == 'str':
                for ch in c:
                    if _local(ch.tag) == 'v':
                        text = ch.text or ''
            if text is not None and text.strip():
                out.append(text)
    return '\n'.join(out)


def _odf_text(el, out):
    t = _local(el.tag)
    if el.text:
        out.append(el.text)
    for ch in el:
        ct = _local(ch.tag)
        if ct == 's':
            try:
                n = int(ch.get('{urn:oasis:names:tc:opendocument:xmlns:text:1.0}c', '1'))
            except ValueError:
                n = 1
            out.append(' ' * max(n, 1))
        elif ct == 'tab':
            out.append('\t')
        elif ct == 'line-break':
            out.append('\n')
        else:
            _odf_text(ch, out)
        if ch.tail:
            out.append(ch.tail)


def _odf(z):
    root = _parse(_read(z, 'content.xml'))
    if root is None:
        return ''
    paras = []

    def walk(el):
        t = _local(el.tag)
        if t in ('p', 'h'):
            buf = []
            _odf_text(el, buf)
            s = ''.join(buf)
            if s.strip():
                paras.append(s)
            return
        for ch in el:
            walk(ch)
    walk(root)
    return '\n'.join(paras)


class _Html(HTMLParser):
    SKIP = {'style', 'script', 'nav', 'head', 'title'}
    BLOCK = {'p', 'div', 'br', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'tr', 'blockquote',
             'section', 'article', 'pre', 'ul', 'ol', 'table', 'hr', 'dt', 'dd', 'figcaption'}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.out = []
        self.depth = {}

    def handle_starttag(self, tag, attrs):
        tag = tag.split(':')[-1].lower()
        if tag in self.SKIP:
            self.depth[tag] = self.depth.get(tag, 0) + 1
        if tag in self.BLOCK:
            self.out.append('\n')

    def handle_startendtag(self, tag, attrs):
        tag = tag.split(':')[-1].lower()
        if tag in self.BLOCK:
            self.out.append('\n')

    def handle_endtag(self, tag):
        tag = tag.split(':')[-1].lower()
        if tag in self.SKIP and self.depth.get(tag, 0) > 0:
            self.depth[tag] -= 1
        if tag in self.BLOCK:
            self.out.append('\n')

    def handle_data(self, data):
        if any(v > 0 for v in self.depth.values()):
            return
        self.out.append(data)


def _html_text(data):
    p = _Html()
    try:
        p.feed(data.decode('utf-8', errors='replace'))
        p.close()
    except Exception:
        pass
    s = ''.join(p.out)
    s = re.sub(r'[ \t\r\f\v]+', ' ', s)
    s = re.sub(r' ?\n ?', '\n', s)
    s = re.sub(r'\n{2,}', '\n', s)
    return s.strip()


def _epub(z):
    names = z.namelist()
    order = []
    try:
        cont = _parse(_read(z, 'META-INF/container.xml'))
        opf_path = None
        if cont is not None:
            for el in cont.iter():
                if _local(el.tag) == 'rootfile':
                    opf_path = el.get('full-path')
                    break
        if opf_path:
            opf = _parse(_read(z, opf_path))
            base = posixpath.dirname(opf_path)
            manifest = {}
            for el in opf.iter():
                if _local(el.tag) == 'item':
                    manifest[el.get('id')] = (el.get('href') or '', el.get('properties') or '')
            for el in opf.iter():
                if _local(el.tag) == 'itemref':
                    it = manifest.get(el.get('idref'))
                    if it and 'nav' not in it[1].split():
                        order.append(posixpath.normpath(posixpath.join(base, it[0])))
    except Exception:
        order = []
    order = [n for n in order if n in names]
    if not order:
        order = sorted((n for n in names if re.search(r'\.(x?html?)$', n, re.I)), key=_num_key)
    out = []
    for n in order:
        data = _read(z, n)
        if data is None:
            continue
        s = _html_text(data)
        if s:
            out.append(s)
    return '\n'.join(out)


def _ipynb(raw):
    try:
        nb = json.loads(decode_bytes(raw))
        cells = nb['cells']
        if not isinstance(cells, list):
            return ''
        out = []
        for c in cells:
            if not isinstance(c, dict) or c.get('cell_type') != 'markdown':
                continue
            src = c.get('source')
            if isinstance(src, list) and all(isinstance(x, str) for x in src):
                src = ''.join(src)
            if isinstance(src, str) and src.strip():
                out.append(src.strip())
        return '\n\n'.join(out)
    except Exception:
        return ''


def extract_bytes(raw, ext):
    """Return extracted prose. Raises NotZip when a zip extension isn't a zip."""
    ext = ext.lower()
    if ext in ZIP_EXT:
        import io
        try:
            z = zipfile.ZipFile(io.BytesIO(raw))
        except (zipfile.BadZipFile, Exception):
            raise NotZip()
        try:
            if ext in ('.docx', '.docm'):
                s = _docx(z)
            elif ext in ('.pptx', '.pptm'):
                s = _pptx(z)
            elif ext in ('.xlsx', '.xlsm'):
                s = _xlsx(z)
            elif ext == '.epub':
                s = _epub(z)
            else:
                s = _odf(z)
        except Exception:
            s = ''
        return s.strip()
    if ext in NOTEBOOK_EXT:
        return _ipynb(raw).strip()
    if ext in ('.pdf', '.rtf'):
        return ''
    return decode_bytes(raw)
