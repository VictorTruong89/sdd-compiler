#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when flagged. Always exits 0.
const fs = require('fs');
const path = require('path');
const L = require('./lib');

function patchPaths(cmd) {
  const out = [];
  if (typeof cmd !== 'string') return out;
  for (const line of cmd.split(/\r?\n/)) {
    const m = /^\*\*\* (Add File|Update File|Move to):(.*)$/.exec(line);
    if (m) {
      const p = m[2].trim();
      if (p) out.push(p);
    }
  }
  return out;
}

function namedPaths(input) {
  const tn = String(input.tool_name || '');
  const ti = input.tool_input && typeof input.tool_input === 'object' ? input.tool_input : {};
  const low = tn.toLowerCase();
  const res = [];
  if (low === 'write' || low === 'edit' || low === 'multiedit') {
    if (typeof ti.file_path === 'string' && ti.file_path.trim()) res.push(ti.file_path.trim());
  } else if (low === 'notebookedit') {
    if (typeof ti.notebook_path === 'string' && ti.notebook_path.trim()) res.push(ti.notebook_path.trim());
    else if (typeof ti.file_path === 'string' && ti.file_path.trim()) res.push(ti.file_path.trim());
  } else if (low === 'apply_patch') {
    for (const p of patchPaths(ti.command)) res.push(p);
  }
  const seen = new Set();
  const uniq = [];
  for (const p of res) { if (!seen.has(p)) { seen.add(p); uniq.push(p); } }
  return uniq.slice(0, L.PATCH_PATH_CAP);
}

function scoreOne(file, level, sid, lines) {
  const base = path.basename(file);
  const ext = L.extOf(file);
  if (L.isSkippedPath(file) || L.isInstructionFile(file)) return;
  if (ext === '.pdf' || ext === '.rtf') {
    let st = null;
    try { st = fs.statSync(file); } catch (e) { st = null; }
    if (st && st.isDirectory()) return;
    L.appendLedger(sid, { base, kind: 'binary' });
    return;
  }
  if (!L.isProseExt(ext)) return;
  let st;
  try { st = fs.statSync(file); } catch (e) {
    L.appendLedger(sid, { base, kind: 'failed', reason: 'file could not be read' });
    return;
  }
  if (!st.isFile()) return;
  const cap = L.capFor(ext);
  if (st.size > cap) {
    L.appendLedger(sid, { base, kind: 'skipped', cap_kb: cap / 1024 });
    return;
  }
  const r = L.runDetector(['--', file], { timeout: L.isArchiveExt(ext) ? 15000 : 8000 });
  if (r.status !== 'ok') {
    const reasons = {
      nopython: 'Python was not found',
      nodetector: 'the bundled detector was not found',
      timeout: 'the detector timed out',
      unusable: 'the detector printed text that was not a structured report',
      noscore: 'the report had no numeric score',
      empty: 'the detector produced no output or exited without a usable result',
      failed: 'the detector produced no output or exited without a usable result',
      noresult: 'the detector produced no output or exited without a usable result',
    };
    L.appendLedger(sid, { base, kind: 'failed', reason: reasons[r.status] || reasons.noresult });
    return;
  }
  const m = r.report._metrics;
  const score = Math.round(m.ai_tell_score);
  const band = String(m.ai_tell_band);
  const threshold = level === 'strict' ? 20 : 40;
  const flagged = score > threshold;
  const fs_ = L.findings(r.report);
  const labels = fs_.map((f) => f.label).slice(0, L.GUARD_LABEL_CAP);
  L.appendLedger(sid, { base, kind: 'scored', score, band, labels, flagged, truncated: m.truncated === true });
  if (flagged) {
    const cov = m.truncated === true ? ', first ' + L.WINDOW_FMT + ' characters only' : '';
    lines.push('prosecheck: ' + base + ' ' + L.phraseFor(band) + ' (score ' + score + ', band ' + band + cov + '). Flagged: ' +
      (labels.length ? labels.join('; ') : band) + '. Please fix the flagged spans and keep the rhythm varied.');
  }
}

try {
  const input = L.readStdinJson();
  const level = L.getLevel();
  if (level === 'full' || level === 'strict') {
    const sid = typeof input.session_id === 'string' ? input.session_id : '';
    const cwd = typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd();
    const lines = [];
    for (const p of namedPaths(input)) {
      try {
        const abs = path.isAbsolute(p) ? p : path.resolve(cwd, p);
        scoreOne(abs, level, sid, lines);
      } catch (e) { /* continue */ }
    }
    if (lines.length) {
      process.stdout.write(JSON.stringify({
        hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
      }) + '\n');
    }
  }
} catch (e) { /* ignore */ }
process.exitCode = 0;
