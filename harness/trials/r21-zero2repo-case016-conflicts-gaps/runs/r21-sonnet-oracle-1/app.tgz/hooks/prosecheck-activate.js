#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract in context. Always exits 0.
const L = require('./lib');
try {
  L.readStdinJson();
  L.cleanOldLedgers();
  const first = !L.flagExists();
  const level = L.getLevel();
  if (level !== 'off') {
    if (first || !L.readStored()) { if (first) L.setLevel(level); }
    const parts = [];
    if (first) parts.push(L.welcomeText());
    parts.push(L.contractText(level));
    process.stdout.write(parts.join('\n\n') + '\n');
  }
} catch (e) { /* never fail the host session */ }
process.exitCode = 0;
