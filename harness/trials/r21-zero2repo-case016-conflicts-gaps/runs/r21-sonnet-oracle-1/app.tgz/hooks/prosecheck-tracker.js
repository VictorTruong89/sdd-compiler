#!/usr/bin/env node
'use strict';
// Prompt-submit hook and /prosecheck command router. Always exits 0.
const fs = require('fs');
const path = require('path');
const L = require('./lib');
const { statsReply } = require('./prosecheck-stats');

const SUBS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }) + '\n');
}

function helpReply() {
  const lvl = L.getLevel();
  return [
    'prosecheck - level: ' + lvl,
    '',
    '  /prosecheck lite - turn on the writing contract, without scoring of saved files',
    '  /prosecheck full - contract plus the saved-file guard, threshold 40 (default)',
    '  /prosecheck strict - guard with a lower threshold of 20, and a scrub finish',
    '  /prosecheck off | on - disable the tool / re-enable it',
    '  /prosecheck status - show the current level',
    '  /prosecheck show - list the files scored in this session',
    '  /prosecheck check <file> - score one file (report only, no rewrite)',
    '  /prosecheck doctor - health check of the install',
    '  /prosecheck stats - token figures and prose score of this session',
    '  /prosecheck init - export the contract to ./AGENTS.md for other agents',
    '',
    'Code, commits, config, and chat are never touched; only prose deliverables are.',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

// ---------------------------------------------------------------- check
function cleanPathArg(arg) {
  let s = (arg || '').trim();
  if (s.startsWith('@')) s = s.slice(1).trim();
  const m = /^(["'])(.*)\1$/.exec(s);
  if (m) s = m[2];
  if (s.startsWith('@')) s = s.slice(1);
  return s.trim();
}

function checkReply(arg, cwd) {
  const typed = cleanPathArg(arg);
  if (!typed) return 'check: give a file path, for example: /prosecheck check notes.md. It reports on one file and never rewrites it.';
  const abs = path.isAbsolute(typed) ? typed : path.resolve(cwd || process.cwd(), typed);
  const base = path.basename(abs);
  let st;
  try { st = fs.statSync(abs); } catch (e) { return 'cannot read ' + typed + ' (it was not found or is not readable).'; }
  if (st.isDirectory()) return 'not a file: ' + typed;
  if (!st.isFile()) return 'not a file: ' + typed;
  const ext = L.extOf(abs);
  if (ext === '.pdf' || ext === '.rtf') return base + ': no readable text (this format is not read as prose).';
  const cap = L.capFor(ext);
  if (st.size > cap) return base + ' is over ' + (cap / 1024) + ' KB, so it was not scored.';
  const r = L.runDetector(['--', abs], { timeout: L.isArchiveExt(ext) ? 15000 : 8000 });
  switch (r.status) {
    case 'nopython':
    case 'nodetector':
      return 'detector unavailable: it could not be run here, so no score was produced.';
    case 'timeout':
      return base + ': the detector failed (it timed out).';
    case 'failed':
      return base + ': the detector failed' + (r.stderr ? ': ' + r.stderr : '.');
    case 'noresult':
      return base + ': the detector failed' + (r.stderr ? ': ' + r.stderr : '.');
    case 'empty':
      return base + ': no report was produced by the detector.';
    case 'unusable':
    case 'noscore':
      return 'The detector gave no report (its output was not a usable report).';
    default: break;
  }
  const rep = r.report;
  const m = rep._metrics;
  const score = Math.round(m.ai_tell_score);
  const lines = [];
  lines.push(base + ' - ' + L.phraseFor(m.ai_tell_band) + ' (score ' + score + '/100, band: ' + m.ai_tell_band + ')');
  let conf = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && m.confidence_reason) conf += ' - ' + m.confidence_reason;
  lines.push(conf);
  if (m.truncated === true) lines.push('coverage: first ' + L.WINDOW_FMT + ' characters only (only that prefix was included)');
  const fs_ = L.findings(rep);
  if (!fs_.length) lines.push('tells: none');
  else lines.push('tells: ' + fs_.slice(0, L.CHECK_LABEL_CAP).map((f) => f.label + ' (x' + f.count + ')').join('; '));
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

// ---------------------------------------------------------------- doctor
function doctorReply(form) {
  const lvl = L.getLevel();
  const checks = [];
  // mode
  let modeOk = lvl !== 'off';
  checks.push(modeOk ? '[OK] mode: ' + lvl
    : '[--] mode: off - prosecheck is switched off; run /prosecheck on to turn it back on');
  // detector
  const dp = L.detectorPath();
  const detOk = !!dp;
  checks.push(detOk ? '[OK] detector: bundled detector found in the plugin tree'
    : '[!!] detector: bundled detector is missing from the plugin tree');
  // python
  let pyOk = false;
  let pyLine;
  const r = L.pythonAvailable()
    ? L.runDetector([], { input: 'prosecheck doctor sample text. It is short and plain.\n', timeout: 15000 })
    : { status: 'nopython' };
  if (r.status === 'ok') {
    pyOk = true;
    pyLine = '[OK] python: Python ran the bundled detector and produced a numeric score';
  } else if (r.status === 'nopython') {
    pyLine = '[!!] python not found: saved files are not re-scored until it is available; the prose contract still shapes new prose';
  } else if (r.status === 'nodetector') {
    pyLine = '[!!] python: could not run the bundled detector because it is missing';
  } else {
    pyLine = '[!!] python: it ran, but the result was not a numeric score';
  }
  checks.push(pyLine);
  // settings
  let setOk = false;
  try {
    const d = L.configDir();
    fs.mkdirSync(d, { recursive: true });
    fs.accessSync(d, fs.constants.W_OK);
    setOk = fs.statSync(d).isDirectory();
  } catch (e) { setOk = false; }
  checks.push(setOk ? '[OK] settings: the settings folder is writable'
    : '[!!] settings: the settings folder is not writable');
  const faults = !detOk || !pyOk || !setOk;
  let closer;
  if (faults) {
    closer = 'Please fix the faulty checks above, then run /prosecheck doctor again.';
  } else if (lvl === 'off') {
    closer = 'The install is healthy. In this mode saving a file triggers no scoring; run ' + form + ' on to have saved files scored again.';
  } else {
    closer = 'prosecheck is active: plain text up to 512 KB and archives up to 4 MB are read, and the first ' + L.WINDOW_FMT +
      ' characters are scanned. Use ' + form + ' show to see files that were only partly scanned or skipped.';
  }
  return ['prosecheck doctor - health check', ...checks, closer].join('\n');
}

// ---------------------------------------------------------------- show
function showReply(sid) {
  const led = L.readLedger(sid);
  if (!led.length) {
    return 'nothing scored yet in this session; rows appear after prose files (including .docx and .pdf deliverables) are saved.';
  }
  const rows = ['Files seen by the guard in this session, newest first:'];
  for (const r of led.slice().reverse()) {
    const base = String(r.base || '');
    if (r.kind === 'scored') {
      let body = L.phraseFor(r.band) + ' (score ' + r.score + '/' + r.band + (r.truncated ? ', first ' + L.WINDOW_FMT + ' characters only' : '') + ')';
      const labels = Array.isArray(r.labels) ? r.labels.slice(0, L.SHOW_LABEL_CAP) : [];
      if (labels.length) body += ' - ' + (r.flagged ? 'flagged' : 'under threshold') + ': ' + labels.join('; ');
      rows.push('  ' + base + ' - ' + body);
    } else if (r.kind === 'skipped') {
      rows.push('  ' + base + ' - not scored: it exceeds the ' + r.cap_kb + ' KB limit');
    } else if (r.kind === 'binary') {
      rows.push('  ' + base + ' - binary file, not re-scored');
    } else {
      rows.push('  ' + base + ' - not scored: ' + (r.reason || 'the check failed'));
    }
  }
  return rows.join('\n');
}

// ---------------------------------------------------------------- init
const MARKER = '<!-- prosecheck:prose-contract -->';
function exportedContract(level) {
  return [
    MARKER,
    '## Prose contract (prosecheck)',
    '',
    L.contractText(level, { portable: true }),
    '<!-- /prosecheck:prose-contract -->',
  ].join('\n');
}

function initReply(form) {
  const lvl = L.getLevel();
  if (lvl === 'off') {
    return 'prosecheck is switched off, so nothing was exported. Run ' + form + ' on to allow the export.';
  }
  const out = [];
  const cwd = process.cwd();
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = null;
  let readErr = false;
  try { existing = fs.readFileSync(agents, 'utf8'); } catch (e) { if (e.code !== 'ENOENT') readErr = true; }
  if (readErr) {
    out.push('cannot read AGENTS.md, so the contract was not written there.');
  } else if (existing !== null && (existing.includes(MARKER) || existing.includes('## Prose contract (prosecheck)'))) {
    out.push('The contract is already present in AGENTS.md; it was left unchanged.');
  } else {
    try {
      let body = existing === null ? '' : existing;
      if (body && !body.endsWith('\n')) body += '\n';
      if (body) body += '\n';
      body += exportedContract(lvl) + '\n';
      fs.writeFileSync(agents, body, 'utf8');
      out.push('Wrote the ' + lvl + ' writing contract to AGENTS.md.');
    } catch (e) {
      out.push('cannot write AGENTS.md, so the contract was not exported.');
    }
  }
  const dest = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(dest)) {
    out.push('The Cursor rule is already there (prosecheck.mdc); it was not overwritten.');
  } else {
    const src = path.join(L.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
    try {
      const data = fs.readFileSync(src);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.writeFileSync(dest, data);
      out.push('Copied the Cursor rule to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      out.push('cannot write the Cursor rule (.cursor/rules/prosecheck.mdc).');
    }
  }
  return out.join('\n');
}

// ---------------------------------------------------------------- router
function setReply(word) {
  if (!L.setLevel(word)) return 'could not store the level ' + word + ' (settings folder is not writable).';
  if (word === 'off') return 'prosecheck is now off.';
  return 'prosecheck level set to ' + word + '.';
}

function handleCommand(prompt, input) {
  const m = /^\/prosecheck(:prosecheck)?(?:\s+([\s\S]*))?$/i.exec(prompt);
  if (!m) return null;
  const form = m[1] ? '/prosecheck:prosecheck' : '/prosecheck';
  const rest = (m[2] || '').trim();
  if (!rest) return helpReply();
  const sp = rest.search(/\s/);
  const word = sp < 0 ? rest : rest.slice(0, sp);
  const arg = sp < 0 ? '' : rest.slice(sp + 1).trim();
  const sub = word.toLowerCase();
  const sid = typeof input.session_id === 'string' ? input.session_id : '';
  switch (sub) {
    case 'lite': case 'full': case 'strict': case 'off':
      return setReply(sub);
    case 'on':
      return L.setLevel('full') ? 'prosecheck is on (level full).' : 'could not store the level on (settings folder is not writable).';
    case 'status':
      return 'prosecheck level: ' + L.getLevel();
    case 'show': return showReply(sid);
    case 'check': return checkReply(arg, typeof input.cwd === 'string' && input.cwd ? input.cwd : process.cwd());
    case 'doctor': return doctorReply(form);
    case 'stats': return statsReply(input);
    case 'init': return initReply(form);
    case 'help': return helpReply();
    default:
      return 'prosecheck: unknown subcommand "' + word + '".\nValid subcommands: ' + SUBS.join(', ') + '.';
  }
}

try {
  const input = L.readStdinJson();
  const prompt = typeof input.prompt === 'string' ? input.prompt : '';
  const trimmed = prompt.trim();
  const lower = trimmed.toLowerCase();
  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    L.setLevel('off');
    block('prosecheck is now off.');
  } else {
    const reply = /^\/prosecheck(?::prosecheck)?(?:\s|$)/i.test(trimmed) ? handleCommand(trimmed, input) : null;
    if (reply !== null) {
      block(reply);
    } else {
      const level = L.getLevel();
      if (level !== 'off') {
        process.stdout.write(JSON.stringify({
          hookSpecificOutput: {
            hookEventName: 'UserPromptSubmit',
            additionalContext: 'prosecheck level ' + level + ': prose deliverables follow the writing contract; code, config, and commits are untouched.',
          },
        }) + '\n');
      }
    }
  }
} catch (e) { /* never fail the host */ }
process.exitCode = 0;
