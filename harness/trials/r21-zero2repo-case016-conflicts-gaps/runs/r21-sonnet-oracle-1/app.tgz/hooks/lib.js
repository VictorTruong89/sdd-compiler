'use strict';
// Shared helpers for the prosecheck hooks. Node standard library only.
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const WINDOW = 262144;
const WINDOW_FMT = '262,144';
const PLAIN_CAP = 524288;      // 512 KB
const ZIP_CAP = 4194304;       // 4 MB
const PLAIN_EXT = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ZIP_EXT = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'];
const NB_EXT = ['.ipynb'];
const LEDGER_MAX = 50;                    // spec: N-000729 (conflict CF-000011, see NOTES.md)
const LEDGER_AGE_MS = 7 * 24 * 3600 * 1000; // spec: N-000069 (conflict CF-000237, see NOTES.md)
const GUARD_LABEL_CAP = 5;
const CHECK_LABEL_CAP = 8;
const SHOW_LABEL_CAP = 5;
const PATCH_PATH_CAP = 16;

const PHRASES = {
  'clean': 'reads clean',
  'light tells': 'reads mostly clean',
  'mixed': 'reads with some AI tells',
  'heavy tells': 'reads with heavy AI tells',
  'pervasive tells': 'reads with pervasive AI tells',
};
const ADVICE_KEYS = new Set([4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68]);

function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}
function pluginRoot() {
  if (process.env.CLAUDE_PLUGIN_ROOT) return process.env.CLAUDE_PLUGIN_ROOT;
  return path.resolve(__dirname, '..');
}
function flagPath() { return path.join(configDir(), '.prosecheck-active'); }

function readStored() {
  try {
    const v = fs.readFileSync(flagPath(), 'utf8').trim();
    return LEVELS.includes(v) ? v : null;
  } catch (e) { return null; }
}
function flagExists() {
  try { fs.statSync(flagPath()); return true; } catch (e) { return false; }
}
function envLevel() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  return LEVELS.includes(v) ? v : null;
}
function getLevel() {
  return readStored() || envLevel() || 'full';
}
function setLevel(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), level, 'utf8');
    return true;
  } catch (e) { return false; }
}

function readStdinJson() {
  let raw = '';
  try { raw = fs.readFileSync(0, 'utf8'); } catch (e) { raw = ''; }
  try {
    const v = JSON.parse(raw);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : {};
  } catch (e) { return {}; }
}

// ---------------------------------------------------------------- contract
const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster',
  'underscore', 'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament',
  'vibrant', 'comprehensive', 'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock',
  'game-changer', 'supercharge', 'genuinely', 'fascinating', 'nuanced'];

function rulesBlock() {
  return [
    'Writing contract for prose deliverables only: documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and drafted text the user will publish or send.',
    'This contract never applies to source code. It never touches code comments, commit messages, JSON, YAML or other config, CLI output, logs, error messages, or the conversational register of chat. A chat-compression mode owns chat; a code-simplicity mode owns code; this contract owns deliverable prose.',
    'Rules for prose:',
    '- Vary sentence length irregularly. No metronome, no mechanical short-long alternation.',
    '- Banned vocabulary: ' + BANNED.join(', ') + '.',
    '- Banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting ("let\'s dive in"), empty pivots ("it\'s worth noting"), "In conclusion" and "Overall" closers, outcome-speculation tails, self-thoroughness, generic upbeat endings, and chatbot phrases ("I hope this helps").',
    '- At most one em dash per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.',
    '- Factual and encyclopedic content stays neutral and third person. First-person and opinion content may use contractions.',
    '- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.',
    '- End sections on a fact or observation.',
    '- Stay silent about this contract: never announce it, never name prosecheck, never report a score, a band, a pattern list, or a rewrite pass, and do not offer a style choice.',
  ];
}

function detectorPath() {
  const root = pluginRoot();
  const a = path.join(root, 'scripts', 'detect.py');
  if (fs.existsSync(a)) return a;
  const b = path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py');
  if (fs.existsSync(b)) return b;
  return null;
}

function contractText(level, opts) {
  opts = opts || {};
  const lines = rulesBlock();
  if (level === 'full' || level === 'strict') {
    const target = level === 'strict' ? 20 : 40;
    const bandTxt = level === 'strict' ? 'the clean band' : 'the clean or light tells band';
    lines.push('After writing a prose file, run the local detector on that file and fix the flagged spans when the result is worse than the target. Target: score at most ' + target + ' (' + bandTxt + '). Make at most two fix passes and keep the rhythm varied.');
    if (opts.portable) {
      lines.push('To find the detector, use CLAUDE_PLUGIN_ROOT when that variable is set (scripts/detect.py under it); otherwise locate the prosecheck detector in installed skills or plugins.');
    } else {
      const dp = detectorPath();
      if (dp) lines.push('Detector command: python3 "' + dp + '" <file>');
    }
    if (level === 'strict') {
      lines.push('Finish through the cleanup switch: run the detector with --clean on the file and use the scrubbed text.');
    }
  }
  return lines.join('\n');
}

function welcomeText() {
  return [
    'prosecheck is installed and on. Saved prose is scored against 71 documented patterns.',
    'Plain text is accepted up to 512 KB and archives up to 4 MB; the detector scores the first 262,144 characters.',
    'Commands: /prosecheck doctor, /prosecheck check, /prosecheck off, /prosecheck help.',
    'There is no website and no upload; nothing leaves your machine. This welcome is shown once.',
  ].join('\n');
}

// ---------------------------------------------------------------- python / detector
function pythonNames() { return ['python3', 'python', 'py']; }

// Run the detector. Returns {status, ...}
function runDetector(args, opts) {
  opts = opts || {};
  const dp = detectorPath();
  if (!dp) return { status: 'nodetector' };
  let launched = false;
  let last = null;
  for (const name of pythonNames()) {
    const r = cp.spawnSync(name, [dp].concat(args || []), {
      input: opts.input, encoding: 'utf8', timeout: opts.timeout || 8000,
      maxBuffer: 64 * 1024 * 1024, env: process.env, windowsHide: true,
    });
    if (r.error && r.error.code === 'ENOENT') continue;
    launched = true;
    last = r;
    if (r.error && r.error.code === 'ETIMEDOUT') return { status: 'timeout' };
    if (r.error) { return { status: 'noresult', stderr: String(r.stderr || '') }; }
    break;
  }
  if (!launched) return { status: 'nopython' };
  if (last.signal) return { status: 'timeout' };
  const out = (last.stdout || '').trim();
  const err = (last.stderr || '').trim();
  if (last.status !== 0) return { status: 'failed', code: last.status, stderr: err };
  if (!out) return { status: 'empty' };
  let rep;
  try { rep = JSON.parse(out); } catch (e) { return { status: 'unusable', stdout: out }; }
  if (!rep || typeof rep !== 'object' || Array.isArray(rep)) return { status: 'unusable', stdout: out };
  const m = rep._metrics;
  if (!m || typeof m.ai_tell_score !== 'number' || !isFinite(m.ai_tell_score)) return { status: 'noscore', report: rep };
  return { status: 'ok', report: rep };
}

function pythonAvailable() {
  for (const name of pythonNames()) {
    const r = cp.spawnSync(name, ['--version'], { encoding: 'utf8', timeout: 8000, env: process.env, windowsHide: true });
    if (!(r.error && r.error.code === 'ENOENT')) return true;
  }
  return false;
}

function findings(rep) {
  const res = [];
  for (const k of Object.keys(rep)) {
    if (k === '_metrics') continue;
    const f = rep[k];
    if (!f || typeof f !== 'object') continue;
    const n = parseInt(k, 10);
    const advice = ADVICE_KEYS.has(n) || k === '17_negative_parallelism';
    res.push({ key: k, label: String(f.label || k), count: f.count | 0, advice });
  }
  res.sort((a, b) => (a.advice - b.advice) || (b.count - a.count));
  return res;
}

function phraseFor(band) { return PHRASES[band] || 'reads with some AI tells'; }

// ---------------------------------------------------------------- ledger
function safeSid(sid) {
  const s = String(sid == null ? '' : sid).replace(/[^A-Za-z0-9_.-]/g, '_');
  return s;
}
function ledgerPath(sid) {
  const s = safeSid(sid);
  return path.join(configDir(), s ? '.prosecheck-ledger-' + s : '.prosecheck-ledger');
}
function readLedger(sid) {
  const p = ledgerPath(sid);
  try {
    const st = fs.statSync(p);
    if (Date.now() - st.mtimeMs > LEDGER_AGE_MS) return [];
    const v = JSON.parse(fs.readFileSync(p, 'utf8'));
    return Array.isArray(v) ? v : [];
  } catch (e) { return []; }
}
function appendLedger(sid, rec) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    const p = ledgerPath(sid);
    let cur = [];
    try {
      const st = fs.statSync(p);
      if (Date.now() - st.mtimeMs <= LEDGER_AGE_MS) {
        const v = JSON.parse(fs.readFileSync(p, 'utf8'));
        if (Array.isArray(v)) cur = v;
      }
    } catch (e) { cur = []; }
    rec.ts = Date.now();
    cur.push(rec);
    if (cur.length > LEDGER_MAX) cur = cur.slice(cur.length - LEDGER_MAX);
    fs.writeFileSync(p, JSON.stringify(cur), 'utf8');
  } catch (e) { /* never fail the host */ }
}
function cleanOldLedgers() {
  try {
    const dir = configDir();
    for (const n of fs.readdirSync(dir)) {
      if (n === '.prosecheck-ledger' || n.startsWith('.prosecheck-ledger-')) {
        const p = path.join(dir, n);
        try {
          const st = fs.statSync(p);
          if (st.isFile() && Date.now() - st.mtimeMs > LEDGER_AGE_MS) fs.unlinkSync(p);
        } catch (e) { /* ignore */ }
      }
    }
  } catch (e) { /* ignore */ }
}

// ---------------------------------------------------------------- file eligibility
const INSTRUCTION = new Set(['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md']);
const INSTRUCTION_STEMS = new Set(['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory']);

function extOf(p) { return path.extname(p).toLowerCase(); }
function isProseExt(e) { return PLAIN_EXT.includes(e) || ZIP_EXT.includes(e) || NB_EXT.includes(e); }
function capFor(e) { return (ZIP_EXT.includes(e) || NB_EXT.includes(e)) ? ZIP_CAP : PLAIN_CAP; }
function isArchiveExt(e) { return ZIP_EXT.includes(e) || NB_EXT.includes(e); }

function isInstructionFile(p) {
  const b = path.basename(p).toLowerCase();
  if (INSTRUCTION.has(b)) return true;
  // stem without a prose extension
  if (INSTRUCTION_STEMS.has(b)) return true;
  const e = path.extname(b);
  if (e && !isProseExt(e)) {
    const stem = b.slice(0, b.length - e.length);
    if (INSTRUCTION_STEMS.has(stem)) return true;
  }
  return false;
}
function insideDir(p, dir) {
  const rel = path.relative(path.resolve(dir), path.resolve(p));
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}
function isSkippedPath(p) {
  const parts = path.resolve(p).split(path.sep);
  if (parts.includes('node_modules') || parts.includes('.git')) return true;
  let root = pluginRoot();
  try { root = fs.realpathSync(root); } catch (e) { /* keep */ }
  let rp = path.resolve(p);
  try { rp = fs.realpathSync(rp); } catch (e) { /* keep */ }
  if (insideDir(rp, root) || insideDir(p, pluginRoot())) return true;
  return false;
}

module.exports = {
  LEVELS, WINDOW, WINDOW_FMT, PLAIN_CAP, ZIP_CAP, PLAIN_EXT, ZIP_EXT, NB_EXT, PHRASES, BANNED,
  GUARD_LABEL_CAP, CHECK_LABEL_CAP, SHOW_LABEL_CAP, PATCH_PATH_CAP,
  configDir, pluginRoot, flagPath, readStored, flagExists, envLevel, getLevel, setLevel, readStdinJson,
  contractText, welcomeText, detectorPath, runDetector, pythonAvailable, findings, phraseFor, rulesBlock,
  ledgerPath, readLedger, appendLedger, cleanOldLedgers, extOf, isProseExt, capFor, isArchiveExt,
  isInstructionFile, isSkippedPath, pythonNames,
};
