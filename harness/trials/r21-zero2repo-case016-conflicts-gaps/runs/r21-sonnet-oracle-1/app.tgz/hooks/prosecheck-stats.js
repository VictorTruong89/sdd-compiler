#!/usr/bin/env node
'use strict';
// Stats: session token use and own-prose score. Usable as a module or run directly
// (JSON on stdin with optional transcript_path; prints the reply as plain text).
const fs = require('fs');
const path = require('path');
const L = require('./lib');

const PROSE_MIN = 500;      // spec: N-001117 (conflict CF-000239, see NOTES.md)
const SLICE_KEEP = 40000;

function newestTranscript(dir) {
  let best = null;
  function walk(d, depth) {
    let ents;
    try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    for (const e of ents) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { if (depth < 4) walk(p, depth + 1); }
      else if (e.isFile() && e.name.endsWith('.jsonl')) {
        try {
          const st = fs.statSync(p);
          if (!best || st.mtimeMs > best.m) best = { p, m: st.mtimeMs };
        } catch (err) { /* ignore */ }
      }
    }
  }
  walk(dir, 0);
  return best ? best.p : null;
}

function fmt(n) { return String(n); }

function statsReply(input) {
  input = input || {};
  const level = L.getLevel();
  let tp = typeof input.transcript_path === 'string' && input.transcript_path.trim() ? input.transcript_path.trim() : null;
  if (!tp) tp = newestTranscript(path.join(L.configDir(), 'projects'));
  if (!tp) return 'stats: no session transcript was found, so there are no token figures to report.';
  let raw;
  try {
    if (!fs.statSync(tp).isFile()) throw new Error('not a file');
    raw = fs.readFileSync(tp, 'utf8');
  } catch (e) {
    return 'stats: the transcript could not be read, so there are no token figures to report.';
  }
  const ids = new Map();
  let anon = 0;
  let turns = 0;
  const texts = [];
  for (const line of raw.split(/\r?\n/)) {
    if (!line.trim()) continue;
    let row;
    try { row = JSON.parse(line); } catch (e) { continue; }
    if (!row || row.type !== 'assistant' || !row.message || typeof row.message !== 'object') continue;
    const msg = row.message;
    const u = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    const o = Number(u.output_tokens) || 0;
    const c = Number(u.cache_read_input_tokens) || 0;
    if (typeof msg.id === 'string' && msg.id) {
      const prev = ids.get(msg.id);
      if (!prev) { ids.set(msg.id, { o, c }); turns++; }
      else { prev.o = Math.max(prev.o, o); prev.c = Math.max(prev.c, c); }
    } else {
      anon++; turns++;
      ids.set('\0anon' + anon, { o, c });
    }
    if (Array.isArray(msg.content)) {
      for (const part of msg.content) {
        if (part && part.type === 'text' && typeof part.text === 'string') texts.push(part.text);
      }
    } else if (typeof msg.content === 'string') {
      texts.push(msg.content);
    }
  }
  let out = 0, cache = 0;
  for (const v of ids.values()) { out += v.o; cache += v.c; }
  const lines = [
    'prosecheck stats',
    'level: ' + level,
    'assistant turns: ' + fmt(turns),
    'output tokens: ' + fmt(out),
    'cache-read input tokens: ' + fmt(cache),
  ];
  let prose = texts.join('\n\n').replace(/^ {0,3}(`{3,}|~{3,})[^\n]*\n[\s\S]*?(?:\n {0,3}\1[`~]*[ \t]*(?=\n|$)|$)/gm, '');
  if (prose.length > SLICE_KEEP) prose = prose.slice(prose.length - SLICE_KEEP);
  prose = prose.trim();
  if (prose.length > PROSE_MIN) {
    const r = L.runDetector([], { input: prose, timeout: 8000 });
    if (r.status === 'ok') {
      lines.push('session prose ai_tell_score: ' + Math.round(r.report._metrics.ai_tell_score));
    }
  }
  return lines.join('\n');
}

module.exports = { statsReply, newestTranscript };

if (require.main === module) {
  try {
    const input = L.readStdinJson();
    process.stdout.write(statsReply(input) + '\n');
  } catch (e) { /* ignore */ }
  process.exitCode = 0;
}
