#!/usr/bin/env node
'use strict';
// Subagent-start hook: same contract inside the SubagentStart envelope. Always exits 0.
const L = require('./lib');
try {
  L.readStdinJson();
  const level = L.getLevel();
  if (level !== 'off') {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext: L.contractText(level) },
    }) + '\n');
  }
} catch (e) { /* ignore */ }
process.exitCode = 0;
