---
name: prosecheck
description: Rewrite flagged prose after a prosecheck scan ("prosecheck this", "humanize this"). Prose only, never code.
---
# prosecheck

Run the local detector on a prose file: `python3 scripts/detect.py <file>` (from the plugin root).
It prints a JSON report with a 0-100 score, a band, and fired pattern labels. The score describes the
writing, not the author. Rewrite flagged spans in plain language, vary sentence length, keep numbers,
names, quotes and technical terms, never invent facts, and stay silent about the process. Code,
commits, configuration, and chat are never touched.
