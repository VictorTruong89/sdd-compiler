---
description: prosecheck - set the level, check a file, run doctor, show, stats, init, or help
argument-hint: [lite|full|strict|off|on|status|show|check <file>|doctor|stats|init|help]
---
/prosecheck $ARGUMENTS
