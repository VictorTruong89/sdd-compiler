# Coverage of spec checklist

Generated from `spec/CHECKLIST.md` (1126 ids). `spec/` is unchanged.

Status meanings:
- **annotated**: the id is cited in a code or test comment (`# spec:` or `// spec:`) next to the code that implements it.
- **equivalent**: the id is a duplicate (per the compiler's "duplicates / same as" relation) of an annotated id.
- **pack-level**: implemented by the named files, which realise the whole pack. Not every id has its own annotation.
- **non-goal**: stated as out of scope; nothing is built for it.

Totals: annotated 607, equivalent 39, pack-level 468, non-goal 12

| id | pack | status | where |
|---|---|---|---|
| N-000588 | 02 | pack-level | scripts/detect.py; hooks/ (same as pack 01) |
| N-000589 | 02 | pack-level | scripts/detect.py; hooks/ (same as pack 01) |
| N-000590 | 02 | pack-level | scripts/detect.py; hooks/ (same as pack 01) |
| N-000591 | 02 | pack-level | scripts/detect.py; hooks/ (same as pack 01) |
| N-000592 | 02 | pack-level | scripts/detect.py; hooks/ (same as pack 01) |
| N-000593 | 03 | pack-level | scripts/detect.py run from the source tree; hooks run with node |
| N-000594 | 03 | pack-level | scripts/detect.py run from the source tree; hooks run with node |
| N-000595 | 03 | pack-level | scripts/detect.py run from the source tree; hooks run with node |
| N-000596 | 03 | pack-level | scripts/detect.py run from the source tree; hooks run with node |
| N-000597 | 03 | pack-level | scripts/detect.py run from the source tree; hooks run with node |
| N-000598 | 03 | pack-level | scripts/detect.py run from the source tree; hooks run with node |
| N-000599 | 03 | pack-level | scripts/detect.py run from the source tree; hooks run with node |
| N-000600 | 03 | pack-level | scripts/detect.py run from the source tree; hooks run with node |
| N-000601 | 03 | pack-level | scripts/detect.py run from the source tree; hooks run with node |
| N-000602 | 03 | pack-level | scripts/detect.py run from the source tree; hooks run with node |
| N-000001 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000002 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000003 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000004 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000005 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000006 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000007 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000008 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000009 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000010 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000011 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000012 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000013 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000014 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000015 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000016 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000017 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000018 | 04 | pack-level | scripts/detect.py; hooks/; commands/prosecheck.md |
| N-000019 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000020 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000021 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000022 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000023 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000024 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000025 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000026 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000027 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000028 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000029 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000030 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000031 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000032 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000033 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000034 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000035 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000036 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000037 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000038 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000039 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000040 | 05 | pack-level | scripts/detect.py (LABELS, band_for, analyse); hooks/lib/core.js (constants) |
| N-000041 | 06 | pack-level | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000042 | 06 | pack-level | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000043 | 06 | pack-level | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000044 | 06 | pack-level | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000045 | 06 | pack-level | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000046 | 06 | pack-level | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000047 | 06 | pack-level | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000048 | 06 | pack-level | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000049 | 06 | pack-level | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000050 | 06 | pack-level | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000051 | 06 | pack-level | scripts/detect.py; hooks/*.js; commands/prosecheck.md; .cursor/rules/prosecheck.mdc |
| N-000052 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000053 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000054 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000055 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000056 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000057 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000058 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000059 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000060 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000061 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000062 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000063 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000064 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000065 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000066 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000067 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000068 | 07 | annotated | annotated in hooks/lib/core.js |
| N-000069 | 07 | annotated | annotated in hooks/lib/core.js |
| N-000070 | 07 | annotated | annotated in hooks/lib/core.js |
| N-000071 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000072 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000073 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000074 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000075 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000076 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000077 | 07 | pack-level | scripts/detect.py (deterministic scan, no network); hooks/lib/core.js (ledger age, no network client) |
| N-000078 | 08 | pack-level | scripts/detect.py; hooks/ (real detector and real hooks, no accelerator) |
| N-000079 | 08 | pack-level | scripts/detect.py; hooks/ (real detector and real hooks, no accelerator) |
| N-000080 | 08 | pack-level | scripts/detect.py; hooks/ (real detector and real hooks, no accelerator) |
| N-000081 | 08 | pack-level | scripts/detect.py; hooks/ (real detector and real hooks, no accelerator) |
| N-000082 | 09 | non-goal | non-goal: nothing built (no authorship classifier, no PDF/RTF extraction, no hosted service) |
| N-000083 | 09 | non-goal | non-goal: nothing built (no authorship classifier, no PDF/RTF extraction, no hosted service) |
| N-000084 | 09 | non-goal | non-goal: nothing built (no authorship classifier, no PDF/RTF extraction, no hosted service) |
| N-000085 | 09 | non-goal | non-goal: nothing built (no authorship classifier, no PDF/RTF extraction, no hosted service) |
| N-000086 | 09 | non-goal | non-goal: nothing built (no authorship classifier, no PDF/RTF extraction, no hosted service) |
| N-000087 | 09 | non-goal | non-goal: nothing built (no authorship classifier, no PDF/RTF extraction, no hosted service) |
| N-000088 | 09 | non-goal | non-goal: nothing built (no authorship classifier, no PDF/RTF extraction, no hosted service) |
| N-000089 | 09 | non-goal | non-goal: nothing built (no authorship classifier, no PDF/RTF extraction, no hosted service) |
| N-000090 | 09 | non-goal | non-goal: nothing built (no authorship classifier, no PDF/RTF extraction, no hosted service) |
| N-000091 | 09 | non-goal | non-goal: nothing built (no authorship classifier, no PDF/RTF extraction, no hosted service) |
| N-000092 | 09 | non-goal | non-goal: nothing built (no authorship classifier, no PDF/RTF extraction, no hosted service) |
| N-000093 | 09 | non-goal | non-goal: nothing built (no authorship classifier, no PDF/RTF extraction, no hosted service) |
| N-000094 | 10 | annotated | annotated in scripts/detect.py |
| N-000095 | 10 | annotated | annotated in scripts/detect.py |
| N-000096 | 10 | annotated | annotated in scripts/detect.py |
| N-000097 | 10 | annotated | annotated in scripts/detect.py |
| N-000098 | 10 | annotated | annotated in scripts/detect.py |
| N-000099 | 10 | annotated | annotated in scripts/detect.py |
| N-000100 | 10 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000101 | 10 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000102 | 10 | annotated | annotated in scripts/detect.py, tests/hooks.test.js (also cited in tests) |
| N-000103 | 10 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000104 | 10 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000105 | 10 | annotated | annotated in scripts/detect.py |
| N-000106 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000107 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000108 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000109 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000110 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000111 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000112 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000113 | 10 | equivalent | duplicate of N-000768 (annotated in scripts/detect.py) |
| N-000114 | 10 | equivalent | duplicate of N-000769 (annotated in scripts/detect.py) |
| N-000115 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000116 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000117 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000118 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000119 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000120 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000121 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000122 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000123 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000124 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000125 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000126 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000127 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000128 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000129 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000130 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000131 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000132 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000133 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000134 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000135 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000136 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000137 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000138 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000139 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000140 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000141 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000142 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000143 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000144 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000145 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000146 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000147 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000148 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000149 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000150 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000151 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000152 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000153 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000154 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000155 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000156 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000157 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000158 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000159 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000160 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000161 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000162 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000163 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000164 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000165 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000166 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000167 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000168 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000169 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000170 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000171 | 10 | annotated | annotated in scripts/detect.py |
| N-000172 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000173 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000174 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000175 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000176 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000177 | 10 | annotated | annotated in scripts/detect.py |
| N-000178 | 10 | annotated | annotated in scripts/detect.py |
| N-000179 | 10 | annotated | annotated in scripts/detect.py |
| N-000180 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000181 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000182 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000183 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000184 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000185 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000186 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000187 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000188 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000189 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000190 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000191 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000192 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000193 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000194 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000195 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000196 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000197 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000198 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000199 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000200 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000201 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000202 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000203 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000204 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000205 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000206 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000207 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000208 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000209 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000210 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000211 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000212 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000213 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000214 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000215 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000216 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000217 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000218 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000219 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000220 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000221 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000222 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000223 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000224 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000225 | 10 | pack-level | scripts/detect.py (evaluate_families, compute_score, character_layer, analyse, main) |
| N-000226 | 10 | annotated | annotated in scripts/detect.py |
| N-000227 | 10 | annotated | annotated in scripts/detect.py |
| N-000228 | 10 | annotated | annotated in scripts/detect.py |
| N-000229 | 10 | annotated | annotated in scripts/detect.py |
| N-000230 | 10 | annotated | annotated in scripts/detect.py |
| N-000231 | 10 | annotated | annotated in scripts/detect.py |
| N-000232 | 10 | annotated | annotated in scripts/detect.py |
| N-000233 | 10 | annotated | annotated in scripts/detect.py |
| N-000234 | 10 | annotated | annotated in scripts/detect.py |
| N-000235 | 10 | annotated | annotated in scripts/detect.py |
| N-000236 | 10 | annotated | annotated in scripts/detect.py |
| N-000237 | 10 | annotated | annotated in scripts/detect.py |
| N-000238 | 10 | annotated | annotated in scripts/detect.py |
| N-000239 | 10 | annotated | annotated in scripts/detect.py |
| N-000240 | 10 | annotated | annotated in scripts/detect.py |
| N-000241 | 10 | annotated | annotated in scripts/detect.py |
| N-000242 | 10 | annotated | annotated in scripts/detect.py |
| N-000243 | 11 | pack-level | scripts/detect.py (read_prose_from_path, _zip_extract, _xlsx_text, _odf_text, _epub_text, _notebook_text); hooks/lib/core.js (caps, extensions) |
| N-000244 | 11 | pack-level | scripts/detect.py (read_prose_from_path, _zip_extract, _xlsx_text, _odf_text, _epub_text, _notebook_text); hooks/lib/core.js (caps, extensions) |
| N-000245 | 11 | annotated | annotated in scripts/detect.py |
| N-000246 | 11 | annotated | annotated in scripts/detect.py |
| N-000247 | 11 | annotated | annotated in scripts/detect.py |
| N-000248 | 11 | annotated | annotated in scripts/detect.py |
| N-000249 | 11 | annotated | annotated in scripts/detect.py |
| N-000250 | 11 | annotated | annotated in scripts/detect.py |
| N-000251 | 11 | pack-level | scripts/detect.py (read_prose_from_path, _zip_extract, _xlsx_text, _odf_text, _epub_text, _notebook_text); hooks/lib/core.js (caps, extensions) |
| N-000252 | 11 | pack-level | scripts/detect.py (read_prose_from_path, _zip_extract, _xlsx_text, _odf_text, _epub_text, _notebook_text); hooks/lib/core.js (caps, extensions) |
| N-000253 | 11 | pack-level | scripts/detect.py (read_prose_from_path, _zip_extract, _xlsx_text, _odf_text, _epub_text, _notebook_text); hooks/lib/core.js (caps, extensions) |
| N-000254 | 11 | annotated | annotated in scripts/detect.py |
| N-000255 | 11 | annotated | annotated in scripts/detect.py |
| N-000256 | 11 | annotated | annotated in scripts/detect.py |
| N-000257 | 11 | annotated | annotated in scripts/detect.py |
| N-000258 | 11 | annotated | annotated in scripts/detect.py |
| N-000259 | 11 | annotated | annotated in scripts/detect.py |
| N-000260 | 11 | annotated | annotated in scripts/detect.py |
| N-000261 | 11 | annotated | annotated in scripts/detect.py |
| N-000262 | 11 | annotated | annotated in scripts/detect.py |
| N-000263 | 11 | annotated | annotated in scripts/detect.py |
| N-000264 | 11 | annotated | annotated in scripts/detect.py |
| N-000265 | 11 | annotated | annotated in scripts/detect.py |
| N-000266 | 11 | annotated | annotated in scripts/detect.py |
| N-000267 | 11 | annotated | annotated in scripts/detect.py |
| N-000268 | 11 | annotated | annotated in scripts/detect.py |
| N-000269 | 11 | annotated | annotated in scripts/detect.py |
| N-000270 | 11 | annotated | annotated in scripts/detect.py |
| N-000271 | 11 | annotated | annotated in scripts/detect.py |
| N-000272 | 11 | annotated | annotated in scripts/detect.py |
| N-000273 | 11 | annotated | annotated in scripts/detect.py |
| N-000274 | 11 | annotated | annotated in scripts/detect.py |
| N-000275 | 11 | annotated | annotated in scripts/detect.py |
| N-000276 | 11 | annotated | annotated in scripts/detect.py |
| N-000277 | 11 | annotated | annotated in scripts/detect.py |
| N-000278 | 11 | annotated | annotated in scripts/detect.py |
| N-000279 | 11 | annotated | annotated in scripts/detect.py |
| N-000280 | 11 | annotated | annotated in scripts/detect.py |
| N-000281 | 11 | annotated | annotated in scripts/detect.py |
| N-000282 | 11 | annotated | annotated in scripts/detect.py |
| N-000283 | 11 | annotated | annotated in scripts/detect.py |
| N-000284 | 11 | annotated | annotated in scripts/detect.py |
| N-000285 | 11 | annotated | annotated in scripts/detect.py |
| N-000286 | 11 | pack-level | scripts/detect.py (read_prose_from_path, _zip_extract, _xlsx_text, _odf_text, _epub_text, _notebook_text); hooks/lib/core.js (caps, extensions) |
| N-000287 | 11 | pack-level | scripts/detect.py (read_prose_from_path, _zip_extract, _xlsx_text, _odf_text, _epub_text, _notebook_text); hooks/lib/core.js (caps, extensions) |
| N-000288 | 11 | pack-level | scripts/detect.py (read_prose_from_path, _zip_extract, _xlsx_text, _odf_text, _epub_text, _notebook_text); hooks/lib/core.js (caps, extensions) |
| N-000289 | 11 | pack-level | scripts/detect.py (read_prose_from_path, _zip_extract, _xlsx_text, _odf_text, _epub_text, _notebook_text); hooks/lib/core.js (caps, extensions) |
| N-000290 | 11 | equivalent | duplicate of N-000779 (annotated in scripts/detect.py) |
| N-000291 | 11 | pack-level | scripts/detect.py (read_prose_from_path, _zip_extract, _xlsx_text, _odf_text, _epub_text, _notebook_text); hooks/lib/core.js (caps, extensions) |
| N-000292 | 11 | equivalent | duplicate of N-000281 (annotated in scripts/detect.py) |
| N-000293 | 11 | pack-level | scripts/detect.py (read_prose_from_path, _zip_extract, _xlsx_text, _odf_text, _epub_text, _notebook_text); hooks/lib/core.js (caps, extensions) |
| N-000294 | 11 | pack-level | scripts/detect.py (read_prose_from_path, _zip_extract, _xlsx_text, _odf_text, _epub_text, _notebook_text); hooks/lib/core.js (caps, extensions) |
| N-000295 | 11 | pack-level | scripts/detect.py (read_prose_from_path, _zip_extract, _xlsx_text, _odf_text, _epub_text, _notebook_text); hooks/lib/core.js (caps, extensions) |
| N-000296 | 11 | pack-level | scripts/detect.py (read_prose_from_path, _zip_extract, _xlsx_text, _odf_text, _epub_text, _notebook_text); hooks/lib/core.js (caps, extensions) |
| N-000297 | 11 | pack-level | scripts/detect.py (read_prose_from_path, _zip_extract, _xlsx_text, _odf_text, _epub_text, _notebook_text); hooks/lib/core.js (caps, extensions) |
| N-000298 | 11 | pack-level | scripts/detect.py (read_prose_from_path, _zip_extract, _xlsx_text, _odf_text, _epub_text, _notebook_text); hooks/lib/core.js (caps, extensions) |
| N-000299 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000300 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000301 | 12 | equivalent | duplicate of N-000724 (annotated in scripts/detect.py) |
| N-000302 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000303 | 12 | annotated | annotated in scripts/detect.py |
| N-000304 | 12 | annotated | annotated in scripts/detect.py |
| N-000305 | 12 | annotated | annotated in scripts/detect.py |
| N-000306 | 12 | annotated | annotated in scripts/detect.py |
| N-000307 | 12 | annotated | annotated in scripts/detect.py |
| N-000308 | 12 | annotated | annotated in scripts/detect.py |
| N-000309 | 12 | annotated | annotated in scripts/detect.py |
| N-000310 | 12 | annotated | annotated in scripts/detect.py |
| N-000311 | 12 | annotated | annotated in scripts/detect.py |
| N-000312 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000313 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000314 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000315 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000316 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000317 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000318 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000319 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000320 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000321 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000322 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000323 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000324 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000325 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000326 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000327 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000328 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000329 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000330 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000331 | 12 | pack-level | scripts/detect.py (cleanup_text, character_layer, _invisible_kept) |
| N-000332 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000333 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000334 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000335 | 13 | annotated | annotated in hooks/prosecheck-activate.js, tests/hooks.test.js (also cited in tests) |
| N-000336 | 13 | annotated | annotated in hooks/prosecheck-activate.js, tests/hooks.test.js (also cited in tests) |
| N-000337 | 13 | annotated | annotated in hooks/prosecheck-activate.js, tests/hooks.test.js (also cited in tests) |
| N-000338 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000339 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000340 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000341 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000342 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000343 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000344 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000345 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000346 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000347 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000348 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000349 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000350 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000351 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000352 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000353 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000354 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000355 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000356 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000357 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000358 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000359 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000360 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000361 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000362 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000363 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000364 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000365 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000366 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000367 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000368 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000369 | 13 | pack-level | hooks/prosecheck-activate.js; hooks/prosecheck-subagent.js; hooks/prosecheck-tracker.js; hooks/lib/core.js (writingContract, welcomeBlock) |
| N-000370 | 13 | annotated | annotated in hooks/prosecheck-activate.js, tests/hooks.test.js (also cited in tests) |
| N-000371 | 13 | annotated | annotated in hooks/prosecheck-activate.js, tests/hooks.test.js (also cited in tests) |
| N-000372 | 13 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000373 | 13 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000374 | 13 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000375 | 13 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000376 | 13 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000377 | 13 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000378 | 13 | annotated | annotated in hooks/prosecheck-activate.js, tests/hooks.test.js (also cited in tests) |
| N-000379 | 13 | annotated | annotated in hooks/prosecheck-activate.js, tests/hooks.test.js (also cited in tests) |
| N-000380 | 13 | annotated | annotated in hooks/prosecheck-tracker.js, tests/hooks.test.js (also cited in tests) |
| N-000381 | 13 | annotated | annotated in hooks/prosecheck-tracker.js, tests/hooks.test.js (also cited in tests) |
| N-000382 | 13 | annotated | annotated in hooks/prosecheck-tracker.js, tests/hooks.test.js (also cited in tests) |
| N-000383 | 13 | annotated | annotated in hooks/prosecheck-tracker.js, tests/hooks.test.js (also cited in tests) |
| N-000384 | 13 | annotated | annotated in hooks/prosecheck-subagent.js, tests/hooks.test.js (also cited in tests) |
| N-000385 | 13 | annotated | annotated in hooks/prosecheck-subagent.js, tests/hooks.test.js (also cited in tests) |
| N-000386 | 13 | annotated | annotated in hooks/lib/core.js, tests/hooks.test.js (also cited in tests) |
| N-000387 | 13 | annotated | annotated in hooks/lib/core.js, tests/hooks.test.js (also cited in tests) |
| N-000388 | 13 | annotated | annotated in hooks/lib/core.js, tests/hooks.test.js (also cited in tests) |
| N-000389 | 13 | annotated | annotated in hooks/lib/core.js |
| N-000390 | 13 | annotated | annotated in hooks/lib/core.js |
| N-000391 | 13 | annotated | annotated in hooks/lib/core.js |
| N-000392 | 13 | annotated | annotated in hooks/lib/core.js |
| N-000393 | 13 | annotated | annotated in hooks/lib/core.js |
| N-000394 | 13 | annotated | annotated in hooks/lib/core.js |
| N-000395 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000396 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000397 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000398 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000399 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000400 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000401 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000402 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000403 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000404 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000405 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000406 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000407 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000408 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000409 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000410 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000411 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000412 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000413 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000414 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000415 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000416 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000417 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000418 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000419 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000420 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000421 | 14 | annotated | annotated in hooks/prosecheck-guard.js, tests/hooks.test.js (also cited in tests) |
| N-000422 | 14 | annotated | annotated in hooks/prosecheck-guard.js, tests/hooks.test.js (also cited in tests) |
| N-000423 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000424 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000425 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000426 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000427 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000428 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000429 | 14 | annotated | annotated in hooks/lib/core.js, hooks/prosecheck-guard.js, tests/hooks.test.js (also cited in tests) |
| N-000430 | 14 | annotated | annotated in hooks/lib/core.js, hooks/prosecheck-guard.js, tests/hooks.test.js (also cited in tests) |
| N-000431 | 14 | annotated | annotated in hooks/prosecheck-guard.js, tests/hooks.test.js (also cited in tests) |
| N-000432 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000433 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000434 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000435 | 14 | annotated | annotated in hooks/prosecheck-guard.js, tests/hooks.test.js (also cited in tests) |
| N-000436 | 14 | annotated | annotated in hooks/lib/core.js, hooks/prosecheck-guard.js, tests/hooks.test.js (also cited in tests) |
| N-000437 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000438 | 14 | annotated | annotated in hooks/lib/core.js, hooks/prosecheck-guard.js |
| N-000439 | 14 | annotated | annotated in hooks/lib/core.js, hooks/prosecheck-guard.js |
| N-000440 | 14 | annotated | annotated in hooks/lib/core.js, hooks/prosecheck-guard.js |
| N-000441 | 14 | annotated | annotated in hooks/lib/core.js, hooks/prosecheck-guard.js |
| N-000442 | 14 | annotated | annotated in hooks/prosecheck-guard.js, tests/hooks.test.js (also cited in tests) |
| N-000443 | 14 | annotated | annotated in hooks/prosecheck-guard.js, tests/hooks.test.js (also cited in tests) |
| N-000444 | 14 | annotated | annotated in hooks/prosecheck-guard.js, tests/hooks.test.js (also cited in tests) |
| N-000445 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000446 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000447 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000448 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000449 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000450 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000451 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000452 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000453 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000454 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000455 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000456 | 14 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000457 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/prosecheck-tracker.js |
| N-000458 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000459 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000460 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000461 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000462 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000463 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000464 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000465 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000466 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000467 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000468 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/prosecheck-tracker.js, tests/hooks.test.js (also cited in tests) |
| N-000469 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000470 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000471 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/prosecheck-tracker.js |
| N-000472 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000473 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000474 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000475 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000476 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000477 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000478 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000479 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000480 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000481 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000482 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000483 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000484 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000485 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000486 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000487 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000488 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000489 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000490 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000491 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000492 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000493 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000494 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000495 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000496 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000497 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000498 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000499 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000500 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000501 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000502 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000503 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000504 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000505 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000506 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000507 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000508 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000509 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000510 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000511 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000512 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000513 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000514 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000515 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000516 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000517 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000518 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000519 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000520 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000521 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000522 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000523 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000524 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000525 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000526 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000527 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000528 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000529 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000530 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000531 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000532 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000533 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000534 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000535 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000536 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000537 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000538 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000539 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000540 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000541 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000542 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000543 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/lib/stats.js, tests/hooks.test.js (also cited in tests) |
| N-000544 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/lib/stats.js, tests/hooks.test.js (also cited in tests) |
| N-000545 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/lib/stats.js |
| N-000546 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/lib/stats.js |
| N-000547 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/lib/stats.js, tests/hooks.test.js (also cited in tests) |
| N-000548 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/lib/stats.js |
| N-000549 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/lib/stats.js, tests/hooks.test.js (also cited in tests) |
| N-000550 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/lib/stats.js |
| N-000551 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/lib/stats.js, tests/hooks.test.js (also cited in tests) |
| N-000552 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/lib/stats.js |
| N-000553 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/lib/stats.js |
| N-000554 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/lib/stats.js |
| N-000555 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/lib/stats.js |
| N-000556 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000557 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000558 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000559 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000560 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000561 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000562 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000563 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000564 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000565 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000566 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000567 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000568 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000569 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000570 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000571 | 15 | annotated | annotated in hooks/lib/commands.js, tests/hooks.test.js (also cited in tests) |
| N-000572 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000573 | 15 | annotated | annotated in hooks/lib/commands.js |
| N-000574 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/prosecheck-tracker.js, tests/hooks.test.js (also cited in tests) |
| N-000575 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/prosecheck-tracker.js |
| N-000576 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/prosecheck-tracker.js |
| N-000577 | 15 | annotated | annotated in hooks/lib/commands.js, hooks/prosecheck-tracker.js |
| N-000578 | 16 | pack-level | all of the above; hooks/lib/core.js (no network); scripts/detect.py (no network) |
| N-000579 | 16 | pack-level | all of the above; hooks/lib/core.js (no network); scripts/detect.py (no network) |
| N-000580 | 16 | pack-level | all of the above; hooks/lib/core.js (no network); scripts/detect.py (no network) |
| N-000581 | 16 | pack-level | all of the above; hooks/lib/core.js (no network); scripts/detect.py (no network) |
| N-000582 | 16 | pack-level | all of the above; hooks/lib/core.js (no network); scripts/detect.py (no network) |
| N-000583 | 16 | pack-level | all of the above; hooks/lib/core.js (no network); scripts/detect.py (no network) |
| N-000584 | 16 | pack-level | all of the above; hooks/lib/core.js (no network); scripts/detect.py (no network) |
| N-000585 | 16 | pack-level | all of the above; hooks/lib/core.js (no network); scripts/detect.py (no network) |
| N-000586 | 16 | pack-level | all of the above; hooks/lib/core.js (no network); scripts/detect.py (no network) |
| N-000587 | 16 | pack-level | all of the above; hooks/lib/core.js (no network); scripts/detect.py (no network) |
| N-000603 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000604 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000605 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000606 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000607 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000608 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000609 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000610 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000611 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000612 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000613 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000614 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000615 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000616 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000617 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000618 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000619 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000620 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000621 | 17 | pack-level | overall product; scripts/detect.py; hooks/ |
| N-000622 | 17 | annotated | annotated in hooks/lib/core.js |
| N-000623 | 17 | annotated | annotated in hooks/lib/core.js |
| N-000624 | 17 | annotated | annotated in hooks/lib/core.js |
| N-000625 | 17 | annotated | annotated in hooks/lib/core.js |
| N-000626 | 17 | annotated | annotated in hooks/lib/core.js |
| N-000627 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000628 | 18 | annotated | annotated in scripts/detect.py |
| N-000629 | 18 | annotated | annotated in scripts/detect.py |
| N-000630 | 18 | annotated | annotated in scripts/detect.py |
| N-000631 | 18 | annotated | annotated in scripts/detect.py |
| N-000632 | 18 | annotated | annotated in scripts/detect.py |
| N-000633 | 18 | annotated | annotated in scripts/detect.py |
| N-000634 | 18 | annotated | annotated in scripts/detect.py |
| N-000635 | 18 | annotated | annotated in scripts/detect.py |
| N-000636 | 18 | annotated | annotated in scripts/detect.py |
| N-000637 | 18 | annotated | annotated in scripts/detect.py |
| N-000638 | 18 | annotated | annotated in scripts/detect.py |
| N-000639 | 18 | annotated | annotated in scripts/detect.py |
| N-000640 | 18 | annotated | annotated in scripts/detect.py |
| N-000641 | 18 | annotated | annotated in scripts/detect.py |
| N-000642 | 18 | annotated | annotated in scripts/detect.py |
| N-000643 | 18 | annotated | annotated in scripts/detect.py |
| N-000644 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000645 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000646 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000647 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000648 | 18 | equivalent | duplicate of N-000248 (annotated in scripts/detect.py) |
| N-000649 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000650 | 18 | equivalent | duplicate of N-000282 (annotated in scripts/detect.py) |
| N-000651 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000652 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000653 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000654 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000655 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000656 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000657 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000658 | 18 | equivalent | duplicate of N-000457 (annotated in hooks/lib/commands.js, hooks/prosecheck-tracker.js) |
| N-000659 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000660 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000661 | 18 | equivalent | duplicate of N-000460 (annotated in hooks/lib/commands.js) |
| N-000662 | 18 | equivalent | duplicate of N-000461 (annotated in hooks/lib/commands.js) |
| N-000663 | 18 | equivalent | duplicate of N-000873 (annotated in hooks/prosecheck-tracker.js) |
| N-000664 | 18 | equivalent | duplicate of N-000469 (annotated in hooks/lib/commands.js, tests/hooks.test.js) |
| N-000665 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000666 | 18 | equivalent | duplicate of N-001085 (annotated in tests/hooks.test.js) |
| N-000667 | 18 | equivalent | duplicate of N-000538 (annotated in hooks/lib/commands.js, tests/hooks.test.js) |
| N-000668 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000669 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000670 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000671 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000672 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000673 | 18 | pack-level | hooks/hooks.json; scripts/detect.py; commands/prosecheck.md; hooks/lib/core.js (exported files) |
| N-000674 | 19 | pack-level | hooks/lib/core.js (env variables, flag and ledger names); scripts/detect.py (labels, bands, confidence) |
| N-000675 | 19 | pack-level | hooks/lib/core.js (env variables, flag and ledger names); scripts/detect.py (labels, bands, confidence) |
| N-000676 | 19 | pack-level | hooks/lib/core.js (env variables, flag and ledger names); scripts/detect.py (labels, bands, confidence) |
| N-000677 | 19 | pack-level | hooks/lib/core.js (env variables, flag and ledger names); scripts/detect.py (labels, bands, confidence) |
| N-000678 | 19 | pack-level | hooks/lib/core.js (env variables, flag and ledger names); scripts/detect.py (labels, bands, confidence) |
| N-000679 | 19 | pack-level | hooks/lib/core.js (env variables, flag and ledger names); scripts/detect.py (labels, bands, confidence) |
| N-000680 | 19 | pack-level | hooks/lib/core.js (env variables, flag and ledger names); scripts/detect.py (labels, bands, confidence) |
| N-000681 | 19 | pack-level | hooks/lib/core.js (env variables, flag and ledger names); scripts/detect.py (labels, bands, confidence) |
| N-000682 | 19 | equivalent | duplicate of N-000765 (annotated in scripts/detect.py) |
| N-000683 | 19 | pack-level | hooks/lib/core.js (env variables, flag and ledger names); scripts/detect.py (labels, bands, confidence) |
| N-000684 | 19 | pack-level | hooks/lib/core.js (env variables, flag and ledger names); scripts/detect.py (labels, bands, confidence) |
| N-000685 | 19 | annotated | annotated in hooks/lib/core.js |
| N-000686 | 19 | annotated | annotated in hooks/lib/core.js |
| N-000687 | 19 | pack-level | hooks/lib/core.js (env variables, flag and ledger names); scripts/detect.py (labels, bands, confidence) |
| N-000688 | 19 | pack-level | hooks/lib/core.js (env variables, flag and ledger names); scripts/detect.py (labels, bands, confidence) |
| N-000689 | 19 | pack-level | hooks/lib/core.js (env variables, flag and ledger names); scripts/detect.py (labels, bands, confidence) |
| N-000690 | 19 | annotated | annotated in hooks/lib/core.js |
| N-000691 | 19 | annotated | annotated in hooks/lib/core.js |
| N-000692 | 19 | annotated | annotated in hooks/lib/core.js |
| N-000693 | 19 | annotated | annotated in hooks/lib/core.js |
| N-000694 | 19 | annotated | annotated in hooks/lib/core.js |
| N-000695 | 19 | annotated | annotated in hooks/lib/core.js |
| N-000696 | 19 | annotated | annotated in hooks/lib/core.js |
| N-000697 | 19 | annotated | annotated in hooks/lib/core.js |
| N-000698 | 19 | annotated | annotated in hooks/lib/core.js |
| N-000699 | 19 | annotated | annotated in hooks/lib/core.js |
| N-000700 | 19 | annotated | annotated in hooks/lib/core.js |
| N-000701 | 19 | annotated | annotated in hooks/lib/core.js |
| N-000702 | 19 | annotated | annotated in hooks/lib/core.js, hooks/prosecheck-activate.js |
| N-000703 | 20 | annotated | annotated in scripts/detect.py |
| N-000704 | 20 | annotated | annotated in scripts/detect.py, tests/hooks.test.js (also cited in tests) |
| N-000705 | 20 | annotated | annotated in scripts/detect.py, tests/hooks.test.js (also cited in tests) |
| N-000706 | 20 | annotated | annotated in scripts/detect.py |
| N-000707 | 20 | annotated | annotated in scripts/detect.py |
| N-000708 | 20 | annotated | annotated in scripts/detect.py |
| N-000709 | 20 | annotated | annotated in scripts/detect.py |
| N-000710 | 20 | annotated | annotated in scripts/detect.py |
| N-000711 | 20 | annotated | annotated in scripts/detect.py |
| N-000712 | 20 | annotated | annotated in scripts/detect.py |
| N-000713 | 20 | annotated | annotated in scripts/detect.py |
| N-000714 | 20 | annotated | annotated in scripts/detect.py |
| N-000715 | 20 | annotated | annotated in scripts/detect.py |
| N-000716 | 20 | annotated | annotated in scripts/detect.py |
| N-000717 | 20 | annotated | annotated in scripts/detect.py |
| N-000718 | 20 | annotated | annotated in scripts/detect.py |
| N-000719 | 20 | annotated | annotated in scripts/detect.py |
| N-000720 | 20 | annotated | annotated in scripts/detect.py |
| N-000721 | 20 | annotated | annotated in scripts/detect.py |
| N-000722 | 20 | annotated | annotated in scripts/detect.py |
| N-000723 | 20 | annotated | annotated in scripts/detect.py |
| N-000724 | 20 | annotated | annotated in scripts/detect.py |
| N-000725 | 20 | annotated | annotated in scripts/detect.py |
| N-000726 | 20 | annotated | annotated in hooks/lib/core.js, tests/hooks.test.js (also cited in tests) |
| N-000727 | 20 | annotated | annotated in hooks/lib/core.js, tests/hooks.test.js (also cited in tests) |
| N-000728 | 20 | pack-level | scripts/detect.py (exit codes, error objects); hooks/lib/core.js (flag, ledger) |
| N-000729 | 20 | pack-level | scripts/detect.py (exit codes, error objects); hooks/lib/core.js (flag, ledger) |
| N-000730 | 20 | pack-level | scripts/detect.py (exit codes, error objects); hooks/lib/core.js (flag, ledger) |
| N-000731 | 21 | pack-level | scripts/detect.py (argument parsing, analyse, error objects, several-operand notice) |
| N-000732 | 21 | annotated | annotated in scripts/detect.py |
| N-000733 | 21 | annotated | annotated in scripts/detect.py |
| N-000734 | 21 | annotated | annotated in scripts/detect.py |
| N-000735 | 21 | annotated | annotated in scripts/detect.py |
| N-000736 | 21 | annotated | annotated in scripts/detect.py |
| N-000737 | 21 | annotated | annotated in scripts/detect.py |
| N-000738 | 21 | annotated | annotated in scripts/detect.py |
| N-000739 | 21 | annotated | annotated in scripts/detect.py |
| N-000740 | 21 | annotated | annotated in scripts/detect.py |
| N-000741 | 21 | annotated | annotated in scripts/detect.py |
| N-000742 | 21 | annotated | annotated in scripts/detect.py |
| N-000743 | 21 | annotated | annotated in scripts/detect.py |
| N-000744 | 21 | annotated | annotated in scripts/detect.py |
| N-000745 | 21 | annotated | annotated in scripts/detect.py |
| N-000746 | 21 | annotated | annotated in scripts/detect.py |
| N-000747 | 21 | annotated | annotated in scripts/detect.py |
| N-000748 | 21 | annotated | annotated in scripts/detect.py |
| N-000749 | 21 | annotated | annotated in scripts/detect.py |
| N-000750 | 21 | annotated | annotated in scripts/detect.py |
| N-000751 | 21 | annotated | annotated in scripts/detect.py |
| N-000752 | 21 | annotated | annotated in scripts/detect.py |
| N-000753 | 21 | annotated | annotated in scripts/detect.py |
| N-000754 | 21 | annotated | annotated in scripts/detect.py |
| N-000755 | 21 | annotated | annotated in scripts/detect.py |
| N-000756 | 21 | annotated | annotated in scripts/detect.py |
| N-000757 | 21 | annotated | annotated in scripts/detect.py |
| N-000758 | 21 | annotated | annotated in scripts/detect.py |
| N-000759 | 21 | annotated | annotated in scripts/detect.py |
| N-000760 | 21 | annotated | annotated in scripts/detect.py |
| N-000761 | 21 | annotated | annotated in scripts/detect.py |
| N-000762 | 21 | annotated | annotated in scripts/detect.py |
| N-000763 | 21 | annotated | annotated in scripts/detect.py |
| N-000764 | 21 | annotated | annotated in scripts/detect.py |
| N-000765 | 21 | annotated | annotated in scripts/detect.py |
| N-000766 | 21 | annotated | annotated in scripts/detect.py |
| N-000767 | 21 | annotated | annotated in scripts/detect.py |
| N-000768 | 21 | annotated | annotated in scripts/detect.py |
| N-000769 | 21 | annotated | annotated in scripts/detect.py |
| N-000770 | 21 | annotated | annotated in scripts/detect.py |
| N-000771 | 21 | annotated | annotated in scripts/detect.py |
| N-000772 | 21 | annotated | annotated in scripts/detect.py |
| N-000773 | 21 | annotated | annotated in scripts/detect.py |
| N-000774 | 21 | annotated | annotated in scripts/detect.py |
| N-000775 | 21 | annotated | annotated in scripts/detect.py |
| N-000776 | 21 | annotated | annotated in scripts/detect.py |
| N-000777 | 21 | annotated | annotated in scripts/detect.py |
| N-000778 | 21 | annotated | annotated in scripts/detect.py |
| N-000779 | 21 | annotated | annotated in scripts/detect.py |
| N-000780 | 21 | annotated | annotated in scripts/detect.py |
| N-000781 | 21 | annotated | annotated in scripts/detect.py |
| N-000782 | 21 | annotated | annotated in scripts/detect.py |
| N-000783 | 21 | annotated | annotated in scripts/detect.py |
| N-000784 | 21 | annotated | annotated in scripts/detect.py |
| N-000785 | 21 | annotated | annotated in scripts/detect.py |
| N-000786 | 21 | annotated | annotated in scripts/detect.py |
| N-000787 | 21 | annotated | annotated in scripts/detect.py |
| N-000788 | 22 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000789 | 22 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000790 | 22 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000791 | 22 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000792 | 22 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000793 | 22 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000794 | 22 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000795 | 22 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000796 | 22 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000797 | 22 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000798 | 22 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000799 | 22 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000800 | 22 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000801 | 22 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000802 | 22 | annotated | annotated in hooks/prosecheck-activate.js, tests/hooks.test.js (also cited in tests) |
| N-000803 | 22 | annotated | annotated in hooks/prosecheck-activate.js, tests/hooks.test.js (also cited in tests) |
| N-000804 | 22 | annotated | annotated in hooks/prosecheck-activate.js, tests/hooks.test.js (also cited in tests) |
| N-000805 | 22 | annotated | annotated in hooks/prosecheck-activate.js, tests/hooks.test.js (also cited in tests) |
| N-000806 | 22 | annotated | annotated in hooks/prosecheck-activate.js, tests/hooks.test.js (also cited in tests) |
| N-000807 | 22 | annotated | annotated in hooks/prosecheck-activate.js, tests/hooks.test.js (also cited in tests) |
| N-000808 | 22 | annotated | annotated in hooks/prosecheck-activate.js, tests/hooks.test.js (also cited in tests) |
| N-000809 | 22 | annotated | annotated in hooks/prosecheck-activate.js, tests/hooks.test.js (also cited in tests) |
| N-000810 | 22 | annotated | annotated in hooks/prosecheck-activate.js, tests/hooks.test.js (also cited in tests) |
| N-000811 | 22 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000812 | 22 | annotated | annotated in hooks/prosecheck-activate.js |
| N-000813 | 23 | annotated | annotated in hooks/prosecheck-subagent.js |
| N-000814 | 23 | annotated | annotated in hooks/prosecheck-subagent.js |
| N-000815 | 23 | annotated | annotated in hooks/prosecheck-subagent.js, tests/hooks.test.js (also cited in tests) |
| N-000816 | 23 | annotated | annotated in hooks/prosecheck-subagent.js |
| N-000817 | 23 | annotated | annotated in hooks/prosecheck-subagent.js, tests/hooks.test.js (also cited in tests) |
| N-000818 | 23 | annotated | annotated in hooks/prosecheck-subagent.js, tests/hooks.test.js (also cited in tests) |
| N-000819 | 24 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000820 | 24 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000821 | 24 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000822 | 24 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000823 | 24 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000824 | 24 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000825 | 24 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000826 | 24 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000827 | 24 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000828 | 24 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000829 | 24 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000830 | 24 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000831 | 24 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000832 | 24 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000833 | 24 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000834 | 24 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000835 | 24 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000836 | 25 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000837 | 25 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000838 | 25 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000839 | 25 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000840 | 25 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000841 | 26 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000842 | 26 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000843 | 26 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000844 | 27 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000845 | 27 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000846 | 27 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000847 | 28 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000848 | 28 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000849 | 28 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000850 | 28 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000851 | 28 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000852 | 28 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000853 | 28 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000854 | 28 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000855 | 28 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000856 | 28 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000857 | 29 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000858 | 29 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000859 | 29 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000860 | 29 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000861 | 29 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000862 | 29 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000863 | 29 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000864 | 30 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000865 | 30 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000866 | 30 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000867 | 30 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000868 | 30 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000869 | 30 | annotated | annotated in hooks/prosecheck-guard.js |
| N-000870 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000871 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000872 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000873 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000874 | 31 | annotated | annotated in hooks/prosecheck-tracker.js, tests/hooks.test.js (also cited in tests) |
| N-000875 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000876 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000877 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000878 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000879 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000880 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000881 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000882 | 31 | annotated | annotated in hooks/prosecheck-tracker.js, tests/hooks.test.js (also cited in tests) |
| N-000883 | 31 | annotated | annotated in hooks/prosecheck-tracker.js, tests/hooks.test.js (also cited in tests) |
| N-000884 | 31 | annotated | annotated in hooks/prosecheck-tracker.js, tests/hooks.test.js (also cited in tests) |
| N-000885 | 31 | annotated | annotated in hooks/prosecheck-tracker.js, tests/hooks.test.js (also cited in tests) |
| N-000886 | 31 | annotated | annotated in hooks/prosecheck-tracker.js, tests/hooks.test.js (also cited in tests) |
| N-000887 | 31 | annotated | annotated in hooks/prosecheck-tracker.js, tests/hooks.test.js (also cited in tests) |
| N-000888 | 31 | annotated | annotated in hooks/prosecheck-tracker.js, tests/hooks.test.js (also cited in tests) |
| N-000889 | 31 | annotated | annotated in hooks/prosecheck-tracker.js, tests/hooks.test.js (also cited in tests) |
| N-000890 | 31 | annotated | annotated in hooks/prosecheck-tracker.js, tests/hooks.test.js (also cited in tests) |
| N-000891 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000892 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000893 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000894 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000895 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000896 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000897 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000898 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000899 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000900 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000901 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000902 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000903 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000904 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000905 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000906 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000907 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000908 | 31 | annotated | annotated in hooks/prosecheck-tracker.js |
| N-000909 | 32 | pack-level | hooks/lib/commands.js (helpReply) |
| N-000910 | 32 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000911 | 32 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000912 | 32 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000913 | 32 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000914 | 32 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000915 | 32 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000916 | 32 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000917 | 32 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000918 | 32 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000919 | 32 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000920 | 32 | pack-level | hooks/lib/commands.js (helpReply) |
| N-000921 | 32 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000922 | 32 | pack-level | hooks/lib/commands.js (helpReply) |
| N-000923 | 32 | pack-level | hooks/lib/commands.js (helpReply) |
| N-000924 | 32 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000925 | 32 | pack-level | hooks/lib/commands.js (helpReply) |
| N-000926 | 32 | pack-level | hooks/lib/commands.js (helpReply) |
| N-000927 | 32 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000928 | 32 | pack-level | hooks/lib/commands.js (helpReply) |
| N-000929 | 32 | pack-level | hooks/lib/commands.js (helpReply) |
| N-000930 | 32 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000931 | 32 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000932 | 32 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000933 | 32 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000934 | 32 | pack-level | hooks/lib/commands.js (helpReply) |
| N-000935 | 33 | pack-level | hooks/lib/commands.js (statusReply) |
| N-000936 | 33 | equivalent | duplicate of N-001105 (annotated in hooks/lib/stats.js) |
| N-000937 | 33 | pack-level | hooks/lib/commands.js (statusReply) |
| N-000938 | 33 | pack-level | hooks/lib/commands.js (statusReply) |
| N-000939 | 33 | equivalent | duplicate of N-000911 (annotated in tests/hooks.test.js) |
| N-000940 | 33 | pack-level | hooks/lib/commands.js (statusReply) |
| N-000941 | 33 | pack-level | hooks/lib/commands.js (statusReply) |
| N-000942 | 34 | pack-level | hooks/lib/commands.js (route, setReply) |
| N-000943 | 34 | pack-level | hooks/lib/commands.js (route, setReply) |
| N-000944 | 34 | pack-level | hooks/lib/commands.js (route, setReply) |
| N-000945 | 34 | pack-level | hooks/lib/commands.js (route, setReply) |
| N-000946 | 34 | pack-level | hooks/lib/commands.js (route, setReply) |
| N-000947 | 34 | equivalent | duplicate of N-000906 (annotated in hooks/prosecheck-tracker.js) |
| N-000948 | 34 | pack-level | hooks/lib/commands.js (route, setReply) |
| N-000949 | 34 | pack-level | hooks/lib/commands.js (route, setReply) |
| N-000950 | 34 | pack-level | hooks/lib/commands.js (route, setReply) |
| N-000951 | 34 | pack-level | hooks/lib/commands.js (route, setReply) |
| N-000952 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000953 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000954 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000955 | 35 | equivalent | duplicate of N-001105 (annotated in hooks/lib/stats.js) |
| N-000956 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000957 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000958 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000959 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000960 | 35 | equivalent | duplicate of N-000496 (annotated in hooks/lib/commands.js) |
| N-000961 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000962 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000963 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000964 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000965 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000966 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000967 | 35 | equivalent | duplicate of N-000798 (annotated in hooks/prosecheck-activate.js) |
| N-000968 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000969 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000970 | 35 | equivalent | duplicate of N-000827 (annotated in hooks/prosecheck-guard.js) |
| N-000971 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000972 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000973 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000974 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000975 | 35 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000976 | 35 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000977 | 35 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000978 | 35 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000979 | 35 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000980 | 35 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000981 | 35 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-000982 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000983 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000984 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000985 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000986 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000987 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000988 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000989 | 35 | equivalent | duplicate of N-000563 (annotated in hooks/lib/commands.js) |
| N-000990 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000991 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000992 | 35 | pack-level | hooks/lib/commands.js (checkReply, stripPathToken) |
| N-000993 | 36 | equivalent | duplicate of N-001105 (annotated in hooks/lib/stats.js) |
| N-000994 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-000995 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-000996 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-000997 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-000998 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-000999 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-001000 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-001001 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-001002 | 36 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001003 | 36 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001004 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-001005 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-001006 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-001007 | 36 | equivalent | duplicate of N-000498 (annotated in hooks/lib/commands.js, tests/hooks.test.js) |
| N-001008 | 36 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001009 | 36 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001010 | 36 | equivalent | duplicate of N-000504 (annotated in hooks/lib/commands.js) |
| N-001011 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-001012 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-001013 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-001014 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-001015 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-001016 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-001017 | 36 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001018 | 36 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001019 | 36 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001020 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-001021 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-001022 | 36 | equivalent | duplicate of N-001028 (annotated in tests/hooks.test.js) |
| N-001023 | 36 | pack-level | hooks/lib/commands.js (doctorReply) |
| N-001024 | 36 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001025 | 36 | equivalent | duplicate of N-001028 (annotated in tests/hooks.test.js) |
| N-001026 | 36 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001027 | 36 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001028 | 36 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001029 | 37 | equivalent | duplicate of N-000518 (annotated in hooks/lib/commands.js) |
| N-001030 | 37 | equivalent | duplicate of N-001105 (annotated in hooks/lib/stats.js) |
| N-001031 | 37 | equivalent | duplicate of N-000527 (annotated in hooks/lib/commands.js) |
| N-001032 | 37 | equivalent | duplicate of N-000435 (annotated in hooks/prosecheck-guard.js, tests/hooks.test.js) |
| N-001033 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001034 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001035 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001036 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001037 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001038 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001039 | 37 | equivalent | duplicate of N-000976 (annotated in tests/hooks.test.js) |
| N-001040 | 37 | equivalent | duplicate of N-000069 (annotated in hooks/lib/core.js) |
| N-001041 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001042 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001043 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001044 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001045 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001046 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001047 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001048 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001049 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001050 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001051 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001052 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001053 | 37 | equivalent | duplicate of N-000799 (annotated in hooks/prosecheck-activate.js) |
| N-001054 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001055 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001056 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001057 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001058 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001059 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001060 | 37 | pack-level | hooks/lib/commands.js (showReply); hooks/lib/core.js (readLedger, appendLedger) |
| N-001061 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001062 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001063 | 38 | equivalent | duplicate of N-001105 (annotated in hooks/lib/stats.js) |
| N-001064 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001065 | 38 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001066 | 38 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001067 | 38 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001068 | 38 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001069 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001070 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001071 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001072 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001073 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001074 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001075 | 38 | equivalent | duplicate of N-000530 (annotated in hooks/lib/commands.js, tests/hooks.test.js) |
| N-001076 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001077 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001078 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001079 | 38 | equivalent | duplicate of N-001094 (annotated in tests/hooks.test.js) |
| N-001080 | 38 | equivalent | duplicate of N-001095 (annotated in tests/hooks.test.js) |
| N-001081 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001082 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001083 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001084 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001085 | 38 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001086 | 38 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001087 | 38 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001088 | 38 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001089 | 38 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001090 | 38 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001091 | 38 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001092 | 38 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001093 | 38 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001094 | 38 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001095 | 38 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001096 | 38 | annotated | annotated in tests/hooks.test.js (also cited in tests) |
| N-001097 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001098 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001099 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001100 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001101 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001102 | 38 | pack-level | hooks/lib/commands.js (initReply); hooks/lib/core.js (exportContract, cursorRuleBody) |
| N-001103 | 39 | annotated | annotated in hooks/lib/stats.js, hooks/prosecheck-stats.js |
| N-001104 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001105 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001106 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001107 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001108 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001109 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001110 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001111 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001112 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001113 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001114 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001115 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001116 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001117 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001118 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001119 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001120 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001121 | 39 | annotated | annotated in hooks/lib/stats.js |
| N-001122 | 40 | annotated | annotated in hooks/lib/stats.js, hooks/prosecheck-stats.js |
| N-001123 | 40 | annotated | annotated in hooks/lib/stats.js |
| N-001124 | 40 | annotated | annotated in hooks/lib/stats.js |
| N-001125 | 40 | annotated | annotated in hooks/lib/stats.js |
| N-001126 | 40 | annotated | annotated in hooks/lib/stats.js |
