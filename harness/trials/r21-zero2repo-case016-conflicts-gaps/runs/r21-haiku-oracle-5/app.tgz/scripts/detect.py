#!/usr/bin/env python3
"""prosecheck detector: a local, deterministic prose-pattern scanner.

Standard library only (Python 3.9+). No network, no model, no randomness in
the default scan. Usage:

    python3 scripts/detect.py [--clean] [--ci] [--] [FILE]
    python3 scripts/detect.py --help

Report on success is one JSON object on stdout. Failures print one JSON
object {"error": ...} as the last line of stderr and exit 1 (empty input,
unreadable input) or 2 (unknown option).
"""

# spec: N-000094 N-000095 N-000096 N-000097 N-000098 N-000099  (FP-01 public entry)
# spec: N-000732 N-000733 N-000734 N-000735 N-000736 N-000737 N-000738 N-000739
# spec: N-000740 N-000741 N-000742 N-000743 N-000744 N-000745 N-000746 N-000747
# spec: N-000748 N-000749 N-000750 N-000751 N-000752 N-000753 N-000754 N-000755
# spec: N-000756 N-000757 N-000758 N-000759 N-000760 N-000761 N-000762 N-000763
# spec: N-000764 N-000765 N-000766 N-000767 N-000768 N-000769 N-000770 N-000771
# spec: N-000772 N-000773 N-000774 N-000775 N-000776 N-000777 N-000778 N-000779
# spec: N-000780 N-000781 N-000782 N-000783 N-000784 N-000785 N-000786 N-000787
# spec: N-000628 N-000629 N-000630 N-000631 N-000632 N-000633 N-000634 N-000635
# spec: N-000636 N-000637 N-000638 N-000639 N-000640 N-000641 N-000642 N-000643
# spec: N-000716 N-000717 N-000718 N-000719 N-000720 N-000721 N-000722 N-000723
# spec: N-000724 N-000725 N-000226 N-000227 N-000228 N-000229 N-000230 N-000231
# spec: N-000232 N-000233 N-000234 N-000235 N-000236 N-000237 N-000238 N-000239
# spec: N-000240 N-000241 N-000242 N-000703 N-000704 N-000705 N-000706 N-000707
# spec: N-000708 N-000709 N-000710 N-000711 N-000712 N-000713 N-000714 N-000715

import html
import json
import math
import os
import random
import re
import sys
import unicodedata
import zipfile

# ---------------------------------------------------------------------------
# Constants (FP-01, FP-02, FP-03)
# ---------------------------------------------------------------------------

SCAN_WINDOW = 262144  # spec: N-000105 N-000236 (window in characters)
PLAIN_CAP_BYTES = 512 * 1024  # spec: N-000245 N-000246 N-000247
ARCHIVE_CAP_BYTES = 4 * 1024 * 1024  # spec: N-000248 N-000249 N-000250

PLAIN_EXTS = {".md", ".mdx", ".markdown", ".txt", ".text", ".rst", ".tex", ".org", ".adoc"}
ZIP_EXTS = {".docx", ".docm", ".pptx", ".pptm", ".xlsx", ".xlsm", ".odt", ".odp", ".ods", ".epub"}
NOTEBOOK_EXT = ".ipynb"
NO_TEXT_EXTS = {".pdf", ".rtf"}  # spec: N-000282 N-000283 N-000284 N-000285

BANDS = [(20, "clean"), (40, "light tells"), (60, "mixed"), (80, "heavy tells"), (100, "pervasive tells")]

NO_DETECTOR = {7, 9, 28, 29, 43, 45, 49, 52, 53}  # spec: N-000102 (FP-01: no-detector numbers never appear)
WRITING_ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}  # weight zero
RHYTHM = {40, 41, 44, 55}
RHYTHM_SCORING = {40, 44}
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
SHORT_DOC_FAMILIES = set(range(1, 40)) | set(range(47, 52)) | {69}

# Per-family base weights (the PRD fixes which families move the score, not
# their size; these are this implementation's choice, see NOTES.md).
BASE_WEIGHT = 7.0
DECISIVE_WEIGHT = 12.0
RHYTHM_WEIGHT = 3.0

LABELS = {
    1: "AI vocabulary",
    2: "model-dialect vocabulary",
    3: "promotional language",
    4: "hyphenated word-pair overuse",
    5: "\"simple yet X\" cliche",
    6: "stacked adjective chains",
    8: "synonym cycling",
    10: "significance inflation",
    11: "notability name-dropping",
    12: "vague attributions",
    13: "article title used as a proper noun",
    14: "conservation and ecosystem padding",
    15: "false ranges",
    16: "superficial -ing tail clauses",
    17: "negative parallelism",
    18: "\"not X, just Y\" construction",
    19: "filler phrases",
    20: "empty pivot phrases",
    21: "outcome-speculation tails",
    22: "persuasive authority tropes",
    23: "editorial interjections",
    24: "self-thoroughness phrases",
    25: "question-and-answer rhetorical pattern",
    26: "\"concrete evidence\" defense phrase",
    27: "compulsive intro hooks",
    30: "diff-anchored writing",
    31: "signposting and announcements",
    32: "cataloguing lead-ins",
    33: "inline-header vertical lists",
    34: "mid-essay bullet injection",
    35: "fragmented headers",
    36: "formulaic challenges sections",
    37: "transition cluster overuse",
    38: "compulsive conclusion phrases",
    39: "generic positive conclusions",
    40: "sentence-length monotony",
    41: "mechanical sentence-length alternation",
    42: "opener repetition",
    44: "uniform paragraph length",
    46: "semicolon and parenthesis underuse",
    47: "chatbot artifacts",
    48: "sycophantic tone",
    50: "knowledge-cutoff disclaimer",
    51: "copula avoidance",
    54: "hedge stacking",
    55: "contraction absence",
    56: "boldface overuse",
    57: "emojis",
    58: "em-dash overuse",
    59: "title case in headings",
    60: "curly quotation marks",
    61: "hyphen in numeric year ranges",
    62: "invisible or zero-width characters",
    63: "placeholder text",
    64: "chatbot reference-markup leak",
    65: "AI tracking parameters",
    66: "mixed-script lookalike letters",
    67: "non-standard spaces",
    68: "trailing whitespace",
    69: "canonical marketing-slop phrases",
    70: "decorative horizontal rules",
    71: "degenerate repetition",
}
LABEL_OVERRIDES = {"17_negative_parallelism": "negative parallelism",
                   "17_tailing_negation": "tailing negation"}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _forms(word):
    """Inflected regex for a single lexical word (whole word, any case)."""
    w = re.escape(word)
    if word.endswith("e"):
        stem = re.escape(word[:-1])
        return r"%s(?:e|es|ed|ing)" % stem
    return r"%s(?:s|es|ed|ing)?" % w


def _alt(words):
    return "|".join(words)


def _rx(pattern, flags=re.IGNORECASE):
    return re.compile(pattern, flags)


def word_list_rx(words):
    parts = []
    for w in words:
        if " " in w:
            first, rest = w.split(" ", 1)
            parts.append(_forms(first) + r"\s+" + re.escape(rest))
        else:
            parts.append(_forms(w))
    return re.compile(r"\b(?:%s)\b" % "|".join(parts), re.IGNORECASE)


def phrase_rx(phrases):
    """Phrases, matched whole-word, with \\s+ between words; ' is curly-aware."""
    parts = []
    for p in phrases:
        esc = re.escape(p).replace(r"\ ", r"\s+").replace("'", "['’]")
        parts.append(esc)
    return re.compile(r"\b(?:%s)" % "|".join(parts) + r"(?![\w])", re.IGNORECASE)


# ---------------------------------------------------------------------------
# Character layer (FP-01 findings 62, 66, 67; FP-03 cleanup)
# ---------------------------------------------------------------------------

# spec: N-000171 N-000303 N-000304 N-000305 N-000306 N-000307 N-000308 N-000309
# spec: N-000310 N-000311 N-000177 N-000178 N-000179 N-000178

# Latin-looking letters of other scripts -> ASCII letter.
_LOOKALIKE = {
    "а": "a", "с": "c", "ԁ": "d", "е": "e", "һ": "h", "і": "i", "ј": "j",
    "о": "o", "р": "p", "ѕ": "s", "ԛ": "q", "ԝ": "w", "х": "x", "у": "y",
    "ѵ": "v", "ο": "o", "ν": "v", "ρ": "p", "ι": "i", "κ": "k", "ո": "n",
    "օ": "o", "ս": "u",
    "А": "A", "В": "B", "С": "C", "Е": "E", "Н": "H", "І": "I", "Ј": "J",
    "К": "K", "М": "M", "Ν": "N", "О": "O", "Р": "P", "Ѕ": "S", "Τ": "T",
    "Х": "X", "Υ": "Y", "Ζ": "Z", "Ο": "O", "Ρ": "P", "Μ": "M", "Ι": "I",
}
_LATIN_LETTER = re.compile(r"[A-Za-z]")
_TOKEN = re.compile(r"\S+")

_EMOJI_RE = re.compile(
    "[\U0001F000-\U0001FAFF\u2600-\u27BF\u2300-\u23FF\u2B00-\u2BFF\U0001F1E6-\U0001F1FF]"
)
_RTL_RE = re.compile(r"[\u0590-\u08FF\uFB1D-\uFDFF\uFE70-\uFEFF]")
_NOSPACE_SCRIPT = re.compile(
    "[\u0E00-\u0EFF\u1000-\u109F\u1780-\u17FF\u3040-\u30FF\u3400-\u9FFF\uF900-\uFAFF\U00020000-\U0003FFFF]"
)
_JOINING_SCRIPT = re.compile("[\u0590-\u06FF\u0900-\u0DFF\u1000-\u109F\u1780-\u17FF]")
_CJK = re.compile("[\u3400-\u9FFF\uF900-\uFAFF\U00020000-\U0003FFFF]")
_MONGOLIAN = re.compile("[\u1800-\u18AF]")
_KHMER = re.compile("[\u1780-\u17FF]")
_BIDI_CODES = set("\u200e\u200f\u061c\u202a\u202b\u202c\u202d\u202e\u2066\u2067\u2068\u2069")
_VS_CHARS = set(chr(c) for c in range(0xFE00, 0xFE10)) | set(chr(c) for c in range(0xE0100, 0xE01F0))
_MONGOL_VS = set("\u180b\u180c\u180d\u180f")
_TAG_RANGE = range(0xE0000, 0xE1000)


def _is_symbolish(ch):
    return bool(ch) and (unicodedata.category(ch) in ("So", "Sm", "Sc", "Sk") or _EMOJI_RE.match(ch))


def _is_letter(ch):
    return bool(ch) and ch.isalpha()


def _is_invisible_candidate(ch):
    cp = ord(ch)
    if ch in "\t\n\r":
        return False
    cat = unicodedata.category(ch)
    if cat == "Cf" or cat == "Cc":
        return True
    if cp in _TAG_RANGE:
        return True
    if ch in _VS_CHARS or ch in _MONGOL_VS:
        return True
    if cp in (0x034F, 0x115F, 0x1160, 0x3164, 0xFFA0, 0x17B4, 0x17B5, 0x180E):
        return True
    return False


def _invisible_kept(text, i, has_rtl):
    """True when an invisible-candidate at i does a job in its position (FP-03)."""
    ch = text[i]
    cp = ord(ch)
    prev = text[i - 1] if i > 0 else ""
    nxt = text[i + 1] if i + 1 < len(text) else ""
    if cp in _TAG_RANGE:
        if cp == 0xE007F:
            return prev == "\U0001F3F4" or (prev and ord(prev) in _TAG_RANGE)
        return prev == "\U0001F3F4" or (prev and ord(prev) in _TAG_RANGE and ord(prev) != 0xE007F)
    if ch in _VS_CHARS:
        return bool(prev) and (bool(_CJK.match(prev)) or _is_symbolish(prev)) or nxt == "\u20e3"
    if ch in _MONGOL_VS:
        return bool(prev) and bool(_MONGOLIAN.match(prev))
    if ch == "\u200b":
        return bool(_NOSPACE_SCRIPT.match(prev) or _NOSPACE_SCRIPT.match(nxt)) if (prev or nxt) else False
    if ch == "\u00ad":
        return _is_letter(prev) and _is_letter(nxt)
    if ch in _BIDI_CODES:
        return has_rtl
    if ch in ("\u200c", "\u200d"):
        return bool(
            (prev and (_JOINING_SCRIPT.match(prev) or _is_symbolish(prev)))
            or (nxt and (_JOINING_SCRIPT.match(nxt) or _is_symbolish(nxt)))
        )
    if ch in ("\u17b4", "\u17b5"):
        return bool((prev and _KHMER.match(prev)) or (nxt and _KHMER.match(nxt)))
    return False


def _is_nonstandard_space(ch):
    return ch != " " and (unicodedata.category(ch) == "Zs" or ch in "\u2028\u2029")


def _nbsp_kept(text, i):
    prev = text[i - 1] if i > 0 else ""
    nxt = text[i + 1] if i + 1 < len(text) else ""
    if (prev and prev.isdigit()) or (nxt and nxt.isdigit()):
        return True
    if nxt and nxt in ":;!?»›%€":
        return True
    if prev and prev in "«‹":
        return True
    return False


def _lookalike_tokens(text):
    """Yield (start, end) of whitespace-delimited tokens meeting the homoglyph condition."""
    for m in _TOKEN.finditer(text):
        tok = m.group(0)
        if not any(c in _LOOKALIKE for c in tok):
            continue
        if not _LATIN_LETTER.search(tok):
            continue
        ok = True
        has_look = False
        for c in tok:
            if c in _LOOKALIKE:
                has_look = True
            elif ord(c) > 127 and c.isalpha():
                ok = False
                break
        if ok and has_look:
            yield m.start(), m.end()


def character_layer(text):
    """Return (invisible_positions, nonstandard_positions, homoglyph_positions)."""
    has_rtl = bool(_RTL_RE.search(text))
    inv, nonstd, homo = [], [], []
    for i, ch in enumerate(text):
        if _is_invisible_candidate(ch) and not _invisible_kept(text, i, has_rtl):
            inv.append(i)
        elif _is_nonstandard_space(ch):
            if ch in "\u00a0\u202f" and _nbsp_kept(text, i):
                continue
            nonstd.append(i)
    for s, e in _lookalike_tokens(text):
        for j in range(s, e):
            if text[j] in _LOOKALIKE:
                homo.append(j)
    return inv, nonstd, homo


def cleanup_text(text):
    """FP-03: scrub the character layer and trim whitespace. Returns plain text."""
    has_rtl = bool(_RTL_RE.search(text))
    out = []
    # homoglyph folding positions
    fold = set()
    for s, e in _lookalike_tokens(text):
        for j in range(s, e):
            if text[j] in _LOOKALIKE:
                fold.add(j)
    for i, ch in enumerate(text):
        if _is_invisible_candidate(ch) and not _invisible_kept(text, i, has_rtl):
            continue
        if ch in "\u2028\u2029":
            out.append("\n")
            continue
        if _is_nonstandard_space(ch):
            if ch in "\u00a0\u202f" and _nbsp_kept(text, i):
                out.append(ch)
            else:
                out.append(" ")
            continue
        if i in fold:
            out.append(_LOOKALIKE[ch])
            continue
        out.append(ch)
    s = "".join(out)
    s = s.replace("\r\n", "\n").replace("\r", "\n")
    lines = [ln.rstrip(" \t") for ln in s.split("\n")]
    # drop leading blank lines
    while lines and lines[0].strip() == "":
        lines.pop(0)
    ended_with_newline = s.endswith("\n")
    while lines and lines[-1].strip() == "":
        lines.pop()
    body = "\n".join(lines)
    if not body:
        return ""
    if ended_with_newline:
        body += "\n"
    return body


# ---------------------------------------------------------------------------
# Extraction (FP-02)
# ---------------------------------------------------------------------------

# spec: N-000254 N-000255 N-000256 N-000257 N-000258 N-000259 N-000260 N-000261
# spec: N-000262 N-000263 N-000264 N-000265 N-000266 N-000267 N-000268 N-000269
# spec: N-000270 N-000271 N-000272 N-000273 N-000274 N-000275 N-000276 N-000277
# spec: N-000278 N-000279 N-000280 N-000281 N-000241

class ExtractError(Exception):
    pass


class EmptyInput(Exception):
    pass


_XML_TOKEN = re.compile(
    r"<!--.*?-->|<!\[CDATA\[(.*?)\]\]>|<\?.*?\?>|<![^>]*>|<(/?)([^\s/>!?]+)([^>]*?)(/?)>|([^<]+)",
    re.DOTALL,
)
_ATTR = re.compile(r"([^\s=]+)\s*=\s*(\"[^\"]*\"|'[^']*')")


def _xml_events(xml):
    """Yield ('open', name, attrs, selfclose) / ('close', name) / ('text', s)."""
    for m in _XML_TOKEN.finditer(xml):
        if m.group(1) is not None:
            yield ("text", m.group(1))
        elif m.group(3) is not None:
            name = m.group(3).rsplit(":", 1)[-1]
            if m.group(2):
                yield ("close", name)
            else:
                attrs = {}
                for k, v in _ATTR.findall(m.group(4)):
                    attrs[k.rsplit(":", 1)[-1]] = html.unescape(v[1:-1])
                yield ("open", name, attrs, bool(m.group(5)))
                if m.group(5):
                    yield ("close", name)
        elif m.group(6) is not None:
            yield ("text", html.unescape(m.group(6)))


def _decode_xml(data):
    if isinstance(data, str):
        return data
    if data.startswith(b"\xef\xbb\xbf"):
        data = data[3:]
    elif data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return data.decode("utf-16")
    return data.decode("utf-8", errors="replace")


def _finish_lines(chunks):
    """Join block chunks; strip each line, drop empty ones (FP-02 whitespace rule)."""
    lines = []
    for ch in chunks:
        for ln in ch.split("\n"):
            ln = ln.strip()
            if ln:
                lines.append(ln)
    return "\n".join(lines)


def _docx_text(xml):
    chunks, cur = [], []
    in_t = 0
    for ev in _xml_events(_decode_xml(xml)):
        if ev[0] == "open":
            name = ev[1]
            if name == "t" and not ev[3]:
                in_t += 1
            elif name == "tab":
                cur.append("\t")
            elif name == "br":
                cur.append("\n")
        elif ev[0] == "close":
            if ev[1] == "t" and in_t:
                in_t -= 1
            elif ev[1] == "p":
                chunks.append("".join(cur))
                cur = []
        elif ev[0] == "text" and in_t:
            cur.append(ev[1])
    if cur:
        chunks.append("".join(cur))
    return chunks


def _pptx_text(xml):
    return _docx_text(xml)  # a:p / a:t / a:br have the same shape for our purposes


def _shared_strings(xml):
    table, cur, in_t, collecting = [], [], 0, False
    for ev in _xml_events(_decode_xml(xml)):
        if ev[0] == "open":
            if ev[1] == "si":
                cur, collecting = [], True
            elif ev[1] == "t" and not ev[3]:
                in_t += 1
        elif ev[0] == "close":
            if ev[1] == "t" and in_t:
                in_t -= 1
            elif ev[1] == "si":
                table.append("".join(cur))
                collecting = False
        elif ev[0] == "text" and in_t and collecting:
            cur.append(ev[1])
    return table


def _xlsx_text(zf):
    names = set(zf.namelist())
    shared = []
    if "xl/sharedStrings.xml" in names:
        shared = _shared_strings(zf.read("xl/sharedStrings.xml"))
    # sheet order from workbook + relationships
    targets = []
    if "xl/workbook.xml" in names:
        rels = {}
        if "xl/_rels/workbook.xml.rels" in names:
            for ev in _xml_events(_decode_xml(zf.read("xl/_rels/workbook.xml.rels"))):
                if ev[0] == "open" and ev[1] == "Relationship":
                    rels[ev[2].get("Id", "")] = ev[2].get("Target", "")
        for ev in _xml_events(_decode_xml(zf.read("xl/workbook.xml"))):
            if ev[0] == "open" and ev[1] == "sheet":
                rid = ev[2].get("id", "")
                tgt = rels.get(rid, "")
                if tgt:
                    tgt = tgt.lstrip("/")
                    if not tgt.startswith("xl/"):
                        tgt = "xl/" + tgt
                    targets.append(tgt)
    if not targets:
        targets = sorted(n for n in names if re.match(r"xl/worksheets/sheet\d+\.xml$", n))
    lines = []
    for tgt in targets:
        if tgt not in names:
            continue
        cell_type, in_v, in_is_t, cell_text, in_c = None, False, 0, [], False
        values = []
        cur_v = []
        for ev in _xml_events(_decode_xml(zf.read(tgt))):
            if ev[0] == "open":
                if ev[1] == "c":
                    cell_type, in_c, cur_v, cell_text = ev[2].get("t", "n"), True, [], []
                    if ev[3]:
                        in_c = False
                        values.append("")
                elif ev[1] == "v" and in_c:
                    in_v = True
                    cur_v = []
                elif ev[1] == "t" and in_c:
                    in_is_t += 1
            elif ev[0] == "close":
                if ev[1] == "v":
                    in_v = False
                    if in_c and cell_type == "s":
                        raw = "".join(cur_v).strip()
                        if re.fullmatch(r"\d+", raw) and int(raw) < len(shared):
                            cell_text.append(shared[int(raw)])
                    elif in_c and cell_type == "str":
                        cell_text.append("".join(cur_v))
                elif ev[1] == "t" and in_is_t:
                    in_is_t -= 1
                elif ev[1] == "c":
                    if in_c:
                        txt = "".join(cell_text)
                        if txt.strip():
                            values.append(txt)
                    in_c = False
            elif ev[0] == "text":
                if in_v:
                    cur_v.append(ev[1])
                elif in_c and in_is_t and cell_type == "inlineStr":
                    cell_text.append(ev[1])
        lines.extend(values)
    return lines


def _odf_text(xml):
    chunks, cur, in_body, depth_skip = [], [], False, 0
    for ev in _xml_events(_decode_xml(xml)):
        if ev[0] == "open":
            name = ev[1]
            if name == "body":
                in_body = True
            elif not in_body:
                continue
            if name in ("p", "h"):
                cur.append("\n")
            elif name == "s":
                try:
                    n = int(ev[2].get("c", "1"))
                except ValueError:
                    n = 1
                cur.append(" " * max(1, min(n, 1000)))
            elif name == "tab":
                cur.append("\t")
            elif name == "line-break":
                cur.append("\n")
            elif name in ("table-cell", "table-row", "list-item"):
                cur.append("\n")
        elif ev[0] == "close":
            if ev[1] == "body":
                in_body = False
            elif ev[1] in ("p", "h", "table-cell", "table-row", "list-item"):
                cur.append("\n")
        elif ev[0] == "text" and in_body:
            cur.append(ev[1])
    text = "".join(cur)
    return [ln for ln in text.split("\n")]


def _epub_text(zf):
    names = zf.namelist()
    chapters = []
    opf_path = None
    if "META-INF/container.xml" in names:
        for ev in _xml_events(_decode_xml(zf.read("META-INF/container.xml"))):
            if ev[0] == "open" and ev[1] == "rootfile":
                opf_path = ev[2].get("full-path")
                break
    if opf_path and opf_path in names:
        base = opf_path.rsplit("/", 1)[0] + "/" if "/" in opf_path else ""
        manifest, spine = {}, []
        for ev in _xml_events(_decode_xml(zf.read(opf_path))):
            if ev[0] == "open":
                if ev[1] == "item":
                    manifest[ev[2].get("id", "")] = ev[2]
                elif ev[1] == "itemref" and ev[2].get("linear", "yes") != "no":
                    spine.append(ev[2].get("idref", ""))
        for idref in spine:
            item = manifest.get(idref)
            if not item:
                continue
            if "nav" in (item.get("properties") or "").split():
                continue
            if "html" not in (item.get("media-type") or "") and not item.get("href", "").endswith(
                (".xhtml", ".html", ".htm")
            ):
                continue
            chapters.append(base + item.get("href", ""))
    if not chapters:
        chapters = sorted(
            n for n in names
            if n.lower().endswith((".xhtml", ".html", ".htm"))
            and "nav" not in n.lower().rsplit("/", 1)[-1] and "toc" not in n.lower().rsplit("/", 1)[-1]
        )
    out = []
    for ch in chapters:
        if ch not in names:
            continue
        out.append(_xhtml_text(zf.read(ch)))
    return out


_BLOCK_TAGS = {"p", "div", "h1", "h2", "h3", "h4", "h5", "h6", "li", "br", "tr", "blockquote",
               "section", "article", "header", "footer", "pre", "dt", "dd", "figcaption",
               "ul", "ol", "table", "hr", "body", "title_block"}
_SKIP_TAGS = {"script", "style", "head", "nav", "title"}


def _xhtml_text(data):
    parts, skip, cur = [], 0, []
    for ev in _xml_events(_decode_xml(data)):
        if ev[0] == "open":
            name = ev[1]
            if name in _SKIP_TAGS:
                skip += 1
            elif name in _BLOCK_TAGS:
                cur.append("\n")
        elif ev[0] == "close":
            name = ev[1]
            if name in _SKIP_TAGS and skip:
                skip -= 1
            elif name in _BLOCK_TAGS:
                cur.append("\n")
        elif ev[0] == "text" and not skip:
            cur.append(re.sub(r"\s+", " ", ev[1]))
    return "".join(cur)


def _notebook_text(data):
    try:
        obj = json.loads(_decode_xml(data))
    except ValueError:
        return ""
    cells = obj.get("cells") if isinstance(obj, dict) else None
    if not isinstance(cells, list):
        return ""
    out = []
    for cell in cells:
        if not isinstance(cell, dict):
            return ""
        if cell.get("cell_type") != "markdown":
            continue
        src = cell.get("source", "")
        if isinstance(src, list):
            if not all(isinstance(s, str) for s in src):
                return ""
            src = "".join(src)
        elif not isinstance(src, str):
            return ""
        out.append(src.strip("\n"))
    return "\n".join(s for s in out if s.strip())


def _zip_extract(path, ext):
    try:
        zf = zipfile.ZipFile(path)
    except (zipfile.BadZipFile, OSError) as exc:
        raise ExtractError("cannot read input: %s (%s)" % (path, exc.__class__.__name__))
    with zf:
        try:
            if ext in (".docx", ".docm"):
                chunks = _docx_text(zf.read("word/document.xml")) if "word/document.xml" in zf.namelist() else []
                return _finish_lines(chunks)
            if ext in (".pptx", ".pptm"):
                slides = [n for n in zf.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)]
                slides.sort(key=lambda n: int(re.search(r"(\d+)\.xml$", n).group(1)))
                chunks = []
                for s in slides:
                    chunks.extend(_pptx_text(zf.read(s)))
                return _finish_lines(chunks)
            if ext in (".xlsx", ".xlsm"):
                return "\n".join(_xlsx_text(zf))
            if ext in (".odt", ".odp", ".ods"):
                if "content.xml" not in zf.namelist():
                    return ""
                return _finish_lines(_odf_text(zf.read("content.xml")))
            if ext == ".epub":
                return _finish_lines(_epub_text(zf))
        except (KeyError, ValueError, RuntimeError, zipfile.BadZipFile) as exc:
            raise ExtractError("cannot read input: %s (%s)" % (path, exc.__class__.__name__))
    return ""


def _plain_decode(data):
    """Decode plain text: UTF-8 (optional BOM) or UTF-16 with a BOM. A leading BOM is not prose."""
    if data.startswith(b"\xef\xbb\xbf"):
        data = data[3:]
        text = None
    elif data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        text = data.decode("utf-16", errors="replace")
    else:
        text = None
    if text is None:
        try:
            text = data.decode("utf-8")
        except UnicodeDecodeError:
            text = data.decode("utf-8", errors="replace")
    if text.startswith("\ufeff"):
        text = text[1:]
    return text


def read_prose_from_path(path):
    ext = os.path.splitext(path)[1].lower()
    if not os.path.isfile(path):
        raise ExtractError("cannot read input: %s" % path)
    if ext in ZIP_EXTS:
        return _zip_extract(path, ext)
    try:
        with open(path, "rb") as fh:
            data = fh.read()
    except OSError:
        raise ExtractError("cannot read input: %s" % path)
    if ext == NOTEBOOK_EXT:
        return _notebook_text(data)
    if ext in NO_TEXT_EXTS:
        return ""
    return _plain_decode(data)


def read_prose_from_stdin():
    data = sys.stdin.buffer.read()
    return _plain_decode(data)


# ---------------------------------------------------------------------------
# Text structure helpers
# ---------------------------------------------------------------------------

_WORD = re.compile(r"(?:[^\W_]|['’-])+")


def words_of(text):
    return [w for w in _WORD.findall(text) if re.search(r"[^\W_]", w)]


def mask_ignored(text):
    """Blank out regions that produce no findings (FP-01 'inside the scan window')."""
    chars = list(text)

    def blank(a, b):
        for k in range(a, b):
            if chars[k] not in "\n":
                chars[k] = " "

    # YAML front matter
    if text.startswith("---\n") or text.startswith("---\r\n"):
        m = re.search(r"\n(?:---|\.\.\.)[ \t]*(?=\n|$)", text)
        if m:
            blank(0, m.end())
    # fenced code blocks (CommonMark-ish), inline code spans
    pos = 0
    lines = text.splitlines(keepends=True)
    offsets = []
    for ln in lines:
        offsets.append(pos)
        pos += len(ln)
    fence = None
    for idx, ln in enumerate(lines):
        stripped = ln.strip()
        start = offsets[idx]
        if fence is None:
            m = re.match(r"^ {0,3}(`{3,}|~{3,})", ln)
            if m:
                fence = (m.group(1)[0], len(m.group(1)))
                blank(start, start + len(ln))
        else:
            ch, n = fence
            m = re.match(r"^ {0,3}(`{3,}|~{3,})[ \t]*$", ln)
            blank(start, start + len(ln))
            if m and m.group(1)[0] == ch and len(m.group(1)) >= n:
                fence = None
    # blockquote runs (>= 2 consecutive lines) and table rows, badge lines
    run = []
    for idx, ln in enumerate(lines):
        s = ln.lstrip()
        if s.startswith(">"):
            run.append(idx)
            continue
        if run:
            if len(run) >= 2:
                for r in run:
                    blank(offsets[r], offsets[r] + len(lines[r]))
            run = []
        if s.startswith("|") and s.count("|") >= 2:
            blank(offsets[idx], offsets[idx] + len(ln))
        elif re.fullmatch(r"\s*(?:\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+", ln):
            blank(offsets[idx], offsets[idx] + len(ln))
    if len(run) >= 2:
        for r in run:
            blank(offsets[r], offsets[r] + len(lines[r]))
    masked = "".join(chars)
    # inline code spans
    masked = re.sub(r"`[^`\n]*`", lambda m: " " * len(m.group(0)), masked)
    return masked


def paragraphs_of(text):
    return [p for p in re.split(r"\n[ \t]*\n", text) if p.strip()]


def sentences_of(text):
    parts = re.split(r"(?<=[.!?])\s+|\n+", text)
    return [s.strip() for s in parts if s and s.strip()]


def _cv(values):
    if len(values) < 2:
        return None
    mean = sum(values) / len(values)
    if mean == 0:
        return None
    var = sum((v - mean) ** 2 for v in values) / len(values)
    return math.sqrt(var) / mean


# ---------------------------------------------------------------------------
# Pattern families. Each returns a list of (start, end) spans in the masked text
# (or ints / strings for structural checks). Count = len(list).
# ---------------------------------------------------------------------------

def spans_of(rx, text):
    return [(m.start(), m.end()) for m in rx.finditer(text)]


AI_VOCAB = word_list_rx([
    "additionally", "align with", "crucial", "delve", "tapestry", "pivotal", "vibrant",
    "meticulous", "testament", "underscore", "intricate", "intricacies", "interplay",
    "garner", "bolster", "foster", "showcase", "emphasize", "enduring", "enhance",
    "leverage", "utilize", "facilitate", "encompass", "harness", "holistic", "paradigm",
    "transformative", "unprecedented", "myriad", "plethora", "robust", "seamless",
    "navigate", "embark", "craft", "landscape", "journey", "realm", "multifaceted",
    "elevate", "empower", "unlock",
])
AI_VOCAB_CAPTURE = _rx(r"\bcapture\s+the\s+(?:essence|spirit|imagination|heart|magic)\b")

MODEL_DIALECT = [
    _rx(r"\bgenuinely\b"), _rx(r"\bfascinating\b"), _rx(r"\bnuanced\b"),
    _rx(r"\bthoughtfully\b"), _rx(r"\brefreshingly\b"), _rx(r"\bstrikingly\b"),
    _rx(r"\bcompellingly\b"), _rx(r"\bquietly\s+(?:powerful|profound|radical)\b"),
    _rx(r"\bdeeply\s+(?:human|personal|felt|unsettling)\b"), _rx(r"\bresonates\s+deeply\b"),
    _rx(r"\bgame[- ]?chang(?:er|ers|ing)\b"), _rx(r"\bsupercharg(?:e|es|ed|ing)\b"),
    _rx(r"\bskyrocket(?:s|ed|ing)?\b"), _rx(r"\bturbocharg(?:e|es|ed|ing)\b"),
    _rx(r"\brevolutioni[sz](?:e|es|ed|ing)\b"), _rx(r"\bdouble\s+down\s+on\b"),
    _rx(r"\bdive\s+deep(?:er)?\s+into\b"), _rx(r"\bunlock\s+(?:the\s+)?(?:power|potential|value)\b"),
    _rx(r"\btake\s+[^.!?\n]{1,40}?\s+to\s+the\s+next\s+level\b"),
]

PROMO = phrase_rx([
    "nestled", "breathtaking", "must-visit", "stunning", "picturesque", "charming", "idyllic",
    "vibrant community", "rich cultural heritage", "in the heart of", "world-class", "top-tier",
    "unparalleled", "premier", "leading", "esteemed organization", "valuable asset",
    "passion for excellence", "proven track record", "results-oriented", "wealth of experience",
    "dynamic team", "fast-paced environment", "deeply passionate", "perfectly situated",
    "close-knit team", "tight-knit team", "I am excited to apply", "I am excited to bring",
    "I'm excited to apply", "I'm excited to bring", "uniquely positioned to",
])
PROMO_IMPERATIVE_VERBS = {
    "install", "join", "grab", "download", "try", "discover", "experience", "escape", "transform",
    "reclaim", "unlock", "elevate", "boost", "say", "imagine", "explore", "meet", "introducing",
    "upgrade", "claim", "unleash", "supercharge", "level", "stop", "start",
}

HYPHEN_PAIRS = phrase_rx([
    "cutting-edge", "state-of-the-art", "best-in-class", "next-generation", "results-driven",
    "data-driven", "user-centric", "customer-centric", "game-changing", "end-to-end",
    "fast-paced", "high-performing", "value-driven", "forward-thinking",
])

SIMPLE_YET = _rx(r"\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b")

ADJ_SUFFIX = re.compile(r"(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$", re.I)
STOCK_ADJ = {"vibrant", "robust", "seamless", "innovative", "dynamic", "comprehensive", "powerful",
             "elegant", "stunning", "cutting-edge", "reliable", "intuitive", "modern", "bold"}
CHAIN = _rx(r"\b(?:[A-Za-z][\w'-]{0,40},\s+){2,8}(?:(?:and|or)\s+)?[A-Za-z][\w'-]{0,40}\b(?=\s+[A-Za-z])")

SYNONYMS = [
    ["protagonist", "main character", "central figure", "hero", "heroine"],
    ["company", "firm", "organization", "enterprise", "business"],
    ["author", "writer", "novelist", "scribe"],
    ["report", "study", "analysis", "investigation", "examination"],
    ["technology", "tool", "system", "platform", "solution"],
    ["technique", "method", "approach", "strategy", "tactic"],
    ["challenge", "obstacle", "difficulty", "hurdle", "barrier"],
    ["benefit", "advantage", "upside", "strength"],
]

SIGNIFICANCE = [_rx(p) for p in [
    r"\b(?:stands?|serves?|stood|served)\s+as\s+an?\s+(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b",
    r"\b(?:underscor\w*|highlight\w*)\s+(?:its|the|their|his|her)\s+(?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b",
    r"\breflects?\s+a\s+broader\s+(?:trend|shift|pattern)\b",
    r"\bmarks?\s+a\s+(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)\b",
    r"\bsymboli[sz](?:es|ing)\b",
    r"\bsets?\s+the\s+stage\s+for\b",
    r"\bleft\s+an\s+indelible\s+mark\b",
    r"\bplays?\s+an?\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b",
    r"\bhas\s+(?:shaped|sparked)\b",
    r"\bhas\s+come\s+to\s+(?:define|symboli[sz]e)\b",
]]

NOTABILITY = [
    _rx(r"(?i:\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+)(?-i:[A-Z][\w&.]*(?:,\s*|\s+and\s+|\s+&\s+)[A-Z][\w&.]*)"),
    _rx(r"\b\d[\d,.]*\s*[KkMm]?\+?\s+followers\b"),
    _rx(r"\b(?:strong|active|robust)\s+(?:online|digital|social[- ]media)\s+presence\b"),
    _rx(r"\bwidely\s+covered\b"),
    _rx(r"\bindependent\s+coverage\b"),
]

VAGUE_ATTR = phrase_rx([
    "experts argue", "experts believe", "experts say", "experts claim", "experts note", "experts suggest",
    "industry reports", "industry observers", "industry analysts", "observers have cited",
    "observers have noted", "some critics argue", "researchers have found", "studies suggest",
    "it is widely believed",
])

ARTICLE_TITLE = re.compile(r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of [^.!?\n]{1,80}? (?:is|are) (?:a|an|the)\b")

CONSERVATION = [_rx(p) for p in [
    r"\bplays?\s+an?\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b",
    r"\bconservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)\b",
    r"\bserves?\s+as\s+an?\s+indicator\s+species\b",
    r"\bcontributes?\s+to\s+biodiversity\b",
]]

FALSE_RANGE = [
    _rx(r"\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]{0,200}?\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b"),
    _rx(r"\bfrom\s+(?:the\s+)?humble\b[^.!?\n]{0,200}?\bto\s+(?:the\s+)?(?:mighty|towering|grand|sprawling)\b"),
]

ING_TAIL = _rx(r",\s+(?:highlighting|reflecting|symboli[sz]ing|emphasi[sz]ing|underscoring|showcasing|fostering|"
               r"cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|"
               r"indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomi[sz]ing)\b")

PARALLEL_FORMS = [
    _rx(r"\bit['’]s\s+not\s+(?:just|merely)\s+(?:about|an?)\b"),
    _rx(r"\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b"),
    _rx(r"\bdoesn['’]t\s+just\b[^,.\n]{0,40}?\bit\b"),
]
TAILING_NEG = _rx(r"[A-Za-z][^,.!?\n]{0,200},\s*no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b")

NOT_X_JUST_Y = [
    _rx(r"\b(?:no|not)\s+[A-Za-z][\w'’-]*,\s+(?:just|only|simply)\s+[A-Za-z][\w'’-]*"),
    _rx(r"\b(?:not|isn['’]t|aren['’]t|wasn['’]t|weren['’]t)\s+(?:just|merely)\s+(?:an?\s+|the\s+)?[A-Za-z][\w'’-]*\s*(?:,|—|–|-)\s*(?:it['’]s|it\s+is|it\s+was|they['’]re|they\s+are|they\s+were|that['’]s|but)\b"),
]

FILLER = phrase_rx([
    "in order to", "due to the fact that", "at this point in time", "in the event that",
    "has the ability to", "it is important to note that", "it should be mentioned that",
    "needless to say",
])

EMPTY_PIVOT = [_rx(p) for p in [
    r"\bit['’]s\s+worth\s+(?:noting|mentioning)\s+that\b",
    r"\bit\s+bears\s+(?:noting|mentioning)\s+that\b",
    r"\b(?:one\s+thing\s+to\s+consider|keep\s+in\s+mind)\s+is\b",
    r"\bit\s+is\s+interesting\s+to\s+note\s+that\b",
    r"\ba\s+key\s+consideration\s+is\b",
    r"\ba\s+point\s+to\s+highlight\s+is\b",
]]

OUTCOME_TAIL = _rx(r",\s+(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about|"
                   r"with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for|"
                   r"signaling\s+a\s+shift\s+toward)\b")

AUTHORITY = phrase_rx([
    "here's the thing", "make no mistake", "the truth is", "let's be honest", "the simple fact is",
    "at its core", "what really matters", "more than anything", "at the end of the day",
    "the bottom line is", "in reality", "the real question is", "the heart of the matter",
    "the deeper issue", "when you get down to it", "when all is said and done",
])
FUNDAMENTALLY = _rx(r"\bfundamentally,")

INTERJECTIONS = [_rx(p) for p in [
    r"\bit\s*(?:['’]s|is)\s+important\s+to\s+(?:remember|note|understand|recognize)\b",
    r"\bone\s+must\s+note\s+that\b",
    r"\bit\s+is\s+worth\s+pointing\s+out\b",
    r"\bit\s+cannot\s+be\s+overstated\s+that\b",
    r"\bit\s+must\s+be\s+emphasi[sz]ed\s+that\b",
]]

SELF_THOROUGH = [_rx(p) for p in [
    r"\bthis\s+comprehensive\s+(?:guide|overview|analysis)\b",
    r"\bthis\s+in-depth\s+(?:analysis|look|examination)\b",
    r"\bthis\s+complete\s+(?:guide|overview)\b",
    r"\ba\s+thorough\s+examination\s+of\b",
    r"\beverything\s+you\s+need\s+to\s+know\s+about\b",
]]

QA_RHET = _rx(r"(?:^|(?<=[\s.!?]))(?:is|are|was|were|can|could|will|would|should|do|does|did|has|have|had)\s+[^.?!\n]{0,80}\?\s+(?:yes|no|absolutely|never|maybe|probably|always)[.!]")

CONCRETE = [_rx(p) for p in [
    r"\bwithout\s+concrete\s+(?:evidence|proof)\b",
    r"\bdo\s+you\s+have\s+concrete\s+(?:evidence|proof)\b",
    r"\bI\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples|proof)\s+to\b",
    r"\babsent\s+concrete\s+(?:proof|evidence)\b",
    r"\bprovide\s+concrete\s+(?:evidence|proof)\b",
]]

INTRO_HOOKS = [_rx(p) for p in [
    r"\bin\s+today['’]s\s+(?:\w+\s+){0,2}?(?:world|landscape|environment|market)\b",
    r"\bin\s+a\s+world\s+where\b",
    r"\bin\s+an\s+era\s+of\b",
    r"\bin\s+recent\s+years,",
    r"\bmore\s+than\s+ever\s+before\b",
    r"\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b",
    r"\b(?:great|exciting|big)\s+news\s*[!:]",
    r"\bever\s+(?:wanted|wondered|dreamed|wished)\b[^?\n]{0,200}\?",
    r"\bin\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world\b",
]]

DIFF_ANCHOR = [_rx(p) for p in [
    r"\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b",
    r"\b(?:the|this)\s+(?:latest\s+|new\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b",
    r"\bhas\s+been\s+(?:updated|refactored|improved|enhanced|changed\s+to)\b",
    r"\bhave\s+been\s+(?:updated|refactored|improved|enhanced|changed\s+to)\b",
    r"\bpreviously\b[^.!?\n]{0,200}\bnow\b",
    r"\b(?:was|were)n['’]t\s+there\s+before\b",
    r"\bwe['’]ve\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b",
    r"\bwe\s+have\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b",
]]

SIGNPOST = [_rx(p) for p in [
    r"\blet['’]s\s+(?:dive|delve|explore)\b",
    r"\blet['’]s\s+break\s+(?:this|it)\s+down\b",
    r"\bhere['’]s\s+what\s+you\s+need\s+to\s+know\b",
    r"\bwithout\s+further\s+ado\b",
    r"\bnow\s+let['’]s\s+look\s+at\b",
    r"\bbuckle\s+up\b",
    r"\bstay\s+with\s+me\b",
    r"\bready\s+to\s+dive\s+in\b",
]]

CATALOGUE_LEADIN = [_rx(p) for p in [
    r"\b(?:used|uses|employs?|employed|relied\s+on|utili[sz]es)\s+(?:several|various|a\s+number\s+of|multiple|different|many|numerous)\s+\w+",
    r"\bThese\s+(?:\w+\s+)?(?:provide|offer|give|reveal|show|allow|enable|help)\s+(?:information|insight|understanding|details|data)\b",
    r"\b(?:is|are|was|were|remains|becomes)\s+(?:the\s+|a\s+)?(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b",
]]

INLINE_HEADER = [
    _rx(r"(?m)^[ \t]*(?:[-*+]\s+|\d+[.)]\s+)?\*\*[^*\n]{1,80}?:\*\*"),
    _rx(r"(?m)^[ \t]*(?:[-*+]\s+|\d+[.)]\s+)?\*\*[^*\n]{1,80}?\*\*:"),
]

HEADING = re.compile(r"^(#{1,6})[ \t]+(.+?)[ \t]*#*[ \t]*$", re.M)
BULLET_LINE = re.compile(r"^\s*(?:[-*+]|\d+[.)])\s+")
TRANSITIONS = re.compile(r"(?:^|(?<=[.!?]\s)|(?<=\n))(Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably)\b")
CONCLUSION = _rx(r"(?m)^[ \t]*(?:in\s+conclusion|overall|in\s+summary|to\s+summari[sz]e|to\s+conclude|all\s+in\s+all|in\s+essence|ultimately)\b")
GENERIC_POS = [_rx(p) for p in [
    r"\bthe\s+future\s+looks\s+bright\b",
    r"\bexciting\s+times\s+lie\s+ahead\b",
    r"\bjourney\s+toward\s+excellence\b",
    r"\bstep\s+in\s+the\s+right\s+direction\b",
    r"\b(?:the\s+)?(?:outlook|future)\s+(?:for\s+[^.!?\n]{1,40}\s+)?(?:is|looks|remains)\s+bright\b",
    r"\bwell[- ]positioned\s+for\s+(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)\b",
]]

CHATBOT = [_rx(p) for p in [
    r"\bI\s+hope\s+this\s+helps\b",
    r"\bCertainly!",
    r"\bOf\s+course!",
    r"\blet\s+me\s+know\s+if\s+you\b",
    r"\bwould\s+you\s+like\s+me\s+to\b",
    r"\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b",
    r"\bhappy\s+to\s+help\s*[.]",
    r"\b(?:here|below)\s+is\s+(?:a\s+|an\s+|the\s+)?(?:overview|summary|rundown|recap|brief)\b",
    r"\bhere\s+(?:are|['’]s)\s+(?:a\s+few|some|two|three)\s+(?:options|drafts|versions|variations)\b",
    r"\bhere\s+is\s+(?:a\s+|the\s+)?draft\b",
    r"\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b",
    r"\bI\s+hope\s+(?:this\s+email\s+)?finds\s+you\s+well\b",
    r"\bas\s+an?\s+(?:AI|LLM)(?:\s+assistant|\s+language\s+model)?\b",
    r"\bas\s+an?\s+(?:large\s+)?language\s+model\b",
    r"\bto\s+(?:answer|address)\s+your\s+question\b",
    r"\bin\s+(?:response|answer)\s+to\s+your\s+question\b",
    r"\byour\s+question\s+(?:about|regarding|concerning)\b",
    r"\bas\s+you\s+(?:requested|asked),\s+here\b",
    r"\bhere\s+is\s+the\s+(?:draft|first\s+pass|revised\s+version)\b",
]]

SYCOPHANT = [_rx(p) for p in [
    r"\byou(?:['’]re|\s+are)\s+absolutely\s+right\b",
    r"\bgreat\s+question\s*[!.,]",
    r"\bexcellent\s+(?:point|question)\s*[!.,]",
    r"\bwhat\s+a\s+(?:thoughtful|great|wonderful|fantastic)\s+question\b",
    r"\bthat['’]s\s+a\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\b",
]]

PLACEHOLDER = [_rx(p) for p in [
    r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])",
    r"\[(?:name|person|company|client|place|source)\]",
    r"\{\{[^}\n]*\}\}",
    r"\bx{3,}\b",
    r"\blorem\s+ipsum\b",
    r"\[[A-Z][A-Z _-]{2,}\](?![(\[])",
]]
CHAT_MARKUP = [_rx(p) for p in [
    r"\bcite(?:turn|start|nav)\w*",
    r"\boai_citation\w*",
    r"\bcontentReference\b",
    r"\bnavlist\b",
    "【\\d+†[^】]*】",
]]
UTM = re.compile(r"utm_source=((?:[A-Za-z0-9-]+\.)*[A-Za-z0-9-]+)", re.I)
AI_HOSTS = {"chatgpt.com", "chat.openai.com", "perplexity.ai", "claude.ai", "gemini.google.com",
            "copilot.microsoft.com", "poe.com"}

HEDGE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|somewhat|relatively|fairly)\b"
                   r"|\bseems?\s+(?:to|like)\b|\bappears?\s+to\b|\bkind\s+of\b|\bsort\s+of\b")

COPULA = [_rx(p) for p in [
    r"\b(?:serves|stands|functions|acts)\s+as\b",
    r"\brepresents\s+an?\s",
    r"\bmarks\s+an?\s",
    r"\bboasts\b",
    r"\bfeatures\s+(?:an?|the|\d[\d,]*|several|many|numerous|multiple|dozens|hundreds)\b",
    r"\boffers\s+an?\s",
    r"\brefers\s+to\b",
]]

BOLD = re.compile(r"\*\*[^*\n]+\*\*")
EMOJI = re.compile("[\U0001F300-\U0001FAFF\u2600-\u27BF\U0001F000-\U0001F2FF\U0001F900-\U0001F9FF]")
EM_DASH = "\u2014"
CURLY = re.compile("[\u2018\u2019\u201c\u201d]")
YEAR_RANGE = re.compile(r"\b(1\d{3}|20\d{2})-(1\d{3}|20\d{2})\b")
HRULE = re.compile(r"^[ \t]*(?:-{3,}|\*{3,}|_{3,})[ \t]*$", re.M)
MARKETING_SLOP = phrase_rx([
    "unlocking full potential", "unlock your full potential", "unlocking your full potential",
    "navigating the complexities", "a testament to the power of", "a testament to the importance of",
    "staying ahead of the curve", "turning challenges into opportunities",
    "harnessing the power of", "paving the way for", "saying goodbye to", "imagining a world where",
    "in today's fast-paced world", "take your business to the next level",
])


def _lowercase_word_tokens(text):
    return [w.lower() for w in re.findall(r"[^\W_]+(?:['’][^\W_]+)*", text)]


# ---------------------------------------------------------------------------
# Family evaluation
# ---------------------------------------------------------------------------

class Finding(object):
    __slots__ = ("num", "slug", "count", "samples")

    def __init__(self, num, slug, count, samples):
        self.num = num
        self.slug = slug
        self.count = count
        self.samples = samples


def _excerpt(text, a, b, width=40):
    s = max(0, a - width)
    e = min(len(text), b + width)
    frag = text[s:e].replace("\n", " ").replace("\r", " ")
    frag = re.sub(r"\s+", " ", frag).strip()
    if s > 0:
        frag = "..." + frag
    if e < len(text):
        frag = frag + "..."
    return frag


def _collect(text, raw, spans, limit=3):
    samples = []
    for a, b in spans[:limit]:
        samples.append(_excerpt(raw, a, b))
    return samples


def _rx_spans(rx, text):
    return [(m.start(), m.end()) for m in rx.finditer(text)]


def _multi_spans(rxs, text):
    out = []
    for rx in rxs:
        out.extend(_rx_spans(rx, text))
    out.sort()
    return out


def evaluate_families(raw, masked):
    """Return dict key -> Finding for every fired machine-checked pattern."""
    found = {}

    def add(num, slug, spans, key=None, label_key=None):
        if not spans:
            return
        k = key or ("%d_%s" % (num, slug))
        found[k] = Finding(num, slug, len(spans), _collect(raw, raw, spans))

    # Lexical families
    add(1, "ai_vocabulary", _rx_spans(AI_VOCAB, masked) + _rx_spans(AI_VOCAB_CAPTURE, masked))
    dialect = _multi_spans(MODEL_DIALECT, masked)
    if len(dialect) >= 2:
        add(2, "model_dialect", dialect)
    imperative = []
    for sent in sentences_of(masked):
        first = re.match(r"[A-Za-z]+", sent)
        if first and first.group(0).lower() in PROMO_IMPERATIVE_VERBS:
            imperative.append((0, 0))
    promo_spans = _rx_spans(PROMO, masked)
    if len(imperative) >= 3:
        promo_spans = promo_spans + imperative
    add(3, "promotional_language", promo_spans)
    add(4, "hyphenated_pairs", _rx_spans(HYPHEN_PAIRS, masked))
    add(5, "simple_yet", _rx_spans(SIMPLE_YET, masked))

    chains = []
    for m in CHAIN.finditer(masked):
        words = re.findall(r"[A-Za-z][\w'-]*", m.group(0))
        if len(words) >= 4 and any(ADJ_SUFFIX.search(w) or w.lower() in STOCK_ADJ for w in words):
            chains.append((m.start(), m.end()))
    add(6, "stacked_adjectives", chains)

    syn_hits, syn_clusters = [], 0
    for cluster in SYNONYMS:
        rx = re.compile(r"\b(?:%s)\b" % "|".join(
            "%s(?:s|es)?" % re.escape(w).replace(r"\ ", r"\s+") for w in cluster), re.I)
        used = set()
        spans = []
        for m in rx.finditer(masked):
            spans.append((m.start(), m.end()))
            used.add(m.group(0).lower().rstrip("s"))
        if len(used) >= 3:
            syn_clusters += 1
            syn_hits.extend(spans)
    add(8, "synonym_cycling", syn_hits)

    add(10, "significance_inflation", _multi_spans(SIGNIFICANCE, masked))
    add(11, "notability", _multi_spans(NOTABILITY, masked))
    add(12, "vague_attributions", _rx_spans(VAGUE_ATTR, masked))
    add(13, "article_title", _rx_spans(ARTICLE_TITLE, masked))
    add(14, "conservation_padding", _multi_spans(CONSERVATION, masked))
    add(15, "false_ranges", _multi_spans(FALSE_RANGE, masked))
    add(16, "ing_tails", _rx_spans(ING_TAIL, masked))

    par = _multi_spans(PARALLEL_FORMS, masked)
    if par:
        found["17_negative_parallelism"] = Finding(17, "negative_parallelism", len(par), _collect(raw, raw, par))
    tail = _rx_spans(TAILING_NEG, masked)
    if tail:
        found["17_tailing_negation"] = Finding(17, "tailing_negation", len(tail), _collect(raw, raw, tail))

    add(18, "not_x_just_y", _multi_spans(NOT_X_JUST_Y, masked))
    add(19, "filler", _rx_spans(FILLER, masked))
    add(20, "empty_pivots", _multi_spans(EMPTY_PIVOT, masked))
    add(21, "outcome_tails", _rx_spans(OUTCOME_TAIL, masked))
    add(22, "authority_tropes", _rx_spans(AUTHORITY, masked) + _rx_spans(FUNDAMENTALLY, masked))
    add(23, "editorial_interjections", _multi_spans(INTERJECTIONS, masked))
    add(24, "self_thoroughness", _multi_spans(SELF_THOROUGH, masked))
    add(25, "question_answer", _rx_spans(QA_RHET, masked))
    add(26, "concrete_evidence", _multi_spans(CONCRETE, masked))
    add(27, "intro_hooks", _multi_spans(INTRO_HOOKS, masked))
    add(30, "diff_anchored", _multi_spans(DIFF_ANCHOR, masked))
    add(31, "signposting", _multi_spans(SIGNPOST, masked))
    add(32, "cataloguing_leadins", _multi_spans(CATALOGUE_LEADIN, masked))
    add(33, "inline_header_lists", _multi_spans(INLINE_HEADER, masked))

    # Structural families
    paras = paragraphs_of(masked)
    headings = list(HEADING.finditer(masked))
    if not headings:
        list_paras = [p for p in paras if all(BULLET_LINE.match(ln) for ln in p.split("\n") if ln.strip())]
        prose_paras = [p for p in paras if not all(BULLET_LINE.match(ln) for ln in p.split("\n") if ln.strip())]
        if list_paras and len(prose_paras) >= 2:
            add(34, "mid_essay_bullets", [(0, 0)] * len(list_paras))
    frag = []
    lines = masked.split("\n")
    for i, ln in enumerate(lines):
        m = HEADING.match(ln)
        if not m:
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nxt = lines[j].strip()
        if not nxt or nxt.startswith(("#", "-", "*", "|", ">", "`")) or re.match(r"\d+[.)]\s", nxt):
            continue
        if len(nxt.split()) > 4:
            continue
        head_words = set(w.lower() for w in re.findall(r"[A-Za-z]{4,}", m.group(2)))
        nxt_words = set(w.lower() for w in re.findall(r"[A-Za-z]{4,}", nxt))
        if head_words & nxt_words:
            frag.append((i, j))
    add(35, "fragmented_headers", [(a, a) for a, _ in frag])
    add(36, "formulaic_challenges", _rx_spans(
        re.compile(r"\bdespite\s+(?:these|its|the)\s+(?:challenges|obstacles)\b|\bchallenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)\b|"
                   r"\bcontinues\s+to\s+thrive\b|\btypical\s+of\s+(?:emerging|urban|modern)\b|\bfaces\s+(?:several|many|numerous)\s+challenges\b",
                   re.I), masked))

    trans_hits = 0
    for p in paras:
        n = len(TRANSITIONS.findall(p))
        if n >= 2:
            trans_hits += 1
    add(37, "transition_clusters", [(0, 0)] * trans_hits)

    add(38, "compulsive_conclusions", _rx_spans(CONCLUSION, masked))
    add(39, "generic_positive_conclusions", _multi_spans(GENERIC_POS, masked))

    sents = sentences_of(masked)
    sent_lens = [len(words_of(s)) for s in sents]
    sent_lens = [n for n in sent_lens if n > 0]
    if len(sent_lens) >= 3:
        cv = _cv(sent_lens)
        if cv is not None and cv < 0.35:
            add(40, "sentence_length_monotony", [(0, 0)])
    # mechanical alternation (writing advice)
    alt_runs = 0
    if len(sent_lens) >= 6:
        run = 0
        for i in range(1, len(sent_lens) - 1):
            d1 = sent_lens[i] - sent_lens[i - 1]
            d2 = sent_lens[i + 1] - sent_lens[i]
            if abs(d1) >= 6 and abs(d2) >= 6 and (d1 > 0) != (d2 > 0):
                run += 1
            else:
                if run >= 4:
                    alt_runs += 1
                run = 0
        if run >= 4:
            alt_runs += 1
    add(41, "mechanical_alternation", [(0, 0)] * alt_runs)

    opener = 0
    for p in paras:
        ps = sentences_of(p)
        if len(ps) < 3:
            continue
        starts = {}
        for s in ps:
            w = re.findall(r"[A-Za-z']+", s)[:2]
            if len(w) == 2:
                key = " ".join(x.lower() for x in w)
                starts[key] = starts.get(key, 0) + 1
        opener += sum(1 for v in starts.values() if v >= 3)
    add(42, "opener_repetition", [(0, 0)] * opener)

    para_lens = [len(words_of(p)) for p in paras]
    if len(para_lens) >= 4:
        cv = _cv(para_lens)
        if cv is not None and cv < 0.4:
            add(44, "uniform_paragraphs", [(0, 0)])

    wc_all = len(words_of(masked))
    if wc_all >= 300 and ";" not in masked and masked.count("(") <= 1:
        add(46, "semicolon_underuse", [(0, 0)])

    add(47, "chatbot_artifacts", _multi_spans(CHATBOT, masked))
    add(48, "sycophantic_tone", _multi_spans(SYCOPHANT, masked))
    add(50, "knowledge_cutoff", _rx_spans(re.compile(
        r"\bas\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)\b|\bup\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)\b|"
        r"\bwhile\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+(?:extensively|widely)\s+documented)\b|"
        r"\bbased\s+on\s+(?:the\s+)?available\s+information\b|\bas\s+of\s+my\s+(?:knowledge\s+)?cutoff\b|"
        r"\bmaintains\s+a\s+low\s+profile\b|\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b",
        re.I), masked))
    add(51, "copula_avoidance", _multi_spans(COPULA, masked))

    hedge_hits = 0
    for s in sents:
        if len(HEDGE.findall(s)) >= 2:
            hedge_hits += 1
    add(54, "hedge_stacking", [(0, 0)] * hedge_hits)

    first_person = len(re.findall(r"\b(?:I|me|my|we|our|us)\b", masked))
    contractions = len(re.findall(r"\b\w+(?:n['’]t|['’](?:re|ve|ll|m|s|d))\b", masked, re.I))
    full_forms = len(re.findall(r"\b(?:do not|does not|did not|is not|are not|was not|were not|I am|I have|I will|it is|that is|we are|we have|they are|you are|cannot)\b", masked, re.I))
    if wc_all and first_person / float(wc_all) >= 0.03 and contractions == 0 and full_forms >= 4:
        add(55, "contraction_absence", [(0, 0)])

    bold = _rx_spans(BOLD, masked)
    if len(bold) >= 3:
        add(56, "boldface_overuse", bold)
    add(57, "emojis", _rx_spans(EMOJI, masked))

    em_hits = 0
    for p in paras:
        if p.count(EM_DASH) >= 2:
            em_hits += 1
    add(58, "em_dash_overuse", [(0, 0)] * em_hits)

    title_hits = []
    for m in HEADING.finditer(masked):
        head = m.group(2).strip()
        if len(head.split()) < 3 or not re.match(r"[A-Za-z]", head) or head.isupper():
            continue
        small = {"a", "an", "the", "and", "but", "or", "nor", "for", "so", "yet", "at", "by", "in", "of",
                 "on", "to", "up", "as", "from", "with", "into", "over", "per", "via", "vs"}
        majors = [w for w in re.findall(r"[A-Za-z][A-Za-z'-]*", head) if w.lower() not in small]
        if len(majors) >= 2 and all(w[0].isupper() for w in majors):
            title_hits.append((m.start(), m.end()))
    add(59, "title_case_headings", title_hits)

    add(60, "curly_quotes", _rx_spans(CURLY, masked))

    year_hits = []
    for m in YEAR_RANGE.finditer(masked):
        if int(m.group(1)) < int(m.group(2)):
            year_hits.append((m.start(), m.end()))
    add(61, "year_hyphen_ranges", year_hits)

    placeholder = _multi_spans(PLACEHOLDER, masked)
    add(63, "placeholder_text", placeholder)
    add(64, "chat_markup", _multi_spans(CHAT_MARKUP, masked))

    utm_hits = []
    for m in UTM.finditer(masked):
        if m.group(1).lower().rstrip(".") in AI_HOSTS:
            utm_hits.append((m.start(), m.end()))
    add(65, "ai_tracking_params", utm_hits)

    hr = [(m.start(), m.end()) for m in HRULE.finditer(masked)]
    nonblank = [ln for ln in masked.split("\n") if ln.strip()]
    if len(hr) >= 3 and len(nonblank) >= 24:
        add(70, "decorative_rules", hr)

    add(69, "marketing_slop", _rx_spans(MARKETING_SLOP, masked))

    toks = _lowercase_word_tokens(masked)
    if len(toks) >= 6:
        grams = [tuple(toks[i:i + 6]) for i in range(len(toks) - 5)]
        counts = {}
        for g in grams:
            counts[g] = counts.get(g, 0) + 1
        rep = sum(1 for g in grams if counts[g] > 1)
        if rep and rep / float(len(grams)) >= 0.2:
            add(71, "degenerate_repetition", [(0, 0)] * rep)

    return found


def structural_character_findings(raw, inv, nonstd, homo):
    out = {}
    if inv:
        out["62_invisible_characters"] = Finding(
            62, "invisible_characters", len(inv),
            ["U+%04X at %d" % (ord(raw[i]), i) for i in inv[:3]])
    if homo:
        out["66_homoglyphs"] = Finding(66, "homoglyphs", len(homo), _collect(raw, raw, [(i, i + 1) for i in homo[:3]], 3))
    if nonstd:
        out["67_nonstandard_spaces"] = Finding(
            67, "nonstandard_spaces", len(nonstd),
            ["U+%04X at %d" % (ord(raw[i]), i) for i in nonstd[:3]])
    return out


def trailing_whitespace_findings(raw):
    """Finding 68: trailing spaces/tabs on lines, end-of-text whitespace, leading whitespace."""
    hits = []
    lines = raw.split("\n")
    for i, ln in enumerate(lines):
        if i < len(lines) - 1 and ln.endswith((" ", "\t")):
            hits.append(i)
    body = raw.rstrip()
    tail = raw[len(body):]
    if tail.strip(" \t") == "" and tail and tail.endswith((" ", "\t")):
        hits.append(-1)
    if tail.count("\n") >= 2:
        hits.append(-2)
    if raw[:1].isspace():
        hits.append(-3)
    if not hits:
        return {}
    return {"68_trailing_whitespace": Finding(68, "trailing_whitespace", len(hits),
                                              ["line %d has trailing whitespace" % (h + 1) for h in hits[:3] if h >= 0]
                                              or ["end of text has stray whitespace"])}


# ---------------------------------------------------------------------------
# Scoring (FP-01)
# ---------------------------------------------------------------------------

def band_for(score):
    for top, name in BANDS:
        if score <= top:
            return name
    return "pervasive tells"


def hook_phrase(band):
    return {
        "clean": "reads clean",
        "light tells": "reads mostly clean",
        "mixed": "reads with some AI tells",
        "heavy tells": "reads with heavy AI tells",
        "pervasive tells": "reads with pervasive AI tells",
    }[band]


def confidence_for(words, score_families):
    if words < 40:
        return "none", "fewer than 40 words, so the score is not meaningful"
    if words < 120:
        return "low", "fewer than 120 words"
    if words < 300 and score_families <= 1:
        return "low", "fewer than 300 words with only one score-moving pattern family"
    if words < 300:
        return "moderate", "fewer than 300 words"
    return "high", ""


def compute_score(findings, words):
    """Return (score, band, confidence, confidence_reason, scoring_families)."""
    fam_points = 0.0
    scoring = {}
    for key, f in findings.items():
        num = f.num
        if num in WRITING_ADVICE or key == "17_negative_parallelism":
            continue
        if num in NO_DETECTOR:
            continue
        scoring[num] = scoring.get(num, 0) + f.count
    fams = set(scoring)
    decisive = fams & DECISIVE
    for num in fams:
        hits = scoring[num]
        if num in DECISIVE:
            w = DECISIVE_WEIGHT
        elif num in RHYTHM:
            w = RHYTHM_WEIGHT
        else:
            w = BASE_WEIGHT
        fam_points += w * (1.0 + 0.25 * min(hits - 1, 4))
    raw = int(round(min(100.0, fam_points)))

    conf, reason = confidence_for(words, len(fams))
    cap = 100
    floor = 0
    if fams and fams <= RHYTHM:
        cap = 20 if fams <= {40} else 40
    if len(fams) == 1 and not (len(decisive) == 1 and conf in ("moderate", "high")):
        cap = min(cap, 40)
    if len(decisive) >= 2:
        floor = max(floor, 65)
    elif len(decisive) == 1 and conf in ("moderate", "high"):
        floor = max(floor, 45)
    if words < 120:
        n = len(fams & SHORT_DOC_FAMILIES)
        if n >= 3:
            floor = max(floor, 45)
        elif n == 2:
            floor = max(floor, 25)
    if words >= 400:
        n = len(fams)
        if n >= 6:
            floor = max(floor, 45)
        elif n >= 5:
            floor = max(floor, 25)
    score = max(floor, min(cap, raw))
    score = max(0, min(100, int(score)))
    return score, band_for(score), conf, reason, fams


def interval_for(sentences_counts, base_words, seed=20240601, rounds=200):
    """Resampled interval over sentence-level family counts (--ci)."""
    rng = random.Random(seed)
    n = len(sentences_counts)
    scores = []
    for _ in range(rounds):
        counts = {}
        words = 0
        for _i in range(n):
            c, w = sentences_counts[rng.randrange(n)]
            words += w
            for k, v in c.items():
                counts[k] = counts.get(k, 0) + v
        fake = {}
        for num, cnt in counts.items():
            fake[str(num)] = Finding(num, "x", cnt, [])
        s = _score_from_counts(counts, words)
        scores.append(s)
    scores.sort()
    lo = scores[int(0.05 * (len(scores) - 1))]
    hi = scores[int(0.95 * (len(scores) - 1))]
    return [lo, hi]


def _score_from_counts(counts, words):
    fam_points = 0.0
    fams = set()
    for num, hits in counts.items():
        if num in WRITING_ADVICE or num in NO_DETECTOR or hits <= 0:
            continue
        fams.add(num)
        if num in DECISIVE:
            w = DECISIVE_WEIGHT
        elif num in RHYTHM:
            w = RHYTHM_WEIGHT
        else:
            w = BASE_WEIGHT
        fam_points += w * (1.0 + 0.25 * min(hits - 1, 4))
    raw = int(round(min(100.0, fam_points)))
    return max(0, min(100, raw))


# ---------------------------------------------------------------------------
# Report
# ---------------------------------------------------------------------------

def analyse(prose, ci=False):
    total_chars = len(prose)
    truncated = total_chars > SCAN_WINDOW
    scanned = prose[:SCAN_WINDOW]
    masked = mask_ignored(scanned)
    inv, nonstd, homo = character_layer(scanned)
    findings = evaluate_families(scanned, masked)
    findings.update(structural_character_findings(scanned, inv, nonstd, homo))
    findings.update(trailing_whitespace_findings(scanned))
    words = len(words_of(scanned))
    score, band, conf, reason, fams = compute_score(findings, words)

    report = {}
    for key in sorted(findings, key=lambda k: (int(k.split("_", 1)[0]), k)):
        f = findings[key]
        label = LABEL_OVERRIDES.get(key) or LABELS.get(f.num, f.slug.replace("_", " "))
        report[key] = {"label": label, "count": int(f.count), "samples": list(f.samples)[:3]}

    metrics = {
        "scanned_chars": len(scanned),
        "truncated": bool(truncated),
        "ai_tell_score": int(score),
        "ai_tell_band": band,
        "confidence": conf,
        "confidence_reason": reason,
        "patterns_flagged": len(report),
        "invisible_chars": len(inv),
        "nonstandard_spaces": len(nonstd),
        "homoglyphs": len(homo),
    }
    if ci:
        metrics["score_ci"] = None
        metrics["score_ci_note"] = ""
        sents = [s for s in sentences_of(masked) if s.strip()]
        if len(sents) >= 4:
            counts_list = []
            for s in sents:
                sub = evaluate_families(s, mask_ignored(s))
                c = {}
                for f in sub.values():
                    if f.num in WRITING_ADVICE:
                        continue
                    c[f.num] = c.get(f.num, 0) + f.count
                counts_list.append((c, len(words_of(s))))
            metrics["score_ci"] = interval_for(counts_list, words)
            metrics["score_ci_note"] = "resampled over sentences (200 rounds, fixed seed); the point score is unchanged"
        else:
            metrics["score_ci"] = None
            metrics["score_ci_note"] = "too few sentences (fewer than 4) for an interval"
    report["_metrics"] = metrics
    return report


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

USAGE_FIRST = "usage: detect.py [--clean] [--ci] [--] [FILE]"
USAGE = (
    USAGE_FIRST + "\n"
    "\n"
    "Score prose for AI-writing patterns. Reads FILE, or standard input when no FILE is given.\n"
    "  --clean   print scrubbed text (invisible characters, odd spaces, lookalike letters, trailing spaces)\n"
    "  --ci      add a low/high interval on the score when the text has enough sentences\n"
    "  --        end option parsing so FILE may begin with a dash\n"
    "  -h, --help  print this usage\n"
    "Supported files: plain text (.md .txt ...), .docx .pptx .xlsx .odt .epub .ipynb (and dotted variants).\n"
    "Exit: 0 success, 1 empty input or unreadable input, 2 unknown option."
)


def _err(obj):
    sys.stderr.write(json.dumps(obj, ensure_ascii=False) + "\n")
    sys.stderr.flush()


def main(argv=None):
    argv = list(sys.argv[1:] if argv is None else argv)
    clean = False
    ci = False
    operands = []
    end = False
    for arg in argv:
        if end:
            operands.append(arg)
            continue
        if arg == "--":
            end = True
            continue
        if arg in ("-h", "--help"):
            sys.stdout.write(USAGE + "\n")
            sys.stdout.flush()
            return 0
        if arg == "--clean":
            clean = True
            continue
        if arg == "--ci":
            ci = True
            continue
        if arg == "-":
            operands.append(arg)
            continue
        if arg.startswith("-"):
            _err({"error": "unknown option '%s'; see --help" % arg})
            return 2
        operands.append(arg)

    if len(operands) > 1:
        sys.stderr.write("note: several files given; only the first file was scanned: %s\n" % operands[0])
        sys.stderr.flush()

    try:
        if operands and operands[0] != "-":
            prose = read_prose_from_path(operands[0])
        else:
            prose = read_prose_from_stdin()
    except ExtractError as exc:
        _err({"error": str(exc)})
        return 1

    if prose is None or not prose.strip():
        _err({"error": "empty input"})
        return 1

    prose = prose.replace("\r\n", "\n").replace("\r", "\n")
    if clean:
        text = cleanup_text(prose)
        if not text.strip():
            _err({"error": "empty input"})
            return 1
        sys.stdout.buffer.write(text.encode("utf-8"))
        sys.stdout.flush()
        return 0

    report = analyse(prose, ci=ci)
    out = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    sys.stdout.buffer.write(out.encode("utf-8"))
    sys.stdout.flush()
    return 0


if __name__ == "__main__":
    sys.exit(main())
