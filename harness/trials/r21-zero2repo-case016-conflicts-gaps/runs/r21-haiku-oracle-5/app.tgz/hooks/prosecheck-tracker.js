#!/usr/bin/env node
'use strict';
// Prompt-submit hook: the /prosecheck command router, the stop phrases, and the per-prompt reminder.
// spec: N-000380 N-000381 N-000382 N-000383 N-000457 N-000468 N-000471 N-000575
// spec: N-000576 N-000577 N-000847 N-000848 N-000849 N-000850 N-000851 N-000852
// spec: N-000853 N-000854 N-000855 N-000856 N-000870 N-000871 N-000872 N-000873
// spec: N-000874 N-000875 N-000876 N-000877 N-000878 N-000879 N-000880 N-000881
// spec: N-000882 N-000883 N-000884 N-000885 N-000886 N-000887 N-000888 N-000889
// spec: N-000890 N-000891 N-000892 N-000893 N-000894 N-000895 N-000896 N-000897
// spec: N-000898 N-000899 N-000900 N-000901 N-000902 N-000903 N-000904 N-000905
// spec: N-000906 N-000907 N-000908 N-000574
const core = require('./lib/core');
const commands = require('./lib/commands');

const CMD = /^\/prosecheck(?::prosecheck)?(?=\s|$)/i;

function emit(obj) {
  process.stdout.write(JSON.stringify(obj) + '\n');
}

function main() {
  const payload = core.readStdinJson();
  const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
  const sessionId = typeof payload.session_id === 'string' ? payload.session_id : '';
  const transcriptPath = typeof payload.transcript_path === 'string' ? payload.transcript_path : '';
  const trimmed = prompt.trim();
  const lower = trimmed.toLowerCase();

  const m = CMD.exec(trimmed);
  if (m) {
    const form = m[0];
    const rest = trimmed.slice(form.length).trim();
    const space = rest.search(/\s/);
    const sub = space === -1 ? rest : rest.slice(0, space);
    const arg = space === -1 ? '' : rest.slice(space + 1).trim();
    const reply = commands.route(sub, arg, { form, sessionId, transcriptPath });
    emit({ decision: 'block', reason: reply });
    return;
  }

  if (lower === 'stop prosecheck' || lower === 'prosecheck off') {
    core.setLevel('off');
    emit({ decision: 'block', reason: 'Level set to off: prosecheck is off, so no contract and no saved-file scoring. Run /prosecheck on to turn it back on.' });
    return;
  }

  const level = core.effectiveLevel();
  if (level === 'off') return;
  const reminder = 'prosecheck is at the ' + level + ' level: prose deliverables follow the writing contract; code, config, and commits are untouched.';
  emit({ hookSpecificOutput: { hookEventName: 'UserPromptSubmit', additionalContext: reminder } });
}

try {
  main();
} catch (e) {
  // never fail the host
}
process.exitCode = 0;
