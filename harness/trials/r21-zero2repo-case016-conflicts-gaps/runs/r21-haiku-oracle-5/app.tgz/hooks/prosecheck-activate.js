#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract (and the one-time welcome) in context.
// spec: N-000335 N-000336 N-000337 N-000370 N-000371 N-000372 N-000373 N-000374
// spec: N-000375 N-000376 N-000377 N-000378 N-000379 N-000788 N-000789 N-000790
// spec: N-000791 N-000792 N-000793 N-000794 N-000795 N-000796 N-000797 N-000798
// spec: N-000799 N-000800 N-000801 N-000802 N-000803 N-000804 N-000805 N-000806
// spec: N-000807 N-000808 N-000809 N-000810 N-000811 N-000812 N-000702
const fs = require('fs');
const path = require('path');
const core = require('./lib/core');

function main() {
  core.readStdinJson();
  try {
    fs.mkdirSync(core.configDir(), { recursive: true });
  } catch (e) {
    // continue; the contract still goes out
  }
  core.pruneLedgers();
  const flagPath = path.join(core.configDir(), core.FLAG_NAME);
  const firstRun = !fs.existsSync(flagPath);
  if (firstRun) {
    try { core.setLevel('full'); } catch (e) { /* ignore */ }
  }
  const level = core.effectiveLevel();
  if (level === 'off') return;
  const parts = [];
  if (firstRun) parts.push(core.welcomeBlock());
  parts.push(core.liveContract(level));
  process.stdout.write(parts.join('\n\n') + '\n');
}

try {
  main();
} catch (e) {
  // A hook never fails the host session.
}
process.exitCode = 0;
