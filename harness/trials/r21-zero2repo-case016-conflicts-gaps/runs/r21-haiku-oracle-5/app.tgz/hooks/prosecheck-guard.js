#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when it is flagged (FP-05).
// spec: N-000395 N-000396 N-000397 N-000398 N-000399 N-000400 N-000401 N-000402
// spec: N-000403 N-000404 N-000405 N-000406 N-000407 N-000408 N-000409 N-000410
// spec: N-000411 N-000412 N-000413 N-000414 N-000415 N-000416 N-000417 N-000418
// spec: N-000419 N-000420 N-000421 N-000422 N-000423 N-000424 N-000425 N-000426
// spec: N-000427 N-000428 N-000429 N-000430 N-000431 N-000432 N-000433 N-000434
// spec: N-000435 N-000436 N-000437 N-000438 N-000439 N-000440 N-000441 N-000442
// spec: N-000443 N-000444 N-000445 N-000446 N-000447 N-000448 N-000449 N-000450
// spec: N-000451 N-000452 N-000453 N-000454 N-000455 N-000456 N-000819 N-000820
// spec: N-000821 N-000822 N-000823 N-000824 N-000825 N-000826 N-000827 N-000828
// spec: N-000829 N-000830 N-000831 N-000832 N-000833 N-000834 N-000835 N-000836
// spec: N-000837 N-000838 N-000839 N-000840 N-000841 N-000842 N-000843 N-000844
// spec: N-000845 N-000846 N-000857 N-000858 N-000859 N-000860 N-000861 N-000862
// spec: N-000863 N-000864 N-000865 N-000866 N-000867 N-000868 N-000869
const fs = require('fs');
const path = require('path');
const core = require('./lib/core');

const PATCH_LINE = /^\*\*\* (Add File|Update File|Move to):\s*(.+?)\s*$/gm;

function collectPaths(payload) {
  const ti = payload.tool_input && typeof payload.tool_input === 'object' ? payload.tool_input : {};
  const found = [];
  if (typeof ti.file_path === 'string' && ti.file_path.trim()) found.push(ti.file_path.trim());
  if (typeof ti.notebook_path === 'string' && ti.notebook_path.trim()) found.push(ti.notebook_path.trim());
  if (typeof ti.command === 'string') {
    let m;
    PATCH_LINE.lastIndex = 0;
    while ((m = PATCH_LINE.exec(ti.command)) !== null) {
      if (m[2].trim()) found.push(m[2].trim());
    }
  }
  const seen = new Set();
  const out = [];
  for (const p of found) {
    if (!seen.has(p)) {
      seen.add(p);
      out.push(p);
    }
  }
  return out.slice(0, core.MAX_APPLY_PATCH_PATHS);
}

function isInstructionFile(abs) {
  const base = path.basename(abs).toLowerCase();
  if (core.INSTRUCTION_NAMES.indexOf(base) !== -1) return true;
  const ext = path.extname(base);
  const stem = ext ? base.slice(0, -ext.length) : base;
  if (core.INSTRUCTION_STEMS.indexOf(stem) !== -1 && core.PROSE_EXTS.indexOf(ext) === -1) return true;
  return false;
}

function isSkippedLocation(abs, root) {
  const segs = abs.split(/[\\/]+/);
  if (segs.indexOf('node_modules') !== -1 || segs.indexOf('.git') !== -1) return true;
  const rel = path.relative(root, abs);
  if (rel && !rel.startsWith('..') && !path.isAbsolute(rel)) return true;
  return false;
}

function main() {
  const payload = core.readStdinJson();
  const level = core.effectiveLevel();
  if (level !== 'full' && level !== 'strict') return;
  const threshold = core.THRESHOLD[level];
  const sessionId = typeof payload.session_id === 'string' ? payload.session_id : '';
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
  const root = core.pluginRoot();
  const nudges = [];

  for (const raw of collectPaths(payload)) {
    const abs = path.isAbsolute(raw) ? raw : path.resolve(cwd, raw);
    const base = path.basename(abs);
    const ext = path.extname(abs).toLowerCase();
    if (isInstructionFile(abs)) continue;
    if (isSkippedLocation(abs, root)) continue;
    let st;
    try {
      st = fs.statSync(abs);
    } catch (e) {
      core.appendLedger(sessionId, { kind: 'failed', base, reason: 'cannot read the file (not on disk)' });
      continue;
    }
    if (!st.isFile()) continue;
    if (core.BINARY_EXTS.indexOf(ext) !== -1) {
      core.appendLedger(sessionId, { kind: 'binary', base });
      continue;
    }
    if (core.PROSE_EXTS.indexOf(ext) === -1) continue;
    const zipLike = core.ZIP_EXTS.indexOf(ext) !== -1;
    const cap = zipLike ? core.ARCHIVE_CAP_BYTES : core.PLAIN_CAP_BYTES;
    if (st.size > cap) {
      core.appendLedger(sessionId, { kind: 'skipped', base, capKb: Math.round(cap / 1024) });
      continue;
    }
    const res = core.runDetector([abs], { timeout: zipLike ? core.ARCHIVE_TIMEOUT_MS : core.PLAIN_TIMEOUT_MS });
    let reason = null;
    if (res.notFound) reason = 'Python not found';
    else if (res.timedOut) reason = 'detector timed out';
    else if (res.status === 0 && !res.stdout.trim()) reason = 'detector exited without a usable result';
    else if (res.status !== 0) reason = 'detector exited without a usable result';
    if (reason) {
      core.appendLedger(sessionId, { kind: 'failed', base, reason });
      continue;
    }
    const rep = core.parseReport(res.stdout);
    if (!rep || rep.__notReport) {
      core.appendLedger(sessionId, { kind: 'failed', base, reason: 'detector output was not a structured report' });
      continue;
    }
    if (typeof rep._metrics.ai_tell_score !== 'number') {
      core.appendLedger(sessionId, { kind: 'failed', base, reason: 'report has no numeric score' });
      continue;
    }
    const s = core.summarizeReport(rep);
    const flagged = s.score > threshold;
    const labels = s.labels.map((l) => l.label).slice(0, 5);
    core.appendLedger(sessionId, {
      kind: 'scored', base, score: s.score, band: s.band, labels, flagged, truncated: s.truncated,
    });
    if (!flagged) continue;
    const coverage = s.truncated ? ', first ' + core.WINDOW_TEXT + ' characters only' : '';
    nudges.push('prosecheck: ' + base + ' ' + core.phraseFor(s.band) + ' (score ' + s.score + ', band ' + s.band + coverage +
      '). Flagged: ' + (labels.length ? labels.join('; ') : 'none') + '. Please fix the flagged spans.');
  }

  if (nudges.length) {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: nudges.join('\n') },
    }) + '\n');
  }
}

try {
  main();
} catch (e) {
  // never fail the host
}
process.exitCode = 0;
