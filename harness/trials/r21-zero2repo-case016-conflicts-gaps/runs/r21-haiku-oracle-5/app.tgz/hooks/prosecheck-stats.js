#!/usr/bin/env node
'use strict';
// Stand-alone stats entry: reads the hook JSON on stdin and prints the stats reply as plain text.
// spec: N-001103 N-001122
const core = require('./lib/core');
const { statsReply } = require('./lib/stats');

try {
  const payload = core.readStdinJson();
  const reply = statsReply({ transcriptPath: payload.transcript_path, level: core.effectiveLevel() });
  process.stdout.write(reply + '\n');
} catch (e) {
  // never fail the host
}
process.exitCode = 0;
