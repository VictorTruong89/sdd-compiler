#!/usr/bin/env node
'use strict';
// Subagent-start hook: the same writing contract, inside the SubagentStart envelope.
// spec: N-000384 N-000385 N-000813 N-000814 N-000815 N-000816 N-000817 N-000818
const core = require('./lib/core');

function main() {
  core.readStdinJson();
  const level = core.effectiveLevel();
  if (level === 'off') return;
  const out = {
    hookSpecificOutput: {
      hookEventName: 'SubagentStart',
      additionalContext: core.liveContract(level),
    },
  };
  process.stdout.write(JSON.stringify(out) + '\n');
}

try {
  main();
} catch (e) {
  // never fail the host
}
process.exitCode = 0;
