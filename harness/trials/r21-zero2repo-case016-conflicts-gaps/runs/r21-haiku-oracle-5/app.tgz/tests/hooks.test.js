'use strict';
// Hook and command tests. Run: node --test tests/
// Each test sets CLAUDE_CONFIG_DIR to a fresh temp folder so the user's real settings are untouched.

const test = require('node:test');
const assert = require('node:assert');
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const ROOT = path.resolve(__dirname, '..');
const HOOKS = path.join(ROOT, 'hooks');

function freshConfig() {
  return fs.mkdtempSync(path.join(os.tmpdir(), 'prosecheck-cfg-'));
}

function runHook(name, input, env) {
  const r = cp.spawnSync('node', [path.join(HOOKS, name)], {
    input: typeof input === 'string' ? input : JSON.stringify(input || {}),
    encoding: 'utf8',
    env: Object.assign({}, process.env, env || {}),
  });
  return { status: r.status, stdout: r.stdout || '', stderr: r.stderr || '' };
}

function command(prompt, env, extra) {
  const out = runHook('prosecheck-tracker.js', Object.assign({ prompt, session_id: 'sess-1' }, extra || {}), env);
  assert.strictEqual(out.status, 0);
  if (!out.stdout.trim()) return null;
  return JSON.parse(out.stdout);
}

// spec: N-000379 N-000380 N-000381 N-000382 N-000383 N-000386 N-000387 N-000388
test('malformed JSON on stdin still exits 0 and never fails the host', () => {
  const out = runHook('prosecheck-activate.js', '{not json', { CLAUDE_CONFIG_DIR: freshConfig() });
  assert.strictEqual(out.status, 0);
});

// spec: N-000370 N-000371 N-000378 N-000335 N-000337
test('first session start prints the welcome once; later starts do not', () => {
  const cfg = freshConfig();
  const env = { CLAUDE_CONFIG_DIR: cfg };
  const first = runHook('prosecheck-activate.js', {}, env).stdout;
  assert.match(first, /71 documented patterns/);
  assert.match(first, /512 KB/);
  assert.match(first, /4 MB/);
  assert.match(first, /262,144/);
  for (const c of ['/prosecheck doctor', '/prosecheck check', '/prosecheck off', '/prosecheck help']) {
    assert.ok(first.includes(c), 'welcome names ' + c);
  }
  const second = runHook('prosecheck-activate.js', {}, env).stdout;
  assert.doesNotMatch(second, /Welcome to prosecheck/);
  assert.match(second, /writing contract/);
});

// spec: N-000726 N-000727 N-000335 N-000336 N-000337 N-000804 N-000805 N-000806 N-000807 N-000808 N-000809 N-000810
test('contract shell parts per level', () => {
  const cfg = freshConfig();
  const env = { CLAUDE_CONFIG_DIR: cfg };
  runHook('prosecheck-activate.js', {}, env);
  const full = command('/prosecheck full', env);
  assert.match(full.reason, /Level set to full/);
  const ctx = runHook('prosecheck-activate.js', {}, env).stdout;
  assert.match(ctx, /Target: score 40 or less, band clean or light tells/);
  assert.doesNotMatch(ctx, /--clean/);

  command('/prosecheck strict', env);
  const strictCtx = runHook('prosecheck-activate.js', {}, env).stdout;
  assert.match(strictCtx, /score 20 or less, band clean/);
  assert.match(strictCtx, /--clean/);

  command('/prosecheck lite', env);
  const liteCtx = runHook('prosecheck-activate.js', {}, env).stdout;
  assert.doesNotMatch(liteCtx, /\b40\b/);
  assert.doesNotMatch(liteCtx, /light tells/);
  assert.match(liteCtx, /This contract never applies to source code/);
});

// spec: N-000384 N-000385 N-000817 N-000818 N-000815
test('subagent start returns the contract in the SubagentStart envelope; off is silent', () => {
  const cfg = freshConfig();
  const env = { CLAUDE_CONFIG_DIR: cfg };
  runHook('prosecheck-activate.js', {}, env);
  const out = runHook('prosecheck-subagent.js', {}, env);
  const obj = JSON.parse(out.stdout);
  assert.strictEqual(obj.hookSpecificOutput.hookEventName, 'SubagentStart');
  assert.match(obj.hookSpecificOutput.additionalContext, /writing contract/);
  command('/prosecheck off', env);
  assert.strictEqual(runHook('prosecheck-subagent.js', {}, env).stdout.trim(), '');
});

// spec: N-000475 N-000885 N-000886 N-000887 N-000888 N-000889 N-000890
test('stop phrases switch off only as the whole prompt', () => {
  const cfg = freshConfig();
  const env = { CLAUDE_CONFIG_DIR: cfg };
  const r = command('Stop Prosecheck', env);
  assert.strictEqual(r.decision, 'block');
  assert.match(r.reason, /\boff\b/);
  assert.strictEqual(command('write a poem', env), null);
  const ordinary = command('please stop prosecheck now', env);
  assert.ok(ordinary === null || ordinary.decision !== 'block' || !/off/.test(ordinary.reason));
});

// spec: N-000468 N-000469 N-000470 N-000473 N-000874 N-000882 N-000883 N-000884 N-000574
test('unknown subcommand names the word and leaves the level unchanged', () => {
  const cfg = freshConfig();
  const env = { CLAUDE_CONFIG_DIR: cfg };
  command('/prosecheck strict', env);
  const r = command('/prosecheck wibble', env);
  assert.match(r.reason, /Unknown subcommand "wibble"/);
  for (const w of ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help']) {
    assert.ok(new RegExp('\\b' + w + '\\b').test(r.reason), 'names ' + w);
  }
  assert.strictEqual(command('/prosecheck status', env).reason, 'prosecheck status: strict.');
});

// spec: N-000910 N-000911 N-000912 N-000913 N-000914 N-000915 N-000916 N-000917 N-000918 N-000919 N-000921 N-000924 N-000927 N-000930 N-000931 N-000932 N-000933
test('help: first line names the live level; every subcommand has a line', () => {
  const cfg = freshConfig();
  const env = { CLAUDE_CONFIG_DIR: cfg };
  const r = command('/prosecheck help', env, {});
  const lines = r.reason.split('\n').filter((l) => l.trim());
  assert.match(lines[0], /level is full/);
  assert.doesNotMatch(lines[0], /\b(lite|strict|off)\b/);
  assert.match(r.reason, /\bcode\b.*\bcommits\b.*\bconfig\b.*\bchat\b/is);
  assert.match(r.reason, /prosecheck this/);
  assert.match(r.reason, /humanize this/);
  assert.doesNotMatch(r.reason, /^\/prosecheck help/m);
  const liteLine = lines.find((l) => l.startsWith('/prosecheck lite'));
  assert.doesNotMatch(liteLine, /\b40\b|\b20\b/);
  assert.match(lines.find((l) => l.startsWith('/prosecheck full')), /\(default\)/);
});

// spec: N-000497 N-000498 N-000499 N-000500 N-000501 N-001002 N-001003 N-001008 N-001009 N-001017 N-001018 N-001019
test('doctor prints four check lines between a title and a closer; healthy install shows [OK] x4', () => {
  const cfg = freshConfig();
  const env = { CLAUDE_CONFIG_DIR: cfg };
  const r = command('/prosecheck:prosecheck doctor', env);
  const lines = r.reason.split('\n').filter((l) => l.trim());
  assert.strictEqual(lines.length, 6);
  const checks = lines.slice(1, 5);
  assert.strictEqual(checks.filter((l) => l.includes('[OK]')).length, 4);
  assert.match(lines[lines.length - 1], /512 KB/);
  assert.match(lines[lines.length - 1], /\/prosecheck:prosecheck show/);
  assert.doesNotMatch(lines[lines.length - 1], /\/prosecheck doctor/);
  assert.strictEqual(checks.filter((l) => /python/i.test(l)).length, 1);
});

// spec: N-001024 N-001026 N-001027 N-001028
test('doctor in off mode: mode line not OK; closer points at on in the typed form', () => {
  const cfg = freshConfig();
  const env = { CLAUDE_CONFIG_DIR: cfg };
  command('/prosecheck off', env);
  const r = command('/prosecheck:prosecheck doctor', env);
  const lines = r.reason.split('\n').filter((l) => l.trim());
  assert.doesNotMatch(lines[1], /\[OK\]/);
  assert.match(lines[1], /\/prosecheck on/);
  assert.match(lines[lines.length - 1], /\/prosecheck:prosecheck on/);
  assert.match(lines[lines.length - 1], /scored/);
  assert.doesNotMatch(lines[lines.length - 1], /not re-scored/);
});

// spec: N-000429 N-000430 N-000431 N-000435 N-000436 N-000442 N-000443 N-000444 N-000421 N-000422
test('guard: flagged file emits a nudge; unflagged and instruction files are silent', () => {
  const cfg = freshConfig();
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'prosecheck-work-'));
  const env = { CLAUDE_CONFIG_DIR: cfg };
  command('/prosecheck full', env);
  const ai = path.join(work, 'ai.md');
  fs.writeFileSync(ai, 'In today\'s fast-paced world, it\'s worth noting that our robust, seamless, and innovative solution is a testament to the power of collaboration. Additionally, the team will delve into the intricate landscape of modern tools. Furthermore, this comprehensive guide explores the multifaceted journey ahead.\n');
  const plain = path.join(work, 'plain.md');
  fs.writeFileSync(plain, 'I replaced the pump last spring. The old one leaked from the seal.\n');
  const claude = path.join(work, 'CLAUDE.md');
  fs.writeFileSync(claude, 'Project notes.\n');

  const nudge = JSON.parse(runHook('prosecheck-guard.js', { tool_name: 'Write', tool_input: { file_path: ai }, session_id: 'g1' }, env).stdout);
  assert.strictEqual(nudge.hookSpecificOutput.hookEventName, 'PostToolUse');
  assert.match(nudge.hookSpecificOutput.additionalContext, /ai\.md/);
  assert.match(nudge.hookSpecificOutput.additionalContext, /fix/i);
  assert.strictEqual(runHook('prosecheck-guard.js', { tool_name: 'Write', tool_input: { file_path: plain }, session_id: 'g1' }, env).stdout.trim(), '');
  assert.strictEqual(runHook('prosecheck-guard.js', { tool_name: 'Write', tool_input: { file_path: claude }, session_id: 'g1' }, env).stdout.trim(), '');
  const shown = command('/prosecheck show', env, { session_id: 'g1' }).reason;
  assert.match(shown, /ai\.md - reads/);
  assert.doesNotMatch(shown, new RegExp(work.replace(/[\\^$.*+?()[\]{}|]/g, '\\$&')));
  assert.doesNotMatch(shown, /CLAUDE\.md/);
});

// spec: N-000472 N-000473 N-000474
test('apply_patch payload: names several files; patch header parsing', () => {
  const cfg = freshConfig();
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'prosecheck-patch-'));
  const env = { CLAUDE_CONFIG_DIR: cfg };
  command('/prosecheck full', env);
  const f = path.join(work, 'draft.md');
  fs.writeFileSync(f, 'In today\'s fast-paced world, it\'s worth noting that our robust, seamless, and innovative solution is a testament to the power of collaboration. Additionally, the team will delve into the intricate landscape of modern tools. Furthermore, this comprehensive guide explores the multifaceted journey ahead.\n');
  const patch = '*** Begin Patch\n*** Update File: ' + f + '\n@@\n-x\n+y\n*** End Patch';
  const out = runHook('prosecheck-guard.js', { tool_name: 'apply_patch', tool_input: { command: patch }, session_id: 'p1' }, env);
  assert.strictEqual(out.status, 0);
  assert.match(out.stdout, /draft\.md/);
});

// spec: N-000975 N-000976 N-000977 N-000978 N-000979 N-000980 N-000981
test('check: missing path, directory, and binary replies', () => {
  const cfg = freshConfig();
  const env = { CLAUDE_CONFIG_DIR: cfg };
  const noPath = command('/prosecheck check', env).reason;
  assert.doesNotMatch(noPath, /unknown/i);
  const dir = command('/prosecheck check ' + os.tmpdir(), env).reason;
  assert.match(dir, /not a file/);
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'prosecheck-check-'));
  const pdf = path.join(work, 'doc.pdf');
  fs.writeFileSync(pdf, '%PDF-1.4');
  assert.match(command('/prosecheck check ' + pdf, env).reason, /no readable text/);
  const missing = command('/prosecheck check "' + path.join(work, 'nope.md') + '"', env).reason;
  assert.match(missing, /cannot read/);
});

// spec: N-000542 N-000543 N-000544 N-000547 N-000549 N-000551
test('stats: counts from the named transcript; missing transcript gives no counts', () => {
  const cfg = freshConfig();
  const env = { CLAUDE_CONFIG_DIR: cfg };
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'prosecheck-stats-'));
  const t = path.join(work, 't.jsonl');
  const rows = [
    { type: 'user', message: { content: 'hi' } },
    { type: 'assistant', message: { id: 'm1', usage: { output_tokens: 10, cache_read_input_tokens: 100 }, content: [{ type: 'text', text: 'Short reply.' }] } },
    { type: 'assistant', message: { id: 'm2', usage: { output_tokens: 5, cache_read_input_tokens: 50 }, content: [{ type: 'text', text: 'Another.' }] } },
  ];
  fs.writeFileSync(t, rows.map((r) => JSON.stringify(r)).join('\n') + '\n');
  const reply = command('/prosecheck stats', env, { transcript_path: t }).reason;
  assert.match(reply, /assistant turns: 2/);
  assert.match(reply, /output tokens: 15/);
  assert.match(reply, /cache-read input tokens: 150/);
  assert.match(reply, /level: full/);
  assert.doesNotMatch(reply, /session prose ai_tell_score/);
  const missing = command('/prosecheck stats', env, { transcript_path: path.join(work, 'nope.jsonl') }).reason;
  assert.doesNotMatch(missing, /assistant turns:/);
});

// spec: N-000529 N-000530 N-000531 N-000532 N-000533 N-000535 N-000536 N-000537 N-000538 N-000539 N-000540 N-001088 N-001089 N-001090 N-001091 N-001092 N-001093 N-001094 N-001095 N-001096 N-001085 N-001086 N-001087 N-001065 N-001066 N-001067 N-001068
test('init: writes AGENTS.md and cursor rule once; off writes nothing', () => {
  const cfg = freshConfig();
  const env = { CLAUDE_CONFIG_DIR: cfg };
  const cwd = fs.mkdtempSync(path.join(os.tmpdir(), 'prosecheck-init-'));
  fs.writeFileSync(path.join(cwd, 'AGENTS.md'), '# Project\n\nExisting notes.\n');
  const init = require(path.join(HOOKS, 'lib', 'commands.js'));
  const prevCwd = process.cwd();
  process.chdir(cwd);
  try {
    command('/prosecheck full', env);
    const reply1 = init.initReply('/prosecheck', 'full', cwd);
    assert.match(reply1, /AGENTS\.md/);
    const agents = fs.readFileSync(path.join(cwd, 'AGENTS.md'), 'utf8');
    assert.ok(agents.startsWith('# Project\n\nExisting notes.'));
    assert.strictEqual(agents.split('## prosecheck writing contract').length - 1, 1);
    assert.ok(fs.existsSync(path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc')));
    const reply2 = init.initReply('/prosecheck', 'full', cwd);
    assert.match(reply2, /already/);
    assert.match(reply2, /AGENTS\.md/);
    assert.ok(!agents.includes(os.homedir()));
    assert.ok(!agents.includes(os.userInfo().username) || os.userInfo().username.length < 3);
    assert.match(agents, /CLAUDE_PLUGIN_ROOT/);
  } finally {
    process.chdir(prevCwd);
  }
  const off = fs.mkdtempSync(path.join(os.tmpdir(), 'prosecheck-init-off-'));
  process.chdir(off);
  try {
    command('/prosecheck off', env);
    const reply = init.initReply('/prosecheck:prosecheck', 'off', off);
    assert.match(reply, /switched off/);
    assert.match(reply, /\/prosecheck:prosecheck on/);
    assert.ok(!fs.existsSync(path.join(off, 'AGENTS.md')));
  } finally {
    process.chdir(prevCwd);
  }
});

// spec: N-000704 N-000705 N-000570 N-000571
test('lite export names no detector path, no skills/plugins line, no full threshold', () => {
  const core = require(path.join(HOOKS, 'lib', 'core.js'));
  const lite = core.exportContract('lite');
  assert.doesNotMatch(lite, /CLAUDE_PLUGIN_ROOT|skills|plugins/);
  assert.doesNotMatch(lite, /\b40\b/);
  assert.doesNotMatch(lite, /light tells/);
  const full = core.exportContract('full');
  assert.match(full, /CLAUDE_PLUGIN_ROOT/);
  assert.match(full, /\bskills\b/);
  assert.match(full, /\bplugins\b/);
  assert.match(full, /\b40\b/);
  assert.doesNotMatch(full, /--clean/);
});

// spec: N-000802 N-000803 N-000804
test('writing contract: every banned word is standalone and source-code sentences say never/not', () => {
  const core = require(path.join(HOOKS, 'lib', 'core.js'));
  const body = core.writingContract('full', { detector: 'x' });
  for (const w of core.BANNED_WORDS) {
    assert.ok(new RegExp('(^|[^A-Za-z-])' + w.replace('-', '-') + '([^A-Za-z]|$)').test(body), 'banned word ' + w);
  }
  const sentences = body.split(/(?<=[.!?])\s+|\n+/);
  for (const s of sentences) {
    if (/source code/i.test(s)) assert.ok(/\b(never|not)\b/i.test(s), 'sentence: ' + s);
  }
});

// spec: N-000100 N-000101 N-000102 N-000103 N-000104
test('cursor rule: prose globs only; no detector step; no full threshold', () => {
  const rule = fs.readFileSync(path.join(ROOT, '.cursor', 'rules', 'prosecheck.mdc'), 'utf8');
  assert.match(rule, /globs: \*\.md, \*\.mdx, \*\.markdown, \*\.txt, \*\.rst, \*\.tex, \*\.org, \*\.adoc/);
  assert.doesNotMatch(rule, /\*\.py|\*\.js|\*\.ts|\*\.json/);
  assert.doesNotMatch(rule, /detect/i);
  assert.doesNotMatch(rule, /\b40\b/);
  assert.match(rule, /prose deliverables only/);
});
