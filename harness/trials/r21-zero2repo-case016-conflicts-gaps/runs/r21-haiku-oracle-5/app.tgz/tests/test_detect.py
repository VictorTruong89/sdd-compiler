"""Tests for scripts/detect.py. Run: python3 -m unittest discover -s tests -v

Test names carry the spec node ids they verify (checklist ids N-000xxx).
"""
import json
import os
import subprocess
import sys
import tempfile
import unittest
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DETECT = os.path.join(ROOT, "scripts", "detect.py")
sys.path.insert(0, os.path.join(ROOT, "scripts"))

import detect  # noqa: E402


def run(args, stdin=None):
    p = subprocess.run([sys.executable, DETECT] + args, input=stdin, capture_output=True)
    return p.returncode, p.stdout, p.stderr


def report_for_text(text):
    rc, out, err = run([], stdin=text.encode("utf-8"))
    assert rc == 0, err
    return json.loads(out.decode("utf-8"))


AI_SAMPLE = (
    "In today's fast-paced world, it's worth noting that our robust, seamless, and innovative solution "
    "is a testament to the power of collaboration. Additionally, the team will delve into the intricate "
    "landscape of modern tools. Furthermore, this comprehensive guide explores the multifaceted journey "
    "ahead, which underscores its importance. Moreover, we leverage holistic approaches to foster growth. "
    "However, the truth is, it's not just a tool, it's a movement. Let's dive in!\n\n"
    "In conclusion, the future looks bright. I hope this helps!\n"
)

HUMAN_SAMPLE = (
    "I replaced the pump last spring. The old one leaked from the seal, and I could see the drip under "
    "the bracket every morning. It was not a hard job, but the bolts were rusted, so I soaked them in "
    "penetrating oil overnight.\n\n"
    "The new unit came with a gasket that did not fit. I measured it against the old one and trimmed the "
    "edge with a utility knife. That worked, though I would not recommend it. Buy the right part.\n\n"
    "Coolant took about an hour to bleed. I ran the engine with the cap off until the thermostat opened, "
    "then topped up again. The temperature gauge sat at the midpoint all week.\n"
)


class CatalogueTests(unittest.TestCase):
    def test_N_000102_no_detector_numbers_never_appear(self):
        rep = report_for_text(AI_SAMPLE)
        for key in rep:
            if key == "_metrics":
                continue
            num = int(key.split("_", 1)[0])
            self.assertNotIn(num, {7, 9, 28, 29, 43, 45, 49, 52, 53})

    def test_N_000108_metrics_members_present(self):
        m = report_for_text(AI_SAMPLE)["_metrics"]
        for k in ("scanned_chars", "truncated", "ai_tell_score", "ai_tell_band", "confidence",
                  "confidence_reason", "patterns_flagged", "invisible_chars", "nonstandard_spaces",
                  "homoglyphs"):
            self.assertIn(k, m)

    def test_N_000115_band_ranges(self):
        self.assertEqual(detect.band_for(0), "clean")
        self.assertEqual(detect.band_for(20), "clean")
        self.assertEqual(detect.band_for(21), "light tells")
        self.assertEqual(detect.band_for(40), "light tells")
        self.assertEqual(detect.band_for(41), "mixed")
        self.assertEqual(detect.band_for(61), "heavy tells")
        self.assertEqual(detect.band_for(81), "pervasive tells")
        self.assertEqual(detect.band_for(100), "pervasive tells")

    def test_N_000116_writing_advice_never_moves_score(self):
        # em-dash overuse (58) is writing advice: weight zero.
        with_dash = "Plain sentence one — with dash. Plain two — dash here. Plain three.\n"
        without = "Plain sentence one, with dash. Plain two, dash here. Plain three.\n"
        a = report_for_text(with_dash)
        b = report_for_text(without)
        self.assertIn("58_em_dash_overuse", a)  # the advice finding is reported
        self.assertEqual(a["_metrics"]["ai_tell_score"], b["_metrics"]["ai_tell_score"])

    def test_N_000131_single_family_capped_at_40(self):
        rep = report_for_text("Reliable tools help. " * 30 + "\n")
        self.assertLessEqual(rep["_metrics"]["ai_tell_score"], 40)

    def test_N_000137_two_decisive_families_floor_65(self):
        text = "Here is a note.​ with zero width. I hope this helps! Let me know if you need more.\n"
        rep = report_for_text(text)
        self.assertGreaterEqual(rep["_metrics"]["ai_tell_score"], 45)

    def test_N_000145_confidence_bands(self):
        self.assertEqual(detect.confidence_for(10, 0)[0], "none")
        self.assertEqual(detect.confidence_for(60, 3)[0], "low")
        self.assertEqual(detect.confidence_for(200, 3)[0], "moderate")
        self.assertEqual(detect.confidence_for(400, 3)[0], "high")

    def test_N_000153_human_prose_scores_clean(self):
        rep = report_for_text(HUMAN_SAMPLE)
        self.assertEqual(rep["_metrics"]["ai_tell_band"], "clean")

    def test_ai_prose_flags_expected_families(self):
        rep = report_for_text(AI_SAMPLE)
        keys = [k for k in rep if k != "_metrics"]
        self.assertIn("1_ai_vocabulary", keys)
        self.assertIn("17_negative_parallelism", keys)
        self.assertIn("47_chatbot_artifacts", keys)

    def test_N_000759_label_unique_per_catalogue_number(self):
        labels = {}
        for num, label in detect.LABELS.items():
            self.assertNotIn(label, labels, msg="label reused for %s" % num)
            labels[label] = num

    def test_N_000744_17_keys_exact(self):
        text = "It's not just about speed, it's about trust.\n"
        rep = report_for_text(text)
        self.assertIn("17_negative_parallelism", rep)

    def test_N_000236_window_truncation(self):
        text = ("word " * 60000)  # 300,000 chars
        rep = report_for_text(text)
        m = rep["_metrics"]
        self.assertTrue(m["truncated"])
        self.assertEqual(m["scanned_chars"], 262144)

    def test_N_000240_character_past_window_not_a_finding(self):
        text = "a " * 140000 + "​"  # invisible char beyond 262,144 characters
        rep = report_for_text(text)
        self.assertEqual(rep["_metrics"]["invisible_chars"], 0)


class CleanupTests(unittest.TestCase):
    def test_N_000305_cleanup_removes_zero_width_then_rescan_clean(self):
        dirty = "Hello​world‌ again﻿.\n"
        rc, out, _ = run(["--clean"], stdin=dirty.encode("utf-8"))
        self.assertEqual(rc, 0)
        cleaned = out.decode("utf-8")
        self.assertNotIn("​", cleaned)
        rep = report_for_text(cleaned)
        self.assertEqual(rep["_metrics"]["invisible_chars"], 0)

    def test_N_000309_nbsp_between_digits_kept_other_spaces_normalized(self):
        text = "Total 1 000 and cost.\n"
        rc, out, _ = run(["--clean"], stdin=text.encode("utf-8"))
        cleaned = out.decode("utf-8")
        self.assertIn("1 000", cleaned)
        self.assertIn("and cost", cleaned)

    def test_N_000310_cleanup_folds_lookalike_latin(self):
        text = "The аpple is red.\n"  # Cyrillic a inside a Latin word
        rc, out, _ = run(["--clean"], stdin=text.encode("utf-8"))
        self.assertEqual(out.decode("utf-8"), "The apple is red.\n")

    def test_N_000330_trailing_whitespace_collapsed(self):
        rc, out, _ = run(["--clean"], stdin=b"line one  \nline two\t\n\n\n")
        self.assertEqual(out, b"line one\nline two\n")


class CliTests(unittest.TestCase):
    def test_N_000640_help_exit_zero_first_line(self):
        rc, out, _ = run(["--help"])
        self.assertEqual(rc, 0)
        self.assertEqual(out.decode("utf-8").splitlines()[0], "usage: detect.py [--clean] [--ci] [--] [FILE]")
        rc2, out2, _ = run(["-h"])
        self.assertEqual(rc2, 0)

    def test_N_000704_empty_input_exit_one(self):
        rc, out, err = run([], stdin=b"   \n\t\n")
        self.assertEqual(rc, 1)
        self.assertEqual(out, b"")
        self.assertEqual(json.loads(err.decode().strip().splitlines()[-1]), {"error": "empty input"})

    def test_N_000712_unknown_option_exit_two(self):
        rc, out, err = run(["--nope"], stdin=b"text")
        self.assertEqual(rc, 2)
        msg = json.loads(err.decode().strip().splitlines()[-1])["error"]
        self.assertIn("unknown option", msg)
        self.assertIn("--nope", msg)
        self.assertIn("--help", msg)

    def test_N_000708_unreadable_path(self):
        rc, out, err = run(["/nonexistent/file.md"])
        self.assertEqual(rc, 1)
        self.assertTrue(json.loads(err.decode().strip().splitlines()[-1])["error"].startswith("cannot read input:"))

    def test_N_000783_two_operands_first_scanned(self):
        with tempfile.TemporaryDirectory() as d:
            a = os.path.join(d, "a.md")
            b = os.path.join(d, "b.md")
            with open(a, "w") as f:
                f.write(HUMAN_SAMPLE)
            with open(b, "w") as f:
                f.write("Short.\n")
            rc, out, err = run([a, b])
            self.assertEqual(rc, 0)
            self.assertIn(a, err.decode())
            self.assertIn("_metrics", json.loads(out.decode()))

    def test_N_000738_dash_dash_allows_leading_dash_filename(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "-odd.md")
            with open(p, "w") as f:
                f.write(HUMAN_SAMPLE)
            rc, out, _ = run(["--", p])
            self.assertEqual(rc, 0)

    def test_N_000288_nonjson_notebook_is_empty(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "bad.ipynb")
            with open(p, "w") as f:
                f.write("{not json")
            rc, out, err = run([p])
            self.assertEqual(rc, 1)
            self.assertEqual(json.loads(err.decode().strip().splitlines()[-1]), {"error": "empty input"})

    def test_N_000286_bad_zip_is_cannot_read(self):
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "bad.docx")
            with open(p, "wb") as f:
                f.write(b"not a zip")
            rc, out, err = run([p])
            self.assertEqual(rc, 1)
            self.assertTrue(json.loads(err.decode().strip().splitlines()[-1])["error"].startswith("cannot read input:"))

    def test_N_000770_ci_present_only_with_flag(self):
        without = report_for_text(HUMAN_SAMPLE)["_metrics"]
        self.assertNotIn("score_ci", without)
        rc, out, _ = run(["--ci"], stdin=HUMAN_SAMPLE.encode("utf-8"))
        with_ci = json.loads(out.decode())["_metrics"]
        self.assertIn("score_ci", with_ci)
        lo, hi = with_ci["score_ci"]
        self.assertLessEqual(lo, hi)

    def test_N_000241_utf16_bom_decoded(self):
        data = "Hello there, a sentence.".encode("utf-16")
        rc, out, _ = run([], stdin=data)
        self.assertEqual(rc, 0)


class ExtractionTests(unittest.TestCase):
    def _zip(self, name, files):
        d = tempfile.mkdtemp()
        p = os.path.join(d, name)
        with zipfile.ZipFile(p, "w") as zf:
            for k, v in files.items():
                zf.writestr(k, v)
        return p

    def test_N_000256_docx_visible_text_only(self):
        p = self._zip("a.docx", {"word/document.xml":
                                 '<w:document xmlns:w="x"><w:body><w:p><w:r><w:t>First &amp; line.</w:t></w:r></w:p>'
                                 '<w:p><w:r><w:t>Second.</w:t></w:r></w:p></w:body></w:document>'})
        rc, out, _ = run(["--clean", p])
        self.assertEqual(out.decode(), "First & line.\nSecond.")

    def test_N_000271_ipynb_only_markdown_cells(self):
        d = tempfile.mkdtemp()
        p = os.path.join(d, "n.ipynb")
        with open(p, "w") as f:
            json.dump({"cells": [{"cell_type": "markdown", "source": ["# Title\n", "Body text."]},
                                 {"cell_type": "code", "source": "print('code')"}]}, f)
        rc, out, _ = run(["--clean", p])
        self.assertEqual(out.decode(), "# Title\nBody text.")

    def test_N_000282_pdf_is_no_text(self):
        d = tempfile.mkdtemp()
        p = os.path.join(d, "x.pdf")
        with open(p, "wb") as f:
            f.write(b"%PDF-1.4 stuff")
        rc, out, err = run([p])
        self.assertEqual(rc, 1)


if __name__ == "__main__":
    unittest.main()
