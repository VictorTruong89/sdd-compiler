#!/usr/bin/env python3
"""prosecheck detector: local, standard-library-only AI-writing pattern scanner."""
import sys
import os
import re
import json
import math
import zipfile
import unicodedata
from collections import Counter

WINDOW = 262144
USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Scores prose for AI-writing patterns (0-100) and prints a JSON report.
  --clean   print scrubbed text (invisible characters, odd spaces, lookalikes) instead of a report
  --ci      add a resampled low/high interval on the score
  --        stop option parsing so FILE may begin with a dash
  FILE      one file operand; with none, text is read from standard input
"""

PLAIN_EXT = {'.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'}
ZIP_EXT = {'.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub'}
NB_EXT = {'.ipynb'}
MEMBER_CAP = 64 * 1024 * 1024


class InputError(Exception):
    pass


# ----------------------------------------------------------------- extraction

def decode_bytes(b):
    if b.startswith(b'\xff\xfe') or b.startswith(b'\xfe\xff'):
        try:
            return b.decode('utf-16', errors='replace')
        except Exception:
            pass
    if b.startswith(b'\xef\xbb\xbf'):
        b = b[3:]
    t = b.decode('utf-8', errors='replace')
    if t.startswith('﻿'):
        t = t[1:]
    return t


def _local(tag):
    if '}' in tag:
        tag = tag.rsplit('}', 1)[1]
    if ':' in tag:
        tag = tag.rsplit(':', 1)[1]
    return tag


def _read_member(z, name):
    info = z.getinfo(name)
    if info.file_size > MEMBER_CAP:
        return None
    return z.read(name)


def _parse_xml(data):
    import xml.etree.ElementTree as ET
    try:
        return ET.fromstring(data)
    except Exception:
        return None


def _natkey(s):
    return [int(p) if p.isdigit() else p for p in re.split(r'(\d+)', s)]


def _para_texts(root, ptag, ttags, tabtag=None, brtag=None):
    out = []
    for p in root.iter():
        if _local(p.tag) != ptag:
            continue
        parts = []
        for e in p.iter():
            n = _local(e.tag)
            if n in ttags:
                parts.append(e.text or '')
            elif tabtag and n == tabtag:
                parts.append('\t')
            elif brtag and n == brtag:
                parts.append('\n')
        out.append(''.join(parts))
    return out


def extract_docx(z):
    names = z.namelist()
    main = 'word/document.xml'
    if main not in names:
        cands = [n for n in names if n.startswith('word/document') and n.endswith('.xml')]
        if not cands:
            return ''
        main = cands[0]
    data = _read_member(z, main)
    root = _parse_xml(data) if data else None
    if root is None:
        return ''
    paras = _para_texts(root, 'p', {'t'}, 'tab', 'br')
    return '\n'.join(p for p in paras if p.strip())


def extract_pptx(z):
    names = [n for n in z.namelist() if re.match(r'ppt/slides/slide\d+\.xml$', n)]
    names.sort(key=_natkey)
    out = []
    for n in names:
        data = _read_member(z, n)
        root = _parse_xml(data) if data else None
        if root is None:
            continue
        paras = [p for p in _para_texts(root, 'p', {'t'}, None, 'br') if p.strip()]
        if paras:
            out.append('\n'.join(paras))
    return '\n'.join(out)


def extract_xlsx(z):
    names = z.namelist()
    sst = []
    if 'xl/sharedStrings.xml' in names:
        data = _read_member(z, 'xl/sharedStrings.xml')
        root = _parse_xml(data) if data else None
        if root is not None:
            for si in root:
                if _local(si.tag) != 'si':
                    continue
                parts = []

                def walk(e):
                    for c in e:
                        n = _local(c.tag)
                        if n in ('rPh', 'phoneticPr'):
                            continue
                        if n == 't':
                            parts.append(c.text or '')
                        else:
                            walk(c)
                walk(si)
                sst.append(''.join(parts))
    order = None
    sheets = [n for n in names if re.match(r'xl/worksheets/[^/]+\.xml$', n)]
    sheets.sort(key=_natkey)
    out = []
    for n in sheets:
        data = _read_member(z, n)
        root = _parse_xml(data) if data else None
        if root is None:
            continue
        cells = []
        for c in root.iter():
            if _local(c.tag) != 'c':
                continue
            t = c.get('t')
            text = None
            if t == 's':
                v = None
                for ch in c:
                    if _local(ch.tag) == 'v':
                        v = (ch.text or '').strip()
                if v is not None and re.fullmatch(r'[0-9]+', v):
                    i = int(v)
                    if i < len(sst):
                        text = sst[i]
            elif t == 'inlineStr':
                parts = []
                for e in c.iter():
                    if _local(e.tag) == 't':
                        parts.append(e.text or '')
                text = ''.join(parts)
            elif t == 'str':
                for ch in c:
                    if _local(ch.tag) == 'v':
                        text = ch.text or ''
            if text is not None and text.strip():
                cells.append(text)
        if cells:
            out.append('\n'.join(cells))
    return '\n'.join(out)


def extract_odf(z):
    if 'content.xml' not in z.namelist():
        return ''
    data = _read_member(z, 'content.xml')
    root = _parse_xml(data) if data else None
    if root is None:
        return ''
    out = []

    def inline(e, buf):
        if e.text:
            buf.append(e.text)
        for c in e:
            n = _local(c.tag)
            if n == 's':
                try:
                    k = int(c.get('{urn:oasis:names:tc:opendocument:xmlns:text:1.0}c') or c.get('c') or 1)
                except Exception:
                    k = 1
                buf.append(' ' * max(1, min(k, 1000)))
            elif n == 'tab':
                buf.append('\t')
            elif n == 'line-break':
                buf.append('\n')
            elif n in ('note', 'annotation'):
                pass
            else:
                inline(c, buf)
            if c.tail:
                buf.append(c.tail)

    def walk(e):
        for c in e:
            n = _local(c.tag)
            if n in ('p', 'h'):
                buf = []
                inline(c, buf)
                s = ''.join(buf)
                if s.strip():
                    out.append(s)
            else:
                walk(c)
    walk(root)
    return '\n'.join(out)


class _HTMLText:
    pass


def extract_html(raw):
    from html.parser import HTMLParser
    blocks = {'p', 'div', 'br', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'li', 'tr', 'blockquote',
              'section', 'article', 'pre', 'ul', 'ol', 'table', 'dd', 'dt', 'figure', 'figcaption', 'hr', 'td', 'th'}
    skip = {'script', 'style', 'nav', 'head', 'title'}

    class P(HTMLParser):
        def __init__(self):
            super().__init__(convert_charrefs=True)
            self.buf = []
            self.depth = 0
            self.stack = []

        def handle_starttag(self, tag, attrs):
            tag = tag.lower()
            if tag in skip:
                self.depth += 1
                self.stack.append(tag)
            if tag in blocks:
                self.buf.append('\n')

        def handle_startendtag(self, tag, attrs):
            if tag.lower() in blocks:
                self.buf.append('\n')

        def handle_endtag(self, tag):
            tag = tag.lower()
            if tag in skip and tag in self.stack:
                while self.stack:
                    t = self.stack.pop()
                    self.depth -= 1
                    if t == tag:
                        break
            if tag in blocks:
                self.buf.append('\n')

        def handle_data(self, data):
            if self.depth == 0:
                self.buf.append(data)
    p = P()
    try:
        p.feed(raw)
        p.close()
    except Exception:
        pass
    text = ''.join(p.buf)
    lines = [re.sub(r'[ \t\r\f\v]+', ' ', ln).strip() for ln in text.split('\n')]
    return '\n'.join(ln for ln in lines if ln)


def extract_epub(z):
    names = z.namelist()
    html_names = [n for n in names if re.search(r'\.(?:xhtml|html|htm)$', n, re.I)]
    order = []
    try:
        if 'META-INF/container.xml' in names:
            root = _parse_xml(z.read('META-INF/container.xml'))
            opf = None
            if root is not None:
                for e in root.iter():
                    if _local(e.tag) == 'rootfile':
                        opf = e.get('full-path')
                        break
            if opf and opf in names:
                r2 = _parse_xml(z.read(opf))
                manifest = {}
                spine = []
                if r2 is not None:
                    for e in r2.iter():
                        n = _local(e.tag)
                        if n == 'item':
                            manifest[e.get('id')] = e.get('href')
                        elif n == 'itemref':
                            spine.append(e.get('idref'))
                    base = opf.rsplit('/', 1)[0] + '/' if '/' in opf else ''
                    from urllib.parse import unquote
                    for idr in spine:
                        h = manifest.get(idr)
                        if h:
                            full = unquote(base + h)
                            full = os.path.normpath(full).replace('\\', '/')
                            if full in names and full not in order:
                                order.append(full)
    except Exception:
        order = []
    rest = sorted([n for n in html_names if n not in order], key=_natkey)
    out = []
    for n in order + rest:
        if n not in html_names:
            continue
        data = _read_member(z, n)
        if not data:
            continue
        t = extract_html(decode_bytes(data))
        if t.strip():
            out.append(t)
    return '\n'.join(out)


def extract_ipynb(b):
    try:
        nb = json.loads(decode_bytes(b))
    except Exception:
        return ''
    if not isinstance(nb, dict):
        return ''
    cells = nb.get('cells')
    if not isinstance(cells, list):
        return ''
    out = []
    for c in cells:
        if not isinstance(c, dict) or c.get('cell_type') != 'markdown':
            continue
        s = c.get('source')
        if isinstance(s, str):
            t = s
        elif isinstance(s, list) and all(isinstance(x, str) for x in s):
            t = ''.join(s)
        else:
            continue
        if t.strip():
            out.append(t.strip())
    return '\n\n'.join(out)


def load_file(path):
    ext = os.path.splitext(path)[1].lower()
    try:
        with open(path, 'rb') as f:
            b = f.read()
    except Exception as e:
        raise InputError('cannot read input: %s' % (getattr(e, 'strerror', None) or e))
    if ext in ZIP_EXT:
        try:
            z = zipfile.ZipFile(path)
        except Exception as e:
            raise InputError('cannot read input: not a readable zip archive (%s)' % path)
        try:
            with z:
                try:
                    if ext in ('.docx', '.docm'):
                        t = extract_docx(z)
                    elif ext in ('.pptx', '.pptm'):
                        t = extract_pptx(z)
                    elif ext in ('.xlsx', '.xlsm'):
                        t = extract_xlsx(z)
                    elif ext == '.epub':
                        t = extract_epub(z)
                    else:
                        t = extract_odf(z)
                except zipfile.BadZipFile:
                    raise InputError('cannot read input: not a readable zip archive (%s)' % path)
                except InputError:
                    raise
                except Exception:
                    t = ''
        except InputError:
            raise
        return t.strip()
    if ext in NB_EXT:
        return extract_ipynb(b).strip()
    if ext in ('.pdf', '.rtf'):
        return ''
    return decode_bytes(b)


# ------------------------------------------------------------- character layer

TAG_LO, TAG_HI = 0xE0000, 0xE0FFF


def _in(c, ranges):
    o = ord(c)
    for lo, hi in ranges:
        if lo <= o <= hi:
            return True
    return False


NOSPACE_SCRIPTS = [(0x0E00, 0x0EFF), (0x1780, 0x17FF), (0x19E0, 0x19FF), (0x1000, 0x109F),
                   (0x3040, 0x30FF), (0x31F0, 0x31FF), (0x3400, 0x4DBF), (0x4E00, 0x9FFF),
                   (0xF900, 0xFAFF), (0x20000, 0x2FFFF), (0x3005, 0x3007), (0xFF66, 0xFF9F)]
CJK = [(0x3400, 0x4DBF), (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0x20000, 0x2FFFF), (0x3005, 0x3007), (0x2E80, 0x2FDF)]
RTL = [(0x0590, 0x08FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF), (0x10800, 0x10FFF), (0x1E800, 0x1EFFF)]
JOINING = [(0x0590, 0x06FF), (0x0700, 0x077F), (0x08A0, 0x08FF), (0xFB1D, 0xFDFF), (0x0900, 0x0DFF),
           (0x1000, 0x109F), (0x1780, 0x17FF)]
KHMER = [(0x1780, 0x17FF), (0x19E0, 0x19FF)]
MONGOLIAN = [(0x1800, 0x18AF)]
EMOJI = [(0x1F000, 0x1FAFF), (0x2600, 0x27BF), (0x2B00, 0x2BFF), (0x2190, 0x21FF), (0x2300, 0x23FF), (0x25A0, 0x25FF), (0x2100, 0x214F)]
BIDI = set([0x200E, 0x200F, 0x061C, 0x202A, 0x202B, 0x202C, 0x202D, 0x202E, 0x2066, 0x2067, 0x2068, 0x2069])


def _base_invisible(o, c):
    if o in (9, 10, 13):
        return False
    if o < 32 or 0x7F <= o <= 0x9F:
        return True
    if o in (0x00AD, 0x034F, 0x061C, 0x115F, 0x1160, 0x17B4, 0x17B5, 0x3164, 0xFFA0, 0xFEFF):
        return True
    if 0x180B <= o <= 0x180F:
        return True
    if 0x200B <= o <= 0x200F or 0x202A <= o <= 0x202E or 0x2060 <= o <= 0x206F:
        return True
    if 0xFE00 <= o <= 0xFE0F or 0xE0100 <= o <= 0xE01EF:
        return True
    if TAG_LO <= o <= TAG_HI:
        return True
    if 0xFFF0 <= o <= 0xFFFB:
        return True
    if 0x1D173 <= o <= 0x1D17A or 0x1BCA0 <= o <= 0x1BCA3:
        return True
    if o < 0x80:
        return False
    if unicodedata.category(c) == 'Cf':
        return True
    return False


def _is_symbolish(c):
    if c is None:
        return False
    if _in(c, EMOJI):
        return True
    return unicodedata.category(c).startswith('S')


def invisible_removals(t):
    """Return set of indices that cleanup removes (and detection counts)."""
    n = len(t)
    cand = []
    has_rtl = None
    for i, c in enumerate(t):
        o = ord(c)
        if o >= 0x80 or o < 32 or o == 0x7F:
            if _base_invisible(o, c):
                cand.append(i)
    if not cand:
        return set()
    removed = set()
    kept_tags = set()
    # emoji tag sequences
    i = 0
    cl = set(cand)
    for i in cand:
        o = ord(t[i])
        if TAG_LO <= o <= TAG_HI and i not in kept_tags:
            # find run start
            s = i
            while s - 1 >= 0 and TAG_LO <= ord(t[s - 1]) <= TAG_HI:
                s -= 1
            e = i
            while e + 1 < n and TAG_LO <= ord(t[e + 1]) <= TAG_HI:
                e += 1
            if s > 0 and t[s - 1] == '\U0001F3F4' and ord(t[e]) == 0xE007F:
                for k in range(s, e + 1):
                    kept_tags.add(k)
    for i in cand:
        c = t[i]
        o = ord(c)
        prev = t[i - 1] if i > 0 else None
        nxt = t[i + 1] if i + 1 < n else None
        keep = False
        if TAG_LO <= o <= TAG_HI:
            keep = i in kept_tags
        elif 0xE0100 <= o <= 0xE01EF:
            keep = prev is not None and _in(prev, CJK)
        elif 0xFE00 <= o <= 0xFE0F:
            keep = (prev is not None and (_is_symbolish(prev) or _in(prev, CJK))) or nxt == '⃣'
        elif o == 0x200B:
            keep = (prev is not None and _in(prev, NOSPACE_SCRIPTS)) or (nxt is not None and _in(nxt, NOSPACE_SCRIPTS))
        elif o == 0x00AD:
            keep = prev is not None and nxt is not None and prev.isalpha() and nxt.isalpha()
        elif o in BIDI:
            if has_rtl is None:
                has_rtl = any(_in(ch, RTL) for ch in t if ord(ch) >= 0x0590)
            keep = has_rtl
        elif 0x180B <= o <= 0x180F:
            keep = prev is not None and _in(prev, MONGOLIAN) and o != 0x180E or (o == 0x180E and prev is not None and _in(prev, MONGOLIAN))
        elif o in (0x17B4, 0x17B5):
            keep = (prev is not None and _in(prev, KHMER)) or (nxt is not None and _in(nxt, KHMER))
        elif o in (0x200C, 0x200D):
            for nb in (prev, nxt):
                if nb is None:
                    continue
                if (_in(nb, JOINING) and nb.isalpha()) or _is_symbolish(nb):
                    keep = True
        if not keep:
            removed.add(i)
    return removed


def _nbsp_kept(t, i):
    prev = t[i - 1] if i > 0 else ''
    nxt = t[i + 1] if i + 1 < len(t) else ''
    if prev.isdigit() or nxt.isdigit():
        return True
    if nxt and nxt in ':;!?»›%€':
        return True
    if prev and prev in '«‹':
        return True
    return False


def space_normalizations(t):
    """Dict index -> replacement for non-standard spaces cleanup normalizes."""
    res = {}
    for i, c in enumerate(t):
        o = ord(c)
        if o < 0xA0 and o != 0x85:
            continue
        if o in (0x2028, 0x2029):
            res[i] = '\n'
            continue
        if unicodedata.category(c) == 'Zs' and c != ' ':
            if o in (0xA0, 0x202F) and _nbsp_kept(t, i):
                continue
            res[i] = ' '
    return res


LOOK = {}
for _pairs in [
    # cyrillic lower
    ('а', 'a'), ('с', 'c'), ('е', 'e'), ('о', 'o'), ('р', 'p'), ('х', 'x'),
    ('у', 'y'), ('і', 'i'), ('ј', 'j'), ('ѕ', 's'), ('ԁ', 'd'), ('һ', 'h'),
    ('ԝ', 'w'), ('ѵ', 'v'), ('ԍ', 'g'), ('ո', 'n'),
    # cyrillic upper
    ('А', 'A'), ('В', 'B'), ('С', 'C'), ('Е', 'E'), ('Н', 'H'), ('І', 'I'),
    ('Ј', 'J'), ('К', 'K'), ('М', 'M'), ('О', 'O'), ('Р', 'P'), ('Ѕ', 'S'),
    ('Т', 'T'), ('Х', 'X'), ('Ү', 'Y'),
    # greek
    ('ο', 'o'), ('ν', 'v'), ('ι', 'i'), ('υ', 'u'), ('α', 'a'), ('ρ', 'p'),
    ('Α', 'A'), ('Β', 'B'), ('Ε', 'E'), ('Ζ', 'Z'), ('Η', 'H'), ('Ι', 'I'),
    ('Κ', 'K'), ('Μ', 'M'), ('Ν', 'N'), ('Ο', 'O'), ('Ρ', 'P'), ('Τ', 'T'),
    ('Υ', 'Y'), ('Χ', 'X'),
    # armenian
    ('օ', 'o'), ('ս', 'u'), ('հ', 'h'), ('ց', 'g'), ('Օ', 'O'), ('Ս', 'U'),
    # arabic presentation lookalikes
    ('ه', 'o'), ('ﻩ', 'o'), ('ﻪ', 'o'), ('ﻫ', 'o'), ('ﻬ', 'o'),
]:
    LOOK[_pairs[0]] = _pairs[1]


def homoglyph_spans(t):
    """Yield (start,end,run) of letter runs with mixed ASCII + lookalike letters only."""
    res = []
    for m in re.finditer(r'\S+', t):
        tok = m.group()
        if tok.isascii():
            continue
        i = 0
        L = len(tok)
        base = m.start()
        while i < L:
            if tok[i].isalpha():
                j = i
                while j < L and (tok[j].isalpha() or unicodedata.category(tok[j]) in ('Mn', 'Mc')):
                    j += 1
                run = tok[i:j]
                if not run.isascii():
                    has_ascii = False
                    has_look = False
                    other = False
                    for ch in run:
                        if ch.isascii():
                            if ch.isalpha():
                                has_ascii = True
                        elif ch in LOOK:
                            has_look = True
                        elif ch.isalpha():
                            other = True
                        else:
                            other = True
                    if has_ascii and has_look and not other:
                        res.append((base + i, base + j))
                i = j
            else:
                i += 1
    return res


def scrub(t):
    rem = invisible_removals(t)
    sp = space_normalizations(t)
    # fold homoglyphs on text after removals/space normalization positions
    out = []
    for i, c in enumerate(t):
        if i in rem:
            continue
        if i in sp:
            out.append(sp[i])
        else:
            out.append(c)
    s = ''.join(out)
    return s


def fold_homoglyphs(s):
    spans = homoglyph_spans(s)
    if not spans:
        return s
    chars = list(s)
    for a, b in spans:
        for k in range(a, b):
            if chars[k] in LOOK:
                chars[k] = LOOK[chars[k]]
    return ''.join(chars)


def clean_text(text):
    s = fold_homoglyphs(scrub(text))
    ended_lf = s.endswith('\n')
    lines = s.split('\n')
    res = []
    for ln in lines:
        if ln.endswith('\r'):
            ln = ln[:-1].rstrip(' \t') + '\r'
        else:
            ln = ln.rstrip(' \t')
        res.append(ln)
    while res and res[0].strip(' \t\r') == '':
        res.pop(0)
    out = '\n'.join(res)
    out = out.rstrip()
    if ended_lf and out:
        out += '\n'
    return out


def trailing_ws_count(raw):
    t = raw.replace('\r\n', '\n').replace('\r', '\n')
    n = 0
    if t and t[0].isspace():
        n += 1
    lines = t.split('\n')
    for i, ln in enumerate(lines):
        if ln != ln.rstrip(' \t'):
            n += 1
    if t.endswith('\n\n'):
        n += 1
    return n


# ----------------------------------------------------------------- masking

def mask_markdown(t):
    lines = t.split('\n')
    N = len(lines)
    masked = [False] * N
    # front matter
    if N and lines[0].strip() == '---':
        for j in range(1, N):
            if lines[j].strip() in ('---', '...'):
                for k in range(0, j + 1):
                    masked[k] = True
                break
    # fences
    i = 0
    fence_re = re.compile(r'^( {0,3})(`{3,}|~{3,})(.*)$')
    while i < N:
        if masked[i]:
            i += 1
            continue
        m = fence_re.match(lines[i])
        if m and not (m.group(2)[0] == '`' and '`' in m.group(3)):
            ch = m.group(2)[0]
            ln = len(m.group(2))
            masked[i] = True
            j = i + 1
            close = re.compile(r'^ {0,3}' + re.escape(ch) + '{' + str(ln) + r',}[ \t]*$')
            while j < N:
                masked[j] = True
                if close.match(lines[j]):
                    break
                j += 1
            i = j + 1
        else:
            i += 1
    # blockquote runs
    i = 0
    while i < N:
        if not masked[i] and re.match(r'^ {0,3}>', lines[i]):
            j = i
            while j + 1 < N and not masked[j + 1] and re.match(r'^ {0,3}>', lines[j + 1]):
                j += 1
            if j > i:
                for k in range(i, j + 1):
                    masked[k] = True
            i = j + 1
        else:
            i += 1
    # tables
    delim = re.compile(r'^\|?\s*:?-{1,}:?\s*(\|\s*:?-{1,}:?\s*)+\|?$')
    for i in range(N):
        if masked[i]:
            continue
        s = lines[i].strip()
        if s.startswith('|') and s.count('|') >= 2:
            masked[i] = True
        elif '|' in s and delim.match(s):
            masked[i] = True
            if i > 0 and not masked[i - 1] and '|' in lines[i - 1]:
                masked[i - 1] = True
            j = i + 1
            while j < N and lines[j].strip() and '|' in lines[j] and not masked[j]:
                masked[j] = True
                j += 1
    badge = re.compile(r'^(?:\[!\[[^\]\n]*\]\([^)\n]*\)\]\([^)\n]*\)\s*)+$')
    for i in range(N):
        if not masked[i] and badge.match(lines[i].strip()):
            masked[i] = True
    out = [' ' * len(lines[i]) if masked[i] else lines[i] for i in range(N)]
    m = '\n'.join(out)
    m = re.sub(r'(?<!`)(`+)(?!`)(.{1,500}?)(?<!`)\1(?!`)', lambda x: ' ' * len(x.group()), m)
    return m, masked


# ---------------------------------------------------------------- lexicon

def forms(w):
    if w.endswith('e'):
        f = [w, w + 's', w + 'd', w[:-1] + 'ing']
    elif w.endswith('y') and len(w) > 2 and w[-2] not in 'aeiou':
        f = [w, w[:-1] + 'ies', w[:-1] + 'ied', w + 's', w + 'ing']
    else:
        f = [w, w + 's', w + 'es', w + 'ed', w + 'ing', w + w[-1] + 'ed', w + w[-1] + 'ing']
    return f


def alt(words):
    return '|'.join(sorted(set(words), key=lambda x: -len(x)))


A = "['’]"
I = re.I

AI_WORDS = ['additionally', 'crucial', 'delve', 'tapestry', 'pivotal', 'vibrant', 'meticulous', 'testament',
            'underscore', 'intricate', 'intricacy', 'interplay', 'garner', 'bolster', 'foster', 'showcase',
            'emphasize', 'emphasise', 'enduring', 'enhance', 'leverage', 'utilize', 'utilise', 'facilitate',
            'encompass', 'harness', 'holistic', 'paradigm', 'transformative', 'unprecedented', 'myriad',
            'plethora', 'robust', 'seamless', 'navigate', 'embark', 'craft', 'landscape', 'journey', 'realm',
            'multifaceted', 'elevate', 'empower', 'unlock']
_ai = []
for w in AI_WORDS:
    _ai.extend(forms(w))
_ai.extend(['intricacies', 'harnesses', 'tapestries'])
RE_AI = re.compile(r'\b(?:' + alt(_ai) + r'|align(?:s|ed|ing)?\s+with|captur(?:e|es|ed|ing)\s+the\s+(?:essence|spirit|imagination|heart|magic))\b', I)

_dial = []
for w in ['supercharge', 'skyrocket', 'turbocharge', 'revolutionize', 'revolutionise']:
    _dial.extend(forms(w))
RE_DIALECT = re.compile(
    r'\b(?:genuinely|fascinating|nuanced|thoughtfully|refreshingly|strikingly|compellingly'
    r'|quietly\s+(?:powerful|profound|radical)|deeply\s+(?:human|personal|felt|unsettling)|resonat(?:e|es|ed|ing)\s+deeply'
    r'|game[- ]chang(?:er|ers|ing)|' + alt(_dial) + r'|doubl(?:e|es|ed|ing)\s+down\s+on|div(?:e|es|ed|ing)\s+deeper?\s+into'
    r'|unlock(?:s|ed|ing)?\s+(?:the\s+)?(?:power|potential|value)'
    r'|tak(?:e|es|ing|en)\b[^.!?\n]{0,40}?\bto\s+the\s+next\s+level)\b', I)

PROMO = ['nestled', 'breathtaking', 'must-visit', 'stunning', 'picturesque', 'charming', 'idyllic', 'vibrant community',
         'rich cultural heritage', 'in the heart of', 'world-class', 'top-tier', 'unparalleled', 'premier', 'leading',
         'esteemed organi[sz]ation', 'valuable asset', 'passion for excellence', 'proven track record',
         'results-oriented', 'wealth of experience', 'dynamic team', 'fast-paced environment', 'deeply passionate',
         'perfectly situated', '(?:close|tight)-knit team', 'I am excited to (?:apply|bring)', 'uniquely positioned to']
RE_PROMO = re.compile(r'\b(?:' + '|'.join(PROMO) + r')\b', I)
IMPER = ['install', 'join', 'grab', 'download', 'try', 'discover', 'experience', 'escape', 'transform', 'reclaim', 'unlock',
         'elevate', 'boost', 'say', 'imagine', 'explore', 'meet', 'introducing', 'upgrade', 'claim', 'unleash',
         'supercharge', 'level', 'stop', 'start']
RE_IMPER = re.compile(r'(?:^|(?<=[.!?])[ \t]+|(?<=\n))[ \t]*(?:' + '|'.join(IMPER) + r')\b', I)

STOCK_ADJ = ['innovative', 'powerful', 'modern', 'reliable', 'scalable', 'secure', 'flexible', 'dynamic', 'seamless',
             'robust', 'cutting-edge', 'user-friendly', 'intuitive', 'stunning', 'beautiful', 'elegant', 'sleek',
             'comprehensive', 'efficient', 'effective', 'vibrant', 'rich', 'unique', 'fast', 'simple', 'easy', 'clean',
             'engaging', 'impactful', 'versatile', 'dedicated', 'passionate', 'creative', 'strategic', 'bold']
ADJ_SUFFIX = re.compile(r'(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$', I)
RE_CHAIN = re.compile(r"(?<![\w,])((?:[A-Za-z][A-Za-z-]*,\s+){2,}(?:and\s+)?[A-Za-z][A-Za-z-]*,?\s+[A-Za-z][A-Za-z-]*)")

SYN = [
    ['protagonist', 'main character', 'central figure', 'hero', 'heroine'],
    ['company', 'firm', 'organization', 'organisation', 'enterprise', 'business'],
    ['author', 'writer', 'novelist', 'scribe'],
    ['report', 'study', 'analysis', 'investigation', 'examination'],
    ['technology', 'tool', 'system', 'platform', 'solution'],
    ['technique', 'method', 'approach', 'strategy', 'tactic'],
    ['challenge', 'obstacle', 'difficulty', 'hurdle', 'barrier'],
    ['benefit', 'advantage', 'upside', 'strength'],
]


def _plural(w):
    ws = w.split(' ')
    last = ws[-1]
    if last.endswith('y'):
        p = last[:-1] + 'ies'
    elif last.endswith(('s', 'sh', 'ch', 'x')):
        p = last + 'es'
    else:
        p = last + 's'
    return ' '.join(ws[:-1] + [p])


SYN_RE = []
for cl in SYN:
    allf = []
    for w in cl:
        allf += [w, _plural(w)]
    SYN_RE.append(re.compile(r'\b(' + alt(allf).replace(' ', r'\s+') + r')\b', I))

RE_ADV = []  # placeholder


def R(p, flags=I):
    return re.compile(p, flags)


F = {}  # key -> list of regex

F['3_x'] = None
RE_SIMPLEYET = R(r'\bsimple\s+yet\s+(?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b')
RE_SIGINF = R(
    r'\b(?:stand(?:s|ing)?|stood|serv(?:e|es|ed|ing))\s+as\s+(?:a|an|the)\s+(?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b'
    r'|\b(?:underscor(?:e|es|ed|ing)|highlight(?:s|ed|ing)?)\s+(?:its|the|their|his|her)\s+(?:enduring|importance|significance|central|vital|crucial|pivotal|key)\b'
    r'|\breflect(?:s|ed|ing)?\s+a\s+broader\s+(?:trend|shift|pattern)\b'
    r'|\bmark(?:s|ed|ing)?\s+a\s+(?:turning\s+point|milestone|watershed|new\s+chapter|new\s+era)\b'
    r'|\bsymboli[sz](?:es|ed|ing)\b|\bsets?\s+the\s+stage\s+for\b|\bleft\s+an\s+indelible\s+mark\b'
    r'|\bplay(?:s|ed|ing)?\s+a\s+(?:crucial|pivotal|vital|key|central|significant)\s+role\b'
    r'|\bhas\s+(?:shaped|sparked)\b|\bhas\s+come\s+to\s+(?:define|symbolize|symbolise)\b')
RE_VAGUE = R(r'\bexperts\s+(?:argue|believe|say|claim|note|suggest)\b|\bindustry\s+(?:reports|observers|analysts)\b'
             r'|\bobservers\s+have\s+(?:cited|noted)\b|\bsome\s+critics\s+argue\b|\bresearchers\s+have\s+found\b'
             r'|\bstudies\s+suggest\b|\bit\s+is\s+widely\s+believed\b')
RE_TITLE13 = re.compile(r'\bThe\s+(?:List|Index|Compilation|Collection|Catalogue|Guide|Overview)\s+of\s+[A-Z][^.\n]{0,80}?\s+(?:is|are)\s+(?:a|an|the)\b')
RE_CONSERV = R(r'\bplays?\s+a\s+(?:vital|crucial|key|significant)\s+role\s+in\s+(?:its|the)\s+ecosystem\b'
               r'|\bconservation\s+efforts\s+are\s+(?:underway|ongoing|in\s+place)\b|\bserves?\s+as\s+an\s+indicator\s+species\b'
               r'|\bcontributes?\s+to\s+biodiversity\b')
RE_FALSERANGE = R(r'\bfrom\s+(?:the\s+)?(?:dawn|birth|earliest\s+days|inception|advent|emergence|humble)\b[^.!?\n]{0,120}?\bto\s+(?:the\s+)?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering|grand|sprawling)\b')
ING = 'highlighting|reflecting|symbolizing|symbolising|emphasizing|emphasising|underscoring|showcasing|fostering|cultivating|encompassing|signaling|signalling|demonstrating|illustrating|representing|suggesting|indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing|epitomising'
RE_ING = R(r',\s+(?:' + ING + r')\b')
RE_NOTX = R(r'\b(?:no|not)\s+\w+,\s+(?:just|only|simply)\s+\w+'
            r'|\b(?:not|isn' + A + r't|aren' + A + r't|wasn' + A + r't|weren' + A + r't)\s+(?:just|merely)\s+(?:(?:a|an|the)\s+)?\w+\s*(?:,|—|–|--|\s-\s)\s*(?:it' + A + r's|it\s+is|it\s+was|they' + A + r're|they\s+are|they\s+were|that' + A + r's|but)\b')
RE_PAR17 = R(r'\bit' + A + r's\s+not\s+(?:just|merely)\s+(?:about|an?)\b|\bnot\s+only\b[^.!?\n]{0,40}?\bbut\b'
             r'|\bdoesn' + A + r't\s+just\b[^,.\n]{0,40}?\bit\b')
RE_TAIL17 = R(r',\s+no\s+(?:guessing|waste|wasted\s+motion|hassle|fluff|stress|jargon)\b')
RE_PIVOT = R(r'\bit(?:' + A + r's|\s+is)\s+worth\s+(?:noting|mentioning)\s+that\b|\bit\s+bears\s+(?:noting|mentioning)\s+that\b'
             r'|\bone\s+thing\s+to\s+(?:consider|keep\s+in\s+mind)\s+is\b|\bit\s+is\s+interesting\s+to\s+note\s+that\b'
             r'|\ba\s+key\s+consideration\s+is\b|\ba\s+point\s+to\s+highlight\s+is\b')
RE_OUTCOME = R(r',\s+(?:raising\s+questions\s+about|prompting\s+reflection\s+on|sparking\s+debate\s+about|with\s+broader\s+implications\s+for|reshaping\s+our\s+understanding\s+of|paving\s+the\s+way\s+for|signaling\s+a\s+shift\s+toward|signalling\s+a\s+shift\s+toward)\b')
RE_EDIT = R(r'\bit(?:' + A + r's|\s+is)\s+important\s+to\s+(?:remember|note|understand|recogni[sz]e)\b|\bone\s+must\s+note\s+that\b'
            r'|\bit\s+is\s+worth\s+pointing\s+out\b|\bit\s+cannot\s+be\s+overstated\s+that\b|\bit\s+must\s+be\s+emphasi[sz]ed\s+that\b')
RE_SELF = R(r'\bthis\s+(?:comprehensive\s+(?:guide|overview|analysis)|in-depth\s+(?:analysis|look|examination)|complete\s+(?:guide|overview))\b'
            r'|\ba\s+thorough\s+examination\s+of\b|\beverything\s+you\s+need\s+to\s+know\s+about\b')
RE_QA = R(r'(?:^|(?<=[.!?])\s+|(?<=\n))(?:is|are|was|were|do|does|did|can|could|will|would|should|shall|has|have|had|may|might|must)\b[^.!?\n]{0,80}\?\s+(?:yes|no|absolutely|never|maybe|probably|always)[.!]', I | re.M)
RE_CONCRETE = R(r'\bwithout\s+concrete\s+(?:evidence|proof)\b|\bdo\s+you\s+have\s+concrete\s+(?:evidence|proof)\b'
                r'|\bI\s+(?:would\s+)?need\s+concrete\s+(?:evidence|examples)\s+to\b|\babsent\s+concrete\s+(?:evidence|proof)\b'
                r'|\bprovide\s+concrete\s+(?:evidence|proof)\b')
RE_HOOK = R(r'\bin\s+today' + A + r's\s+(?:\w+\s+)?(?:\w+\s+)?(?:world|landscape|environment|market)\b|\bin\s+a\s+world\s+where\b|\bin\s+an\s+era\s+of\b'
            r'|\bin\s+recent\s+years,|\bmore\s+than\s+ever\s+before\b|\bwe\s+live\s+in\s+a\s+(?:time|world)\s+when\b'
            r'|\b(?:great|exciting|big)\s+news\s*[!:]|\bever\s+(?:wanted|wondered|dreamed|wished)\s+to\b[^.!?\n]{0,80}\?'
            r'|\bin\s+an\s+increasingly\s+(?:interconnected|digital|competitive|complex)\s+world\b')
RE_DIFF = R(r'\bunlike\s+the\s+(?:previous|prior|old|earlier)\s+(?:version|release|implementation|approach)\b'
            r'|\b(?:the|this)\s+(?:(?:latest|new)\s+)?(?:update|release|version|change|patch|design)\s+(?:adds|introduces|brings|delivers|includes|provides|improves)\b'
            r'|\b(?:has|have)\s+been\s+(?:updated|refactored|improved|enhanced|changed)\s+to\b'
            r'|\bpreviously\b[^.!?\n]{0,120}?\bnow\b|\b(?:wasn' + A + r't|weren' + A + r't)\s+there\s+before\b'
            r'|\bwe(?:' + A + r'ive|\s+have)\s+(?:now\s+)?(?:added|removed|replaced|refactored|migrated)\b')
RE_SIGNPOST = R(r'\blet' + A + r's\s+(?:dive|delve|explore)\b|\blet' + A + r's\s+break\s+(?:this|it)\s+down\b|\bhere' + A + r's\s+what\s+you\s+need\s+to\s+know\b'
                r'|\bwithout\s+further\s+ado\b|\bnow\s+let' + A + r's\s+look\s+at\b|\bbuckle\s+up\b|\bstay\s+with\s+me\b|\b(?:are\s+you\s+)?ready\s+to\s+dive\s+in\b')
RE_CATALOG = R(r'\b(?:used|uses|employs?|employed|relied\s+on|relies\s+on|utili[sz]es)\s+(?:several|various|a\s+number\s+of|multiple|different|many|numerous)\s+\w+'
               r'|(?:^|(?<=[.!?]\s)|(?<=\n))These(?:\s+\w+)?\s+(?:provide|offer|give|reveal|show|allow|enable|help)s?\s+(?:\w+\s+){0,2}(?:information|insights?|understanding|details|data)\b'
               r'|\b(?:is|are|was|were|remains|becomes)\s+(?:the|a)\s+(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective\s+tissue)\s+of\b', I | re.M)
RE_BOLDHDR = re.compile(r'^[ \t]*(?:[-*+][ \t]+|\d+[.)][ \t]+)?\*\*[^*\n]+?(?::\*\*|\*\*:)', re.M)
RE_BOLD = re.compile(r'\*\*[^*\n]+?\*\*')
RE_FORMULAIC = R(r'\bdespite\s+(?:these|its|the)\s+(?:challenges|obstacles)\b|\bchallenges\s+and\s+(?:future\s+)?(?:prospects|outlook|legacy)\b'
                 r'|\bcontinues\s+to\s+thrive\b|\btypical\s+of\s+(?:emerging|urban|modern)\b|\bfaces\s+(?:several|many|numerous)\s+challenges\b')
TRANS = 'Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably'
RE_TRANS = re.compile(r'(?:^|(?<=\n)|(?<=[.!?]\s)|(?<=[.!?]\)\s)|(?<=[.!?]"\s))[ \t]*(?:' + TRANS + r')\b')
RE_CONCL = R(r'^[ \t]*(?:[-*]\s+)?(?:in\s+conclusion|overall|in\s+summary|to\s+summari[sz]e|to\s+conclude|all\s+in\s+all|in\s+essence|ultimately)\b', I | re.M)
RE_POSCON = R(r'\bthe\s+future\s+looks\s+bright\b|\bexciting\s+times\s+lie\s+ahead\b|\bjourney\s+toward\s+excellence\b|\bstep\s+in\s+the\s+right\s+direction\b'
              r'|\b(?:the\s+)?(?:outlook|future)(?:\s+for\s+[^.!?\n]{1,40}?)?\s+(?:is|looks|remains)\s+bright\b|\bwell[- ]positioned\s+for\s+(?:whatever\s+comes\s+next|the\s+future|the\s+road\s+ahead)\b')
RE_FILLER = R(r'\bin\s+order\s+to\b|\bdue\s+to\s+the\s+fact\s+that\b|\bat\s+this\s+point\s+in\s+time\b|\bin\s+the\s+event\s+that\b|\bhas\s+the\s+ability\s+to\b'
              r'|\bit\s+is\s+important\s+to\s+note\s+that\b|\bit\s+should\s+be\s+mentioned\s+that\b|\bneedless\s+to\s+say\b')
RE_AUTH = R(r'\bhere' + A + r's\s+the\s+thing\b|\bmake\s+no\s+mistake\b|\bthe\s+truth\s+is\b|\blet' + A + r's\s+be\s+honest\b|\bthe\s+simple\s+fact\s+is\b|\bat\s+its\s+core\b'
            r'|\bwhat\s+really\s+matters\b|\bmore\s+than\s+anything\b|\bat\s+the\s+end\s+of\s+the\s+day\b|\bthe\s+bottom\s+line\s+is\b|\bin\s+reality\b|\bfundamentally,'
            r'|\bthe\s+real\s+question\s+is\b|\bthe\s+heart\s+of\s+the\s+matter\b|\bthe\s+deeper\s+issue\b|\bwhen\s+you\s+get\s+down\s+to\s+it\b|\bwhen\s+all\s+is\s+said\s+and\s+done\b')
RE_CHATBOT = R(r'\bI\s+hope\s+this\s+helps\b|\b(?:certainly|of\s+course)!|\blet\s+me\s+know\s+if\s+you\b|\bwould\s+you\s+like\s+me\s+to\b|\bfeel\s+free\s+to\s+(?:ask|reach\s+out)\b'
               r'|\bhappy\s+to\s+help\s*(?:[.!?]|$)|\b(?:here|below)\s+is\s+(?:a|an|the)\s+(?:overview|summary|rundown|recap|brief)\b'
               r'|\bhere\s+(?:are|' + A + r's)\s+(?:a\s+few|some|two|three)\s+(?:options|drafts|versions|variations)\b|\bhere\s+(?:is|' + A + r's)\s+a\s+draft\b'
               r'|\bdepending\s+on\s+the\s+(?:vibe|tone|style)\b|\bI\s+hope\s+(?:this\s+email\s+)?finds\s+you\s+well\b'
               r'|\bas\s+an?\s+(?:AI|LLM|AI\s+assistant|AI\s+language\s+model|large\s+language\s+model|language\s+model)\b'
               r'|\bto\s+(?:answer|address)\s+your\s+question\b|\bin\s+(?:response|answer)\s+to\s+your\s+question\b|\byour\s+question\s+(?:about|regarding|concerning)\b'
               r'|\bas\s+(?:you\s+)?(?:requested|asked),\s+here\b|\bhere\s+is\s+(?:the\s+)?(?:draft|first\s+pass|revised\s+version\s+of|for\s+your)\b')
RE_SYCO = R(r'\byou(?:' + A + r're|\s+are)\s+absolutely\s+right\b|\b(?:great\s+question|excellent\s+point)\s*[!.,]'
            r'|\bwhat\s+a\s+(?:thoughtful|great|wonderful|fantastic)\s+question\b|\bthat' + A + r's\s+a\s+(?:great|wonderful|fantastic|brilliant|excellent)\s+(?:point|question)\b')
RE_CUTOFF = R(r'\bas\s+of\s+my\s+(?:last\s+)?(?:training|knowledge)\b|\bup\s+to\s+my\s+(?:last\s+)?(?:training|knowledge)\b'
              r'|\bwhile\s+specific\s+details\s+are\s+(?:limited|scarce|not\s+(?:extensively|widely)\s+documented)\b|\bbased\s+on\s+(?:the\s+)?available\s+information\b'
              r'|\bas\s+of\s+my\s+(?:knowledge\s+)?cutoff\b|\bmaintains\s+a\s+low\s+profile\b|\bkeeps\s+(?:his|her|their)\s+personal\s+life\s+private\b')
RE_COPULA = R(r'\b(?:serves|stands|functions|acts)\s+as\b|\b(?:represents|marks)\s+(?:a|the)\b|\bboasts\b|\bboasted\b|\bboasting\b'
              r'|\bfeatures\s+(?:a|an|the|\d+|several|many|numerous|multiple|various|two|three|four|five|six|a\s+range|a\s+variety|a\s+host)\b|\boffers\s+a\b|\brefers\s+to\b')
RE_HEDGE = re.compile(r'\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems?\s+(?:to|like)|appears?\s+to|somewhat|relatively|fairly|kind\s+of|sort\s+of)\b')
RE_PLACEHOLDER = [
    R(r'\[\s*(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])'),
    R(r'\[[^\]\n]{0,40}\b(?:name|company|client|place|city|location|source|person|recipient|employer)\b[^\]\n]{0,40}\](?![(\[])'),
    re.compile(r'\[(?![A-Z]{1,2}\d{0,3}\]|\d+\])[A-Z][A-Z0-9 _\-]{1,40}\](?![(\[])'),
    re.compile(r'\{\{[^}\n]*\}\}'),
    re.compile(r'(?<![A-Za-z])[xX]{3,}(?![A-Za-z])'),
    R(r'\blorem\s+ipsum\b'),
]
RE_CHATREF = re.compile(r'\bcite(?:turn|start|nav)\w*|\boai_citation\w*|contentReference|navlist|【\d+†[^】\n]*】', re.I)
RE_UTM = re.compile(r'utm_source=([A-Za-z0-9._-]+)')
TRACK_HOSTS = {'chatgpt.com', 'chat.openai.com', 'perplexity.ai', 'claude.ai', 'gemini.google.com', 'copilot.microsoft.com', 'poe.com'}
HYPH = ['results-driven', 'data-driven', 'cutting-edge', 'state-of-the-art', 'best-in-class', 'detail-oriented', 'forward-thinking',
        'mission-critical', 'customer-centric', 'end-to-end', 'cross-functional', 'high-performing', 'high-impact', 'well-rounded',
        'value-added', 'next-generation', 'thought-provoking', 'ever-evolving', 'ever-changing', 'far-reaching', 'award-winning',
        'results-oriented', 'fast-paced', 'game-changing', 'world-class', 'top-tier', 'user-friendly', 'hands-on', 'results-focused',
        'action-oriented', 'goal-oriented', 'client-focused', 'solution-oriented', 'future-proof', 'game-changer', 'must-have', 'best-of-breed']
RE_HYPH = R(r'\b(?:' + '|'.join(re.escape(h) for h in HYPH) + r')\b')
RE_OUTLETS = R(r'\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+[A-Z][\w.&\'-]*(?:\s+[A-Z][\w.&\'-]*)*(?:\s*,\s*(?:and\s+)?|\s+and\s+)[A-Z][\w.&\'-]*', 0)
RE_NOTAB = R(r'\b(?:\d[\d,.]*\s*[kKmM]?\s+followers|(?:strong|active|robust|significant|growing)\s+(?:online|digital|social[- ]media)\s+presence|widely\s+covered|independent\s+coverage)\b')
RE_NOTAB2 = R(r'\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased)\s+(?:in|by)\s+(?:[A-Z][\w.&\'-]*(?:\s+[A-Z][\w.&\'-]*)*)\s*(?:,|\band\b)\s*(?:and\s+)?[A-Z][\w.&\'-]*', 0)
SLOP = ['unlock(?:ing)?\\s+(?:your\\s+|their\\s+|its\\s+|the\\s+)?full\\s+potential', 'navigat(?:e|es|ed|ing)\\s+the\\s+complexit(?:y|ies)',
        'a\\s+testament\\s+to\\s+the\\s+(?:power|importance)', 'stay(?:ing|s)?\\s+ahead\\s+of\\s+the\\s+curve',
        'turn(?:ing|s)?\\s+challenges\\s+into\\s+opportunit(?:y|ies)', 'tak(?:e|es|ing)\\s+(?:\\w+\\s+){1,4}to\\s+the\\s+next\\s+level',
        'harness(?:es|ing)?\\s+the\\s+power\\s+of', 'paving\\s+the\\s+way\\s+for', 'saying\\s+goodbye\\s+to',
        'imagin(?:e|ing)\\s+a\\s+world\\s+where', 'in\\s+today' + A + 's\\s+fast-paced\\s+world', 'embark(?:ing)?\\s+on\\s+a\\s+journey',
        'a\\s+game[- ]changer\\s+for', 'revolutioni[sz]ing\\s+the\\s+way', 'redefin(?:e|es|ing)\\s+the\\s+way', 'unlock(?:ing)?\\s+new\\s+possibilities',
        'at\\s+the\\s+forefront\\s+of', 'pave\\s+the\\s+way\\s+for', 'beyond\\s+the\\s+ordinary']
RE_SLOP = R(r'\b(?:' + '|'.join(SLOP) + r')\b')
RE_HR = re.compile(r'^ {0,3}(?:(?:-[ \t]*){3,}|(?:\*[ \t]*){3,}|(?:_[ \t]*){3,})[ \t]*$')
RE_EMOJI = re.compile('[\U0001F000-\U0001FAFF☀-➿⭐⭕⬛⬜⌚⌛⏩-⏳⏸-⏺✅✨❤❌❎❓-❕❗➕-➗➰➿]')
RE_CURLY = re.compile('[‘’“”]')
RE_YR = re.compile(r'\b(1[0-9]{3}|20[0-9]{2})-(1[0-9]{3}|20[0-9]{2})\b')
RE_WORD = re.compile(r"[^\W_](?:[^\W_]|['’-])*")
SMALL = set('a an the and or but nor for so yet of in on at to by up as if is it via per vs with from into onto over off out than then that this'.split())

FIRST_PERSON = set(['i', 'me', 'my', 'mine', 'myself', 'we', 'our', 'ours', 'us', 'ourselves', "i'm", "i've", "i'd", "i'll", "we're", "we've", "we'll", "we'd"])
RE_FULL = R(r'\b(?:(?:do|does|did|is|are|was|were|have|has|had|would|could|should|will|can)\s+not|cannot|can\s+not|I\s+am|I\s+have|I\s+will|I\s+would|we\s+are|we\s+have|we\s+will|they\s+are|you\s+are|he\s+is|she\s+is|it\s+is|that\s+is|there\s+is|what\s+is|let\s+us)\b')
RE_CONTR = R(r"\b\w+(?:n['’]t|['’](?:re|ve|ll|m|d|s))\b")

WEIGHTS = {
    1: 10, 2: 10, 3: 10, 5: 8, 6: 8, 8: 8, 10: 12, 11: 10, 12: 10, 13: 20, 14: 10, 15: 10, 16: 10, 17: 8, 18: 10,
    20: 10, 21: 10, 23: 8, 24: 10, 25: 8, 26: 8, 27: 10, 30: 8, 31: 10, 32: 8, 33: 8, 34: 8, 35: 6, 36: 8,
    37: 8, 38: 8, 39: 10, 40: 8, 44: 8, 47: 20, 48: 20, 50: 20, 51: 8, 56: 8, 57: 8, 59: 6, 62: 20, 63: 20,
    64: 20, 65: 20, 66: 20, 67: 8, 69: 12, 70: 6, 71: 12,
}
SCORE_KEYS = set(WEIGHTS)
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
RHYTHM_SM = {40, 44}
FLOOR_SHORT = set(range(1, 40)) | set(range(47, 52)) | {69}

LABELS = {
    1: 'AI vocabulary', 2: 'Model-dialect vocabulary', 3: 'Promotional language', 4: 'Hyphenated word-pair overuse',
    5: '"Simple yet X" cliche', 6: 'Stacked adjective chains', 8: 'Synonym cycling', 10: 'Significance inflation',
    11: 'Notability name-dropping', 12: 'Vague attributions', 13: 'Article title as proper noun',
    14: 'Conservation / ecosystem padding', 15: 'False ranges', 16: 'Superficial -ing tail clauses',
    '17p': 'Negative parallelism', '17t': 'Tailing negation', 18: '"Not X, just Y" construction', 19: 'Filler phrases',
    20: 'Empty pivot phrases', 21: 'Outcome speculation tails', 22: 'Persuasive authority tropes', 23: 'Editorial interjections',
    24: 'Self-thoroughness phrases', 25: 'Question-answer rhetorical pattern', 26: '"Concrete evidence" defense phrase',
    27: 'Compulsive intro hooks', 30: 'Diff-anchored writing', 31: 'Signposting and announcements', 32: 'Cataloguing lead-ins',
    33: 'Inline-header vertical lists', 34: 'Mid-essay bullet injection', 35: 'Fragmented headers', 36: 'Formulaic challenges section',
    37: 'Transition cluster overuse', 38: 'Compulsive conclusion phrases', 39: 'Generic positive conclusions',
    40: 'Sentence-length monotony', 41: 'Mechanical sentence-length alternation', 42: 'Opener repetition',
    44: 'Uniform paragraph length', 46: 'Semicolon and parenthesis underuse', 47: 'Chatbot artifacts',
    48: 'Sycophantic tone', 50: 'Knowledge-cutoff disclaimers', 51: 'Copula avoidance', 54: 'Excessive hedging',
    55: 'Contraction absence', 56: 'Boldface overuse', 57: 'Emojis', 58: 'Em-dash overuse', 59: 'Title case in headings',
    60: 'Curly quotation marks', 61: 'Hyphen for en dash in ranges', 62: 'Invisible / zero-width characters',
    63: 'Placeholder text', 64: 'Chatbot reference markup', 65: 'AI tracking parameters', 66: 'Homoglyph / mixed-script characters',
    67: 'Non-standard spaces', 68: 'Trailing / stray whitespace', 69: 'Canonical marketing-slop phrases',
    70: 'Decorative horizontal rules', 71: 'Degenerate repetition',
}
SLUGS = {k: re.sub(r'[^a-z0-9]+', '_', v.lower()).strip('_') for k, v in LABELS.items() if isinstance(k, int)}


def clip(s, n=80):
    s = re.sub(r'\s+', ' ', s).strip()
    return s if len(s) <= n else s[:n - 1] + '…'


def sample_ctx(u, a, b, ctx=30):
    s = max(0, a - ctx)
    e = min(len(u), b + ctx)
    ex = re.sub(r'\s+', ' ', u[s:e]).strip()
    if s > 0:
        ex = '...' + ex
    if e < len(u):
        ex = ex + '...'
    return ex


def split_sentences(m):
    out = []
    for line in m.split('\n'):
        ls = line.strip()
        if not ls or re.match(r'^#{1,6}\s', ls):
            continue
        ls = re.sub(r'^(?:[-*+]\s+|\d+[.)]\s+)', '', ls)
        for s in re.split(r'(?<=[.!?])["\')\]”’]*\s+', ls):
            if RE_WORD.search(s):
                out.append(s)
    return out


def wc(s):
    return len(RE_WORD.findall(s))


def cv(vals):
    if not vals:
        return 1e9
    mean = sum(vals) / len(vals)
    if mean == 0:
        return 1e9
    var = sum((v - mean) ** 2 for v in vals) / len(vals)
    return math.sqrt(var) / mean


def paragraphs(m):
    return [p for p in re.split(r'\n[ \t]*\n', m) if p.strip()]


def analyze(window, with_chars=True):
    """Return (findings dict, metrics base). findings: key -> dict(num, slug, label, count, samples, weight)"""
    raw = window
    rem = invisible_removals(raw)
    spn = space_normalizations(raw)
    homs = homoglyph_spans(raw)
    n_inv = len(rem)
    n_sp = len(spn)
    n_hom = sum(1 for a, b in homs for ch in raw[a:b] if ch in LOOK)
    # analysis text
    u0 = []
    for i, c in enumerate(raw):
        if i in rem:
            continue
        if i in spn:
            u0.append(spn[i])
        else:
            u0.append(c)
    u = ''.join(u0)
    u = u.replace('\r\n', ' \n').replace('\r', '\n')
    m, _mk = mask_markdown(u)
    findings = {}

    def add(key, num, label, count, samples):
        if count <= 0:
            return
        findings[key] = {'num': num, 'label': label, 'count': count, 'samples': [clip(s) for s in samples[:3]]}

    def rx(key, num, rgx, label=None, ctx=False, minc=1):
        ms = list(rgx.finditer(m))
        if len(ms) < minc:
            return
        if ctx:
            smp = [sample_ctx(u, x.start(), x.end()) for x in ms[:3]]
        else:
            smp = [x.group() for x in ms[:3]]
        add(key, num, label or LABELS[num], len(ms), smp)

    def sk(num):
        return '%d_%s' % (num, SLUGS[num])

    rx(sk(1), 1, RE_AI, ctx=True)
    rx(sk(2), 2, RE_DIALECT, minc=2)
    # 3
    ms = list(RE_PROMO.finditer(m))
    im = list(RE_IMPER.finditer(m))
    smp = [x.group() for x in ms[:3]]
    cnt = len(ms)
    if len(im) >= 3:
        cnt += len(im)
        smp += [x.group().strip() for x in im[:3]]
    add(sk(3), 3, LABELS[3], cnt, smp)
    rx(sk(4), 4, RE_HYPH)
    rx(sk(5), 5, RE_SIMPLEYET)
    # 6
    chains = []
    for x in RE_CHAIN.finditer(m):
        words = re.findall(r'[A-Za-z][A-Za-z-]*', x.group(1))
        words = [w for w in words if w.lower() != 'and']
        if len(words) >= 4:
            chained = words[:-1]
            if any(w.lower() in STOCK_ADJ or ADJ_SUFFIX.search(w) for w in chained):
                chains.append(x.group(1))
    add(sk(6), 6, LABELS[6], len(chains), chains)
    # 8
    syn_total = 0
    syn_s = []
    for rgx in SYN_RE:
        found = [x.group(1).lower() for x in rgx.finditer(m)]
        kinds = set(re.sub(r'\s+', ' ', f).rstrip('s') if False else f for f in found)
        # normalize plural to singular for distinctness
        kn = set()
        for f in found:
            kn.add(re.sub(r'(ies)$', 'y', re.sub(r'(es)$', '', f)) if f.endswith('ies') else (f[:-2] if f.endswith(('ches', 'shes', 'xes', 'sses')) else (f[:-1] if f.endswith('s') and not f.endswith('ss') else f)))
        if len(kn) >= 3:
            syn_total += len(found)
            syn_s.append(', '.join(sorted(kn)))
    add(sk(8), 8, LABELS[8], syn_total, syn_s)
    rx(sk(10), 10, RE_SIGINF)
    # 11
    ms = list(RE_NOTAB2.finditer(m)) + list(RE_NOTAB.finditer(m))
    add(sk(11), 11, LABELS[11], len(ms), [x.group() for x in ms])
    rx(sk(12), 12, RE_VAGUE)
    rx(sk(13), 13, RE_TITLE13)
    rx(sk(14), 14, RE_CONSERV)
    rx(sk(15), 15, RE_FALSERANGE)
    rx(sk(16), 16, RE_ING)
    rx('17_negative_parallelism', 17, RE_PAR17, LABELS['17p'])
    rx('17_tailing_negation', 17, RE_TAIL17, LABELS['17t'])
    rx(sk(18), 18, RE_NOTX)
    rx(sk(19), 19, RE_FILLER)
    rx(sk(20), 20, RE_PIVOT)
    rx(sk(21), 21, RE_OUTCOME)
    rx(sk(22), 22, RE_AUTH)
    rx(sk(23), 23, RE_EDIT)
    rx(sk(24), 24, RE_SELF)
    rx(sk(25), 25, RE_QA)
    rx(sk(26), 26, RE_CONCRETE)
    rx(sk(27), 27, RE_HOOK)
    rx(sk(30), 30, RE_DIFF)
    rx(sk(31), 31, RE_SIGNPOST)
    rx(sk(32), 32, RE_CATALOG)
    rx(sk(33), 33, RE_BOLDHDR)
    # 34
    lines = m.split('\n')
    has_heading = any(re.match(r'^ {0,3}#{1,6}\s', ln) for ln in lines)
    paras = paragraphs(m)
    if not has_heading and paras:
        listre = re.compile(r'^\s*(?:[-*+]|\d+[.)])\s+\S')
        list_paras = 0
        prose_paras = 0
        for p in paras:
            pl = [x for x in p.split('\n') if x.strip()]
            if all(listre.match(x) for x in pl):
                list_paras += 1
            elif not any(listre.match(x) for x in pl):
                prose_paras += 1
        if list_paras >= 1 and prose_paras >= 2:
            add(sk(34), 34, LABELS[34], list_paras, ['bulleted list inside prose'])
    # 35
    c35 = []
    for i, ln in enumerate(lines):
        mh = re.match(r'^ {0,3}#{1,6}\s+(.+?)\s*#*\s*$', ln)
        if not mh:
            continue
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j >= len(lines):
            continue
        nl = lines[j].strip()
        if re.match(r'^(?:#|[-*+]\s|\d+[.)]\s|\|)', nl):
            continue
        nw = RE_WORD.findall(nl)
        if 0 < len(nw) <= 5:
            hw = set(w.lower() for w in RE_WORD.findall(mh.group(1)) if len(w) > 2)
            if any(w.lower() in hw for w in nw):
                c35.append(mh.group(1) + ' / ' + nl)
    add(sk(35), 35, LABELS[35], len(c35), c35)
    rx(sk(36), 36, RE_FORMULAIC)
    # 37
    c37 = 0
    s37 = []
    for p in paras:
        mm = list(RE_TRANS.finditer(p))
        if len(mm) >= 2:
            c37 += len(mm)
            s37 += [x.group().strip() for x in mm]
    add(sk(37), 37, LABELS[37], c37, s37)
    rx(sk(38), 38, RE_CONCL)
    rx(sk(39), 39, RE_POSCON)
    # sentences / rhythm
    sents = split_sentences(m)
    swc = [wc(s) for s in sents]
    words_all = RE_WORD.findall(m)
    nwords = len(words_all)
    if len(sents) >= 3 and cv(swc) < 0.35:
        add(sk(40), 40, LABELS[40], len(sents), ['%d sentences, lengths %s' % (len(sents), ','.join(map(str, swc[:8])))])
    # 41
    best = 0
    run_start = 0
    if len(swc) >= 6:
        i = 0
        L = len(swc)
        while i < L - 1:
            j = i
            lastsign = 0
            while j < L - 1:
                d = swc[j + 1] - swc[j]
                sg = 1 if d > 0 else (-1 if d < 0 else 0)
                if sg == 0 or abs(d) < 5 or sg == lastsign:
                    break
                lastsign = sg
                j += 1
            runlen = j - i + 1
            if runlen > best:
                best = runlen
            i = max(j, i + 1)
        if best >= 6:
            add(sk(41), 41, LABELS[41], best, ['alternating run of %d sentences' % best])
    # 42
    c42 = 0
    s42 = []
    for p in paras:
        ss = split_sentences(p)
        if len(ss) >= 3:
            cnt = Counter()
            for s in ss:
                w = [x.lower() for x in RE_WORD.findall(s)[:2]]
                if len(w) == 2:
                    cnt[' '.join(w)] += 1
            for k, v in cnt.items():
                if v >= 3:
                    c42 += v
                    s42.append(k)
    add(sk(42), 42, LABELS[42], c42, s42)
    # 44
    pw = [wc(p) for p in paras]
    if len(paras) >= 4 and cv(pw) < 0.4:
        add(sk(44), 44, LABELS[44], len(paras), ['%d paragraphs, word counts %s' % (len(paras), ','.join(map(str, pw[:8])))])
    # 46
    if nwords >= 300 and ';' not in m and m.count('(') <= 1:
        add(sk(46), 46, LABELS[46], 1, ['no semicolons, almost no parentheticals'])
    rx(sk(47), 47, RE_CHATBOT)
    rx(sk(48), 48, RE_SYCO)
    rx(sk(50), 50, RE_CUTOFF)
    rx(sk(51), 51, RE_COPULA)
    # 54
    c54 = 0
    s54 = []
    for s in re.split(r'(?<=[.!?])\s+|\n+', m):
        hs = RE_HEDGE.findall(s)
        if len(hs) >= 2:
            c54 += 1
            s54.append(s)
    add(sk(54), 54, LABELS[54], c54, s54)
    # 55
    fp = sum(1 for w in words_all if w.lower().replace('’', "'") in FIRST_PERSON)
    if nwords and fp >= 3 and fp / nwords >= 0.02:
        full = RE_FULL.findall(m)
        con = RE_CONTR.findall(m)
        if len(full) >= 3 and len(full) / (len(full) + len(con)) >= 0.7:
            add(sk(55), 55, LABELS[55], len(full), full[:3])
    rx(sk(56), 56, RE_BOLD)
    rx(sk(57), 57, RE_EMOJI)
    # 58
    c58 = 0
    for p in paras:
        k = p.count('—')
        if k >= 2:
            c58 += k
    add(sk(58), 58, LABELS[58], c58, ['em dashes'])
    # 59
    c59 = []
    for ln in lines:
        mh = re.match(r'^ {0,3}#{1,6}\s+(.+?)\s*#*\s*$', ln)
        if not mh:
            continue
        h = mh.group(1)
        ws = h.split()
        if len(ws) < 3 or not h[0].isalpha() or h.upper() == h:
            continue
        major = [w for w in ws if w.lower().strip('.,:;!?') not in SMALL]
        if len(major) >= 2 and all(w[0].isupper() for w in major if w[0].isalpha()) and all(w[0].isalpha() for w in major):
            c59.append(h)
    add(sk(59), 59, LABELS[59], len(c59), c59)
    rx(sk(60), 60, RE_CURLY)
    # 61
    c61 = [x.group() for x in RE_YR.finditer(m) if int(x.group(2)) > int(x.group(1))]
    add(sk(61), 61, LABELS[61], len(c61), c61)
    # 62 / 66 / 67 / 68
    if n_inv:
        add(sk(62), 62, LABELS[62], n_inv, ['U+%04X' % ord(raw[i]) for i in sorted(rem)[:3]])
    if n_hom:
        add(sk(66), 66, LABELS[66], n_hom, [raw[a:b] for a, b in homs[:3]])
    if n_sp:
        add(sk(67), 67, LABELS[67], n_sp, ['U+%04X' % ord(raw[i]) for i in sorted(spn)[:3]])
    t68 = trailing_ws_count(raw)
    if t68:
        add(sk(68), 68, LABELS[68], t68, ['trailing whitespace'])
    # 63
    c63 = 0
    s63 = []
    for rgx in RE_PLACEHOLDER:
        for x in rgx.finditer(m):
            c63 += 1
            s63.append(x.group())
    add(sk(63), 63, LABELS[63], c63, s63)
    # 64 / 65
    rx(sk(64), 64, RE_CHATREF)
    c65 = []
    for x in RE_UTM.finditer(m):
        host = x.group(1).rstrip('.').lower()
        if host in TRACK_HOSTS:
            c65.append(x.group())
    add(sk(65), 65, LABELS[65], len(c65), c65)
    rx(sk(69), 69, RE_SLOP)
    # 70
    if len([ln for ln in lines if ln.strip()]) + 0 >= 0 and len(lines) >= 24:
        hrs = []
        for i, ln in enumerate(lines):
            if RE_HR.match(ln):
                if ln.strip().startswith('-') and i > 0 and lines[i - 1].strip() and not RE_HR.match(lines[i - 1]) and not re.match(r'^\s*(?:[-*+]|\d+[.)])\s', lines[i - 1]) and not re.match(r'^\s*(?:[-*+]|\d+[.)])\s', ln):
                    # setext heading underline
                    if len(ln.strip().replace(' ', '')) >= 3 and ' ' not in ln.strip():
                        continue
                hrs.append(ln.strip())
        if len(hrs) >= 3:
            add(sk(70), 70, LABELS[70], len(hrs), hrs)
    # 71
    lw = [w.lower() for w in words_all]
    if len(lw) >= 12:
        grams = [tuple(lw[i:i + 6]) for i in range(len(lw) - 5)]
        cnt = Counter(grams)
        rep = sum(1 for g in grams if cnt[g] > 1)
        if grams and rep / len(grams) >= 0.2:
            top = [' '.join(g) for g, c in cnt.most_common(3) if c > 1]
            add(sk(71), 71, LABELS[71], rep, top)
    meta = {'words': nwords, 'sents': len(sents), 'inv': n_inv, 'sp': n_sp, 'hom': n_hom}
    return findings, meta


def moving(num):
    return num in SCORE_KEYS


def compute_score(findings, meta):
    nwords = meta['words']
    fams = {}
    for k, f in findings.items():
        n = f['num']
        if n == 17:
            if k != '17_tailing_negation':
                continue
        if n not in SCORE_KEYS:
            continue
        fams[n] = fams.get(n, 0) + f['count']
    nfam = len(fams)
    if nfam == 0:
        conf_fams = 0
    conf_fams = nfam
    # confidence
    if nwords < 40:
        conf, reason = 'none', 'fewer than 40 words; too short for a meaningful score'
    elif nwords < 120:
        conf, reason = 'low', 'fewer than 120 words; short text gives a weak signal'
    elif nwords < 300 and conf_fams <= 1:
        conf, reason = 'low', 'under 300 words with at most one score-moving pattern family'
    elif nwords < 300:
        conf, reason = 'moderate', 'under 300 words; longer text gives a stronger signal'
    else:
        conf, reason = 'high', ''
    raw = 0.0
    for n, c in fams.items():
        raw += WEIGHTS[n] * min(1 + (c - 1) * 0.25, 2.0)
    score = int(round(raw))
    score = min(score, 100)
    dec = [n for n in fams if n in DECISIVE]
    if nfam == 0:
        score = 0
    else:
        if nfam == 1:
            score = min(score, 40)
        if set(fams) <= RHYTHM_SM:
            score = min(score, 40)
        if set(fams) == {40}:
            score = min(score, 20)
        if nfam == 1 and 40 in fams:
            score = min(score, 20)
        if len(dec) >= 2:
            score = max(score, 65)
        elif len(dec) == 1 and conf in ('moderate', 'high'):
            score = max(score, 45)
        if nwords < 120:
            k = len([n for n in fams if n in FLOOR_SHORT])
            if k >= 3:
                score = max(score, 45)
            elif k >= 2:
                score = max(score, 25)
        if nwords >= 400:
            if nfam >= 6:
                score = max(score, 45)
            elif nfam >= 5:
                score = max(score, 25)
    # rhythm-only cap re-applied after floors (floors do not apply for rhythm-only anyway)
    score = max(0, min(100, score))
    return score, conf, reason


def band(s):
    if s <= 20:
        return 'clean'
    if s <= 40:
        return 'light tells'
    if s <= 60:
        return 'mixed'
    if s <= 80:
        return 'heavy tells'
    return 'pervasive tells'


def build_report(text):
    truncated = len(text) > WINDOW
    window = text[:WINDOW]
    findings, meta = analyze(window)
    score, conf, reason = compute_score(findings, meta)
    rep = {}
    for k in sorted(findings, key=lambda k: (findings[k]['num'], k)):
        f = findings[k]
        rep[k] = {'label': f['label'], 'count': f['count'], 'samples': f['samples']}
    metrics = {
        'scanned_chars': len(window),
        'truncated': truncated,
        'ai_tell_score': score,
        'ai_tell_band': band(score),
        'confidence': conf,
        'confidence_reason': reason,
        'patterns_flagged': len(rep),
        'invisible_chars': meta['inv'],
        'nonstandard_spaces': meta['sp'],
        'homoglyphs': meta['hom'],
        'word_count': meta['words'],
    }
    rep['_metrics'] = metrics
    return rep, window


def sentence_units(window):
    m = window.replace('\r\n', '\n').replace('\r', '\n')
    return split_sentences(m)


def interval(window, score):
    sents = sentence_units(window)
    if len(sents) < 4:
        return None, 'too few sentences for an interval (need at least 4)'
    import random
    rng = random.Random(1729)
    n = len(sents)
    runs = 20 if len(window) < 20000 else (8 if len(window) < 100000 else 4)
    vals = []
    for _ in range(runs):
        pick = [sents[rng.randrange(n)] for _ in range(n)]
        txt = ' '.join(pick)
        f, mt = analyze(txt)
        s, _c, _r = compute_score(f, mt)
        vals.append(s)
    vals.sort()
    lo = vals[int(0.1 * (len(vals) - 1))]
    hi = vals[int(math.ceil(0.9 * (len(vals) - 1)))]
    lo = min(lo, score)
    hi = max(hi, score)
    return [lo, hi], 'bootstrap over sentences (%d resamples, fixed seed)' % runs


# ------------------------------------------------------------------- main

def err(msg, code):
    sys.stderr.write(json.dumps({'error': msg}) + '\n')
    sys.stderr.flush()
    return code


def main(argv):
    clean = False
    ci = False
    operands = []
    i = 0
    only_ops = False
    while i < len(argv):
        a = argv[i]
        i += 1
        if only_ops:
            operands.append(a)
            continue
        if a == '--':
            only_ops = True
        elif a in ('--help', '-h'):
            sys.stdout.buffer.write(USAGE.encode('utf-8'))
            sys.stdout.flush()
            return 0
        elif a == '--clean':
            clean = True
        elif a == '--ci':
            ci = True
        elif a.startswith('-') and a != '-':
            return err('unknown option %s (see --help)' % a, 2)
        else:
            operands.append(a)
    if len(operands) >= 2:
        sys.stderr.write('note: only the first file was scanned: %s\n' % operands[0])
        # contract: "the last one is the file scanned" in the signature, first in PRD
    try:
        if operands:
            text = load_file(operands[0])
        else:
            text = decode_bytes(sys.stdin.buffer.read())
    except InputError as e:
        return err(str(e), 1)
    except Exception as e:
        return err('cannot read input: %s' % e, 1)
    if not text or not text.strip():
        return err('empty input', 1)
    if clean:
        out = clean_text(text)
        sys.stdout.buffer.write(out.encode('utf-8', errors='replace'))
        sys.stdout.flush()
        return 0
    rep, window = build_report(text)
    if ci:
        iv, note = interval(window, rep['_metrics']['ai_tell_score'])
        rep['_metrics']['score_ci'] = iv
        rep['_metrics']['score_ci_note'] = note
    sys.stdout.buffer.write((json.dumps(rep, ensure_ascii=False, indent=2) + '\n').encode('utf-8', errors='replace'))
    sys.stdout.flush()
    return 0


if __name__ == '__main__':
    try:
        sys.exit(main(sys.argv[1:]))
    except BrokenPipeError:
        sys.exit(0)
    except Exception as e:  # never a traceback
        sys.stderr.write(json.dumps({'error': 'cannot read input: %s' % e}) + '\n')
        sys.exit(1)
