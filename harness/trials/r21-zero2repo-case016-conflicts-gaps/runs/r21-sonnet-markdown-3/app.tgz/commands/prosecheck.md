---
description: Control prosecheck (levels, check, doctor, show, stats, init, help)
argument-hint: [lite|full|strict|off|on|status|show|check|doctor|stats|init|help]
---
/prosecheck $ARGUMENTS
