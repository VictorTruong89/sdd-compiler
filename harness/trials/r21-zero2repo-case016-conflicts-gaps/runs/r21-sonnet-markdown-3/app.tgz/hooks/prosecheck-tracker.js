#!/usr/bin/env node
'use strict';
// Prompt-submit hook and /prosecheck command router.
const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib.js');

const SUBS = ['lite', 'full', 'strict', 'off', 'on', 'status', 'show', 'check', 'doctor', 'stats', 'init', 'help'];
const AGENTS_START = '<!-- prosecheck:prose-contract:start -->';
const AGENTS_END = '<!-- prosecheck:prose-contract:end -->';

function block(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }) + '\n');
}

function helpReply(level) {
  return [
    'prosecheck is on its ' + level + ' level. Commands:',
    '/prosecheck lite - writing contract on, no saved-file scoring',
    '/prosecheck full - contract plus saved-file guard, threshold 40 (default)',
    '/prosecheck strict - guard with a stricter threshold of 20, plus the cleanup scrub',
    '/prosecheck off | on - disable or re-enable prosecheck',
    '/prosecheck status - show the current level',
    '/prosecheck show - list files scored or skipped in this session',
    '/prosecheck check FILE - score one file; report only, no rewrite',
    '/prosecheck doctor - install health check',
    '/prosecheck stats - session token figures and the score of the session prose',
    '/prosecheck init - export the contract to ./AGENTS.md for other agents',
    'Code, commits, config, and chat are never touched.',
    'For a deep rewrite, ask in plain language: "prosecheck this" or "humanize this".',
  ].join('\n');
}

function setLevel(word) {
  const ok = lib.writeLevel(word);
  return ok;
}

function stripArg(a) {
  a = (a || '').trim();
  if (a.startsWith('@')) a = a.slice(1);
  if (a.length >= 2 && ((a[0] === '"' && a[a.length - 1] === '"') || (a[0] === "'" && a[a.length - 1] === "'"))) {
    a = a.slice(1, -1);
  } else if (a.startsWith('@')) { /* nothing */ }
  a = a.trim();
  if (a.startsWith('@')) a = a.slice(1);
  return a;
}

function checkReply(arg) {
  const p = stripArg(arg);
  if (!p) return 'prosecheck check needs a file path, for example: /prosecheck check README.md';
  const abs = path.resolve(process.cwd(), p);
  const base = path.basename(abs);
  let st;
  try { st = fs.statSync(abs); } catch (e) { return 'cannot read ' + p + ': no such file'; }
  if (!st.isFile()) return p + ' is not a file';
  const ext = path.extname(base).toLowerCase();
  if (ext === '.pdf' || ext === '.rtf') return base + ': no readable text (this format is not scored)';
  const archive = lib.ARCHIVE_EXT.includes(ext);
  const cap = archive ? lib.ARCHIVE_CAP : lib.PLAIN_CAP;
  if (st.size > cap) return base + ' is over ' + (cap / 1024) + ' KB and was not scored';
  const r = lib.runDetector(['--', abs], { timeout: archive ? 15000 : 8000 });
  switch (r.kind) {
    case 'nopython': return 'detector unavailable: Python was not found, so nothing could be scored';
    case 'nodetector': return 'detector unavailable: the bundled script is missing';
    case 'timeout': return base + ' failed: the detector timed out';
    case 'failed': return base + ' failed: ' + (r.stderr || 'the detector reported a failure');
    case 'empty': return base + ': no report was produced by the detector';
    case 'notreport': case 'noscore': return 'no report: the detector printed text that is not a report';
    default: break;
  }
  const rep = r.report;
  const m = rep._metrics;
  const lines = [];
  lines.push(base + ' - ' + lib.hookPhrase(m.ai_tell_band) + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')');
  let conf = 'confidence: ' + m.confidence;
  if (m.confidence !== 'high' && m.confidence_reason) conf += ' - ' + m.confidence_reason;
  lines.push(conf);
  if (m.truncated) lines.push('coverage: first ' + lib.WINDOW_TXT + ' characters only; the rest of the text was not included');
  const fl = lib.findingList(rep).slice(0, lib.CHECK_LABEL_CAP);
  if (fl.length === 0) lines.push('tells: none');
  else lines.push('tells: ' + fl.map(f => f.label + ' (x' + f.count + ')').join('; '));
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

function doctorReply(form) {
  const level = lib.getLevel();
  const lines = [];
  lines.push('prosecheck doctor');
  const modeOk = level !== 'off';
  lines.push(modeOk ? '[OK] mode: ' + level : '[--] mode: off (not a fault; run /prosecheck on to switch it back on)');
  const det = lib.findDetector();
  lines.push(det ? '[OK] detector: bundled script found' : '[!!] detector: bundled script missing from the plugin tree');
  let pyOk = false;
  if (!lib.findPython()) {
    lines.push('[!!] python not found: saved files are not re-scored until Python is available; the writing contract still shapes new prose');
  } else if (!det) {
    lines.push('[!!] python: found, but the bundled script is missing so nothing could run');
  } else {
    const r = lib.runDetector([], { input: 'The cat sat on the mat. It was a quiet afternoon, and nobody minded.', timeout: 15000 });
    if (r.kind === 'ok') { pyOk = true; lines.push('[OK] python: ran the bundled script and got a numeric score'); }
    else if (r.kind === 'nopython') lines.push('[!!] python not found: saved files are not re-scored until Python is available; the writing contract still shapes new prose');
    else lines.push('[!!] python: ran but the result was not a numeric score');
  }
  let setOk = false;
  try {
    const dir = lib.configDir();
    fs.mkdirSync(dir, { recursive: true });
    const tmp = path.join(dir, '.prosecheck-write-test-' + process.pid);
    fs.writeFileSync(tmp, 'x');
    fs.unlinkSync(tmp);
    setOk = true;
  } catch (e) { setOk = false; }
  lines.push(setOk ? '[OK] settings folder is writable' : '[!!] settings folder is not writable');
  const faults = !det || !pyOk || !setOk;
  let closer;
  if (faults) closer = 'Please fix the faulty checks above, then run /prosecheck doctor again.';
  else if (!modeOk) closer = 'The install is healthy but switched off: saving files triggers no scoring, so nothing is scored. Run ' + form + ' on to turn it back on.';
  else closer = 'prosecheck is active. Plain text is accepted up to 512 KB and archives up to 4 MB; the first ' + lib.WINDOW_TXT + ' characters are scanned. Run ' + form + ' show to see files that were only partly scanned or skipped.';
  lines.push(closer);
  return lines.join('\n');
}

function showReply(sid) {
  lib.pruneLedgers();
  const recs = lib.readLedger(sid);
  if (!recs.length) {
    return 'nothing scored yet in this session. Rows appear after prose files (including .docx and .pdf deliverables) are saved.';
  }
  const rows = ['Files this session, newest first:'];
  for (const r of recs.slice().reverse()) {
    const b = r.file;
    if (r.kind === 'scored') {
      let body = lib.hookPhrase(r.band) + ' (score ' + r.score + '/' + r.band + (r.truncated ? ', first ' + lib.WINDOW_TXT + ' characters only' : '') + ')';
      const labels = (r.labels || []).slice(0, lib.LABEL_CAP);
      if (labels.length) body += ' - ' + (r.flagged ? 'flagged' : 'under the threshold') + ': ' + labels.join('; ');
      rows.push('  ' + b + ' - ' + body);
    } else if (r.kind === 'skipped') {
      rows.push('  ' + b + ' - not scored: the file exceeds the ' + r.capKB + ' KB limit');
    } else if (r.kind === 'binary') {
      rows.push('  ' + b + ' - binary format, not re-scored');
    } else {
      rows.push('  ' + b + ' - not scored: ' + String(r.reason || 'check failed').replace(/\d+\s*KB/gi, ''));
    }
  }
  return rows.join('\n');
}

function initReply(form) {
  const level = lib.getLevel();
  if (level === 'off') {
    return 'prosecheck is switched off, so nothing was exported. Run ' + form + ' on to allow the export.';
  }
  const out = [];
  const cwd = process.cwd();
  const agents = path.join(cwd, 'AGENTS.md');
  let existing = null;
  let readFail = false;
  try {
    if (fs.existsSync(agents)) existing = fs.readFileSync(agents, 'utf8');
  } catch (e) { readFail = true; }
  if (readFail) {
    out.push('cannot read AGENTS.md, so the contract was not written there.');
  } else if (existing !== null && (existing.includes(AGENTS_START) || existing.includes('## Prose contract (prosecheck)'))) {
    out.push('AGENTS.md already contains the contract section; left unchanged.');
  } else {
    const section = AGENTS_START + '\n## Prose contract (prosecheck)\n\n' + lib.contractText(level, { portable: true }) + '\n' + AGENTS_END + '\n';
    let content;
    if (existing === null || existing.length === 0) content = section;
    else content = existing + (existing.endsWith('\n') ? '\n' : '\n\n') + section;
    try {
      fs.writeFileSync(agents, content);
      out.push('AGENTS.md: wrote the writing contract (' + level + ').');
    } catch (e) {
      out.push('cannot write AGENTS.md, so the contract was not exported.');
    }
  }
  const rule = path.join(cwd, '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(rule)) {
    out.push('.cursor/rules/prosecheck.mdc is already there; left unchanged.');
  } else {
    let src = null;
    for (const c of lib.cursorRuleCandidates()) { try { src = fs.readFileSync(c); break; } catch (e) { /* next */ } }
    try {
      if (src === null) throw new Error('missing shipped rule');
      fs.mkdirSync(path.dirname(rule), { recursive: true });
      fs.writeFileSync(rule, src);
      out.push('Cursor rule: copied to .cursor/rules/prosecheck.mdc.');
    } catch (e) {
      out.push('cannot write the Cursor rule .cursor/rules/prosecheck.mdc.');
    }
  }
  return out.join('\n');
}

function route(payload) {
  const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
  const trimmed = prompt.trim();
  const low = trimmed.toLowerCase();
  if (low === 'stop prosecheck' || low === 'prosecheck off') {
    setLevel('off');
    block('prosecheck is now off. Use /prosecheck on to re-enable it.');
    return;
  }
  const m = /^(\/prosecheck(?::prosecheck)?)(?:\s+([\s\S]*))?$/.exec(trimmed);
  if (!m) {
    const level = lib.getLevel();
    if (level === 'off') return;
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: {
        hookEventName: 'UserPromptSubmit',
        additionalContext: 'prosecheck (' + level + '): prose deliverables follow the writing contract; code, config, and commits are untouched.',
      },
    }) + '\n');
    return;
  }
  const form = m[1];
  const rest = (m[2] || '').trim();
  const sm = /^(\S+)(?:\s+([\s\S]*))?$/.exec(rest);
  const word = sm ? sm[1] : '';
  const arg = sm && sm[2] ? sm[2] : '';
  const sub = word.toLowerCase();
  if (!word) return block(helpReply(lib.getLevel()));
  switch (sub) {
    case 'help': return block(helpReply(lib.getLevel()));
    case 'lite': case 'full': case 'strict':
      setLevel(sub);
      return block('prosecheck level set to ' + sub + '.');
    case 'off':
      setLevel('off');
      return block('prosecheck is now off. Use /prosecheck on to re-enable it.');
    case 'on':
      setLevel('full');
      return block('prosecheck is on, level full.');
    case 'status':
      return block('prosecheck level: ' + lib.getLevel());
    case 'show': return block(showReply(typeof payload.session_id === 'string' ? payload.session_id : ''));
    case 'check': return block(checkReply(arg));
    case 'doctor': return block(doctorReply(form));
    case 'stats': return block(require('./prosecheck-stats.js').statsReply(payload));
    case 'init': return block(initReply(form));
    default:
      return block('unknown subcommand: ' + word + '. Valid subcommands: ' + SUBS.join(', ') + '.');
  }
}

try {
  route(lib.readStdinJson());
} catch (e) { /* never fail the host */ }
process.exit(0);
