#!/usr/bin/env node
'use strict';
// Stats: session token figures and own-prose score from a host transcript.
const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib.js');

function newestTranscript(dir) {
  let best = null;
  function walk(d, depth) {
    let ents = [];
    try { ents = fs.readdirSync(d, { withFileTypes: true }); } catch (e) { return; }
    for (const e of ents) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) { if (depth < 4) walk(p, depth + 1); }
      else if (e.isFile() && e.name.endsWith('.jsonl')) {
        try {
          const m = fs.statSync(p).mtimeMs;
          if (!best || m > best.m) best = { p, m };
        } catch (err) { /* skip */ }
      }
    }
  }
  walk(dir, 0);
  return best ? best.p : null;
}

function statsReply(payload) {
  payload = payload || {};
  const level = lib.getLevel();
  let tp = typeof payload.transcript_path === 'string' && payload.transcript_path ? payload.transcript_path : null;
  if (!tp) tp = newestTranscript(path.join(lib.configDir(), 'projects'));
  let raw = null;
  if (tp) { try { raw = fs.readFileSync(tp, 'utf8'); } catch (e) { raw = null; } }
  if (raw === null) {
    return 'prosecheck stats: no readable transcript was found for this session.\nlevel: ' + level;
  }
  const byId = new Map();
  let anon = 0;
  const texts = [];
  for (const line of raw.split('\n')) {
    if (!line.trim()) continue;
    let o;
    try { o = JSON.parse(line); } catch (e) { continue; }
    if (!o || o.type !== 'assistant' || !o.message || typeof o.message !== 'object') continue;
    const msg = o.message;
    const id = typeof msg.id === 'string' && msg.id ? msg.id : ('#anon' + (anon++));
    const u = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    const out = Number(u.output_tokens) || 0;
    const cr = Number(u.cache_read_input_tokens) || 0;
    const prev = byId.get(id);
    if (!prev) byId.set(id, { out, cr, texts: [] });
    else { prev.out = Math.max(prev.out, out); prev.cr = Math.max(prev.cr, cr); }
    const ent = byId.get(id);
    const c = msg.content;
    if (typeof c === 'string') ent.texts.push(c);
    else if (Array.isArray(c)) {
      for (const part of c) {
        if (part && part.type === 'text' && typeof part.text === 'string') ent.texts.push(part.text);
      }
    }
  }
  let turns = 0, out = 0, cr = 0;
  for (const v of byId.values()) {
    turns += 1; out += v.out; cr += v.cr;
    for (const t of v.texts) texts.push(t);
  }
  const lines = [
    'prosecheck session stats',
    'level: ' + level,
    'assistant turns: ' + turns,
    'output tokens: ' + out,
    'cache-read input tokens: ' + cr,
  ];
  let prose = texts.join('\n\n').replace(/^ {0,3}(`{3,}|~{3,})[^\n]*\n[\s\S]*?(?:\n {0,3}\1[`~]*[ \t]*(?=\n|$)|$)/gm, '');
  prose = prose.slice(-40000).trim();
  if (prose.length > 200) {
    const r = lib.runDetector([], { input: prose, timeout: 15000 });
    if (r.kind === 'ok') lines.push('session prose ai_tell_score: ' + r.report._metrics.ai_tell_score);
  }
  return lines.join('\n');
}

module.exports = { statsReply };

if (require.main === module) {
  try {
    process.stdout.write(statsReply(lib.readStdinJson()) + '\n');
  } catch (e) { /* never fail */ }
  process.exit(0);
}
