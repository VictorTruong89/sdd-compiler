'use strict';
// Shared helpers for the prosecheck hooks. Node standard library only.
const fs = require('fs');
const os = require('os');
const path = require('path');
const cp = require('child_process');

const WINDOW = 262144;
const WINDOW_TXT = '262,144';
const PLAIN_CAP = 512 * 1024;
const ARCHIVE_CAP = 4 * 1024 * 1024;
const PLAIN_EXT = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ARCHIVE_EXT = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub', '.ipynb'];
const LEVELS = ['lite', 'full', 'strict', 'off'];
const LEDGER_MAX_AGE_MS = 7 * 24 * 3600 * 1000;
const LEDGER_MAX_RECORDS = 20;
const LABEL_CAP = 5;
const CHECK_LABEL_CAP = 8;

const BANNED = ['delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster', 'underscore',
  'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic', 'testament', 'vibrant', 'comprehensive',
  'plethora', 'myriad', 'boast', 'elevate', 'empower', 'unlock', 'game-changer', 'supercharge', 'genuinely',
  'fascinating', 'nuanced'];

function configDir() {
  return process.env.CLAUDE_CONFIG_DIR || path.join(os.homedir(), '.claude');
}
function pluginRoot() {
  return process.env.CLAUDE_PLUGIN_ROOT || path.resolve(__dirname, '..');
}
function flagPath() { return path.join(configDir(), '.prosecheck-active'); }

function readStored() {
  try {
    const v = fs.readFileSync(flagPath(), 'utf8').trim().toLowerCase();
    return LEVELS.includes(v) ? v : null;
  } catch (e) { return null; }
}
function envDefault() {
  const v = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  return LEVELS.includes(v) ? v : null;
}
function getLevel() { return readStored() || envDefault() || 'full'; }
function flagExists() {
  try { fs.statSync(flagPath()); return true; } catch (e) { return false; }
}
function writeLevel(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), level);
    return true;
  } catch (e) { return false; }
}

function readStdinJson() {
  let raw = '';
  try { raw = fs.readFileSync(0, 'utf8'); } catch (e) { raw = ''; }
  try {
    const v = JSON.parse(raw);
    return v && typeof v === 'object' && !Array.isArray(v) ? v : {};
  } catch (e) { return {}; }
}

function findDetector() {
  const root = pluginRoot();
  const cands = [path.join(root, 'scripts', 'detect.py'), path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py')];
  for (const c of cands) {
    try { if (fs.statSync(c).isFile()) return c; } catch (e) { /* next */ }
  }
  return null;
}

function findPython() {
  const PATH = process.env.PATH || '';
  const dirs = PATH.split(path.delimiter).filter(Boolean);
  const exts = process.platform === 'win32' ? ['.exe', '.cmd', '.bat', ''] : [''];
  for (const name of ['python3', 'python', 'py']) {
    for (const d of dirs) {
      for (const x of exts) {
        const p = path.join(d, name + x);
        try {
          const st = fs.statSync(p);
          if (st.isFile()) { fs.accessSync(p, fs.constants.X_OK); return p; }
        } catch (e) { /* next */ }
      }
    }
  }
  return null;
}

// Runs the detector. Returns {kind, ...}
// kind: nopython | nodetector | timeout | failed(stderr,status) | empty | notreport | noscore | ok(report)
function runDetector(args, opts) {
  opts = opts || {};
  const py = findPython();
  if (!py) return { kind: 'nopython' };
  const det = findDetector();
  if (!det) return { kind: 'nodetector' };
  let r;
  try {
    r = cp.spawnSync(py, [det].concat(args), {
      input: opts.input, timeout: opts.timeout || 15000, maxBuffer: 64 * 1024 * 1024,
      encoding: 'utf8', env: process.env, cwd: opts.cwd || process.cwd(),
    });
  } catch (e) { return { kind: 'nopython' }; }
  if (r.error) {
    if (r.error.code === 'ENOENT' || r.error.code === 'EACCES') return { kind: 'nopython' };
    if (r.error.code === 'ETIMEDOUT') return { kind: 'timeout' };
    return { kind: 'failed', stderr: String(r.stderr || r.error.message || '').trim(), status: r.status };
  }
  if (r.signal === 'SIGTERM' && r.status === null) return { kind: 'timeout' };
  if (r.status !== 0) return { kind: 'failed', stderr: String(r.stderr || '').trim(), status: r.status };
  const out = String(r.stdout || '');
  if (!out.trim()) return { kind: 'empty' };
  let rep;
  try { rep = JSON.parse(out); } catch (e) { return { kind: 'notreport' }; }
  if (!rep || typeof rep !== 'object' || Array.isArray(rep) || !rep._metrics || typeof rep._metrics !== 'object') {
    return { kind: 'notreport' };
  }
  const s = rep._metrics.ai_tell_score;
  if (typeof s !== 'number' || !isFinite(s)) return { kind: 'noscore' };
  return { kind: 'ok', report: rep };
}

function hookPhrase(band) {
  switch (band) {
    case 'clean': return 'reads clean';
    case 'light tells': return 'reads mostly clean';
    case 'mixed': return 'reads with some AI tells';
    case 'heavy tells': return 'reads with heavy AI tells';
    default: return 'reads with pervasive AI tells';
  }
}

const ADVICE = new Set([4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68]);
function findingList(rep) {
  const out = [];
  for (const k of Object.keys(rep)) {
    if (k === '_metrics') continue;
    const n = parseInt(k, 10);
    const f = rep[k] || {};
    const advice = ADVICE.has(n) || k === '17_negative_parallelism' || k === '17_tailing_negation' && false;
    out.push({ key: k, num: n, label: String(f.label || k), count: f.count || 0, advice });
  }
  out.sort((a, b) => (a.advice - b.advice) || (b.count - a.count) || (a.num - b.num));
  return out;
}

// ---- ledger
function ledgerFile(sessionId) {
  if (!sessionId) return path.join(configDir(), '.prosecheck-ledger');
  const safe = String(sessionId).replace(/[^A-Za-z0-9_.-]/g, c => '%' + c.charCodeAt(0).toString(16));
  return path.join(configDir(), '.prosecheck-ledger-' + safe);
}
function pruneLedgers() {
  try {
    const dir = configDir();
    for (const n of fs.readdirSync(dir)) {
      if (n === '.prosecheck-ledger' || n.startsWith('.prosecheck-ledger-')) {
        const p = path.join(dir, n);
        try {
          const st = fs.statSync(p);
          if (Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) fs.unlinkSync(p);
        } catch (e) { /* ignore */ }
      }
    }
  } catch (e) { /* ignore */ }
}
function readLedger(sessionId) {
  const p = ledgerFile(sessionId);
  try {
    const st = fs.statSync(p);
    if (Date.now() - st.mtimeMs > LEDGER_MAX_AGE_MS) { try { fs.unlinkSync(p); } catch (e) { /* */ } return []; }
    const arr = JSON.parse(fs.readFileSync(p, 'utf8'));
    return Array.isArray(arr) ? arr : [];
  } catch (e) { return []; }
}
function appendLedger(sessionId, rec) {
  try {
    const arr = readLedger(sessionId);
    arr.push(rec);
    while (arr.length > LEDGER_MAX_RECORDS) arr.shift();
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(ledgerFile(sessionId), JSON.stringify(arr));
  } catch (e) { /* ignore */ }
}

// ---- writing contract
function contractText(level, opts) {
  opts = opts || {};
  const L = [];
  L.push('PROSE CONTRACT (level: ' + level + ')');
  L.push('Scope: prose deliverables only: documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and drafted text the user will publish or send.');
  L.push('This contract never touches source code, code comments, commit messages, JSON/YAML/config files, CLI output, logs, error messages, or the conversational register of chat. It composes with other modes: a chat-compression mode owns chat, a code-simplicity mode owns code, and this contract owns deliverable prose.');
  L.push('Rules for prose:');
  L.push('- Vary sentence length irregularly. No metronome and no mechanical short-long alternation.');
  L.push('- Banned vocabulary: ' + BANNED.join(', ') + '.');
  L.push('- Banned moves: rule-of-three flourishes, "it\'s not just X, it\'s Y", hedge stacking, signposting ("let\'s dive in"), empty pivots ("it\'s worth noting"), "In conclusion" or "Overall" closers, outcome-speculation tails, self-thoroughness, generic upbeat endings, and chatbot phrases ("I hope this helps").');
  L.push('- Em dash at most once per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.');
  L.push('- Factual or encyclopedic content stays neutral third person. First-person or opinion content may use contractions.');
  L.push('- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms. Never invent facts.');
  L.push('- End sections on a fact or an observation.');
  L.push('- Stay silent about this: never announce the contract, never name the tool, never report a score, a band, a pattern list, or a rewrite pass, and never offer a style choice.');
  if (level === 'full' || level === 'strict') {
    const target = level === 'strict' ? 20 : 40;
    const bandTxt = level === 'strict' ? 'the clean band' : 'the clean or light tells band';
    if (opts.portable) {
      L.push('Resolve the detector first: use CLAUDE_PLUGIN_ROOT when that variable is set, otherwise locate the prosecheck detector (scripts/detect.py) among installed skills and plugins.');
      L.push('After writing a prose file, run the detector (python3 detect.py FILE) on that file.');
    } else {
      const det = findDetector() || 'scripts/detect.py';
      L.push('After writing a prose file, run the detector on that file: python3 ' + det + ' FILE');
    }
    L.push('If the score is above ' + target + ' (target: ' + bandTxt + ', score at most ' + target + '), fix the flagged spans and run it again, keeping rhythm variation. At most two fix passes.');
    if (level === 'strict') {
      L.push('Finish by running the detector once more with --clean on the file and keep the scrubbed output.');
    }
  }
  return L.join('\n');
}

function welcomeText() {
  return [
    'prosecheck is installed and on. Saved prose is scored against 71 documented AI-writing patterns.',
    'Plain text is accepted up to 512 KB and archives and notebooks up to 4 MB; the detector scores the first 262,144 characters.',
    'There is no website and nothing is uploaded; everything runs locally. This welcome is shown once.',
    'Try /prosecheck doctor, /prosecheck check FILE, /prosecheck off, or /prosecheck help.',
    '',
  ].join('\n');
}

function cursorRuleCandidates() {
  return [path.join(pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc')];
}

module.exports = {
  WINDOW, WINDOW_TXT, PLAIN_CAP, ARCHIVE_CAP, PLAIN_EXT, ARCHIVE_EXT, LEVELS, LABEL_CAP, CHECK_LABEL_CAP, BANNED,
  configDir, pluginRoot, flagPath, readStored, envDefault, getLevel, flagExists, writeLevel, readStdinJson,
  findDetector, findPython, runDetector, hookPhrase, findingList, ledgerFile, pruneLedgers, readLedger, appendLedger,
  contractText, welcomeText, cursorRuleCandidates,
};
