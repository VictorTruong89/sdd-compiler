#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when flagged.
const fs = require('fs');
const path = require('path');
const lib = require('./prosecheck-lib.js');

const INSTR = new Set(['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory']);
const INSTR_EXACT = new Set(['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md']);
const MAX_PATHS = 16;
const SUPPORTED = new Set(['write', 'edit', 'multiedit', 'notebookedit', 'apply_patch']);

function patchPaths(body) {
  const out = [];
  if (typeof body !== 'string') return out;
  for (const line of body.split(/\r?\n/)) {
    const m = /^\*\*\* (?:Add File|Update File|Move to):(.*)$/.exec(line);
    if (m) {
      const p = m[1].trim();
      if (p) out.push(p);
    }
  }
  return out;
}

function collectPaths(payload) {
  const ti = payload.tool_input && typeof payload.tool_input === 'object' ? payload.tool_input : {};
  const name = String(payload.tool_name || '').toLowerCase();
  if (!SUPPORTED.has(name)) return [];
  let paths = [];
  if (name === 'apply_patch') {
    paths = patchPaths(ti.command).concat(patchPaths(ti.patch), patchPaths(ti.input));
  } else if (name === 'notebookedit') {
    if (typeof ti.notebook_path === 'string') paths.push(ti.notebook_path);
    else if (typeof ti.file_path === 'string') paths.push(ti.file_path);
  } else {
    if (typeof ti.file_path === 'string') paths.push(ti.file_path);
  }
  paths = paths.map(p => p.trim()).filter(Boolean);
  const seen = new Set();
  const res = [];
  for (const p of paths) {
    if (!seen.has(p)) { seen.add(p); res.push(p); }
    if (res.length >= MAX_PATHS) break;
  }
  return res;
}

function skipPath(abs, root) {
  const parts = abs.split(/[\\/]+/);
  if (parts.includes('node_modules') || parts.includes('.git')) return true;
  const r = path.resolve(root);
  if (abs === r || abs.startsWith(r + path.sep)) return true;
  const base = path.basename(abs).toLowerCase();
  if (INSTR_EXACT.has(base)) return true;
  const ext = path.extname(base);
  const stem = ext ? base.slice(0, -ext.length) : base;
  if (INSTR.has(stem) && !lib.PLAIN_EXT.includes(ext)) return true;
  return false;
}

function failReason(r) {
  switch (r.kind) {
    case 'nopython': return 'python not found';
    case 'nodetector': return 'detector script missing';
    case 'timeout': return 'detector timed out';
    case 'notreport': return 'detector output was not a structured report';
    case 'noscore': return 'report had no numeric score';
    default: return 'detector produced no usable result';
  }
}

try {
  const payload = lib.readStdinJson();
  const level = lib.getLevel();
  if (level === 'full' || level === 'strict') {
    const threshold = level === 'strict' ? 20 : 40;
    const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();
    const sid = typeof payload.session_id === 'string' ? payload.session_id : '';
    const lines = [];
    for (const p of collectPaths(payload)) {
      const abs = path.resolve(cwd, p);
      if (skipPath(abs, lib.pluginRoot())) continue;
      const base = path.basename(abs);
      const ext = path.extname(base).toLowerCase();
      const isPlain = lib.PLAIN_EXT.includes(ext);
      const isArchive = lib.ARCHIVE_EXT.includes(ext);
      if (ext === '.pdf' || ext === '.rtf') {
        lib.appendLedger(sid, { file: base, kind: 'binary', t: Date.now() });
        continue;
      }
      if (!isPlain && !isArchive) continue;
      let st;
      try { st = fs.statSync(abs); } catch (e) {
        lib.appendLedger(sid, { file: base, kind: 'failed', reason: 'file unreadable (not found)', t: Date.now() });
        continue;
      }
      if (!st.isFile()) continue;
      const cap = isPlain ? lib.PLAIN_CAP : lib.ARCHIVE_CAP;
      if (st.size > cap) {
        lib.appendLedger(sid, { file: base, kind: 'skipped', capKB: cap / 1024, t: Date.now() });
        continue;
      }
      const r = lib.runDetector(['--', abs], { timeout: isPlain ? 8000 : 15000 });
      if (r.kind !== 'ok') {
        lib.appendLedger(sid, { file: base, kind: 'failed', reason: failReason(r), t: Date.now() });
        continue;
      }
      const m = r.report._metrics;
      const labels = lib.findingList(r.report).map(f => f.label);
      const uniq = Array.from(new Set(labels)).slice(0, lib.LABEL_CAP);
      const flagged = m.ai_tell_score > threshold;
      lib.appendLedger(sid, {
        file: base, kind: 'scored', score: m.ai_tell_score, band: m.ai_tell_band, labels: uniq,
        flagged, truncated: !!m.truncated, t: Date.now(),
      });
      if (flagged) {
        const cov = m.truncated ? ', first ' + lib.WINDOW_TXT + ' characters only' : '';
        const note = m.truncated ? ' Only that prefix of the file was included in the score.' : '';
        lines.push('prosecheck: ' + base + ' ' + lib.hookPhrase(m.ai_tell_band) + ' (score ' + m.ai_tell_score +
          ', band ' + m.ai_tell_band + cov + '). Flagged: ' + (uniq.join('; ') || 'none') +
          '. Please fix the flagged spans and keep sentence rhythm varied.' + note);
      }
    }
    if (lines.length) {
      process.stdout.write(JSON.stringify({
        hookSpecificOutput: { hookEventName: 'PostToolUse', additionalContext: lines.join('\n') },
      }) + '\n');
    }
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
