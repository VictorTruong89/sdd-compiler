#!/usr/bin/env node
'use strict';
// Subagent-start hook: same contract inside the SubagentStart envelope.
const lib = require('./prosecheck-lib.js');
try {
  lib.readStdinJson();
  const level = lib.getLevel();
  if (level !== 'off') {
    process.stdout.write(JSON.stringify({
      hookSpecificOutput: { hookEventName: 'SubagentStart', additionalContext: lib.contractText(level, {}) },
    }) + '\n');
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
