#!/usr/bin/env node
'use strict';
// Session-start hook: emits the writing contract (and a one-time welcome).
const lib = require('./prosecheck-lib.js');
try {
  lib.readStdinJson();
  lib.pruneLedgers();
  const existed = lib.flagExists();
  const level = lib.getLevel();
  if (!existed) lib.writeLevel(level);
  if (level !== 'off') {
    let out = '';
    if (!existed) out += lib.welcomeText() + '\n';
    out += lib.contractText(level, {}) + '\n';
    process.stdout.write(out);
  }
} catch (e) { /* never fail the host */ }
process.exit(0);
