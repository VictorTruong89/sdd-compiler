"""Behavioural tests for the core Optlyn surface, run through the in-process runner."""

import os

from optlyn import (
    Choice,
    IntRange,
    argument,
    command,
    confirmation_option,
    custom_version_option,
    echo,
    get_current_context,
    group,
    option,
)
from optlyn.testing import CliRunner


def test_command_name_derivation_and_options():
    @command()
    @option("--count", type=int, default=1)
    @option("-v", "--verbose", is_flag=True)
    @argument("name")
    def say_hello(count, verbose, name):
        for _ in range(count):
            echo(f"hi {name} {verbose}")

    assert say_hello.name == "say-hello"
    r = CliRunner().invoke(say_hello, ["--count", "2", "-v", "Bob"])
    assert r.exit_code == 0
    assert r.output == "hi Bob True\nhi Bob True\n"


def test_stacked_flags_and_double_dash():
    @command()
    @option("-a", is_flag=True)
    @option("-b", is_flag=True)
    @argument("rest", nargs=-1)
    def stack(a, b, rest):
        echo(f"{a} {b} {rest}")

    r = CliRunner().invoke(stack, ["-ab", "--", "--x"])
    assert r.output == "True True ('--x',)\n"


def test_usage_error_exit_status_and_message():
    @command()
    @option("--count", type=int)
    def cmd(count):
        echo("ran")

    r = CliRunner().invoke(cmd, ["--count", "x"])
    assert r.exit_code == 2
    assert "Invalid value for '--count'" in r.stderr
    assert "ran" not in r.output


def test_group_callback_runs_before_child_and_nests():
    @group()
    @option("--debug", is_flag=True)
    def cli(debug):
        echo(f"debug={debug}")

    @cli.group()
    def inner():
        pass

    @inner.command()
    def leaf():
        echo("leaf")

    r = CliRunner().invoke(cli, ["--debug", "inner", "leaf"])
    assert r.output == "debug=True\nleaf\n"


def test_missing_subcommand_is_usage_failure_with_help():
    @group()
    def cli():
        pass

    r = CliRunner().invoke(cli, [])
    assert r.exit_code == 2
    assert "Usage:" in r.stderr


def test_intentional_help_is_success_and_skips_callback():
    @command()
    @option("--x")
    def cmd(x):
        """Does things."""
        echo("should not run")

    r = CliRunner().invoke(cmd, ["--help"])
    assert r.exit_code == 0
    assert "Does things." in r.stdout
    assert "should not run" not in r.output


def test_choice_and_range_conversion():
    @command()
    @option("--color", type=Choice(["red", "green"]), default="red")
    @option("--n", type=IntRange(0, 10, clamp=True), default=5)
    def pick(color, n):
        echo(f"{color} {n}")

    assert CliRunner().invoke(pick, ["--color", "green", "--n", "99"]).output == "green 10\n"
    assert CliRunner().invoke(pick, ["--color", "blue"]).exit_code == 2


def test_prompt_reads_from_input_when_flag_has_no_value():
    @command()
    @option("--name", prompt=True)
    def ask(name):
        echo(f"name={name}")

    r = CliRunner().invoke(ask, ["--name"], input="Bo\n")
    assert r.exit_code == 0
    assert r.output.endswith("name=Bo\n")


def test_environment_and_auto_prefix_and_default_map():
    @command()
    @option("--a")
    @option("--b", envvar="BEE")
    def cmd(a, b):
        echo(f"{a} {b}")

    r = CliRunner().invoke(cmd, [], auto_envvar_prefix="MYAPP", env={"MYAPP_A": "fromenv", "BEE": "bee"})
    assert r.output == "fromenv bee\n"
    r = CliRunner().invoke(cmd, [], default_map={"a": "mapped"}, env={"BEE": None})
    assert r.output == "mapped None\n"


def test_parameter_source_reporting():
    @command()
    @option("--n", type=int, default=3)
    def cmd(n):
        ctx = get_current_context()
        echo(f"{ctx.get_parameter_source('n')} {ctx.get_parameter_source('zz')}")

    assert CliRunner().invoke(cmd, ["--n", "4"]).output == "ParameterSource.COMMANDLINE None\n"


def test_custom_version_identity_is_exact():
    @command()
    @custom_version_option(lambda ctx: "build 42")
    def cmd():
        echo("body")

    r = CliRunner().invoke(cmd, ["--version"])
    assert r.output == "build 42\n"


def test_confirmation_option_aborts_on_decline():
    @command()
    @confirmation_option()
    def dangerous():
        echo("doing it")

    assert CliRunner().invoke(dangerous, [], input="n\n").exit_code == 1
    assert CliRunner().invoke(dangerous, ["--yes"]).output == "doing it\n"


def test_chaining_group_collects_results():
    @group(chain=True)
    def chained():
        pass

    @chained.command()
    @option("--k", type=int)
    def one(k):
        return ("one", k)

    @chained.command()
    @argument("w")
    def two(w):
        return ("two", w)

    @chained.result_callback()
    def done(results, **params):
        echo(repr(results))

    r = CliRunner().invoke(chained, ["one", "--k", "1", "two", "z"])
    assert r.output == "[('one', 1), ('two', 'z')]\n"


def test_completion_suggests_subcommands_and_options():
    @group()
    def comp():
        pass

    @comp.command()
    @option("--color", type=Choice(["red", "green"]))
    def run(color):
        pass

    os.environ["_COMP_COMPLETE"] = "bash_complete"
    try:
        os.environ["COMP_WORDS"] = "comp run --"
        os.environ["COMP_CWORD"] = "2"
        assert "--color" in CliRunner().invoke(comp, []).stdout.split()
        os.environ["COMP_WORDS"] = "comp run --color "
        os.environ["COMP_CWORD"] = "3"
        assert CliRunner().invoke(comp, []).stdout.split() == ["red", "green"]
        os.environ["_COMP_COMPLETE"] = "bogus"
        assert CliRunner().invoke(comp, []).exit_code == 1
    finally:
        for key in ("_COMP_COMPLETE", "COMP_WORDS", "COMP_CWORD"):
            os.environ.pop(key, None)


def test_isolated_filesystem_changes_directory():
    runner = CliRunner()
    before = os.getcwd()
    with runner.isolated_filesystem() as path:
        assert os.getcwd() == os.path.realpath(path)
    assert os.getcwd() == before
