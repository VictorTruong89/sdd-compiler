"""Terminal helpers, file opening, and the thread-local context stack (FP-07, FP-08, FP-09, FP-11)."""

import contextlib
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import threading
import time

from .exceptions import Abort, FileError
from .param_types import convert_type

_local = threading.local()

_ANSI_RE = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")

_COLORS = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "reset": 39,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
}

_STYLE_CODES = {
    "bold": 1,
    "dim": 2,
    "italic": 3,
    "underline": 4,
    "blink": 5,
    "reverse": 7,
    "strikethrough": 9,
    "overline": 53,
}


# --- thread-local context -------------------------------------------------


def _stack():
    if not hasattr(_local, "stack"):
        _local.stack = []
    return _local.stack


def push_context(ctx):
    _stack().append(ctx)


def pop_context():
    _stack().pop()


def get_current_context(silent=False):
    """Return the context current on this thread, or None / raise when there is none."""
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


def _current_color():
    ctx = get_current_context(silent=True)
    return None if ctx is None else ctx.color


# --- styling ----------------------------------------------------------------


def unstyle(text):
    """Remove ANSI escape sequences from ``text``."""
    return _ANSI_RE.sub("", text)


def _color_code(color, background):
    if isinstance(color, bool):
        raise TypeError("color must be a name, an int, or an RGB sequence")
    if isinstance(color, str):
        if color not in _COLORS:
            raise ValueError(f"unknown color {color!r}")
        base = _COLORS[color]
        if background:
            if color == "reset":
                return "49"
            return str(base + 10)
        return str(base)
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ValueError("256-color values must be between 0 and 255")
        return f"{48 if background else 38};5;{color}"
    if isinstance(color, (list, tuple)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return f"{48 if background else 38};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"invalid color: {color!r}")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
):
    """Wrap ``text`` in ANSI SGR sequences. Invalid colors raise."""
    codes = []
    if fg is not None:
        codes.append(_color_code(fg, False))
    if bg is not None:
        codes.append(_color_code(bg, True))
    switches = {
        "bold": bold,
        "dim": dim,
        "underline": underline,
        "overline": overline,
        "italic": italic,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for name, on in switches.items():
        if on:
            codes.append(str(_STYLE_CODES[name]))
    if not codes:
        return str(text)
    prefix = f"\033[{';'.join(codes)}m"
    return f"{prefix}{text}\033[0m" if reset else f"{prefix}{text}"


def is_interactive():
    """True when standard input or standard output is attached to a terminal."""
    return _isatty(sys.stdin) or _isatty(sys.stdout)


def _isatty(stream):
    try:
        return stream is not None and bool(stream.isatty())
    except (AttributeError, ValueError):
        return False


def _ascii_encoding(stream):
    enc = (getattr(stream, "encoding", None) or "ascii").lower()
    return enc.replace("-", "").replace("_", "") in ("ascii", "usascii", "ansix3.41968")


def _write_text(stream, text):
    buffer = getattr(stream, "buffer", None)
    if _ascii_encoding(stream) and buffer is not None:
        stream.flush()
        buffer.write(text.encode("utf-8"))
        buffer.flush()
        return
    try:
        stream.write(text)
    except UnicodeEncodeError:
        stream.flush()
        if buffer is not None:
            buffer.write(text.encode("utf-8"))
            buffer.flush()
        else:
            raise


def _target_stream(file, err):
    if file is not None:
        return file
    return sys.stderr if err else sys.stdout


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes; strips styles unless the stream is a terminal or color is forced."""
    stream = _target_stream(file, err)
    if message is None:
        message = ""
    if isinstance(message, bytes):
        stream.flush()
        stream.buffer.write(message + (b"\n" if nl else b""))
        stream.buffer.flush()
        return
    if not isinstance(message, str):
        message = str(message)
    flag = color if color is not None else _current_color()
    keep_styles = flag if flag is not None else _isatty(stream)
    if not keep_styles:
        message = unstyle(message)
    if nl:
        message += "\n"
    _write_text(stream, message)
    stream.flush()


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


# --- input ------------------------------------------------------------------


def _read_line(hide_input):
    stdin = sys.stdin
    if hide_input and _isatty(stdin):
        try:
            import termios

            fd = stdin.fileno()
            old = termios.tcgetattr(fd)
            new = termios.tcgetattr(fd)
            new[3] &= ~termios.ECHO
            termios.tcsetattr(fd, termios.TCSADRAIN, new)
            try:
                line = stdin.readline()
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
                sys.stdout.write("\n")
                sys.stdout.flush()
        except (ImportError, OSError, ValueError):
            line = stdin.readline()
    else:
        line = stdin.readline()
        if not line:
            raise Abort()
        if not hide_input and not _isatty(stdin):
            # Visible prompts echo the typed line so captured output reads naturally.
            sys.stdout.write(line if line.endswith("\n") else line + "\n")
            sys.stdout.flush()
    if not line:
        raise Abort()
    return line.rstrip("\r\n")


def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    show_default=True,
    err=False,
    **_ignored,
):
    """Ask for a value, convert it, and re-ask on conversion failure."""
    param_type = convert_type(type, default)
    dflt = default() if callable(default) else default
    suffix = ""
    if dflt is not None and show_default:
        shown = "*****" if hide_input else dflt
        suffix = f" [{shown}]"
    while True:
        out = sys.stderr if err else sys.stdout
        out.write(f"{text}{suffix}: ")
        out.flush()
        value = _read_line(hide_input)
        if value == "" and dflt is not None:
            value = dflt
        if confirmation_prompt:
            out.write("Repeat for confirmation: ")
            out.flush()
            again = _read_line(hide_input)
            if again != value:
                echo("Error: The two entered values do not match.", err=err)
                continue
        try:
            return param_type.convert(value)
        except Exception as exc:  # usage failure: re-ask until valid or EOF
            echo(f"Error: {getattr(exc, 'message', exc)}", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question. Empty input takes ``default``; anything else re-asks."""
    hint = "[Y/n]" if default else "[y/N]"
    out = sys.stderr if err else sys.stdout
    while True:
        out.write(f"{text} {hint if show_default else ''}{prompt_suffix}")
        out.flush()
        answer = _read_line(False).strip().lower()
        if answer == "":
            value = default
            break
        if answer in ("y", "yes"):
            value = True
            break
        if answer in ("n", "no"):
            value = False
            break
    if abort and not value:
        raise Abort()
    return value


def getchar(echo=False):
    """Read one character from the terminal (``/dev/tty`` when available)."""
    try:
        import termios
        import tty

        fd = os.open("/dev/tty", os.O_RDONLY)
        try:
            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                ch = os.read(fd, 1).decode("utf-8", "replace")
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        finally:
            os.close(fd)
    except (ImportError, OSError, termios_error()):
        ch = sys.stdin.read(1)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04" or ch == "":
        raise EOFError()
    if echo:
        echo(ch, nl=False)
    return ch


def termios_error():
    try:
        import termios

        return termios.error
    except ImportError:
        return OSError


def pause(info=None, err=False):
    """Wait for a key press when interactive; do nothing otherwise."""
    if not is_interactive():
        return
    echo(info or "Press any key to continue...", err=err)
    try:
        getchar()
    except (EOFError, KeyboardInterrupt):
        pass


# --- progress -----------------------------------------------------------------


class ProgressBar:
    """Context manager and iterator wrapper showing progress on a terminal."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, file=None, width=36):
        self.iterable = iterable
        if length is None and iterable is not None and hasattr(iterable, "__len__"):
            length = len(iterable)
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.file = file or sys.stdout
        self.width = width
        self.pos = 0
        self.start = time.time()
        self.show = (not hidden) and _isatty(self.file)
        if not self.show and not hidden and self.label:
            echo(self.label, file=self.file)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.show:
            echo("", file=self.file)

    def __iter__(self):
        if self.iterable is None:
            raise TypeError("progress bar has no iterable")
        self.render()
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps=1):
        self.pos += n_steps
        self.render()

    def eta(self):
        if not self.length or self.pos == 0:
            return None
        elapsed = time.time() - self.start
        return max(0.0, elapsed / self.pos * (self.length - self.pos))

    def render(self):
        if not self.show:
            return
        if self.length:
            filled = int(self.width * min(self.pos, self.length) / self.length)
            bar = "#" * filled + " " * (self.width - filled)
            eta = self.eta()
            eta_text = "" if eta is None else f"  eta {int(eta)}s"
            text = f"\r{self.label} [{bar}] {self.pos}/{self.length}{eta_text}"
        else:
            text = f"\r{self.label} {self.pos}"
        self.file.write(text)
        self.file.flush()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


# --- editor, launcher, screen, app dirs ----------------------------------------


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor. Returns the saved text, or None when unsaved or a filename was given."""
    if sys.platform == "win32":
        default_editor = "notepad"
    else:
        default_editor = "vi"
    command = shlex.split(editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or default_editor)
    run_env = dict(os.environ)
    if env:
        run_env.update(env)
    if filename is not None:
        subprocess.call(command + [os.fspath(filename)], env=run_env)
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(text or "")
        before = os.stat(path).st_mtime_ns
        subprocess.call(command + [path], env=run_env)
        with open(path, encoding="utf-8", newline="") as f:
            result = f.read()
        changed = os.stat(path).st_mtime_ns != before
        if require_save and not changed:
            return None
        return result
    finally:
        os.remove(path)


def launch(url, wait=False, locate=False):
    """Open ``url`` or a path with the default application. Returns the process status."""
    if sys.platform == "win32":
        os.startfile(url)  # noqa: S606 - documented platform behaviour
        return 0
    if sys.platform == "darwin":
        args = ["open"]
        if locate:
            args.append("-R")
    else:
        args = ["xdg-open"]
        if locate:
            url = os.path.dirname(os.path.abspath(url))
    try:
        proc = subprocess.Popen(args + [url])
    except FileNotFoundError:
        return 127
    return proc.wait() if wait else 0


def clear():
    """Clear the terminal; does nothing when not connected to one."""
    if not _isatty(sys.stdout):
        return
    sys.stdout.write("\033[2J\033[1;1H")
    sys.stdout.flush()


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Per-user config directory for ``app_name`` on the current platform."""
    home = os.path.expanduser("~")
    if sys.platform == "win32" and not force_posix:
        base = os.environ.get("APPDATA" if roaming else "LOCALAPPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    if force_posix:
        return os.path.join(home, "." + re.sub(r"\s+", "-", app_name.lower()))
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(config_home, folder)


def format_filename(filename, shorten=False):
    """Text form of a path that prints and encodes as UTF-8 without failing."""
    if isinstance(filename, bytes):
        name = os.fsdecode(filename)
    else:
        name = os.fspath(filename)
    if shorten:
        name = os.path.basename(name)
    # Undecodable bytes survive as surrogates; escape them so distinct names stay distinct.
    return name.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")


# --- file opening ---------------------------------------------------------------


class _NonClosing:
    """Wraps a standard stream so that closing it is a no-op."""

    def __init__(self, stream):
        self._stream = stream

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def close(self):
        self._stream.flush()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


class _AtomicFile:
    """Writes to a sibling temporary file; replaces the target on close."""

    def __init__(self, filename, mode, encoding, errors):
        self._target = filename
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        os.close(fd)
        kwargs = {} if "b" in mode else {"encoding": encoding, "errors": errors}
        self._f = open(self._tmp, mode, **kwargs)  # noqa: SIM115 - closed in close()

    def __getattr__(self, name):
        return getattr(self._f, name)

    def close(self):
        if self._f.closed:
            return
        self._f.close()
        os.replace(self._tmp, self._target)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


def _open_now(filename, mode, encoding, errors, atomic):
    if atomic and ("w" in mode or "a" in mode):
        return _AtomicFile(filename, mode, encoding, errors)
    kwargs = {} if "b" in mode else {"encoding": encoding, "errors": errors}
    return open(filename, mode, **kwargs)  # noqa: SIM115 - returned to the caller


class _LazyFile:
    """Opens its real file on first I/O. Failures there are general file errors."""

    def __init__(self, filename, mode, encoding, errors, atomic):
        self.name = filename
        self._args = (filename, mode, encoding, errors, atomic)
        self._f = None
        self._closed = False

    def _real(self):
        if self._f is None:
            try:
                self._f = _open_now(*self._args)
            except OSError as exc:
                raise FileError(f"Could not open file '{self.name}': {exc.strerror or exc}") from exc
        return self._f

    def __getattr__(self, name):
        return getattr(self._real(), name)

    @property
    def closed(self):
        return self._closed

    def close(self):
        if self._f is not None:
            self._f.close()
        self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file; ``-`` is standard input for reading and standard output for writing."""
    writing = "w" in mode or "a" in mode
    if filename == "-":
        binary = "b" in mode
        if writing:
            stream = sys.stdout.buffer if binary else sys.stdout
        else:
            stream = sys.stdin.buffer if binary else sys.stdin
        return _NonClosing(stream)
    if lazy:
        return _LazyFile(filename, mode, encoding, errors, atomic)
    return _open_now(filename, mode, encoding, errors, atomic)


# --- pager ----------------------------------------------------------------------


def _pager_command():
    pager = os.environ.get("PAGER")
    if pager:
        return shlex.split(pager)
    return ["less"] if shutil.which("less") else ["more"]


def echo_via_pager(text_or_generator, color=None):
    """Write text through a pager when interactive; otherwise write it to standard output."""
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    if not is_interactive():
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    try:
        proc = subprocess.Popen(_pager_command(), stdin=subprocess.PIPE, text=True)
    except (FileNotFoundError, OSError):
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    try:
        for chunk in chunks:
            proc.stdin.write(chunk if color else unstyle(chunk))
            proc.stdin.flush()
    except BrokenPipeError:
        pass
    finally:
        try:
            proc.stdin.close()
        except BrokenPipeError:
            pass
        proc.wait()


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream that is shown through the pager when interactive."""
    if not is_interactive():
        yield _NonClosing(sys.stdout)
        return
    import io

    buffer = io.StringIO()
    try:
        yield buffer
    finally:
        echo_via_pager(buffer.getvalue(), color=color)
