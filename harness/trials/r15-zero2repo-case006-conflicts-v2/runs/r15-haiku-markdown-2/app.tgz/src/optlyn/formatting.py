"""Text wrapping and two-column layout for help pages."""

import textwrap

DEFAULT_WRAP_WIDTH = 100  # wrap_text default; help pages use their own 80-column cap
BACKSPACE_MARK = "\b"


def wrap_text(
    text,
    width=DEFAULT_WRAP_WIDTH,
    initial_indent="",
    subsequent_indent="",
    preserve_paragraphs=False,
):
    """Rewrap ``text`` to ``width``. Any string is accepted.

    With ``preserve_paragraphs``, blank lines separate paragraphs; a paragraph whose
    first line is a lone backspace keeps its line breaks.
    """
    width = max(width, 1)
    if not preserve_paragraphs:
        return textwrap.fill(
            " ".join(text.split()),
            width=width,
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
            break_long_words=True,
            break_on_hyphens=False,
        ) if text.strip() else ""
    out = []
    for block in split_paragraphs(text):
        if block[0].strip() == BACKSPACE_MARK:
            kept = [line for line in block[1:]]
            out.append("\n".join(initial_indent + line for line in kept))
            continue
        out.append(
            textwrap.fill(
                " ".join(line.strip() for line in block),
                width=width,
                initial_indent=initial_indent,
                subsequent_indent=subsequent_indent,
                break_long_words=True,
                break_on_hyphens=False,
            )
        )
    return "\n\n".join(out)


def split_paragraphs(text):
    """Split into lists of lines, separated by blank lines."""
    paragraphs = []
    current = []
    for line in text.splitlines():
        if line.strip():
            current.append(line)
        elif current:
            paragraphs.append(current)
            current = []
    if current:
        paragraphs.append(current)
    return paragraphs


def ellipsize(text, width):
    if len(text) <= width:
        return text
    if width <= 3:
        return text[:width]
    return text[: width - 3].rstrip() + "..."


def format_two_columns(rows, width, col_max=30, indent=2, spacing=2):
    """Render ``(first, second)`` rows; long first cells push their help to the next line."""
    if not rows:
        return []
    first_w = min(max(len(first) for first, _ in rows), col_max)
    help_indent = " " * (indent + first_w + spacing)
    help_w = max(width - len(help_indent), 10)
    lines = []
    for first, second in rows:
        if not second:
            lines.append(" " * indent + first)
            continue
        wrapped = wrap_text(second, width=help_w).split("\n")
        if len(first) <= first_w:
            # Help sits beside a short name; a long name pushes help onto its own lines.
            lines.append(" " * indent + first.ljust(first_w) + " " * spacing + wrapped[0])
        else:
            lines.append(" " * indent + first)
            lines.append(help_indent + wrapped[0])
        lines.extend(help_indent + extra for extra in wrapped[1:])
    return lines
