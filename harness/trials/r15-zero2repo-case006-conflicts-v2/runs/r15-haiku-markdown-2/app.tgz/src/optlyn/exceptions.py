"""Exceptions and exit statuses.

Standalone mode maps these onto the exit classes in the Interface Contract:
usage errors exit with 2, aborts and other library errors with 1.
"""


class OptlynError(Exception):
    """Base class for library-signalled errors (general error class, exit 1)."""

    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def show(self):
        from .utils import echo

        echo(f"Error: {self.message}", err=True)


class UsageError(OptlynError):
    """Incorrect use of a command line (usage-error class, exit 2)."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self):
        from .utils import echo

        # A message of None means the help page already explained the problem.
        if self.message is None:
            return
        if self.ctx is not None:
            echo(self.ctx.get_usage(), err=True)
            echo(
                f"Try '{self.ctx.command_path} {self.ctx.help_option_names[0]}' for help.",
                err=True,
            )
            echo("", err=True)
        echo(f"Error: {self.format_message()}", err=True)

    def format_message(self):
        return self.message


class BadParameter(UsageError):
    """A value was refused, by a type or by a parameter callback."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.param_hint:
            return f"Invalid value for {self.param_hint}: {self.message}"
        return self.message


class MissingParameter(UsageError):
    """A required parameter received no value from any source."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint


class NoSuchOption(UsageError):
    """An option token that the command does not declare."""

    def __init__(self, option_name, message=None, ctx=None):
        super().__init__(message or f"No such option: {option_name}", ctx)
        self.option_name = option_name


class FileError(OptlynError):
    """A file could not be opened when I/O started (general error class, exit 1)."""


class Abort(RuntimeError):
    """The user or the author aborted the run (abort class, exit 1)."""

    def show(self):
        from .utils import echo

        echo("Aborted!", err=True)


class Exit(RuntimeError):
    """An author clean stop, or an intentional help/version exit."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
