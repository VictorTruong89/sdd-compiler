"""Shell completion: registration scripts and suggestion output (FP-12)."""

import os

from .core import Context, Group
from .param_types import Path
from .utils import echo

SHELLS = ("bash", "zsh", "fish", "powershell")
_FILE_PREFIX = "<file> "
_DIR_PREFIX = "<dir> "


class CompletionItem:
    """A suggested value, with optional help text and a kind ("plain" for ordinary values)."""

    def __init__(self, value, help=None, kind="plain"):
        self.value = value
        self.help = help
        self.type = kind


def complete_var_name(prog_name):
    """``_<PROG>_COMPLETE`` with the program name upper-cased and dashes turned into underscores."""
    return "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"


def run_completion(cmd, prog_name, instruction):
    """Handle a completion instruction. Returns the process exit status."""
    shell, _, action = instruction.partition("_")
    if shell not in SHELLS or action not in ("source", "complete"):
        echo(f"Error: unrecognized completion instruction {instruction!r}.", err=True)
        return 1
    if action == "source":
        echo(source_script(shell, prog_name, complete_var_name(prog_name)))
        return 0
    words = os.environ.get("COMP_WORDS", "")
    cword = os.environ.get("COMP_CWORD", "")
    for item in suggestions(cmd, prog_name, shell, words, cword):
        echo(_format_item(shell, item))
    return 0


def _format_item(shell, item):
    if item.type == "file":
        return _FILE_PREFIX + item.value
    if item.type == "dir":
        return _DIR_PREFIX + item.value
    if shell == "zsh":
        value = item.value.replace(":", "\\:")
        return f"{value}:{item.help}" if item.help else value
    if shell == "fish" and item.help:
        return f"{item.value}\t{item.help}"
    return item.value


def _split_words(shell, words, cword):
    """Return (completed argument tokens, incomplete token)."""
    parts = words.split(" ") if words else []
    if shell == "fish":
        incomplete = cword or ""
        args = parts[1:]
        if args and incomplete and args[-1] == incomplete:
            args = args[:-1]
        return args, incomplete
    try:
        index = int(cword)
    except (TypeError, ValueError):
        index = len(parts)
    args = parts[1:index]
    incomplete = parts[index] if index < len(parts) else ""
    return args, incomplete


def _flag_map(cmd):
    flags = {}
    for p in cmd.options:
        for f in p.all_flag_names():
            flags[f] = p
    return flags


def _locate(root, args):
    """Walk completed tokens to the command they address. Returns (command, pending option)."""
    current = root
    pending = None
    for tok in args:
        if pending is not None:
            pending = None
            continue
        if len(tok) > 1 and tok[0] == "-":
            param = _flag_map(current).get(tok)
            if param is not None and param.consumes_value:
                pending = param
            continue
        if isinstance(current, Group):
            child = current.get_command(None, tok)
            if child is not None:
                current = child
    return current, pending


def suggestions(root, prog_name, shell, words, cword):
    """Suggestions for the incomplete token of the command line."""
    args, incomplete = _split_words(shell, words, cword)
    current, pending = _locate(root, args)
    ctx = Context(root, info_name=prog_name)
    if pending is not None:
        return _value_items(ctx, pending, incomplete)
    if incomplete.startswith("-"):
        items = []
        for p in current.options:
            if p.hidden:
                continue
            for flag in p.all_flag_names():
                if flag.startswith(incomplete):
                    items.append(CompletionItem(flag, help=p.help))
        if "--help".startswith(incomplete) and not any(i.value == "--help" for i in items):
            items.append(CompletionItem("--help", help="Show this message and exit."))
        return items
    items = []
    if isinstance(current, Group):
        for name in current.list_commands(None):
            child = current.get_command(None, name)
            if child is None or child.hidden or not name.startswith(incomplete):
                continue
            short = child.short_help or ""
            items.append(CompletionItem(name, help=short))
    for arg in current.arguments:
        if isinstance(arg.type, Path) or getattr(arg.type, "name", "") in ("filename",):
            items.extend(_value_items(ctx, arg, incomplete))
            break
    return items


def _value_items(ctx, param, incomplete):
    if param.shell_complete_func is not None:
        raw = param.shell_complete_func(ctx, param, incomplete)
    else:
        raw = param.type.shell_complete(ctx, param, incomplete)
    items = []
    for entry in raw or ():
        if isinstance(entry, CompletionItem):
            items.append(entry)
        elif isinstance(entry, str):
            items.append(CompletionItem(entry))
        else:
            items.append(CompletionItem(entry.value, getattr(entry, "help", None), getattr(entry, "type", "plain")))
    return items


def source_script(shell, prog_name, var):
    """The registration script the user sources for ``shell``."""
    fn = prog_name.replace("-", "_")
    if shell == "bash":
        return f"""_{fn}_completion() {{
    local IFS=$'\\n'
    local cur="${{COMP_WORDS[COMP_CWORD]}}"
    local entry response
    response=$(env COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD {var}=bash_complete {prog_name})
    COMPREPLY=()
    for entry in $response; do
        case "$entry" in
            "{_FILE_PREFIX}"*) COMPREPLY+=($(compgen -f -- "$cur"));;
            "{_DIR_PREFIX}"*) COMPREPLY+=($(compgen -d -- "$cur"));;
            *) COMPREPLY+=("$entry");;
        esac
    done
    return 0
}}
complete -o default -F _{fn}_completion {prog_name}"""
    if shell == "zsh":
        return f"""#compdef {prog_name}
_{fn}_completion() {{
    local -a items
    items=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog_name})}}")
    _describe 'values' items
}}
compdef _{fn}_completion {prog_name}"""
    if shell == "fish":
        return (
            f"complete -c {prog_name} -f -a '(env {var}=fish_complete "
            f"COMP_WORDS=\"(commandline -opc | string join ' ')\" "
            f"COMP_CWORD=\"(commandline -ct)\" {prog_name})'"
        )
    return f"""Register-ArgumentCompleter -Native -CommandName '{prog_name}' -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $env:COMP_WORDS = $commandAst.ToString()
    $env:COMP_CWORD = $wordToComplete
    $env:{var} = 'powershell_complete'
    & '{prog_name}' | ForEach-Object {{
        [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_)
    }}
    Remove-Item Env:{var}
}}"""
