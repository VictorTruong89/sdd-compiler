"""Declaration decorators: commands, groups, parameters, and ready-made options."""

import functools
import importlib.metadata

from .core import Argument, Command, Group, Option, _help_callback
from .utils import confirm, echo, get_current_context


def _attach_param(f, param):
    # Decorators run bottom-up; inserting at the front keeps declaration order top-down.
    f.__dict__.setdefault("__optlyn_params__", []).insert(0, param)
    return f


def _pop_params(f):
    return list(f.__dict__.pop("__optlyn_params__", []))


def _derive_name(func_name):
    name = func_name.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def option(*param_decls, cls=None, **attrs):
    """Attach an option to the function that the decorator is applied to."""
    cls = cls or Option

    def decorator(f):
        return _attach_param(f, cls(param_decls, **attrs))

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to the function that the decorator is applied to."""
    cls = cls or Argument

    def decorator(f):
        return _attach_param(f, cls(param_decls, **attrs))

    return decorator


def command(name=None, cls=None, **attrs):
    """Turn a function into a command. Works bare (``@command``) or called (``@command()``)."""
    if callable(name) and not isinstance(name, str):
        return command(None, cls, **attrs)(name)
    cls = cls or Command

    def decorator(f):
        cmd_name = name if name is not None else _derive_name(f.__name__)
        return cls(cmd_name, callback=f, params=_pop_params(f), **attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a group. Works bare (``@group``) or called (``@group()``)."""
    if callable(name) and not isinstance(name, str):
        return group(None, cls, **attrs)(name)
    cls = cls or Group

    def decorator(f):
        grp_name = name if name is not None else _derive_name(f.__name__)
        return cls(grp_name, callback=f, params=_pop_params(f), **attrs)

    return decorator


def help_option(*param_decls, **kwargs):
    """An extra eager help flag. It prints help and exits like the automatic one."""
    decls = param_decls or ("--help",)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("callback", _help_callback)
    return option(*decls, **kwargs)


def _detect_version(package_name):
    try:
        return importlib.metadata.version(package_name)
    except importlib.metadata.PackageNotFoundError:
        pass
    # Not a distribution name: treat it as an import name and use the distribution providing it.
    providers = importlib.metadata.packages_distributions().get(package_name, [])
    if providers:
        return importlib.metadata.version(providers[0])
    raise RuntimeError(f"Could not determine the version for {package_name!r}.")


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """An eager version flag. The identity is ``version``, or detected from ``package_name``."""
    decls = param_decls or ("--version",)

    def callback(ctx, param, value):
        if not value:
            return value
        prog = prog_name or ctx.find_root().info_name
        ident = version
        if ident is None:
            ident = _detect_version(package_name or prog)
        template = message or "%(prog)s, version %(version)s"
        echo(template % {"prog": prog, "version": ident}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("help", "Show the version and exit.")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    return option(*decls, callback=callback, **kwargs)


def custom_version_option(callback_fn, *param_decls, **kwargs):
    """An eager version flag whose whole identity is what ``callback_fn(ctx)`` returns."""
    decls = param_decls or ("--version",)

    def callback(ctx, param, value):
        if not value:
            return value
        echo(callback_fn(ctx), color=True)
        ctx.exit()

    kwargs.setdefault("help", "Show the version and exit.")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    return option(*decls, callback=callback, **kwargs)


def password_option(*param_decls, **kwargs):
    """A hidden prompt that asks twice."""
    decls = param_decls or ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    """A yes flag. When omitted, the user is asked; declining aborts the run."""
    decls = param_decls or ("--yes",)
    question = kwargs.pop("prompt", "Do you want to continue?")

    def callback(ctx, param, value):
        if not value:
            confirm(question, abort=True)
        return value

    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs["callback"] = callback
    return option(*decls, **kwargs)


def pass_context(f):
    """Pass the current invocation context as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    """Pass the current context's author object as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Pass the nearest object of ``object_type`` (created when ``ensure`` and none exists)."""

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            return f(obj, *args, **kwargs)

        return new_func

    return decorator
