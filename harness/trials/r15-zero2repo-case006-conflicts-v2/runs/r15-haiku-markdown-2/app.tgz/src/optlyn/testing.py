"""In-process runner: invoke a command with tokens and capture its output (FP-14)."""

import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile


class Result:
    """Outcome of ``CliRunner.invoke``."""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code, exception, exc_info):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class _Sink(io.RawIOBase):
    """A raw stream that records writes both per-stream and in combined write order."""

    def __init__(self, own, combined):
        self._own = own
        self._combined = combined

    def writable(self):
        return True

    def write(self, data):
        self._own.write(data)
        self._combined.write(data)
        return len(data)


class _EchoingStdin(io.TextIOWrapper):
    """Standard input that echoes what was actually read into captured output."""

    def __init__(self, buffer, encoding, echo_to):
        super().__init__(buffer, encoding=encoding)
        self._echo_to = echo_to

    def readline(self, *args):
        line = super().readline(*args)
        if line:
            self._echo_to.write(line)
            self._echo_to.flush()
        return line


class CliRunner:
    """Runs a command in-process with argument tokens, input, and environment overrides."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        if args is None:
            args = []
        elif isinstance(args, str):
            args = shlex.split(args)
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)

        own_out, own_err, combined = io.BytesIO(), io.BytesIO(), io.BytesIO()
        out_stream = io.TextIOWrapper(_Sink(own_out, combined), encoding=self.charset, write_through=True)
        err_stream = io.TextIOWrapper(_Sink(own_err, combined), encoding=self.charset, write_through=True)
        in_stream = _EchoingStdin(io.BytesIO(data), self.charset, out_stream) if self.echo_stdin else io.TextIOWrapper(
            io.BytesIO(data), encoding=self.charset
        )

        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {}
        for key, value in merged_env.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
        standalone = extra.pop("standalone_mode", True)
        old_streams = sys.stdin, sys.stdout, sys.stderr
        sys.stdin, sys.stdout, sys.stderr = in_stream, out_stream, err_stream
        exit_code = 0
        exception = None
        exc_info = None
        return_value = None
        try:
            return_value = cli.main(
                args=args,
                prog_name=prog_name,
                standalone_mode=standalone,
                **extra,
            )
        except SystemExit as exc:
            exit_code = _exit_code_of(exc)
        except Exception as exc:
            if not catch_exceptions:
                raise
            exception = exc
            exit_code = 1
            exc_info = sys.exc_info()
        finally:
            sys.stdout.flush()
            sys.stderr.flush()
            sys.stdin, sys.stdout, sys.stderr = old_streams
            for key, old in saved_env.items():
                if old is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = old
            out_stream.flush()
            err_stream.flush()
        return Result(
            self,
            own_out.getvalue(),
            own_err.getvalue(),
            combined.getvalue(),
            return_value,
            exit_code,
            exception,
            exc_info,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Run inside a new empty directory. Without ``temp_dir`` it is removed on exit."""
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
        else:
            path = tempfile.mkdtemp(dir=os.fspath(temp_dir))
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(path, ignore_errors=True)


def _exit_code_of(exc):
    if exc.code is None:
        return 0
    if isinstance(exc.code, int):
        return exc.code
    sys.stderr.write(str(exc.code) + "\n")
    return 1
