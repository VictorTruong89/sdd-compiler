"""Contexts, parameters, commands, groups, parsing, and help pages."""

import contextlib
import enum
import inspect
import os
import shutil
import sys

from .exceptions import (
    Abort,
    BadParameter,
    Exit,
    MissingParameter,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import ellipsize, format_two_columns, wrap_text
from .param_types import BOOL, INT, FALSE_TOKENS, TRUE_TOKENS, Choice, Tuple, convert_type
from .utils import echo, pop_context, prompt, push_context

_MISSING = object()
DEFAULT_MAX_CONTENT_WIDTH = 80
CHAIN_MARK = "<chain>"  # invoked_subcommand value for chaining groups; never a child name


class ParameterSource(enum.Enum):
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


# The most explicit source wins when several options share one destination.
_SOURCE_RANK = {
    ParameterSource.PROMPT: 5,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.ENVIRONMENT: 3,
    ParameterSource.DEFAULT_MAP: 2,
    ParameterSource.DEFAULT: 1,
}


def _inherit(value, parent, attr, default):
    if value is not None:
        return value
    if parent is not None:
        return getattr(parent, attr)
    return default


class Context:
    """Per-invocation state: parsed values, parent linkage, settings, and resources."""

    def __init__(
        self,
        command,
        parent=None,
        info_name=None,
        obj=None,
        default_map=None,
        terminal_width=None,
        max_content_width=None,
        help_option_names=None,
        token_normalize_func=None,
        color=None,
        show_default=None,
        allow_extra_args=None,
        ignore_unknown_options=None,
        allow_interspersed_args=None,
        auto_envvar_prefix=None,
        chained=False,
    ):
        self.parent = parent
        self.command = command
        self.info_name = info_name
        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.default_map = default_map
        self.terminal_width = _inherit(terminal_width, parent, "terminal_width", None)
        self.max_content_width = _inherit(max_content_width, parent, "max_content_width", DEFAULT_MAX_CONTENT_WIDTH)
        self.help_option_names = list(_inherit(help_option_names, parent, "help_option_names", ["--help"]))
        self.token_normalize_func = _inherit(token_normalize_func, parent, "token_normalize_func", None)
        self.color = _inherit(color, parent, "color", None)
        self.show_default = bool(_inherit(show_default, parent, "show_default", False))
        self.allow_extra_args = bool(
            allow_extra_args if allow_extra_args is not None else command.allow_extra_args
        )
        self.ignore_unknown_options = bool(
            _inherit(ignore_unknown_options, parent, "ignore_unknown_options", False)
        )
        self.allow_interspersed_args = bool(
            allow_interspersed_args if allow_interspersed_args is not None else command.allow_interspersed_args
        )
        if auto_envvar_prefix is None and parent is not None and parent.auto_envvar_prefix:
            auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{info_name}"
        self.auto_envvar_prefix = auto_envvar_prefix
        self.chained = chained
        self.params = {}
        self.args = []
        self.invoked_subcommand = None
        self._sources = {}
        self._ranks = {}
        self._close_callbacks = []

    # -- thread-current context ---------------------------------------------------
    def __enter__(self):
        push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        pop_context()
        return False

    # -- navigation -----------------------------------------------------------------
    @property
    def command_path(self):
        if self.parent is None:
            return self.info_name or ""
        return f"{self.parent.command_path} {self.info_name}"

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    # -- resources ------------------------------------------------------------------
    def call_on_close(self, func):
        self._close_callbacks.append(func)

    def with_resource(self, cm):
        value = cm.__enter__()
        self._close_callbacks.append(lambda: cm.__exit__(None, None, None))
        return value

    def close(self):
        callbacks, self._close_callbacks = self._close_callbacks, []
        for func in reversed(callbacks):
            with contextlib.suppress(Exception):
                func()

    # -- help and control -----------------------------------------------------------
    def get_help(self):
        return self.command.get_help(self)

    def get_usage(self):
        return self.command.get_usage(self)

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def get_parameter_source(self, name):
        if not any(p.name == name for p in self.command.params):
            return None
        return self._sources.get(name)

    def invoke(self, callback, *args, **kwargs):
        """Run another command with explicitly chosen values, or a plain callable."""
        if isinstance(callback, Command):
            sub = Context(callback, parent=self, info_name=callback.name)
            with sub:
                for p in callback.params:
                    if p.name in kwargs:
                        sub.params[p.name] = kwargs[p.name]
                    elif p.expose_value:
                        sub.params[p.name] = p.default_value(sub)
                try:
                    return callback._call_callback(sub)
                finally:
                    sub.close()
        with self:
            return callback(*args, **kwargs)

    def forward(self, cmd, **kwargs):
        """Run ``cmd`` with this command's values, overridden by ``kwargs``."""
        return self.invoke(cmd, **{**self.params, **kwargs})


def _help_width(ctx):
    if ctx.terminal_width:
        return ctx.terminal_width
    detected = shutil.get_terminal_size((80, 24)).columns
    return min(detected, ctx.max_content_width)


def _first_sentence(doc):
    text = " ".join(doc.split("\n\n")[0].split())
    cut = text.find(". ")
    return text[: cut + 1] if cut != -1 else text


def _clean_doc(callback):
    if callback is None:
        return ""
    doc = inspect.getdoc(callback)
    if not doc:
        return ""
    return doc.split("\f")[0].strip("\n")


def _is_option_like(token, prefixes):
    return len(token) > 1 and token[0] in prefixes


def _split_decls(decls):
    opts, secondary, dest = [], [], None
    for decl in decls:
        if decl.isidentifier():
            dest = decl
        elif "/" in decl[1:]:
            idx = decl.index("/", 1)
            opts.append(decl[:idx])
            secondary.append(decl[idx + 1 :])
        else:
            opts.append(decl)
    return opts, secondary, dest


def _infer_dest(flags):
    longs = [f for f in flags if len(f) > 2 and f[1] == f[0]]
    chosen = longs[0] if longs else flags[0]
    return chosen.lstrip("-/+").replace("-", "_")


def _prompt_text_for(name):
    return name.replace("_", " ").capitalize()


def _warn_deprecated(message, note):
    text = f"DeprecationWarning: {message}."
    if isinstance(note, str):
        text += f" {note}"
    echo(text, err=True)


class Parameter:
    """State shared by options and arguments."""

    # Option-only attributes; arguments keep these neutral defaults.
    prompt = False
    is_flag = False
    count = False
    flag_value = None
    optional_value = False
    _auto_flag_default = False

    def __init__(
        self,
        name,
        type=None,
        required=False,
        default=None,
        callback=None,
        nargs=1,
        multiple=False,
        metavar=None,
        expose_value=True,
        is_eager=False,
        envvar=None,
        shell_complete=None,
        deprecated=False,
        help=None,
        hidden=False,
        show_default=None,
        show_envvar=False,
    ):
        self.name = name
        self.type = convert_type(type, default)
        self.is_tuple = isinstance(self.type, Tuple)
        self.nargs = len(self.type.types) if self.is_tuple else nargs
        self.required = required
        self.default = default
        self.callback = callback
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.envvars = [envvar] if isinstance(envvar, str) else list(envvar or [])
        self.shell_complete_func = shell_complete
        self.deprecated = deprecated
        self.help = help
        self.hidden = hidden
        self.show_default = show_default
        self.show_envvar = show_envvar

    def hint(self):
        return f"'{self.name}'"

    def _attach(self, exc, ctx):
        if exc.param is None:
            exc.param = self
        if exc.ctx is None:
            exc.ctx = ctx
        if exc.param_hint is None:
            exc.param_hint = self.hint()
        return exc

    def convert_one(self, ctx, token):
        try:
            return self.type.convert(token, self, ctx)
        except BadParameter as exc:
            raise self._attach(exc, ctx) from None

    def convert_tokens(self, ctx, tokens):
        if self.is_tuple:
            try:
                return self.type.convert(tuple(tokens), self, ctx)
            except BadParameter as exc:
                raise self._attach(exc, ctx) from None
        if self.nargs == 1:
            return self.convert_one(ctx, tokens[0])
        return tuple(self.convert_one(ctx, t) for t in tokens)

    def _split_and_convert(self, ctx, raw):
        parts = self.type.split_envvar_value(raw)
        if self.nargs == -1:
            return tuple(self.convert_one(ctx, t) for t in parts)
        size = self.nargs
        if self.multiple:
            if size == 1 and not self.is_tuple:
                return tuple(self.convert_one(ctx, t) for t in parts)
            chunks = [parts[i : i + size] for i in range(0, len(parts), size)]
            return tuple(self.convert_tokens(ctx, c) for c in chunks)
        return self.convert_tokens(ctx, parts[:size])

    def value_from_default(self, ctx, raw):
        """Convert a default-map or declared default (callables already resolved)."""
        if self.multiple:
            if raw is None:
                return ()
            if isinstance(raw, (str, bytes)) or not isinstance(raw, (list, tuple)):
                raise self._attach(
                    BadParameter("a repeatable parameter needs an iterable (sequence) default, not a single value."),
                    ctx,
                )
            return tuple(self.convert_one(ctx, x) if isinstance(x, str) else x for x in raw)
        if raw is None:
            return None
        if self.nargs != 1 or self.is_tuple:
            if isinstance(raw, str):
                return self._split_and_convert(ctx, raw)
            return raw
        if isinstance(raw, str):
            return self.convert_one(ctx, raw)
        return raw

    def default_value(self, ctx):
        raw = self.default() if callable(self.default) else self.default
        return self.value_from_default(ctx, raw)


class Option(Parameter):
    def __init__(self, param_decls=(), **attrs):
        opts, secondary, dest = _split_decls(param_decls)
        if not opts and not secondary and dest is None:
            raise TypeError("an option needs at least one flag name or a destination name")
        self.opts = opts
        self.secondary_opts = secondary
        name = dest or _infer_dest(opts + secondary)

        default = attrs.pop("default", None)
        is_flag = attrs.pop("is_flag", None)
        self.count = bool(attrs.pop("count", False))
        if is_flag is None:
            is_flag = isinstance(default, bool) or bool(secondary)
        self.is_flag = bool(is_flag) and not self.count
        flag_value = attrs.pop("flag_value", None)
        if self.is_flag and flag_value is None:
            flag_value = True
        self.flag_value = flag_value
        self.optional_value = not self.is_flag and not self.count and flag_value is not None
        self._auto_flag_default = self.is_flag and default is None

        prompt_arg = attrs.pop("prompt", False)
        self.prompt = bool(prompt_arg)
        self.prompt_text = prompt_arg if isinstance(prompt_arg, str) else _prompt_text_for(name)
        self.prompt_required = attrs.pop("prompt_required", True)
        self.hide_input = bool(attrs.pop("hide_input", False))
        self.confirmation_prompt = bool(attrs.pop("confirmation_prompt", False))
        self.allow_from_autoenv = bool(attrs.pop("allow_from_autoenv", True))

        required = bool(attrs.pop("required", False))
        multiple = bool(attrs.pop("multiple", False))
        nargs = attrs.pop("nargs", 1)
        if nargs < 1:
            raise TypeError("nargs must be a positive integer")
        if self.is_flag or self.count:
            nargs = 1
        if attrs.get("deprecated") and (required or self.prompt):
            raise TypeError("a deprecated option cannot be required or prompt")
        if self.prompt and self.is_flag:
            raise TypeError("a flag cannot prompt")

        type_ = attrs.pop("type", None)
        if type_ is None and self.is_flag:
            type_ = BOOL
        if type_ is None and self.count:
            type_ = INT
        super().__init__(
            name,
            type=type_,
            required=required,
            default=default,
            nargs=nargs,
            multiple=multiple,
            **attrs,
        )

    def hint(self):
        return f"'{self.opts[0] if self.opts else self.name}'"

    @property
    def consumes_value(self):
        return not (self.is_flag or self.count)

    def get_metavar(self):
        if self.metavar is not None:
            return self.metavar
        if not self.consumes_value:
            return None
        if isinstance(self.type, Choice):
            return self.type.get_metavar(self)
        return self.name.upper()

    def all_flag_names(self):
        return list(self.opts) + list(self.secondary_opts)


class Argument(Parameter):
    def __init__(self, param_decls=(), **attrs):
        if len(param_decls) != 1 or not str(param_decls[0]).isidentifier():
            raise TypeError("an argument takes exactly one destination name")
        name = param_decls[0]
        nargs = attrs.pop("nargs", 1)
        if nargs == 0 or nargs < -1:
            raise TypeError("argument nargs must be a positive integer or -1")
        default = attrs.get("default")
        required = attrs.pop("required", None)
        if required is None:
            required = default is None and nargs != -1
        if attrs.get("deprecated") and required:
            raise TypeError("a deprecated argument cannot be required")
        super().__init__(name, required=required, nargs=nargs, **attrs)

    def hint(self):
        return f"'{self.name.upper()}'"

    def get_metavar(self):
        return self.metavar or self.name.upper()


class Command:
    """A leaf command: options, arguments, and a callback."""

    allow_extra_args = False
    allow_interspersed_args = True

    def __init__(
        self,
        name,
        callback=None,
        params=None,
        help=None,
        short_help=None,
        epilog=None,
        options_metavar="[OPTIONS]",
        context_settings=None,
        add_help_option=True,
        no_args_is_help=False,
        deprecated=False,
        hidden=False,
    ):
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        self.help = help
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    @property
    def options(self):
        return [p for p in self.params if isinstance(p, Option)]

    @property
    def arguments(self):
        return [p for p in self.params if isinstance(p, Argument)]

    # -- entry point -----------------------------------------------------------------
    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        if args is None:
            args = sys.argv[1:]
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "cli"
        from .shell_completion import complete_var_name, run_completion

        varname = complete_var or complete_var_name(prog_name)
        instruction = os.environ.get(varname)
        if instruction:
            code = run_completion(self, prog_name, instruction)
            if standalone_mode:
                sys.exit(code)
            return None
        try:
            try:
                ctx = self.make_context(prog_name, list(args), **extra)
                rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                sys.exit(0)
            except (EOFError, KeyboardInterrupt) as exc:
                if not standalone_mode:
                    raise
                raise Abort() from exc
        except Exit as exc:
            if not standalone_mode:
                return None
            sys.exit(exc.exit_code)
        except OptlynError as exc:
            if not standalone_mode:
                raise
            exc.show()
            sys.exit(exc.exit_code)
        except Abort as exc:
            if not standalone_mode:
                raise
            exc.show()
            sys.exit(1)

    def make_context(self, info_name, args, parent=None, chained=False, **extra):
        for key, value in self.context_settings.items():
            extra.setdefault(key, value)
        if parent is not None and isinstance(parent.default_map, dict):
            child_map = parent.default_map.get(info_name)
            if isinstance(child_map, dict):
                extra["default_map"] = child_map
        ctx = Context(self, parent=parent, info_name=info_name, chained=chained, **extra)
        with ctx:
            try:
                ctx.args = self.parse_args(ctx, list(args))
            except BaseException:
                ctx.close()
                raise
        return ctx

    def invoke(self, ctx):
        try:
            with ctx:
                if self.deprecated:
                    _warn_deprecated(f"The command '{ctx.info_name}' is deprecated", self.deprecated)
                return self._call_callback(ctx)
        finally:
            ctx.close()

    def _exposed_kwargs(self, ctx):
        return {p.name: ctx.params.get(p.name) for p in self.params if p.expose_value}

    def _call_callback(self, ctx):
        if self.callback is None:
            return None
        return self.callback(**self._exposed_kwargs(ctx))

    # -- automatic help ---------------------------------------------------------------
    def _automatic_help_params(self, ctx):
        names = list(ctx.help_option_names)
        if not self.add_help_option or not names:
            return []
        author_flags = {f for p in self.options for f in p.all_flag_names()}
        remaining = [n for n in names if n not in author_flags]
        if not remaining:
            return []
        return [
            Option(
                (*remaining, "help"),
                is_flag=True,
                is_eager=True,
                expose_value=False,
                callback=_help_callback,
                help="Show this message and exit.",
            )
        ]

    # -- parsing ------------------------------------------------------------------------
    def parse_args(self, ctx, args):
        """Bind tokens to this command's parameters. Returns the tokens left for a subcommand/chain."""
        if not args and self.no_args_is_help:
            echo(self.get_help(ctx), err=True)
            raise UsageError(None, ctx)

        all_params = self.params + self._automatic_help_params(ctx)
        flag_map = {}
        for p in all_params:
            if isinstance(p, Option):
                for f in p.opts:
                    flag_map[f] = (p, False)
                for f in p.secondary_opts:
                    flag_map[f] = (p, True)
        prefixes = {f[0] for f in flag_map} or {"-"}
        is_group = isinstance(self, Group)
        name_after = None
        if is_group and not any(a.nargs == -1 for a in self.arguments):
            name_after = len(self.arguments)
        leaf_stop = not is_group and not (ctx.allow_interspersed_args and not ctx.chained)

        occurrences = {}
        seq = 0
        positional = []  # (token, after_double_dash)
        tail = []
        dashdash = False
        stop = False
        i = 0
        while i < len(args):
            tok = args[i]
            if not dashdash and tok == "--":
                dashdash = True
                i += 1
                continue
            option_like = not dashdash and _is_option_like(tok, prefixes)
            if is_group and name_after is not None and not option_like and len(positional) >= name_after:
                tail = args[i:]  # this token names the subcommand; the rest is its business
                break
            if option_like and not stop:
                i, entries = self._consume_option(ctx, args, i, flag_map, prefixes, is_group, positional)
                for p, kind, payload in entries:
                    seq += 1
                    occurrences.setdefault(p, []).append((kind, payload, seq))
                continue
            if option_like and not ctx.ignore_unknown_options and not ctx.chained:
                raise NoSuchOption(tok, ctx=ctx)
            positional.append((tok, dashdash))
            i += 1
            if leaf_stop and not dashdash:
                stop = True

        bound, extras = self._bind_arguments(ctx, positional)
        ctx.args = tail
        if not is_group:
            ctx.args = []
            if extras:
                if ctx.chained:
                    ctx.args = [t for t, _ in extras]
                else:
                    tok, literal = extras[0]
                    if not literal and _is_option_like(tok, prefixes) and not ctx.ignore_unknown_options:
                        raise NoSuchOption(tok, ctx=ctx)
                    if not ctx.allow_extra_args:
                        names = " ".join(t for t, _ in extras)
                        plural = "s" if len(extras) > 1 else ""
                        raise UsageError(f"Got unexpected extra argument{plural} ({names})", ctx)
                    ctx.args = [t for t, _ in extras]

        processed = set()
        eager = [p for p in all_params if p.is_eager and p in occurrences]
        for p in sorted(eager, key=lambda p: min(s for _, _, s in occurrences[p])):
            entries = [(k, v) for k, v, _ in occurrences[p]]
            try:
                value = self._value_from_cmdline(ctx, p, entries)
            except BadParameter as exc:
                raise p._attach(exc, ctx) from None
            self._run_callback(ctx, p, value)
            processed.add(id(p))

        for p in all_params:
            if id(p) in processed:
                continue
            if isinstance(p, Argument):
                raw = bound.get(p.name)
                self._process_param(ctx, p, [("tokens", raw)] if raw is not None else [])
            else:
                self._process_param(ctx, p, [(k, v) for k, v, _ in occurrences.get(p, [])])
        return ctx.args

    def _consume_option(self, ctx, args, i, flag_map, prefixes, is_group, positional):
        """Consume one option token (possibly a stack). Returns (next index, occurrences)."""
        tok = args[i]
        found = self._lookup_flag(ctx, flag_map, tok)
        if found is not None:
            return self._take(ctx, args, i, found, tok, None, prefixes)
        if len(tok) > 2 and tok[0] in prefixes and tok[1] == tok[0]:
            if "=" in tok:
                name, _, inline = tok.partition("=")
                found = self._lookup_flag(ctx, flag_map, name)
                if found is not None:
                    return self._take(ctx, args, i, found, name, inline, prefixes)
            return self._unknown_option(ctx, tok, i, positional)
        # Single-character flags may be stacked: -abc is -a -b -c.
        prefix = tok[0]
        entries = []
        j = 1
        while j < len(tok):
            flag = prefix + tok[j]
            found = self._lookup_flag(ctx, flag_map, flag)
            if found is None:
                if ctx.ignore_unknown_options:
                    positional.append((prefix + tok[j:], False))  # unknown rest stays leftover
                    return i + 1, entries
                raise NoSuchOption(flag, ctx=ctx)
            p, secondary = found
            if p.consumes_value:
                inline = tok[j + 1 :] or None
                new_i, more = self._take(ctx, args, i, found, flag, inline, prefixes)
                return new_i, entries + more
            kind, payload = self._flag_entry(p, secondary)
            entries.append((p, kind, payload))
            j += 1
        return i + 1, entries

    def _unknown_option(self, ctx, tok, i, positional):
        if ctx.ignore_unknown_options:
            positional.append((tok, False))
            return i + 1, []
        raise NoSuchOption(tok, ctx=ctx)

    def _lookup_flag(self, ctx, flag_map, token):
        if token in flag_map:
            return flag_map[token]
        if ctx.token_normalize_func is not None:
            norm = ctx.token_normalize_func(token)
            for flag, value in flag_map.items():
                if ctx.token_normalize_func(flag) == norm:
                    return value
        return None

    def _flag_entry(self, p, secondary):
        if p.count:
            return "literal", 1
        if secondary:
            return "literal", not p.flag_value
        return "literal", p.flag_value

    def _take(self, ctx, args, i, found, flag, inline, prefixes):
        """Take a known option token and its value(s). Returns (next index, occurrences)."""
        p, secondary = found
        if not p.consumes_value:
            if inline is not None:
                raise UsageError(f"Option '{flag}' does not take a value.", ctx)
            kind, payload = self._flag_entry(p, secondary)
            return i + 1, [(p, kind, payload)]
        if p.optional_value:
            if inline is not None:
                return i + 1, [(p, "tokens", [inline])]
            if i + 1 < len(args) and not _is_option_like(args[i + 1], prefixes):
                return i + 2, [(p, "tokens", [args[i + 1]])]
            return i + 1, [(p, "literal", p.flag_value)]
        vals = [] if inline is None else [inline]
        j = i + 1
        while len(vals) < p.nargs and j < len(args):
            vals.append(args[j])
            j += 1
        if len(vals) < p.nargs:
            if p.prompt:
                return j, [(p, "prompt", None)]
            raise UsageError(f"Option '{flag}' requires an argument.", ctx)
        return j, [(p, "tokens", vals)]

    def _bind_arguments(self, ctx, positional):
        """Assign positional tokens to arguments in declaration order. Returns (bound, extras)."""
        tokens = [t for t, _ in positional]
        bound = {}
        idx = 0
        args = self.arguments
        for k, a in enumerate(args):
            later_min = sum(b.nargs for b in args[k + 1 :] if b.required and b.nargs > 0)
            remaining = len(tokens) - idx
            if a.nargs == -1:
                take = max(remaining - later_min, 0)
                bound[a.name] = tokens[idx : idx + take] or None
                idx += take
            elif a.nargs == 1:
                if remaining > later_min:
                    bound[a.name] = [tokens[idx]]
                    idx += 1
                else:
                    bound[a.name] = None
            elif remaining >= a.nargs:
                bound[a.name] = tokens[idx : idx + a.nargs]
                idx += a.nargs
            elif remaining > 0 and a.required:
                raise UsageError(f"Argument {a.hint()} requires {a.nargs} values.", ctx)
            else:
                bound[a.name] = None
        return bound, positional[idx:]

    # -- value resolution ------------------------------------------------------------------
    def _value_from_cmdline(self, ctx, p, entries):
        values = []
        for kind, payload in entries:
            if kind == "literal":
                values.append(payload)
            elif kind == "tokens":
                values.append(p.convert_tokens(ctx, payload))
        if p.count:
            return sum(values)
        if p.multiple:
            return tuple(values)
        return values[-1]

    def _env_value(self, ctx, p):
        names = list(p.envvars)
        if isinstance(p, Option) and p.allow_from_autoenv and ctx.auto_envvar_prefix and not names:
            names = [f"{ctx.auto_envvar_prefix}_{p.name}".upper().replace("-", "_")]
        for name in names:
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            return self._value_from_env_text(ctx, p, raw)
        return _MISSING

    def _value_from_env_text(self, ctx, p, raw):
        if p.count:
            return _MISSING
        if p.is_flag:
            text = raw.strip().lower()
            if text in TRUE_TOKENS:
                return p.flag_value
            if text in FALSE_TOKENS or text == "":
                return False if isinstance(p.flag_value, bool) else _MISSING
            if not isinstance(p.flag_value, bool):
                # A non-boolean flag value activates on its own text; anything else is unset.
                return p.flag_value if text == str(p.flag_value).lower() else _MISSING
            raise p._attach(BadParameter(f"{raw!r} is not a valid boolean."), ctx)
        if p.multiple or p.nargs != 1 or p.is_tuple:
            return p._split_and_convert(ctx, raw)
        return p.convert_one(ctx, raw)

    def _dm_value(self, ctx, p):
        dm = ctx.default_map
        if isinstance(dm, dict) and p.name in dm:
            return dm[p.name]
        return _MISSING

    def _resolve(self, ctx, p, entries):
        """Pick the value and its source: prompt, command line, environment, default map, default."""
        cmdline = [(k, v) for k, v in entries if k != "prompt"]
        wants_prompt = len(cmdline) != len(entries)
        value, source = _MISSING, None
        if cmdline:
            value, source = self._value_from_cmdline(ctx, p, cmdline), ParameterSource.COMMANDLINE
        if value is _MISSING:
            env = self._env_value(ctx, p)
            if env is not _MISSING:
                value, source = env, ParameterSource.ENVIRONMENT
        dm_raw = self._dm_value(ctx, p)
        declared = p.default() if callable(p.default) else p.default
        if value is _MISSING and p.prompt and (
            wants_prompt or (p.required and dm_raw is _MISSING and declared is None)
        ):
            shown = dm_raw if dm_raw is not _MISSING else declared
            value = prompt(
                p.prompt_text,
                default=shown,
                hide_input=p.hide_input,
                confirmation_prompt=p.confirmation_prompt,
                type=p.type,
            )
            source = ParameterSource.PROMPT
        if value is _MISSING and dm_raw is not _MISSING:
            value, source = p.value_from_default(ctx, dm_raw), ParameterSource.DEFAULT_MAP
        if value is _MISSING:
            source = ParameterSource.DEFAULT
            if p.is_flag:
                value = declared if declared is not None else False
            elif p.count:
                value = declared if declared is not None else 0
            elif isinstance(p, Argument) and p.nargs == -1 and declared is None:
                value = ()
            elif declared is not None or p.multiple:
                value = p.value_from_default(ctx, declared)
            else:
                value = None
        if value is None and p.required:
            if isinstance(p, Argument):
                raise MissingParameter(f"Missing argument {p.hint()}.", ctx, p, p.hint())
            raise MissingParameter(f"Missing option {p.hint()}.", ctx, p, p.hint())
        return value, source

    def _run_callback(self, ctx, p, value):
        if p.callback is None:
            return value
        try:
            return p.callback(ctx, p, value)
        except BadParameter as exc:
            raise p._attach(exc, ctx) from None

    def _process_param(self, ctx, p, entries):
        if entries and p.deprecated:
            kind = "option" if isinstance(p, Option) else "argument"
            label = p.hint()[1:-1] if isinstance(p, Option) else p.name
            _warn_deprecated(f"The {kind} '{label}' is deprecated", p.deprecated)
        try:
            value, source = self._resolve(ctx, p, entries)
        except BadParameter as exc:
            raise p._attach(exc, ctx) from None
        value = self._run_callback(ctx, p, value)
        self._store(ctx, p, value, source)

    def _store(self, ctx, p, value, source):
        rank = 0 if (source is ParameterSource.DEFAULT and p._auto_flag_default) else _SOURCE_RANK[source]
        # A later declaration wins ties, so shared destinations follow the most explicit source.
        if p.name in ctx._ranks and rank < ctx._ranks[p.name]:
            return
        ctx._ranks[p.name] = rank
        ctx._sources[p.name] = source
        if p.expose_value:
            ctx.params[p.name] = value

    # -- help -----------------------------------------------------------------------------
    def get_usage(self, ctx):
        return "Usage: " + " ".join(self._usage_parts(ctx))

    def _usage_parts(self, ctx):
        parts = [ctx.command_path]
        if self.options_metavar:
            parts.append(self.options_metavar)
        for a in self.arguments:
            base = a.get_metavar()
            if a.nargs == -1:
                parts.append(f"{base}..." if a.required else f"[{base}]...")
            else:
                parts.append(base if a.required else f"[{base}]")
        return parts

    def _description(self):
        return self.help or _clean_doc(self.callback)

    def get_help(self, ctx):
        width = _help_width(ctx)
        lines = [self.get_usage(ctx), ""]
        desc = self._description()
        if self.deprecated:
            note = f" {self.deprecated}" if isinstance(self.deprecated, str) else ""
            desc = f"(Deprecated){note}\n\n{desc}" if desc else f"(Deprecated){note}"
        if desc:
            lines += [wrap_text(desc, width=width, preserve_paragraphs=True), ""]
        self._help_arguments(ctx, lines, width)
        self._help_options(ctx, lines, width)
        self._help_commands(ctx, lines, width)
        if self.epilog:
            lines += [wrap_text(self.epilog, width=width, preserve_paragraphs=True), ""]
        return "\n".join(lines).rstrip("\n") + "\n"

    def _help_arguments(self, ctx, lines, width):
        rows = [(a.get_metavar(), a.help) for a in self.arguments if a.help and not a.hidden]
        if rows:
            lines.append("Positional arguments:")
            lines.extend(format_two_columns(rows, width))
            lines.append("")

    def _option_extras(self, ctx, p):
        extras = []
        show = p.show_default if p.show_default is not None else ctx.show_default
        if show and p.default is not None:
            if isinstance(show, str):
                extras.append(f"[default: {show}]")
            elif not callable(p.default) and not (p.is_flag and p.default is False):
                extras.append(f"[default: {p.default}]")
        if p.show_envvar:
            names = list(p.envvars)
            if not names and ctx.auto_envvar_prefix and p.allow_from_autoenv:
                names = [f"{ctx.auto_envvar_prefix}_{p.name}".upper().replace("-", "_")]
            if names:
                extras.append(f"[env var: {', '.join(names)}]")
        if isinstance(p.type, Choice):
            extras.append(f"[choices: {', '.join(p.type._keys)}]")
        if p.deprecated:
            extras.append("[deprecated]")
        return extras

    def _help_options(self, ctx, lines, width):
        rows = []
        for p in self.options + self._automatic_help_params(ctx):
            if p.hidden:
                continue
            names = ", ".join(p.opts)
            if p.secondary_opts:
                names += "/" + "/".join(p.secondary_opts)
            metavar = p.get_metavar()
            first = f"{names} {metavar}" if metavar else names
            text = " ".join([p.help or ""] + self._option_extras(ctx, p)).strip()
            rows.append((first, text))
        if rows:
            lines.append("Options:")
            lines.extend(format_two_columns(rows, width))
            lines.append("")

    def _help_commands(self, ctx, lines, width):
        """Commands are listed only for groups."""


def _help_callback(ctx, param, value):
    if not value:
        return
    echo(ctx.get_help(), color=ctx.color)
    raise Exit(0)


class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_interspersed_args = False

    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        **kwargs,
    ):
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self.result_callback_func = result_callback
        self.commands = {}
        super().__init__(name, no_args_is_help=no_args_is_help, **kwargs)
        if isinstance(commands, dict):
            commands = commands.items()
        for item in commands or ():
            if isinstance(item, tuple):
                self.add_command(item[1], item[0])
            else:
                self.add_command(item)

    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise TypeError("a chaining group cannot contain nested groups")
        self.commands[name or cmd.name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command

        def decorator(f):
            cmd = command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group

        def decorator(f):
            cmd = group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(f):
            self.result_callback_func = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        if ctx is not None and ctx.token_normalize_func is not None:
            norm = ctx.token_normalize_func(cmd_name)
            for name, cmd in self.commands.items():
                if ctx.token_normalize_func(name) == norm:
                    return cmd
        return None

    def _usage_parts(self, ctx):
        parts = super()._usage_parts(ctx)
        sub = self.subcommand_metavar or "COMMAND [ARGS]..."
        if self.chain:
            parts.append(f"[{sub}]...")
        else:
            parts.append(f"[{sub}]" if self.invoke_without_command else sub)
        return parts

    def _help_commands(self, ctx, lines, width):
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            short = cmd.short_help
            if short is None:
                short = _first_sentence(cmd._description()) if cmd._description() else ""
            rows.append((name, short))
        if rows:
            col = min(max(len(n) for n, _ in rows), 30)
            room = max(width - col - 4, 10)
            rows = [(n, ellipsize(s, room)) for n, s in rows]
            lines.append("Commands:")
            lines.extend(format_two_columns(rows, width))
            lines.append("")

    def invoke(self, ctx):
        try:
            with ctx:
                if self.deprecated:
                    _warn_deprecated(f"The command '{ctx.info_name}' is deprecated", self.deprecated)
                if self.chain:
                    return self._invoke_chain(ctx)
                rest = ctx.args
                if not rest:
                    if self.invoke_without_command:
                        ctx.invoked_subcommand = None
                        return self._apply_result(ctx, self._call_callback(ctx))
                    raise UsageError("Missing command.", ctx)
                name, sub_args = rest[0], rest[1:]
                cmd = self.get_command(ctx, name)
                if cmd is None:
                    raise UsageError(f"No such command {name!r}.", ctx)
                ctx.invoked_subcommand = name
                self._call_callback(ctx)
                sub_ctx = cmd.make_context(name, sub_args, parent=ctx)
                return self._apply_result(ctx, cmd.invoke(sub_ctx))
        finally:
            ctx.close()

    def _apply_result(self, ctx, value):
        if self.result_callback_func is None:
            return value
        return self.result_callback_func(value, **self._exposed_kwargs(ctx))

    def _invoke_chain(self, ctx):
        rest = ctx.args
        if not rest and not self.invoke_without_command:
            raise UsageError("Missing command.", ctx)
        ctx.invoked_subcommand = CHAIN_MARK
        self._call_callback(ctx)
        results = []
        remaining = rest
        while remaining:
            name = remaining[0]
            cmd = self.get_command(ctx, name)
            if cmd is None:
                raise UsageError(f"No such command {name!r}.", ctx)
            sub_ctx = cmd.make_context(name, remaining[1:], parent=ctx, chained=True)
            results.append(cmd.invoke(sub_ctx))
            remaining = sub_ctx.args
        if self.result_callback_func is None:
            return results
        return self.result_callback_func(results, **self._exposed_kwargs(ctx))


class CommandCollection(Group):
    """A group presenting the union of subcommands from several source groups."""

    def __init__(self, name=None, sources=None, **kwargs):
        self.sources = list(sources or [])
        super().__init__(name, **kwargs)

    def list_commands(self, ctx):
        names = set(super().list_commands(ctx))
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        found = super().get_command(ctx, cmd_name)
        if found is not None:
            return found
        for source in self.sources:
            found = source.get_command(ctx, cmd_name)
            if found is not None:
                return found
        return None
