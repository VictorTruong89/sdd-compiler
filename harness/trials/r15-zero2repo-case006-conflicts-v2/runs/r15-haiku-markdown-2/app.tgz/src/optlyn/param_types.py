"""Parameter types and conversion (FP-05, FP-09)."""

import datetime as _dt
import enum
import os
import pathlib
import uuid

from .exceptions import BadParameter

TRUE_TOKENS = {"1", "true", "t", "yes", "y", "on"}
FALSE_TOKENS = {"0", "false", "f", "no", "n", "off"}


class ParamType:
    """Base class for parameter types. Subclasses implement ``convert``."""

    name = "text"
    is_composite = False

    def convert(self, value, param=None, ctx=None):
        return value

    def get_metavar(self, param=None):
        return None

    def split_envvar_value(self, rv):
        return rv.split()

    def shell_complete(self, ctx, param, incomplete):
        return []

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self):
        return self.name.upper()


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return value if isinstance(value, str) else str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        try:
            return int(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in TRUE_TOKENS:
            return True
        if text in FALSE_TOKENS:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


class FuncParamType(ParamType):
    """Adapts a plain ``f(token) -> value`` conversion function."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        if not isinstance(value, (str, bytes)):
            return value  # already converted (defaults, Python-side calls)
        try:
            return self.func(value)
        except ValueError as exc:
            self.fail(str(exc) or f"{value!r} is not valid.", param, ctx)


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._keys = [member.name for member in self.choices]
        else:
            self.choices = list(choices)
            self._keys = [str(choice) for choice in self.choices]

    def convert(self, value, param=None, ctx=None):
        for choice in self.choices:
            if choice is value or choice == value:
                return choice
        token = value if isinstance(value, str) else str(value)
        for key, choice in zip(self._keys, self.choices):
            if self.case_sensitive:
                if key == token:
                    return choice
            elif key.casefold() == token.casefold():
                return choice
        options = ", ".join(repr(k) for k in self._keys)
        self.fail(f"{token!r} is not {options}.", param, ctx)

    def get_metavar(self, param=None):
        return "[" + "|".join(self._keys) + "]"

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        return [CompletionItem(key) for key in self._keys if key.startswith(incomplete)]


class DateTime(ParamType):
    name = "datetime"
    DEFAULT_FORMATS = ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S")

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(self.DEFAULT_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        formats = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{text!r} does not match the formats {formats}.", param, ctx)


class IntRange(IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def _describe(self):
        lo = "" if self.min is None else f"{self.min}{'<' if self.min_open else '<='}"
        hi = "" if self.max is None else f"{'<' if self.max_open else '<='}{self.max}"
        return f"{lo}x{hi}"

    def convert(self, value, param=None, ctx=None):
        rv = super().convert(value, param, ctx)
        if self.min is not None:
            if rv < self.min or (self.min_open and rv == self.min):
                if self.clamp:
                    return self.min + 1 if self.min_open else self.min
                self.fail(f"{rv} is not in the range {self._describe()}.", param, ctx)
        if self.max is not None:
            if rv > self.max or (self.max_open and rv == self.max):
                if self.clamp:
                    return self.max - 1 if self.max_open else self.max
                self.fail(f"{rv} is not in the range {self._describe()}.", param, ctx)
        return rv


class FloatRange(FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise ValueError("clamping is only allowed when both bounds are closed")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def _describe(self):
        lo = "" if self.min is None else f"{self.min}{'<' if self.min_open else '<='}"
        hi = "" if self.max is None else f"{'<' if self.max_open else '<='}{self.max}"
        return f"{lo}x{hi}"

    def convert(self, value, param=None, ctx=None):
        rv = super().convert(value, param, ctx)
        if self.min is not None:
            if rv < self.min or (self.min_open and rv == self.min):
                if self.clamp:
                    return float(self.min)
                self.fail(f"{rv} is not in the range {self._describe()}.", param, ctx)
        if self.max is not None:
            if rv > self.max or (self.max_open and rv == self.max):
                if self.clamp:
                    return float(self.max)
                self.fail(f"{rv} is not in the range {self._describe()}.", param, ctx)
        return rv


class Tuple(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(t) for t in types]

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, str) or len(value) != len(self.types):
            self.fail(f"{value!r} must have exactly {len(self.types)} items.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))

    def get_metavar(self, param=None):
        return " ".join(t.get_metavar(param) or t.name.upper() for t in self.types)


class File(ParamType):
    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        if lazy is None:
            lazy = "w" in mode or "a" in mode
        self.lazy = lazy

    def convert(self, value, param=None, ctx=None):
        from .utils import open_file

        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        try:
            f = open_file(
                value,
                self.mode,
                self.encoding,
                self.errors,
                lazy=self.lazy,
                atomic=self.atomic,
            )
        except OSError as exc:
            self.fail(f"'{value}': {exc.strerror or exc}", param, ctx)
        if ctx is not None:
            ctx.call_on_close(f.close)
        return f

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        return [CompletionItem(incomplete, kind="file")]


class Path(ParamType):
    name = "path"

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param=None, ctx=None):
        rv = os.fspath(value)
        if self.allow_dash and rv == "-":
            return self._wrap("-")
        if self.resolve_path:
            rv = os.path.realpath(rv)
        try:
            is_there = os.path.exists(rv)
        except (OSError, ValueError):
            is_there = False
        if not is_there:
            if self.exists:
                self.fail(f"{value!r} does not exist.", param, ctx)
            return self._wrap(rv)
        if os.path.isdir(rv):
            if not self.dir_okay:
                self.fail(f"{value!r} is a directory.", param, ctx)
        elif not self.file_okay:
            self.fail(f"{value!r} is a file.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{value!r} is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{value!r} is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{value!r} is not executable.", param, ctx)
        return self._wrap(rv)

    def _wrap(self, rv):
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return rv

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        kind = "dir" if self.dir_okay and not self.file_okay else "file"
        return [CompletionItem(incomplete, kind=kind)]


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()

_BY_PYTHON_TYPE = {str: STRING, int: INT, float: FLOAT, bool: BOOL, uuid.UUID: UUID}


def convert_type(ty, default=None):
    """Return a ParamType for ``ty``, inferring from ``default`` when ``ty`` is None."""
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if ty is None:
        if isinstance(default, (list, tuple)):
            return convert_type(None, default[0]) if default else STRING
        if default is None:
            return STRING
        # bool is a subclass of int, so it must be checked first
        if isinstance(default, bool):
            return BOOL
        for py_type in (int, float, uuid.UUID):
            if isinstance(default, py_type):
                return _BY_PYTHON_TYPE[py_type]
        return STRING
    if isinstance(ty, tuple):
        return Tuple(ty)
    if ty in _BY_PYTHON_TYPE:
        return _BY_PYTHON_TYPE[ty]
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")
