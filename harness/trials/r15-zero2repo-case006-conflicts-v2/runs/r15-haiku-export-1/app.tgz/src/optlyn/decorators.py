"""Decorators that declare commands, groups, parameters and callback helpers."""

import functools
import re
import sys
from importlib import metadata

from ._context import get_current_context
from .core import Argument, Command, Group, Option
from .exceptions import Abort
from .utils import echo

_SUFFIX_RE = re.compile(r"_(command|cmd|group|grp)$")


def _derive_name(func_name):
    """``list_all_cmd`` becomes ``list-all``: lowercase, suffix stripped, underscores to dashes."""
    name = _SUFFIX_RE.sub("", func_name.lower())
    return name.replace("_", "-")


def _attach_param(func, param):
    if isinstance(func, Command):
        func.params.insert(0, param)
        return
    if not hasattr(func, "__optlyn_params__"):
        func.__optlyn_params__ = []
    func.__optlyn_params__.append(param)


def _take_params(func):
    params = list(reversed(getattr(func, "__optlyn_params__", [])))
    if hasattr(func, "__optlyn_params__"):
        del func.__optlyn_params__
    return params


def _make_command(cls, name, attrs, func, default_cls):
    if name is None:
        name = _derive_name(func.__name__)
    cls = cls or default_cls
    return cls(name=name, callback=func, params=_take_params(func), **attrs)


# spec: N-000834–N-000841 (command declaration), N-000073–N-000076 (naming)
def command(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Command`. Used as ``@command()`` or ``@command``."""
    if callable(name) and not isinstance(name, str):
        return command()(name)

    def decorator(func):
        return _make_command(cls, name, attrs, func, Command)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Group` (or an instance of ``cls``)."""
    if callable(name) and not isinstance(name, str):
        return group()(name)

    def decorator(func):
        return _make_command(cls, name, attrs, func, Group)

    return decorator


# spec: N-000868–N-000871 (option declaration)
def option(*param_decls, cls=None, **attrs):
    """Attach an :class:`Option` to a function or a command."""

    def decorator(func):
        param = (cls or Option)(list(param_decls), **attrs)
        _attach_param(func, param)
        return func

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach an :class:`Argument` to a function or a command."""

    def decorator(func):
        param = (cls or Argument)(list(param_decls), **attrs)
        _attach_param(func, param)
        return func

    return decorator


# spec: N-000911–N-000919 (ready-made options), N-000916 (help flag)
def help_option(*param_decls, **kwargs):
    """An extra eager help flag. Printing help and exiting with status 0."""
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _help_callback)
    return option(*decls, **kwargs)


def _help_callback(ctx, param, value):
    if not value:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def _caller_package(depth):
    frame = sys._getframe(depth + 1)
    module = frame.f_globals.get("__name__", "__main__")
    return module.partition(".")[0]


def _detect_version(name):
    """Version of a distribution, or of the distribution that provides an import name."""
    try:
        return metadata.version(name)
    except metadata.PackageNotFoundError:
        providers = metadata.packages_distributions().get(name)
        if providers:
            return metadata.version(providers[0])
        raise RuntimeError(f"Could not determine the version of {name!r}.") from None


# spec: N-000917–N-000918, N-000149–N-000156 (version identity)
def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """An eager flag that prints the program's version and exits (FP-02)."""
    decls = list(param_decls) or ["--version"]
    if version is None and package_name is None:
        package_name = _caller_package(1)

    def callback(ctx, param, value):
        if not value:
            return
        identity = version if version is not None else _detect_version(package_name)
        name = prog_name or ctx.find_root().info_name
        if message:
            text = message % {"prog": name, "package": package_name, "version": identity}
        else:
            text = f"{name}, version {identity}"
        echo(text, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*decls, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    """An eager flag whose printed identity is exactly what ``callback(ctx)`` returns."""
    decls = list(param_decls) or ["--version"]

    def _print_identity(ctx, param, value):
        if not value:
            return
        echo(callback(ctx), color=True)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = _print_identity
    return option(*decls, **kwargs)


def password_option(*param_decls, **kwargs):
    """A prompting, hidden, confirmed option (FP-08)."""
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*decls, **kwargs)


# spec: N-000503–N-000509 (confirmation option), N-000477 (ready-made)
def confirmation_option(*param_decls, **kwargs):
    """A yes flag that asks when omitted and aborts when the user declines (FP-08)."""
    decls = list(param_decls) or ["--yes"]

    def _confirm(ctx, param, value):
        if not value:
            raise Abort()
        return value

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs["callback"] = _confirm
    return option(*decls, **kwargs)


# spec: N-000957–N-000959 (callback decorators)
def pass_context(func):
    """Pass the current :class:`Context` as the first argument."""

    @functools.wraps(func)
    def new_func(*args, **kwargs):
        return func(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(func):
    """Pass the current context's ``obj`` as the first argument."""

    @functools.wraps(func)
    def new_func(*args, **kwargs):
        return func(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Build a decorator passing the nearest object of exactly ``object_type``."""

    def decorator(func):
        @functools.wraps(func)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(f"Managed to invoke callback without a context object of type {object_type.__name__!r} existing.")
            return func(obj, *args, **kwargs)

        return new_func

    return decorator
