"""Shell completion: registration scripts and suggestion output (section 8, FP-12)."""

import os
import re

from . import core
from .types import CompletionItem

# spec: N-000677–N-000703 (FP-12), N-000983–N-001005 (contract §8)
SHELLS = ("bash", "zsh", "fish", "powershell")


def complete_var_name(prog_name):
    """``_<PROG>_COMPLETE``: the program name upper-cased, dashes turned into underscores."""
    return "_" + prog_name.replace("-", "_").upper() + "_COMPLETE"


def handle_complete(cli, prog_name, instruction, args):
    """Handle a completion instruction. Returns the exit status (0 on success)."""
    shell, _, action = instruction.rpartition("_")
    if shell not in SHELLS or action not in ("source", "complete"):
        # Not a recognised instruction: print nothing and report failure.
        return 1
    var_name = complete_var_name(prog_name)
    if action == "source":
        print(_SCRIPTS[shell](prog_name, var_name))
        return 0
    line = os.environ.get("COMP_WORDS", " ".join([prog_name] + list(args)))
    raw_cword = os.environ.get("COMP_CWORD", "")
    completed, incomplete = _split_line(shell, line, raw_cword)
    items = _suggest(cli, prog_name, completed, incomplete)
    for item in items:
        print(_format_item(item, shell))
    return 0


def _split_line(shell, line, raw_cword):
    words = line.split(" ")
    if shell == "fish":
        incomplete = raw_cword
        completed = words[1:]
        if completed and completed[-1] == incomplete:
            completed = completed[:-1]
        return completed, incomplete
    try:
        cword = int(raw_cword)
    except ValueError:
        cword = len(words)
    incomplete = words[cword] if cword < len(words) else ""
    return words[1:cword], incomplete


def _normalize(item):
    if isinstance(item, CompletionItem):
        return item
    if isinstance(item, str):
        return CompletionItem(item)
    return CompletionItem(item.value, getattr(item, "help", None), getattr(item, "type", "plain") or "plain")


def _format_item(item, shell):
    if item.type != "plain":
        return f"{item.type},{item.value}"
    if item.help and shell in ("zsh", "fish"):
        return f"plain,{item.value}\t{item.help}"
    return f"plain,{item.value}"


# spec: N-000682–N-000688 (suggestions), N-000694–N-000699 (completion functions)
def _suggest(cli, prog_name, completed, incomplete):
    ctx = core.Context(cli, info_name=prog_name)
    cmd = cli
    pending = None
    positional = 0
    for token in completed:
        if pending is not None:
            pending = None
            continue
        if token == "--":
            continue
        if token.startswith("-") and token != "-":
            name, eq, _ = token.partition("=")
            option = core._find_option(ctx, cmd._build_lookup(ctx, cmd.get_params(ctx)), name)
            if option is not None and not eq and option.is_option and not (option.is_flag or option.count):
                pending = option
            continue
        if isinstance(cmd, core.Group):
            child = cmd.get_command(ctx, token)
            if child is not None:
                ctx = core.Context(child, info_name=token, parent=ctx)
                cmd = child
                positional = 0
                continue
        positional += 1

    if pending is not None:
        return [_normalize(item) for item in pending.shell_complete(ctx, incomplete) or []]

    params = cmd.get_params(ctx)
    items = []
    if incomplete.startswith("-"):
        for param in params:
            if not param.is_option or param.hidden:
                continue
            for flag in param.opts + param.secondary_opts:
                if flag.startswith(incomplete):
                    items.append(CompletionItem(flag, help=param.help))
        return items

    if isinstance(cmd, core.Group):
        for name in cmd.list_commands(ctx):
            child = cmd.get_command(ctx, name)
            if child is None or child.hidden or not name.startswith(incomplete):
                continue
            items.append(CompletionItem(name, help=child.get_short_help_str(60)))

    arguments = [param for param in params if param.is_argument]
    target = None
    if positional < len(arguments):
        target = arguments[positional]
    elif arguments and arguments[-1].nargs == -1:
        target = arguments[-1]
    if target is not None:
        items.extend(_normalize(item) for item in target.shell_complete(ctx, incomplete) or [])
    return items


def _bash_source(prog, var):
    func = "_" + re.sub(r"\W", "_", prog) + "_completion"
    return f"""{func}() {{
    local response
    response=$(env COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD {var}=bash_complete {prog} 2>/dev/null)
    local IFS=$'\\n'
    local completion type value
    COMPREPLY=()
    for completion in $response; do
        IFS=',' read -r type value <<< "$completion"
        case "$type" in
            plain) COMPREPLY+=("$value") ;;
            dir) COMPREPLY=(); compopt -o dirnames ;;
            file) COMPREPLY=(); compopt -o default ;;
        esac
    done
    return 0
}}
complete -o nosort -F {func} {prog}"""


def _zsh_source(prog, var):
    func = "_" + re.sub(r"\W", "_", prog) + "_completion"
    return f"""#compdef {prog}

{func}() {{
    local -a response completions descriptions
    local item type rest value descr
    response=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog} 2>/dev/null)}}")
    for item in "${{response[@]}}"; do
        type="${{item%%,*}}"
        rest="${{item#*,}}"
        value="${{rest%%$'\\t'*}}"
        descr="${{rest#*$'\\t'}}"
        case "$type" in
            plain)
                if [[ "$rest" == *$'\\t'* ]]; then
                    descriptions+=("${{value}}:${{descr}}")
                else
                    completions+=("$value")
                fi ;;
            dir) _path_files -/ ;;
            file) _files ;;
        esac
    done
    if (( ${{#descriptions}} )); then _describe 'values' descriptions; fi
    if (( ${{#completions}} )); then compadd -a completions; fi
}}

compdef {func} {prog}"""


def _fish_source(prog, var):
    func = "_" + re.sub(r"\W", "_", prog) + "_completion"
    return f"""function {func}
    set -lx COMP_WORDS (commandline -cp)
    set -lx COMP_CWORD (commandline -ct)
    set -lx {var} fish_complete
    {prog} | string replace -r '^plain,' ''
end
complete --no-files --command {prog} --arguments '({func})'"""


def _powershell_source(prog, var):
    return f"""Register-ArgumentCompleter -Native -CommandName {prog} -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $words = @($commandAst.CommandElements | ForEach-Object {{ $_.ToString() }})
    if ($wordToComplete -eq '') {{ $cword = $words.Count }} else {{ $cword = $words.Count - 1 }}
    $env:COMP_WORDS = $words -join ' '
    $env:COMP_CWORD = $cword
    $env:{var} = 'powershell_complete'
    {prog} | ForEach-Object {{
        $type, $value = $_ -split ',', 2
        if ($type -eq 'plain') {{
            [System.Management.Automation.CompletionResult]::new($value, $value, 'ParameterValue', $value)
        }}
    }}
    Remove-Item Env:{var} -ErrorAction SilentlyContinue
}}"""


_SCRIPTS = {
    "bash": _bash_source,
    "zsh": _zsh_source,
    "fish": _fish_source,
    "powershell": _powershell_source,
}
