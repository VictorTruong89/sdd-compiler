"""Terminal helpers: styling, prompts, pager, progress bars and editor launch (FP-08, FP-11)."""

import contextlib
import os
import shlex
import subprocess
import sys
import tempfile
import time

from . import types as _types
from .exceptions import Abort, BadParameter
from .utils import _NoClose, echo, unstyle

__all__ = [
    "echo",
    "secho",
    "style",
    "unstyle",
    "echo_via_pager",
    "get_pager_file",
    "progressbar",
    "prompt",
    "confirm",
    "getchar",
    "pause",
    "edit",
    "clear",
]

_COLOR_NAMES = {
    "black": 0,
    "red": 1,
    "green": 2,
    "yellow": 3,
    "blue": 4,
    "magenta": 5,
    "cyan": 6,
    "white": 7,
    "bright_black": 60,
    "bright_red": 61,
    "bright_green": 62,
    "bright_yellow": 63,
    "bright_blue": 64,
    "bright_magenta": 65,
    "bright_cyan": 66,
    "bright_white": 67,
}

_SWITCH_CODES = {
    "bold": 1,
    "dim": 2,
    "italic": 3,
    "underline": 4,
    "blink": 5,
    "reverse": 7,
    "strikethrough": 9,
    "overline": 53,
}


def _color_codes(color, base):
    """SGR parameters for a foreground (base 30) or background (base 40) color."""
    if isinstance(color, str):
        if color == "reset":
            return [str(base + 9)]
        if color not in _COLOR_NAMES:
            raise TypeError(f"unknown color {color!r}")
        return [str(base + _COLOR_NAMES[color])]
    if isinstance(color, int) and not isinstance(color, bool):
        if not 0 <= color <= 255:
            raise TypeError("a color index must be in 0-255")
        return [str(base + 8), "5", str(color)]
    if isinstance(color, (list, tuple)) and len(color) == 3 and all(
        isinstance(part, int) and not isinstance(part, bool) and 0 <= part <= 255 for part in color
    ):
        return [str(base + 8), "2"] + [str(part) for part in color]
    raise TypeError(f"invalid color {color!r}")


# spec: N-000618–N-000630 (styling), N-000676 (invalid color raises)
def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
):
    """Wrap ``text`` in ANSI SGR sequences. An invalid color raises ``TypeError``."""
    codes = []
    if fg is not None:
        codes += _color_codes(fg, 30)
    if bg is not None:
        codes += _color_codes(bg, 40)
    switches = {
        "bold": bold,
        "dim": dim,
        "underline": underline,
        "overline": overline,
        "italic": italic,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for key, enabled in switches.items():
        if enabled:
            codes.append(str(_SWITCH_CODES[key]))
    if not codes:
        return text
    prefix = "\x1b[" + ";".join(codes) + "m"
    return prefix + text + ("\x1b[0m" if reset else "")


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    """Echo ``message`` styled with ``styles`` (the keywords of :func:`style`)."""
    if message is not None and not isinstance(message, bytes):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def is_interactive():
    """A session is interactive when standard input or output is a terminal."""
    return _isatty(sys.stdin) or _isatty(sys.stdout)


def _isatty(stream):
    try:
        return bool(stream.isatty())
    except (AttributeError, ValueError):
        return False


def _read_line(text, hide_input=False, err=False):
    echo(text, nl=False, err=err)
    line = sys.stdin.readline()
    if line == "":
        raise EOFError
    line = line.rstrip("\r\n")
    if _isatty(sys.stdin):
        if hide_input:
            echo(err=err)
    elif hide_input:
        echo(err=err)
    else:
        echo(line, err=err)
    return line


# spec: N-000478–N-000486, N-000491–N-000499, N-000510–N-000512 (prompts and confirm)
def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    value_proc=None,
    prompt_suffix=": ",
    show_default=True,
    err=False,
):
    """Ask for a value until a valid one is given; returns the converted value.

    An empty answer takes ``default`` when one is given; otherwise it asks again.
    Input ending raises ``EOFError``.
    """
    ptype = _types.convert_type(type, default)
    shown = text
    if default is not None and show_default:
        shown = f"{text} [{'*' * 8 if hide_input else default}]"
    while True:
        value = _read_line(shown + prompt_suffix, hide_input=hide_input, err=err)
        if value == "":
            if default is None:
                continue
            value = default
        try:
            result = ptype.convert(value)
        except BadParameter as exc:
            echo(f"Error: {exc.message}", err=True)
            continue
        if value_proc is not None:
            result = value_proc(result)
        if confirmation_prompt:
            again = _read_line("Repeat for confirmation" + prompt_suffix, hide_input=hide_input, err=err)
            if again != value:
                echo("Error: The two entered values do not match.", err=True)
                continue
        return result


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question. Empty answers take ``default``; other answers ask again."""
    if default is True:
        choices = " [Y/n]"
    elif default is False:
        choices = " [y/N]"
    else:
        choices = " [y/n]"
    while True:
        answer = _read_line(text + choices + prompt_suffix, err=err).strip().lower()
        if answer == "":
            if default is None:
                continue
            result = default
            break
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
    if abort and not result:
        raise Abort()
    return result


def getchar(echo_char=False):
    """Read one character. ``\\x03`` raises KeyboardInterrupt and end of input raises EOFError."""
    char = sys.stdin.read(1)
    if char == "":
        raise EOFError
    if char == "\x03":
        raise KeyboardInterrupt
    if char == "\x04":
        raise EOFError
    if echo_char:
        echo(char, nl=False)
    return char


# spec: N-000652–N-000653 (pause), N-000675 (non-interactive pause)
def pause(info=None, err=False):
    """Wait for a key when the session is interactive; otherwise return at once."""
    if not is_interactive():
        return
    echo(info or "Press any key to continue...", nl=False, err=err)
    try:
        getchar()
    finally:
        echo(err=err)


# spec: N-000654–N-000656 (editor), N-000963–N-000982 (contract §7)
def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor on ``text`` (or on ``filename``); returns the saved text or None."""
    if editor is None:
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if editor is None:
        editor = "notepad" if sys.platform.startswith("win") else "vi"
    run_env = None
    if env:
        run_env = dict(os.environ)
        run_env.update(env)
    if filename is not None:
        subprocess.call(shlex.split(editor) + [filename], env=run_env)
        return None
    original = text or ""
    handle, path = tempfile.mkstemp(suffix=extension)
    with os.fdopen(handle, "w", encoding="utf-8") as stream:
        stream.write(original)
    try:
        subprocess.call(shlex.split(editor) + [path], env=run_env)
        with open(path, encoding="utf-8") as stream:
            result = stream.read()
    finally:
        os.remove(path)
    if require_save and result == original:
        return None
    return result


def clear():
    """Clear the terminal when standard output is one; otherwise do nothing."""
    if _isatty(sys.stdout):
        sys.stdout.write("\x1b[2J\x1b[H")
        sys.stdout.flush()


def _pager_command():
    return os.environ.get("PAGER") or None


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream that goes to the pager when interactive."""
    command = _pager_command()
    if not (is_interactive() and command):
        yield _NoClose(sys.stdout)
        return
    process = subprocess.Popen(shlex.split(command), stdin=subprocess.PIPE)
    stream = process.stdin
    try:
        yield _PagerStream(stream, color)
    finally:
        stream.close()
        process.wait()


class _PagerStream:
    def __init__(self, stream, color):
        self._stream = stream
        self._color = color

    def write(self, text):
        if not self._color:
            text = unstyle(text)
        self._stream.write(text.encode("utf-8"))
        self._stream.flush()
        return len(text)

    def flush(self):
        self._stream.flush()


# spec: N-000631–N-000638 (pager)
def echo_via_pager(text_or_generator, color=None):
    """Write text through the pager (``PAGER``) when interactive, else to standard output."""
    if callable(text_or_generator):
        chunks = text_or_generator()
    elif isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    with get_pager_file(color=color) as stream:
        for chunk in chunks:
            if isinstance(chunk, bytes):
                chunk = chunk.decode("utf-8", "replace")
            stream.write(chunk)
            if hasattr(stream, "flush"):
                stream.flush()


# spec: N-000639–N-000647 (progress bars), N-000673–N-000674 (hidden and no-tty iteration)
class ProgressBar:
    """Progress bar over an iterable or a known length (FP-11)."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, width=36):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label
        self.hidden = hidden
        self.width = width
        self.pos = 0
        self.start = time.monotonic()
        self._printed_label = False

    @property
    def _tty(self):
        return not self.hidden and _isatty(sys.stdout)

    def __enter__(self):
        if not self.hidden and not self._tty and self.label:
            echo(self.label)
            self._printed_label = True
        return self

    def __exit__(self, exc_type, exc, tb):
        self.finish()

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps):
        self.pos += n_steps
        self.render()

    def _eta(self):
        if not self.length or self.pos == 0:
            return ""
        elapsed = time.monotonic() - self.start
        remaining = elapsed / self.pos * max(self.length - self.pos, 0)
        return f" eta {int(remaining) // 60:02d}:{int(remaining) % 60:02d}"

    def render(self):
        if not self._tty:
            return
        label = f"{self.label} " if self.label else ""
        if self.length:
            filled = int(self.width * min(self.pos, self.length) / self.length)
            bar = "#" * filled + "-" * (self.width - filled)
            text = f"\r{label}[{bar}] {self.pos}/{self.length}{self._eta()}"
        else:
            text = f"\r{label}{self.pos}"
        echo(text, nl=False)

    def finish(self):
        if self._tty:
            echo()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    """Return a progress bar; use it as a context manager and iterate over it."""
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)
