"""Exceptions raised by Optlyn.

Usage failures exit with status 2, abort and general errors with status 1
(see FP-13). Clean stops requested by an author use :class:`Exit`.
"""

import sys


class OptlynError(Exception):
    """A user-facing error that standalone programs report and exit on."""

    exit_code = 1

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def format_message(self):
        return self.message

    def show(self, file=None):
        file = file or sys.stderr
        print(f"Error: {self.format_message()}", file=file)


class UsageError(OptlynError):
    """Incorrect command-line usage. Exit status 2 (FP-13)."""

    exit_code = 2

    def show(self, file=None):
        file = file or sys.stderr
        if self.ctx is not None:
            print(self.ctx.get_usage(), file=file)
            if self.ctx.help_option_names:
                hint = self.ctx.help_option_names[0]
                print(f"Try '{self.ctx.command_path} {hint}' for help.", file=file)
            print(file=file)
        print(f"Error: {self.format_message()}", file=file)


class BadParameter(UsageError):
    """A value was refused by a type, a callback or a conversion function."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if hint is None:
            return self.message
        return f"Invalid value for {hint}: {self.message}"


class MissingParameter(UsageError):
    """A required parameter received no value from any source."""

    def __init__(self, message=None, ctx=None, param=None, param_hint=None):
        super().__init__(message or "", ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.message:
            return self.message
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        kind = "argument" if self.param is not None and self.param.is_argument else "option"
        return f"Missing {kind} {hint}."


class NoSuchOption(UsageError):
    def __init__(self, option_name, ctx=None):
        super().__init__(f"No such option: {option_name}", ctx)
        self.option_name = option_name


class NoSuchCommand(UsageError):
    def __init__(self, name, ctx=None):
        super().__init__(f"No such command '{name}'.", ctx)
        self.command_name = name


class BadOptionUsage(UsageError):
    """A usage error about an option that is not a bad value."""


class BadArgumentUsage(UsageError):
    """A usage error about arguments (for example extra arguments)."""


class NoArgsIsHelpError(UsageError):
    """No arguments were given to a command that shows help in that case.

    The help page goes to standard error and the exit status is the usage class.
    """

    def show(self, file=None):
        file = file or sys.stderr
        if self.ctx is not None:
            print(self.ctx.get_help(), file=file)


class FileError(OptlynError):
    """A file could not be opened when I/O started (general error class)."""

    exit_code = 1

    def __init__(self, filename, message, ctx=None):
        super().__init__(f"Could not open file '{filename}': {message}", ctx)
        self.filename = filename


class Abort(RuntimeError):
    """The user declined, input ended, or the author aborted. Exit status 1."""


class Exit(RuntimeError):
    """An author or built-in clean stop with a status code."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code


class DeclarationError(TypeError):
    """An invalid combination of keywords, refused when declared."""
