"""Text wrapping and help-page layout helpers."""

import re
import textwrap

# Spec: help and wrapped text use 100 columns unless the caller sets another (N-001014).
# The default maximum content width is 80 (see NOTES.md, CF-000155).
# spec: N-001014 vs N-000127 (see NOTES.md, CF-000155)
DEFAULT_MAX_CONTENT_WIDTH = 80
_PARAGRAPH_SPLIT = re.compile(r"\n\s*\n")
_BACKSPACE = "\x08"


def wrap_text(text, width=78, initial_indent="", subsequent_indent="", preserve_paragraphs=False):
    """Wrap ``text`` to ``width`` columns. Single newlines are not hard breaks."""
    width = max(width, len(initial_indent) + 1, len(subsequent_indent) + 1, 10)
    if preserve_paragraphs:
        parts = [
            wrap_text(" ".join(part.split()), width, initial_indent, subsequent_indent)
            for part in _PARAGRAPH_SPLIT.split(text.strip("\n"))
            if part.strip()
        ]
        return "\n\n".join(parts)
    return textwrap.fill(
        " ".join(text.split()),
        width=width,
        initial_indent=initial_indent,
        subsequent_indent=subsequent_indent,
        break_on_hyphens=False,
        break_long_words=True,
    )


def format_paragraphs(text, width):
    """Rewrap a docstring-style block. A paragraph starting with a backspace keeps its lines."""
    blocks = []
    for paragraph in _PARAGRAPH_SPLIT.split(text.strip("\n")):
        lines = paragraph.split("\n")
        if not any(line.strip() for line in lines):
            continue
        if lines[0].strip() == _BACKSPACE:
            blocks.append("\n".join(line.rstrip() for line in lines[1:]))
        else:
            blocks.append(wrap_text(" ".join(line.strip() for line in lines), width))
    return "\n\n".join(blocks)


def first_sentence(text):
    """Return the first sentence of ``text`` (up to the first period), on one line."""
    flat = " ".join(text.split())
    match = re.search(r"\.(\s|$)", flat)
    if match:
        return flat[: match.start() + 1]
    return flat


def ellipsize(text, width):
    """Shorten ``text`` to fit in ``width`` columns, marking the cut with '...'."""
    if len(text) <= width:
        return text
    if width <= 3:
        return text[:width]
    return text[: width - 3].rstrip() + "..."


def format_section(title, rows, width, indent=2, gap=2):
    """Lay out ``(left, right)`` rows in two columns under a heading."""
    if not rows:
        return []
    left_width = max(len(left) for left, _ in rows)
    left_width = min(left_width, max(width // 2, 10))
    right_width = max(width - indent - left_width - gap, 10)
    lines = [f"{title}:"]
    for left, right in rows:
        wrapped = textwrap.wrap(right, right_width) or [""]
        if len(left) > left_width:
            lines.append(" " * indent + left)
            lines.extend(" " * (indent + left_width + gap) + part for part in wrapped)
            continue
        first, *others = wrapped
        lines.append((" " * indent + left.ljust(left_width) + " " * gap + first).rstrip())
        lines.extend((" " * (indent + left_width + gap) + part).rstrip() for part in others)
    return lines
