"""In-process runner: invoke a command with tokens and capture its output (FP-14)."""

import contextlib
import io
import os
import sys
import tempfile


class _CaptureSink:
    """Keeps every write in order, tagged with the stream it went to."""

    def __init__(self):
        self.chunks = []


class _CaptureBuffer:
    def __init__(self, stream):
        self._stream = stream

    def write(self, data):
        data = bytes(data)
        self._stream._sink.chunks.append((self._stream.name, data))
        return len(data)

    def flush(self):
        pass


class _CaptureStream:
    """A text stream whose writes are recorded in order, for stdout or stderr."""

    def __init__(self, name, sink, charset):
        self.name = name
        self._sink = sink
        self.encoding = charset
        self.errors = "strict"
        self.buffer = _CaptureBuffer(self)

    def write(self, text):
        data = text.encode(self.encoding)
        self._sink.chunks.append((self.name, data))
        return len(text)

    def flush(self):
        pass

    def isatty(self):
        return False

    def writable(self):
        return True

    def readable(self):
        return False


class _CaptureStdin(io.TextIOWrapper):
    """Standard input fed from the invoke input; optionally echoes what it reads."""

    def __init__(self, data, charset, sink=None, echo_stdin=False):
        super().__init__(io.BytesIO(data), encoding=charset)
        self._sink = sink
        self._echo_stdin = echo_stdin

    def readline(self, *args):
        line = super().readline(*args)
        if self._echo_stdin and self._sink is not None and line:
            self._sink.chunks.append(("stdout", line.encode(self.encoding)))
        return line

    def isatty(self):
        return False


# spec: N-000726–N-000727, N-001007–N-001011 (result object)
class Result:
    """What an invocation produced."""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code, exception):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


# spec: N-000724–N-000749 (FP-14), N-001006–N-001012 (contract §9)
class CliRunner:
    """Invokes a command in-process, capturing standard streams and the exit status."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        """Swap in captured standard streams and environment for the block."""
        sink = _CaptureSink()
        data = b""
        if input is not None:
            data = input.encode(self.charset) if isinstance(input, str) else bytes(input)
        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {}
        for key, value in merged_env.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        saved_streams = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin = _CaptureStdin(data, self.charset, sink, self.echo_stdin)
        sys.stdout = _CaptureStream("stdout", sink, self.charset)
        sys.stderr = _CaptureStream("stderr", sink, self.charset)
        try:
            yield sink
        finally:
            sys.stdin, sys.stdout, sys.stderr = saved_streams
            for key, previous in saved_env.items():
                if previous is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = previous

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        """Run ``cli`` with the token list ``args``; returns a :class:`Result`."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        standalone = extra.pop("standalone_mode", True)
        prog_name = extra.pop("prog_name", None) or getattr(cli, "name", None) or "root"
        exit_code = 0
        exception = None
        return_value = None
        with self.isolation(input=input, env=env, color=color) as sink:
            try:
                return_value = cli.main(
                    args=list(args or []),
                    prog_name=prog_name,
                    standalone_mode=standalone,
                    color=color,
                    **extra,
                )
            except SystemExit as exc:
                exit_code = _exit_status(exc.code)
            except Exception as exc:
                if not catch_exceptions:
                    raise
                exception = exc
                exit_code = 1
        stdout = b"".join(data for name, data in sink.chunks if name == "stdout")
        stderr = b"".join(data for name, data in sink.chunks if name == "stderr")
        output = b"".join(data for _, data in sink.chunks)
        return Result(self, stdout, stderr, output, return_value, exit_code, exception)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Change into a new empty directory for the block and yield its path.

        The directory is left in place after the block (contract, N-001015).
        """
        previous = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(previous)


def _exit_status(code):
    if code is None:
        return 0
    if isinstance(code, int):
        return code
    print(code, file=sys.stderr)
    return 1
