"""Parameters, invocation contexts, commands and groups.

The parser is in :meth:`Command.parse_args`. Value resolution order for each
parameter is: command line, environment, prompt, default map, declared default
(FP-03, FP-07, FP-08). Parameter callbacks run after the value is resolved.
"""

import enum
import inspect
import os
import re
import shutil
import sys
import contextlib

from . import _context
from . import termui
from . import types as _types
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    DeclarationError,
    Exit,
    MissingParameter,
    NoArgsIsHelpError,
    NoSuchCommand,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import ellipsize, first_sentence, format_paragraphs, format_section
from .utils import echo

DEFAULT_MAX_CONTENT_WIDTH = 80
_PREFIX_CHARS = "-/+"
_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_MISSING = object()


# spec: N-000453–N-000456 (FP-07 value sources), N-000453 (source inspection)
class ParameterSource(enum.Enum):
    """Where a parameter's value came from (for ``Context.get_parameter_source``)."""

    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


# Higher wins when several feature-switch options share one destination.
_SOURCE_RANK = {
    ParameterSource.PROMPT: 5,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.ENVIRONMENT: 3,
    ParameterSource.DEFAULT_MAP: 2,
    ParameterSource.DEFAULT: 1,
}


def _as_list(value):
    if value is None:
        return None
    if isinstance(value, str):
        return [value]
    return list(value)


def _is_long(flag):
    return flag[:2] in ("--", "//", "++") or len(flag.lstrip("-/+")) > 1


def _parse_option_decls(decls):
    """Split declarations into (primary flags, secondary flags, destination name)."""
    opts, secondary, name = [], [], None
    for decl in decls:
        if not decl:
            raise DeclarationError("empty parameter declaration")
        if decl[0] in _PREFIX_CHARS:
            if decl[0] == "/" and decl.count("/") == 2:
                _, on, off = decl.split("/")
                opts.append("/" + on)
                secondary.append("/" + off)
            elif decl[0] != "/" and "/" in decl:
                on, off = decl.split("/", 1)
                opts.append(on)
                secondary.append(off)
            else:
                opts.append(decl)
        elif _IDENT.match(decl):
            if name is not None:
                raise DeclarationError(f"more than one destination name: {name!r}, {decl!r}")
            name = decl
        else:
            raise DeclarationError(f"invalid parameter declaration {decl!r}")
    if name is None:
        if not opts:
            raise DeclarationError("a parameter needs a name or a flag name")
        chosen = next((flag for flag in opts if _is_long(flag)), opts[0])
        name = chosen.lstrip("-/+").replace("-", "_")
    return opts, secondary, name


# spec: N-000868–N-000922 (contract §4), N-000908–N-000910 (parameter objects)
class Parameter:
    """Base class for options and arguments."""

    is_option = False
    is_argument = False
    is_flag = False
    count = False
    _auto_default = False

    def __init__(
        self,
        name,
        *,
        type=None,
        default=None,
        required=False,
        callback=None,
        nargs=1,
        multiple=False,
        metavar=None,
        expose_value=True,
        is_eager=False,
        envvar=None,
        allow_from_autoenv=True,
        shell_complete=None,
        deprecated=False,
        help=None,
        hidden=False,
    ):
        self.name = name
        self.type = _types.convert_type(type, default)
        if isinstance(self.type, _types.Tuple):
            nargs = self.type.arity
        if nargs != -1 and (not isinstance(nargs, int) or nargs < 1):
            raise DeclarationError("nargs must be a positive integer, or -1 for a variadic argument")
        self.nargs = nargs
        self.default = default
        self.required = bool(required)
        self.callback = callback
        self.multiple = bool(multiple)
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = bool(is_eager)
        self.envvar = _as_list(envvar)
        self.allow_from_autoenv = allow_from_autoenv
        self.shell_complete_func = shell_complete
        self.deprecated = deprecated
        self.help = help
        self.hidden = hidden

    def get_error_hint(self, ctx=None):
        return f"'{self.name}'"

    def get_default(self, ctx=None):
        """The declared default, with callables invoked."""
        default = self.default
        if callable(default):
            default = default()
        return default

    def invoke_default(self, ctx=None):
        """The value delivered by ``Context.invoke`` when a caller omits this parameter."""
        default = self.get_default(ctx)
        if default is None:
            return () if self.multiple or self.nargs == -1 else None
        if self.multiple and isinstance(default, (list, tuple)):
            return tuple(default)
        return default

    def shell_complete(self, ctx, incomplete):
        if self.shell_complete_func is not None:
            return self.shell_complete_func(ctx, self, incomplete)
        return self.type.shell_complete(ctx, self, incomplete)

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


# spec: N-000165–N-000272 (FP-03 options), N-000896 (declaration-time refusal)
class Option(Parameter):
    """A named parameter. Flags, counting options and value options are all options."""

    is_option = True

    def __init__(
        self,
        param_decls=None,
        *,
        is_flag=None,
        flag_value=None,
        count=False,
        prompt=False,
        prompt_required=True,
        hide_input=False,
        confirmation_prompt=False,
        show_default=None,
        show_envvar=False,
        **kwargs,
    ):
        if isinstance(param_decls, str):
            param_decls = [param_decls]
        opts, secondary, name = _parse_option_decls(list(param_decls or []))
        self.opts = opts
        self.secondary_opts = secondary
        if kwargs.get("deprecated") and (kwargs.get("required") or prompt):
            raise DeclarationError("a deprecated option cannot be required or prompt.")
        if count:
            is_flag = False
            if kwargs.get("type") is None:
                kwargs["type"] = _types.INT
            if kwargs.get("default") is None:
                kwargs["default"] = 0
        if is_flag is None:
            is_flag = bool(secondary) or (
                kwargs.get("type") is None and isinstance(kwargs.get("default"), bool)
            )
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self._auto_default = False
        if self.is_flag:
            if kwargs.get("default") is None:
                kwargs["default"] = False
                self._auto_default = True
            if kwargs.get("type") is None:
                kwargs["type"] = _types.BOOL
        self.flag_value = flag_value
        self.on_value = flag_value if (self.is_flag and flag_value is not None) else True
        self.off_value = False
        self.prompt = bool(prompt)
        self.prompt_text = prompt if isinstance(prompt, str) else None
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.show_default = show_default
        self.show_envvar = show_envvar
        if self.is_flag and kwargs.get("nargs", 1) != 1:
            raise DeclarationError("a flag takes no values")
        super().__init__(name, **kwargs)

    def get_error_hint(self, ctx=None):
        return "'" + "/".join(self.opts + self.secondary_opts) + "'"

    def flag_for(self, flag):
        return self.off_value if flag in self.secondary_opts else self.on_value


# spec: N-000273–N-000317 (FP-04 positional arguments), N-000276 (required by default)
class Argument(Parameter):
    """A positional parameter."""

    is_argument = True

    def __init__(self, param_decls=None, **kwargs):
        if isinstance(param_decls, str):
            param_decls = [param_decls]
        decls = list(param_decls or [])
        if len(decls) != 1 or not _IDENT.match(decls[0]):
            raise DeclarationError("an argument takes exactly one destination name")
        nargs = kwargs.pop("nargs", 1)
        required = kwargs.pop("required", None)
        if required is None:
            required = kwargs.get("default") is None and nargs != -1
        if kwargs.get("deprecated") and required:
            raise DeclarationError("a deprecated argument cannot be required")
        super().__init__(decls[0], nargs=nargs, required=required, **kwargs)

    def get_error_hint(self, ctx=None):
        return f"'{self.name.upper()}'"

    @property
    def placeholder(self):
        return self.metavar or self.name.upper()


# spec: N-000932–N-000962 (contract §6), N-000424–N-000473 (FP-07)
class Context:
    """The state of one invocation of a command (section 6 of the contract)."""

    def __init__(self, command, info_name=None, parent=None, obj=None, default_map=None, **settings):
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.default_map = default_map
        self.params = {}
        self.args = []
        self.protected_args = []
        self.invoked_subcommand = None
        self._sources = {}
        self._declared = set()
        self._exit_stack = contextlib.ExitStack()
        self._closed = False
        inherited = dict(parent._settings) if parent is not None else {}
        inherited.update(getattr(command, "context_settings", None) or {})
        inherited.update(settings)
        self._settings = inherited
        self.terminal_width = inherited.get("terminal_width")
        self.max_content_width = inherited.get("max_content_width", DEFAULT_MAX_CONTENT_WIDTH)
        self.help_option_names = list(inherited.get("help_option_names", ["--help"]))
        self.token_normalize_func = inherited.get("token_normalize_func")
        self.color = inherited.get("color")
        self.show_default = inherited.get("show_default", False)
        self.allow_extra_args = inherited.get("allow_extra_args", False)
        self.ignore_unknown_options = inherited.get("ignore_unknown_options", False)
        self.allow_interspersed_args = inherited.get("allow_interspersed_args")
        self.auto_envvar_prefix = inherited.get("auto_envvar_prefix")

    # -- identity -------------------------------------------------------

    @property
    def command_path(self):
        names = []
        ctx = self
        while ctx is not None:
            if ctx.info_name:
                names.append(ctx.info_name)
            ctx = ctx.parent
        return " ".join(reversed(names))

    def find_root(self):
        ctx = self
        while ctx.parent is not None:
            ctx = ctx.parent
        return ctx

    def find_object(self, object_type):
        ctx = self
        while ctx is not None:
            if ctx.obj is not None and type(ctx.obj) is object_type:
                return ctx.obj
            ctx = ctx.parent
        return None

    def ensure_object(self, object_type):
        obj = self.find_object(object_type)
        if obj is None:
            obj = object_type()
            self.obj = obj
        return obj

    def get_parameter_source(self, name):
        if name not in self._declared:
            return None
        return self._sources.get(name)

    # -- help -----------------------------------------------------------

    def get_help(self):
        return self.command.get_help(self)

    def get_usage(self):
        return self.command.get_usage(self)

    # -- lifecycle ------------------------------------------------------

    def __enter__(self):
        _context.push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        _context.pop_context(self)

    def call_on_close(self, func):
        self._exit_stack.callback(func)

    def with_resource(self, cm):
        return self._exit_stack.enter_context(cm)

    def close(self):
        if not self._closed:
            self._closed = True
            self._exit_stack.close()

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    # -- invocation -----------------------------------------------------

    def invoke(self, callback, *args, **kwargs):
        """Run a command or function from inside this context."""
        if isinstance(callback, Command):
            other = callback
            sub = Context(other, info_name=other.name, parent=self)
            try:
                for param in other.params:
                    if param.expose_value and param.name not in kwargs:
                        kwargs[param.name] = param.invoke_default(sub)
                with sub:
                    sub.params = dict(kwargs)
                    if other.callback is None:
                        return None
                    return sub.invoke(other.callback, *args, **kwargs)
            finally:
                sub.close()
        with self:
            return callback(*args, **kwargs)

    def forward(self, cmd, *args, **kwargs):
        values = dict(self.params)
        values.update(kwargs)
        return self.invoke(cmd, *args, **values)


# spec: N-001014 (maximum content width), N-000126–N-000131 (wrapping)
def _help_width(ctx):
    if ctx.terminal_width:
        return ctx.terminal_width
    size = shutil.get_terminal_size(fallback=(ctx.max_content_width, 24))
    return min(size.columns, ctx.max_content_width)


def _arg_placeholder(param):
    base = param.placeholder
    if param.nargs == -1:
        return f"{base}..." if param.required else f"[{base}]..."
    text = " ".join([base] * param.nargs)
    return text if param.required else f"[{text}]"


def _option_metavar(param):
    if param.is_flag or param.count:
        return None
    if param.metavar:
        base = param.metavar
    elif isinstance(param.type, _types.Choice):
        base = param.type.get_metavar()
    elif isinstance(param.type, _types.Tuple):
        base = " ".join(item.name.upper() for item in param.type.types)
    else:
        base = param.name.upper()
    if param.nargs > 1 and not isinstance(param.type, _types.Tuple):
        return " ".join([base] * param.nargs)
    return base


def _option_extras(param, ctx):
    extras = []
    show = param.show_default if param.show_default is not None else ctx.show_default
    if show and param.default is not None:
        if isinstance(show, str):
            extras.append(f"[default: {show}]")
        elif param.is_flag and param.default is False:
            pass
        elif callable(param.default):
            extras.append("[default: (dynamic)]")
        elif isinstance(param.default, (list, tuple)):
            extras.append("[default: " + ", ".join(str(item) for item in param.default) + "]")
        else:
            extras.append(f"[default: {param.default}]")
    if param.show_envvar and param.envvar:
        extras.append(f"[env var: {', '.join(param.envvar)}]")
    if param.deprecated:
        extras.append("(DEPRECATED)")
    return extras


def _short_help_for(cmd, limit):
    text = cmd.short_help if cmd.short_help is not None else first_sentence(cmd._description())
    return ellipsize(text, limit)


def _find_option(ctx, lookup, name):
    if name in lookup:
        return lookup[name]
    normalize = ctx.token_normalize_func
    if normalize is not None:
        target = normalize(name)
        for flag, param in lookup.items():
            if normalize(flag) == target:
                return param
    return None


def _is_option_token(ctx, lookup, token):
    if token.startswith("-") and token != "-":
        return True
    return _find_option(ctx, lookup, token.partition("=")[0]) is not None


_NEGATIVE_NUMBER = re.compile(r"^-\d")


def _is_value_token(ctx, lookup, token):
    """A token that may serve as an option's value: not an option, or a negative number."""
    if token == "-" or _NEGATIVE_NUMBER.match(token):
        return True
    return not _is_option_token(ctx, lookup, token)


class _ParseState:
    """Occurrences gathered while parsing one command line."""

    def __init__(self):
        self.occ = {}
        self.eager_order = []

    def add(self, param, occurrence):
        self.occ.setdefault(param, []).append(occurrence)
        if param.is_eager and param not in self.eager_order:
            self.eager_order.append(param)


def _groups(tokens, nargs):
    if nargs == -1:
        return [list(tokens)]
    return [list(tokens[k : k + nargs]) for k in range(0, len(tokens), nargs)]


def _attach_usage_context(exc, ctx):
    if isinstance(exc, UsageError) and exc.ctx is None:
        exc.ctx = ctx


def _warn_deprecated(ctx, kind, hint, note):
    message = f"DeprecationWarning: The {kind} {hint} is deprecated."
    if isinstance(note, str):
        message = f"{message} {note}"
    echo(message, err=True)


# spec: N-000834–N-000849 (contract §3 command), N-000103–N-000164 (FP-02 help), N-000090–N-000093 (FP-01 standalone)
class Command:
    """A leaf command: parses its own parameters and runs a callback."""

    def __init__(
        self,
        name=None,
        context_settings=None,
        callback=None,
        params=None,
        help=None,
        epilog=None,
        short_help=None,
        options_metavar="[OPTIONS]",
        add_help_option=True,
        no_args_is_help=False,
        hidden=False,
        deprecated=False,
    ):
        if name is None and callback is not None:
            name = callback.__name__
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        # FP-04: a command may have at most one variadic (consume-rest) argument.
        if sum(1 for param in self.params if param.is_argument and param.nargs == -1) > 1:
            raise DeclarationError("only one variadic argument is allowed per command.")
        self.help = help if help is not None else (inspect.getdoc(callback) if callback else None)
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"

    # -- parameters -----------------------------------------------------

    def get_params(self, ctx):
        params = list(self.params)
        if self.add_help_option:
            author_flags = {
                flag
                for param in params
                if param.is_option
                for flag in param.opts + param.secondary_opts
            }
            names = [name for name in ctx.help_option_names if name not in author_flags]
            if names:
                params.append(_make_help_option(names))
        return params

    def _no_args_help(self):
        return bool(self.no_args_is_help)

    @staticmethod
    def _build_lookup(ctx, params):
        lookup = {}
        for param in params:
            if not param.is_option:
                continue
            for flag in param.opts + param.secondary_opts:
                if flag in lookup:
                    raise DeclarationError(f"option {flag!r} is declared more than once")
                lookup[flag] = param
        return lookup

    # -- parsing --------------------------------------------------------

    def make_context(self, info_name, args, parent=None, **extra):
        """Build and parse a context for this command. Parsing runs callbacks as it goes."""
        if parent is None:
            default_map = extra.pop("default_map", None)
        elif isinstance(parent.default_map, dict) and info_name in parent.default_map:
            default_map = parent.default_map[info_name]
        else:
            default_map = None
        if default_map is None:
            default_map = self.context_settings.get("default_map")
        ctx = Context(self, info_name=info_name, parent=parent, default_map=default_map, **extra)
        try:
            with ctx:
                self.parse_args(ctx, list(args))
        except BaseException as exc:
            _attach_usage_context(exc, ctx)
            ctx.close()
            raise
        return ctx

    def parse_args(self, ctx, args):
        params = self.get_params(ctx)
        ctx._declared = {param.name for param in params}
        if not args and self._no_args_help():
            raise NoArgsIsHelpError(None, ctx)
        lookup = self._build_lookup(ctx, params)
        args_params = [param for param in params if param.is_argument]
        is_group = isinstance(self, Group)
        mixing = ctx.allow_interspersed_args
        if mixing is None:
            mixing = not is_group

        state = _ParseState()
        positional = []
        index = 0
        dd = False
        stop = None
        while index < len(args):
            token = args[index]
            if dd:
                positional.append(token)
                index += 1
                continue
            if token == "--":
                dd = True
                index += 1
                continue
            if _is_option_token(ctx, lookup, token):
                index = self._take_token(ctx, lookup, args, index, state, positional)
                continue
            if is_group:
                stop = index
                break
            positional.append(token)
            index += 1

        if stop is not None:
            if mixing:
                # A group option after the subcommand name still belongs to the group.
                forwarded = []
                index = stop
                while index < len(args):
                    token = args[index]
                    if _is_option_token(ctx, lookup, token):
                        index = self._take_token(ctx, lookup, args, index, state, [])
                    else:
                        forwarded.append(token)
                        index += 1
                positional = positional + forwarded
            else:
                positional = positional + args[stop:]

        # Eager flags (help, version) finish the invocation before missing
        # required parameters are reported (FP-02).
        processed = {}
        for param in state.eager_order:
            processed[param] = self._process_param(ctx, param, state)

        leftovers = self._assign_arguments(ctx, args_params, positional, state)

        if is_group:
            ctx.protected_args = list(leftovers)
            ctx.args = list(leftovers)
        elif leftovers:
            if ctx.allow_extra_args and not any(
                _is_option_token(ctx, lookup, token) for token in leftovers
            ):
                ctx.args = list(leftovers)
            else:
                raise BadArgumentUsage(
                    "Got unexpected extra argument(s) (" + ", ".join(repr(t) for t in leftovers) + ")",
                    ctx,
                )

        for param in params:
            if param.deprecated and param in state.occ:
                kind = "argument" if param.is_argument else "option"
                hint = param.get_error_hint(ctx)
                _warn_deprecated(ctx, kind, hint, param.deprecated)

        for param in params:
            if param not in processed:
                processed[param] = self._process_param(ctx, param, state)
        self._finalize(ctx, params, processed)

    # spec: N-000175–N-000180 (short stacking), N-000255–N-000261 (unknown options)
    def _take_token(self, ctx, lookup, args, index, state, leftovers):
        token = args[index]
        name, eq, inline = token.partition("=")
        if not eq:
            inline = None
        option = _find_option(ctx, lookup, name)
        if option is not None:
            return self._take_option(ctx, lookup, option, name, inline, args, index, state)
        if token.startswith("--"):
            if ctx.ignore_unknown_options:
                leftovers.append(token)
                return index + 1
            raise NoSuchOption(name, ctx=ctx)
        if token.startswith("-"):
            position = 1
            while position < len(token):
                flag = "-" + token[position]
                option = _find_option(ctx, lookup, flag)
                if option is None:
                    if ctx.ignore_unknown_options:
                        leftovers.append("-" + token[position:])
                        return index + 1
                    raise NoSuchOption(flag, ctx=ctx)
                rest = token[position + 1 :]
                if option.is_flag or option.count:
                    self._record_flag(option, flag, state)
                    position += 1
                    continue
                return self._take_option(
                    ctx, lookup, option, flag, rest or None, args, index, state
                )
            return index + 1
        if ctx.ignore_unknown_options:
            leftovers.append(token)
            return index + 1
        raise NoSuchOption(token, ctx=ctx)

    @staticmethod
    def _record_flag(option, flag, state):
        if option.count:
            state.add(option, ("count", 1))
        else:
            state.add(option, ("value", option.flag_for(flag)))

    def _take_option(self, ctx, lookup, option, flag, inline, args, index, state):
        if option.is_flag or option.count:
            if inline is not None:
                raise BadOptionUsage(f"Option '{flag}' does not take a value.", ctx=ctx)
            self._record_flag(option, flag, state)
            return index + 1
        if inline is not None:
            tokens = [inline]
            cursor = index + 1
            while len(tokens) < option.nargs and cursor < len(args):
                tokens.append(args[cursor])
                cursor += 1
            if len(tokens) < option.nargs:
                raise BadOptionUsage(f"Option '{flag}' requires {option.nargs} values.", ctx=ctx)
            state.add(option, ("tokens", tokens))
            return cursor
        cursor = index + 1
        has_next = cursor < len(args) and _is_value_token(ctx, lookup, args[cursor])
        if option.flag_value is not None:
            if has_next and option.nargs == 1:
                state.add(option, ("tokens", [args[cursor]]))
                return cursor + 1
            state.add(option, ("value", option.flag_value))
            return cursor
        if option.prompt and option.nargs == 1 and not has_next:
            state.add(option, ("bare", None))
            return cursor
        tokens = []
        while len(tokens) < option.nargs and cursor < len(args) and _is_value_token(
            ctx, lookup, args[cursor]
        ):
            tokens.append(args[cursor])
            cursor += 1
        if len(tokens) < option.nargs:
            if option.nargs == 1:
                raise BadOptionUsage(f"Option '{flag}' requires an argument.", ctx=ctx)
            raise BadOptionUsage(f"Option '{flag}' requires {option.nargs} arguments.", ctx=ctx)
        state.add(option, ("tokens", tokens))
        return cursor

    # spec: N-000279–N-000291 (argument arity), N-000309–N-000311 (missing and extra)
    def _assign_arguments(self, ctx, args_params, tokens, state):
        """Bind positional tokens to arguments in declaration order; returns leftovers."""
        index = 0
        for position, param in enumerate(args_params):
            later_required = sum(
                other.nargs
                for other in args_params[position + 1 :]
                if other.required and other.nargs > 0
            )
            available = len(tokens) - index
            if param.nargs == -1:
                take = max(0, available - later_required)
                if take == 0:
                    if param.required:
                        raise MissingParameter(ctx=ctx, param=param)
                    continue
                state.add(param, ("tokens", tokens[index : index + take]))
                index += take
                continue
            if available >= param.nargs:
                state.add(param, ("tokens", tokens[index : index + param.nargs]))
                index += param.nargs
                continue
            if param.required:
                raise MissingParameter(ctx=ctx, param=param)
            if available > 0:
                raise BadArgumentUsage(
                    f"Argument '{param.name}' takes {param.nargs} values.", ctx=ctx
                )
        return tokens[index:]

    # -- value resolution -----------------------------------------------

    def _process_param(self, ctx, param, state):
        """Resolve a parameter's value and run its callback. Returns (value, source)."""
        occurrences = state.occ.get(param)
        if occurrences:
            value, source = self._from_command_line(ctx, param, occurrences)
        else:
            value, source = self._from_other_sources(ctx, param)
        if param.callback is not None:
            try:
                value = param.callback(ctx, param, value)
            except BadParameter as exc:
                if exc.ctx is None:
                    exc.ctx = ctx
                if exc.param is None:
                    exc.param = param
                raise
        return value, source

    def _from_command_line(self, ctx, param, occurrences):
        kinds = [kind for kind, _ in occurrences]
        if "count" in kinds:
            return sum(payload for kind, payload in occurrences if kind == "count"), ParameterSource.COMMANDLINE
        if "value" in kinds:
            last = [payload for kind, payload in occurrences if kind == "value"][-1]
            return last, ParameterSource.COMMANDLINE
        if "bare" in kinds:
            return self._prompt(ctx, param, self._prompt_default(ctx, param)), ParameterSource.PROMPT
        values = [
            self._convert_tokens(ctx, param, payload)
            for kind, payload in occurrences
            if kind == "tokens"
        ]
        if param.multiple:
            return tuple(values), ParameterSource.COMMANDLINE
        return values[-1], ParameterSource.COMMANDLINE

    # spec: N-000230–N-000232 (value order), N-000440–N-000452 (default map), N-000434–N-000439 (env prefix)
    def _from_other_sources(self, ctx, param):
        value = self._env_value(ctx, param)
        if value is not _MISSING:
            return value, ParameterSource.ENVIRONMENT
        if param.is_option and param.prompt and param.prompt_required:
            return self._prompt(ctx, param, self._prompt_default(ctx, param)), ParameterSource.PROMPT
        value = self._default_map_value(ctx, param)
        if value is not _MISSING:
            return value, ParameterSource.DEFAULT_MAP
        value = self._declared_default(ctx, param)
        if value is not None:
            return value, ParameterSource.DEFAULT
        if param.required:
            raise MissingParameter(ctx=ctx, param=param)
        if param.multiple or param.nargs == -1:
            return (), None
        return None, None

    def _prompt_default(self, ctx, param):
        value = self._default_map_value(ctx, param)
        if value is _MISSING:
            value = self._declared_default(ctx, param)
        return value

    def _prompt(self, ctx, param, default):
        text = param.prompt_text or param.name.replace("_", " ").title()
        if param.is_flag:
            return termui.confirm(text, default=bool(default))
        return termui.prompt(
            text,
            default=default,
            hide_input=param.hide_input,
            confirmation_prompt=param.confirmation_prompt,
            type=param.type,
        )

    def _env_value(self, ctx, param):
        names = list(param.envvar or [])
        if param.is_option and param.allow_from_autoenv and ctx.auto_envvar_prefix:
            names.append(self._auto_env_name(ctx, param))
        for name in names:
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            value = self._convert_env(ctx, param, raw)
            if value is not _MISSING:
                return value
        return _MISSING

    @staticmethod
    def _auto_env_name(ctx, param):
        path = []
        node = ctx
        while node is not None and node.parent is not None:
            path.append(node.info_name)
            node = node.parent
        parts = [ctx.auto_envvar_prefix] + list(reversed(path)) + [param.name]
        return "_".join(part.replace("-", "_").upper() for part in parts if part)

    def _convert_env(self, ctx, param, raw):
        if param.is_flag:
            return _parse_flag_env(ctx, param, raw)
        if param.multiple or param.nargs != 1 or isinstance(param.type, _types.Tuple):
            tokens = param.type.split_envvar_value(raw)
            return self._build_from_groups(ctx, param, _groups(tokens, param.nargs))
        return param.type.convert(raw, param, ctx)

    def _default_map_value(self, ctx, param):
        mapping = ctx.default_map
        if not isinstance(mapping, dict) or mapping.get(param.name) is None:
            return _MISSING
        raw = mapping[param.name]
        if isinstance(raw, str):
            if param.is_flag:
                parsed = _parse_flag_env(ctx, param, raw)
                return parsed if parsed is not _MISSING else _MISSING
            if param.multiple and param.nargs == 1 and not isinstance(param.type, _types.Tuple):
                raise BadOptionUsage(
                    f"Invalid default for {param.get_error_hint(ctx)}: needs an iterable (sequence) value, not a string.",
                    ctx=ctx,
                )
            if param.multiple or param.nargs != 1 or isinstance(param.type, _types.Tuple):
                tokens = param.type.split_envvar_value(raw)
                return self._build_from_groups(ctx, param, _groups(tokens, param.nargs))
            return param.type.convert(raw, param, ctx)
        if param.multiple and isinstance(raw, (list, tuple)):
            return tuple(raw)
        return raw

    def _declared_default(self, ctx, param):
        default = param.get_default(ctx)
        if default is None:
            return None
        if param.is_flag:
            return default
        if param.multiple:
            if isinstance(default, str) or not isinstance(default, (list, tuple)):
                raise BadOptionUsage(
                    f"Invalid default for {param.get_error_hint(ctx)}: needs an iterable (sequence) default, not a string.",
                    ctx=ctx,
                )
            return tuple(
                self._convert_tokens(ctx, param, [item] if param.nargs == 1 else list(item))
                for item in default
            )
        if param.nargs != 1 or isinstance(param.type, _types.Tuple):
            if isinstance(default, (list, tuple)):
                return self._convert_tokens(ctx, param, list(default))
        return param.type.convert(default, param, ctx)

    def _convert_tokens(self, ctx, param, tokens):
        if isinstance(param.type, _types.Tuple):
            return param.type.convert(tuple(tokens), param, ctx)
        if param.nargs == 1:
            return param.type.convert(tokens[0], param, ctx)
        return tuple(param.type.convert(token, param, ctx) for token in tokens)

    def _build_from_groups(self, ctx, param, groups):
        values = [self._convert_tokens(ctx, param, group) for group in groups]
        if param.multiple:
            return tuple(values)
        if not values:
            return ()
        return values[-1]

    # spec: N-000233–N-000236 (feature-switch groups)
    def _finalize(self, ctx, params, processed):
        """Pick one value per destination (feature-switch groups) and store the params."""
        by_dest = {}
        for index, param in enumerate(params):
            if param.expose_value and param in processed:
                by_dest.setdefault(param.name, []).append((index, param))
        for dest, members in by_dest.items():
            def rank(member):
                index, param = member
                _, source = processed[param]
                base = _SOURCE_RANK.get(source, 0)
                explicit = 1 if source is ParameterSource.DEFAULT and not param._auto_default else 0
                return (base, explicit, index)

            _, winner = max(members, key=rank)
            value, source = processed[winner]
            ctx.params[dest] = value
            ctx._sources[dest] = source

    # -- invocation -----------------------------------------------------

    def invoke(self, ctx):
        if self.deprecated:
            _warn_deprecated(ctx, "command", f"'{ctx.command_path}'", self.deprecated)
        if self.callback is None:
            return None
        return ctx.invoke(self.callback, **ctx.params)

    # spec: N-000704–N-000723 (exit status), N-000842–N-000848 (main)
    def main(
        self,
        args=None,
        prog_name=None,
        complete_var=None,
        standalone_mode=True,
        **extra,
    ):
        """Run the command as a program, or in-process when ``standalone_mode`` is false."""
        from . import shell_completion

        args = list(sys.argv[1:] if args is None else args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "main"
        var_name = complete_var or shell_completion.complete_var_name(prog_name)
        instruction = os.environ.get(var_name)
        if instruction:
            status = shell_completion.handle_complete(self, prog_name, instruction, args)
            if standalone_mode:
                sys.exit(status)
            return status

        ctx = None
        try:
            try:
                ctx = self.make_context(prog_name, args, **extra)
                with ctx:
                    rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                ctx.exit()
            finally:
                if ctx is not None:
                    ctx.close()
        except Exit as exc:
            if standalone_mode:
                sys.exit(exc.exit_code)
            return exc.exit_code
        except Abort:
            if not standalone_mode:
                raise
            print("Aborted!", file=sys.stderr)
            sys.exit(1)
        except OptlynError as exc:
            if not standalone_mode:
                raise
            exc.show()
            sys.exit(exc.exit_code)
        except (EOFError, KeyboardInterrupt):
            if not standalone_mode:
                raise
            print("Aborted!", file=sys.stderr)
            sys.exit(1)

    # -- help -----------------------------------------------------------

    def _description(self):
        text = self.help
        if not text:
            return ""
        if "\f" in text:
            text = text.split("\f", 1)[0]
        return inspect.cleandoc(text)

    def get_short_help_str(self, limit=45):
        return _short_help_for(self, limit)

    def _usage_pieces(self, ctx):
        pieces = [ctx.command_path]
        params = self.get_params(ctx)
        if self.options_metavar and any(param.is_option for param in params):
            pieces.append(self.options_metavar)
        for param in params:
            if param.is_argument:
                pieces.append(_arg_placeholder(param))
        pieces.extend(self._subcommand_usage(ctx))
        return pieces

    def _subcommand_usage(self, ctx):
        return []

    def get_usage(self, ctx):
        return "Usage: " + " ".join(self._usage_pieces(ctx))

    def _extra_help_sections(self, ctx, width):
        return []

    def get_help(self, ctx):
        width = _help_width(ctx)
        blocks = []
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else "This command is deprecated."
            blocks.append(f"DEPRECATED: {note}")
        blocks.append(self.get_usage(ctx))
        description = self._description()
        if description:
            blocks.append(format_paragraphs(description, width))
        params = self.get_params(ctx)
        arg_rows = [(_arg_placeholder(p), p.help) for p in params if p.is_argument and p.help]
        blocks.append("\n".join(format_section("Positional arguments", arg_rows, width)))
        option_rows = []
        for param in params:
            if not param.is_option or param.hidden:
                continue
            left = ", ".join(param.opts)
            if param.secondary_opts:
                left += "/" + ", ".join(param.secondary_opts)
            metavar = _option_metavar(param)
            if metavar:
                left += " " + metavar
            right = " ".join([param.help or ""] + _option_extras(param, ctx)).strip()
            left = left.rstrip()
            option_rows.append((left, right))
        blocks.append("\n".join(format_section("Options", option_rows, width)))
        blocks.extend(self._extra_help_sections(ctx, width))
        if self.epilog:
            blocks.append(format_paragraphs(self.epilog, width))
        return "\n\n".join(block for block in blocks if block.strip())


def _parse_flag_env(ctx, param, raw):
    """Interpret an environment value for a flag. Returns _MISSING when it says nothing."""
    if raw == "":
        return _MISSING
    non_bool = not isinstance(param.on_value, bool)
    if non_bool and raw == str(param.on_value):
        return param.on_value
    word = raw.strip().lower()
    if word == "":
        return param.off_value
    if word in _types._TRUE_WORDS:
        return param.on_value
    if word in _types._FALSE_WORDS:
        return param.off_value
    if non_bool:
        return _MISSING
    raise BadParameter(f"{raw!r} is not a valid boolean.", ctx=ctx, param=param)


# spec: N-000142–N-000148 (help option names), N-000916 (help flag)
def _make_help_option(names):
    def _help_callback(ctx, param, value):
        if not value:
            return value
        echo(ctx.get_help(), color=ctx.color)
        ctx.exit()

    return Option(
        list(names),
        is_flag=True,
        expose_value=False,
        is_eager=True,
        callback=_help_callback,
        help="Show this message and exit.",
    )


# spec: N-000850–N-000867 (contract §3 group), N-000375–N-000423 (FP-06), N-000582–N-000607 (FP-10 chaining)
class Group(Command):
    """A command that dispatches to named subcommands."""

    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        **kwargs,
    ):
        super().__init__(name, **kwargs)
        if isinstance(commands, dict):
            self.commands = dict(commands)
        else:
            self.commands = {cmd.name: cmd for cmd in (commands or [])}
        self.invoke_without_command = invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback

    def _no_args_help(self):
        if self.no_args_is_help is None:
            return not self.invoke_without_command
        return bool(self.no_args_is_help)

    # -- children -------------------------------------------------------

    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise TypeError("a group cannot be attached beneath a chaining group.")
        self.commands[name or cmd.name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as command_decorator

        def decorator(func):
            cmd = command_decorator(*args, **kwargs)(func)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as group_decorator

        def decorator(func):
            cmd = group_decorator(*args, **kwargs)(func)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(func):
            self._result_callback = func
            return func

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        normalize = ctx.token_normalize_func
        if normalize is not None:
            target = normalize(cmd_name)
            for name, cmd in self.commands.items():
                if normalize(name) == target:
                    return cmd
        return None

    # -- parsing and dispatch -------------------------------------------

    def _subcommand_usage(self, ctx):
        meta = self.subcommand_metavar or "COMMAND"
        if self.chain:
            return [f"{meta} [ARGS]... [{meta} [ARGS]...]..."]
        if self.invoke_without_command:
            return [f"[{meta}] [ARGS]..."]
        return [f"{meta} [ARGS]..."]

    def _extra_help_sections(self, ctx, width):
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            short = cmd.get_short_help_str(max(width - 30, 20))
            if cmd.deprecated:
                short = (short + " (deprecated)").strip()
            rows.append((name, short))
        section = format_section("Commands", rows, width)
        return ["\n".join(section)] if section else []

    def _process_result(self, ctx, value):
        if self._result_callback is None:
            return value
        return ctx.invoke(self._result_callback, value, **ctx.params)

    def invoke(self, ctx):
        if self.deprecated:
            _warn_deprecated(ctx, "command", f"'{ctx.command_path}'", self.deprecated)
        if self.chain:
            return self._invoke_chain(ctx)
        if not ctx.protected_args:
            if not self.invoke_without_command:
                raise UsageError("Missing command.", ctx)
            ctx.invoked_subcommand = None
            rv = ctx.invoke(self.callback, **ctx.params) if self.callback is not None else None
            return self._process_result(ctx, rv)
        name, rest = ctx.protected_args[0], ctx.protected_args[1:]
        cmd = self.get_command(ctx, name)
        if cmd is None:
            raise NoSuchCommand(name, ctx)
        ctx.invoked_subcommand = name
        if self.callback is not None:
            ctx.invoke(self.callback, **ctx.params)
        sub = cmd.make_context(name, rest, parent=ctx)
        try:
            with sub:
                rv = cmd.invoke(sub)
        finally:
            sub.close()
        return self._process_result(ctx, rv)

    # spec: N-000584–N-000601 (chain order and variadic rule), N-000588–N-000595 (result callback)
    def _invoke_chain(self, ctx):
        tokens = ctx.protected_args
        segments = []
        index = 0
        while index < len(tokens):
            name = tokens[index]
            cmd = self.get_command(ctx, name)
            if cmd is None:
                raise NoSuchCommand(name, ctx)
            end = index + 1
            if any(param.is_argument and param.nargs == -1 for param in cmd.params):
                end = len(tokens)
            else:
                while end < len(tokens) and self.get_command(ctx, tokens[end]) is None:
                    end += 1
            segments.append((name, cmd, tokens[index + 1 : end]))
            index = end
        if not segments and not self.invoke_without_command:
            raise UsageError("Missing command.", ctx)
        ctx.invoked_subcommand = "*" if segments else None
        if self.callback is not None:
            ctx.invoke(self.callback, **ctx.params)
        results = []
        for name, cmd, toks in segments:
            sub = cmd.make_context(name, toks, parent=ctx)
            try:
                with sub:
                    results.append(cmd.invoke(sub))
            finally:
                sub.close()
        if self._result_callback is not None:
            ctx.invoke(self._result_callback, results, **ctx.params)
        return results


class CommandCollection(Group):
    """Presents the subcommands of several groups under one dispatch surface."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None
