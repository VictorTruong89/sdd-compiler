"""Output, file and platform helpers shared by the terminal helpers and types."""

import io
import os
import re
import subprocess
import sys
import tempfile

from ._context import get_current_context
from .exceptions import FileError

# CSI sequences: ESC [ parameters intermediates final
_ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")


def unstyle(text):
    """Remove ANSI escape sequences from ``text``; other text is kept."""
    return _ANSI_RE.sub("", text)


def _stream_is_tty(stream):
    try:
        return bool(stream.isatty())
    except (AttributeError, ValueError):
        return False


def _write(stream, data):
    if isinstance(data, bytes):
        buffer = getattr(stream, "buffer", None)
        if buffer is not None:
            stream.flush()
            buffer.write(data)
        else:
            stream.write(data.decode("utf-8", "replace"))
        return
    try:
        stream.write(data)
    except UnicodeEncodeError:
        # ASCII-only encodings cannot print ordinary Unicode; fall back to UTF-8 bytes.
        buffer = getattr(stream, "buffer", None)
        if buffer is None:
            raise
        stream.flush()
        buffer.write(data.encode("utf-8"))


# spec: N-000609–N-000617 (echo, color and ASCII fallback), N-000670–N-000672
def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes to standard output (or error), stripping styles when appropriate.

    Styles are kept when ``color`` is true, or when it is ``None`` and the stream is a
    terminal. The context current on this thread supplies ``color`` when not given.
    """
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        data = message + (b"\n" if nl else b"")
        _write(file, data)
        file.flush()
        return
    if color is None:
        ctx = get_current_context(silent=True)
        color = ctx.color if ctx is not None else None
    keep_styles = color if color is not None else _stream_is_tty(file)
    if not keep_styles:
        message = unstyle(message)
    data = message + ("\n" if nl else "")
    _write(file, data)
    file.flush()


class _Proxy:
    """Forwards attribute access to a wrapped file object."""

    _target = None

    def __getattr__(self, name):
        return getattr(self._get(), name)

    def _get(self):
        return self._target

    def __iter__(self):
        return iter(self._get())

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def close(self):
        self._get().close()


class _NoClose(_Proxy):
    """Standard streams are never closed by the block that used them."""

    def __init__(self, stream):
        self._target = stream

    def close(self):
        pass

    def flush(self):
        self._target.flush()


class _EncodedWriter(_Proxy):
    """Text writer that encodes to the standard output's byte stream."""

    def __init__(self, stream, encoding, errors):
        self._stream = stream
        self._encoding = encoding
        self._errors = errors

    def _get(self):
        return self._stream

    def write(self, text):
        self._stream.flush()
        self._stream.buffer.write(text.encode(self._encoding, self._errors))
        return len(text)

    def close(self):
        pass

    def flush(self):
        self._stream.flush()


def _open_real(filename, mode, encoding, errors, atomic):
    if "b" in mode:
        encoding = errors = None
    if atomic:
        return AtomicFile(filename, mode, encoding, errors)
    return open(filename, mode, encoding=encoding, errors=errors)


def _std_stream(mode, encoding, errors):
    if "r" in mode:
        if "b" in mode:
            return _NoClose(sys.stdin.buffer)
        if encoding:
            data = sys.stdin.buffer.read().decode(encoding, errors or "strict")
            return io.StringIO(data)
        return _NoClose(sys.stdin)
    if "b" in mode:
        return _NoClose(sys.stdout.buffer)
    if encoding:
        return _EncodedWriter(sys.stdout, encoding, errors or "strict")
    return _NoClose(sys.stdout)


class AtomicFile(_Proxy):
    """Writes to a sibling temporary file and replaces the target on close."""

    def __init__(self, filename, mode, encoding=None, errors=None):
        self._target_name = filename
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp_name = tempfile.mkstemp(dir=directory, prefix=".optlyn-atomic-")
        os.close(fd)
        self._target = open(self._tmp_name, mode, encoding=encoding, errors=errors)
        self._closed = False

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._target.close()
        os.replace(self._tmp_name, self._target_name)


class LazyFile(_Proxy):
    """Opens its file on first I/O instead of when constructed (FP-09)."""

    def __init__(self, filename, mode, encoding=None, errors=None, atomic=False):
        self._filename = filename
        self._mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._opened = None

    def _get(self):
        if self._opened is None:
            try:
                self._opened = _open_real(
                    self._filename, self._mode, self._encoding, self._errors, self._atomic
                )
            except OSError as exc:
                raise FileError(self._filename, exc.strerror or str(exc)) from exc
        return self._opened

    def close(self):
        if self._opened is not None:
            self._opened.close()


# spec: N-000518–N-000521 (file helper), N-000522–N-000535 (open modes), N-000536–N-000537 (dash)
def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open ``filename``; ``-`` is the standard input or output for the mode.

    Opens immediately unless ``lazy`` is true. OSError propagates when opening fails.
    """
    if filename == "-":
        return _std_stream(mode, encoding, errors)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    return _open_real(filename, mode, encoding, errors, atomic)


# spec: N-000566–N-000568 (filename formatting)
def format_filename(filename, shorten=False):
    """Return ``filename`` as text that prints and encodes as strict UTF-8."""
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    elif hasattr(filename, "__fspath__"):
        path = os.fspath(filename)
        text = os.fsdecode(path) if isinstance(path, bytes) else path
    else:
        text = str(filename)
    if shorten:
        text = os.path.basename(text)
    return text.encode("utf-8", "backslashreplace").decode("utf-8")


# spec: N-000664–N-000668 (application directory)
def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user configuration directory for ``app_name``."""
    home = os.path.expanduser("~")
    unix_folder = re.sub(r"\s+", "-", app_name.lower())
    if force_posix:
        return os.path.join(home, "." + unix_folder)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    if sys.platform.startswith("win"):
        env_name = "APPDATA" if roaming else "LOCALAPPDATA"
        base = os.environ.get(env_name) or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(config_home, unix_folder)


# spec: N-000657–N-000661 (application launch)
def launch(url, wait=False, locate=False):
    """Open ``url`` or a path with the default associated application.

    Returns the status of the opener, or 127 when no opener is available.
    """
    if sys.platform.startswith("win"):
        os.startfile(url)  # noqa: S606 - documented platform behaviour
        return 0
    if sys.platform == "darwin":
        command = ["open"] + (["-R"] if locate else []) + [url]
    else:
        command = ["xdg-open", url]
    try:
        process = subprocess.Popen(command)
    except OSError:
        return 127
    if wait:
        return process.wait()
    return 0
