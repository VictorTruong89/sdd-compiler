"""Parameter types: built-in conversions and the base class for custom types (FP-05, FP-09)."""

import datetime
import enum
import os
import pathlib
import uuid

from . import utils
from .exceptions import BadParameter


# spec: N-001003–N-001005 (completion items)
class CompletionItem:
    """One shell-completion suggestion (section 8 of the contract)."""

    __slots__ = ("value", "help", "type")

    def __init__(self, value, help=None, type="plain"):
        self.value = str(value)
        self.help = help
        self.type = type

    def __repr__(self):
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


# spec: N-000361–N-000365 (custom types), N-000923–N-000926 (contract §5)
class ParamType:
    """Base class for parameter types. Subclasses set ``name`` and implement ``convert``."""

    name = "text"
    is_composite = False

    def __call__(self, value, param=None, ctx=None):
        return self.convert(value, param, ctx)

    def convert(self, value, param=None, ctx=None):
        return value

    def get_metavar(self, param=None):
        return None

    def shell_complete(self, ctx, param, incomplete):
        return []

    def split_envvar_value(self, rv):
        return rv.split()

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, str):
            return value
        if isinstance(value, bytes):
            try:
                return value.decode("utf-8")
            except UnicodeDecodeError:
                self.fail("the value is not valid UTF-8.", param, ctx)
        return str(value)


class _IntType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        if isinstance(value, float):
            if value.is_integer():
                return int(value)
            self.fail(f"{value!r} is not a valid integer.", param, ctx)
        try:
            return int(str(value).strip(), 10)
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid float.", param, ctx)


_TRUE_WORDS = frozenset({"1", "true", "t", "yes", "y", "on"})
_FALSE_WORDS = frozenset({"0", "false", "f", "no", "n", "off"})


class _BoolType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        word = str(value).strip().lower()
        if word in _TRUE_WORDS:
            return True
        if word in _FALSE_WORDS:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


# spec: N-000320–N-000338 (string, integer, float, boolean, UUID types)
STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()


# spec: N-000339–N-000343 (choice), N-000373–N-000374 (case folding)
class Choice(ParamType):
    """A closed list of values, or the member names of an enumeration."""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.enum_type = choices
            self.choices = list(choices)
            self._names = [member.name for member in choices]
        else:
            self.enum_type = None
            self.choices = list(choices)
            self._names = [str(choice) for choice in self.choices]
        self.case_sensitive = case_sensitive

    def get_metavar(self, param=None):
        return "[" + "|".join(self._names) + "]"

    def _normalizer(self, ctx):
        func = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
        return func if func is not None else (lambda token: token)

    def convert(self, value, param=None, ctx=None):
        if self.enum_type is not None and isinstance(value, self.enum_type):
            return value
        normalize = self._normalizer(ctx)
        token = normalize(str(value))
        for choice, name in zip(self.choices, self._names):
            candidate = normalize(name)
            if self.case_sensitive:
                matched = candidate == token
            else:
                matched = candidate.casefold() == token.casefold()
            if matched:
                return choice
        choices = ", ".join(repr(name) for name in self._names)
        self.fail(f"{value!r} is not one of {choices}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        results = []
        for name in self._names:
            if self.case_sensitive:
                matched = name.startswith(incomplete)
            else:
                matched = name.casefold().startswith(incomplete.casefold())
            if matched:
                results.append(CompletionItem(name))
        return results


_DEFAULT_DATETIME_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]


# spec: N-000344–N-000348 (date-time formats)
class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DATETIME_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, datetime.datetime):
            return value
        for fmt in self.formats:
            try:
                return datetime.datetime.strptime(str(value).strip(), fmt)
            except ValueError:
                continue
        self.fail(f"{value!r} does not match the formats {', '.join(self.formats)}.", param, ctx)


def _describe_range(min_value, max_value, min_open, max_open):
    low = "" if min_value is None else f"{'>' if min_open else '>='}{min_value}"
    high = "" if max_value is None else f"{'<' if max_open else '<='}{max_value}"
    return " and ".join(part for part in (low, high) if part) or "any"


class _RangeMixin:
    def _check_range(self, value, param, ctx):
        below = self.min is not None and (value < self.min or (self.min_open and value == self.min))
        above = self.max is not None and (value > self.max or (self.max_open and value == self.max))
        if not below and not above:
            return value
        if self.clamp:
            if below:
                return self.min + 1 if self.min_open and value == self.min else self.min
            return self.max - 1 if self.max_open and value == self.max else self.max
        described = _describe_range(self.min, self.max, self.min_open, self.max_open)
        self.fail(f"{value!r} is not in the range {described}.", param, ctx)


# spec: N-000349–N-000353 (integer range and clamp)
class IntRange(_RangeMixin, _IntType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        number = _IntType.convert(self, value, param, ctx)
        return self._check_range(number, param, ctx)


# spec: N-000354–N-000356 (float range), N-000372 (clamp needs closed bounds)
class FloatRange(_RangeMixin, _FloatType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min is None or max is None or min_open or max_open):
            raise TypeError("clamp is only allowed when both bounds are set and closed.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        number = _FloatType.convert(self, value, param, ctx)
        return self._check_range(number, param, ctx)


class Tuple(ParamType):
    """A fixed-length product of inner types, one converted value per position."""

    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(item) for item in types]

    @property
    def arity(self):
        return len(self.types)

    def get_metavar(self, param=None):
        return " ".join(item.name.upper() for item in self.types)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, str) or len(value) != len(self.types):
            self.fail(f"{value!r} does not have {len(self.types)} values.", param, ctx)
        return tuple(
            item.convert(part, param, ctx) for item, part in zip(self.types, value)
        )


class FuncParamType(ParamType):
    """Adapts a plain ``f(token) -> value`` function that refuses by raising ``ValueError``."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except ValueError as exc:
            self.fail(str(exc) or f"{value!r} is not valid.", param, ctx)


# spec: N-000522–N-000537 (file type, lazy and atomic), N-000569–N-000573 (open errors)
class File(ParamType):
    """An open file object; ``-`` is the standard stream for the mode (FP-09)."""

    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"unsupported file mode {mode!r}")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def shell_complete(self, ctx, param, incomplete):
        return [CompletionItem(incomplete, type="file")]

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self.lazy if self.lazy is not None else ("w" in self.mode)
        if value == "-":
            return utils.open_file("-", self.mode, self.encoding, self.errors)
        try:
            handle = utils.open_file(
                value,
                self.mode,
                self.encoding,
                self.errors,
                lazy=lazy,
                atomic=self.atomic,
            )
        except OSError as exc:
            self.fail(f"'{value}': {exc.strerror or exc}", param, ctx)
        if ctx is not None and value != "-":
            ctx.call_on_close(handle.close)
        return handle


# spec: N-000538–N-000564 (path checks and dash), N-000574–N-000578 (checks)
class Path(ParamType):
    """A filesystem path, checked against the requested properties (FP-09)."""

    name = "path"

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def shell_complete(self, ctx, param, incomplete):
        kind = "dir" if not self.file_okay else "file"
        return [CompletionItem(incomplete, type=kind)]

    def _to_type(self, value):
        if self.path_type is pathlib.Path:
            return pathlib.Path(value)
        if self.path_type is None or self.path_type is str:
            return value
        return self.path_type(value)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            value = os.fsdecode(value)
        if self.allow_dash and value == "-":
            return self._to_type(value)
        rv = value
        if self.resolve_path:
            rv = os.path.realpath(os.path.abspath(rv))
        try:
            os.stat(rv)
            present = True
        except OSError:
            present = False
        if not present:
            if self.exists:
                self.fail(f"{value!r} does not exist.", param, ctx)
            return self._to_type(rv)
        if not self.file_okay and os.path.isfile(rv):
            self.fail(f"{value!r} is a file.", param, ctx)
        if not self.dir_okay and os.path.isdir(rv):
            self.fail(f"{value!r} is a directory.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{value!r} is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{value!r} is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{value!r} is not executable.", param, ctx)
        return self._to_type(rv)


_PYTHON_TYPES = {str: STRING, int: INT, float: FLOAT, bool: BOOL}


def convert_type(ty, default=None):
    """Turn a declared type (or an inferred one from ``default``) into a ParamType."""
    if ty is None:
        if default is None or callable(default):
            return STRING
        sample = default
        if isinstance(default, (list, tuple)):
            if not default:
                return STRING
            sample = default[0]
        if isinstance(sample, bool):
            return BOOL
        if isinstance(sample, int):
            return INT
        if isinstance(sample, float):
            return FLOAT
        return STRING
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type):
        if issubclass(ty, ParamType):
            return ty()
        if ty in _PYTHON_TYPES:
            return _PYTHON_TYPES[ty]
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"unsupported parameter type: {ty!r}")
