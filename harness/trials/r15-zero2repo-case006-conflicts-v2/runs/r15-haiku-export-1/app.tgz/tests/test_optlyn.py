"""Behavioural tests for Optlyn, organised by feature point (FP-01 .. FP-14) and the contract."""

import datetime
import io
import os
import sys
import uuid

import pytest

import optlyn
from optlyn import (
    Abort,
    Argument,
    BadParameter,
    Choice,
    Command,
    CommandCollection,
    Context,
    DateTime,
    File,
    FloatRange,
    Group,
    IntRange,
    Option,
    ParamType,
    ParameterSource,
    Path,
    Tuple,
    UsageError,
    argument,
    command,
    confirmation_option,
    custom_version_option,
    echo,
    get_current_context,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    version_option,
)
from optlyn.formatting import wrap_text
from optlyn.termui import pause, progressbar, secho, style, unstyle
from optlyn.testing import CliRunner
from optlyn.types import INT, STRING, CompletionItem
from optlyn.utils import format_filename, get_app_dir, open_file


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def clean_env(monkeypatch):
    for key in list(os.environ):
        if key.startswith(("OPTLYN_", "TOOL_", "_TOOL", "MYAPP_", "NNN", "XDG_")):
            monkeypatch.delenv(key, raising=False)
    return monkeypatch


# -- FP-01: declaration, naming, invocation ----------------------------------


@pytest.mark.parametrize(
    "func_name, expected",
    [
        ("list_all", "list-all"),
        ("make_cmd", "make"),
        ("run_command", "run"),
        ("build_grp", "build"),
        ("sync_group", "sync"),
    ],
)
def test_derived_command_names(func_name, expected):
    def _body():
        pass

    _body.__name__ = func_name
    cmd = command()(_body)
    assert cmd.name == expected


def test_explicit_name_replaces_derived(runner):
    @command("other")
    def something():
        echo("ran")

    assert runner.invoke(something, []).exit_code == 0
    assert something.name == "other"


def test_command_runs_once_and_returns_status(runner):
    calls = []

    @command()
    def hi():
        calls.append(1)
        echo("hi")

    result = runner.invoke(hi, [])
    assert result.exit_code == 0
    assert result.output == "hi\n"
    assert calls == [1]


def test_deprecated_command_still_runs_and_warns(runner):
    @command(deprecated="use new-hi")
    def hi():
        echo("ran")

    result = runner.invoke(hi, [])
    assert result.exit_code == 0
    assert "use new-hi" in result.stderr
    assert result.stdout == "ran\n"


def test_unknown_option_is_usage_error_and_callback_not_run(runner):
    calls = []

    @command()
    @option("--name")
    def hi(name):
        calls.append(name)

    result = runner.invoke(hi, ["--bogus"])
    assert result.exit_code == 2
    assert calls == []


def test_extra_arguments_rejected_unless_allowed(runner):
    @command()
    @argument("a")
    def hi(a):
        echo(a)

    assert runner.invoke(hi, ["x", "y"]).exit_code == 2
    result = runner.invoke(hi, ["x", "y"], allow_extra_args=True)
    assert result.exit_code == 0
    assert result.stdout == "x\n"


def test_standalone_off_propagates_and_returns_value(runner):
    @command()
    def answer():
        return 42

    assert runner.invoke(answer, [], standalone_mode=False).return_value == 42


def test_option_like_extra_after_allow_extra_is_still_error(runner):
    @command()
    @argument("a")
    def hi(a):
        echo(a)

    result = runner.invoke(hi, ["x", "--zzz"], allow_extra_args=True)
    assert result.exit_code == 2


# -- FP-02: help and version -------------------------------------------------


def test_help_prints_help_and_exits_zero_without_running(runner):
    calls = []

    @command(help="Does things.")
    @option("--count", type=int, default=3, help="How many.")
    def thing(count):
        calls.append(count)

    result = runner.invoke(thing, ["--help"])
    assert result.exit_code == 0
    assert calls == []
    assert "Usage: thing" in result.stdout
    assert "Does things." in result.stdout
    assert "--count COUNT" in result.stdout
    assert "How many." in result.stdout


def test_N_001013_integer_option_metavar_shows_destination(runner):
    @command()
    @option("--count", type=int)
    def thing(count):
        pass

    assert "--count COUNT" in runner.invoke(thing, ["--help"]).stdout


def test_docstring_form_feed_truncates_help(runner):
    @command()
    def thing():
        """Visible part.\f hidden part"""

    text = runner.invoke(thing, ["--help"]).stdout
    assert "Visible part." in text
    assert "hidden" not in text
    assert "\f" not in text


def test_epilog_printed_last(runner):
    @command(epilog="The end marker.")
    @option("--x")
    def thing(x):
        pass

    lines = [line for line in runner.invoke(thing, ["--help"]).stdout.splitlines() if line.strip()]
    assert lines[-1] == "The end marker."


def test_group_without_subcommand_is_usage_failure_with_help_on_stderr(runner):
    @group()
    def cli():
        """The group."""

    @cli.command()
    def sub():
        pass

    result = runner.invoke(cli, [])
    assert result.exit_code == 2
    assert "Usage: cli" in result.stderr
    assert "The group." in result.stderr
    assert result.stdout == ""


def test_help_option_names_can_be_replaced(runner):
    @command()
    def thing():
        pass

    result = runner.invoke(thing, ["-h"], help_option_names=["-h"])
    assert result.exit_code == 0
    assert "Usage: thing" in result.stdout
    assert runner.invoke(thing, ["--help"], help_option_names=["-h"]).exit_code == 2


def test_author_option_reusing_all_help_names_wins(runner):
    @command()
    @option("--help", is_flag=True, help="Mine.")
    def thing(help):
        echo(f"mine={help}")

    result = runner.invoke(thing, ["--help"])
    assert result.stdout == "mine=True\n"


def test_add_help_option_false_makes_help_unknown(runner):
    @command(add_help_option=False)
    def thing():
        pass

    assert runner.invoke(thing, ["--help"]).exit_code == 2


def test_version_option_prints_identity_and_exits(runner):
    @command()
    @version_option("9.9", prog_name="tool")
    @option("--must", required=True)
    def thing(must):
        echo("body")

    result = runner.invoke(thing, ["--version"])
    assert result.exit_code == 0
    assert "tool" in result.stdout and "9.9" in result.stdout
    assert "body" not in result.stdout


def test_custom_version_option_is_exact_callback_string(runner):
    @command()
    @custom_version_option(lambda ctx: "ID-123 (custom)")
    def thing():
        pass

    result = runner.invoke(thing, ["--version"])
    assert result.stdout == "ID-123 (custom)\n"


def test_first_eager_flag_typed_wins(runner):
    @command()
    @version_option("1.0", prog_name="tool")
    @help_option()
    def thing():
        echo("body")

    assert "version" in runner.invoke(thing, ["--version", "--help"]).stdout
    assert "Usage" in runner.invoke(thing, ["--help", "--version"]).stdout


# -- FP-03: options ----------------------------------------------------------


def test_short_stacking_and_attached_values(runner):
    @command()
    @option("-a", is_flag=True)
    @option("-b", is_flag=True)
    @option("-c")
    def thing(a, b, c):
        echo(f"{a} {b} {c}")

    assert runner.invoke(thing, ["-ab", "-cVALUE"]).stdout == "True True VALUE\n"
    assert runner.invoke(thing, ["-abc", "X"]).stdout == "True True X\n"


def test_double_dash_ends_options(runner):
    @command()
    @option("--flag", is_flag=True)
    @argument("rest", nargs=-1)
    def thing(flag, rest):
        echo(f"{flag} {rest}")

    assert runner.invoke(thing, ["--", "--flag", "x"]).stdout == "False ('--flag', 'x')\n"


def test_on_off_pair_and_env_boolean(runner, clean_env):
    @command()
    @option("--shout/--no-shout", envvar="TOOL_SHOUT", default=False)
    def thing(shout):
        echo(str(shout))

    assert runner.invoke(thing, ["--shout"]).stdout == "True\n"
    assert runner.invoke(thing, ["--no-shout"]).stdout == "False\n"
    assert runner.invoke(thing, [], env={"TOOL_SHOUT": " YES "}).stdout == "True\n"
    assert runner.invoke(thing, [], env={"TOOL_SHOUT": "off"}).stdout == "False\n"
    assert runner.invoke(thing, [], env={"TOOL_SHOUT": "maybe"}).exit_code == 2
    assert runner.invoke(thing, [], env={"TOOL_SHOUT": ""}).stdout == "False\n"


def test_counting_option(runner):
    @command()
    @option("-v", count=True)
    def thing(v):
        echo(str(v))

    assert runner.invoke(thing, ["-vvv"]).stdout == "3\n"
    assert runner.invoke(thing, []).stdout == "0\n"


def test_repeatable_option_collects_values_and_empty_default(runner):
    @command()
    @option("-p", multiple=True)
    def thing(p):
        echo(repr(p))

    assert runner.invoke(thing, ["-p", "a", "-p", "b"]).stdout == "('a', 'b')\n"
    assert runner.invoke(thing, []).stdout == "()\n"


def test_bare_string_default_on_repeatable_is_usage_error(runner):
    @command()
    @option("-p", multiple=True, default="x")
    def thing(p):
        echo(repr(p))

    result = runner.invoke(thing, [])
    assert result.exit_code == 2
    assert "'-p'" in result.stderr
    assert "iterable" in result.stderr


def test_multi_value_option_and_tuple_type(runner):
    @command()
    @option("--pair", nargs=2, type=int)
    @option("--tup", type=Tuple([str, int]))
    def thing(pair, tup):
        echo(f"{pair} {tup}")

    assert runner.invoke(thing, ["--pair", "1", "2", "--tup", "a", "3"]).stdout == "(1, 2) ('a', 3)\n"
    assert runner.invoke(thing, ["--pair", "1"]).exit_code == 2


def test_optional_value_option(runner):
    @command()
    @option("--opt", is_flag=False, flag_value="F", default="D")
    def thing(opt):
        echo(opt)

    assert runner.invoke(thing, ["--opt"]).stdout == "F\n"
    assert runner.invoke(thing, ["--opt", "V"]).stdout == "V\n"
    assert runner.invoke(thing, []).stdout == "D\n"


def test_value_option_without_value_is_usage_error(runner):
    @command()
    @option("--name")
    def thing(name):
        pass

    assert runner.invoke(thing, ["--name"]).exit_code == 2


def test_required_option_missing_is_usage_error(runner):
    @command()
    @option("--name", required=True)
    def thing(name):
        pass

    result = runner.invoke(thing, [])
    assert result.exit_code == 2
    assert "--name" in result.stderr


def test_env_var_fills_option_and_empty_value_is_unset(runner):
    @command()
    @option("--n", type=int, envvar="TOOL_N", default=1)
    def thing(n):
        echo(str(n))

    assert runner.invoke(thing, [], env={"TOOL_N": "7"}).stdout == "7\n"
    assert runner.invoke(thing, [], env={"TOOL_N": ""}).stdout == "1\n"
    assert runner.invoke(thing, ["--n", "3"], env={"TOOL_N": "7"}).stdout == "3\n"


def test_option_callback_can_replace_or_refuse(runner):
    def double(ctx, param, value):
        if value == 0:
            raise BadParameter("zero is not allowed")
        return value * 2

    @command()
    @option("--n", type=int, callback=double)
    def thing(n):
        echo(str(n))

    assert runner.invoke(thing, ["--n", "4"]).stdout == "8\n"
    result = runner.invoke(thing, ["--n", "0"])
    assert result.exit_code == 2
    assert "zero is not allowed" in result.stderr


def test_hidden_parameter_not_passed_to_callback(runner):
    @command()
    @option("--secret", expose_value=False, is_flag=True)
    def thing():
        echo("ok")

    result = runner.invoke(thing, ["--secret"])
    assert result.exit_code == 0
    assert result.stdout == "ok\n"


def test_feature_switch_last_declared_wins_ties(runner):
    @command()
    @option("--fast", "mode", is_flag=True, flag_value="fast")
    @option("--slow", "mode", is_flag=True, flag_value="slow")
    def thing(mode):
        echo(str(mode))

    assert runner.invoke(thing, ["--fast"]).stdout == "fast\n"


def test_option_declaration_errors_are_raised_at_declaration():
    with pytest.raises(TypeError):
        option("--x", required=True, deprecated=True)(lambda x: None)


def test_deprecated_option_warns_only_when_supplied(runner):
    @command()
    @option("--old", default="z", deprecated=True)
    def thing(old):
        echo(old)

    assert "deprecated" not in runner.invoke(thing, []).stderr
    assert "deprecated" in runner.invoke(thing, ["--old", "q"]).stderr


def test_option_prefix_slash_is_supported(runner):
    @command()
    @option("/force", is_flag=True)
    @argument("name")
    def thing(force, name):
        echo(f"{force} {name}")

    assert runner.invoke(thing, ["/force", "x"]).stdout == "True x\n"
    assert runner.invoke(thing, ["x"]).stdout == "False x\n"


# -- FP-04: positional arguments --------------------------------------------


def test_arguments_bind_in_order_and_missing_is_usage_error(runner):
    @command()
    @argument("first")
    @argument("second", required=False, default="dflt")
    def thing(first, second):
        echo(f"{first} {second}")

    assert runner.invoke(thing, ["a"]).stdout == "a dflt\n"
    assert runner.invoke(thing, []).exit_code == 2


def test_variadic_argument_collects_rest(runner):
    @command()
    @argument("head")
    @argument("tail", nargs=-1)
    def thing(head, tail):
        echo(f"{head} {tail}")

    assert runner.invoke(thing, ["a", "b", "c"]).stdout == "a ('b', 'c')\n"
    assert runner.invoke(thing, ["a"]).stdout == "a ()\n"


def test_argument_environment_must_be_named(runner, clean_env):
    @command()
    @argument("who", envvar="TOOL_WHO", required=False)
    @argument("other", required=False)
    def thing(who, other):
        echo(f"{who} {other}")

    assert runner.invoke(thing, [], env={"TOOL_WHO": "env"}).stdout == "env None\n"
    assert runner.invoke(thing, [], env={"WHO": "no"}).stdout == "None None\n"


def test_deprecated_required_argument_refused_at_declaration():
    with pytest.raises(TypeError):
        argument("x", deprecated=True)(lambda x: None)


# -- FP-05: types ------------------------------------------------------------


def test_builtin_types_convert(runner):
    @command()
    @option("--i", type=INT)
    @option("--f", type=float)
    @option("--b", type=bool)
    def thing(i, f, b):
        echo(repr((i, f, b)))

    assert runner.invoke(thing, ["--i", "4", "--f", "1.5", "--b", "YES"]).stdout == "(4, 1.5, True)\n"
    assert runner.invoke(thing, ["--i", "1.5"]).exit_code == 2
    assert runner.invoke(thing, ["--b", "maybe"]).exit_code == 2


def test_default_infers_type(runner):
    @command()
    @option("--n", default=2)
    def thing(n):
        echo(repr(n))

    assert runner.invoke(thing, ["--n", "9"]).stdout == "9\n"


def test_choice_case_insensitive_returns_original(runner):
    import enum

    class Color(enum.Enum):
        RED = 1
        BLUE = 2

    @command()
    @option("--c", type=Choice(Color, case_sensitive=False))
    @option("--d", type=Choice(["Alpha", "Beta"], case_sensitive=False))
    def thing(c, d):
        echo(repr((c, d)))

    assert runner.invoke(thing, ["--c", "blue", "--d", "beta"]).stdout == "(<Color.BLUE: 2>, 'Beta')\n"
    assert runner.invoke(thing, ["--c", "green"]).exit_code == 2


def test_int_range_closed_open_and_clamp():
    rng = IntRange(1, 5, min_open=True)
    with pytest.raises(BadParameter):
        rng.convert("1")
    assert IntRange(1, 5, clamp=True).convert("0") == 1
    assert IntRange(1, 5, max_open=True, clamp=True).convert("5") == 4


def test_float_range_clamp_requires_closed_bounds():
    with pytest.raises(TypeError):
        FloatRange(0.0, 1.0, min_open=True, clamp=True)
    assert FloatRange(0.0, 1.0, clamp=True).convert("2") == 1.0


def test_datetime_default_and_custom_formats():
    assert DateTime().convert("2024-02-03 04:05:06") == datetime.datetime(2024, 2, 3, 4, 5, 6)
    assert DateTime(["%d/%m/%Y"]).convert("03/02/2024") == datetime.datetime(2024, 2, 3)
    with pytest.raises(BadParameter):
        DateTime(["%d/%m/%Y"]).convert("2024-02-03")


def test_custom_param_type_subclass(runner):
    class Upper(ParamType):
        name = "upper"

        def convert(self, value, param=None, ctx=None):
            return value.upper() if isinstance(value, str) else value

    @command()
    @option("--u", type=Upper())
    def thing(u):
        echo(u)

    assert runner.invoke(thing, ["--u", "abc"]).stdout == "ABC\n"


def test_conversion_function_refusal(runner):
    def positive(token):
        value = int(token)
        if value <= 0:
            raise ValueError("must be positive")
        return value

    @command()
    @option("--n", type=positive)
    def thing(n):
        echo(str(n))

    result = runner.invoke(thing, ["--n", "-1"])
    assert result.exit_code == 2
    assert "--n" in result.stderr


def test_uuid_type(runner):
    @command()
    @option("--id", type=optlyn.UUID)
    def thing(id):
        echo(str(id))

    value = uuid.UUID(int=5)
    assert runner.invoke(thing, ["--id", str(value)]).stdout == f"{value}\n"


# -- FP-06: groups ----------------------------------------------------------


def _make_tool():
    @group()
    @option("--verbose", is_flag=True)
    def tool(verbose):
        echo(f"group verbose={verbose}")

    @tool.command()
    def hello():
        echo("hello")

    @tool.group()
    def inner():
        pass

    @inner.command()
    def deep():
        echo("deep")

    return tool


def test_group_callback_runs_before_child_and_nesting_works(runner):
    tool = _make_tool()
    result = runner.invoke(tool, ["--verbose", "inner", "deep"])
    assert result.exit_code == 0
    assert result.stdout == "group verbose=True\ndeep\n"


def test_skipping_middle_name_is_unknown_command(runner):
    tool = _make_tool()
    result = runner.invoke(tool, ["deep"])
    assert result.exit_code == 2
    assert "No such command 'deep'" in result.stderr


def test_unknown_subcommand_does_not_run_group_callback(runner):
    tool = _make_tool()
    result = runner.invoke(tool, ["nope"])
    assert result.exit_code == 2
    assert "group verbose" not in result.output


def test_child_help_after_name_and_group_help_before(runner):
    tool = _make_tool()
    assert "Usage: tool hello" in runner.invoke(tool, ["hello", "--help"]).stdout
    group_help = runner.invoke(tool, ["--help"])
    assert group_help.exit_code == 0
    assert "group verbose" not in group_help.stdout


def test_group_option_after_subcommand_is_unknown(runner):
    tool = _make_tool()
    assert runner.invoke(tool, ["hello", "--verbose"]).exit_code == 2


def test_invoke_without_command_runs_group_callback(runner):
    @group(invoke_without_command=True)
    def cli():
        echo(f"subcommand={get_current_context().invoked_subcommand}")

    result = runner.invoke(cli, [])
    assert result.exit_code == 0
    assert result.stdout == "subcommand=None\n"


def test_command_collection_union(runner):
    @group()
    def one():
        pass

    @one.command()
    def a():
        echo("a")

    @group()
    def two():
        pass

    @two.command()
    def b():
        echo("b")

    combined = group(cls=CommandCollection, sources=[one, two])(lambda: None)
    combined.name = "combined"
    assert combined.list_commands(None) == ["a", "b"]
    assert runner.invoke(combined, ["a"]).stdout == "a\n"
    assert runner.invoke(combined, ["b"]).stdout == "b\n"


def test_custom_group_lazy_lookup(runner):
    class Lazy(Group):
        def list_commands(self, ctx):
            return ["dyn"]

        def get_command(self, ctx, cmd_name):
            if cmd_name == "dyn":
                return command()(lambda: echo("loaded"))
            return None

    cli = Lazy(name="lazy")
    assert runner.invoke(cli, ["dyn"]).stdout == "loaded\n"
    assert "dyn" in runner.invoke(cli, ["--help"]).stdout


def test_hidden_command_omitted_from_help_but_invocable(runner):
    @group()
    def cli():
        pass

    @cli.command(hidden=True)
    def secret():
        echo("found")

    assert "secret" not in runner.invoke(cli, ["--help"]).stdout
    assert runner.invoke(cli, ["secret"]).stdout == "found\n"


def test_attaching_group_beneath_chain_group_is_refused():
    chain = Group(name="chain", chain=True)
    with pytest.raises(TypeError):
        chain.add_command(Group(name="child"))
    chain.add_command(Command(name="leaf"))


# -- FP-07: invocation context ----------------------------------------------


def test_obj_is_inherited_and_pass_decorators(runner):
    class Config:
        pass

    @group()
    @pass_context
    def cli(ctx):
        ctx.obj = Config()

    @cli.command()
    @make_pass_decorator(Config)
    def run(config):
        echo(type(config).__name__)

    @cli.command()
    @pass_obj
    def other(obj):
        echo(type(obj).__name__)

    assert runner.invoke(cli, ["run"]).stdout == "Config\n"
    assert runner.invoke(cli, ["other"]).stdout == "Config\n"


def test_make_pass_decorator_ensure_creates_object(runner):
    class Bag:
        pass

    @command()
    @make_pass_decorator(Bag, ensure=True)
    def cmd(bag):
        echo(type(bag).__name__)

    assert runner.invoke(cmd, []).stdout == "Bag\n"


def test_auto_envvar_prefix_includes_subcommand_path(runner, clean_env):
    @group()
    def cli():
        pass

    @cli.command()
    @option("--mode")
    def sub(mode):
        echo(str(mode))

    clean_env.setenv("MYAPP_SUB_MODE", "from-env")
    result = runner.invoke(cli, ["sub"], auto_envvar_prefix="MYAPP")
    assert result.stdout == "from-env\n"


def test_default_map_nests_by_subcommand_and_env_beats_map(runner, clean_env):
    @group()
    def cli():
        pass

    @cli.command()
    @option("--x", type=int, default=1, envvar="TOOL_X")
    def sub(x):
        echo(str(x))

    assert runner.invoke(cli, ["sub"], default_map={"sub": {"x": 9}}).stdout == "9\n"
    assert runner.invoke(cli, ["sub"], default_map={"other": {"x": 9}}).stdout == "1\n"
    assert runner.invoke(cli, ["sub"], default_map={"sub": {"x": 9}}, env={"TOOL_X": "4"}).stdout == "4\n"


def test_parameter_source_reports_each_source(runner, clean_env):
    seen = {}

    @command()
    @option("--cli", type=int)
    @option("--env", type=int, envvar="TOOL_ENV")
    @option("--map", type=int)
    @option("--dflt", type=int, default=3)
    @pass_context
    def cmd(ctx, cli, env, map, dflt):
        for name in ("cli", "env", "map", "dflt", "nothing"):
            seen[name] = ctx.get_parameter_source(name)

    runner.invoke(cmd, ["--cli", "1"], env={"TOOL_ENV": "2"}, default_map={"map": 4})
    assert seen["cli"] is ParameterSource.COMMANDLINE
    assert seen["env"] is ParameterSource.ENVIRONMENT
    assert seen["map"] is ParameterSource.DEFAULT_MAP
    assert seen["dflt"] is ParameterSource.DEFAULT
    assert seen["nothing"] is None


def test_context_invoke_and_forward(runner):
    @command()
    @option("--a", type=int, default=0)
    def target(a):
        echo(f"target a={a}")
        return a

    @command()
    @option("--a", type=int, default=5)
    @pass_context
    def caller(ctx, a):
        ctx.invoke(target, a=2)
        ctx.forward(target)

    result = runner.invoke(caller, [])
    assert result.stdout == "target a=2\ntarget a=5\n"


def test_with_resource_closed_after_invocation(runner):
    closed = []

    class Resource:
        def __enter__(self):
            return "value"

        def __exit__(self, *exc):
            closed.append(True)

    @command()
    @pass_context
    def cmd(ctx):
        echo(ctx.with_resource(Resource()))

    assert runner.invoke(cmd, []).stdout == "value\n"
    assert closed == [True]


def test_current_context_only_on_entering_thread(runner):
    import threading

    @command()
    def cmd():
        pass

    ctx = Context(cmd, info_name="x")
    results = []
    with ctx:
        assert get_current_context() is ctx
        thread = threading.Thread(target=lambda: results.append(get_current_context(silent=True)))
        thread.start()
        thread.join()
    assert results == [None]
    assert get_current_context(silent=True) is None
    with pytest.raises(RuntimeError):
        get_current_context()


# -- FP-08: prompts and confirmation ----------------------------------------


def test_option_prompts_when_omitted_and_skips_on_cli(runner):
    @command()
    @option("--name", prompt=True)
    def cmd(name):
        echo(name)

    assert runner.invoke(cmd, [], input="ann\n").stdout == "Name: ann\nann\n"
    assert runner.invoke(cmd, ["--name", "bob"]).stdout == "bob\n"


def test_prompt_reasks_until_valid_and_eof_aborts(runner):
    @command()
    @option("--n", type=int, prompt="Number")
    def cmd(n):
        echo(str(n))

    result = runner.invoke(cmd, [], input="x\n4\n")
    assert "Number:" in result.stdout
    assert result.stdout.endswith("4\n")
    eof = runner.invoke(cmd, [], input="")
    assert eof.exit_code == 1
    assert "Aborted!" in eof.stderr


def test_prompt_default_used_on_empty_answer(runner):
    @command()
    @option("--name", prompt=True, default="zed")
    def cmd(name):
        echo(name)

    assert runner.invoke(cmd, [], input="\n").stdout.endswith("zed\n")


def test_environment_value_skips_prompt(runner, clean_env):
    @command()
    @option("--name", prompt=True, envvar="TOOL_NAME")
    def cmd(name):
        echo(name)

    result = runner.invoke(cmd, [], env={"TOOL_NAME": "envy"})
    assert result.stdout == "envy\n"


def test_password_option_confirms_pair(runner):
    @command()
    @password_option()
    def cmd(password):
        echo(password)

    assert runner.invoke(cmd, [], input="a\na\n").stdout == "Password: \nRepeat for confirmation: \na\n"
    mismatch = runner.invoke(cmd, [], input="a\nb\na\na\n")
    assert "do not match" in mismatch.stderr
    assert mismatch.stdout.endswith("a\n")


def test_confirmation_option_flag_skips_question(runner):
    @command()
    @confirmation_option()
    def cmd():
        echo("ran")

    assert runner.invoke(cmd, ["--yes"], input="").stdout == "ran\n"


def test_confirmation_declined_aborts_and_standalone_off_propagates(runner):
    @command()
    @confirmation_option()
    def cmd():
        echo("ran")

    declined = runner.invoke(cmd, [], input="n\n")
    assert declined.exit_code == 1
    assert "ran" not in declined.stdout
    assert "Aborted!" in declined.stderr
    with pytest.raises(Abort):
        runner.invoke(cmd, [], input="no\n", standalone_mode=False, catch_exceptions=False)


def test_confirm_other_answer_asks_again(runner):
    @command()
    def cmd():
        from optlyn import confirm

        echo(str(confirm("Go?")))

    result = runner.invoke(cmd, [], input="maybe\nyes\n")
    assert result.stdout.endswith("True\n")
    assert result.stdout.count("Go?") == 2


# -- FP-09: files and paths --------------------------------------------------


def test_file_write_is_lazy_and_read_fails_early(runner):
    @command()
    @argument("out", type=File("w"))
    def cmd(out):
        pass

    with runner.isolated_filesystem():
        open("keep.txt", "w").write("old")
        runner.invoke(cmd, ["keep.txt"])
        assert open("keep.txt").read() == "old"

    @command()
    @argument("inp", type=File("r"))
    def read_cmd(inp):
        echo("never")

    result = runner.invoke(read_cmd, ["missing-file-xyz"])
    assert result.exit_code == 2
    assert "missing-file-xyz" in result.stderr


def test_dash_is_standard_stream(runner):
    @command()
    @argument("inp", type=File("r"))
    def cmd(inp):
        echo(inp.read().strip().upper())

    assert runner.invoke(cmd, ["-"], input="hey\n").stdout == "HEY\n"


def test_atomic_write_replaces_on_close(runner):
    with runner.isolated_filesystem():
        open("target.txt", "w").write("original")
        handle = open_file("target.txt", "w", atomic=True)
        handle.write("new")
        assert open("target.txt").read() == "original"
        handle.close()
        assert open("target.txt").read() == "new"


def test_path_checks_and_dash(runner):
    @command()
    @argument("p", type=Path(exists=True, dir_okay=False))
    def cmd(p):
        echo(str(p))

    with runner.isolated_filesystem():
        open("f.txt", "w").write("x")
        os.mkdir("sub")
        assert runner.invoke(cmd, ["f.txt"]).stdout == "f.txt\n"
        assert runner.invoke(cmd, ["sub"]).exit_code == 2
        assert runner.invoke(cmd, ["nothere"]).exit_code == 2

    assert Path(allow_dash=True).convert("-") == "-"


def test_path_type_object(runner):
    import pathlib

    assert Path(path_type=pathlib.Path).convert("a/b") == pathlib.Path("a/b")


def test_format_filename_keeps_printable_names_distinct():
    assert format_filename("name.txt") == "name.txt"
    assert format_filename(b"x\xffy") != format_filename("xy")
    assert format_filename("/tmp/dir/file.txt", shorten=True) == "file.txt"


# -- FP-10: chaining --------------------------------------------------------


def test_chain_runs_each_subcommand_and_result_callback(runner):
    @group(chain=True)
    def pipe():
        pass

    @pipe.command()
    @argument("x", type=int)
    def add(x):
        return x + 1

    @pipe.command()
    @argument("y", type=int)
    def mul(y):
        return y * 10

    @pipe.result_callback()
    def summary(results, **params):
        echo(f"sum={sum(results)}")

    result = runner.invoke(pipe, ["add", "1", "mul", "4"])
    assert result.stdout == "sum=42\n"
    values = runner.invoke(pipe, ["add", "1", "mul", "4"], standalone_mode=False)
    assert values.return_value == [2, 40]


def test_chain_empty_with_invoke_without_command(runner):
    @group(chain=True, invoke_without_command=True)
    def pipe():
        pass

    @pipe.result_callback()
    def done(results):
        echo(f"results={results}")

    assert runner.invoke(pipe, []).stdout == "results=[]\n"


# -- FP-11: terminal helpers ------------------------------------------------


def test_echo_strips_styles_unless_color_forced(runner):
    @command()
    def cmd():
        echo(style("hi", fg="red"))
        echo(style("hi", fg="red"), color=True)

    out = runner.invoke(cmd, []).stdout
    assert out.splitlines()[0] == "hi"
    assert "\x1b[" in out.splitlines()[1]


def test_color_setting_on_invocation(runner):
    @command()
    def cmd():
        echo(style("x", bold=True))

    assert "\x1b[" in runner.invoke(cmd, [], color=True).stdout


def test_style_colors_and_errors():
    assert style("a", fg="red") != style("a", bg="red")
    assert style("a", fg=(1, 2, 3)) != style("a", fg="red")
    assert style("a", fg=200) != style("a", fg=201)
    assert unstyle(style("abc", fg="green", bold=True, underline=True)) == "abc"
    with pytest.raises(TypeError):
        style("x", fg="notacolor")
    with pytest.raises(TypeError):
        style("x", fg=256)


def test_secho_styles_and_strips_for_non_terminal(runner):
    @command()
    def cmd():
        secho("ok", fg="green")

    assert runner.invoke(cmd, []).stdout == "ok\n"


def test_echo_writes_utf8_on_ascii_stream():
    stream = io.TextIOWrapper(io.BytesIO(), encoding="ascii")
    echo("café", file=stream)
    stream.flush()
    assert stream.buffer.getvalue() == "café\n".encode("utf-8")


def test_progressbar_visits_every_item_without_terminal(runner):
    @command()
    def cmd():
        items = list(range(4))
        with progressbar(items, label="work") as bar:
            seen = [item for item in bar]
        echo(str(seen))

    result = runner.invoke(cmd, [])
    assert "work" in result.stdout
    assert "[0, 1, 2, 3]" in result.stdout


def test_hidden_progressbar_prints_nothing(runner):
    @command()
    def cmd():
        with progressbar(["a", "b"], label="quiet", hidden=True) as bar:
            echo(",".join(bar))

    assert runner.invoke(cmd, []).stdout == "a,b\n"


def test_pause_does_nothing_when_not_interactive(runner):
    @command()
    def cmd():
        pause()
        echo("after")

    assert runner.invoke(cmd, [], input="").stdout == "after\n"


def test_app_dir_on_posix_forced_ignores_xdg(monkeypatch):
    monkeypatch.setenv("XDG_CONFIG_HOME", "/nowhere")
    assert get_app_dir("My Tool", force_posix=True).endswith(os.sep + ".my-tool")
    assert get_app_dir("My Tool").startswith("/nowhere") or sys.platform != "linux"


def test_wrap_text_default_and_paragraphs():
    text = wrap_text("alpha beta gamma delta " * 8, width=40)
    assert max(len(line) for line in text.splitlines()) <= 40
    assert wrap_text("", width=20) == ""


# -- FP-12: shell completion ------------------------------------------------


def _tool():
    @group()
    def tool():
        pass

    @tool.command(hidden=True)
    def hidden():
        pass

    @tool.command()
    @option("--level", type=Choice(["low", "high"]))
    @option("--out", type=Path(dir_okay=False))
    @argument("target", type=Choice(["alpha", "beta"]))
    def run(level, out, target):
        pass

    return tool


def _complete(runner, cli, line, cword):
    return runner.invoke(
        cli,
        [],
        env={"_TOOL_COMPLETE": "bash_complete", "COMP_WORDS": line, "COMP_CWORD": str(cword)},
    ).stdout


def test_completion_suggests_commands_and_hides_hidden(runner):
    out = _complete(runner, _tool(), "tool ", 1)
    assert "plain,run" in out
    assert "hidden" not in out


def test_completion_options_only_after_dash_and_include_help(runner):
    tool = _tool()
    assert _complete(runner, tool, "tool run ", 2).count("--") == 0
    out = _complete(runner, tool, "tool run --", 2)
    assert "plain,--level" in out and "plain,--help" in out


def test_completion_choice_and_path_requests(runner):
    tool = _tool()
    assert "plain,low" in _complete(runner, tool, "tool run --level ", 3)
    filtered = _complete(runner, tool, "tool run --level h", 3)
    assert "plain,high" in filtered and "plain,low" not in filtered
    assert "file," in _complete(runner, tool, "tool run --out ", 3)
    assert "plain,alpha" in _complete(runner, tool, "tool run ", 2)


def test_completion_unmatched_is_empty_not_error(runner):
    result = runner.invoke(
        _tool(), [], env={"_TOOL_COMPLETE": "bash_complete", "COMP_WORDS": "tool zzz", "COMP_CWORD": "1"}
    )
    assert result.exit_code == 0
    assert result.stdout == ""


def test_completion_source_scripts_for_each_shell(runner):
    for shell in ("bash", "zsh", "fish", "powershell"):
        result = runner.invoke(_tool(), [], env={"_TOOL_COMPLETE": f"{shell}_source"})
        assert result.exit_code == 0
        assert "_TOOL_COMPLETE" in result.stdout
        assert "bash_complete" in result.stdout or "zsh_complete" in result.stdout or "fish_complete" in result.stdout or "powershell_complete" in result.stdout


def test_completion_unrecognised_instruction_prints_nothing(runner):
    result = runner.invoke(_tool(), [], env={"_TOOL_COMPLETE": "tcsh_source"})
    assert result.stdout == "" and result.exit_code == 1


def test_completion_var_is_ignored_for_other_program_names(runner):
    result = runner.invoke(
        _tool(),
        ["run", "alpha"],
        prog_name="other-tool",
        env={"_TOOL_COMPLETE": "bash_source", "_OTHER_TOOL_COMPLETE": ""},
    )
    assert result.exit_code == 0 and result.stdout == ""


def test_custom_completion_function_supplies_values(runner):
    def complete(ctx, param, incomplete):
        return [CompletionItem("pick-" + incomplete, help="custom")]

    @command()
    @option("--x", shell_complete=complete)
    def cmd(x):
        pass

    out = runner.invoke(
        cmd, [], env={"_CMD_COMPLETE": "zsh_complete", "COMP_WORDS": "cmd --x p", "COMP_CWORD": "2"}
    ).stdout
    assert "plain,pick-p\tcustom" in out


# -- FP-13: exit status -----------------------------------------------------


def test_author_exit_status_and_abort(runner):
    @command()
    @option("--code", type=int, default=0)
    @pass_context
    def cmd(ctx, code):
        if code == 9:
            ctx.exit(9)
        if code == 8:
            ctx.abort()
        echo("end")

    assert runner.invoke(cmd, []).exit_code == 0
    assert runner.invoke(cmd, ["--code", "9"]).exit_code == 9
    aborted = runner.invoke(cmd, ["--code", "8"])
    assert aborted.exit_code == 1 and "Aborted!" in aborted.stderr


def test_usage_error_identifies_parameter(runner):
    @command()
    @option("--count", type=int)
    def cmd(count):
        pass

    result = runner.invoke(cmd, ["--count", "x"])
    assert result.exit_code == 2
    assert "--count" in result.stderr


def test_standalone_off_raises_usage_error(runner):
    @command()
    @option("--count", type=int)
    def cmd(count):
        pass

    result = runner.invoke(cmd, ["--count", "x"], standalone_mode=False)
    assert isinstance(result.exception, UsageError)


# -- FP-14: in-process runner -----------------------------------------------


def test_runner_captures_stdout_stderr_and_output_in_order(runner):
    @command()
    def cmd():
        echo("out-1")
        echo("err-1", err=True)
        echo("out-2")

    result = runner.invoke(cmd, [])
    assert result.stdout == "out-1\nout-2\n"
    assert result.stderr == "err-1\n"
    assert result.output == "out-1\nerr-1\nout-2\n"
    assert result.stdout_bytes == b"out-1\nout-2\n"


def test_runner_catches_exception_and_reports_it(runner):
    @command()
    def cmd():
        raise ValueError("boom")

    result = runner.invoke(cmd, [])
    assert result.exit_code == 1
    assert isinstance(result.exception, ValueError)
    with pytest.raises(ValueError):
        runner.invoke(cmd, [], catch_exceptions=False)


def test_runner_env_none_unsets_variable(runner, clean_env):
    clean_env.setenv("TOOL_KEEP", "1")

    @command()
    @option("--k", envvar="TOOL_KEEP")
    def cmd(k):
        echo(str(k))

    assert runner.invoke(cmd, [], env={"TOOL_KEEP": None}).stdout == "None\n"


def test_runner_input_fed_to_stdin_and_hidden_prompt_not_echoed(runner):
    @command()
    @option("--pw", prompt=True, hide_input=True)
    def cmd(pw):
        echo("got")

    result = runner.invoke(cmd, [], input="secretvalue\n")
    assert "secretvalue" not in result.output
    assert result.stdout.endswith("got\n")


def test_runner_isolated_filesystem_leaves_directory(runner):
    with runner.isolated_filesystem() as path:
        open("made.txt", "w").write("x")
        assert os.path.isdir(path)
        assert os.getcwd() == os.path.realpath(path) or os.getcwd() == path
    assert os.path.exists(os.path.join(path, "made.txt"))


def test_runner_echo_stdin_mirrors_reads(runner):
    @command()
    def cmd():
        echo(sys.stdin.readline().strip())

    result = CliRunner(echo_stdin=True).invoke(cmd, [], input="typed\n")
    assert "typed" in result.stdout


# -- Contract: package surface and exports ----------------------------------


def test_package_exports_declaration_and_classes():
    for name in (
        "command",
        "group",
        "option",
        "argument",
        "help_option",
        "version_option",
        "custom_version_option",
        "password_option",
        "confirmation_option",
        "pass_context",
        "pass_obj",
        "make_pass_decorator",
        "Command",
        "Group",
        "CommandCollection",
        "Context",
        "Option",
        "Parameter",
        "ParamType",
        "BadParameter",
        "Abort",
        "STRING",
        "INT",
        "FLOAT",
        "BOOL",
        "UUID",
        "UNPROCESSED",
        "Choice",
        "DateTime",
        "IntRange",
        "FloatRange",
        "Tuple",
        "File",
        "Path",
        "echo",
        "secho",
        "style",
        "unstyle",
        "echo_via_pager",
        "get_pager_file",
        "progressbar",
        "prompt",
        "confirm",
        "getchar",
        "pause",
        "edit",
        "launch",
        "clear",
        "get_app_dir",
        "get_current_context",
        "format_filename",
        "open_file",
    ):
        assert hasattr(optlyn, name), name


def test_formatting_and_testing_modules_export():
    from optlyn.formatting import wrap_text as wt
    from optlyn.testing import CliRunner as Runner

    assert callable(wt) and Runner is CliRunner


def test_declared_parameter_types_have_expected_delivery(runner):
    @command()
    @argument("n", nargs=-1, type=int)
    @option("--flag", is_flag=True)
    @option("--c", count=True)
    @option("--none")
    def cmd(n, flag, c, none):
        echo(repr((n, flag, c, none)))

    assert runner.invoke(cmd, ["1", "2"]).stdout == "((1, 2), False, 0, None)\n"


def test_argument_and_option_expose_name_and_metavar():
    opt = Option(["--out-file", "-o"], metavar="FILE")
    arg = Argument(["target"], metavar="TGT")
    assert opt.name == "out_file" and opt.metavar == "FILE"
    assert arg.name == "target" and arg.metavar == "TGT"
    assert opt.get_error_hint() == "'--out-file/-o'"
    assert STRING.name == "text" and INT.name == "integer"


# -- Remaining feature points, checked once more --------------------------


def test_second_variadic_argument_refused_at_declaration():
    with pytest.raises(TypeError):

        @command()
        @argument("a", nargs=-1)
        @argument("b", nargs=-1)
        def cmd(a, b):
            pass


def test_flag_value_on_boolean_flag(runner):
    @command()
    @option("--mode", is_flag=True, flag_value="fast")
    def cmd(mode):
        echo(str(mode))

    assert runner.invoke(cmd, ["--mode"]).stdout == "fast\n"
    assert runner.invoke(cmd, []).stdout == "False\n"


def test_no_args_is_help_on_leaf_is_usage_failure(runner):
    @command(no_args_is_help=True)
    @option("--x")
    def cmd(x):
        pass

    result = runner.invoke(cmd, [])
    assert result.exit_code == 2
    assert "Usage: cmd" in result.stderr


def test_help_shows_metavar_override_and_choice_values(runner):
    @command(options_metavar="[flags]")
    @option("--level", type=Choice(["low", "high"]), help="Level.")
    @argument("name", metavar="NAME_HERE")
    def cmd(level, name):
        pass

    text = runner.invoke(cmd, ["--help"]).stdout
    assert "Usage: cmd [flags] NAME_HERE" in text
    assert "[low|high]" in text


def test_version_detected_from_installed_distribution(runner):
    from optlyn.decorators import _detect_version

    assert _detect_version("pytest") == __import__("pytest").__version__
    assert _detect_version("pytest") == _detect_version("_pytest")


def test_isolated_filesystem_creates_child_under_parent(runner, tmp_path):
    with runner.isolated_filesystem(temp_dir=str(tmp_path)) as path:
        assert os.path.dirname(path) == str(tmp_path)
    assert os.path.isdir(path)


def test_dash_write_goes_to_standard_output(runner):
    @command()
    @argument("out", type=File("w"))
    def cmd(out):
        out.write("to-stdout\n")

    result = runner.invoke(cmd, ["-"])
    assert result.stdout == "to-stdout\n"


def test_command_invoke_fills_defaults_for_omitted_parameters(runner):
    @command()
    @option("--a", default=1)
    @option("--b", default=2)
    def target(a, b):
        return a + b

    @command()
    @pass_context
    def caller(ctx):
        echo(str(ctx.invoke(target, b=10)))

    assert runner.invoke(caller, []).stdout == "11\n"


def test_edit_returns_saved_text_or_none(monkeypatch):
    from optlyn.termui import edit

    assert edit(text="same", editor="true") is None
    assert edit(text="a", editor="sh -c 'printf changed > \"$0\"'") == "changed"


def test_negative_number_is_a_value_for_value_option(runner):
    @command()
    @option("--offset", type=int)
    def cmd(offset):
        echo(str(offset))

    assert runner.invoke(cmd, ["--offset", "-5"]).stdout == "-5\n"
    assert runner.invoke(cmd, ["--offset", "--other"]).exit_code == 2
