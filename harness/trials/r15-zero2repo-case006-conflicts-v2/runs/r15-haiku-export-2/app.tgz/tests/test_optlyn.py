"""Behavioural tests for the Optlyn package, written against the specification."""

import enum
import os
import sys

import pytest

from optlyn import (
    Abort,
    BadParameter,
    Choice,
    Context,
    FloatRange,
    IntRange,
    ParameterSource,
    argument,
    command,
    confirmation_option,
    custom_version_option,
    echo,
    format_filename,
    get_app_dir,
    get_current_context,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    progressbar,
    secho,
    style,
    unstyle,
    version_option,
)
from optlyn.formatting import wrap_text
from optlyn.testing import CliRunner
from optlyn.types import DateTime, File, Path, UUID, STRING


@pytest.fixture
def runner():
    return CliRunner()


# spec: N-000073 N-000074 N-000075 — name derivation from the function name
def test_command_name_derivation():
    @command()
    def init_command():
        pass

    @command("explicit")
    def other():
        pass

    @command()
    def my_cmd():
        pass

    assert init_command.name == "init"
    assert other.name == "explicit"
    assert my_cmd.name == "my"


# spec: N-000077 N-000085 — declarations move from the function to the command
def test_declarations_move_onto_command_and_not_reused():
    @option("--a")
    @option("--b")
    def f(a, b):
        pass

    cmd = command()(f)
    assert [p.name for p in cmd.params] == ["a", "b"]
    assert not hasattr(f, "__optlyn_params__")


# spec: N-001013 — integer option shows its metavar on the help page
def test_N_001013_count_metavar(runner):
    @command()
    @option("--count", type=int)
    def cmd():
        pass

    res = runner.invoke(cmd, ["--help"])
    assert "--count COUNT" in res.output


# spec: N-000080 N-000157 — help is success; no-args group help is a usage failure
def test_help_exit_codes(runner):
    @group()
    def cli():
        """Top."""

    @cli.command()
    def sub():
        pass

    assert runner.invoke(cli, ["--help"]).exit_code == 0
    res = runner.invoke(cli, [])
    assert res.exit_code == 2
    assert "Usage:" in res.stderr


# spec: N-000157 N-000160 — missing subcommand after group options is an error, no help page
def test_missing_command_is_error_without_help(runner):
    @group()
    @option("--flag", is_flag=True)
    def cli(flag):
        pass

    @cli.command()
    def sub():
        pass

    res = runner.invoke(cli, ["--flag"])
    assert res.exit_code == 2
    assert "Missing command." in res.stderr
    assert "Commands:" not in res.stderr


# spec: N-000094 N-000095 — unknown options are usage errors that skip the callback
def test_unknown_option_is_usage_error(runner):
    ran = []

    @command()
    @option("--x")
    def cmd(x):
        ran.append(x)

    res = runner.invoke(cmd, ["--nope"])
    assert res.exit_code == 2
    assert ran == []
    assert "No such option: --nope" in res.stderr


# spec: N-000189 N-000193 N-000208 — flags, on/off pairs, optional values
def test_flags_pairs_and_optional_values(runner):
    @command()
    @option("--shout/--no-shout")
    @option("--opt", is_flag=False, flag_value="flagged", default="dflt")
    def cmd(shout, opt):
        print(shout, opt)

    assert "False dflt" in runner.invoke(cmd, []).output
    assert "True dflt" in runner.invoke(cmd, ["--shout"]).output
    assert "False dflt" in runner.invoke(cmd, ["--no-shout"]).output
    assert "False flagged" in runner.invoke(cmd, ["--opt"]).output
    assert "False val" in runner.invoke(cmd, ["--opt", "val"]).output


# spec: N-000194 N-000195 — counting options and stacked short flags
def test_count_and_stacked_short_flags(runner):
    @command()
    @option("-v", count=True)
    @option("-q", is_flag=True)
    def cmd(v, q):
        print(v, q)

    assert "3 True" in runner.invoke(cmd, ["-vvvq"]).output
    assert "0 False" in runner.invoke(cmd, []).output


# spec: N-000196 N-000199 — repeatable and multi-value options
def test_multiple_and_tuple_options(runner):
    @command()
    @option("--item", multiple=True)
    @option("--pair", type=(str, int))
    def cmd(item, pair):
        print(item, pair)

    res = runner.invoke(cmd, ["--item", "a", "--item", "b", "--pair", "x", "5"])
    assert "('a', 'b') ('x', 5)" in res.output
    res = runner.invoke(cmd, [])
    assert "() None" in res.output


# spec: N-000213 — alternative prefixes are supported when declared
def test_alternative_prefix(runner):
    @command()
    @option("/f", "//force", is_flag=True)
    def cmd(force):
        print(force)

    assert "True" in runner.invoke(cmd, ["/f"]).output
    assert "True" in runner.invoke(cmd, ["//force"]).output


# spec: N-000221 N-000226 N-000227 — environment variables and their boolean rules
def test_envvar_and_boolean_rules(runner):
    @command()
    @option("--flag", is_flag=True, envvar="F_FLAG")
    @option("--num", type=int, envvar=["MISSING_X", "N_NUM"])
    def cmd(flag, num):
        print(flag, num)

    assert "True 4" in runner.invoke(cmd, [], env={"F_FLAG": " YES ", "N_NUM": "4"}).output
    assert "False None" in runner.invoke(cmd, [], env={"F_FLAG": "   "}).output
    res = runner.invoke(cmd, [], env={"F_FLAG": "maybe"})
    assert res.exit_code == 2


# spec: N-000230 N-000233 — command line beats environment beats default map beats default
def test_value_sources(runner):
    @command()
    @option("--a", default="d")
    @option("--b", envvar="B_VAR", default="d")
    def cmd(a, b):
        ctx = get_current_context()
        print(a, b, ctx.get_parameter_source("a").value, ctx.get_parameter_source("b").value)

    out = runner.invoke(cmd, [], default_map={"a": "map"}, env={"B_VAR": "env"}).output
    assert "map env default_map environment" in out
    out = runner.invoke(cmd, ["--a", "cli"]).output
    assert "cli d commandline default" in out
    assert ParameterSource.COMMANDLINE != ParameterSource.DEFAULT_MAP


# spec: N-000440 N-000441 N-000452 — default map nests by subcommand name
def test_default_map_nested(runner):
    @group()
    def cli():
        pass

    @cli.command()
    @option("--who", default="x")
    def who(who):
        print(who)

    assert "dm" in runner.invoke(cli, ["who"], default_map={"who": {"who": "dm"}}).output
    assert "x" in runner.invoke(cli, ["who"], default_map={"other": {"who": "dm"}}).output


# spec: N-000434 N-000439 — automatic environment prefix includes subcommand names
def test_auto_envvar_prefix(runner):
    @group()
    def cli():
        pass

    @cli.command()
    @option("--who", default="x")
    def who(who):
        print(who)

    res = runner.invoke(cli, ["who"], auto_envvar_prefix="APP", env={"APP_WHO_WHO": "env"})
    assert "env" in res.output


# spec: N-000237 N-000250 — parameter callbacks may replace values or refuse them
def test_callbacks_replace_and_refuse(runner):
    def upper(ctx, param, value):
        return value.upper()

    def refuse(ctx, param, value):
        if value == "bad":
            raise BadParameter("nope", ctx=ctx, param=param)
        return value

    @command()
    @option("--name", callback=upper)
    @option("--other", callback=refuse)
    def cmd(name, other):
        print(name, other)

    assert "BOB ok" in runner.invoke(cmd, ["--name", "bob", "--other", "ok"]).output
    res = runner.invoke(cmd, ["--other", "bad"])
    assert res.exit_code == 2
    assert "Invalid value for '--other': nope" in res.stderr


# spec: N-000366 N-000367 N-000368 — failed conversions name the parameter, exit 2
def test_conversion_failure(runner):
    @command()
    @option("--n", type=int)
    def cmd(n):
        pass

    res = runner.invoke(cmd, ["--n", "1.5"])
    assert res.exit_code == 2
    assert "--n" in res.stderr


# spec: N-000321 N-000324 N-000332 N-000349 — built-in types and range clamping
def test_builtin_types():
    assert IntRange(1, 5, clamp=True).convert("9", None, None) == 5
    assert IntRange(1, 5, min_open=True, clamp=True).convert("1", None, None) == 2
    assert FloatRange(0.0, 1.0, clamp=True).convert(-3.0, None, None) == 0.0
    with pytest.raises(ValueError):
        FloatRange(0.0, 1.0, min_open=True, clamp=True)
    with pytest.raises(BadParameter):
        IntRange(1, 5).convert("9", None, None)
    assert DateTime().convert("2024-01-02").day == 2
    with pytest.raises(BadParameter):
        DateTime(formats=["%Y/%m"]).convert("2024-01-02")
    assert str(UUID.convert("12345678-1234-5678-1234-567812345678", None, None)).startswith("12345678")
    assert STRING.convert("true") == "true"


# spec: N-000339 N-000343 N-000373 — choice delivers the original member
def test_choice_delivers_original_member(runner):
    class Color(enum.Enum):
        RED = 1
        GREEN = 2

    @command()
    @option("--color", type=Choice(Color, case_sensitive=False), default=Color.RED)
    def cmd(color):
        print(repr(color))

    assert "Color.GREEN" in runner.invoke(cmd, ["--color", "green"]).output


# spec: N-000310 N-000311 — missing or extra arguments
def test_arguments(runner):
    @command()
    @argument("src")
    @argument("rest", nargs=-1)
    def cmd(src, rest):
        print(src, rest)

    assert "a ('b', 'c')" in runner.invoke(cmd, ["a", "b", "c"]).output
    assert "a ()" in runner.invoke(cmd, ["a"]).output
    assert runner.invoke(cmd, []).exit_code == 2


# spec: N-000098 N-000102 N-000312 — leftover tokens and allow_extra_args
def test_extra_arguments(runner):
    @command()
    @argument("a")
    def cmd(a):
        print(a, get_current_context().args)

    assert runner.invoke(cmd, ["x", "y"]).exit_code == 2
    res = runner.invoke(cmd, ["x", "y"], allow_extra_args=True)
    assert "x ['y']" in res.output


# spec: N-000254 N-000317 — deprecated option warns only when supplied
def test_deprecated_warning(runner):
    @command()
    @option("--old", deprecated=True)
    def cmd(old):
        print("body", old)

    assert "deprecated" not in runner.invoke(cmd, []).output
    res = runner.invoke(cmd, ["--old", "v"])
    assert "DeprecationWarning" in res.stderr
    assert "body v" in res.stdout


# spec: N-000080 N-000084 — deprecated command still runs with a warning
def test_deprecated_command(runner):
    @command(deprecated="use other")
    def old():
        print("ran")

    res = runner.invoke(old, [])
    assert res.exit_code == 0
    assert "use other" in res.stderr
    assert "ran" in res.stdout


# spec: N-000707 N-000711 — abort exits 1 with an indication on stderr
def test_abort(runner):
    @command()
    def cmd():
        raise Abort()

    res = runner.invoke(cmd, [])
    assert res.exit_code == 1
    assert "Aborted!" in res.stderr


# spec: N-000704 N-000706 — author exit with an explicit status
def test_author_exit(runner):
    @command()
    def cmd():
        get_current_context().exit(3)

    assert runner.invoke(cmd, []).exit_code == 3


# spec: N-000842 N-000844 — standalone mode off returns the callback value
def test_standalone_mode_off():
    @command()
    @option("--x", required=True)
    def cmd(x):
        return x * 2

    assert cmd.main(["--x", "2"], standalone_mode=False) == "22"
    with pytest.raises(BadParameter):
        cmd.main([], standalone_mode=False, prog_name="c")


# spec: N-000379 N-000381 N-000382 — a group runs its callback before the child
def test_group_callback_before_child(runner):
    order = []

    @group()
    def cli():
        order.append("group")

    @cli.command()
    def child():
        order.append("child")

    runner.invoke(cli, ["child"])
    assert order == ["group", "child"]
    order.clear()
    runner.invoke(cli, ["child", "--help"])
    assert order == ["group"]


# spec: N-000389 N-000391 — arbitrary nesting; skipping a middle name is unknown
def test_nested_groups(runner):
    @group()
    def root():
        pass

    @root.group()
    def mid():
        pass

    @mid.command()
    def leaf():
        print("leaf ran")

    assert "leaf ran" in runner.invoke(root, ["mid", "leaf"]).output
    res = runner.invoke(root, ["leaf"])
    assert res.exit_code == 2
    assert "No such command" in res.stderr


# spec: N-000412 N-000415 — command collection unions its sources
def test_command_collection(runner):
    from optlyn import CommandCollection

    @group()
    def a():
        pass

    @a.command()
    def one():
        print("one")

    @group()
    def b():
        pass

    @b.command()
    def two():
        print("two")

    coll = group(cls=CommandCollection, sources=[a, b])(lambda: None)
    assert coll.list_commands(Context(coll)) == ["one", "two"]
    assert "two" in runner.invoke(coll, ["two"]).output


# spec: N-000394 N-000395 N-000424 — chaining, invoke without command, result callback
def test_chaining(runner):
    seen = []

    @group(chain=True, invoke_without_command=True)
    def cli():
        seen.append(get_current_context().invoked_subcommand)

    @cli.command("a")
    @option("--x", type=int, default=0)
    def cmd_a(x):
        return x * 10

    @cli.command("b")
    @argument("word")
    def cmd_b(word):
        return word.upper()

    @cli.result_callback()
    def done(results):
        print("results", results)

    res = runner.invoke(cli, ["a", "--x", "3", "b", "hi"])
    assert "results [30, 'HI']" in res.output
    assert seen == ["*"]
    res = runner.invoke(cli, [])
    assert "results []" in res.output


# spec: N-000602 N-000603 — groups cannot be attached beneath a chaining group
def test_chain_refuses_nested_group():
    @group(chain=True)
    def cli():
        pass

    @group()
    def inner():
        pass

    with pytest.raises(RuntimeError):
        cli.add_command(inner)


# spec: N-000247 N-000252 N-000251 — hidden parameters parse but are not passed
def test_hidden_expose_value(runner):
    @command()
    @option("--secret", expose_value=False, is_flag=True)
    @option("--x", default=1)
    def cmd(x):
        print("x", x, sorted(get_current_context().params))

    res = runner.invoke(cmd, ["--secret"])
    assert "x 1 ['x']" in res.output


# spec: N-000149 N-000154 N-000919 — eager help wins, custom version prints verbatim
def test_eager_ordering_and_custom_version(runner):
    @command()
    @option("--need", required=True)
    @custom_version_option(lambda ctx: "custom 9.9")
    def cmd(need):
        pass

    res = runner.invoke(cmd, ["--version"])
    assert res.output == "custom 9.9\n"
    res = runner.invoke(cmd, ["--help"])
    assert res.exit_code == 0
    assert "Usage:" in res.output


# spec: N-000917 N-000918 — version option with an explicit version
def test_version_option(runner):
    @command()
    @version_option("1.2.3", prog_name="tool")
    def cmd():
        pass

    res = runner.invoke(cmd, ["--version"])
    assert res.output == "tool, version 1.2.3\n"


# spec: N-000916 — help_option prints the help page
def test_help_option_decorator(runner):
    @command(add_help_option=False)
    @help_option("-h", "--help")
    def cmd():
        """Does things."""

    assert "Does things." in runner.invoke(cmd, ["-h"]).output
    assert "Does things." in runner.invoke(cmd, ["--help"]).output


# spec: N-000810 N-000811 — help page shows argument help only when given
def test_help_page_sections(runner):
    @command(epilog="The end.")
    @argument("src", help="Source file.")
    @option("--n", help="Count.", show_default=True, default=3)
    def cmd(src, n):
        """Summary line.

        Longer description here.
        """

    text = runner.invoke(cmd, ["--help"]).output
    assert "Positional arguments:" in text
    assert "Source file." in text
    assert "[default: 3]" in text
    assert text.rstrip().endswith("The end.")


# spec: N-000126 N-000131 — help text rewraps; the form feed truncates the docstring
def test_docstring_form_feed_and_wrapping(runner):
    @command(context_settings={"terminal_width": 30})
    def cmd():
        """First words that wrap around a narrow terminal.\f

        Hidden part.
        """

    text = runner.invoke(cmd, ["--help"]).output
    assert "Hidden part" not in text
    assert "\f" not in text
    assert all(len(line) <= 30 for line in text.splitlines())


# spec: N-000098 N-000101 N-000126 — echo strips styles when not a terminal
def test_echo_and_styles(runner):
    @command()
    def cmd():
        echo(style("plain", fg="green"))
        secho("bold", bold=True)

    res = runner.invoke(cmd, [])
    assert "\x1b[" not in res.output
    assert res.output == "plain\nbold\n"
    res = runner.invoke(cmd, [], color=True)
    assert "\x1b[32m" in res.output


def test_style_and_unstyle():
    styled = style("x", fg="red", bg="blue", bold=True, underline=True)
    assert styled.startswith("\x1b[")
    assert unstyle(styled) == "x"
    assert style("x", fg="red") != style("x", bg="red")
    assert style("x", bold=True) != style("x", bold=True, underline=True)
    with pytest.raises(TypeError):
        style("x", fg="not-a-color")
    with pytest.raises(ValueError):
        style("x", fg=(1, 2, 300))


# spec: N-000639 N-000642 N-000673 — progress bar visits every item without a tty
def test_progressbar_visits_all(runner):
    @command()
    def cmd():
        with progressbar(range(4), label="Work") as bar:
            total = sum(item for item in bar)
        print("total", total)

    res = runner.invoke(cmd, [])
    assert "Work" in res.output
    assert "total 6" in res.output


# spec: N-000522 N-000535 — file parameter opens reads immediately, dash is stdin
def test_file_parameter_and_dash(runner):
    @command()
    @argument("src", type=File("r"))
    def cmd(src):
        print("got", src.read().strip())

    with runner.isolated_filesystem():
        with open("in.txt", "w") as handle:
            handle.write("hello\n")
        assert "got hello" in runner.invoke(cmd, ["in.txt"]).output
        res = runner.invoke(cmd, ["missing.txt"])
        assert res.exit_code == 2
        assert "missing.txt" in res.stderr
        assert "got stdin" in runner.invoke(cmd, ["-"], input="stdin\n").output


# spec: N-000538 N-000564 N-000574 — path checks and dash handling
def test_path_checks(runner):
    @command()
    @argument("p", type=Path(exists=True, dir_okay=False))
    def cmd(p):
        print("p", p)

    with runner.isolated_filesystem():
        with open("f.txt", "w") as handle:
            handle.write("x")
        assert "p f.txt" in runner.invoke(cmd, ["f.txt"]).output
        assert runner.invoke(cmd, ["nope"]).exit_code == 2
        os.mkdir("sub")
        res = runner.invoke(cmd, ["sub"])
        assert res.exit_code == 2 and "is a directory" in res.stderr


# spec: N-000533 N-000577 — lazy write does not create the file unless used
def test_lazy_write_file(runner):
    @command()
    @argument("out", type=File("w"))
    def cmd(out):
        pass

    with runner.isolated_filesystem():
        assert runner.invoke(cmd, ["made.txt"]).exit_code == 0
        assert not os.path.exists("made.txt")


# spec: N-000609 N-000617 — prompts read input and re-ask on invalid values
def test_prompt_option(runner):
    @command()
    @option("--age", type=int, prompt="Age")
    def cmd(age):
        print("age", age)

    res = runner.invoke(cmd, [], input="x\n42\n")
    assert "age 42" in res.output
    assert "not a valid integer" in res.output


# spec: N-000503 N-000509 — confirmation option asks and aborts on decline
def test_confirmation_option(runner):
    @command()
    @confirmation_option(prompt="Sure?")
    def cmd():
        print("ran")

    assert runner.invoke(cmd, [], input="n\n").exit_code == 1
    assert "ran" in runner.invoke(cmd, [], input="y\n").output
    res = runner.invoke(cmd, ["--yes"])
    assert "ran" in res.output and "Sure?" not in res.output


# spec: N-000500 N-000502 — password option confirms and hides input
def test_password_option(runner):
    @command()
    @password_option()
    def cmd(password):
        print("pw", password)

    res = runner.invoke(cmd, ["--password", "secret"])
    assert "pw secret" in res.output


# spec: N-000708 — isolated filesystem is a new working directory
def test_isolated_filesystem(runner):
    before = os.getcwd()
    with runner.isolated_filesystem() as path:
        assert os.getcwd() == os.path.realpath(path) or os.getcwd() == path
    assert os.getcwd() == before


# spec: N-000648 N-000651 — context managers and pass decorators
def test_pass_decorators(runner):
    class Cfg:
        def __init__(self):
            self.name = "cfg"

    pass_cfg = make_pass_decorator(Cfg, ensure=True)

    @group()
    def cli():
        pass

    @cli.command()
    @pass_cfg
    @pass_obj
    def sub(obj, cfg_obj):
        print(type(cfg_obj).__name__, obj)

    @cli.command()
    @pass_context
    def ctxsub(ctx):
        print("name", ctx.info_name)

    assert "Cfg" in runner.invoke(cli, ["sub"]).output
    assert "name ctxsub" in runner.invoke(cli, ["ctxsub"]).output


# spec: N-000953 N-000960 N-000962 — get_current_context outside a context
def test_get_current_context_silent():
    assert get_current_context(silent=True) is None
    with pytest.raises(RuntimeError):
        get_current_context()


# spec: N-000459 N-000462 — ctx.invoke fills defaults; forward passes params
def test_invoke_and_forward(runner):
    @command()
    @option("--a", default=1)
    @option("--b", default=2)
    def target(a, b):
        print("target", a, b)

    @command()
    @option("--a", default=5)
    def caller(a):
        ctx = get_current_context()
        ctx.invoke(target, a=7)
        ctx.forward(target)

    out = runner.invoke(caller, []).output
    assert "target 7 2" in out
    assert "target 5 2" in out


# spec: N-000566 N-000568 — file names format to printable text
def test_format_filename():
    assert format_filename("plain.txt") == "plain.txt"
    assert format_filename(b"bad\xff") == "bad\\xff"
    assert format_filename("/a/b/c.txt", shorten=True) == "c.txt"


# spec: N-000664 N-000668 — application directory
def test_get_app_dir_posix(monkeypatch, tmp_path):
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    if sys.platform.startswith(("win", "darwin")):
        pytest.skip("POSIX path rules only")
    assert get_app_dir("My App") == os.path.join(str(tmp_path), "my-app")
    assert get_app_dir("My App", force_posix=True) == os.path.join(os.path.expanduser("~"), ".my-app")


# spec: N-000669 N-001014 — wrap text accepts any string and respects the width
def test_wrap_text():
    text = wrap_text("alpha beta gamma delta epsilon", width=12)
    assert all(len(line) <= 12 for line in text.splitlines())
    assert wrap_text("") == ""


# spec: N-000689 N-000693 — built-in completion sources and suggestions
def test_completion_source_and_suggestions(runner):
    @group()
    def tool():
        pass

    @tool.command("build")
    @option("--target", type=Choice(["x86", "arm"]))
    def build(target):
        pass

    @tool.command(hidden=True)
    def secret():
        pass

    def complete(words, cword):
        env = {"_TOOL_COMPLETE": "bash_complete", "COMP_WORDS": words, "COMP_CWORD": str(cword)}
        return runner.invoke(tool, [], env=env, prog_name="tool").output

    assert "plain,build" in complete("tool b", 1)
    assert "plain,x86" in complete("tool build --target ", 3)
    assert complete("tool sec", 1) == ""
    assert "plain,--target" in complete("tool build --", 2)
    res = runner.invoke(tool, [], env={"_TOOL_COMPLETE": "bash_source"}, prog_name="tool")
    assert "complete -o nosort -F" in res.output
    res = runner.invoke(tool, [], env={"_TOOL_COMPLETE": "bogus_source"}, prog_name="tool")
    assert res.exit_code != 0 and res.stdout == ""


# spec: N-000677 N-000681 — completion mode ignores variables derived from other names
def test_completion_ignored_for_other_name(runner):
    @command()
    def cmd():
        print("ran")

    res = runner.invoke(cmd, [], env={"_OTHER_COMPLETE": "bash_source"}, prog_name="tool")
    assert "ran" in res.output
