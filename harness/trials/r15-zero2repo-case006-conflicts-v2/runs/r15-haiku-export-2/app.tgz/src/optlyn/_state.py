"""Per-thread stack of the invocation contexts that are currently entered."""

import threading

_local = threading.local()


def _stack() -> list:
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def push_context(ctx) -> None:
    _stack().append(ctx)


def pop_context() -> None:
    _stack().pop()


def get_current_context(silent: bool = False):
    """Return the context current on this thread.

    When there is none, raise ``RuntimeError`` unless ``silent`` is true, in
    which case ``None`` is returned.
    """
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")
