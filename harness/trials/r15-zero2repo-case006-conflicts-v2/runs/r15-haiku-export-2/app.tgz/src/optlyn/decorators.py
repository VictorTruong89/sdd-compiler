"""Decorators that declare commands, groups, options, arguments, and callbacks."""

import functools
import typing as t
from importlib import metadata

from ._state import get_current_context
from .core import Argument, Command, Context, Group, Option, Parameter, _show_help
from .termui import echo


def _param_memo(f: t.Any, param: Parameter) -> None:
    if isinstance(f, Command):
        f.params.append(param)
        return
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)


def _consume_params(f: t.Any) -> t.List[Parameter]:
    params = list(reversed(getattr(f, "__optlyn_params__", [])))
    if hasattr(f, "__optlyn_params__"):
        del f.__optlyn_params__
    return params


def _default_name(func_name: str) -> str:
    name = func_name.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _make(f: t.Any, name: t.Optional[str], attrs: t.Dict[str, t.Any], cls: type) -> Command:
    params = _consume_params(f)
    if name is None:
        name = _default_name(f.__name__)
    return cls(name=name, callback=f, params=params, **attrs)


def command(name: t.Any = None, cls: t.Optional[type] = None, **attrs: t.Any) -> t.Any:
    """Turn a function into a command. Usable as ``@command()`` or ``@command``."""
    if cls is None:
        cls = Command
    if callable(name) and not isinstance(name, str):
        return command()(name)

    def decorator(f: t.Callable) -> Command:
        return _make(f, name, attrs, cls)

    return decorator


def group(name: t.Any = None, cls: t.Optional[type] = None, **attrs: t.Any) -> t.Any:
    """Turn a function into a group. Usable as ``@group()`` or ``@group``."""
    if cls is None:
        cls = Group
    if callable(name) and not isinstance(name, str):
        return group()(name)

    def decorator(f: t.Callable) -> Group:
        return _make(f, name, attrs, cls)

    return decorator


def option(*param_decls: str, cls: t.Optional[type] = None, **attrs: t.Any) -> t.Callable:
    """Attach an option to the function (or command) it decorates."""
    if cls is None:
        cls = Option

    def decorator(f: t.Any) -> t.Any:
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def argument(*param_decls: str, cls: t.Optional[type] = None, **attrs: t.Any) -> t.Callable:
    """Attach a positional argument to the function (or command) it decorates."""
    if cls is None:
        cls = Argument

    def decorator(f: t.Any) -> t.Any:
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def help_option(*param_decls: str, **kwargs: t.Any) -> t.Callable:
    """An extra eager help flag that prints the help page and exits."""
    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help)
    return option(*param_decls, **kwargs)


def _detect_version(package_name: str) -> str:
    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    try:
        providers = metadata.packages_distributions().get(package_name, [])
    except Exception:
        providers = []
    for dist in providers:
        try:
            return metadata.version(dist)
        except metadata.PackageNotFoundError:
            continue
    return "unknown"


def version_option(
    version: t.Optional[str] = None,
    *param_decls: str,
    package_name: t.Optional[str] = None,
    prog_name: t.Optional[str] = None,
    message: t.Optional[str] = None,
    **kwargs: t.Any,
) -> t.Callable:
    """An eager flag (default ``--version``) that prints the version identity and exits."""
    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx: Context, param: t.Any, value: t.Any) -> None:
        if not value or ctx.resilient_parsing:
            return
        root = ctx.find_root()
        prog = prog_name or root.info_name or ""
        identity = version
        if identity is None:
            pkg = package_name
            if pkg is None:
                cb = root.command.callback
                pkg = (cb.__module__ if cb is not None else root.command.name or "").split(".")[0]
            identity = _detect_version(pkg)
        text = (message or "%(prog)s, version %(version)s") % {"prog": prog, "version": identity}
        echo(text, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("callback", callback)
    return option(*param_decls, **kwargs)


def custom_version_option(callback: t.Callable[[Context], str], *param_decls: str, **kwargs: t.Any) -> t.Callable:
    """An eager version flag whose whole printed identity is ``callback(ctx)``."""
    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def wrapped(ctx: Context, param: t.Any, value: t.Any) -> None:
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=False)
        ctx.exit()

    kwargs.setdefault("callback", wrapped)
    return option(*param_decls, **kwargs)


def password_option(*param_decls: str, **kwargs: t.Any) -> t.Callable:
    """A prompting, hidden, confirmed option (default ``--password``)."""
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*param_decls, **kwargs)


def confirmation_option(*param_decls: str, **kwargs: t.Any) -> t.Callable:
    """A yes-flag (default ``--yes``) that asks when omitted and aborts when declined."""
    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def callback(ctx: Context, param: t.Any, value: t.Any) -> None:
        if not value:
            ctx.abort()

    kwargs.setdefault("callback", callback)
    return option(*param_decls, **kwargs)


def pass_context(f: t.Callable) -> t.Callable:
    """Pass the current context as the first positional argument."""

    @functools.wraps(f)
    def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f: t.Callable) -> t.Callable:
    """Pass the current context's author object as the first positional argument."""

    @functools.wraps(f)
    def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type: type, ensure: bool = False) -> t.Callable:
    """Build a decorator that passes the nearest object of ``object_type`` from the context."""

    def decorator(f: t.Callable) -> t.Callable:
        @functools.wraps(f)
        def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(f"Managed to invoke callback without a context object of type {object_type.__name__!r} existing.")
            return ctx.invoke(f, obj, *args, **kwargs)

        return new_func

    return decorator
