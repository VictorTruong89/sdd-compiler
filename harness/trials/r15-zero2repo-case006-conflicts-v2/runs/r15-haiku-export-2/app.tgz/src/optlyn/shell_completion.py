"""Shell completion: registration scripts and suggestion output.

Completion mode is selected by the environment variable ``_<PROG>_COMPLETE``.
Its value is ``<shell>_source`` (print the registration script) or
``<shell>_complete`` (print suggestions for the words in ``COMP_WORDS``).
Each suggestion line is ``type,value``; ``type`` is ``plain``, ``file``, or ``dir``.
"""

import os
import re
import sys
import typing as t

from .termui import echo

SHELLS = ("bash", "zsh", "fish", "powershell")
_PREFIX_CHARS = "-+/"


class CompletionItem:
    """One suggestion. ``type`` is ``plain`` for values, ``file``/``dir`` for path requests."""

    def __init__(self, value: str, type: str = "plain", help: t.Optional[str] = None) -> None:
        self.value = value
        self.type = type
        self.help = help

    def __repr__(self) -> str:
        return f"CompletionItem({self.value!r}, type={self.type!r}, help={self.help!r})"


def _to_items(result: t.Iterable[t.Any]) -> t.List[CompletionItem]:
    items: t.List[CompletionItem] = []
    for entry in result:
        if isinstance(entry, CompletionItem):
            items.append(entry)
        elif isinstance(entry, str):
            items.append(CompletionItem(entry))
        else:
            items.append(
                CompletionItem(
                    str(entry.value),
                    type=getattr(entry, "type", "plain") or "plain",
                    help=getattr(entry, "help", None),
                )
            )
    return items


def _complete_var(prog_name: str) -> str:
    return "_" + prog_name.replace("-", "_").upper() + "_COMPLETE"


def _script(shell: str, prog_name: str, complete_var: str) -> str:
    ident = re.sub(r"[^A-Za-z0-9_]", "_", prog_name)
    func = f"_{ident}_completion"
    if shell == "bash":
        return f"""{func}() {{
    local IFS=$'\\n'
    local response
    response=$(env COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD {complete_var}=bash_complete {prog_name} 2>/dev/null)
    COMPREPLY=()
    local item type value
    for item in $response; do
        type="${{item%%,*}}"
        value="${{item#*,}}"
        if [[ $type == 'plain' ]]; then
            COMPREPLY+=("$value")
        elif [[ $type == 'dir' ]]; then
            compopt -o dirnames
        elif [[ $type == 'file' ]]; then
            compopt -o default
        fi
    done
    return 0
}}

complete -o nosort -F {func} {prog_name}
"""
    if shell == "zsh":
        return f"""#compdef {prog_name}

{func}() {{
    local -a response plain
    local item type value
    response=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {complete_var}=zsh_complete {prog_name} 2>/dev/null)}}")
    for item in $response; do
        type="${{item%%,*}}"
        value="${{${{item#*,}}%%$'\\t'*}}"
        if [[ $type == 'plain' ]]; then
            plain+=("$value")
        elif [[ $type == 'dir' ]]; then
            _path_files -/
        elif [[ $type == 'file' ]]; then
            _path_files
        fi
    done
    if (( ${{#plain}} )); then
        compadd -a plain
    fi
}}

compdef {func} {prog_name}
"""
    if shell == "fish":
        return f"""function {func}
    set -lx COMP_WORDS (commandline -cp)
    set -lx COMP_CWORD (commandline -ct)
    env {complete_var}=fish_complete {prog_name}
end

complete -c {prog_name} -f -a '(__fish_complete_{ident})'
"""
    return f"""Register-ArgumentCompleter -Native -CommandName '{prog_name}' -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $words = $commandAst.ToString()
    $env:COMP_WORDS = $words
    $env:COMP_CWORD = ($words.Split(' ') | Measure-Object).Count - 1
    $env:{complete_var} = 'powershell_complete'
    & '{prog_name}' | ForEach-Object {{
        $type, $value = $_.Split(',', 2)
        if ($type -eq 'plain') {{
            [System.Management.Automation.CompletionResult]::new($value, $value, 'ParameterValue', $value)
        }}
    }}
    Remove-Item Env:{complete_var}
}}
"""


def _split_words(shell: str, words_env: str, cword_env: str) -> t.Tuple[t.List[str], str]:
    """Return the completed words (program name excluded) and the incomplete token."""
    if shell == "fish":
        incomplete = cword_env
        words = words_env.split(" ")
        args = words[1:]
        if args and args[-1] == incomplete:
            args = args[:-1]
        return [w for w in args if w != ""], incomplete
    words = words_env.split(" ")
    try:
        cword = int(cword_env)
    except ValueError:
        cword = len(words)
    incomplete = words[cword] if 0 <= cword < len(words) else ""
    args = words[1:cword] if cword > 1 else []
    return [w for w in args if w != ""], incomplete


def get_completions(cli: t.Any, prog_name: str, args: t.List[str], incomplete: str) -> t.List[CompletionItem]:
    """Work out suggestions for ``incomplete`` after the completed ``args``.

    No callback runs. Option values are pre-filled into ``ctx.params`` as they are typed.
    """
    from .core import Argument, Context, Group, Option

    root = Context(cli, info_name=prog_name, resilient_parsing=True)
    cmd: t.Any = cli
    ctx = root
    positional = 0
    pending: t.Any = None
    stop_options = False
    descended = False
    i = 0
    while i < len(args):
        tok = args[i]
        i += 1
        if pending is not None:
            ctx.params[pending.name] = tok
            pending = None
            continue
        if tok == "--":
            stop_options = True
            continue
        if not stop_options and len(tok) > 1 and tok[0] in _PREFIX_CHARS:
            name = tok.partition("=")[0]
            opt = _find_option(cmd, ctx, name)
            if opt is not None and opt.takes_value and "=" not in tok:
                pending = opt
            continue
        if isinstance(cmd, Group) and not descended:
            sub = cmd.get_command(ctx, tok)
            if sub is not None:
                cmd = sub
                ctx = Context(sub, info_name=tok, parent=ctx, resilient_parsing=True)
                descended = True
                positional = 0
                continue
        arguments = [p for p in cmd.get_params(ctx) if isinstance(p, Argument)]
        if positional < len(arguments):
            ctx.params[arguments[positional].name] = tok
        positional += 1

    if pending is not None:
        return _value_items(pending, ctx, incomplete)
    if incomplete[:1] and incomplete[0] in _PREFIX_CHARS:
        items = []
        for param in cmd.get_params(ctx):
            if not isinstance(param, Option) or param.hidden:
                continue
            for name in param.opts + param.secondary_opts:
                if name.startswith(incomplete):
                    items.append(CompletionItem(name, help=param.help))
        return items
    if isinstance(cmd, Group) and not descended:
        items = []
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            items.append(CompletionItem(name, help=sub.get_short_help_str(45) or None))
        return items
    arguments = [p for p in cmd.get_params(ctx) if isinstance(p, Argument)]
    if positional < len(arguments):
        return _value_items(arguments[positional], ctx, incomplete)
    return []


def _find_option(cmd: t.Any, ctx: t.Any, name: str) -> t.Any:
    from .core import Option

    for param in cmd.get_params(ctx):
        if isinstance(param, Option) and name in param.opts + param.secondary_opts:
            return param
    return None


def _value_items(param: t.Any, ctx: t.Any, incomplete: str) -> t.List[CompletionItem]:
    if param.shell_complete_func is not None:
        return _to_items(param.shell_complete_func(ctx, param, incomplete) or [])
    if hasattr(param.type, "shell_complete"):
        return _to_items(param.type.shell_complete(ctx, param, incomplete) or [])
    return []


def _format_item(item: CompletionItem, shell: str) -> str:
    line = f"{item.type},{item.value}"
    if shell in ("zsh", "fish") and item.help:
        line += "\t" + " ".join(str(item.help).split())
    return line


def run_completion(cli: t.Any, prog_name: str, instruction: str) -> int:
    """Handle completion mode. Returns the process exit status."""
    shell, _, action = instruction.partition("_")
    if shell not in SHELLS or action not in ("source", "complete"):
        echo(f"Unknown completion instruction {instruction!r}.", file=sys.stderr)
        return 1
    complete_var = _complete_var(prog_name)
    if action == "source":
        echo(_script(shell, prog_name, complete_var), nl=False)
        return 0
    words_env = os.environ.get("COMP_WORDS", "")
    cword_env = os.environ.get("COMP_CWORD", "")
    args, incomplete = _split_words(shell, words_env, cword_env)
    for item in get_completions(cli, prog_name, args, incomplete):
        echo(_format_item(item, shell), file=sys.stdout)
    return 0
