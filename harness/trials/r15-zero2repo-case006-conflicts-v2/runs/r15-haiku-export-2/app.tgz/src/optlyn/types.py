"""Parameter types: conversion of command-line tokens into Python values."""

import datetime as dt
import enum
import os
import pathlib
import stat
import typing as t
import uuid

from .exceptions import BadParameter
from .utils import LazyFile, format_filename, open_file

TRUE_TOKENS = frozenset(("1", "true", "t", "yes", "y", "on"))
FALSE_TOKENS = frozenset(("0", "false", "f", "no", "n", "off"))
DEFAULT_DATETIME_FORMATS = ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S")


class ParamType:
    """Base class for parameter types. Subclasses implement ``convert``."""

    name = "text"
    is_composite = False
    # Separator used to split environment-variable lists; None splits on whitespace.
    envvar_list_splitter: t.Optional[str] = None

    def __call__(self, value: t.Any, param: t.Any = None, ctx: t.Any = None) -> t.Any:
        if value is not None:
            return self.convert(value, param, ctx)
        return None

    def get_metavar(self, param: t.Any) -> t.Optional[str]:
        return None

    def convert(self, value: t.Any, param: t.Any = None, ctx: t.Any = None) -> t.Any:
        return value

    def fail(self, message: str, param: t.Any = None, ctx: t.Any = None) -> t.NoReturn:
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx: t.Any, param: t.Any, incomplete: str) -> list:
        return []

    def split_envvar_value(self, rv: str) -> t.List[str]:
        return rv.split(self.envvar_list_splitter)


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, (bytes, bytearray)):
            return bytes(value).decode("utf-8", "replace")
        return str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        if isinstance(value, float):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)
        try:
            return int(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid float.", param, ctx)


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        token = str(value).strip().lower()
        if token in TRUE_TOKENS:
            return True
        if token in FALSE_TOKENS:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value))
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()


class Choice(ParamType):
    """A closed list of values, or the member names of an enumeration."""

    name = "choice"

    def __init__(self, choices: t.Iterable, case_sensitive: bool = True) -> None:
        self.choices = list(choices)
        self.case_sensitive = case_sensitive

    @staticmethod
    def _token(choice: t.Any) -> str:
        if isinstance(choice, enum.Enum):
            return choice.name
        return str(choice)

    def get_metavar(self, param: t.Any) -> str:
        return "[" + "|".join(self._token(c) for c in self.choices) + "]"

    def convert(self, value, param=None, ctx=None):
        for choice in self.choices:
            if value is choice:
                return choice
        normalize = getattr(ctx, "token_normalize_func", None)

        def norm(text: str) -> str:
            if normalize is not None:
                text = normalize(text)
            return text if self.case_sensitive else text.casefold()

        target = norm(self._token(value) if isinstance(value, enum.Enum) else str(value))
        for choice in self.choices:
            if norm(self._token(choice)) == target:
                return choice
        options = ", ".join(repr(self._token(c)) for c in self.choices)
        self.fail(f"{value!r} is not one of {options}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        found = []
        for choice in self.choices:
            token = self._token(choice)
            if token.startswith(incomplete) if self.case_sensitive else token.casefold().startswith(incomplete.casefold()):
                found.append(CompletionItem(token))
        return found


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats: t.Optional[t.Sequence[str]] = None) -> None:
        self.formats = list(formats) if formats is not None else list(DEFAULT_DATETIME_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return dt.datetime.strptime(str(value), fmt)
            except ValueError:
                continue
        formats = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the formats {formats}.", param, ctx)


def _describe_range(rt: t.Any) -> str:
    lo, hi = rt.min, rt.max
    if lo is not None and hi is not None:
        return f"{lo}{'<' if rt.min_open else '<='}x{'<' if rt.max_open else '<='}{hi}"
    if lo is not None:
        return f"x{'>' if rt.min_open else '>='}{lo}"
    if hi is not None:
        return f"x{'<' if rt.max_open else '<='}{hi}"
    return "any value"


def _check_range(rt: t.Any, value: t.Any, param: t.Any, ctx: t.Any) -> t.Any:
    lo, hi = rt.min, rt.max
    below = lo is not None and (value < lo or (rt.min_open and value == lo))
    above = hi is not None and (value > hi or (rt.max_open and value == hi))
    if rt.clamp:
        if below:
            return lo + 1 if rt.min_open else lo
        if above:
            return hi - 1 if rt.max_open else hi
        return value
    if below or above:
        rt.fail(f"{value!r} is not in the range {_describe_range(rt)}.", param, ctx)
    return value


class IntRange(IntParamType):
    name = "integer range"

    def __init__(
        self,
        min: t.Optional[int] = None,
        max: t.Optional[int] = None,
        min_open: bool = False,
        max_open: bool = False,
        clamp: bool = False,
    ) -> None:
        if min is not None and max is not None and min > max:
            raise ValueError("'min' must not be greater than 'max'.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        value = super().convert(value, param, ctx)
        return _check_range(self, value, param, ctx)


class FloatRange(FloatParamType):
    name = "float range"

    def __init__(
        self,
        min: t.Optional[float] = None,
        max: t.Optional[float] = None,
        min_open: bool = False,
        max_open: bool = False,
        clamp: bool = False,
    ) -> None:
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is only allowed when both bounds are closed.")
        if min is not None and max is not None and min > max:
            raise ValueError("'min' must not be greater than 'max'.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        value = super().convert(value, param, ctx)
        return _check_range(self, value, param, ctx)


class Tuple(ParamType):
    """A fixed-length product of inner types, one converted value per position."""

    is_composite = True

    def __init__(self, types: t.Iterable) -> None:
        self.types = [convert_type(ty) for ty in types]

    @property
    def name(self) -> str:  # type: ignore[override]
        return "<" + " ".join(ty.name for ty in self.types) + ">"

    def get_metavar(self, param: t.Any) -> str:
        return " ".join(ty.get_metavar(param) or ty.name.upper() for ty in self.types)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, (str, bytes)) or not hasattr(value, "__len__"):
            self.fail(f"{value!r} is not a sequence of {len(self.types)} values.", param, ctx)
        if len(value) != len(self.types):
            self.fail(f"Expected {len(self.types)} values, got {len(value)}.", param, ctx)
        return tuple(ty(v, param, ctx) for ty, v in zip(self.types, value))


class File(ParamType):
    """An open file. ``-`` is standard input for reading, standard output for writing."""

    name = "filename"
    envvar_list_splitter = os.pathsep

    def __init__(
        self,
        mode: str = "r",
        encoding: t.Optional[str] = None,
        errors: str = "strict",
        lazy: t.Optional[bool] = None,
        atomic: bool = False,
    ) -> None:
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self.lazy if self.lazy is not None else ("w" in self.mode)
        try:
            if lazy and value != "-":
                opened: t.Any = LazyFile(value, self.mode, self.encoding, self.errors, atomic=self.atomic)
            else:
                opened = open_file(value, self.mode, self.encoding, self.errors, atomic=self.atomic)
        except OSError as e:
            self.fail(f"Could not open file {format_filename(value)!r}: {e.strerror or e}", param, ctx)
        if ctx is not None:
            ctx.call_on_close(opened.close)
        return opened

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        return [CompletionItem(incomplete, type="file")]


class Path(ParamType):
    """A validated file-system path. Delivers a path, not an open file."""

    name = "path"
    envvar_list_splitter = os.pathsep

    def __init__(
        self,
        exists: bool = False,
        file_okay: bool = True,
        dir_okay: bool = True,
        writable: bool = False,
        readable: bool = True,
        resolve_path: bool = False,
        allow_dash: bool = False,
        path_type: t.Any = None,
        executable: bool = False,
    ) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def _coerce(self, value: str) -> t.Any:
        if self.path_type is None:
            return value
        if self.path_type is pathlib.Path:
            return pathlib.Path(value)
        return self.path_type(value)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, (bytes, bytearray)):
            value = os.fsdecode(bytes(value))
        rv = os.fspath(value)
        if self.allow_dash and rv == "-":
            return self._coerce(rv)
        if self.resolve_path:
            rv = os.path.realpath(rv)
        try:
            st = os.stat(rv)
        except OSError:
            if not self.exists:
                return self._coerce(rv)
            self.fail(f"{format_filename(value)!r} does not exist.", param, ctx)
        if not self.file_okay and stat.S_ISREG(st.st_mode):
            self.fail(f"{format_filename(value)!r} is a file.", param, ctx)
        if not self.dir_okay and stat.S_ISDIR(st.st_mode):
            self.fail(f"{format_filename(value)!r} is a directory.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{format_filename(value)!r} is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{format_filename(value)!r} is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{format_filename(value)!r} is not executable.", param, ctx)
        return self._coerce(rv)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        kind = "dir" if not self.file_okay else "file"
        return [CompletionItem(incomplete, type=kind)]


class FuncParamType(ParamType):
    """Adapter for a conversion function ``f(token) -> value`` that raises ValueError."""

    def __init__(self, func: t.Callable[[t.Any], t.Any]) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "value").lower()

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except ValueError:
            self.fail(f"{value!r} is not a valid {self.name}.", param, ctx)


BUILTIN_TYPE_CLASSES = (
    StringParamType,
    UnprocessedParamType,
    IntParamType,
    FloatParamType,
    BoolParamType,
    UUIDParamType,
    Choice,
    DateTime,
    IntRange,
    FloatRange,
    Tuple,
    File,
    Path,
    FuncParamType,
)


def guess_type(value: t.Any) -> t.Optional[ParamType]:
    """Infer a type from a default value. UUID is never inferred."""
    if isinstance(value, bool):
        return BOOL
    if isinstance(value, int):
        return INT
    if isinstance(value, float):
        return FLOAT
    return None


def convert_type(ty: t.Any, default: t.Any = None) -> ParamType:
    """Turn a Python type, function, or ``ParamType`` into a ``ParamType``."""
    if isinstance(ty, ParamType):
        return ty
    if ty is None:
        if isinstance(default, (list, tuple)) and default:
            guessed = guess_type(default[0])
        else:
            guessed = guess_type(default)
        return guessed or STRING
    if ty is str:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if ty is uuid.UUID:
        return UUID
    if isinstance(ty, (list, tuple)):
        return Tuple(ty)
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")
