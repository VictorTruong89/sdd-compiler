"""Text wrapping and the help-page layout helper."""

import re
import shutil
import textwrap
import typing as t
from contextlib import contextmanager


def wrap_text(
    text: str,
    width: int = 78,
    initial_indent: str = "",
    subsequent_indent: str = "",
    preserve_paragraphs: bool = False,
) -> str:
    """Wrap ``text`` to ``width`` columns. Accepts any string."""
    width = max(width, 1)
    if not preserve_paragraphs:
        wrapper = textwrap.TextWrapper(
            width,
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
            break_long_words=False,
            break_on_hyphens=False,
            replace_whitespace=True,
        )
        return wrapper.fill(text)
    out = []
    for para in re.split(r"\n\s*\n", text.strip("\n")):
        lines = [line.strip() for line in para.split("\n") if line.strip()]
        if not lines:
            continue
        wrapper = textwrap.TextWrapper(
            width,
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
            break_long_words=False,
            break_on_hyphens=False,
        )
        out.append(wrapper.fill(" ".join(lines)))
    return "\n\n".join(out)


class HelpFormatter:
    """Accumulates the lines of a help page or a usage line."""

    def __init__(
        self,
        indent_increment: int = 2,
        width: t.Optional[int] = None,
        max_width: t.Optional[int] = None,
    ) -> None:
        self.indent_increment = indent_increment
        if width is None:
            limit = max_width if max_width is not None else 80
            width = max(min(shutil.get_terminal_size().columns, limit) - 2, 50)
        self.width = width
        self.current_indent = 0
        self.buffer: t.List[str] = []

    def write(self, string: str) -> None:
        self.buffer.append(string)

    def getvalue(self) -> str:
        return "".join(self.buffer)

    def indent(self) -> None:
        self.current_indent += self.indent_increment

    def dedent(self) -> None:
        self.current_indent = max(self.current_indent - self.indent_increment, 0)

    @contextmanager
    def section(self, name: str):
        self.write_paragraph()
        self.write_heading(name)
        self.indent()
        try:
            yield
        finally:
            self.dedent()

    def write_usage(self, prog: str, args: str = "", prefix: str = "Usage: ") -> None:
        usage_prefix = f"{prefix}{prog} "
        base = " " * self.current_indent
        text_width = max(self.width - self.current_indent, 10)
        if not args:
            self.write(f"{base}{usage_prefix.rstrip()}\n")
        elif len(usage_prefix) + len(args) <= text_width:
            self.write(f"{base}{usage_prefix}{args}\n")
        else:
            lines = textwrap.wrap(
                args,
                width=max(text_width - len(usage_prefix), 10),
                break_long_words=False,
                break_on_hyphens=False,
            )
            self.write(f"{base}{usage_prefix}{lines[0]}\n")
            for line in lines[1:]:
                self.write(f"{base}{' ' * len(usage_prefix)}{line}\n")

    def write_paragraph(self) -> None:
        value = self.getvalue()
        if value and not value.endswith("\n\n"):
            self.write("\n")

    def write_heading(self, heading: str) -> None:
        self.write(f"{' ' * self.current_indent}{heading}:\n")

    def write_text(self, text: str) -> None:
        indent = " " * self.current_indent
        width = max(self.width - self.current_indent, 10)
        paragraphs = [p for p in re.split(r"\n\s*\n", text.strip("\n")) if p.strip()]
        for index, para in enumerate(paragraphs):
            lines = para.split("\n")
            if lines[0].strip() == "\b":
                body = "\n".join(indent + line for line in lines[1:])
                self.write(body + "\n")
            else:
                joined = " ".join(line.strip() for line in lines if line.strip())
                wrapped = wrap_text(joined, width, indent, indent)
                self.write(wrapped + "\n")
            if index < len(paragraphs) - 1:
                self.write("\n")

    def write_dl(self, rows: t.Sequence[t.Tuple[str, str]], col_max: int = 30, col_spacing: int = 2) -> None:
        rows = list(rows)
        if not rows:
            return
        first_col = min(max(len(first) for first, _ in rows), col_max) + col_spacing
        indent = " " * self.current_indent
        for first, second in rows:
            if len(first) + col_spacing <= first_col:
                lead = indent + first.ljust(first_col)
                text_width = max(self.width - self.current_indent - first_col, 10)
                lines = wrap_text(second, text_width).split("\n") if second else []
                if not lines:
                    self.write(lead.rstrip() + "\n")
                    continue
                self.write(lead + lines[0] + "\n")
                for line in lines[1:]:
                    self.write(" " * (self.current_indent + first_col) + line + "\n")
            else:
                self.write(indent + first + "\n")
                if second:
                    text_width = max(self.width - self.current_indent - first_col, 10)
                    for line in wrap_text(second, text_width).split("\n"):
                        self.write(" " * (self.current_indent + first_col) + line + "\n")
