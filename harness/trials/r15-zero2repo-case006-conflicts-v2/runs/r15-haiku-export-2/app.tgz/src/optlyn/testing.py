"""In-process runner: invoke a command with tokens and capture its output."""

import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile
import typing as t


def _to_bytes(data: t.Any, charset: str) -> bytes:
    if data is None:
        return b""
    if isinstance(data, str):
        return data.encode(charset)
    return bytes(data)


class _CaptureBuffer(io.BufferedIOBase):
    """Byte side of a captured stream; every write is appended to the shared log."""

    def __init__(self, kind: str, log: t.List[t.Tuple[str, bytes]]) -> None:
        super().__init__()
        self._kind = kind
        self._log = log

    def writable(self) -> bool:
        return True

    def write(self, data: t.Any) -> int:
        chunk = bytes(data)
        self._log.append((self._kind, chunk))
        return len(chunk)

    def flush(self) -> None:
        pass

    def isatty(self) -> bool:
        return False


class _CaptureText(io.TextIOBase):
    """Text side of a captured stdout or stderr."""

    def __init__(self, kind: str, log: t.List[t.Tuple[str, bytes]], charset: str) -> None:
        self._charset = charset
        self.buffer = _CaptureBuffer(kind, log)

    @property
    def encoding(self) -> str:
        return self._charset

    def writable(self) -> bool:
        return True

    def isatty(self) -> bool:
        return False

    def write(self, text: str) -> int:
        self.buffer.write(text.encode(self._charset, "backslashreplace"))
        return len(text)

    def flush(self) -> None:
        pass


class _CaptureInput(io.TextIOBase):
    """Standard input fed from the invoke ``input`` data."""

    def __init__(self, data: bytes, charset: str, echo_sink: t.Optional[_CaptureBuffer]) -> None:
        self._raw = io.BytesIO(data)
        self._text = io.TextIOWrapper(self._raw, encoding=charset, errors="replace")
        self._echo = echo_sink
        self.buffer = self._raw

    @property
    def encoding(self) -> str:
        return self._text.encoding

    def readable(self) -> bool:
        return True

    def isatty(self) -> bool:
        return False

    def _echoed(self, text: str) -> str:
        if self._echo is not None and text:
            self._echo.write(text.encode(self._text.encoding, "replace"))
        return text

    def read(self, size: int = -1) -> str:
        return self._echoed(self._text.read(size))

    def readline(self, size: int = -1) -> str:
        return self._echoed(self._text.readline(size))


class Result:
    """What one invocation produced."""

    def __init__(
        self,
        log: t.List[t.Tuple[str, bytes]],
        charset: str,
        return_value: t.Any,
        exit_code: int,
        exception: t.Optional[BaseException],
        exc_info: t.Any,
    ) -> None:
        self._charset = charset
        self.stdout_bytes = b"".join(data for kind, data in log if kind == "stdout")
        self.stderr_bytes = b"".join(data for kind, data in log if kind == "stderr")
        self.output_bytes = b"".join(data for _, data in log)
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self) -> str:
        return self.output_bytes.decode(self._charset, "replace")

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self._charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self._charset, "replace")

    def __repr__(self) -> str:
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invokes a command in-process, capturing standard streams and the exit status."""

    def __init__(
        self,
        charset: str = "utf-8",
        env: t.Optional[t.Mapping[str, t.Optional[str]]] = None,
        echo_stdin: bool = False,
        catch_exceptions: bool = True,
        capture: str = "sys",
    ) -> None:
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli: t.Any) -> str:
        return cli.name or "root"

    @contextlib.contextmanager
    def isolation(self, input_bytes: bytes, log: t.List[t.Tuple[str, bytes]], env: t.Mapping[str, t.Optional[str]]):
        echo_sink = _CaptureBuffer("stdout", log) if self.echo_stdin else None
        stdin = _CaptureInput(input_bytes, self.charset, echo_sink)
        fd_files = None
        if self.capture == "fd":
            sys.stdout.flush()
            sys.stderr.flush()
            out_file = tempfile.TemporaryFile()
            err_file = tempfile.TemporaryFile()
            saved_fds = (os.dup(1), os.dup(2))
            os.dup2(out_file.fileno(), 1)
            os.dup2(err_file.fileno(), 2)
            stdout = io.TextIOWrapper(io.FileIO(1, "w", closefd=False), encoding=self.charset, write_through=True)
            stderr = io.TextIOWrapper(io.FileIO(2, "w", closefd=False), encoding=self.charset, write_through=True)
            fd_files = (out_file, err_file, saved_fds)
        else:
            stdout = _CaptureText("stdout", log, self.charset)
            stderr = _CaptureText("stderr", log, self.charset)
        saved_streams = (sys.stdin, sys.stdout, sys.stderr)
        saved_env = {key: os.environ.get(key) for key in env}
        for key, value in env.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield
        finally:
            sys.stdin, sys.stdout, sys.stderr = saved_streams
            stdout.flush()
            stderr.flush()
            if fd_files is not None:
                out_file, err_file, (saved_out, saved_err) = fd_files
                os.dup2(saved_out, 1)
                os.dup2(saved_err, 2)
                os.close(saved_out)
                os.close(saved_err)
                for kind, handle in (("stdout", out_file), ("stderr", err_file)):
                    handle.seek(0)
                    log.append((kind, handle.read()))
                    handle.close()
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(
        self,
        cli: t.Any,
        args: t.Any = None,
        input: t.Any = None,
        env: t.Optional[t.Mapping[str, t.Optional[str]]] = None,
        catch_exceptions: t.Optional[bool] = None,
        color: bool = False,
        **extra: t.Any,
    ) -> Result:
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
        if isinstance(args, str):
            args = shlex.split(args)
        arg_list = list(args or [])
        merged_env: t.Dict[str, t.Optional[str]] = dict(self.env)
        merged_env.update(env or {})
        log: t.List[t.Tuple[str, bytes]] = []
        exit_code = 0
        exception: t.Optional[BaseException] = None
        exc_info: t.Any = None
        return_value: t.Any = None
        extra.setdefault("color", color)
        with self.isolation(_to_bytes(input, self.charset), log, merged_env):
            try:
                return_value = cli.main(args=arg_list, prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                code = e.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    sys.stderr.write(str(code) + "\n")
                    exit_code = 1
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
        return Result(log, self.charset, return_value, exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir: t.Optional[str] = None):
        """Run the block inside a new empty directory, which is the working directory."""
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(dt, ignore_errors=True)
