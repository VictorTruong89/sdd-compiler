"""Token parsing for options. Positional arguments are assigned by the command."""

import typing as t

from .exceptions import BadOptionUsage, NoSuchOption


class _NeedsValue:
    """Marks an optional-value option that was given without a value."""

    def __repr__(self) -> str:
        return "NEEDS_VALUE"


NEEDS_VALUE: t.Any = _NeedsValue()


def _prefix_of(name: str) -> str:
    end = 0
    while end < len(name) and not name[end].isalnum() and name[end] != "_":
        end += 1
    return name[:end]


class OptionParser:
    """Parses a token list against a set of options.

    Positional tokens are collected in ``largs`` in order. Option values are
    collected in ``raw``, keyed by option, and ``order`` records first use.
    """

    def __init__(
        self,
        options: t.Sequence[t.Any],
        allow_interspersed_args: bool = True,
        ignore_unknown_options: bool = False,
        normalize: t.Optional[t.Callable[[str], str]] = None,
    ) -> None:
        self.allow_interspersed_args = allow_interspersed_args
        self.ignore_unknown_options = ignore_unknown_options
        self._normalize = normalize or (lambda s: s)
        self._lookup: t.Dict[str, t.Tuple[t.Any, bool]] = {}
        self._short_prefixes: t.Set[str] = set()
        self._long_prefixes: t.Set[str] = set()
        for opt in options:
            for name in opt.opts:
                self._register(name, opt, False)
            for name in opt.secondary_opts:
                self._register(name, opt, True)
        self.raw: t.Dict[t.Any, t.Any] = {}
        self.order: t.List[t.Any] = []
        self.largs: t.List[str] = []

    def _register(self, name: str, opt: t.Any, secondary: bool) -> None:
        prefix = _prefix_of(name)
        if len(prefix) >= 2:
            self._long_prefixes.add(prefix)
        else:
            self._short_prefixes.add(prefix)
        self._lookup[self._normalize(name)] = (opt, secondary)

    def _find(self, name: str) -> t.Optional[t.Tuple[t.Any, bool]]:
        return self._lookup.get(self._normalize(name))

    def _long_prefix(self, arg: str) -> t.Optional[str]:
        for prefix in self._long_prefixes:
            if arg.startswith(prefix) and len(arg) > len(prefix):
                return prefix
        return None

    def _is_option(self, arg: str) -> bool:
        if len(arg) < 2:
            return False
        if self._long_prefix(arg) is not None:
            return True
        return arg[0] in self._short_prefixes or arg[0] in {p[0] for p in self._long_prefixes}

    def parse(self, args: t.Sequence[str]) -> t.Tuple[t.Dict[t.Any, t.Any], t.List[t.Any], t.List[str]]:
        i = 0
        stop = False
        n = len(args)
        while i < n:
            arg = args[i]
            i += 1
            if stop:
                self.largs.append(arg)
                continue
            if arg == "--":
                stop = True
                continue
            if self._is_option(arg):
                i = self._parse_option_token(arg, args, i)
                continue
            self.largs.append(arg)
            if not self.allow_interspersed_args:
                self.largs.extend(args[i:])
                break
        return self.raw, self.order, self.largs

    def _parse_option_token(self, arg: str, args: t.Sequence[str], i: int) -> int:
        if self._long_prefix(arg) is not None:
            return self._parse_long(arg, args, i)
        return self._parse_short(arg, args, i)

    def _parse_long(self, arg: str, args: t.Sequence[str], i: int) -> int:
        name, has_eq, inline = arg.partition("=")
        found = self._find(name)
        if found is None:
            if self.ignore_unknown_options:
                self.largs.append(arg)
                return i
            raise NoSuchOption(name)
        opt, secondary = found
        if opt.is_flag or opt.count:
            if has_eq:
                raise BadOptionUsage(name, f"Option {name!r} does not take a value.")
            self._store_flag(opt, secondary)
            return i
        value, i = self._take_value(opt, name, inline if has_eq else None, args, i)
        self._store(opt, value)
        return i

    def _parse_short(self, arg: str, args: t.Sequence[str], i: int) -> int:
        prefix = arg[0]
        chars = arg[1:]
        unknown: t.List[str] = []
        j = 0
        while j < len(chars):
            ch = chars[j]
            j += 1
            name = prefix + ch
            found = self._find(name)
            if found is None:
                if self.ignore_unknown_options:
                    unknown.append(ch)
                    continue
                raise NoSuchOption(name)
            opt, secondary = found
            if opt.is_flag or opt.count:
                self._store_flag(opt, secondary)
                continue
            rest = chars[j:] or None
            value, i = self._take_value(opt, name, rest, args, i)
            self._store(opt, value)
            break
        if unknown:
            self.largs.append(prefix + "".join(unknown))
        return i

    def _take_value(
        self,
        opt: t.Any,
        name: str,
        inline: t.Optional[str],
        args: t.Sequence[str],
        i: int,
    ) -> t.Tuple[t.Any, int]:
        if opt.nargs == 1:
            if inline is not None:
                return inline, i
            if opt.needs_value_flag:
                if i < len(args) and not self._is_option(args[i]):
                    return args[i], i + 1
                if opt.flag_value is not None:
                    return opt.flag_value, i
                return NEEDS_VALUE, i
            if i >= len(args):
                raise BadOptionUsage(name, f"Option {name!r} requires an argument.")
            return args[i], i + 1
        values: t.List[str] = []
        if inline is not None:
            values.append(inline)
        while len(values) < opt.nargs:
            if i >= len(args):
                raise BadOptionUsage(name, f"Option {name!r} requires {opt.nargs} arguments.")
            values.append(args[i])
            i += 1
        return tuple(values), i

    def _store_flag(self, opt: t.Any, secondary: bool) -> None:
        if opt.count:
            self.raw[opt] = self.raw.get(opt, 0) + 1
            if opt not in self.order:
                self.order.append(opt)
            return
        self._store(opt, opt.secondary_flag_value if secondary else opt.flag_value)

    def _store(self, opt: t.Any, value: t.Any) -> None:
        if opt.multiple:
            self.raw.setdefault(opt, []).append(value)
        else:
            self.raw[opt] = value
        if opt not in self.order:
            self.order.append(opt)
