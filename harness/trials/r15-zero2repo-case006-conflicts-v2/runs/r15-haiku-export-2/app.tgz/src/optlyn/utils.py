"""File, stream, and environment helpers shared by the rest of the package."""

import io
import os
import re
import sys
import tempfile
import typing as t

from .exceptions import FileError

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")
_WRITE_MODES = ("w", "a", "x", "+")


def strip_ansi(text: str) -> str:
    """Remove ANSI escape sequences, leaving all other text."""
    return _ANSI_RE.sub("", text)


class _NonClosing:
    """Proxy for a standard stream whose ``close`` must not close the stream."""

    def __init__(self, stream: t.Any, detach: bool = False) -> None:
        self._stream = stream
        self._detach = detach

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def close(self) -> None:
        if self._detach:
            self._stream.flush()
            self._stream.detach()
        else:
            self._stream.flush()


def get_text_stream(name: str, encoding: t.Optional[str] = None, errors: str = "strict") -> t.Any:
    """Return the text stream ``stdin``/``stdout``/``stderr`` that cannot be closed."""
    stream = {"stdin": sys.stdin, "stdout": sys.stdout, "stderr": sys.stderr}[name]
    if encoding is None:
        return _NonClosing(stream)
    try:
        stream.flush()
    except Exception:
        pass
    buffer = getattr(stream, "buffer", None)
    if buffer is None:
        return _NonClosing(stream)
    wrapper = io.TextIOWrapper(buffer, encoding=encoding, errors=errors, write_through=True)
    return _NonClosing(wrapper, detach=True)


def get_binary_stream(name: str) -> t.Any:
    """Return the binary stream behind ``stdin``/``stdout``/``stderr``."""
    stream = {"stdin": sys.stdin, "stdout": sys.stdout, "stderr": sys.stderr}[name]
    try:
        stream.flush()
    except Exception:
        pass
    return _NonClosing(getattr(stream, "buffer", stream))


class AtomicFile:
    """Write to a sibling temporary file; replace the target when closed."""

    def __init__(self, filename: str, mode: str, encoding: t.Optional[str], errors: t.Optional[str]) -> None:
        self._target = filename
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        os.close(fd)
        if "b" in mode:
            encoding = errors = None
        self._file = open(self._tmp, mode, encoding=encoding, errors=errors)

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._file, name)

    def __iter__(self):
        return iter(self._file)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def close(self) -> None:
        if self._file.closed:
            return
        self._file.close()
        os.replace(self._tmp, self._target)


class LazyFile:
    """A file that is opened on first I/O rather than when created."""

    def __init__(
        self,
        filename: str,
        mode: str = "r",
        encoding: t.Optional[str] = None,
        errors: t.Optional[str] = "strict",
        atomic: bool = False,
    ) -> None:
        self.name = filename
        self.mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._file: t.Any = None

    def _ensure(self) -> t.Any:
        if self._file is None:
            try:
                self._file = _open(self.name, self.mode, self._encoding, self._errors, self._atomic)
            except OSError as e:
                raise FileError(self.name, e.strerror or str(e)) from e
        return self._file

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._ensure(), name)

    def __iter__(self):
        return iter(self._ensure())

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def close(self) -> None:
        if self._file is not None:
            self._file.close()


def _open(filename: str, mode: str, encoding: t.Optional[str], errors: t.Optional[str], atomic: bool) -> t.Any:
    if "b" in mode:
        return open(filename, mode)
    if atomic and any(m in mode for m in _WRITE_MODES):
        return AtomicFile(filename, mode, encoding, errors)
    return open(filename, mode, encoding=encoding, errors=errors)


def open_file(
    filename: str,
    mode: str = "r",
    encoding: t.Optional[str] = None,
    errors: t.Optional[str] = "strict",
    lazy: bool = False,
    atomic: bool = False,
) -> t.Any:
    """Open a file, or the standard stream for ``-``.

    Files open immediately unless ``lazy`` is set. Standard streams are never
    closed by the caller's block.
    """
    if filename == "-":
        name = "stdout" if any(m in mode for m in _WRITE_MODES) else "stdin"
        if "b" in mode:
            return get_binary_stream(name)
        return get_text_stream(name, encoding, errors or "strict")
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    return _open(filename, mode, encoding, errors, atomic)


def format_filename(filename: t.Any, shorten: bool = False) -> str:
    """Return a printable, UTF-8-encodable text form of a file name."""
    if isinstance(filename, (bytes, bytearray)):
        name = os.fsdecode(bytes(filename))
    else:
        name = os.fspath(filename)
    if shorten:
        name = os.path.basename(name)
    try:
        return name.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")
    except UnicodeEncodeError:
        return name.encode("utf-8", "backslashreplace").decode("utf-8")


def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    """Return the per-user configuration directory for ``app_name``."""
    home = os.path.expanduser("~")
    folder = "-".join(app_name.lower().split())
    if force_posix:
        return os.path.join(home, "." + folder)
    if sys.platform == "win32":
        var = "APPDATA" if roaming else "LOCALAPPDATA"
        base = os.environ.get(var) or os.path.join(home, "AppData", "Roaming" if roaming else "Local")
        return os.path.join(base, app_name)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    xdg = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(xdg, folder)
