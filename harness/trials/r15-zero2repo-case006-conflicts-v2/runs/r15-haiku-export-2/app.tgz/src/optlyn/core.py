"""Parameters, the invocation context, commands, and groups."""

import enum
import inspect
import itertools
import os
import re
import sys
import typing as t
from collections.abc import Mapping
from contextlib import ExitStack

from . import types as _types
from ._state import pop_context, push_context
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingParameter,
    OptlynError,
    UsageError,
)
from .formatting import HelpFormatter
from .parser import NEEDS_VALUE, OptionParser
from .termui import confirm, echo, prompt

_counter = itertools.count()


class ParameterSource(enum.Enum):
    """Where a parameter's value came from."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


_SOURCE_RANK = {
    ParameterSource.DEFAULT: 1,
    ParameterSource.DEFAULT_MAP: 2,
    ParameterSource.ENVIRONMENT: 3,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.PROMPT: 5,
}

_TRUE = _types.TRUE_TOKENS
_FALSE = _types.FALSE_TOKENS


def _show_help(ctx: "Context", param: t.Any, value: t.Any) -> None:
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def _split_option_decls(decls: t.Sequence[str]) -> t.Tuple[t.List[str], t.List[str], t.Optional[str]]:
    opts: t.List[str] = []
    secondary: t.List[str] = []
    dest: t.Optional[str] = None
    for decl in decls:
        if decl and not (decl[0].isalnum() or decl[0] == "_"):
            slash = decl.find("/", len(_prefix(decl)))
            if slash > 0:
                opts.append(decl[:slash])
                secondary.append(decl[slash + 1 :])
            else:
                opts.append(decl)
        else:
            if dest is not None:
                raise TypeError("Parameter destination given more than once.")
            dest = decl
    return opts, secondary, dest


def _infer_name(opts: t.Sequence[str]) -> str:
    def stripped(name: str) -> str:
        return name.lstrip("".join(ch for ch in name if not ch.isalnum() and ch != "_")).replace("-", "_")

    longs = [o for o in opts if len(_prefix(o)) >= 2]
    shorts = [o for o in opts if len(_prefix(o)) < 2]
    for name in longs:
        if stripped(name).isidentifier():
            return stripped(name)
    for name in shorts:
        if stripped(name).isidentifier():
            return stripped(name)
    first = (longs or shorts)[0]
    return stripped(first)


def _prefix(name: str) -> str:
    end = 0
    while end < len(name) and not name[end].isalnum() and name[end] != "_":
        end += 1
    return name[:end]


def iter_params_for_processing(invocation_order: t.Sequence[t.Any], declaration_order: t.Sequence[t.Any]) -> t.List[t.Any]:
    """Eager parameters first, then in the order they were typed, then the rest in declaration order."""

    def sort_key(item: t.Any) -> t.Tuple[bool, float]:
        try:
            index: float = invocation_order.index(item)
        except ValueError:
            index = float("inf")
        return (not item.is_eager, index)

    return sorted(declaration_order, key=sort_key)


class Parameter:
    """Base class for options and arguments."""

    param_type_name = "parameter"

    def __init__(
        self,
        name: str,
        type: t.Any = None,
        required: bool = False,
        default: t.Any = None,
        callback: t.Optional[t.Callable] = None,
        nargs: int = 1,
        multiple: bool = False,
        metavar: t.Optional[str] = None,
        expose_value: bool = True,
        is_eager: bool = False,
        envvar: t.Any = None,
        shell_complete: t.Optional[t.Callable] = None,
        deprecated: t.Any = False,
        allow_from_autoenv: bool = True,
        hidden: bool = False,
        help: t.Optional[str] = None,
    ) -> None:
        self.name = name
        self.required = required
        self.default = default
        self.callback = callback
        self.nargs = nargs
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        if envvar is None:
            self.envvar: t.List[str] = []
        elif isinstance(envvar, str):
            self.envvar = [envvar]
        else:
            self.envvar = list(envvar)
        self.shell_complete_func = shell_complete
        self.deprecated = deprecated
        self.allow_from_autoenv = allow_from_autoenv
        self.hidden = hidden
        self.help = help
        self._order = next(_counter)
        self._auto_default = False
        self.type = self._resolve_type(type)
        if isinstance(self.type, _types.Tuple):
            self.nargs = len(self.type.types)

    def _resolve_type(self, ty: t.Any) -> t.Any:
        return _types.convert_type(ty, self.default if not callable(self.default) else None)

    @property
    def is_builtin_type(self) -> bool:
        return isinstance(self.type, _types.BUILTIN_TYPE_CLASSES)

    # -- naming and help -------------------------------------------------

    def get_error_hint(self, ctx: t.Any) -> str:
        return f"'{self.make_metavar()}'"

    def make_metavar(self) -> str:
        if self.metavar is not None:
            return self.metavar
        if isinstance(self.type, _types.Choice):
            return self.type.get_metavar(self) or ""
        if isinstance(self.type, _types.Tuple):
            return self.type.get_metavar(self)
        if not self.is_builtin_type:
            return self.type.name.upper()
        return self.name.upper()

    def get_usage_pieces(self, ctx: t.Any) -> t.List[str]:
        return []

    # -- values ----------------------------------------------------------

    def get_default(self, ctx: t.Any, call: bool = True) -> t.Any:
        value = self.default
        if callable(value) and call:
            value = value()
        return value

    def type_cast_value(self, ctx: t.Any, value: t.Any) -> t.Any:
        """Convert a value that is already shaped per occurrence into the delivered shape."""
        if self.multiple:
            occurrences = [] if value is None else value
            return tuple(self._convert_occurrence(ctx, occ) for occ in occurrences)
        if self.nargs == -1:
            tokens = [] if value is None else value
            return tuple(self._convert_scalar(ctx, tok) for tok in tokens)
        if isinstance(self.type, _types.Tuple):
            if value is None:
                return None
            return self._convert_scalar(ctx, tuple(value))
        if self.nargs != 1:
            if value is None:
                return None
            return tuple(self._convert_scalar(ctx, tok) for tok in value)
        if value is None:
            return None
        return self._convert_scalar(ctx, value)

    def _convert_occurrence(self, ctx: t.Any, occurrence: t.Any) -> t.Any:
        if isinstance(self.type, _types.Tuple):
            return self._convert_scalar(ctx, tuple(occurrence))
        if self.nargs != 1:
            return tuple(self._convert_scalar(ctx, tok) for tok in occurrence)
        return self._convert_scalar(ctx, occurrence)

    def _convert_scalar(self, ctx: t.Any, value: t.Any) -> t.Any:
        try:
            return self.type(value, self, ctx)
        except BadParameter as e:
            if e.param is None:
                e.param = self
            if e.ctx is None:
                e.ctx = ctx
            raise

    def value_is_missing(self, value: t.Any) -> bool:
        if value is None:
            return True
        if (self.multiple or self.nargs == -1) and value == ():
            return True
        return False

    def process_value(self, ctx: t.Any, value: t.Any) -> t.Any:
        value = self.type_cast_value(ctx, value)
        if self.required and self.value_is_missing(value):
            raise MissingParameter(ctx=ctx, param=self)
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value

    @property
    def _tuple_type(self) -> bool:
        return isinstance(self.type, _types.Tuple)

    def _tokens_to_shape(self, tokens: t.List[str]) -> t.Any:
        """Group split tokens into the per-occurrence shape the parser produces."""
        if self.multiple:
            if self.nargs == 1 and not self._tuple_type:
                return tokens
            size = self.nargs
            return [tuple(tokens[i : i + size]) for i in range(0, len(tokens), size)]
        return tuple(tokens)

    def _shape_external(self, ctx: t.Any, value: t.Any, source: ParameterSource) -> t.Any:
        """Shape a value from the default map or declared default."""
        if value is None:
            return None
        if isinstance(value, str):
            if self.multiple and self.nargs == 1 and not self._tuple_type:
                raise self._not_iterable(ctx, value)
            if self.nargs == 1 and not self.multiple and not self._tuple_type:
                return value
            return self._tokens_to_shape(self.type.split_envvar_value(value))
        if self.multiple:
            if isinstance(value, (list, tuple)):
                return list(value)
            raise self._not_iterable(ctx, value)
        if self.nargs != 1 or self._tuple_type:
            return tuple(value) if isinstance(value, (list, tuple)) else value
        return value

    def _not_iterable(self, ctx: t.Any, value: t.Any) -> BadParameter:
        return BadParameter(
            f"{value!r} is not an iterable (sequence) default; "
            "a repeatable option needs a sequence of values.",
            ctx=ctx,
            param=self,
        )

    def _envvar_names(self, ctx: t.Any) -> t.List[str]:
        return list(self.envvar)

    def _shape_env_string(self, raw: str) -> t.Any:
        if self.nargs == 1 and not self.multiple and not self._tuple_type:
            return raw
        return self._tokens_to_shape(self.type.split_envvar_value(raw))

    def resolve_envvar(self, ctx: t.Any) -> t.Any:
        for name in self._envvar_names(ctx):
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            value = self._shape_env_string(raw)
            if value is not None:
                return value
        return None

    def lookup_default_map(self, ctx: t.Any) -> t.Any:
        return ctx.lookup_default(self.name)

    def prompt_for_value(self, ctx: t.Any, default: t.Any) -> t.Any:
        raise NotImplementedError

    def _resolve_value(self, ctx: t.Any, raw: t.Any) -> t.Tuple[t.Any, ParameterSource]:
        if raw is not None and raw is not NEEDS_VALUE:
            return raw, ParameterSource.COMMANDLINE
        forced = raw is NEEDS_VALUE
        env_value = self.resolve_envvar(ctx)
        if getattr(self, "prompt", None) is not None and (forced or (self.prompt_required and env_value is None)):
            default = self.lookup_default_map(ctx)
            if default is None:
                default = self.get_default(ctx)
            value = self.prompt_for_value(ctx, default)
            return value, ParameterSource.PROMPT
        if forced:
            raise BadOptionUsage(self.name, f"Option {self.name!r} requires an argument.", ctx=ctx)
        if env_value is not None:
            return env_value, ParameterSource.ENVIRONMENT
        dm_value = self.lookup_default_map(ctx)
        if dm_value is not None:
            return self._shape_external(ctx, dm_value, ParameterSource.DEFAULT_MAP), ParameterSource.DEFAULT_MAP
        default = self.get_default(ctx)
        return self._shape_external(ctx, default, ParameterSource.DEFAULT), ParameterSource.DEFAULT

    def _warn_deprecated(self, ctx: t.Any) -> None:
        kind = "option" if self.param_type_name == "option" else "argument"
        message = f"DeprecationWarning: The {kind} {self.get_error_hint(ctx)} is deprecated."
        if isinstance(self.deprecated, str):
            message += " " + self.deprecated
        echo(message, err=True)

    def handle_parse_result(self, ctx: t.Any, raw: t.Any) -> t.Any:
        if self.deprecated and raw is not None:
            self._warn_deprecated(ctx)
        value, source = self._resolve_value(ctx, raw)
        value = self.process_value(ctx, value)
        if self.expose_value:
            explicit = 1 if (self.default is not None and not self._auto_default) else 0
            rank = (_SOURCE_RANK[source], explicit, self._order)
            previous = ctx._ranks.get(self.name)
            if previous is None or rank >= previous:
                ctx.params[self.name] = value
                ctx._ranks[self.name] = rank
                ctx._sources[self.name] = source
        return value


class Option(Parameter):
    """A named parameter, introduced by a prefix such as ``--`` or ``-``."""

    param_type_name = "option"

    def __init__(
        self,
        param_decls: t.Sequence[str] = (),
        show_default: t.Any = None,
        prompt: t.Any = False,
        confirmation_prompt: bool = False,
        prompt_required: bool = True,
        hide_input: bool = False,
        is_flag: t.Optional[bool] = None,
        flag_value: t.Any = None,
        count: bool = False,
        show_envvar: bool = False,
        show_choices: bool = True,
        **attrs: t.Any,
    ) -> None:
        opts, secondary, dest = _split_option_decls(param_decls)
        if not opts:
            raise TypeError("An option needs at least one flag name.")
        name = dest if dest is not None else _infer_name(opts + secondary)
        if is_flag is None:
            is_flag = bool(secondary) if flag_value is None else False
        if count and is_flag:
            raise TypeError("'count' is not compatible with 'is_flag'.")
        if attrs.get("deprecated") and attrs.get("required"):
            raise TypeError("A deprecated option cannot be required.")
        if attrs.get("deprecated") and prompt:
            raise TypeError("A deprecated option cannot use a prompt.")
        self.opts = opts
        self.secondary_opts = secondary
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self.takes_value = not (self.is_flag or self.count)
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.show_choices = show_choices
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.prompt_required = prompt_required
        self.prompt = _prompt_text(prompt, name)

        if self.is_flag:
            self.flag_value = True if flag_value is None else flag_value
        else:
            self.flag_value = flag_value
        self.secondary_flag_value = False
        self.needs_value_flag = self.takes_value and (
            (self.flag_value is not None) or (self.prompt is not None and not prompt_required)
        )

        default = attrs.pop("default", None)
        if self.is_flag and default is None:
            default = False
            self._auto_default = True
        if self.count and default is None:
            default = 0
        attrs.setdefault("nargs", 1)
        if attrs["nargs"] < 1:
            raise TypeError("'nargs' must be a positive integer for options.")
        type_arg = attrs.pop("type", None)
        self._type_arg = type_arg
        self._explicit_type = type_arg is not None
        self._flag_guess = self.flag_value
        super().__init__(name, type=None, default=default, **attrs)
        if isinstance(self.type, _types.Tuple):
            self.nargs = len(self.type.types)
        if not self.takes_value:
            self.nargs = 1

    def _resolve_type(self, ty: t.Any) -> t.Any:
        return self._build_type(self._type_arg)

    def _build_type(self, ty: t.Any) -> t.Any:
        if ty is not None:
            return _types.convert_type(ty)
        if self.is_flag:
            if isinstance(self._flag_guess, bool) or self._flag_guess is None:
                return _types.BOOL
            return _types.convert_type(None, self._flag_guess)
        if self.count:
            return _types.INT
        if self.flag_value is not None:
            return _types.convert_type(None, self.flag_value)
        return _types.convert_type(None, self.default if not callable(self.default) else None)

    def get_help_record(self, ctx: t.Any) -> t.Optional[t.Tuple[str, str]]:
        if self.hidden:
            return None
        opts = ", ".join(self.opts)
        if self.secondary_opts:
            opts = f"{opts} / {', '.join(self.secondary_opts)}"
        if not self.is_flag and not self.count:
            metavar = self.make_metavar()
            if metavar:
                opts = f"{opts} {metavar}"
        extras: t.List[str] = []
        show_default = self.show_default if self.show_default is not None else bool(ctx.show_default)
        if isinstance(self.show_default, str):
            extras.append(f"[default: {self.show_default}]")
        elif show_default and not callable(self.default) and self.default is not None:
            if not self.is_flag or self.default:
                extras.append(f"[default: {self.default}]")
        if self.show_envvar and self.envvar:
            extras.append(f"[env var: {', '.join(self.envvar)}]")
        text = self.help or ""
        if self.deprecated:
            text = ("(DEPRECATED) " + text).strip()
        if extras:
            text = (text + " " + " ".join(extras)).strip()
        return opts, text

    def get_error_hint(self, ctx: t.Any) -> str:
        return " / ".join(f"'{o}'" for o in self.opts + self.secondary_opts)

    def make_metavar(self) -> str:
        if self.metavar is not None:
            return self.metavar
        if self.is_flag or self.count:
            return ""
        if isinstance(self.type, _types.Choice):
            return self.type.get_metavar(self) or ""
        if isinstance(self.type, _types.Tuple):
            return self.type.get_metavar(self)
        base = self.type.name.upper() if not self.is_builtin_type else self.name.upper()
        if self.nargs > 1:
            return " ".join([base] * self.nargs)
        return base

    def _envvar_names(self, ctx: t.Any) -> t.List[str]:
        names = list(self.envvar)
        if self.allow_from_autoenv and ctx.auto_envvar_prefix is not None:
            parts = [ctx.auto_envvar_prefix, self.name]
            names.append("_".join(p.replace("-", "_") for p in parts).upper())
        return names

    def resolve_envvar(self, ctx: t.Any) -> t.Any:
        for name in self._envvar_names(ctx):
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            if self.is_flag:
                value = self._flag_from_env(ctx, raw)
            else:
                value = self._shape_env_string(raw)
            if value is not None:
                return value
        return None

    def _flag_from_env(self, ctx: t.Any, raw: str) -> t.Any:
        token = raw.strip().lower()
        flag_value = self.flag_value
        if isinstance(flag_value, bool):
            if token in _TRUE:
                return True
            if token in _FALSE or token == "":
                return False
            raise BadParameter(f"{raw!r} is not a valid boolean.", ctx=ctx, param=self)
        if raw == str(flag_value) or token == str(flag_value).lower():
            return flag_value
        if token in _TRUE:
            return flag_value
        if token in _FALSE:
            return False
        return None

    def prompt_for_value(self, ctx: t.Any, default: t.Any) -> t.Any:
        if self.is_flag:
            return confirm(self.prompt, default=bool(default) if default is not None else False)
        shown = default if not isinstance(default, (list, tuple)) else None

        def convert(raw: str) -> t.Any:
            return self._convert_scalar(ctx, raw)

        value = prompt(
            self.prompt,
            default=shown,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            value_proc=convert,
            show_default=True,
        )
        return [value] if self.multiple else value

    def get_usage_pieces(self, ctx: t.Any) -> t.List[str]:
        return []


def _prompt_text(prompt_arg: t.Any, name: str) -> t.Optional[str]:
    if prompt_arg is True:
        return name.replace("_", " ").capitalize()
    if isinstance(prompt_arg, str):
        return prompt_arg
    return None


class Argument(Parameter):
    """A positional parameter. Tokens bind in declaration order."""

    param_type_name = "argument"

    def __init__(
        self,
        param_decls: t.Sequence[str] = (),
        required: t.Optional[bool] = None,
        default: t.Any = None,
        nargs: t.Optional[int] = None,
        **attrs: t.Any,
    ) -> None:
        if len(param_decls) != 1:
            raise TypeError("An argument takes exactly one destination name.")
        name = param_decls[0].replace("-", "_")
        if nargs is None:
            nargs = 1
        if nargs == 0 or nargs < -1:
            raise TypeError("'nargs' must be a positive integer, or -1 for variadic.")
        if required is None:
            required = default is None and nargs != -1
        if attrs.get("deprecated") and required:
            raise TypeError("A deprecated argument cannot be required.")
        if attrs.get("deprecated") and default is None and not required:
            raise TypeError("A deprecated argument needs a default or must be optional.")
        type_arg = attrs.pop("type", None)
        attrs.pop("cls", None)
        self.prompt = None
        self.prompt_required = True
        self.show_default = None
        self.show_envvar = False
        self.show_choices = True
        self.hide_input = False
        self.confirmation_prompt = False
        self.is_flag = False
        self.count = False
        self.takes_value = True
        self.flag_value = None
        self.secondary_flag_value = None
        self.needs_value_flag = False
        self.opts = []
        self.secondary_opts = []
        self._explicit_type = type_arg is not None
        self._type_arg = type_arg
        super().__init__(name, type=None, required=required, default=default, nargs=nargs, **attrs)

    def _resolve_type(self, ty: t.Any) -> t.Any:
        if self._type_arg is not None:
            ty = self._type_arg
        return _types.convert_type(ty, self.default if not callable(self.default) else None)

    def get_error_hint(self, ctx: t.Any) -> str:
        return f"'{self.make_metavar()}'"

    def get_help_record(self, ctx: t.Any) -> t.Optional[t.Tuple[str, str]]:
        if self.hidden or not self.help:
            return None
        return self.make_metavar(), self.help

    def get_usage_pieces(self, ctx: t.Any) -> t.List[str]:
        if self.hidden:
            return []
        metavar = self.make_metavar()
        if self.nargs > 1 and not isinstance(self.type, _types.Tuple):
            metavar = " ".join([metavar] * self.nargs)
        if self.nargs == -1:
            metavar = f"{metavar}..."
        if not self.required:
            metavar = f"[{metavar}]"
        return [metavar]

    def make_metavar(self) -> str:
        if self.metavar is not None:
            return self.metavar
        if isinstance(self.type, _types.Choice):
            return self.type.get_metavar(self) or ""
        if isinstance(self.type, _types.Tuple):
            return self.type.get_metavar(self)
        if not self.is_builtin_type:
            return self.type.name.upper()
        return self.name.upper()

    def prompt_for_value(self, ctx: t.Any, default: t.Any) -> t.Any:
        raise BadArgumentUsage(f"Missing argument {self.make_metavar()}.", ctx=ctx)


class Context:
    """State for one invocation of a command, linked to its parent context."""

    def __init__(
        self,
        command: "Command",
        parent: t.Optional["Context"] = None,
        info_name: t.Optional[str] = None,
        obj: t.Any = None,
        auto_envvar_prefix: t.Optional[str] = None,
        default_map: t.Optional[Mapping] = None,
        terminal_width: t.Optional[int] = None,
        max_content_width: t.Optional[int] = None,
        allow_extra_args: t.Optional[bool] = None,
        allow_interspersed_args: t.Optional[bool] = None,
        ignore_unknown_options: t.Optional[bool] = None,
        help_option_names: t.Optional[t.Sequence[str]] = None,
        token_normalize_func: t.Optional[t.Callable[[str], str]] = None,
        color: t.Optional[bool] = None,
        show_default: t.Optional[bool] = None,
        resilient_parsing: bool = False,
        **extra: t.Any,
    ) -> None:
        self.parent = parent
        self.command = command
        self.info_name = info_name
        self.resilient_parsing = resilient_parsing
        self.extra = extra
        if parent is not None:
            if obj is None:
                obj = parent.obj
            if terminal_width is None:
                terminal_width = parent.terminal_width
            if max_content_width is None:
                max_content_width = parent.max_content_width
            if help_option_names is None:
                help_option_names = parent.help_option_names
            if token_normalize_func is None:
                token_normalize_func = parent.token_normalize_func
            if color is None:
                color = parent.color
            if show_default is None:
                show_default = parent.show_default
            if auto_envvar_prefix is None and parent.auto_envvar_prefix is not None and info_name:
                auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{info_name}"
            if ignore_unknown_options is None:
                ignore_unknown_options = parent.ignore_unknown_options
        self.obj = obj
        self.terminal_width = terminal_width
        self.max_content_width = max_content_width if max_content_width is not None else 80
        self.help_option_names = list(help_option_names) if help_option_names is not None else ["--help"]
        self.token_normalize_func = token_normalize_func
        self.color = color
        self.show_default = bool(show_default) if show_default is not None else False
        self.auto_envvar_prefix = auto_envvar_prefix
        self.default_map = default_map
        self.allow_extra_args = allow_extra_args if allow_extra_args is not None else command.allow_extra_args
        self.allow_interspersed_args = (
            allow_interspersed_args if allow_interspersed_args is not None else command.allow_interspersed_args
        )
        self.ignore_unknown_options = bool(ignore_unknown_options)
        self.params: t.Dict[str, t.Any] = {}
        self.args: t.List[str] = []
        self.protected_args: t.List[str] = []
        self.invoked_subcommand: t.Optional[str] = None
        self._ranks: t.Dict[str, t.Any] = {}
        self._sources: t.Dict[str, ParameterSource] = {}
        self._depth = 0
        self._exit_stack = ExitStack()

    # -- navigation ------------------------------------------------------

    @property
    def command_path(self) -> str:
        rv = self.info_name or ""
        if self.parent is not None:
            parent_path = self.parent.command_path
            rv = f"{parent_path} {rv}" if parent_path else rv
        return rv

    def find_root(self) -> "Context":
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type: type) -> t.Any:
        node: t.Optional[Context] = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type: type) -> t.Any:
        rv = self.find_object(object_type)
        if rv is None:
            self.obj = rv = object_type()
        return rv

    def lookup_default(self, name: str) -> t.Any:
        if self.default_map is not None:
            return self.default_map.get(name)
        return None

    def get_parameter_source(self, name: str) -> t.Optional[ParameterSource]:
        return self._sources.get(name)

    # -- output and control ----------------------------------------------

    def make_formatter(self) -> HelpFormatter:
        return HelpFormatter(width=self.terminal_width, max_width=self.max_content_width)

    def get_usage(self) -> str:
        formatter = self.make_formatter()
        self.command.format_usage(self, formatter)
        return formatter.getvalue().rstrip("\n")

    def get_help(self) -> str:
        return self.command.get_help(self)

    def fail(self, message: str) -> t.NoReturn:
        raise UsageError(message, ctx=self)

    def abort(self) -> t.NoReturn:
        raise Abort()

    def exit(self, code: int = 0) -> t.NoReturn:
        raise Exit(code)

    def call_on_close(self, func: t.Callable[[], t.Any]) -> t.Callable[[], t.Any]:
        self._exit_stack.callback(func)
        return func

    def with_resource(self, context_manager: t.Any) -> t.Any:
        return self._exit_stack.enter_context(context_manager)

    def close(self) -> None:
        self._exit_stack.close()

    def _make_sub_context(self, command: "Command") -> "Context":
        return type(self)(command, info_name=command.name, parent=self)

    def invoke(self, callback: t.Any, /, *args: t.Any, **kwargs: t.Any) -> t.Any:
        if isinstance(callback, Command):
            other = callback
            if other.callback is None:
                raise TypeError("The given command does not have a callback that can be invoked.")
            func = other.callback
            ctx = self._make_sub_context(other)
            for param in other.get_params(ctx):
                if param.name not in kwargs and param.expose_value:
                    kwargs[param.name] = param.type_cast_value(ctx, param.get_default(ctx))
            ctx.params.update(kwargs)
        else:
            func = callback
            ctx = self
        with ctx:
            return func(*args, **kwargs)

    def forward(self, cmd: t.Any, /, *args: t.Any, **kwargs: t.Any) -> t.Any:
        merged = dict(self.params)
        merged.update(kwargs)
        return self.invoke(cmd, *args, **merged)

    def __enter__(self) -> "Context":
        self._depth += 1
        push_context(self)
        return self

    def __exit__(self, exc_type: t.Any, exc: t.Any, tb: t.Any) -> None:
        self._depth -= 1
        if self._depth == 0:
            self.close()
        pop_context()


class Command:
    """A leaf command: parses its arguments and runs a callback."""

    allow_extra_args = False
    allow_interspersed_args = True
    context_class = Context

    def __init__(
        self,
        name: t.Optional[str],
        context_settings: t.Optional[t.Mapping[str, t.Any]] = None,
        callback: t.Optional[t.Callable] = None,
        params: t.Optional[t.List[t.Any]] = None,
        help: t.Optional[str] = None,
        epilog: t.Optional[str] = None,
        short_help: t.Optional[str] = None,
        options_metavar: t.Optional[str] = "[OPTIONS]",
        add_help_option: bool = True,
        no_args_is_help: bool = False,
        hidden: bool = False,
        deprecated: t.Any = False,
    ) -> None:
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        if help is None and callback is not None and callback.__doc__:
            help = _clean_doc(callback.__doc__)
        elif help is not None:
            help = _clean_doc(help)
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated
        variadic = [p for p in self.params if isinstance(p, Argument) and p.nargs == -1]
        if len(variadic) > 1:
            raise TypeError("Only one variadic argument is allowed per command.")

    def __call__(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        return self.main(*args, **kwargs)

    # -- parameters ------------------------------------------------------

    def get_help_option(self, ctx: Context) -> t.Optional[Option]:
        if not self.add_help_option:
            return None
        taken = {o for p in self.params if isinstance(p, Option) for o in p.opts + p.secondary_opts}
        names = [n for n in ctx.help_option_names if n not in taken]
        if not names:
            return None
        return Option(
            names,
            is_flag=True,
            expose_value=False,
            is_eager=True,
            callback=_show_help,
            help="Show this message and exit.",
        )

    def get_params(self, ctx: Context) -> t.List[Parameter]:
        rv: t.List[Parameter] = list(self.params)
        help_option = self.get_help_option(ctx)
        if help_option is not None:
            rv.append(help_option)
        return rv

    # -- context and parsing ---------------------------------------------

    def make_context(
        self,
        info_name: t.Optional[str],
        args: t.Sequence[str],
        parent: t.Optional[Context] = None,
        **extra: t.Any,
    ) -> Context:
        for key, value in self.context_settings.items():
            if key not in extra:
                extra[key] = value
        if parent is not None and "default_map" not in extra and parent.default_map:
            nested = parent.default_map.get(info_name)
            if isinstance(nested, Mapping):
                extra["default_map"] = nested
        ctx = self.context_class(self, info_name=info_name, parent=parent, **extra)
        self.parse_args(ctx, list(args))
        return ctx

    def parse_args(self, ctx: Context, args: t.List[str]) -> t.List[str]:
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            echo(ctx.get_help(), err=True)
            ctx.exit(2)
        params = self.get_params(ctx)
        parser = OptionParser(
            [p for p in params if isinstance(p, Option)],
            allow_interspersed_args=ctx.allow_interspersed_args,
            ignore_unknown_options=ctx.ignore_unknown_options,
            normalize=ctx.token_normalize_func,
        )
        try:
            raw, order, largs = parser.parse(args)
        except UsageError as e:
            if e.ctx is None:
                e.ctx = ctx
            raise
        arguments = [p for p in params if isinstance(p, Argument)]
        arg_values, leftover = _assign_arguments(ctx, arguments, largs)
        values: t.Dict[t.Any, t.Any] = dict(raw)
        values.update(arg_values)
        invocation = list(order) + [a for a in arguments if arg_values.get(a) is not None]
        for param in iter_params_for_processing(invocation, params):
            param.handle_parse_result(ctx, values.get(param))
        if leftover:
            if ctx.allow_extra_args:
                ctx.args.extend(leftover)
            elif not ctx.resilient_parsing:
                ctx.fail(
                    "Got unexpected extra argument"
                    f"{'s' if len(leftover) > 1 else ''} ({' '.join(leftover)})"
                )
        return ctx.args

    def invoke(self, ctx: Context) -> t.Any:
        if self.deprecated:
            message = f"DeprecationWarning: The command {ctx.command_path!r} is deprecated."
            if isinstance(self.deprecated, str):
                message += " " + self.deprecated
            echo(message, err=True)
        if self.callback is not None:
            return ctx.invoke(self.callback, **ctx.params)
        return None

    # -- entry point -----------------------------------------------------

    def main(
        self,
        args: t.Optional[t.Sequence[str]] = None,
        prog_name: t.Optional[str] = None,
        complete_var: t.Optional[str] = None,
        standalone_mode: bool = True,
        **extra: t.Any,
    ) -> t.Any:
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        if prog_name is None:
            prog_name = _detect_prog_name() or self.name or "root"
        if complete_var is None:
            complete_var = "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"
        instruction = os.environ.get(complete_var)
        if instruction:
            from .shell_completion import run_completion

            code = run_completion(self, prog_name, instruction)
            if standalone_mode:
                sys.exit(code)
            return code

        try:
            with self.make_context(prog_name, args, **extra) as ctx:
                rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                ctx.exit()
        except (EOFError, KeyboardInterrupt) as e:
            echo(file=sys.stderr)
            if not standalone_mode:
                raise Abort() from e
            echo("Aborted!", file=sys.stderr)
            sys.exit(1)
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", file=sys.stderr)
            sys.exit(1)
        return None

    # -- help ------------------------------------------------------------

    def get_usage(self, ctx: Context) -> str:
        return ctx.get_usage()

    def collect_usage_pieces(self, ctx: Context) -> t.List[str]:
        rv: t.List[str] = []
        if self.options_metavar:
            rv.append(self.options_metavar)
        for param in self.get_params(ctx):
            rv.extend(param.get_usage_pieces(ctx))
        return rv

    def format_usage(self, ctx: Context, formatter: HelpFormatter) -> None:
        pieces = self.collect_usage_pieces(ctx)
        formatter.write_usage(ctx.command_path, " ".join(pieces))

    def get_help(self, ctx: Context) -> str:
        formatter = ctx.make_formatter()
        self.format_help(ctx, formatter)
        return formatter.getvalue().rstrip("\n")

    def format_help(self, ctx: Context, formatter: HelpFormatter) -> None:
        self.format_usage(ctx, formatter)
        self.format_help_text(ctx, formatter)
        self.format_arguments(ctx, formatter)
        self.format_options(ctx, formatter)
        self.format_commands(ctx, formatter)
        self.format_epilog(ctx, formatter)

    def format_help_text(self, ctx: Context, formatter: HelpFormatter) -> None:
        text = self.help or ""
        if self.deprecated:
            text = ("(DEPRECATED) " + text).strip()
        if text:
            formatter.write_paragraph()
            formatter.indent()
            formatter.write_text(text)
            formatter.dedent()

    def format_arguments(self, ctx: Context, formatter: HelpFormatter) -> None:
        rows = []
        for param in self.get_params(ctx):
            if isinstance(param, Argument):
                record = param.get_help_record(ctx)
                if record is not None:
                    rows.append(record)
        if rows:
            with formatter.section("Positional arguments"):
                formatter.write_dl(rows)

    def format_options(self, ctx: Context, formatter: HelpFormatter) -> None:
        rows = []
        for param in self.get_params(ctx):
            if isinstance(param, Option):
                record = param.get_help_record(ctx)
                if record is not None:
                    rows.append(record)
        if rows:
            with formatter.section("Options"):
                formatter.write_dl(rows)

    def format_commands(self, ctx: Context, formatter: HelpFormatter) -> None:
        return None

    def format_epilog(self, ctx: Context, formatter: HelpFormatter) -> None:
        if self.epilog:
            formatter.write_paragraph()
            formatter.write_text(self.epilog)

    def get_short_help_str(self, limit: int = 45) -> str:
        if self.short_help is not None:
            text = self.short_help
        elif self.help:
            paragraph = self.help.split("\n\n")[0]
            joined = " ".join(paragraph.split())
            parts = _split_sentences(joined)
            text = parts[0] if parts else joined
        else:
            text = ""
        text = " ".join(text.split())
        if len(text) > limit:
            text = text[: max(limit - 3, 0)].rstrip() + "..."
        return text

def _split_sentences(text: str) -> t.List[str]:
    return re.split(r"(?<=[.!?])\s", text, maxsplit=1)


def _clean_doc(doc: str) -> str:
    doc = doc.split("\f", 1)[0]
    return inspect.cleandoc(doc)


def _detect_prog_name() -> t.Optional[str]:
    if not sys.argv or not sys.argv[0]:
        return None
    return os.path.basename(sys.argv[0]) or None


def _assign_arguments(
    ctx: Context, arguments: t.Sequence[Argument], tokens: t.Sequence[str]
) -> t.Tuple[t.Dict[Argument, t.Any], t.List[str]]:
    result: t.Dict[Argument, t.Any] = {}
    remaining = list(tokens)
    for index, arg in enumerate(arguments):
        if arg.nargs == -1:
            reserve = sum(a.nargs for a in arguments[index + 1 :] if a.required and a.nargs > 0)
            take = max(len(remaining) - reserve, 0)
            chunk = remaining[:take]
            remaining = remaining[take:]
            result[arg] = list(chunk) if chunk else None
            continue
        if not remaining:
            result[arg] = None
            continue
        if len(remaining) < arg.nargs:
            raise BadArgumentUsage(
                f"Argument {arg.make_metavar()} takes {arg.nargs} values.", ctx=ctx
            )
        chunk = remaining[: arg.nargs]
        remaining = remaining[arg.nargs :]
        result[arg] = chunk[0] if arg.nargs == 1 else tuple(chunk)
    return result, remaining


class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_extra_args = True
    allow_interspersed_args = False

    def __init__(
        self,
        name: t.Optional[str] = None,
        commands: t.Any = None,
        invoke_without_command: bool = False,
        no_args_is_help: t.Optional[bool] = None,
        subcommand_metavar: t.Optional[str] = None,
        chain: bool = False,
        result_callback: t.Optional[t.Callable] = None,
        **kwargs: t.Any,
    ) -> None:
        super().__init__(name, **kwargs)
        self.commands: t.Dict[str, Command] = {}
        if commands is not None:
            if isinstance(commands, Mapping):
                for cmd_name, cmd in commands.items():
                    self.add_command(cmd, cmd_name)
            else:
                for cmd in commands:
                    self.add_command(cmd)
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.chain = chain
        self._result_callback = result_callback
        if subcommand_metavar is None:
            if chain:
                first = "[COMMAND]" if invoke_without_command else "COMMAND"
                subcommand_metavar = f"{first} [ARGS]... [COMMAND [ARGS]...]..."
            elif invoke_without_command:
                subcommand_metavar = "[COMMAND] [ARGS]..."
            else:
                subcommand_metavar = "COMMAND [ARGS]..."
        self.subcommand_metavar = subcommand_metavar

    # -- registration ----------------------------------------------------

    def add_command(self, cmd: Command, name: t.Optional[str] = None) -> None:
        name = name or cmd.name
        if name is None:
            raise TypeError("A command needs a name before it can be added to a group.")
        if self.chain and isinstance(cmd, Group):
            raise RuntimeError("Cannot attach a group beneath a chaining group.")
        self.commands[name] = cmd

    def command(self, *args: t.Any, **kwargs: t.Any) -> t.Callable:
        from .decorators import command as command_decorator

        decorator = command_decorator(*args, **kwargs)

        def register(f: t.Callable) -> Command:
            cmd = decorator(f)
            self.add_command(cmd)
            return cmd

        return register

    def group(self, *args: t.Any, **kwargs: t.Any) -> t.Callable:
        from .decorators import group as group_decorator

        decorator = group_decorator(*args, **kwargs)

        def register(f: t.Callable) -> "Group":
            cmd = decorator(f)
            self.add_command(cmd)
            return cmd

        return register

    def result_callback(self, replace: bool = False) -> t.Callable:
        """Return a decorator that registers ``f(value, **group_params)`` as the result callback."""

        def decorator(f: t.Callable) -> t.Callable:
            self._result_callback = f
            return f

        return decorator

    # -- lookup ----------------------------------------------------------

    def list_commands(self, ctx: Context) -> t.List[str]:
        return sorted(self.commands)

    def get_command(self, ctx: Context, cmd_name: str) -> t.Optional[Command]:
        return self.commands.get(cmd_name)

    def resolve_command(self, ctx: Context, args: t.List[str]) -> t.Tuple[t.Optional[str], t.Optional[Command], t.List[str]]:
        cmd_name = args[0]
        original = cmd_name
        cmd = self.get_command(ctx, cmd_name)
        if cmd is None and ctx.token_normalize_func is not None:
            normalize = ctx.token_normalize_func
            for name in self.list_commands(ctx):
                if normalize(name) == normalize(cmd_name):
                    cmd_name = name
                    cmd = self.get_command(ctx, name)
                    break
        if cmd is None:
            ctx.fail(f"No such command {original!r}.")
        return cmd_name, cmd, args[1:]

    # -- parsing and dispatch --------------------------------------------

    def parse_args(self, ctx: Context, args: t.List[str]) -> t.List[str]:
        rest = super().parse_args(ctx, args)
        if self.chain:
            ctx.protected_args = list(rest)
            ctx.args = []
        elif rest:
            ctx.protected_args = list(rest[:1])
            ctx.args = list(rest[1:])
        else:
            ctx.protected_args = []
            ctx.args = []
        return ctx.args

    def invoke(self, ctx: Context) -> t.Any:
        def process_result(value: t.Any) -> t.Any:
            if self._result_callback is not None:
                value = ctx.invoke(self._result_callback, value, **ctx.params)
            return value

        if not ctx.protected_args:
            if self.invoke_without_command:
                with ctx:
                    rv = super().invoke(ctx)
                    return process_result([] if self.chain else rv)
            ctx.fail("Missing command.")

        args = [*ctx.protected_args, *ctx.args]
        ctx.args = []
        ctx.protected_args = []

        if not self.chain:
            with ctx:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                ctx.invoked_subcommand = cmd_name
                super().invoke(ctx)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx)
                with sub_ctx:
                    return process_result(sub_ctx.command.invoke(sub_ctx))

        with ctx:
            ctx.invoked_subcommand = "*" if args else None
            super().invoke(ctx)
            contexts: t.List[Context] = []
            while args:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                sub_ctx = cmd.make_context(
                    cmd_name,
                    args,
                    parent=ctx,
                    allow_extra_args=True,
                    allow_interspersed_args=False,
                )
                contexts.append(sub_ctx)
                args, sub_ctx.args = sub_ctx.args, []
            rv: t.List[t.Any] = []
            for sub_ctx in contexts:
                with sub_ctx:
                    rv.append(sub_ctx.command.invoke(sub_ctx))
            return process_result(rv)

    # -- help ------------------------------------------------------------

    def collect_usage_pieces(self, ctx: Context) -> t.List[str]:
        rv = super().collect_usage_pieces(ctx)
        rv.append(self.subcommand_metavar)
        return rv

    def format_commands(self, ctx: Context, formatter: HelpFormatter) -> None:
        names = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            names.append((name, cmd))
        if not names:
            return
        longest = max(len(name) for name, _ in names)
        limit = formatter.width - 6 - longest
        rows = [(name, cmd.get_short_help_str(limit)) for name, cmd in names]
        with formatter.section("Commands"):
            formatter.write_dl(rows)


class CommandCollection(Group):
    """A group that presents the subcommands of several source groups."""

    def __init__(self, name: t.Optional[str] = None, sources: t.Optional[t.Iterable[Group]] = None, **kwargs: t.Any) -> None:
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx: Context) -> t.List[str]:
        names: t.Set[str] = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx: Context, cmd_name: str) -> t.Optional[Command]:
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None
