"""Terminal helpers: output, styling, prompts, pagers, progress bars, editors."""

import contextlib
import getpass
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
import typing as t

from ._state import get_current_context
from .exceptions import Abort, BadParameter
from .types import convert_type
from .utils import strip_ansi


class InvalidColorError(TypeError, ValueError):
    """A style color is not a name, a 0-255 integer, or an RGB triple."""


def _isatty(stream: t.Any) -> bool:
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def _is_interactive() -> bool:
    return _isatty(sys.stdin) or _isatty(sys.stdout)


def echo(
    message: t.Any = None,
    file: t.Any = None,
    nl: bool = True,
    err: bool = False,
    color: t.Optional[bool] = None,
) -> None:
    """Write text or bytes to standard output (or error), stripping styles when needed."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, (bytes, bytearray)):
        buffer = getattr(file, "buffer", None)
        if buffer is None:
            file.write(bytes(message).decode("utf-8", "replace") + ("\n" if nl else ""))
        else:
            file.flush()
            buffer.write(bytes(message) + (b"\n" if nl else b""))
            buffer.flush()
        file.flush()
        return

    if color is None:
        ctx = get_current_context(silent=True)
        color = ctx.color if ctx is not None else None
    if color is None:
        keep = _isatty(file)
    else:
        keep = bool(color)
    if not keep:
        message = strip_ansi(message)
    if nl:
        message += "\n"
    encoding = (getattr(file, "encoding", None) or "").lower()
    if "ascii" in encoding:
        file.flush()
        file.buffer.write(message.encode("utf-8"))
        file.buffer.flush()
    else:
        file.write(message)
    file.flush()


_COLOR_NAMES = {
    "black": 0,
    "red": 1,
    "green": 2,
    "yellow": 3,
    "blue": 4,
    "magenta": 5,
    "cyan": 6,
    "white": 7,
}


def _color_code(color: t.Any, foreground: bool) -> str:
    base = 30 if foreground else 40
    if isinstance(color, str):
        if color == "reset":
            return "39" if foreground else "49"
        if color.startswith("bright_") and color[7:] in _COLOR_NAMES:
            return str(base + 60 + _COLOR_NAMES[color[7:]])
        if color in _COLOR_NAMES:
            return str(base + _COLOR_NAMES[color])
        raise InvalidColorError(f"Unknown color {color!r}.")
    if isinstance(color, int) and not isinstance(color, bool):
        if 0 <= color <= 255:
            return f"{38 if foreground else 48};5;{color}"
        raise InvalidColorError(f"Color {color!r} is out of range 0-255.")
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return f"{38 if foreground else 48};2;{color[0]};{color[1]};{color[2]}"
    raise InvalidColorError(f"Invalid color {color!r}.")


def style(
    text: t.Any,
    fg: t.Any = None,
    bg: t.Any = None,
    bold: t.Optional[bool] = None,
    dim: t.Optional[bool] = None,
    underline: t.Optional[bool] = None,
    overline: t.Optional[bool] = None,
    italic: t.Optional[bool] = None,
    blink: t.Optional[bool] = None,
    reverse: t.Optional[bool] = None,
    strikethrough: t.Optional[bool] = None,
    reset: bool = True,
) -> str:
    """Wrap ``text`` in ANSI SGR sequences for the requested colors and switches."""
    bits: t.List[str] = []
    if fg is not None:
        bits.append(_color_code(fg, True))
    if bg is not None:
        bits.append(_color_code(bg, False))
    switches = (
        (bold, "1"),
        (dim, "2"),
        (italic, "3"),
        (underline, "4"),
        (blink, "5"),
        (reverse, "7"),
        (strikethrough, "9"),
        (overline, "53"),
    )
    for flag, code in switches:
        if flag:
            bits.append(code)
    if not bits:
        return str(text)
    result = f"\x1b[{';'.join(bits)}m{text}"
    if reset:
        result += "\x1b[0m"
    return result


def unstyle(text: str) -> str:
    """Remove ANSI styles, leaving all other text."""
    return strip_ansi(text)


def secho(
    message: t.Any = None,
    file: t.Any = None,
    nl: bool = True,
    err: bool = False,
    color: t.Optional[bool] = None,
    **styles: t.Any,
) -> None:
    """Echo text with styling applied in one step."""
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def _pager_command() -> str:
    return os.environ.get("PAGER") or "less"


def echo_via_pager(text_or_generator: t.Any, color: t.Optional[bool] = None) -> None:
    """Write long text through a pager when the session is interactive."""
    value = text_or_generator() if callable(text_or_generator) else text_or_generator
    chunks = [value] if isinstance(value, str) else list(value)
    if not _is_interactive():
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    proc = subprocess.Popen(_pager_command(), shell=True, stdin=subprocess.PIPE)
    try:
        for chunk in chunks:
            if color is False:
                chunk = strip_ansi(chunk)
            proc.stdin.write(chunk.encode("utf-8"))
            proc.stdin.flush()
    finally:
        proc.stdin.close()
        proc.wait()


class _EchoWriter:
    """A writable text stream that sends its text through ``echo``."""

    def __init__(self, color: t.Optional[bool]) -> None:
        self._color = color

    def write(self, text: str) -> int:
        echo(text, nl=False, color=self._color)
        return len(text)

    def flush(self) -> None:
        pass


@contextlib.contextmanager
def get_pager_file(color: t.Optional[bool] = None):
    """Yield a writable text stream that is sent through the pager when interactive."""
    if not _is_interactive():
        yield _EchoWriter(color)
        return
    proc = subprocess.Popen(_pager_command(), shell=True, stdin=subprocess.PIPE)
    try:
        yield proc.stdin
    finally:
        proc.stdin.close()
        proc.wait()


class ProgressBar:
    """The object yielded by ``progressbar``. Iterating it visits every item."""

    def __init__(self, iterable: t.Any, length: t.Optional[int], label: t.Optional[str], hidden: bool) -> None:
        self.iter = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.pos = 0
        self.start = time.time()
        self.drawn = False
        self.tty = not hidden and _isatty(sys.stdout)

    def __iter__(self):
        if self.iter is None:
            return
        for item in self.iter:
            yield item
            self.update(1)

    def update(self, n_steps: int, current_item: t.Any = None) -> None:
        self.pos += n_steps
        if self.tty:
            self._render()

    def _render(self) -> None:
        elapsed = time.time() - self.start
        if self.length:
            fraction = min(self.pos / self.length, 1.0)
            filled = int(fraction * 36)
            bar = "#" * filled + "-" * (36 - filled)
            if self.pos and fraction < 1.0:
                remaining = elapsed / fraction - elapsed
                eta = time.strftime("%H:%M:%S", time.gmtime(remaining))
            else:
                eta = "00:00:00"
            text = f"\r{self.label} [{bar}] {self.pos}/{self.length}  eta {eta}"
        else:
            text = f"\r{self.label} {self.pos}"
        echo(text, nl=False)
        self.drawn = True

    def finish(self) -> None:
        if self.drawn:
            echo("")


@contextlib.contextmanager
def progressbar(iterable: t.Any = None, length: t.Optional[int] = None, label: t.Optional[str] = None, hidden: bool = False, **options: t.Any):
    """Context manager yielding a progress bar that wraps ``iterable``."""
    bar = ProgressBar(iterable, length, label, hidden)
    if not hidden and not bar.tty and label:
        echo(label)
    try:
        yield bar
    finally:
        bar.finish()


def _read_line(text: str, hide_input: bool, err: bool) -> str:
    stream = sys.stderr if err else sys.stdout
    echo(text, nl=False, err=err)
    stream.flush()
    if hide_input and _isatty(sys.stdin):
        value = getpass.getpass("", stream=stream)
        return value
    line = sys.stdin.readline()
    if line == "":
        raise EOFError()
    value = line.rstrip("\r\n")
    if not hide_input and not _isatty(sys.stdin):
        echo(value, err=err)
    elif hide_input:
        echo("", err=err)
    return value


def prompt(
    text: str,
    default: t.Any = None,
    hide_input: bool = False,
    confirmation_prompt: bool = False,
    type: t.Any = None,
    value_proc: t.Optional[t.Callable[[str], t.Any]] = None,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
    show_choices: bool = True,
) -> t.Any:
    """Ask for a value, converting it and asking again until it is valid."""
    param_type = convert_type(type, default)
    convert = value_proc or (lambda raw: param_type.convert(raw))
    shown = None
    if default is not None and show_default:
        shown = str(default)
    while True:
        suffix = f" [{shown}]" if shown is not None else ""
        raw = _read_line(f"{text}{suffix}{prompt_suffix}", hide_input, err)
        if raw == "" and default is not None:
            raw_value: t.Any = default
        else:
            raw_value = raw
        try:
            result = convert(raw_value)
        except BadParameter as e:
            echo(f"Error: {e.format_message()}", err=err)
            continue
        if confirmation_prompt:
            second = _read_line("Repeat for confirmation" + prompt_suffix, hide_input, err)
            if second != raw:
                echo("Error: The two entered values do not match.", err=err)
                continue
        return result


def confirm(
    text: str,
    default: t.Optional[bool] = False,
    abort: bool = False,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
) -> bool:
    """Ask a yes/no question. ``y``/``yes`` is yes, ``n``/``no`` is no, and a blank line takes the default."""
    if show_default:
        if default is True:
            hint = " [Y/n]"
        elif default is False:
            hint = " [y/N]"
        else:
            hint = " [y/n]"
    else:
        hint = ""
    while True:
        answer = _read_line(f"{text}{hint}{prompt_suffix}", False, err).strip().lower()
        if answer in ("y", "yes"):
            value = True
            break
        if answer in ("n", "no"):
            value = False
            break
        if answer == "" and default is not None:
            value = default
            break
        echo("Error: invalid input", err=err)
    if abort and not value:
        raise Abort()
    return value


def getchar(echo: bool = False) -> str:
    """Read one character. Interrupt raises ``KeyboardInterrupt``; end of input raises ``EOFError``."""
    if _isatty(sys.stdin):
        import termios
        import tty

        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            char = os.read(fd, 1).decode("utf-8", "replace")
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    else:
        char = sys.stdin.read(1)
    if char == "":
        raise EOFError()
    if char == "\x03":
        raise KeyboardInterrupt()
    if char == "\x04":
        raise EOFError()
    if echo:
        sys.stdout.write(char)
        sys.stdout.flush()
    return char


def pause(info: t.Optional[str] = None, err: bool = False) -> None:
    """Wait for a key press when the session is interactive; do nothing otherwise."""
    if not _is_interactive():
        return
    echo(info or "Press any key to continue...", err=err, nl=False)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo("", err=err)


def edit(
    text: t.Optional[str] = None,
    editor: t.Optional[str] = None,
    env: t.Optional[t.Mapping[str, str]] = None,
    require_save: bool = True,
    extension: str = ".txt",
    filename: t.Optional[str] = None,
) -> t.Optional[str]:
    """Open an editor. Return the saved text, or ``None`` when unsaved or when ``filename`` is given."""
    if editor is None:
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR") or ("notepad" if os.name == "nt" else "vi")
    run_env = dict(os.environ)
    if env:
        run_env.update(env)
    if filename is not None:
        subprocess.call(shlex.split(editor) + [filename], env=run_env)
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(text or "")
        before = open(path, encoding="utf-8", newline="").read()
        subprocess.call(shlex.split(editor) + [path], env=run_env)
        with open(path, encoding="utf-8", newline="") as handle:
            after = handle.read()
    finally:
        os.remove(path)
    if require_save and after == before:
        return None
    return after


def launch(url: str, wait: bool = False, locate: bool = False) -> int:
    """Open ``url`` (or a path) with the default application. Returns a status code."""
    if sys.platform == "win32":
        os.startfile(url)  # type: ignore[attr-defined]
        return 0
    if sys.platform == "darwin":
        command = ["open", "-R", url] if locate else ["open", url]
    else:
        opener = shutil.which("xdg-open")
        if opener is None:
            return 127
        command = [opener, url]
    proc = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    if wait:
        return proc.wait()
    return 0


def clear() -> None:
    """Clear the terminal screen. Does nothing when not connected to a terminal."""
    if not _isatty(sys.stdout):
        return
    if os.name == "nt":
        os.system("cls")
        return
    echo("\x1b[2J\x1b[3J\x1b[1;1H", nl=False)
