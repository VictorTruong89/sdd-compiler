"""Exceptions raised by Optlyn.

Subclasses of ``OptlynError`` are reported by standalone program mode and
turned into an exit status. ``Abort`` and ``Exit`` are control-flow signals.
"""

import sys
import typing as t


class OptlynError(Exception):
    """Base class for errors that standalone mode shows and exits on."""

    exit_code = 1

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message

    def format_message(self) -> str:
        return self.message

    def show(self, file: t.Any = None) -> None:
        from .termui import echo

        if file is None:
            file = sys.stderr
        echo(f"Error: {self.format_message()}", file=file)


class UsageError(OptlynError):
    """An incorrect command line. Exit status 2, with the usage line shown."""

    exit_code = 2

    def __init__(self, message: str, ctx: t.Any = None) -> None:
        super().__init__(message)
        self.ctx = ctx

    def show(self, file: t.Any = None) -> None:
        from .termui import echo

        if file is None:
            file = sys.stderr
        if self.ctx is not None:
            echo(self.ctx.get_usage(), file=file)
            if self.ctx.help_option_names:
                hint = self.ctx.help_option_names[0]
                echo(f"Try '{self.ctx.command_path} {hint}' for help.", file=file)
        echo(f"\nError: {self.format_message()}", file=file)


class BadParameter(UsageError):
    """A value was refused by a type, a callback, or a conversion function."""

    def __init__(
        self,
        message: str,
        ctx: t.Any = None,
        param: t.Any = None,
        param_hint: t.Any = None,
    ) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self) -> str:
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if hint is None:
            return self.message
        if isinstance(hint, (list, tuple)):
            hint = " / ".join(f"'{h}'" for h in hint)
        return f"Invalid value for {hint}: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value from any source."""

    def __init__(
        self,
        message: t.Optional[str] = None,
        ctx: t.Any = None,
        param: t.Any = None,
        param_hint: t.Any = None,
        param_type: t.Optional[str] = None,
    ) -> None:
        super().__init__(message or "", ctx, param, param_hint)
        self.param_type = param_type

    def format_message(self) -> str:
        if self.message:
            return super().format_message()
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        kind = self.param_type
        if kind is None:
            kind = "option" if getattr(self.param, "param_type_name", "") == "option" else "argument"
        return f"Missing {kind} {hint}." if hint else f"Missing {kind}."


class NoSuchOption(UsageError):
    """An option token that matches no declared flag name."""

    def __init__(self, option_name: str, message: t.Optional[str] = None, ctx: t.Any = None) -> None:
        super().__init__(message or f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option was used incorrectly, for example without its value."""

    def __init__(self, option_name: str, message: str, ctx: t.Any = None) -> None:
        super().__init__(message, ctx)
        self.option_name = option_name


class BadArgumentUsage(UsageError):
    """A positional argument was used incorrectly."""


class FileError(OptlynError):
    """A file could not be opened at first I/O. General error, exit status 1."""

    def __init__(self, filename: str, hint: str) -> None:
        super().__init__(f"Could not open file {filename!r}: {hint}")
        self.filename = filename


class Abort(RuntimeError):
    """The user declined, or input ended, or an author aborted the run."""


class Exit(RuntimeError):
    """An author clean stop with an exit status."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code
