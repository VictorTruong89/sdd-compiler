"""Declaration decorators: commands, groups, options, arguments and ready-made options (section 3-4)."""

import functools
from importlib import metadata

from . import _state
from .core import Argument, Command, Group, Option, _show_help_callback
from .termui import confirm
from .utils import echo

_PARAMS_ATTR = "__optlyn_params__"


def _param_memo(f, param):
    if not hasattr(f, _PARAMS_ATTR):
        setattr(f, _PARAMS_ATTR, [])
    getattr(f, _PARAMS_ATTR).append(param)


def _pop_params(f):
    """Declarations attached to ``f`` move onto the new command (FP-03)."""
    params = getattr(f, _PARAMS_ATTR, [])
    if hasattr(f, _PARAMS_ATTR):
        delattr(f, _PARAMS_ATTR)
    params = list(reversed(params))
    return params


def _default_name(func_name):
    name = func_name.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def command(name=None, cls=None, **attrs):
    """Turn a function into a command."""
    if callable(name) and not isinstance(name, str):
        return command()(name)
    cls = cls or Command

    def decorator(f):
        cmd_name = name if name is not None else _default_name(f.__name__)
        params = _pop_params(f)
        return cls(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a group."""
    if callable(name) and not isinstance(name, str):
        return group()(name)
    cls = cls or Group

    def decorator(f):
        cmd_name = name if name is not None else _default_name(f.__name__)
        params = _pop_params(f)
        return cls(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to the function it decorates."""
    cls = cls or Option

    def decorator(f):
        _param_memo(f, cls(list(param_decls), **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to the function it decorates."""
    cls = cls or Argument

    def decorator(f):
        _param_memo(f, cls(list(param_decls), **attrs))
        return f

    return decorator


def help_option(*param_decls, **kwargs):
    """An extra eager help flag; it prints help and exits."""
    names = list(param_decls) or ["--help"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help_callback)
    return option(*names, **kwargs)


def _package_version(name):
    try:
        return metadata.version(name)
    except metadata.PackageNotFoundError:
        pass
    providers = metadata.packages_distributions().get(name, [])
    if providers:
        return metadata.version(providers[0])
    raise RuntimeError(f"Cannot determine the version of {name!r}.")


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """Eager version flag printing a version identity and exiting (FP-02)."""
    names = list(param_decls) or ["--version"]

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        ident = version
        if ident is None:
            ident = _package_version(package_name or ctx.find_root().info_name or "")
        prog = prog_name or ctx.find_root().info_name
        template = message or "%(prog)s, version %(version)s"
        echo(template % {"prog": prog, "package": package_name, "version": ident}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*names, **kwargs)


def custom_version_option(callback_fn, *param_decls, **kwargs):
    """Eager version flag whose identity is exactly the string ``callback_fn(ctx)`` returns."""
    names = list(param_decls) or ["--version"]

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback_fn(ctx), color=True)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*names, **kwargs)


def password_option(*param_decls, **kwargs):
    """Prompting, hidden, confirmed option (FP-08)."""
    names = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("help", "The password to use.")
    return option(*names, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    """A yes flag that prompts when omitted and aborts when declined (FP-08)."""
    names = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def callback(ctx, param, value):
        if not value and not ctx.resilient_parsing:
            confirm(question, abort=True)
        return value

    kwargs["callback"] = callback
    return option(*names, **kwargs)


def pass_context(f):
    """Pass the current context as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(_state.get_current_context(), *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Pass the nearest object of ``object_type`` from the context chain (FP-07)."""

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = _state.get_current_context()
            obj = ctx.find_object(object_type)
            if obj is None and ensure:
                obj = ctx.ensure_object(object_type)
            if obj is None:
                raise RuntimeError(f"Managed to invoke callback without a context object of type {object_type.__name__!r} existing.")
            return f(obj, *args, **kwargs)

        return new_func

    return decorator


def pass_obj(f):
    """Pass the current context's author object as the first argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        ctx = _state.get_current_context()
        return f(ctx.obj, *args, **kwargs)

    return new_func
