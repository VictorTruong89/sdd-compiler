"""Parameter types and conversion (FP-05, FP-09, section 5)."""

import datetime as _datetime
import enum
import os
import pathlib
import uuid as _uuid

from .exceptions import BadParameter, FileError
from .utils import format_filename, open_file


class CompletionItem:
    """A completion suggestion: a value, its help, and its kind (section 8)."""

    def __init__(self, value, help=None, type="plain"):
        self.value = value
        self.help = help
        self.type = type

    def __repr__(self):
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


def _normalize(value, ctx):
    func = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
    if func is not None:
        return func(value)
    return value


class ParamType:
    """Base class for types. Subclasses set ``name`` and implement ``convert``."""

    name = "text"
    arity = 1

    def convert(self, value, param=None, ctx=None):
        return value

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def get_metavar(self, param=None):
        return None

    def shell_complete(self, ctx, param, incomplete):
        return []

    def __repr__(self):
        return f"<{type(self).__name__}>"


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        if isinstance(value, str):
            return value
        return str(value)


class _IntType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        try:
            return int(value)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid float.", param, ctx)


class _BoolType(ParamType):
    name = "boolean"

    _true = {"1", "true", "t", "yes", "y", "on"}
    _false = {"0", "false", "f", "no", "n", "off"}

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in self._true:
            return True
        if text in self._false:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value))
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()


class Choice(ParamType):
    """A closed list of values, or the member names of an enumeration."""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self._members = {m.name: m for m in choices}
            self.choices = list(self._members)
        else:
            self._members = None
            self.choices = list(choices)

    def _original(self, key):
        if self._members is not None:
            return self._members[key]
        return key

    def _key_str(self, choice):
        return choice if isinstance(choice, str) else str(choice)

    def _fold(self, text):
        return text if self.case_sensitive else text.casefold()

    def get_metavar(self, param=None):
        return "[" + "|".join(str(c) for c in self.choices) + "]"

    def convert(self, value, param=None, ctx=None):
        if self._members is None and value in self.choices:
            return value
        if self._members is not None and isinstance(value, enum.Enum):
            return value
        token = self._fold(_normalize(str(value), ctx))
        for choice in self.choices:
            key = self._fold(_normalize(self._key_str(choice), ctx))
            if key == token:
                return self._original(choice)
        options = ", ".join(repr(str(c)) for c in self.choices)
        self.fail(f"{value!r} is not {'one of ' if len(self.choices) != 1 else ''}{options}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        return [CompletionItem(str(c)) for c in self.choices if str(c).startswith(incomplete)]


_DEFAULT_DATETIME_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(_DEFAULT_DATETIME_FORMATS if formats is None else formats)

    def get_metavar(self, param=None):
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _datetime.datetime):
            return value
        for fmt in self.formats:
            try:
                return _datetime.datetime.strptime(str(value), fmt)
            except ValueError:
                continue
        formats = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the formats {formats}.", param, ctx)


class _RangeMixin:
    def _range_text(self):
        lo, hi = self.min, self.max
        if lo is not None and hi is not None:
            left = "<" if self.min_open else "<="
            right = "<" if self.max_open else "<="
            return f"{lo}{left}x{right}{hi}"
        if lo is not None:
            return f"x{'>' if self.min_open else '>='}{lo}"
        if hi is not None:
            return f"x{'<' if self.max_open else '<='}{hi}"
        return ""

    def _check_range(self, value, param, ctx):
        if self.min is not None:
            if self.min_open:
                if value <= self.min:
                    return self._clamp_or_fail(value, param, ctx, low=True)
            elif value < self.min:
                return self._clamp_or_fail(value, param, ctx, low=True)
        if self.max is not None:
            if self.max_open:
                if value >= self.max:
                    return self._clamp_or_fail(value, param, ctx, low=False)
            elif value > self.max:
                return self._clamp_or_fail(value, param, ctx, low=False)
        return value

    def _clamp_or_fail(self, value, param, ctx, low):
        if self.clamp:
            if low:
                return self._adjacent(self.min, self.min_open, up=True)
            return self._adjacent(self.max, self.max_open, up=False)
        self.fail(f"{value!r} is not in the range {self._range_text()}.", param, ctx)

    def _adjacent(self, bound, is_open, up):
        raise NotImplementedError


class IntRange(_RangeMixin, _IntType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if min is not None and max is not None and min > max:
            raise ValueError("'min' must be less than or equal to 'max'.")
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def _adjacent(self, bound, is_open, up):
        if is_open:
            return bound + 1 if up else bound - 1
        return bound

    def convert(self, value, param=None, ctx=None):
        value = _IntType.convert(self, value, param, ctx)
        return self._check_range(value, param, ctx)


class FloatRange(_RangeMixin, _FloatType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if min is not None and max is not None and min > max:
            raise ValueError("'min' must be less than or equal to 'max'.")
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is only supported when both bounds are closed.")
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def _adjacent(self, bound, is_open, up):
        return bound

    def convert(self, value, param=None, ctx=None):
        value = _FloatType.convert(self, value, param, ctx)
        return self._check_range(value, param, ctx)


class Tuple(ParamType):
    """A fixed-length product of inner types."""

    name = "tuple"

    def __init__(self, types):
        self.types = [_convert_type_arg(t) for t in types]
        self.arity = len(self.types)

    def get_metavar(self, param=None):
        return " ".join((t.get_metavar(param) or t.name.upper()) for t in self.types)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, str):
            value = value.split()
        value = tuple(value)
        if len(value) != len(self.types):
            self.fail(f"{len(value)} values were given but {len(self.types)} are required.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


def _register_file(ctx, f):
    if ctx is not None and hasattr(ctx, "call_on_close"):
        ctx.call_on_close(f.close)


class File(ParamType):
    """An open file object; ``-`` is standard input or output (FP-09)."""

    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def get_metavar(self, param=None):
        return "FILENAME"

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self.lazy
        if lazy is None:
            lazy = "w" in self.mode
        if value == "-":
            lazy = False
        try:
            f = open_file(value, self.mode, self.encoding, self.errors, lazy=lazy, atomic=self.atomic)
        except FileError as e:
            self.fail(e.message, param, ctx)
        _register_file(ctx, f)
        return f

    def shell_complete(self, ctx, param, incomplete):
        return [CompletionItem(incomplete, type="file")]


class Path(ParamType):
    """A filesystem path, not an open file (FP-09)."""

    name = "path"

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False, readable=True,
                 resolve_path=False, allow_dash=False, path_type=None, executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def get_metavar(self, param=None):
        return "PATH"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            value = os.fsdecode(value)
        if isinstance(value, pathlib.PurePath):
            value = os.fspath(value)
        if self.allow_dash and value == "-":
            return self._deliver(value)
        if self.resolve_path:
            value = os.path.realpath(os.path.abspath(value))
        shown = format_filename(value)
        if not os.path.exists(value):
            if self.exists:
                self.fail(f"{shown!r} does not exist.", param, ctx)
        else:
            if not self.file_okay and os.path.isfile(value):
                self.fail(f"{shown!r} is a file.", param, ctx)
            if not self.dir_okay and os.path.isdir(value):
                self.fail(f"{shown!r} is a directory.", param, ctx)
            if self.readable and not os.access(value, os.R_OK):
                self.fail(f"{shown!r} is not readable.", param, ctx)
            if self.writable and not os.access(value, os.W_OK):
                self.fail(f"{shown!r} is not writable.", param, ctx)
            if self.executable and not os.access(value, os.X_OK):
                self.fail(f"{shown!r} is not executable.", param, ctx)
        return self._deliver(value)

    def _deliver(self, value):
        if self.path_type is None or self.path_type is str:
            return value
        if self.path_type is pathlib.Path or self.path_type is pathlib.PurePath:
            return pathlib.Path(value)
        return self.path_type(value)

    def shell_complete(self, ctx, param, incomplete):
        kind = "dir" if (self.dir_okay and not self.file_okay) else "file"
        return [CompletionItem(incomplete, type=kind)]


class FuncParamType(ParamType):
    """A conversion function that refuses invalid input by raising ValueError."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text") or "text"

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is not valid.", param, ctx)


def _convert_type_arg(ty):
    if isinstance(ty, ParamType):
        return ty
    if ty is str:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if ty is _uuid.UUID:
        return UUID
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type {ty!r}.")


def convert_type(ty, default=None):
    """Resolve a declared type, inferring one from ``default`` when ``ty`` is None."""
    if ty is None:
        if default is None:
            return STRING
        if isinstance(default, tuple):
            return Tuple([convert_type(None, v) for v in default])
        if isinstance(default, (list, set, frozenset)):
            sample = next(iter(default), None)
            return convert_type(None, sample) if sample is not None else STRING
        if isinstance(default, bool):
            return BOOL
        if isinstance(default, int):
            return INT
        if isinstance(default, float):
            return FLOAT
        if isinstance(default, _uuid.UUID):
            return UUID
        return STRING
    return _convert_type_arg(ty)

