"""Shell completion: registration scripts and suggestion output (FP-12, section 8)."""

import os
import sys

from .core import Context, Group, Option
from .paramtypes import CompletionItem

SHELLS = ("bash", "zsh", "fish", "powershell")


def _func_name(prog_name):
    return "optlyn_complete_" + "".join(c if c.isalnum() else "_" for c in prog_name)


def _var_name(prog_name):
    return "_" + prog_name.replace("-", "_").upper() + "_COMPLETE"


def _source_script(shell, prog_name, var):
    func = _func_name(prog_name)
    if shell == "bash":
        return f"""_{func}() {{
    local response item
    response=$(env COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD {var}=bash_complete {prog_name} 2>/dev/null)
    COMPREPLY=()
    local IFS=$'\\n'
    for item in $response; do
        case "$item" in
            @@file@@*) COMPREPLY+=($(compgen -f -- "${{item#@@file@@}}")) ;;
            @@dir@@*) COMPREPLY+=($(compgen -d -- "${{item#@@dir@@}}")) ;;
            *) COMPREPLY+=("$item") ;;
        esac
    done
    return 0
}}
complete -o default -F _{func} {prog_name}
"""
    if shell == "zsh":
        return f"""#compdef {prog_name}
_{func}() {{
    local -a response completions
    local item value
    response=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog_name} 2>/dev/null)}}")
    for item in "${{response[@]}}"; do
        value="${{item%%$'\\t'*}}"
        completions+=("$value")
    done
    compadd -- $completions
}}
compdef _{func} {prog_name}
"""
    if shell == "fish":
        return f"""function _{func}_completion
    set -l response (env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) {var}=fish_complete {prog_name} 2>/dev/null)
    for completion in $response
        echo $completion
    end
end
complete -nc {prog_name} -f -a '(_{func}_completion)'
"""
    return f"""Register-ArgumentCompleter -Native -CommandName {prog_name} -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $env:COMP_WORDS = $commandAst.ToString()
    $env:COMP_CWORD = $wordToComplete
    $env:{var} = "powershell_complete"
    & {prog_name} | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_) }}
    Remove-Item Env:{var}
}}
"""


def _split_line(shell):
    line = os.environ.get("COMP_WORDS", "")
    words = line.split(" ")
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        args = words[1:-1] if words and words[-1] == incomplete else words[1:]
        return args, incomplete
    try:
        cword = int(os.environ.get("COMP_CWORD", str(len(words))))
    except ValueError:
        cword = len(words)
    incomplete = words[cword] if cword < len(words) else ""
    return words[1:cword], incomplete


def _as_items(values, incomplete):
    items = []
    for value in values or []:
        if isinstance(value, CompletionItem):
            items.append(value)
        else:
            items.append(CompletionItem(str(value)))
    return [i for i in items if i.type != "plain" or str(i.value).startswith(incomplete)]


def _walk(cli, root_ctx, args):
    """Follow already-typed tokens down the group tree; returns (ctx, pending args)."""
    ctx = root_ctx
    tokens = list(args)
    positional = []
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        i += 1
        cmd = ctx.command
        flags = {}
        for param in cmd.get_params(ctx):
            for flag in param.all_flags() if not param.is_argument else []:
                flags[flag] = param
        if tok == "--":
            positional.extend(tokens[i:])
            break
        if tok in flags:
            if flags[tok].takes_value() and i < len(tokens):
                i += 1
            continue
        if tok.startswith("-") and tok != "-":
            continue
        if isinstance(cmd, Group) and not positional and not ctx.protected_args:
            child = cmd.get_command(ctx, tok)
            if child is not None:
                ctx = Context(child, info_name=tok, parent=ctx)
                positional = []
                continue
        positional.append(tok)
    return ctx, positional, tokens


def _option_flag_items(ctx, incomplete):
    items = []
    for param in ctx.command.get_params(ctx):
        if param.is_argument or getattr(param, "hidden", False):
            continue
        for flag in param.all_flags():
            if flag.startswith(incomplete):
                items.append(CompletionItem(flag, help=getattr(param, "help", None)))
    return items


def _suggestions(cli, prog_name, args, incomplete):
    root_ctx = Context(cli, info_name=prog_name)
    ctx, positional, tokens = _walk(cli, root_ctx, args)
    cmd = ctx.command

    if incomplete.startswith("-"):
        return _option_flag_items(ctx, incomplete)

    if tokens:
        previous = tokens[-1]
        for param in cmd.get_params(ctx):
            if param.is_argument or not isinstance(param, Option):
                continue
            if previous in param.all_flags() and param.takes_value():
                return _param_items(ctx, param, incomplete)

    if isinstance(cmd, Group) and not positional and not ctx.protected_args:
        items = []
        for name in cmd.list_commands(ctx):
            child = cmd.get_command(ctx, name)
            if child is None or child.hidden or not name.startswith(incomplete):
                continue
            items.append(CompletionItem(name, help=child.short_help_text(60) or None))
        return items

    arguments = [p for p in cmd.params if p.is_argument]
    if len(positional) < len(arguments):
        return _param_items(ctx, arguments[len(positional)], incomplete)
    return []


def _param_items(ctx, param, incomplete):
    if param.shell_complete is not None:
        return _as_items(param.shell_complete(ctx, param, incomplete), incomplete)
    if hasattr(param.type, "shell_complete"):
        return _as_items(param.type.shell_complete(ctx, param, incomplete), incomplete)
    return []


def _render(items, shell):
    lines = []
    for item in items:
        if item.type == "file":
            lines.append("@@file@@" + item.value)
        elif item.type == "dir":
            lines.append("@@dir@@" + item.value)
        elif shell in ("zsh", "fish") and item.help:
            lines.append(f"{item.value}\t{' '.join(str(item.help).split())}")
        else:
            lines.append(str(item.value))
    return lines


def run_completion(cli, args, prog_name, instruction, standalone_mode=True):
    """Handle ``_<PROG>_COMPLETE``; returns the exit status (FP-12)."""
    shell, _, action = instruction.partition("_")
    if shell not in SHELLS or action not in ("source", "complete"):
        return 1
    var = _var_name(prog_name)
    if action == "source":
        sys.stdout.write(_source_script(shell, prog_name, var))
        sys.stdout.flush()
        return 0
    prior, incomplete = _split_line(shell)
    items = _suggestions(cli, prog_name, prior, incomplete)
    for line in _render(items, shell):
        sys.stdout.write(line + "\n")
    sys.stdout.flush()
    return 0
