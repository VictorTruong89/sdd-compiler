"""Output, stream and filesystem helpers shared by the core and the terminal helpers."""

import codecs
import os
import re
import sys
import tempfile

from ._state import should_strip_ansi
from .exceptions import FileError

_ansi_re = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")


def unstyle(text):
    """Remove ANSI escape sequences, leaving all other text (FP-11)."""
    return _ansi_re.sub("", text)


def _is_ascii_stream(file):
    enc = getattr(file, "encoding", None) or ""
    try:
        return codecs.lookup(enc).name == "ascii"
    except LookupError:
        return False


def write_text(file, text):
    """Write text to ``file``; ASCII-only streams get UTF-8 bytes (FP-11)."""
    if _is_ascii_stream(file):
        buffer = getattr(file, "buffer", None)
        if buffer is not None:
            file.flush()
            buffer.write(text.encode("utf-8"))
            buffer.flush()
            return
    try:
        file.write(text)
    except UnicodeEncodeError:
        buffer = getattr(file, "buffer", None)
        if buffer is None:
            raise
        file.flush()
        buffer.write(text.encode("utf-8"))
        buffer.flush()


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes to stdout (stderr when ``err``) or ``file``."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        data = message + (b"\n" if nl else b"")
        buffer = getattr(file, "buffer", None)
        if buffer is None:
            buffer = file
        if hasattr(file, "flush"):
            file.flush()
        buffer.write(data)
        buffer.flush()
        return
    if not isinstance(message, str):
        message = str(message)
    if should_strip_ansi(file, color):
        message = unstyle(message)
    if nl:
        message += "\n"
    write_text(file, message)
    if hasattr(file, "flush"):
        file.flush()


def make_str(value):
    """Turn bytes into text, leaving other values alone."""
    if isinstance(value, bytes):
        return value.decode(sys.getfilesystemencoding() or "utf-8", "replace")
    return str(value) if not isinstance(value, str) else value


def format_filename(filename, shorten=False):
    """Text form of a path that may not be Unicode; never fails (FP-09)."""
    if isinstance(filename, bytes):
        filename = os.fsdecode(filename)
    else:
        filename = os.fspath(filename)
        if isinstance(filename, bytes):
            filename = os.fsdecode(filename)
    if shorten:
        filename = os.path.basename(filename)
    return filename.encode("utf-8", "backslashreplace").decode("utf-8")


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Per-user configuration directory for ``app_name`` (FP-11)."""
    home = os.path.expanduser("~")
    if sys.platform.startswith("win"):
        if not force_posix:
            base = os.environ.get("APPDATA" if roaming else "LOCALAPPDATA")
            if base is None:
                base = os.path.join(home, "AppData", "Roaming" if roaming else "Local")
            return os.path.join(base, app_name)
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(home, "Library", "Application Support", app_name)
    folder = "-".join(app_name.lower().split())
    if force_posix:
        return os.path.join(home, "." + folder)
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(config_home, folder)


class _NoCloseProxy:
    """Wraps a standard stream so that leaving a ``with`` block does not close it."""

    def __init__(self, stream):
        object.__setattr__(self, "_stream", stream)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def __next__(self):
        return next(self._stream)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def get_text_stdin(encoding=None, errors=None):
    return _NoCloseProxy(sys.stdin)


def get_text_stdout(encoding=None, errors=None):
    return _NoCloseProxy(sys.stdout)


def get_text_stderr(encoding=None, errors=None):
    return _NoCloseProxy(sys.stderr)


def get_binary_stdin():
    return _NoCloseProxy(getattr(sys.stdin, "buffer", sys.stdin))


def get_binary_stdout():
    return _NoCloseProxy(getattr(sys.stdout, "buffer", sys.stdout))


def get_binary_stderr():
    return _NoCloseProxy(getattr(sys.stderr, "buffer", sys.stderr))


class _AtomicWriter:
    """Writes to a sibling temporary file and replaces the target on close."""

    def __init__(self, filename, mode, encoding, errors):
        self.filename = filename
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        os.close(fd)
        self._file = open(self._tmp, mode, **_open_kwargs(mode, encoding, errors))
        self._closed = False

    def __getattr__(self, name):
        return getattr(self._file, name)

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._file.close()
        os.replace(self._tmp, self.filename)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


def _open_kwargs(mode, encoding, errors):
    if "b" in mode:
        return {}
    kwargs = {}
    if encoding is not None:
        kwargs["encoding"] = encoding
    if errors is not None:
        kwargs["errors"] = errors
    return kwargs


class LazyFile:
    """Opens its file on first I/O (FP-09). Closing an unused one does nothing."""

    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._file = None

    def _open(self):
        if self._file is not None:
            return self._file
        try:
            if self.atomic:
                self._file = _AtomicWriter(self.name, self.mode, self.encoding, self.errors)
            else:
                self._file = open(self.name, self.mode, **_open_kwargs(self.mode, self.encoding, self.errors))
        except OSError as e:
            raise FileError(format_filename(self.name), f"Could not open file '{format_filename(self.name)}': {e.strerror}") from e
        return self._file

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def __next__(self):
        return next(self._open())

    def close(self):
        if self._file is not None:
            self._file.close()

    def close_intelligently(self):
        self.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or a standard stream for ``-`` (FP-09, FP-11)."""
    if filename == "-":
        if any(m in mode for m in "wax"):
            stream = sys.stdout
        else:
            stream = sys.stdin
        if "b" in mode:
            stream = getattr(stream, "buffer", stream)
        return _NoCloseProxy(stream)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    try:
        if atomic and any(m in mode for m in "wax"):
            return _AtomicWriter(filename, mode, encoding, errors)
        return open(filename, mode, **_open_kwargs(mode, encoding, errors))
    except OSError as e:
        raise FileError(format_filename(filename), f"Could not open file '{format_filename(filename)}': {e.strerror}") from e
