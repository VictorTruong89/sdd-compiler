"""In-process runner: ``optlyn.testing.CliRunner`` (section 9, FP-14)."""

import contextlib
import io
import os
import shutil
import sys
import tempfile



class _Shared:
    """Byte sink shared by stdout and stderr so that output keeps write order."""

    def __init__(self):
        self.data = io.BytesIO()


class _CaptureBinary:
    def __init__(self, stream):
        self._stream = stream

    def write(self, data):
        self._stream._write_bytes(bytes(data))
        return len(data)

    def flush(self):
        pass

    def isatty(self):
        return False


class _CaptureStream(io.TextIOBase):
    """Text stream recording writes into its own buffer and the shared buffer."""

    def __init__(self, shared, charset, errors="strict"):
        super().__init__()
        self._shared = shared
        self._own = io.BytesIO()
        self._charset = charset
        self.buffer = _CaptureBinary(self)

    @property
    def encoding(self):
        return self._charset

    @property
    def errors(self):
        return "strict"

    def _write_bytes(self, data):
        self._own.write(data)
        self._shared.data.write(data)

    def write(self, text):
        if isinstance(text, bytes):
            self._write_bytes(text)
            return len(text)
        self._write_bytes(text.encode(self._charset, "backslashreplace"))
        return len(text)

    def writable(self):
        return True

    def readable(self):
        return False

    def isatty(self):
        return False

    def getvalue(self):
        return self._own.getvalue()


class _CliInput(io.StringIO):
    """Standard input for an invocation; optionally echoes what is read (echo_stdin)."""

    def __init__(self, data, echo_to=None):
        super().__init__(data)
        self._echo_to = echo_to
        self._optlyn_self_echo = echo_to is not None

    def readline(self, size=-1):
        line = super().readline(size)
        if line and self._echo_to is not None:
            self._echo_to(line)
        return line

    def isatty(self):
        return False


class Result:
    """Outcome of one invocation."""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code,
                 exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code!r}>"


class CliRunner:
    """Invokes a command in-process with captured streams and exit status."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        """Swap the standard streams and environment for one invocation.

        Yields ``(stdout, stderr, collect)``; ``collect()`` returns
        ``(stdout_bytes, stderr_bytes, output_bytes)`` once the block has run.
        """
        if input is None:
            data = ""
        elif isinstance(input, bytes):
            data = input.decode(self.charset)
        else:
            data = input

        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {}
        for key, value in merged_env.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        if self.capture == "fd":
            stdout, stderr, collect, restore = self._fd_streams()
        else:
            stdout, stderr, collect, restore = self._sys_streams()
        stdin = _CliInput(data, echo_to=(stdout.write if self.echo_stdin else None))

        saved = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield stdout, stderr, collect
        finally:
            sys.stdin, sys.stdout, sys.stderr = saved
            restore()
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def _sys_streams(self):
        shared = _Shared()
        stdout = _CaptureStream(shared, self.charset)
        stderr = _CaptureStream(shared, self.charset)

        def collect():
            return stdout.getvalue(), stderr.getvalue(), shared.data.getvalue()

        return stdout, stderr, collect, lambda: None

    def _fd_streams(self):
        """Interpreter streams with real descriptors; OS writes to 1 and 2 are captured too."""
        out_file = tempfile.TemporaryFile()
        err_file = tempfile.TemporaryFile()
        sys.stdout.flush()
        sys.stderr.flush()
        saved_fds = (os.dup(1), os.dup(2))
        os.dup2(out_file.fileno(), 1)
        os.dup2(err_file.fileno(), 2)
        stdout = io.TextIOWrapper(out_file, encoding=self.charset, write_through=True)
        stderr = io.TextIOWrapper(err_file, encoding=self.charset, write_through=True)

        def collect():
            stdout.flush()
            stderr.flush()
            out_file.seek(0)
            err_file.seek(0)
            out_bytes, err_bytes = out_file.read(), err_file.read()
            return out_bytes, err_bytes, out_bytes + err_bytes

        def restore():
            os.dup2(saved_fds[0], 1)
            os.dup2(saved_fds[1], 2)
            os.close(saved_fds[0])
            os.close(saved_fds[1])
            stdout.detach()
            stderr.detach()
            out_file.close()
            err_file.close()

        return stdout, stderr, collect, restore

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        """Run ``cli`` with the argument tokens ``args`` and capture the outcome."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        prog_name = extra.pop("prog_name", None) or getattr(cli, "name", None) or "root"
        if isinstance(args, str):
            args = args.split()
        extra.setdefault("color", color)
        exit_code = 0
        exception = None
        exc_info = None
        return_value = None
        with self.isolation(input=input, env=env, color=color) as (stdout, stderr, collect):
            try:
                return_value = cli.main(args=list(args or []), prog_name=prog_name, **extra)
            except SystemExit as e:
                code = e.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    print(code, file=sys.stderr)
                    exit_code = 1
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            stdout_bytes, stderr_bytes, output_bytes = collect()
        return Result(
            self,
            stdout_bytes=stdout_bytes,
            stderr_bytes=stderr_bytes,
            output_bytes=output_bytes,
            return_value=return_value,
            exit_code=exit_code,
            exception=exception,
            exc_info=exc_info,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Run inside a new empty working directory (FP-14).

        Without ``temp_dir`` the directory is removed on exit. With ``temp_dir``
        the new directory is created under it and left in place.
        """
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(path, ignore_errors=True)
