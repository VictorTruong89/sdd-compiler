"""Tokenizer for option tokens (FP-01, FP-03, FP-04).

The parser consumes option tokens and option values. Everything else is a
positional token and is returned, in order, as the leftovers. Each leftover is
a ``(token, option_shaped)`` pair; ``option_shaped`` is true for a leading-prefix
token that did not come after ``--``.
"""

from .exceptions import BadOptionUsage, NoSuchOption


class _Prompt:
    """Marks an option occurrence that had no value and should prompt (FP-08)."""

    def __repr__(self):
        return "<prompt>"


PROMPT = _Prompt()


class OptionParser:
    def __init__(self, options, allow_interspersed_args=True, ignore_unknown_options=False,
                 normalize=None, positional_limit=0, is_group=False):
        self.allow_interspersed_args = allow_interspersed_args
        self.ignore_unknown_options = ignore_unknown_options
        # Positional tokens before the subcommand name (a group's own arguments).
        self.positional_limit = positional_limit
        self.is_group = is_group
        self.normalize = normalize or (lambda s: s)
        self._ignore_now = ignore_unknown_options
        self._flags = {}
        self._prefixes = {"-"}
        for option in options:
            for flag in option.all_flags():
                self._flags[self.normalize(flag)] = (option, flag)
                self._prefixes.add(flag[0])

    # -- classification -------------------------------------------------

    def is_option_like(self, token):
        return bool(token) and token[0] in self._prefixes and token != "-" and token != "--"

    def _lookup(self, name):
        return self._flags.get(self.normalize(name))

    # -- main loop -------------------------------------------------------

    def parse(self, args):
        """Return ``(occurrences, leftovers)``.

        ``occurrences`` maps each option to the list of its raw occurrences, in
        command-line order. ``leftovers`` is a list of ``(token, option_shaped)``.
        """
        self.occurrences = {}
        self.first_seen = {}
        self._counter = 0
        leftovers = []
        i = 0
        n = len(args)
        stop = False
        positionals = 0
        while i < n:
            token = args[i]
            i += 1
            if stop:
                leftovers.append((token, False))
                continue
            if token == "--":
                stop = True
                continue
            if self._lookup(token) is not None:
                i = self._take_flag_token(token, args, i, leftovers)
                continue
            if self.is_option_like(token):
                # Past the subcommand name, with mixing enabled, unknown options
                # belong to the subcommand and are passed through.
                past_subcommand = self.is_group and positionals > self.positional_limit
                self._ignore_now = self.ignore_unknown_options or past_subcommand
                i = self._take_option_token(token, args, i, leftovers)
                self._ignore_now = self.ignore_unknown_options
                continue
            leftovers.append((token, False))
            positionals += 1
            if not self.allow_interspersed_args and positionals > self.positional_limit:
                stop = True
        return self.occurrences, leftovers

    def _record(self, option, value):
        self._counter += 1
        self.first_seen.setdefault(option, self._counter)
        self.occurrences.setdefault(option, []).append(value)

    def _take_flag_token(self, token, args, i, leftovers):
        option, flag = self._lookup(token)
        if option.takes_value():
            return self._take_value(option, flag, args, i, None)
        self._record(option, option.flag_value_for(flag))
        return i

    def _take_option_token(self, token, args, i, leftovers):
        if token[1:2] == token[0:1] and len(token) > 2:
            # long option, possibly with "=value"
            name, eq, rest = token.partition("=")
            found = self._lookup(name)
            if found is None:
                if self._ignore_now:
                    leftovers.append((token, False))
                    return i
                raise NoSuchOption(name)
            option, flag = found
            if option.takes_value():
                return self._take_value(option, flag, args, i, rest if eq else None)
            if eq:
                raise BadOptionUsage(f"Option '{flag}' does not take a value.")
            self._record(option, option.flag_value_for(flag))
            return i
        # short option stack: "-abc" is "-a -b -c"; a value may follow the flag
        prefix = token[0]
        chars = token[1:]
        j = 0
        while j < len(chars):
            flag = prefix + chars[j]
            found = self._lookup(flag)
            if found is None:
                if self._ignore_now:
                    leftovers.append((prefix + chars[j:], False))
                    return i
                raise NoSuchOption(flag)
            option, real_flag = found
            if option.takes_value():
                rest = chars[j + 1:]
                return self._take_value(option, real_flag, args, i, rest or None)
            self._record(option, option.flag_value_for(real_flag))
            j += 1
        return i

    def _take_value(self, option, flag, args, i, inline):
        """Consume the value (or values) of an option occurrence."""
        arity = option.occurrence_arity()
        if inline is not None:
            if arity == 1:
                self._record(option, inline)
                return i
            tokens = [inline]
        else:
            tokens = []
        if option.is_optional_value and inline is None:
            if i < len(args) and not self.is_option_like(args[i]):
                self._record(option, args[i])
                return i + 1
            self._record(option, option.flag_value)
            return i
        needed = arity - len(tokens)
        available = args[i:i + needed]
        if len(available) < needed:
            if option.prompt:
                self._record(option, PROMPT)
                return i + len(available)
            if arity == 1:
                raise BadOptionUsage(f"Option '{flag}' requires an argument.")
            raise BadOptionUsage(f"Option '{flag}' requires {arity} arguments.")
        tokens.extend(available)
        i += len(available)
        if arity == 1:
            self._record(option, tokens[0])
        else:
            self._record(option, tuple(tokens))
        return i
