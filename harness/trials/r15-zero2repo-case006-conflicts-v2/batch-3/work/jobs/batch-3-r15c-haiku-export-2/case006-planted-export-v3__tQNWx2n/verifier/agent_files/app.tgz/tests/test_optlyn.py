"""Behavioural tests for Optlyn. Names cite the spec ids they exercise (see NOTES.md)."""

import enum
import os
import pathlib
import uuid

import pytest

import optlyn as o
from optlyn.formatting import wrap_text
from optlyn.testing import CliRunner

runner = CliRunner()


def invoke(cli, args=(), **kwargs):
    kwargs.setdefault("prog_name", "tool")
    return runner.invoke(cli, list(args), **kwargs)


# ---------------------------------------------------------------- FP-01 / FP-13

def test_command_name_derivation_and_run():  # spec: FP-01 naming
    @o.command()
    def sync_data_cmd():
        o.echo("synced")

    assert sync_data_cmd.name == "sync-data"
    res = invoke(sync_data_cmd)
    assert res.exit_code == 0 and res.output == "synced\n"


def test_explicit_name_only_accepts_that_name():  # spec: FP-01 explicit name
    @o.group()
    def grp():
        pass

    @grp.command("go")
    def run_it():
        o.echo("ran")

    assert invoke(grp, ["go"]).output == "ran\n"
    assert invoke(grp, ["run-it"]).exit_code == 2


def test_unknown_option_is_usage_error_and_skips_callback():  # spec: FP-03/FP-13
    calls = []

    @o.command()
    def cmd():
        calls.append(1)

    res = invoke(cmd, ["--nope"])
    assert res.exit_code == 2 and calls == []
    assert "No such option" in res.output


def test_author_clean_stop_status():  # spec: FP-13 author clean stop
    @o.command()
    def stop():
        o.get_current_context().exit(4)
        o.echo("never")

    res = invoke(stop)
    assert res.exit_code == 4 and "never" not in res.output


def test_abort_exit_status_and_message():  # spec: FP-13 abort
    @o.command()
    def boom():
        raise o.Abort()

    res = invoke(boom)
    assert res.exit_code == 1 and "Aborted!" in res.stderr


def test_standalone_off_propagates_and_returns():  # spec: FP-01 standalone off
    @o.command()
    @o.option("--n", type=int, default=2)
    def twice(n):
        return n * 2

    assert twice.main(["--n", "4"], standalone_mode=False) == 8
    with pytest.raises(o.BadParameter):
        twice.main(["--n", "x"], standalone_mode=False)


def test_deprecated_command_still_runs_and_warns():  # spec: FP-01 deprecated
    @o.command(deprecated="use new")
    def old():
        o.echo("body")

    res = invoke(old)
    assert res.exit_code == 0
    assert res.output.index("deprecated") < res.output.index("body")
    assert "use new" in res.output


# ---------------------------------------------------------------- FP-02 help

def test_AC_help_skips_callback_and_exits_zero():  # spec: FP-02 help
    ran = []

    @o.command()
    @o.option("--count", type=int, help="How many times.")
    def cmd(count):
        """Do the thing.

        Long description.
        """
        ran.append(1)

    res = invoke(cmd, ["--help"])
    assert res.exit_code == 0 and ran == []
    assert "Usage: tool [OPTIONS]" in res.stdout
    assert "Do the thing." in res.stdout
    assert "--count INTEGER" in res.stdout and "How many times." in res.stdout


def test_form_feed_truncates_help():  # spec: FP-02 form feed
    @o.command(help="Visible.\fHidden part.")
    def cmd():
        pass

    out = invoke(cmd, ["--help"]).stdout
    assert "Visible." in out and "Hidden" not in out and "\f" not in out


def test_no_args_group_is_usage_failure_with_help():  # spec: FP-02 / FP-06
    @o.group()
    def grp():
        """Group help."""

    res = invoke(grp)
    assert res.exit_code == 2
    assert "Group help." in res.output and "Commands" not in res.output or "Group help." in res.output


def test_missing_subcommand_with_options_only_reports_missing_command():  # spec: FP-06
    @o.group()
    @o.option("--flag", is_flag=True)
    def grp(flag):
        pass

    @grp.command()
    def leaf():
        pass

    res = invoke(grp, ["--flag"])
    assert res.exit_code == 2 and "Missing command." in res.output


def test_help_option_names_can_be_overridden():  # spec: FP-02 help option names
    @o.command()
    def cmd():
        pass

    res = invoke(cmd, ["-h"], help_option_names=["-h"])
    assert res.exit_code == 0 and "Usage:" in res.stdout
    assert invoke(cmd, ["--help"], help_option_names=["-h"]).exit_code == 2


def test_version_option_is_eager_and_exact():  # spec: FP-02 version
    @o.command()
    @o.version_option("9.9", prog_name="tool")
    @o.option("--req", required=True)
    def cmd(req):
        pass

    res = invoke(cmd, ["--version"])
    assert res.exit_code == 0 and res.stdout == "tool, version 9.9\n"


def test_custom_version_option_prints_exactly_callback_value():  # spec: FP-02 custom version
    @o.command()
    @o.custom_version_option(lambda ctx: "build 42")
    def cmd():
        pass

    assert invoke(cmd, ["--version"]).stdout == "build 42\n"


def test_show_default_and_env_var_in_help():  # spec: FP-02 show-default
    @o.command()
    @o.option("--level", default=3, show_default=True)
    @o.option("--path", envvar="P_PATH", show_envvar=True)
    @o.option("--fl", is_flag=True, default=False, show_default=True)
    def cmd(level, path, fl):
        pass

    out = invoke(cmd, ["--help"]).stdout
    assert "[default: 3]" in out and "[env var: P_PATH]" in out
    assert "[default: False]" not in out


def test_choice_help_lists_values():  # spec: FP-02 choice help
    @o.command()
    @o.option("--mode", type=o.Choice(["fast", "slow"]))
    def cmd(mode):
        pass

    assert "[fast, slow]" in invoke(cmd, ["--help"]).stdout


def test_hidden_option_not_in_help_but_accepted():  # spec: FP-02 hidden
    @o.command()
    @o.option("--secret", hidden=True)
    def cmd(secret):
        o.echo(secret)

    res = invoke(cmd, ["--help"])
    assert "--secret" not in res.stdout
    assert invoke(cmd, ["--secret", "x"]).output == "x\n"


def test_wrap_text_keeps_backspace_paragraphs():  # spec: FP-02 backspace paragraph
    text = "\b\nline one\nline two\n\nlong paragraph " + "word " * 30
    out = wrap_text(text, width=40)
    assert "line one\nline two" in out
    assert "\b" not in out


# ---------------------------------------------------------------- FP-03 options

def test_option_forms_and_stacking():  # spec: FP-03 short stacking / attached values
    @o.command()
    @o.option("-a", is_flag=True)
    @o.option("-b", is_flag=True)
    @o.option("-n", type=int)
    def cmd(a, b, n):
        o.echo(f"{a} {b} {n}")

    assert invoke(cmd, ["-ab", "-n5"]).output == "True True 5\n"
    assert invoke(cmd, ["-n", "7"]).output == "False False 7\n"
    assert invoke(cmd, ["--", "-a"]).exit_code == 2


def test_long_option_equals_form():  # spec: FP-03 long options
    @o.command()
    @o.option("--name")
    def cmd(name):
        o.echo(name)

    assert invoke(cmd, ["--name=ann"]).output == "ann\n"
    assert invoke(cmd, ["--name", "bob"]).output == "bob\n"


def test_feature_switch_and_pairs():  # spec: FP-03 on/off pairs
    @o.command()
    @o.option("--shout/--whisper", default=True)
    def cmd(shout):
        o.echo(shout)

    assert invoke(cmd, ["--whisper"]).output == "False\n"
    assert invoke(cmd, []).output == "True\n"


def test_counting_and_repeatable_and_tuple_options():  # spec: FP-03 count/multiple/nargs
    @o.command()
    @o.option("-v", count=True)
    @o.option("--tag", multiple=True)
    @o.option("--pair", nargs=2, type=int)
    def cmd(v, tag, pair):
        o.echo(f"{v}|{tag}|{pair}")

    assert invoke(cmd, ["-vvv", "--tag", "a", "--tag", "b", "--pair", "1", "2"]).output == "3|('a', 'b')|(1, 2)\n"
    assert invoke(cmd, []).output == "0|()|None\n"


def test_missing_option_value_is_usage_error():  # spec: FP-03 missing value
    @o.command()
    @o.option("--name")
    def cmd(name):
        pass

    res = invoke(cmd, ["--name"])
    assert res.exit_code == 2 and "requires an argument" in res.output


def test_bare_string_default_on_repeatable_is_usage_error():  # spec: FP-03 sequence default
    @o.command()
    @o.option("--tag", multiple=True, default="abc")
    def cmd(tag):
        pass

    res = invoke(cmd, [])
    assert res.exit_code == 2 and "iterable" in res.output


def test_deprecated_option_refuses_required_at_declaration():  # spec: FP-03 deprecated+required
    with pytest.raises(TypeError):
        o.Option(["--x"], deprecated=True, required=True)


def test_boolean_env_values():  # spec: FP-03 env booleans
    @o.command()
    @o.option("--on", is_flag=True, envvar="ON_FLAG")
    def cmd(on):
        o.echo(on)

    assert invoke(cmd, [], env={"ON_FLAG": " YES "}).output == "True\n"
    assert invoke(cmd, [], env={"ON_FLAG": "off"}).output == "False\n"
    assert invoke(cmd, [], env={"ON_FLAG": "   "}).output == "False\n"
    assert invoke(cmd, [], env={"ON_FLAG": "maybe"}).exit_code == 2


def test_env_split_for_repeatable_and_first_set_wins():  # spec: FP-03 env lists
    @o.command()
    @o.option("--item", "-i", multiple=True, envvar=["FIRST_ITEMS", "SECOND_ITEMS"])
    def cmd(item):
        o.echo(repr(item))

    assert invoke(cmd, [], env={"FIRST_ITEMS": "a b", "SECOND_ITEMS": "z"}).output == "('a', 'b')\n"
    assert invoke(cmd, [], env={"FIRST_ITEMS": "", "SECOND_ITEMS": "z"}).output == "('z',)\n"


def test_value_source_precedence_and_inspection():  # spec: FP-03 / FP-07 sources
    seen = {}

    @o.command()
    @o.option("--a", default="d", envvar="A_ENV")
    @o.option("--b", default="d")
    @o.pass_context
    def cmd(ctx, a, b):
        for name in ("a", "b", "missing"):
            seen[name] = ctx.get_parameter_source(name)

    invoke(cmd, ["--b", "x"], env={"A_ENV": "e"}, default_map={"b": "m"})
    assert seen["a"].name == "ENVIRONMENT"
    assert seen["b"].name == "COMMANDLINE"
    assert seen["missing"] is None


def test_default_map_applies_and_loses_to_command_line():  # spec: FP-07 default map
    @o.group()
    def grp():
        pass

    @grp.command()
    @o.option("--size", type=int, default=1)
    def leaf(size):
        o.echo(size)

    assert invoke(grp, ["leaf"], default_map={"leaf": {"size": 5}}).output == "5\n"
    assert invoke(grp, ["leaf", "--size", "2"], default_map={"leaf": {"size": 5}}).output == "2\n"


def test_auto_envvar_prefix_includes_subcommand_names():  # spec: FP-07 auto env prefix
    @o.group()
    def grp():
        pass

    @grp.command("sub-one")
    @o.option("--port", type=int)
    def leaf(port):
        o.echo(port)

    res = invoke(grp, ["sub-one"], auto_envvar_prefix="my-app", env={"MY_APP_SUB_ONE_PORT": "8080"})
    assert res.output == "8080\n"


def test_callbacks_run_and_can_refuse():  # spec: FP-03 parameter callback
    def check(ctx, param, value):
        if value < 0:
            raise o.BadParameter("must be positive")
        return value * 10

    @o.command()
    @o.option("--n", type=int, default=1, callback=check)
    def cmd(n):
        o.echo(n)

    assert invoke(cmd, ["--n", "2"]).output == "20\n"
    res = invoke(cmd, ["--n", "-1"])
    assert res.exit_code == 2 and "must be positive" in res.output and "'--n'" in res.output


def test_eager_flag_wins_over_missing_required():  # spec: FP-02 / FP-03 eager
    @o.command()
    @o.option("--must", required=True)
    @o.help_option()
    def cmd(must):
        pass

    assert invoke(cmd, ["--help"]).exit_code == 0
    assert invoke(cmd, []).exit_code == 2


# ---------------------------------------------------------------- FP-04 arguments

def test_arguments_fixed_variadic_and_double_dash():  # spec: FP-04 arguments
    @o.command()
    @o.argument("first")
    @o.argument("rest", nargs=-1)
    def cmd(first, rest):
        o.echo(f"{first}|{rest}")

    assert invoke(cmd, ["a", "b", "c"]).output == "a|('b', 'c')\n"
    assert invoke(cmd, ["a", "--", "-x"]).output == "a|('-x',)\n"


def test_missing_required_argument_names_it():  # spec: FP-04 missing argument
    @o.command()
    @o.argument("src")
    def cmd(src):
        pass

    res = invoke(cmd, [])
    assert res.exit_code == 2 and "'SRC'" in res.output


def test_extra_arguments_rejected_by_default():  # spec: FP-04 extra tokens
    @o.command()
    @o.argument("one")
    def cmd(one):
        pass

    assert invoke(cmd, ["a", "b"]).exit_code == 2


def test_allow_extra_args_tolerates_plain_tokens():  # spec: FP-01 extra arguments
    @o.command(context_settings={"allow_extra_args": True})
    @o.argument("one")
    def cmd(one):
        o.echo(one)

    assert invoke(cmd, ["a", "b", "c"]).output == "a\n"
    assert invoke(cmd, ["a", "-z"]).exit_code == 2


def test_ignore_unknown_options_consumes_as_arguments():  # spec: FP-03 ignore unknown
    @o.command(context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
    @o.argument("items", nargs=-1)
    def cmd(items):
        o.echo(items)

    assert invoke(cmd, ["-q", "--zz"]).output == "('-q', '--zz')\n"


# ---------------------------------------------------------------- FP-05 types

def test_builtin_types_and_failures():  # spec: FP-05 conversion
    @o.command()
    @o.option("--f", type=o.FLOAT)
    @o.option("--b", type=o.BOOL)
    @o.option("--u", type=o.UUID)
    @o.option("--d", type=o.DateTime())
    def cmd(f, b, u, d):
        o.echo(f"{f} {b} {u} {d.year}")

    ok = invoke(cmd, ["--f", "1.5", "--b", "YES", "--u", str(uuid.UUID(int=1)), "--d", "2024-02-03"])
    assert ok.output == f"1.5 True {uuid.UUID(int=1)} 2024\n"
    assert invoke(cmd, ["--b", "maybe"]).exit_code == 2
    assert invoke(cmd, ["--d", "03/02/2024"]).exit_code == 2


def test_int_rejects_fraction_and_clamp_open_bound():  # spec: FP-05 integer range
    @o.command()
    @o.option("--n", type=o.INT)
    @o.option("--r", type=o.IntRange(1, 5, max_open=True, clamp=True))
    def cmd(n, r):
        o.echo(r)

    assert invoke(cmd, ["--n", "1.5"]).exit_code == 2
    assert invoke(cmd, ["--r", "9"]).output == "4\n"
    assert invoke(cmd, ["--r", "0"]).output == "1\n"


def test_float_range_clamp_with_open_bound_refused():  # spec: FP-05 float range clamp
    with pytest.raises(ValueError):
        o.FloatRange(0.0, 1.0, min_open=True, clamp=True)


def test_choice_enum_returns_member_and_case_folds():  # spec: FP-05 choice
    class Pick(enum.Enum):
        Alpha = 1

    @o.command()
    @o.option("--p", type=o.Choice(Pick, case_sensitive=False))
    def cmd(p):
        o.echo(repr(p))

    assert invoke(cmd, ["--p", "alpha"]).output == "<Pick.Alpha: 1>\n"


def test_tuple_type_option():  # spec: FP-03 tuple option
    @o.command()
    @o.option("--xy", type=o.Tuple([int, str]))
    def cmd(xy):
        o.echo(repr(xy))

    assert invoke(cmd, ["--xy", "3", "abc"]).output == "(3, 'abc')\n"


def test_custom_param_type_and_function_type():  # spec: FP-05 custom types
    class Upper(o.ParamType):
        name = "upper"

        def convert(self, value, param, ctx):
            if value.isdigit():
                self.fail("digits not allowed", param, ctx)
            return value.upper()

    def positive(text):
        value = int(text)
        if value < 1:
            raise ValueError("need positive")
        return value

    @o.command()
    @o.option("--u", type=Upper())
    @o.option("--p", type=positive)
    def cmd(u, p):
        o.echo(f"{u}{p}")

    assert invoke(cmd, ["--u", "ab", "--p", "3"]).output == "AB3\n"
    assert invoke(cmd, ["--u", "12"]).exit_code == 2
    assert invoke(cmd, ["--p", "0"]).exit_code == 2


# ---------------------------------------------------------------- FP-06 groups

def test_nested_groups_run_outside_in():  # spec: FP-06 nesting
    trace = []

    @o.group()
    def outer():
        trace.append("outer")

    @outer.group()
    def middle():
        trace.append("middle")

    @middle.command()
    def leaf():
        trace.append("leaf")

    assert invoke(outer, ["middle", "leaf"]).exit_code == 0
    assert trace == ["outer", "middle", "leaf"]


def test_nested_group_without_child_shows_its_own_help():  # spec: FP-06 nested help
    @o.group()
    def outer():
        pass

    @outer.group()
    def inner():
        """Inner help."""

    res = invoke(outer, ["inner"])
    assert res.exit_code == 2 and "Inner help." in res.output


def test_unknown_subcommand_does_not_run_group_callback():  # spec: FP-06 unknown
    trace = []

    @o.group()
    def grp():
        trace.append(1)

    res = invoke(grp, ["nope"])
    assert res.exit_code == 2 and trace == [] and "No such command 'nope'." in res.output


def test_group_callback_runs_before_child_and_group_help_skips_it():  # spec: FP-06 dispatch
    trace = []

    @o.group()
    def grp():
        trace.append("group")

    @grp.command()
    def child():
        trace.append("child")

    assert invoke(grp, ["child"]).exit_code == 0
    assert trace == ["group", "child"]
    trace.clear()
    assert invoke(grp, ["--help"]).exit_code == 0
    assert trace == []


def test_invoke_without_command_and_subcommand_context_flag():  # spec: FP-06 invoke_without_command
    seen = []

    @o.group(invoke_without_command=True)
    @o.pass_context
    def grp(ctx):
        seen.append(ctx.invoked_subcommand)

    @grp.command()
    def child():
        pass

    invoke(grp, [])
    invoke(grp, ["child"])
    assert seen == [None, "child"]


def test_command_collection_union():  # spec: FP-06 command collection
    @o.group()
    def a():
        pass

    @o.group()
    def b():
        pass

    @a.command()
    def one():
        o.echo("one")

    @b.command()
    def two():
        o.echo("two")

    union = o.group(cls=o.CommandCollection, sources=[a, b])(lambda: None)
    assert invoke(union, ["one"]).output == "one\n"
    assert invoke(union, ["two"]).output == "two\n"
    assert "one" in invoke(union, ["--help"]).stdout and "two" in invoke(union, ["--help"]).stdout


def test_hidden_command_reachable_but_not_listed():  # spec: FP-06 hidden
    @o.group()
    def grp():
        pass

    @grp.command(hidden=True)
    def secret():
        o.echo("here")

    assert "secret" not in invoke(grp, ["--help"]).stdout
    assert invoke(grp, ["secret"]).output == "here\n"


def test_group_cannot_nest_under_chain():  # spec: FP-10 refusal
    chain = o.Group("c", chain=True)
    with pytest.raises(TypeError):
        chain.add_command(o.Group("inner"))


# ---------------------------------------------------------------- FP-10 chaining

def test_chain_returns_list_and_standalone_off():  # spec: FP-10 chain return
    @o.group(chain=True)
    def pipe():
        pass

    @pipe.command()
    @o.argument("n", type=int)
    def inc(n):
        return n + 1

    @pipe.command()
    @o.argument("n", type=int)
    def dbl(n):
        return n * 2

    assert pipe.main(["inc", "1", "dbl", "5"], standalone_mode=False) == [2, 10]


def test_chain_empty_pipeline_runs_result_callback():  # spec: FP-10 empty pipeline
    @o.group(chain=True, invoke_without_command=True)
    def pipe():
        pass

    @pipe.result_callback()
    def finish(values):
        o.echo(f"values={values}")

    assert invoke(pipe, []).output == "values=[]\n"


# ---------------------------------------------------------------- FP-08 prompts

def test_prompt_uses_input_and_reasks_on_bad_value():  # spec: FP-08 prompt
    @o.command()
    @o.option("--n", prompt=True, type=int)
    def cmd(n):
        o.echo(n)

    assert invoke(cmd, [], input="abc\n4\n").output.endswith("4\n")


def test_prompt_not_read_when_supplied():  # spec: FP-08 command line skips prompt
    @o.command()
    @o.option("--n", prompt=True)
    def cmd(n):
        o.echo(n)

    res = invoke(cmd, ["--n", "x"], input="never\n")
    assert res.output == "x\n"


def test_standalone_prompt_and_confirm():  # spec: FP-08 standalone helpers
    @o.command()
    def cmd():
        o.echo(o.prompt("Name", default="anon"))
        o.echo(o.confirm("Go?", default=True))

    res = invoke(cmd, [], input="\nn\n")
    assert res.output.splitlines()[-2:] == ["Go? [Y/n]: n", "False"]
    assert "anon" in res.output.splitlines()


def test_confirm_eof_is_abort():  # spec: FP-08 eof
    @o.command()
    def cmd():
        o.confirm("Really?")

    assert invoke(cmd, [], input="").exit_code == 1


# ---------------------------------------------------------------- FP-09 files and paths

def test_file_type_reads_and_missing_read_is_usage_error(tmp_path):  # spec: FP-09 read
    target = tmp_path / "in.txt"
    target.write_text("hello")

    @o.command()
    @o.argument("src", type=o.File("r"))
    def cmd(src):
        o.echo(src.read())

    assert invoke(cmd, [str(target)]).output == "hello\n"
    res = invoke(cmd, [str(tmp_path / "nope.txt")])
    assert res.exit_code == 2 and "nope.txt" in res.output


def test_lazy_write_not_truncated_until_used(tmp_path):  # spec: FP-09 lazy write
    target = tmp_path / "out.txt"
    target.write_text("keep")

    @o.command()
    @o.argument("dst", type=o.File("w"))
    def cmd(dst):
        pass

    invoke(cmd, [str(target)])
    assert target.read_text() == "keep"


def test_write_and_dash_stdout(tmp_path):  # spec: FP-09 write / dash
    target = tmp_path / "w.txt"

    @o.command()
    @o.argument("dst", type=o.File("w"))
    def cmd(dst):
        dst.write("data")

    invoke(cmd, [str(target)])
    assert target.read_text() == "data"

    @o.command()
    @o.argument("dst", type=o.File("w"))
    def dash(dst):
        dst.write("to stdout\n")

    assert invoke(dash, ["-"]).output == "to stdout\n"


def test_atomic_write_replaces_on_close(tmp_path):  # spec: FP-09 atomic
    target = tmp_path / "a.txt"
    target.write_text("old")
    f = o.open_file(str(target), "w", atomic=True)
    f.write("new")
    assert target.read_text() == "old"
    f.close()
    assert target.read_text() == "new"


def test_path_checks(tmp_path):  # spec: FP-09 path checks
    sub = tmp_path / "d"
    sub.mkdir()
    (tmp_path / "f.txt").write_text("x")

    @o.command()
    @o.argument("p", type=o.Path(exists=True, dir_okay=False))
    def cmd(p):
        o.echo(type(p).__name__)

    assert invoke(cmd, [str(tmp_path / "f.txt")]).output == "str\n"
    assert invoke(cmd, [str(sub)]).exit_code == 2
    assert invoke(cmd, [str(tmp_path / "missing")]).exit_code == 2


def test_path_path_type_delivers_pathlib(tmp_path):  # spec: FP-09 path object
    @o.command()
    @o.argument("p", type=o.Path(path_type=pathlib.Path))
    def cmd(p):
        o.echo(type(p).__name__)

    assert invoke(cmd, [str(tmp_path)]).output == "PosixPath\n"


def test_format_filename_non_unicode_is_printable():  # spec: FP-09 filename formatting
    text = o.format_filename(b"caf\xff.txt")
    text.encode("utf-8")
    assert text != o.format_filename(b"caf\xfe.txt")
    assert o.format_filename("plain.txt", shorten=True) == "plain.txt"


# ---------------------------------------------------------------- FP-11 terminal helpers

def test_echo_strips_styles_off_terminal_and_forced_color_keeps():  # spec: FP-11 echo
    @o.command()
    def cmd():
        o.echo(o.style("hi", fg="red"))

    assert invoke(cmd, []).stdout == "hi\n"
    assert invoke(cmd, [], color=True).stdout == "\x1b[31mhi\x1b[0m\n"


def test_style_colors_and_switches():  # spec: FP-11 style
    assert o.style("x", fg="red") != o.style("x", bg="red")
    assert o.style("x", fg=200) != o.style("x", fg=[1, 2, 3])
    assert o.style("x", bold=True) != o.style("x", italic=True)
    assert o.style("x", bold=True, italic=True) not in (o.style("x", bold=True), o.style("x", italic=True))
    assert o.unstyle(o.style("x", fg="green", underline=True)) == "x"
    with pytest.raises(TypeError):
        o.style("x", fg="chartreuse")
    with pytest.raises(TypeError):
        o.style("x", fg=300)


def test_secho_styles_and_err_channel():  # spec: FP-11 secho / channels
    @o.command()
    def cmd():
        o.secho("warn", fg="yellow", err=True)

    res = invoke(cmd, [], color=True)
    assert "\x1b[33mwarn" in res.stderr and res.stdout == ""


def test_progressbar_visits_every_item_without_terminal():  # spec: FP-11 progress
    @o.command()
    def cmd():
        with o.progressbar([1, 2, 3], label="work") as bar:
            seen = [item for item in bar]
        o.echo(seen)

    res = invoke(cmd, [])
    assert res.stdout.endswith("[1, 2, 3]\n") and "work" in res.stdout


def test_hidden_progressbar_prints_nothing():  # spec: FP-11 hidden bar
    @o.command()
    def cmd():
        with o.progressbar(range(2), label="quiet", hidden=True) as bar:
            list(bar)

    assert invoke(cmd, []).stdout == ""


def test_get_app_dir_unix_rules(monkeypatch, tmp_path):  # spec: FP-11 app dir
    import sys

    monkeypatch.setattr(sys, "platform", "linux")
    monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path))
    assert o.get_app_dir("My  App") == str(tmp_path / "my-app")
    assert o.get_app_dir("My App", force_posix=True).endswith("/.my-app")


def test_open_file_dash_does_not_close_stdout():  # spec: FP-11 stdout stays open
    @o.command()
    def cmd():
        with o.open_file("-", "w") as stream:
            stream.write("first\n")
        o.echo("after")

    assert invoke(cmd, []).stdout == "first\nafter\n"


def test_clear_no_terminal_is_noop():  # spec: FP-11 clear
    @o.command()
    def cmd():
        o.clear()

    assert invoke(cmd, []).stdout == ""


def test_pager_non_interactive_writes_stdout(monkeypatch):  # spec: FP-11 pager
    monkeypatch.setenv("PAGER", "false")

    @o.command()
    def cmd():
        o.echo_via_pager(iter(["a\n", "b\n"]))

    assert invoke(cmd, []).stdout == "a\nb\n"


# ---------------------------------------------------------------- FP-12 completion

def _complete(cli, words, cword=None, shell="bash"):
    line = " ".join(words)
    env = {"COMP_WORDS": line, "COMP_CWORD": str(len(words) - 1 if cword is None else cword)}
    if shell == "fish":
        env["COMP_CWORD"] = words[-1]
    env["_TOOL_COMPLETE"] = f"{shell}_complete"
    return runner.invoke(cli, [], prog_name="tool", env=env)


def test_bash_source_script_and_no_callback():  # spec: FP-12 source mode
    ran = []

    @o.command()
    def cli():
        ran.append(1)

    res = runner.invoke(cli, [], prog_name="tool", env={"_TOOL_COMPLETE": "bash_source"})
    assert res.exit_code == 0 and "complete -o default -F" in res.stdout and ran == []


def test_complete_suggests_commands_and_options():  # spec: FP-12 complete
    @o.group()
    def cli():
        pass

    @cli.command()
    def build():
        pass

    @cli.command()
    @o.option("--force", is_flag=True, help="Force it.")
    @o.option("--fast", is_flag=True)
    def deploy(force, fast):
        pass

    assert "build" in _complete(cli, ["tool", ""]).stdout
    opts = _complete(cli, ["tool", "deploy", "--f"]).stdout.split()
    assert opts == ["--force", "--fast"]
    assert _complete(cli, ["tool", "deploy", ""]).stdout == ""


def test_complete_choice_and_path_requests():  # spec: FP-12 choice/path
    @o.command()
    @o.option("--mode", type=o.Choice(["alpha", "beta", "gamma"]))
    @o.argument("out", type=o.Path(file_okay=False))
    def cmd(mode, out):
        pass

    assert _complete(cmd, ["tool", "--mode", "b"]).stdout.split() == ["beta"]
    assert _complete(cmd, ["tool", "--mode", "x"]).stdout == ""
    assert _complete(cmd, ["tool", ""]).stdout.strip() == "@@dir@@"


def test_unknown_completion_instruction_prints_nothing():  # spec: FP-12 unknown instruction
    @o.command()
    def cmd():
        o.echo("ran")

    res = runner.invoke(cmd, [], prog_name="tool", env={"_TOOL_COMPLETE": "tcsh_source"})
    assert res.stdout == "" and "ran" not in res.stdout


# ---------------------------------------------------------------- FP-14 runner

def test_runner_captures_stdout_stderr_and_exception():  # spec: FP-14 result
    @o.command()
    def cmd():
        o.echo("out")
        o.echo("err", err=True)

    res = invoke(cmd, [])
    assert res.stdout == "out\n" and res.stderr == "err\n" and res.output == "out\nerr\n"
    assert res.stdout_bytes == b"out\n"

    @o.command()
    def bad():
        raise RuntimeError("kaboom")

    res = invoke(bad, [])
    assert res.exit_code == 1 and isinstance(res.exception, RuntimeError)
    with pytest.raises(RuntimeError):
        invoke(bad, [], catch_exceptions=False)


def test_runner_input_is_consumed_and_prompt_echoed():  # spec: FP-14 input echo
    @o.command()
    def cmd():
        o.echo(o.prompt("Q"))

    res = invoke(cmd, [], input="typed\n")
    assert "Q: typed" in res.output


def test_runner_env_applies_to_one_invoke_only():  # spec: FP-14 env scope
    @o.command()
    def cmd():
        o.echo(os.environ.get("ONE_OFF", "unset"))

    assert invoke(cmd, [], env={"ONE_OFF": "yes"}).output == "yes\n"
    assert invoke(cmd, []).output == "unset\n"


def test_isolated_filesystem_creates_and_restores_cwd(tmp_path):  # spec: FP-14 isolated fs
    before = os.getcwd()
    with runner.isolated_filesystem(temp_dir=str(tmp_path)) as path:
        assert os.getcwd() == path
        pathlib.Path("note.txt").write_text("x")
        assert (tmp_path / os.path.basename(path) / "note.txt").exists()
    assert os.getcwd() == before
    assert (tmp_path / os.path.basename(path) / "note.txt").exists()


def test_file_command_inside_isolated_fs():  # spec: FP-14 files written in sandbox
    @o.command()
    @o.argument("dst", type=o.File("w"))
    def cmd(dst):
        dst.write("made")

    with runner.isolated_filesystem():
        assert invoke(cmd, ["out.txt"]).exit_code == 0
        assert pathlib.Path("out.txt").read_text() == "made"


# ---------------------------------------------------------------- FP-07 context

def test_context_objects_nearest_wins_and_ensure():  # spec: FP-07 author objects
    class Config:
        pass

    @o.group()
    @o.pass_context
    def root(ctx):
        ctx.obj = Config()

    @root.command()
    @o.make_pass_decorator(Config, ensure=True)
    def leaf(cfg):
        o.echo("has config" if isinstance(cfg, Config) else "no")

    assert invoke(root, ["leaf"]).output == "has config\n"

    class Other:
        pass

    @o.command()
    @o.make_pass_decorator(Config, ensure=True)
    def standalone(cfg):
        o.echo(type(cfg).__name__)

    assert invoke(standalone, []).output == "Config\n"


def test_invoke_and_forward_values():  # spec: FP-07 invoke / forward
    @o.command()
    @o.option("--a", type=int, default=0)
    @o.option("--b", type=int, default=0)
    def target(a, b):
        o.echo(f"{a},{b}")

    @o.command()
    @o.option("--a", type=int, default=1)
    @o.pass_context
    def source(ctx, a):
        ctx.invoke(target, a=7)
        ctx.forward(target)

    assert invoke(source, []).output == "7,0\n1,0\n"


def test_token_normalization_applies_to_names():  # spec: FP-07 normalize
    @o.group()
    def grp():
        pass

    @grp.command()
    @o.option("--Verbose", is_flag=True)
    def run(Verbose):
        o.echo(Verbose)

    res = invoke(grp, ["RUN", "--verbose"], token_normalize_func=str.lower)
    assert res.exit_code == 0 and res.output == "True\n"
    assert invoke(grp, ["RUN"]).exit_code == 2


def test_resource_closed_when_invocation_ends(tmp_path):  # spec: FP-07 resource cleanup
    closed = []

    class Res:
        def __enter__(self):
            return self

        def __exit__(self, *exc):
            closed.append(True)

    @o.group()
    @o.pass_context
    def grp(ctx):
        ctx.with_resource(Res())

    @grp.command()
    def child():
        raise o.Abort()

    invoke(grp, ["child"])
    assert closed == [True]


def test_default_map_source_is_reported():  # spec: FP-07 source inspection
    seen = {}

    @o.command()
    @o.option("--b", default="d")
    @o.option("--c", default="d")
    @o.pass_context
    def cmd(ctx, b, c):
        seen["b"] = ctx.get_parameter_source("b")
        seen["c"] = ctx.get_parameter_source("c")

    invoke(cmd, [], default_map={"b": "m"})
    assert seen["b"].name == "DEFAULT_MAP" and seen["c"].name == "DEFAULT"


def test_ascii_stream_echo_writes_utf8_bytes():  # spec: FP-11 ascii-only stream
    import io

    import optlyn.utils as u

    raw = io.BytesIO()
    stream = io.TextIOWrapper(raw, encoding="ascii", write_through=True)
    u.echo("caf\u00e9", file=stream)
    stream.flush()
    assert raw.getvalue() == "caf\u00e9\n".encode("utf-8")


def test_group_arguments_do_not_end_group_option_parsing():  # spec: FP-03 group options before subcommand
    @o.group()
    @o.argument("name")
    @o.option("--gopt")
    def grp(name, gopt):
        o.echo(f"{name}|{gopt}")

    @grp.command()
    @o.option("--sopt")
    def sub(sopt):
        o.echo(f"sub {sopt}")

    assert invoke(grp, ["bob", "--gopt", "g", "sub", "--sopt", "s"]).output == "bob|g\nsub s\n"


def test_mixing_on_group_delivers_group_option_after_subcommand():  # spec: FP-03 mixing enabled
    @o.group(context_settings={"allow_interspersed_args": True})
    @o.option("--gopt")
    def grp(gopt):
        o.echo(f"group {gopt}")

    @grp.command()
    @o.option("--sopt")
    def sub(sopt):
        o.echo(f"sub {sopt}")

    assert invoke(grp, ["sub", "--gopt", "G", "--sopt", "S"]).output == "group G\nsub S\n"


def test_optional_argument_defaults():  # spec: FP-04 optional arguments
    @o.command()
    @o.argument("x", default="dflt")
    @o.argument("y", required=False)
    def cmd(x, y):
        o.echo(f"{x}|{y}")

    assert invoke(cmd, []).output == "dflt|None\n"
    assert invoke(cmd, ["a"]).output == "a|None\n"


def test_optional_value_option_forms():  # spec: FP-03 optional value
    @o.command()
    @o.option("--opt", is_flag=False, flag_value="FLAG", default="DEF")
    def cmd(opt):
        o.echo(opt)

    assert invoke(cmd, []).output == "DEF\n"
    assert invoke(cmd, ["--opt"]).output == "FLAG\n"
    assert invoke(cmd, ["--opt", "given"]).output == "given\n"
