"""Exception classes and their exit statuses (FP-13)."""



def echo(*args, **kwargs):
    # Imported late: ``utils`` depends on this module for ``FileError``.
    from .utils import echo as _echo

    return _echo(*args, **kwargs)


class OptlynError(Exception):
    """General Optlyn error: exit status 1, error description on stderr."""

    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def show(self, file=None):
        echo(f"Error: {self.format_message()}", err=True)


class FileError(OptlynError):
    """A file could not be opened at first I/O (general error class)."""

    def __init__(self, filename, message=None):
        self.filename = filename
        super().__init__(message or f"Could not open file '{filename}'.")


class UsageError(OptlynError):
    """Incorrect usage: exit status 2, usage line and error on stderr."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self, file=None):
        ctx = self.ctx
        if ctx is not None:
            usage = ctx.get_usage()
            echo(usage, err=True)
            hint = ctx.get_help_option_hint()
            if hint:
                echo(hint, err=True)
            echo("", err=True)
        echo(f"Error: {self.format_message()}", err=True)


class BadParameter(UsageError):
    """A value was refused. ``param_hint`` names the parameter."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.param_hint is not None:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            return self.message
        return f"Invalid value for {hint}: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value from any source."""

    def __init__(self, message=None, ctx=None, param=None, param_hint=None):
        super().__init__(message or "", ctx=ctx, param=param, param_hint=param_hint)

    def format_message(self):
        if self.message:
            return self.message
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        kind = "option" if getattr(self.param, "param_type_name", "") == "option" else "argument"
        return f"Missing {kind} {hint}."


class NoSuchOption(UsageError):
    """An option token that the command does not declare."""

    def __init__(self, option_name, message=None, possibilities=None, ctx=None):
        self.option_name = option_name
        super().__init__(message or f"No such option: {option_name}", ctx)


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example a missing value)."""


class BadArgumentUsage(UsageError):
    """An argument was used incorrectly."""


class NoSuchCommand(UsageError):
    """An unknown subcommand name."""

    def __init__(self, name, ctx=None):
        self.command_name = name
        super().__init__(f"No such command '{name}'.", ctx)


class NoArgsHelp(UsageError):
    """Help shown because of incorrect usage (no-args-is-help paths)."""

    def __init__(self, ctx=None):
        super().__init__("", ctx)

    def show(self, file=None):
        if self.ctx is not None:
            echo(self.ctx.get_help(), err=True)


class Exit(OptlynError):
    """Author or intentional clean stop, carrying the exit status."""

    exit_code = 0

    def __init__(self, code=0):
        super().__init__("")
        self.exit_code = code


class Abort(OptlynError):
    """Abort: user declined, end of input, keyboard interrupt or author abort."""

    exit_code = 1

    def __init__(self, message="Aborted!"):
        super().__init__(message)

    def show(self, file=None):
        echo(self.message, err=True)
