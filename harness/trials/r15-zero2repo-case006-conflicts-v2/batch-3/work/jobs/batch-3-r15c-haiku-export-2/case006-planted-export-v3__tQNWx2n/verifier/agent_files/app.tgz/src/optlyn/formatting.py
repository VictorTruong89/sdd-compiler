"""Text wrapping and help-page layout helpers (FP-02, FP-11, section 2)."""

import re
import textwrap

_BLANK_LINE = re.compile(r"\n\s*\n")


def wrap_text(text, width=78, initial_indent="", subsequent_indent="", preserve_paragraphs=False):
    """Rewrap ``text`` to ``width`` columns.

    Single newlines inside a paragraph are not kept. A paragraph whose first line
    is only a backspace character keeps its line breaks, and that line is dropped.
    """
    if text is None:
        return ""
    out = []
    for paragraph in _BLANK_LINE.split(text.strip("\n")):
        lines = paragraph.split("\n")
        if lines and lines[0].strip() == "\b":
            kept = [line for line in lines[1:]]
            for k, line in enumerate(kept):
                prefix = initial_indent if (not out and k == 0) else subsequent_indent
                out.append(prefix + line.rstrip())
            out.append("")
            continue
        words = " ".join(line.strip() for line in lines).split()
        if not words:
            continue
        wrapper = textwrap.TextWrapper(
            width=max(width, 1),
            initial_indent=initial_indent if not out else subsequent_indent,
            subsequent_indent=subsequent_indent,
            break_long_words=False,
            break_on_hyphens=False,
        )
        out.append(wrapper.fill(" ".join(words)))
        out.append("")
    while out and out[-1] == "":
        out.pop()
    return "\n".join(out)


def strip_form_feed(text):
    """A form feed truncates a help text: the rest is omitted from the page."""
    if text is None:
        return None
    return text.split("\f", 1)[0]


def first_sentence(text):
    """The first sentence of a help text, on one line."""
    if not text:
        return ""
    flat = " ".join(text.split())
    match = re.search(r"[.!?](\s|$)", flat)
    if match:
        return flat[: match.start() + 1]
    return flat


def ellipsize(text, limit):
    if limit is None or len(text) <= limit:
        return text
    if limit <= 3:
        return text[:limit]
    return text[: limit - 3].rstrip() + "..."


def format_dl(rows, width, col_max=30, indent=2, col_spacing=2):
    """Lay out ``(first, second)`` rows as an indented two-column list."""
    if not rows:
        return []
    first_width = min(max(len(first) for first, _ in rows), col_max)
    lines = []
    text_width = max(width - indent - first_width - col_spacing, 20)
    for first, second in rows:
        pad = " " * indent
        if not second:
            lines.append(pad + first)
            continue
        wrapped = wrap_text(second, width=text_width).split("\n")
        continuation = " " * (indent + first_width + col_spacing)
        if len(first) <= first_width:
            lines.append(pad + first.ljust(first_width) + " " * col_spacing + wrapped[0])
        else:
            lines.append(pad + first)
            lines.append(continuation + wrapped[0])
        for extra in wrapped[1:]:
            lines.append(continuation + extra)
    return lines


def format_section(title, lines):
    """A titled block, followed by a blank line."""
    return [title + ":"] + list(lines) + [""]
