"""Thread-local bookkeeping shared by the terminal helpers and the core."""

import sys
import threading

_local = threading.local()


def _stack():
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def push_context(ctx):
    _stack().append(ctx)


def pop_context(ctx):
    stack = _stack()
    if stack and stack[-1] is ctx:
        stack.pop()
    elif ctx in stack:
        stack.remove(ctx)


def get_current_context(silent=False):
    """Return the context current on this thread (see FP-07 and section 6)."""
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active context.")


def current_color_flag():
    """Color flag of the current context, or ``None`` for autodetection."""
    ctx = get_current_context(silent=True)
    if ctx is None:
        return None
    return ctx.color


def is_tty(stream):
    try:
        return bool(stream is not None and stream.isatty())
    except (AttributeError, ValueError):
        return False


def is_interactive():
    """A session is interactive when stdin or stdout is a terminal (FP-11)."""
    return is_tty(sys.stdin) or is_tty(sys.stdout)


def should_strip_ansi(stream, color=None):
    """Decide whether styles are stripped before writing to ``stream``."""
    if color is None:
        color = current_color_flag()
    if color is not None:
        return not color
    return not is_tty(stream)
