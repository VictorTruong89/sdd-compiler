"""Contexts, parameters, commands and groups (FP-01 to FP-07, FP-10, FP-13)."""

import enum
import os
import shutil
import sys
from contextlib import ExitStack

from . import _state
from .exceptions import (
    Abort,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingParameter,
    NoArgsHelp,
    NoSuchCommand,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import (
    ellipsize,
    first_sentence,
    format_dl,
    format_section,
    strip_form_feed,
    wrap_text,
)
from .paramtypes import BOOL, INT, Choice, File, Path, Tuple, convert_type
from .parser import PROMPT, OptionParser
from .utils import echo, make_str

_TRUE_TOKENS = {"1", "true", "t", "yes", "y", "on"}
_FALSE_TOKENS = {"0", "false", "f", "no", "n", "off"}
_NOTSET = object()


class ParameterSource(enum.Enum):
    """Where a parameter's value came from (FP-03, FP-07)."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


# Most explicit first (FP-03): prompt, command line, environment, default map, default.
_SOURCE_RANK = {
    ParameterSource.PROMPT: 5,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.ENVIRONMENT: 3,
    ParameterSource.DEFAULT_MAP: 2,
    ParameterSource.DEFAULT: 1,
}

_INHERITED = (
    "auto_envvar_prefix",
    "terminal_width",
    "max_content_width",
    "help_option_names",
    "token_normalize_func",
    "color",
    "show_default",
)


def _warn_deprecated(kind, name, note):
    message = f"DeprecationWarning: The {kind} '{name}' is deprecated."
    if note:
        message += " " + note
    echo(message, err=True)


def _help_width(ctx):
    if ctx.terminal_width is not None:
        return ctx.terminal_width
    detected = shutil.get_terminal_size((80, 24)).columns
    return min(detected, ctx.max_content_width)


class Context:
    """The state of one invocation of one command (section 6)."""

    def __init__(self, command, parent=None, info_name=None, obj=None, auto_envvar_prefix=None,
                 default_map=None, terminal_width=None, max_content_width=None,
                 help_option_names=None, token_normalize_func=None, color=None, show_default=None,
                 allow_extra_args=None, ignore_unknown_options=None, allow_interspersed_args=None,
                 resilient_parsing=False):
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.params = {}
        self._param_sources = {}
        self._param_ranks = {}
        self.protected_args = []
        self.args = []
        self.invoked_subcommand = None
        self.resilient_parsing = resilient_parsing
        self._exit_stack = ExitStack()

        values = {
            "auto_envvar_prefix": auto_envvar_prefix,
            "terminal_width": terminal_width,
            "max_content_width": max_content_width,
            "help_option_names": help_option_names,
            "token_normalize_func": token_normalize_func,
            "color": color,
            "show_default": show_default,
        }
        for key in _INHERITED:
            value = values[key]
            if value is None and parent is not None:
                value = getattr(parent, key)
            setattr(self, key, value)
        if self.max_content_width is None:
            self.max_content_width = 80
        if self.help_option_names is None:
            self.help_option_names = ["--help"]

        if default_map is None and parent is not None and isinstance(parent.default_map, dict):
            nested = parent.default_map.get(info_name)
            if isinstance(nested, dict):
                default_map = nested
        self.default_map = default_map

        self.ignore_unknown_options = bool(ignore_unknown_options) if ignore_unknown_options is not None else False
        self.allow_extra_args = (
            command.allow_extra_args if allow_extra_args is None else bool(allow_extra_args)
        )
        self.allow_interspersed_args = (
            command.allow_interspersed_args if allow_interspersed_args is None else bool(allow_interspersed_args)
        )

    # -- context manager: makes this context current on this thread -------

    def __enter__(self):
        _state.push_context(self)
        return self

    def __exit__(self, *exc):
        _state.pop_context(self)
        return False

    # -- tree helpers ---------------------------------------------------------

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    @property
    def command_path(self):
        parts = []
        node = self
        while node is not None:
            if node.info_name:
                parts.append(node.info_name)
            node = node.parent
        return " ".join(reversed(parts))

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    def auto_envvar_name(self, dest):
        """Environment name built from the prefix, subcommand names and destination (FP-07)."""
        parts = [dest]
        node = self
        while node is not None:
            if node.parent is not None and node.info_name:
                parts.append(node.info_name)
            node = node.parent
        parts.append(self.auto_envvar_prefix)
        parts.reverse()
        return "_".join(p.replace("-", "_") for p in parts).upper()

    # -- messages -------------------------------------------------------------

    def get_help(self):
        return self.command.get_help(self)

    def get_usage(self):
        return self.command.get_usage(self)

    def get_help_option_hint(self):
        names = [n for n in self.help_option_names if n.startswith("-")]
        if not names:
            return None
        return f"Try '{self.command_path} {names[0]}' for help."

    def fail(self, message):
        raise UsageError(message, ctx=self)

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    # -- values ---------------------------------------------------------------

    def lookup_default(self, name):
        if self.default_map and name in self.default_map:
            return self.default_map[name]
        return None

    def get_parameter_source(self, name):
        if not any(p.name == name for p in self.command.params):
            return None
        return self._param_sources.get(name, ParameterSource.DEFAULT)

    def call_on_close(self, func):
        self._exit_stack.callback(func)

    def with_resource(self, cm):
        return self.find_root()._exit_stack.enter_context(cm)

    def close(self):
        self._exit_stack.close()

    # -- invoking other commands -------------------------------------------

    def invoke(self, callback, *args, **kwargs):
        if isinstance(callback, Command):
            other = callback
            if other.callback is None:
                return None
            sub = Context(other, info_name=other.name, parent=self)
            for param in other.params:
                if param.expose_value and param.name not in kwargs:
                    kwargs[param.name] = param.get_default(sub)
            sub.params.update({k: v for k, v in kwargs.items() if k in {p.name for p in other.params}})
            for key in kwargs:
                sub._param_sources[key] = ParameterSource.COMMANDLINE
            return sub.invoke(other.callback, *args, **kwargs)
        with self:
            return callback(*args, **kwargs)

    def forward(self, cmd, *args, **kwargs):
        merged = dict(self.params)
        merged.update(kwargs)
        if isinstance(cmd, Command):
            declared = {p.name for p in cmd.params}
            merged = {k: v for k, v in merged.items() if k in declared}
        return self.invoke(cmd, *args, **merged)


class Parameter:
    """Common machinery of options and arguments (FP-03, FP-04, FP-05)."""

    param_type_name = "parameter"

    def __init__(self, name, opts=(), secondary=(), type=None, default=None, required=False, nargs=1,
                 multiple=False, callback=None, metavar=None, expose_value=True, is_eager=False,
                 envvar=None, shell_complete=None, deprecated=False, deprecation_note=None,
                 allow_from_autoenv=True, hidden=False, help=None, show_default=None,
                 show_envvar=False, is_flag=False, count=False):
        self.name = name
        self.required = bool(required)
        self.opts = list(opts)
        self.secondary_opts = list(secondary)
        self.default = default
        self.multiple = bool(multiple)
        self.callback = callback
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = bool(is_eager)
        self.envvar = [envvar] if isinstance(envvar, str) else (list(envvar) if envvar else [])
        self.shell_complete = shell_complete
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecation_note
        self.allow_from_autoenv = allow_from_autoenv
        self.hidden = hidden
        self.help = help
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.is_flag = bool(is_flag)
        self.count = bool(count)

        if count and multiple:
            raise TypeError("A counting option cannot also be repeatable.")
        if isinstance(nargs, bool) or (nargs is not None and (not isinstance(nargs, int) or nargs == 0 or nargs < -1)):
            raise TypeError("'nargs' must be a positive integer, or -1 for a variadic argument.")
        if nargs == -1 and not self.is_argument:
            raise TypeError("Only arguments may be variadic.")
        if self.is_flag:
            ty = BOOL if type is None else convert_type(type)
            if self.count:
                ty = INT if type is None else ty
            self.type = ty
            nargs = 1
        else:
            sample = default
            if self.multiple and isinstance(default, (list, tuple)):
                sample = default[0] if default else None
            self.type = convert_type(type, sample)
            if isinstance(self.type, Tuple) and (nargs or 1) == 1:
                nargs = self.type.arity
        self.nargs = nargs if nargs is not None else 1

    # -- shape ------------------------------------------------------------

    @property
    def is_argument(self):
        return False

    @property
    def occ_arity(self):
        """Tokens per occurrence."""
        if self.nargs == -1:
            return 1
        return self.nargs

    @property
    def is_multiple(self):
        return self.multiple or self.nargs == -1

    def all_flags(self):
        return []

    def takes_value(self):
        return False

    def occurrence_arity(self):
        return self.occ_arity

    def get_error_hint(self, ctx=None):
        return f"'{self.name.upper()}'"

    def get_metavar(self, ctx=None):
        if self.metavar is not None:
            return self.metavar
        return self.type.get_metavar(self) or self.type.name.upper()

    def get_default(self, ctx=None, call=True):
        value = self.default
        if callable(value) and call:
            value = value()
        return value

    # -- sources ------------------------------------------------------------

    def _env_names(self, ctx):
        names = list(self.envvar)
        if (ctx is not None and self.allow_from_autoenv and not self.is_argument
                and ctx.auto_envvar_prefix):
            names.append(ctx.auto_envvar_name(self.name))
        return names

    def _split_env(self, text):
        if self.occ_arity == 1 and not self.multiple:
            return [text]
        sep = os.pathsep if isinstance(self.type, (File, Path)) else None
        tokens = text.split(sep) if sep else text.split()
        if self.occ_arity == 1:
            return tokens
        size = self.occ_arity
        return [tuple(tokens[i:i + size]) for i in range(0, len(tokens) - size + 1, size)]

    def _flag_from_env(self, text):
        """Occurrence for a flag from its environment text, or None when unset."""
        if text == "":
            return None
        fv = self.flag_value
        bool_flag = isinstance(fv, bool)
        if not bool_flag and text == str(fv):
            return [fv]
        token = text.strip().lower()
        if token == "":
            return [False] if bool_flag else None
        if token in _TRUE_TOKENS:
            return [fv]
        if token in _FALSE_TOKENS:
            return [False]
        if bool_flag:
            raise BadParameter(f"{text!r} is not a valid boolean.", param=self)
        return None

    def _from_env(self, ctx):
        for name in self._env_names(ctx):
            text = os.environ.get(name)
            if text is None or text == "":
                continue
            if self.is_flag:
                occ = self._flag_from_env(text)
                if occ is None:
                    continue
                return occ
            occ = self._split_env(text)
            if occ:
                return occ
        return None

    def _occurrences_from_value(self, value, from_map=False):
        """Occurrences for a value from the default map or a declared default."""
        if self.is_flag:
            return [value]
        if self.is_multiple:
            if isinstance(value, str):
                if from_map and self.occ_arity > 1:
                    return self._split_env(value)
                raise BadOptionUsage(
                    f"'{self.name}' needs an iterable (sequence) default, not a string.", ctx=None
                )
            if isinstance(value, (list, tuple, set, frozenset)):
                items = list(value)
                if self.occ_arity > 1:
                    return [tuple(item) for item in items]
                return items
            return [value]
        if isinstance(value, str) and from_map and self.occ_arity > 1:
            return [tuple(self._split_env(value)[0])] if self._split_env(value) else []
        if self.occ_arity > 1 and isinstance(value, (list, tuple)):
            return [tuple(value)]
        return [value]

    def _fallback(self, ctx):
        """(occurrences, source, explicit) from the default map, then the declared default."""
        dm_value = ctx.lookup_default(self.name) if ctx is not None else None
        if dm_value is not None:
            return self._occurrences_from_value(dm_value, from_map=True), ParameterSource.DEFAULT_MAP, True, dm_value
        value = self.get_default(ctx)
        if value is not None:
            return self._occurrences_from_value(value), ParameterSource.DEFAULT, True, value
        return None, None, False, None

    # -- conversion ---------------------------------------------------------

    def _convert_occurrence(self, ctx, occ):
        try:
            if self.occ_arity > 1:
                if isinstance(self.type, Tuple):
                    return self.type.convert(occ, self, ctx)
                return tuple(self.type.convert(item, self, ctx) for item in occ)
            return self.type.convert(occ, self, ctx)
        except BadParameter as e:
            if e.param is None:
                e.param = self
            if e.ctx is None:
                e.ctx = ctx
            raise

    def _finalize(self, ctx, occ, converted):
        if self.is_flag:
            if self.count:
                return sum(occ) if occ else 0
            return occ[-1] if occ else False
        if self.is_multiple:
            if converted:
                return tuple(occ)
            return tuple(self._convert_occurrence(ctx, o) for o in occ)
        if not occ:
            return None
        if converted:
            return occ[-1]
        return self._convert_occurrence(ctx, occ[-1])

    def _prompt(self, ctx, default):
        from .termui import confirm, prompt

        text = self.prompt if isinstance(self.prompt, str) else self.name.replace("_", " ").capitalize()
        if self.is_flag:
            return confirm(text, default=bool(default))

        def value_proc(raw):
            return self._convert_occurrence(ctx, raw)

        return prompt(
            text,
            default=default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            value_proc=value_proc,
        )

    # -- the pipeline -------------------------------------------------------

    def handle_parse_result(self, ctx, occurrences):
        """Resolve, convert, check and store this parameter's value (FP-03).

        Sources, most explicit first: prompt, command line, environment,
        default map, declared default. A parameter callback sees every value.
        """
        marked = list(occurrences or [])
        prompt_marked = any(o is PROMPT for o in marked)
        occ = [o for o in marked if o is not PROMPT]
        source = None
        converted = False
        explicit = False
        if occ:
            source = ParameterSource.COMMANDLINE
        else:
            env_occ = self._from_env(ctx)
            if env_occ is not None:
                occ = env_occ
                source = ParameterSource.ENVIRONMENT

        fallback = (None, None, False, None)
        if source is None:
            fallback = self._fallback(ctx)

        if source is None and self._prompt_enabled() and (prompt_marked or self.prompt_required or self.required):
            occ = [self._prompt(ctx, fallback[3])]
            source = ParameterSource.PROMPT
            converted = True
        elif source is None and fallback[1] is not None:
            occ, source, explicit = fallback[0] or [], fallback[1], fallback[2]
        elif source is None and self.is_flag:
            occ, source = [], ParameterSource.DEFAULT
        elif source is None and self.is_multiple:
            occ, source = [], ParameterSource.DEFAULT

        if source is None and self.required:
            raise MissingParameter(param=self, ctx=ctx)
        if source is None:
            occ = []
        if source is ParameterSource.COMMANDLINE and self.deprecated:
            kind = "argument" if self.is_argument else "option"
            _warn_deprecated(kind, self.name, self.deprecation_note)

        value = self._finalize(ctx, occ, converted)

        if self.callback is not None:
            try:
                value = self.callback(ctx, self, value)
            except BadParameter as e:
                if e.param is None:
                    e.param = self
                if e.ctx is None:
                    e.ctx = ctx
                raise

        if self.expose_value:
            rank = (_SOURCE_RANK[source] if source else 0, 1 if explicit else 0)
            previous = ctx._param_ranks.get(self.name)
            if previous is None or rank >= previous:
                ctx._param_ranks[self.name] = rank
                ctx.params[self.name] = value
                ctx._param_sources[self.name] = source
        return value

    def _prompt_enabled(self):
        return bool(self.prompt)


class Option(Parameter):
    param_type_name = "option"

    def __init__(self, param_decls=None, show_default=None, prompt=False, confirmation_prompt=False,
                 prompt_required=True, hide_input=False, is_flag=None, flag_value=None, multiple=False,
                 count=False, allow_from_autoenv=True, type=None, help=None, hidden=False,
                 show_choices=True, show_envvar=False, default=None, required=False, nargs=None,
                 envvar=None, callback=None, is_eager=False, expose_value=True, metavar=None,
                 deprecated=False, shell_complete=None, deprecation_note=None, **attrs):
        opts, secondary, dest = parse_decls(param_decls or [])
        if dest is None:
            dest = infer_dest(opts or secondary)
        if not (opts or secondary):
            raise TypeError("An option needs at least one flag name.")
        if is_flag is None:
            is_flag = bool(secondary) or count or isinstance(default, bool)
        if count:
            is_flag = True
        self.prompt = prompt
        self.confirmation_prompt = confirmation_prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.show_choices = show_choices
        self.flag_value = 1 if count else (True if flag_value is None else flag_value)
        self.is_optional_value = (not is_flag) and flag_value is not None and not count
        if deprecated and required:
            raise TypeError("A deprecated option cannot also be required.")
        if deprecated and prompt:
            raise TypeError("A deprecated option cannot use a prompt.")
        super().__init__(
            dest,
            opts=opts,
            secondary=secondary,
            type=type,
            default=default,
            required=required,
            nargs=nargs or 1,
            multiple=multiple,
            callback=callback,
            metavar=metavar,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=envvar,
            shell_complete=shell_complete,
            deprecated=deprecated,
            deprecation_note=deprecation_note,
            allow_from_autoenv=allow_from_autoenv,
            hidden=hidden,
            help=help,
            show_default=show_default,
            show_envvar=show_envvar,
            is_flag=is_flag,
            count=count,
        )
        if self.is_flag and not count:
            self.nargs = 1
        if self.is_optional_value and self.nargs != 1:
            raise TypeError("An option with an optional value takes one value.")
        if self.is_flag and self.multiple and not count:
            raise TypeError("A flag cannot be repeatable.")

    def all_flags(self):
        return self.opts + self.secondary_opts

    def takes_value(self):
        return not self.is_flag

    def flag_value_for(self, flag):
        if flag in self.secondary_opts:
            return False
        return self.flag_value

    def get_error_hint(self, ctx=None):
        return " / ".join(f"'{flag}'" for flag in self.all_flags())

    def get_help_record(self, ctx):
        pieces = []
        if self.opts:
            pieces.append(", ".join(self.opts))
        if self.secondary_opts:
            pieces.append(", ".join(self.secondary_opts))
        first = " / ".join(pieces)
        if self.takes_value():
            first = f"{first} {self.get_metavar(ctx)}"
        parts = []
        if self.help:
            parts.append(self.help)
        if self.deprecated:
            parts.append("(deprecated)" + (f" {self.deprecation_note}" if self.deprecation_note else ""))
        if isinstance(self.type, Choice) and self.show_choices:
            parts.append("[" + ", ".join(str(c) for c in self.type.choices) + "]")
        show_default = self.show_default if self.show_default is not None else (ctx.show_default if ctx else None)
        if show_default and not callable(self.default):
            if isinstance(show_default, str):
                parts.append(f"[default: {show_default}]")
            elif self.default is not None and not (self.is_flag and self.default is False):
                parts.append(f"[default: {_show_value(self.default)}]")
        if self.show_envvar and self.envvar:
            parts.append(f"[env var: {self.envvar[0]}]")
        if self.required:
            parts.append("[required]")
        return first, " ".join(parts)


class Argument(Parameter):
    param_type_name = "argument"

    def __init__(self, param_decls=None, required=None, default=None, nargs=1, type=None, help=None,
                 metavar=None, envvar=None, deprecated=False, deprecation_note=None, callback=None,
                 expose_value=True, shell_complete=None, hidden=False, **attrs):
        decls = list(param_decls or [])
        if len(decls) != 1 or decls[0].startswith("-") or not decls[0].isidentifier():
            raise TypeError("An argument takes exactly one destination name.")
        name = decls[0]
        if nargs is None:
            nargs = 1
        if required is None:
            required = default is None and nargs != -1
        if deprecated and required:
            raise TypeError("A deprecated argument cannot be required.")
        self.required = bool(required)
        super().__init__(
            name,
            type=type,
            default=default,
            required=self.required,
            nargs=nargs,
            multiple=False,
            callback=callback,
            metavar=metavar,
            expose_value=expose_value,
            envvar=envvar,
            shell_complete=shell_complete,
            deprecated=deprecated,
            deprecation_note=deprecation_note,
            allow_from_autoenv=False,
            hidden=hidden,
            help=help,
        )
        self.prompt = False
        self.prompt_required = False
        self.hide_input = False
        self.confirmation_prompt = False
        self.flag_value = None
        self.is_optional_value = False

    @property
    def is_argument(self):
        return True

    def get_metavar(self, ctx=None):
        return self.metavar or self.name.upper()

    def get_error_hint(self, ctx=None):
        return f"'{self.name.upper()}'"

    def usage_text(self):
        metavar = self.get_metavar()
        if self.nargs == -1:
            text = f"{metavar}..."
            return text if self.required else f"[{text}]"
        text = " ".join([metavar] * self.nargs)
        return text if self.required else f"[{text}]"

    def min_tokens(self):
        if not self.required:
            return 0
        return 1 if self.nargs == -1 else self.nargs

    def get_help_record(self, ctx):
        text = self.help or ""
        return self.get_metavar(ctx), text


def _show_value(value):
    if isinstance(value, enum.Enum):
        return value.name
    return str(value)


def parse_decls(decls):
    """Split option declarations into flags, secondary flags and destination."""
    opts, secondary, dest = [], [], None
    for decl in decls:
        if not isinstance(decl, str) or not decl:
            raise TypeError("Option declarations must be non-empty strings.")
        if decl[0].isalnum() or decl[0] == "_":
            # no prefix character: this is the destination
            if dest is not None:
                raise TypeError("Only one destination name may be declared.")
            dest = decl
        elif "/" in decl[1:]:
            # "<on-flag>/<off-flag>"
            first, _, second = decl.partition("/")
            opts.append(first)
            secondary.append(second)
        else:
            opts.append(decl)
    return opts, secondary, dest


def infer_dest(flags):
    """Destination name inferred from flags (FP-03)."""
    stripped = [f.lstrip("-+/") for f in flags]
    for name in stripped:
        if name.isidentifier():
            return name
    longs = [f for f in flags if f[:2] == f[0] * 2]
    for flag in longs:
        return flag.lstrip("-+/").replace("-", "_")
    for name in stripped:
        return name.replace("-", "_")
    raise TypeError("Cannot infer a destination name.")


def _show_help_callback(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def _help_option(ctx, taken):
    names = [n for n in ctx.help_option_names if n not in taken]
    if not names:
        return None
    return Option(
        names,
        is_flag=True,
        is_eager=True,
        expose_value=False,
        callback=_show_help_callback,
        help="Show this message and exit.",
    )


class Command:
    """A bare command: options and arguments with a callback (FP-01)."""

    allow_extra_args = False
    allow_interspersed_args = True

    def __init__(self, name, context_settings=None, callback=None, params=None, help=None,
                 epilog=None, short_help=None, options_metavar="[OPTIONS]", add_help_option=True,
                 no_args_is_help=False, hidden=False, deprecated=False, **kwargs):
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        if help is None and callback is not None and callback.__doc__:
            import inspect

            help = inspect.cleandoc(callback.__doc__)
        self.help = strip_form_feed(help)
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None
        variadic = [p for p in self.params if isinstance(p, Argument) and p.nargs == -1]
        if len(variadic) > 1:
            raise TypeError("Only one variadic argument may be declared on a command.")


    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # -- parameters -----------------------------------------------------------

    def get_help_option(self, ctx):
        if not self.add_help_option:
            return None
        taken = {flag for p in self.params if not p.is_argument for flag in p.all_flags()}
        return _help_option(ctx, taken)

    def get_params(self, ctx):
        params = list(self.params)
        help_option = self.get_help_option(ctx)
        if help_option is not None:
            params.append(help_option)
        return params

    # -- running --------------------------------------------------------------

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True,
             windows_expand_args=True, **extra):
        if args is None:
            args = sys.argv[1:]
        else:
            args = list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0] or "") or "main"
            if prog_name.endswith(".py"):
                prog_name = prog_name[:-3]
        var = complete_var or "_" + prog_name.replace("-", "_").upper() + "_COMPLETE"
        if var in os.environ:
            from .shell_completion import run_completion

            code = run_completion(self, args, prog_name, os.environ[var], standalone_mode)
            if standalone_mode:
                sys.exit(code)
            return code

        ctx = None
        try:
            try:
                ctx = self.make_context(prog_name, args, **extra)
                rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                ctx.exit()
            except (EOFError, KeyboardInterrupt) as e:
                echo(file=sys.stderr)
                raise Abort() from e
            except Exit as e:
                if standalone_mode:
                    sys.exit(e.exit_code)
                return e.exit_code
            except Abort as e:
                if standalone_mode:
                    e.show()
                    sys.exit(1)
                raise
            except UsageError as e:
                if standalone_mode:
                    e.show()
                    sys.exit(e.exit_code)
                raise
            except OptlynError as e:
                if standalone_mode:
                    e.show()
                    sys.exit(e.exit_code)
                raise
        finally:
            if ctx is not None:
                ctx.close()

    def make_context(self, info_name, args, parent=None, **extra):
        for key, value in self.context_settings.items():
            extra.setdefault(key, value)
        ctx = Context(self, info_name=info_name, parent=parent, **extra)
        with ctx:
            try:
                self.parse_args(ctx, list(args))
            except BaseException:
                ctx.close()
                raise
        return ctx

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsHelp(ctx)
        extras = self._parse(ctx, args)
        ctx.args = self._check_extras(ctx, extras)
        return ctx.args

    def _parse(self, ctx, args):
        """Parse this command's own parameters; returns the unconsumed tokens."""
        params = self.get_params(ctx)
        options = [p for p in params if not p.is_argument]
        arguments = [p for p in params if p.is_argument]
        parser = OptionParser(
            options,
            allow_interspersed_args=ctx.allow_interspersed_args,
            ignore_unknown_options=ctx.ignore_unknown_options,
            normalize=ctx.token_normalize_func,
            positional_limit=self._positional_limit(arguments),
            is_group=isinstance(self, Group),
        )
        self._parser = parser
        try:
            occurrences, leftovers = parser.parse(args)
            arg_occurrences, remaining = self._assign_arguments(ctx, arguments, leftovers)
            order = parser.first_seen
            processing = self._processing_order(params, occurrences, order)
            for param in processing:
                if param.is_argument:
                    raw = arg_occurrences.get(param)
                else:
                    raw = occurrences.get(param)
                param.handle_parse_result(ctx, raw)
        except UsageError as e:
            if e.ctx is None:
                e.ctx = ctx
            raise
        return remaining

    def _positional_limit(self, arguments):
        """Positional tokens that belong to this command before its subcommand name."""
        return 0

    def _processing_order(self, params, occurrences, order):
        eager = [p for p in params if p.is_eager and p in occurrences]
        eager.sort(key=lambda p: order.get(p, 0))
        rest = [p for p in params if p not in eager]
        eager_rest = [p for p in rest if p.is_eager]
        others = [p for p in rest if not p.is_eager]
        return eager + eager_rest + others

    def _assign_arguments(self, ctx, arguments, leftovers):
        tokens = [token for token, _ in leftovers]
        pos = 0
        assigned = {}
        for index, arg in enumerate(arguments):
            later_min = sum(a.min_tokens() for a in arguments[index + 1:])
            available = len(tokens) - pos - later_min
            if arg.nargs == -1:
                take = max(available, 0)
                assigned[arg] = tokens[pos:pos + take]
                pos += take
                continue
            size = arg.nargs
            if available >= size:
                take = size
            elif available > 0 and arg.required:
                raise BadParameter(
                    f"Argument '{arg.name.upper()}' takes {size} values but {available} were given.",
                    ctx=ctx, param=arg,
                )
            else:
                take = 0
            if take == 0:
                assigned[arg] = []
                continue
            chunk = tokens[pos:pos + take]
            pos += take
            if size == 1:
                assigned[arg] = [chunk[0]]
            else:
                assigned[arg] = [tuple(chunk)]
        remaining = leftovers[pos:]
        return assigned, remaining

    def _check_extras(self, ctx, extras):
        if not extras:
            return []
        shaped = [tok for tok, is_shaped in extras if is_shaped]
        if not ctx.allow_extra_args:
            raise UsageError(
                "Got unexpected extra argument" + ("s" if len(extras) > 1 else "")
                + " (" + " ".join(tok for tok, _ in extras) + ")",
                ctx=ctx,
            )
        if shaped and not ctx.ignore_unknown_options and ctx.allow_interspersed_args:
            raise NoSuchOption(shaped[0], ctx=ctx)
        return [tok for tok, _ in extras]

    # -- invocation -----------------------------------------------------------

    def invoke(self, ctx):
        if self.deprecated:
            _warn_deprecated("command", ctx.command_path or self.name, self.deprecation_note)
        return self._run_callback(ctx)

    def _run_callback(self, ctx):
        if self.callback is None:
            return None
        with ctx:
            return ctx.invoke(self.callback, **ctx.params)

    # -- help -----------------------------------------------------------------

    def get_usage(self, ctx):
        return "Usage: " + self.format_usage(ctx)

    def format_usage(self, ctx):
        pieces = [ctx.command_path]
        if self.options_metavar:
            pieces.append(self.options_metavar)
        for param in self.params:
            if param.is_argument and not param.hidden:
                pieces.append(param.usage_text())
        return " ".join(pieces)

    def short_help_text(self, limit):
        if self.short_help:
            text = self.short_help
        else:
            text = first_sentence(strip_form_feed(self.help) or "")
        return ellipsize(text, limit)

    def get_help(self, ctx):
        width = _help_width(ctx)
        lines = [self.get_usage(ctx), ""]
        description = self.help
        if self.deprecated:
            mark = "(Deprecated)" if not self.deprecation_note else f"(Deprecated: {self.deprecation_note})"
            description = (description + " " if description else "") + mark
        if description:
            lines.append(wrap_text(description, width=width))
            lines.append("")
        arg_rows = [p.get_help_record(ctx) for p in self.params if p.is_argument and p.help and not p.hidden]
        if arg_rows:
            lines.extend(format_section("Positional arguments", format_dl(arg_rows, width)))
        option_rows = [
            param.get_help_record(ctx)
            for param in self.get_params(ctx)
            if not param.is_argument and not param.hidden
        ]
        if option_rows:
            lines.extend(format_section("Options", format_dl(option_rows, width)))
        lines.extend(self.format_extra_sections(ctx, width))
        if self.epilog:
            lines.append(wrap_text(self.epilog, width=width))
        while lines and lines[-1] == "":
            lines.pop()
        return "\n".join(lines)

    def format_extra_sections(self, ctx, width):
        return []

    def get_short_help_str(self, limit=45):
        return self.short_help_text(limit)


class Group(Command):
    """A command that dispatches to named subcommands (FP-06, FP-10)."""

    allow_extra_args = True
    allow_interspersed_args = False

    def __init__(self, name=None, commands=None, invoke_without_command=False, no_args_is_help=None,
                 subcommand_metavar=None, chain=False, result_callback=None, **kwargs):
        super().__init__(name, **kwargs)
        self.commands = {}
        if isinstance(commands, dict):
            self.commands.update(commands)
        elif commands:
            for cmd in commands:
                self.add_command(cmd)
        self.invoke_without_command = bool(invoke_without_command)
        if no_args_is_help is None:
            no_args_is_help = not self.invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = bool(chain)
        self._result_callback = result_callback

    # -- children -------------------------------------------------------------

    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Groups cannot be nested under a chaining group.")
        name = name or cmd.name
        if name is None:
            raise TypeError("A command needs a name to be added to a group.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as command_decorator

        def decorator(f):
            cmd = command_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        if args and callable(args[0]) and len(args) == 1 and not kwargs:
            return decorator(args[0])
        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as group_decorator

        def decorator(f):
            cmd = group_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        if args and callable(args[0]) and len(args) == 1 and not kwargs:
            return decorator(args[0])
        return decorator

    def result_callback(self, replace=False):
        """Decorator registering the function that receives subcommand return values."""

        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def resolve_command(self, ctx, args):
        cmd_name = make_str(args[0])
        cmd = self.get_command(ctx, cmd_name)
        if cmd is None and ctx.token_normalize_func is not None:
            wanted = ctx.token_normalize_func(cmd_name)
            for candidate in self.list_commands(ctx):
                if ctx.token_normalize_func(candidate) == wanted:
                    cmd_name = candidate
                    cmd = self.get_command(ctx, candidate)
                    break
        if cmd is None:
            raise NoSuchCommand(cmd_name, ctx=ctx)
        return cmd_name, cmd, list(args[1:])

    # -- parsing and invocation ---------------------------------------------

    def _positional_limit(self, arguments):
        """A group's own arguments come before the subcommand name."""
        return sum(a.nargs for a in arguments if a.nargs != -1)

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsHelp(ctx)
        extras = self._parse(ctx, args)
        if self.chain:
            ctx.protected_args = [tok for tok, _ in extras]
            ctx.args = []
        elif extras:
            ctx.protected_args = [extras[0][0]]
            ctx.args = [tok for tok, _ in extras[1:]]
        else:
            ctx.protected_args = []
            ctx.args = []
        return ctx.args

    def invoke(self, ctx):
        if self.deprecated:
            _warn_deprecated("command", ctx.command_path or self.name, self.deprecation_note)
        if not ctx.protected_args:
            if self.invoke_without_command:
                ctx.invoked_subcommand = None
                rv = self._run_callback(ctx)
                if self.chain:
                    rv = []
                return self._process_result(ctx, rv)
            raise UsageError("Missing command.", ctx=ctx)
        if self.chain:
            return self._invoke_chain(ctx)
        args = list(ctx.protected_args) + list(ctx.args)
        cmd_name, cmd, rest = self.resolve_command(ctx, args)
        ctx.invoked_subcommand = cmd_name
        self._run_callback(ctx)
        sub_ctx = cmd.make_context(cmd_name, rest, parent=ctx)
        try:
            rv = cmd.invoke(sub_ctx)
        finally:
            sub_ctx.close()
        return self._process_result(ctx, rv)

    def _invoke_chain(self, ctx):
        ctx.invoked_subcommand = "*"
        self._run_callback(ctx)
        args = list(ctx.protected_args)
        contexts = []
        while args:
            cmd_name, cmd, args = self.resolve_command(ctx, args)
            sub = cmd.make_context(cmd_name, args, parent=ctx, allow_extra_args=True,
                                   allow_interspersed_args=False)
            contexts.append(sub)
            args = sub.args
            sub.args = []
        results = []
        for sub in contexts:
            try:
                results.append(sub.command.invoke(sub))
            finally:
                sub.close()
        return self._process_result(ctx, results)

    def _process_result(self, ctx, value):
        if self._result_callback is None:
            return value
        return ctx.invoke(self._result_callback, value, **ctx.params)

    def format_extra_sections(self, ctx, width):
        names = self.list_commands(ctx)
        rows = []
        for name in names:
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            rows.append((name, cmd.short_help_text(max(width - 30, 20))))
        if not rows:
            return []
        return format_section("Commands", format_dl(rows, width))

    def format_usage(self, ctx):
        pieces = [ctx.command_path]
        if self.options_metavar:
            pieces.append(self.options_metavar)
        for param in self.params:
            if param.is_argument and not param.hidden:
                pieces.append(param.usage_text())
        if self.list_commands(ctx):
            meta = self.subcommand_metavar or "COMMAND"
            unit = f"{meta} [ARGS]..."
            if self.chain:
                pieces.append(unit + " [" + unit + "]...")
            elif self.invoke_without_command:
                pieces.append("[" + unit + "]")
            else:
                pieces.append(unit)
        return " ".join(pieces)


class CommandCollection(Group):
    """Presents the subcommands of several source groups under one dispatch surface."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        names.update(self.commands)
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None

