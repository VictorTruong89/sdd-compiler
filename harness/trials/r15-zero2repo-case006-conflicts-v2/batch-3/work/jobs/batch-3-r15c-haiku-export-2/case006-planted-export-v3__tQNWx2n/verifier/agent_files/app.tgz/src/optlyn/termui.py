"""Terminal helpers: styling, prompts, pager, progress bars, editor and launch (FP-08, FP-11)."""

import getpass
import io
import os
import shlex
import subprocess
import sys
import tempfile
import time
from contextlib import contextmanager

from ._state import current_color_flag, is_interactive, is_tty
from .exceptions import Abort, BadParameter
from .paramtypes import convert_type
from .utils import echo, unstyle
from .utils import echo as _echo

__all__ = [
    "style",
    "unstyle",
    "secho",
    "echo_via_pager",
    "get_pager_file",
    "progressbar",
    "prompt",
    "confirm",
    "getchar",
    "pause",
    "edit",
    "launch",
    "clear",
]

_COLOR_INDEX = {
    "black": 0,
    "red": 1,
    "green": 2,
    "yellow": 3,
    "blue": 4,
    "magenta": 5,
    "cyan": 6,
    "white": 7,
}

_SWITCHES = [
    ("bold", 1),
    ("dim", 2),
    ("italic", 3),
    ("underline", 4),
    ("blink", 5),
    ("reverse", 7),
    ("strikethrough", 9),
    ("overline", 53),
]


def _color_code(color, background):
    base = 40 if background else 30
    if isinstance(color, str):
        name = color.lower()
        if name == "reset":
            return "49" if background else "39"
        if name.startswith("bright_") and name[len("bright_"):] in _COLOR_INDEX:
            return str((100 if background else 90) + _COLOR_INDEX[name[len("bright_"):]])
        if name in _COLOR_INDEX:
            return str(base + _COLOR_INDEX[name])
        raise TypeError(f"Unknown color {color!r}.")
    prefix = "48" if background else "38"
    if isinstance(color, int) and not isinstance(color, bool) and 0 <= color <= 255:
        return f"{prefix};5;{color}"
    if (isinstance(color, (list, tuple)) and len(color) == 3
            and all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color)):
        return f"{prefix};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"Invalid color {color!r}.")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None, italic=None,
          blink=None, reverse=None, strikethrough=None, reset=True):
    """Wrap ``text`` in ANSI SGR sequences (FP-11)."""
    bits = []
    if fg is not None:
        bits.append(_color_code(fg, background=False))
    if bg is not None:
        bits.append(_color_code(bg, background=True))
    flags = {
        "bold": bold,
        "dim": dim,
        "italic": italic,
        "underline": underline,
        "overline": overline,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for name, code in _SWITCHES:
        if flags.get(name):
            bits.append(str(code))
    if not bits:
        return text
    out = "\x1b[" + ";".join(bits) + "m" + text
    if reset:
        out += "\x1b[0m"
    return out


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    """``echo`` of a styled message."""
    if message is not None:
        message = style(str(message), **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


# -- pager ---------------------------------------------------------------

def _pager_command():
    return os.environ.get("PAGER")


def echo_via_pager(text_or_generator, color=None):
    """Write long text through the pager when the session is interactive (FP-11)."""
    text = text_or_generator
    if callable(text):
        text = text()
    chunks = [text] if isinstance(text, str) else text
    pager = _pager_command()
    if not is_interactive() or not pager:
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    strip = color is False or (color is None and current_color_flag() is False)
    proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE)
    stream = io.TextIOWrapper(proc.stdin, encoding="utf-8", errors="replace")
    try:
        for chunk in chunks:
            if strip:
                chunk = unstyle(chunk)
            stream.write(chunk)
            stream.flush()
    finally:
        stream.close()
        proc.wait()


@contextmanager
def get_pager_file(color=None):
    """Writable text stream that goes through the pager when interactive (FP-11)."""
    pager = _pager_command()
    if not is_interactive() or not pager:
        yield sys.stdout
        return
    proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE)
    stream = io.TextIOWrapper(proc.stdin, encoding="utf-8", errors="replace")
    try:
        yield stream
    finally:
        stream.close()
        proc.wait()


# -- progress bar --------------------------------------------------------

class ProgressBar:
    """Iterable progress indicator. Items are always visited, in order (FP-11)."""

    def __init__(self, iterable, length, label, hidden, width=36):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label
        self.hidden = hidden
        self.width = width
        self.pos = 0
        self.start = time.time()
        self.visible = (not hidden) and is_tty(sys.stdout)
        self._printed_label = False

    def __enter__(self):
        if self.label and not self.hidden and not self.visible:
            echo(self.label)
            self._printed_label = True
        self.render()
        return self

    def __exit__(self, *exc):
        if self.visible:
            self.render(final=True)
            echo("")
        return False

    def __iter__(self):
        for item in self.iterable or ():
            yield item
            self.update(1)

    def update(self, n_steps):
        self.pos += n_steps
        self.render()

    def eta_seconds(self):
        if not self.length or self.pos == 0:
            return None
        elapsed = time.time() - self.start
        return (self.length - self.pos) * elapsed / self.pos

    def render(self, final=False):
        if not self.visible:
            return
        label = self.label or ""
        if self.length:
            done = min(self.pos / self.length, 1.0)
            filled = int(self.width * done)
            bar = "#" * filled + "-" * (self.width - filled)
            eta = 0 if final else (self.eta_seconds() or 0)
            line = f"\r{label}  [{bar}]  {self.pos}/{self.length}  eta {int(eta)}s"
        else:
            line = f"\r{label}  {self.pos}"
        echo(line, nl=False)


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    """Context manager yielding a progress bar (FP-11)."""
    return ProgressBar(iterable, length, label, hidden, width=options.get("width", 36))


# -- prompts and input -----------------------------------------------------

def _read_line(prompt_text, hide=False, err=False, echo_input=True):
    stream_out = sys.stderr if err else sys.stdout
    stdin = sys.stdin
    if is_tty(stdin) and hide:
        return getpass.getpass(prompt_text)
    echo(prompt_text, nl=False, err=err)
    stream_out.flush()
    line = stdin.readline()
    if line == "":
        raise Abort()
    text = line.rstrip("\r\n")
    if echo_input and not hide and not is_tty(stdin):
        echo(text)
    return text


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None, value_proc=None,
           prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    """Ask for a value; re-asks on conversion failure (FP-08)."""
    if callable(default):
        default = default()
    if value_proc is None:
        ty = convert_type(type, default)

        def value_proc(raw):
            return ty.convert(raw, None, None)

    shown = ""
    if show_default and default is not None and not hide_input:
        shown = f" [{default}]"
    prompt_text = f"{text}{shown}{prompt_suffix}"
    while True:
        raw = _read_line(prompt_text, hide=hide_input, err=err)
        if raw == "":
            if default is None:
                continue
            raw_value = default
            try:
                result = value_proc(raw_value)
            except BadParameter as e:
                echo(f"Error: {e.format_message()}", err=True)
                continue
        else:
            try:
                result = value_proc(raw)
            except BadParameter as e:
                echo(f"Error: {e.format_message()}", err=True)
                continue
        if confirmation_prompt:
            again = _read_line("Repeat for confirmation" + prompt_suffix, hide=hide_input, err=err)
            if again != raw:
                echo("Error: The two entered values do not match.", err=True)
                continue
        return result


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question and return a boolean (FP-08)."""
    if show_default:
        choices = "[Y/n]" if default else "[y/N]"
        prompt_text = f"{text} {choices}{prompt_suffix}"
    else:
        prompt_text = f"{text}{prompt_suffix}"
    while True:
        answer = _read_line(prompt_text, err=err).strip().lower()
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        if answer == "":
            result = bool(default)
            break
        echo("Error: invalid input", err=True)
    if abort and not result:
        raise Abort()
    return result


def getchar(echo=False):
    """Read one character from the terminal, even if stdin is a pipe (FP-11)."""
    try:
        import termios
        import tty

        fd = os.open("/dev/tty", os.O_RDWR)
    except (ImportError, OSError):
        fd = None
    if fd is None:
        char = sys.stdin.read(1)
    else:
        try:
            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                char = os.read(fd, 1).decode("utf-8", "replace")
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        finally:
            os.close(fd)
    if char == "\x03":
        raise KeyboardInterrupt()
    if char in ("\x04", "\x1a", ""):
        raise EOFError()
    if echo:
        _echo(char, nl=False)
    return char


def pause(info=None, err=False):
    """Wait for a key when interactive; do nothing otherwise (FP-11)."""
    if not is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    echo(info, nl=False, err=err)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo("", err=err)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open a file in an editor; returns the saved text, or None (FP-11)."""
    if editor is None:
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if editor is None:
        editor = "notepad" if sys.platform.startswith("win") else "vi"
    merged_env = dict(os.environ)
    if env:
        merged_env.update(env)
    if filename is not None:
        subprocess.call(shlex.split(editor) + [str(filename)], env=merged_env)
        return None
    original = text or ""
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(original)
        subprocess.call(shlex.split(editor) + [path], env=merged_env)
        with open(path, encoding="utf-8", newline="") as handle:
            saved = handle.read()
    finally:
        os.remove(path)
    if require_save and saved == original:
        return None
    return saved


def launch(url, wait=False, locate=False):
    """Open a URL or file with the default application; returns a status (FP-11)."""
    if sys.platform.startswith("win"):
        os.startfile(url)  # noqa: S606 - documented Windows behaviour
        return 0
    if sys.platform == "darwin":
        command = ["open"] + (["-R"] if locate else []) + [url]
    else:
        command = ["xdg-open", url]
    try:
        proc = subprocess.Popen(command)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def clear():
    """Clear the visible terminal; nothing when not connected to one (FP-11)."""
    if is_tty(sys.stdout):
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()
