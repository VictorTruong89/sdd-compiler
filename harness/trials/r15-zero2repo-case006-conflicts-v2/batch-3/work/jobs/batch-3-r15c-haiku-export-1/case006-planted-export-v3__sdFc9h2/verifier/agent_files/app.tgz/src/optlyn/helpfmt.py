"""Help page and usage line rendering (FP-02, Interface Contract section 2)."""

import shutil

from .core import Group
from .formatting import ellipsize, first_sentence, format_options_table, wrap_text
from .params import Argument, Option
from .types import Choice


def _help_width(ctx):
    if ctx.terminal_width:
        return int(ctx.terminal_width)
    auto = shutil.get_terminal_size((80, 20)).columns
    return min(auto, ctx.max_content_width)


def _claimed_help_names(cmd, ctx):
    claimed = set()
    for p in cmd.get_params():
        if isinstance(p, Option):
            claimed.update(p.all_names())
    return [n for n in ctx.help_option_names if n not in claimed]


def _argument_placeholder(arg):
    return arg.get_metavar()


def format_usage(cmd, ctx):
    parts = [ctx.command_path]
    if cmd.options_metavar:
        parts.append(cmd.options_metavar)
    if isinstance(cmd, _group_type()):
        if cmd.invoke_without_command:
            parts.append("[COMMAND] [ARGS]...")
        else:
            parts.append("COMMAND [ARGS]...")
        if cmd.chain:
            parts.append("[COMMAND [ARGS]...]...")
    for arg in cmd.get_params():
        if not isinstance(arg, Argument):
            continue
        ph = _argument_placeholder(arg)
        if arg.is_variadic():
            token = f"{ph}..." if arg.required else f"[{ph}]..."
        else:
            token = ph if arg.required else f"[{ph}]"
        parts.append(token)
    return "Usage: " + " ".join(parts)


def _group_type():
    return Group


def _description(cmd, ctx):
    text = cmd.help or ""
    text = text.split("\f", 1)[0]
    if not text.strip():
        return []
    width = _help_width(ctx)
    return wrap_text(text, width=width, preserve_paragraphs=True).splitlines()


def _option_entry(p, ctx):
    if p.secondary_opts:
        names = " / ".join(p.opts + p.secondary_opts)
    else:
        names = ", ".join(p.opts)
    meta = p.get_metavar(ctx)
    first = f"{names} {meta}" if meta else names
    extras = []
    help_text = p.help or ""
    if isinstance(p.type, Choice):
        extras.append("choices: " + ", ".join(str(n) for n in p.type._names))
    show_default = p.show_default if p.show_default is not None else ctx.show_default
    if show_default and p.default is not None and not (p.is_flag and p.default is False):
        if isinstance(p.show_default, str):
            extras.append(f"default: {p.show_default}")
        else:
            extras.append(f"default: {p.default}")
    if p.show_envvar and p.envvar:
        names_env = [p.envvar] if isinstance(p.envvar, str) else list(p.envvar)
        extras.append("env var: " + ", ".join(names_env))
    if p.deprecated:
        extras.append("deprecated")
    if extras:
        help_text = (help_text + " " if help_text else "") + "[" + "; ".join(extras) + "]"
    return first, help_text


def _positional_section(cmd, ctx):
    rows = []
    for arg in cmd.get_params():
        if isinstance(arg, Argument) and arg.help and arg.expose_value:
            rows.append((_argument_placeholder(arg), arg.help))
    if not rows:
        return []
    return ["Positional arguments:"] + format_options_table(rows, width=_help_width(ctx))


def _options_section(cmd, ctx):
    rows = []
    for p in cmd.get_params():
        if isinstance(p, Option) and not p.hidden:
            rows.append(_option_entry(p, ctx))
    if cmd.help_option_enabled(ctx):
        names = _claimed_help_names(cmd, ctx)
        if names:
            rows.append((", ".join(names), "Show this message and exit."))
    if not rows:
        return []
    return ["Options:"] + format_options_table(rows, width=_help_width(ctx))


def _commands_section(cmd, ctx):
    rows = []
    width = _help_width(ctx)
    for name in cmd.list_commands(ctx):
        sub = cmd.get_command(ctx, name)
        if sub is None or sub.hidden:
            continue
        short = sub.short_help or first_sentence((sub.help or "").split("\f", 1)[0])
        rows.append((name, ellipsize(short, max(10, width - 30))))
    if not rows:
        return []
    return ["Commands:"] + format_options_table(rows, width=width)


def format_help(cmd, ctx):
    lines = [format_usage(cmd, ctx), ""]
    desc = _description(cmd, ctx)
    if getattr(cmd, "deprecated", False):
        lines.extend(["DEPRECATED: this command is deprecated.", ""])
    if desc:
        lines.extend(desc)
        lines.append("")
    for section in (
        _positional_section(cmd, ctx),
        _options_section(cmd, ctx),
        _commands_section(cmd, ctx) if _is_group(cmd) else [],
    ):
        if section:
            lines.extend(section)
            lines.append("")
    if cmd.epilog:
        lines.extend(wrap_text(cmd.epilog, width=_help_width(ctx), preserve_paragraphs=True).splitlines())
        lines.append("")
    while lines and lines[-1] == "":
        lines.pop()
    return "\n".join(lines) + "\n"


def _is_group(cmd):
    return isinstance(cmd, _group_type())
