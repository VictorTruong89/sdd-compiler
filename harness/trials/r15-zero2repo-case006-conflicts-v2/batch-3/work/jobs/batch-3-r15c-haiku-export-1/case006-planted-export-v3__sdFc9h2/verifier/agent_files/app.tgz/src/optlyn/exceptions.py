"""Exception classes and their exit statuses (FP-13)."""

import sys


class OptlynError(Exception):
    """Base class for errors raised by Optlyn."""

    exit_code = 1

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def show(self, file=None):
        from .utils import echo

        echo(f"Error: {self.message}", file=file or sys.stderr, err=True)


class UsageError(OptlynError):
    """Incorrect usage: unknown option, missing parameter, bad value. Exit 2."""

    exit_code = 2

    def __init__(self, message, ctx=None, command=None):
        super().__init__(message, ctx)
        self.command = command

    def show(self, file=None):
        from .utils import echo

        echo(f"Error: {self.message}", file=file or sys.stderr, err=True)
        if self.ctx is not None and self.command is not None:
            hint = self.ctx.get_usage()
            echo(hint, file=file or sys.stderr, err=True)
            echo(
                f"Try '{self.ctx.command_path} {self.ctx.help_option_names[0]}' for help.",
                file=file or sys.stderr,
                err=True,
            )


class BadParameter(UsageError):
    """A value was refused. Raised from callbacks, types and conversion functions."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def show(self, file=None):
        from .utils import echo

        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint()
        if hint:
            echo(f"Error: Invalid value for {hint}: {self.message}", file=file or sys.stderr, err=True)
        else:
            echo(f"Error: Invalid value: {self.message}", file=file or sys.stderr, err=True)


class MissingParameter(BadParameter):
    """A required parameter was not supplied."""

    def show(self, file=None):
        from .utils import echo

        hint = self.param.get_error_hint() if self.param is not None else None
        echo(f"Error: Missing {hint or 'parameter'}.", file=file or sys.stderr, err=True)


class NoSuchOption(UsageError):
    """An option token that is not declared."""


class BadOptionUsage(UsageError):
    """Option-level usage error (missing value, bad default shape)."""


class BadArgumentUsage(UsageError):
    """Argument-level usage error."""


class NoArgsIsHelpError(UsageError):
    """Group invoked with no subcommand under the no-args-is-help policy."""


class Abort(OptlynError):
    """User or author abort. Exit 1."""

    exit_code = 1

    def __init__(self, message="Aborted!"):
        super().__init__(message)

    def show(self, file=None):
        from .utils import echo

        echo(self.message, file=file or sys.stderr, err=True)


class Exit(Exception):
    """Author clean stop. ``code`` is the exit status (0 by default)."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code


class DeclarationError(TypeError):
    """An invalid combination of declaration keywords (raised at decoration)."""
