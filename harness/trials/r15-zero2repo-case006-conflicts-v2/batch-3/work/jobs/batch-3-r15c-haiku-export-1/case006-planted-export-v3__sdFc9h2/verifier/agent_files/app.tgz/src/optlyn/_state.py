"""Thread-local storage for the current invocation context (FP-07, NFC threading)."""

import threading

_local = threading.local()


def _stack():
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = []
        _local.stack = stack
    return stack


def push_context(ctx):
    _stack().append(ctx)


def pop_context(ctx):
    stack = _stack()
    if stack and stack[-1] is ctx:
        stack.pop()


def current_context():
    stack = _stack()
    return stack[-1] if stack else None
