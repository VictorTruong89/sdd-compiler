"""Text wrapping and help-page layout helpers (FP-02, Interface Contract section 2)."""

import textwrap

DEFAULT_MAX_CONTENT_WIDTH = 80
UNWRAPPED_MAX_WIDTH = 100


def wrap_text(text, width=78, initial_indent="", subsequent_indent="",
              preserve_paragraphs=False):
    """Rewrap ``text`` to ``width``. Any string is accepted (FP-11)."""
    if text is None:
        return ""
    width = max(10, int(width))
    if not preserve_paragraphs:
        return textwrap.fill(
            " ".join(str(text).split()),
            width=width,
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
            break_long_words=True,
            break_on_hyphens=False,
        )
    out = []
    for para in str(text).split("\n\n"):
        lines = para.split("\n")
        if lines and lines[0].strip() == "\b":
            # A paragraph whose first line is only a backspace keeps its breaks.
            kept = [ln for ln in lines[1:]]
            out.append("\n".join(initial_indent + ln for ln in kept))
            continue
        out.append(
            textwrap.fill(
                " ".join(para.split()),
                width=width,
                initial_indent=initial_indent,
                subsequent_indent=subsequent_indent,
            )
        )
    return "\n\n".join(out)


def ellipsize(text, width):
    if len(text) <= width:
        return text
    if width <= 3:
        return text[:width]
    return text[: width - 3].rstrip() + "..."


def first_sentence(text):
    if not text:
        return ""
    flat = " ".join(text.split())
    for end in (". ", ".\n"):
        idx = flat.find(end)
        if idx != -1:
            return flat[: idx + 1]
    return flat.rstrip(".") + ("." if flat.endswith(".") else "")


def format_options_table(rows, col_indent=2, col_gap=2, width=78):
    """Render (first, second) rows with aligned second columns."""
    if not rows:
        return []
    first_w = max(len(a) for a, _ in rows)
    first_w = min(first_w, max(20, width // 3))
    lines = []
    text_w = max(20, width - col_indent - first_w - col_gap)
    for first, second in rows:
        head = " " * col_indent + first
        if not second:
            lines.append(head)
            continue
        wrapped = textwrap.wrap(" ".join(second.split()), width=text_w) or [""]
        if len(head) <= col_indent + first_w:
            lines.append(head.ljust(col_indent + first_w + col_gap) + wrapped[0])
        else:
            lines.append(head)
            lines.append(" " * (col_indent + first_w + col_gap) + wrapped[0])
        for extra in wrapped[1:]:
            lines.append(" " * (col_indent + first_w + col_gap) + extra)
    return lines
