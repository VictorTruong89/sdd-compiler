"""Parameter types and conversion (FP-05, Interface Contract section 5)."""

import datetime as _dt
import enum
import os
import pathlib
import uuid as _uuid

from .exceptions import BadParameter


class ParamType:
    """Base class for parameter types. Subclasses implement ``convert``."""

    name = "text"
    is_composite = False
    envvar_list_splitter = None

    def convert(self, value, param=None, ctx=None):
        return value

    def get_metavar(self, param):
        return None

    def get_missing_message(self, param):
        return None

    def shell_complete(self, ctx, param, incomplete):
        return []

    def split_envvar_value(self, rv):
        return rv.split()

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self):
        return self.name.upper()


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class _IntType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid float.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class _BoolType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices.__members__.values())
            self._names = list(choices.__members__.keys())
        else:
            self.choices = list(choices)
            self._names = [str(c) for c in self.choices]

    def get_metavar(self, param):
        return "[" + "|".join(str(n) for n in self._names) + "]"

    def _norm(self, text):
        return text if self.case_sensitive else text.casefold()

    def convert(self, value, param=None, ctx=None):
        if value in self.choices:
            return value
        token = str(value)
        for name, choice in zip(self._names, self.choices):
            if self._norm(name) == self._norm(token):
                return choice
        self.fail(
            f"{value!r} is not one of {', '.join(repr(n) for n in self._names)}.",
            param,
            ctx,
        )

    def shell_complete(self, ctx, param, incomplete):
        return [n for n in self._names if n.startswith(incomplete)]


_DEFAULT_DATETIME_FORMATS = [
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DATETIME_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value), fmt)
            except ValueError:
                continue
        self.fail(f"{value!r} does not match the formats {', '.join(self.formats)}.", param, ctx)


class IntRange(ParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        value = INT.convert(value, param, ctx)
        lo, hi = self.min, self.max
        if self.clamp:
            if lo is not None and (value < lo or (self.min_open and value == lo)):
                if self.min_open:
                    return lo + 1
                return lo
            if hi is not None and (value > hi or (self.max_open and value == hi)):
                if self.max_open:
                    return hi - 1
                return hi
            return value
        if lo is not None and (value < lo or (self.min_open and value == lo)):
            self.fail(f"{value} is out of range.", param, ctx)
        if hi is not None and (value > hi or (self.max_open and value == hi)):
            self.fail(f"{value} is out of range.", param, ctx)
        return value


class FloatRange(ParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min is None or max is None or min_open or max_open):
            raise ValueError("clamp is only allowed when both bounds are closed.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        value = FLOAT.convert(value, param, ctx)
        if self.clamp:
            if value < self.min:
                return float(self.min)
            if value > self.max:
                return float(self.max)
            return value
        if self.min is not None and (value < self.min or (self.min_open and value == self.min)):
            self.fail(f"{value} is out of range.", param, ctx)
        if self.max is not None and (value > self.max or (self.max_open and value == self.max)):
            self.fail(f"{value} is out of range.", param, ctx)
        return value


class Tuple(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [_to_type(t) for t in types]

    def convert(self, value, param=None, ctx=None):
        if len(value) != len(self.types):
            self.fail(f"Expected {len(self.types)} values.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


class Path(ParamType):
    name = "path"
    envvar_list_splitter = os.pathsep

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            value = os.fsdecode(value)
        token = os.fspath(value)
        if self.allow_dash and token == "-":
            rv = token
        else:
            rv = token
            if self.resolve_path:
                rv = os.path.realpath(rv)
            exists = os.path.exists(rv)
            if not exists:
                if self.exists:
                    self.fail(f"{token!r} does not exist.", param, ctx)
            else:
                if not self.file_okay and os.path.isfile(rv):
                    self.fail(f"{token!r} is a file.", param, ctx)
                if not self.dir_okay and os.path.isdir(rv):
                    self.fail(f"{token!r} is a directory.", param, ctx)
                if self.readable and not os.access(rv, os.R_OK):
                    self.fail(f"{token!r} is not readable.", param, ctx)
                if self.writable and not os.access(rv, os.W_OK):
                    self.fail(f"{token!r} is not writable.", param, ctx)
                if self.executable and not os.access(rv, os.X_OK):
                    self.fail(f"{token!r} is not executable.", param, ctx)
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return rv

    def shell_complete(self, ctx, param, incomplete):
        from .completion import CompletionItem

        kind = "dir" if (not self.file_okay and self.dir_okay) else "file"
        return [CompletionItem(incomplete, type=f"path:{kind}")]


class File(ParamType):
    name = "filename"
    envvar_list_splitter = os.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"unsupported mode {mode!r}")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def _is_lazy(self):
        if self.lazy is not None:
            return self.lazy
        return self.mode in ("w", "wb")

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        from .utils import open_file

        if self._is_lazy():
            from .utils import LazyFile

            lf = LazyFile(
                os.fspath(value),
                self.mode,
                self.encoding,
                self.errors,
                atomic=self.atomic,
            )
            if ctx is not None:
                ctx.call_on_close(lf.close_intermediate)
            return lf
        try:
            f = open_file(
                os.fspath(value),
                self.mode,
                self.encoding,
                self.errors,
                lazy=False,
                atomic=self.atomic,
            )
        except OSError as exc:
            self.fail(f"Could not open file {os.fspath(value)!r}: {exc.strerror}", param, ctx)
        if ctx is not None:
            ctx.call_on_close(f.close)
        return f

    def shell_complete(self, ctx, param, incomplete):
        from .completion import CompletionItem

        return [CompletionItem(incomplete, type="file")]


def _to_type(value):
    """Turn a ``type=`` keyword into a ParamType instance."""
    if isinstance(value, ParamType):
        return value
    if isinstance(value, type) and issubclass(value, ParamType):
        return value()
    if value is None:
        return STRING
    if value is str:
        return STRING
    if value is int:
        return INT
    if value is float:
        return FLOAT
    if value is bool:
        return BOOL
    if callable(value):
        return _FuncType(value)
    return STRING


class _FuncType(ParamType):
    """Wrap a conversion function ``f(token) -> value`` that refuses by raising ValueError."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as exc:
            self.fail(str(exc) or f"{value!r} is not valid.", param, ctx)


def infer_type(default):
    """Infer a built-in type from a default value (FP-05)."""
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, _uuid.UUID):
        return UUID
    return None
