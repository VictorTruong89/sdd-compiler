"""Shell completion: registration scripts and suggestion stream (FP-12, Interface Contract section 8)."""

import os
import re
import sys

from .core import Context, Group
from .params import Argument, Option

SHELLS = ("bash", "zsh", "fish", "powershell")


class CompletionItem:
    """A suggestion with optional help text. ``type`` is ``plain`` for ordinary values."""

    def __init__(self, value, help=None, type="plain"):
        self.value = value
        self.help = help
        self.type = type


def _var_name(prog_name):
    return "_" + re.sub(r"[^A-Za-z0-9]", "_", os.path.basename(prog_name)).upper() + "_COMPLETE"


def maybe_complete(cli, prog_name, complete_var, args):
    """Return an exit status when completion mode ran, otherwise None."""
    var = complete_var or _var_name(prog_name)
    instruction = os.environ.get(var)
    if instruction is None:
        return None
    shell, _, action = instruction.partition("_")
    if shell not in SHELLS or action not in ("source", "complete"):
        return 1
    if action == "source":
        sys.stdout.write(registration_script(shell, prog_name, var))
        sys.stdout.flush()
        return 0
    words, incomplete = _completion_words(shell)
    for line in suggestions(cli, prog_name, words, incomplete, shell):
        sys.stdout.write(line + "\n")
    sys.stdout.flush()
    return 0


def _completion_words(shell):
    raw = os.environ.get("COMP_WORDS", "")
    tokens = raw.split(" ")
    cword = os.environ.get("COMP_CWORD", "")
    if shell == "fish":
        incomplete = cword
        words = tokens[1:]
        if words and words[-1] == incomplete:
            words = words[:-1]
        return words, incomplete
    try:
        index = int(cword)
    except ValueError:
        index = len(tokens)
    incomplete = tokens[index] if index < len(tokens) else ""
    return tokens[1:index], incomplete


def _visible_options(cmd, ctx):
    out = []
    for p in cmd.get_params():
        if isinstance(p, Option) and not p.hidden:
            out.append((p, p.all_names()))
    return out


def _option_suggestions(cmd, ctx, incomplete):
    names = []
    for p, opts in _visible_options(cmd, ctx):
        for name in opts:
            if name.startswith(incomplete):
                names.append(CompletionItem(name, help=p.help))
    if cmd.help_option_enabled(ctx):
        for name in ctx.help_option_names:
            if name.startswith(incomplete):
                names.append(CompletionItem(name, help="Show this message and exit."))
    return names


def _command_suggestions(cmd, ctx, incomplete):
    out = []
    for name in cmd.list_commands(ctx):
        sub = cmd.get_command(ctx, name)
        if sub is None or sub.hidden or not name.startswith(incomplete):
            continue
        out.append(CompletionItem(name, help=sub.short_help or (sub.help or "").split("\n")[0]))
    return out


def suggestions(cli, prog_name, words, incomplete, shell):
    """Compute the suggestion lines for the current position."""
    ctx = Context(cli, info_name=os.path.basename(prog_name))
    cmd = cli
    positional_index = 0
    previous_option = None
    i = 0
    while i < len(words):
        tok = words[i]
        i += 1
        if previous_option is not None:
            previous_option = None
            continue
        if tok == "--":
            break
        if tok.startswith("-") and len(tok) > 1:
            found = _find_option(cmd, tok)
            if found is not None and not found.is_flag and not found.count:
                previous_option = found
            continue
        if isinstance(cmd, Group) and cmd.get_command(ctx, tok) is not None:
            cmd = cmd.get_command(ctx, tok)
            ctx = Context(cmd, info_name=tok, parent=ctx)
            positional_index = 0
            continue
        positional_index += 1

    lines = []
    if previous_option is not None:
        return _format_items(_param_items(previous_option, ctx, incomplete), shell)
    if incomplete.startswith("-"):
        return _format_items(_option_suggestions(cmd, ctx, incomplete), shell)
    if isinstance(cmd, Group):
        return _format_items(_command_suggestions(cmd, ctx, incomplete), shell)
    args = [p for p in cmd.get_params() if isinstance(p, Argument)]
    if positional_index < len(args):
        return _format_items(_param_items(args[positional_index], ctx, incomplete), shell)
    if args and args[-1].is_variadic():
        return _format_items(_param_items(args[-1], ctx, incomplete), shell)
    return lines


def _find_option(cmd, tok):
    for p in cmd.get_params():
        if isinstance(p, Option) and tok in p.all_names():
            return p
    return None


def _param_items(param, ctx, incomplete):
    raw = param.shell_complete(ctx, incomplete)
    items = []
    for entry in raw or []:
        if isinstance(entry, CompletionItem):
            items.append(entry)
        else:
            items.append(CompletionItem(str(entry)))
    return items


def _format_items(items, shell):
    lines = []
    for item in items:
        if item.type.startswith("path:"):
            kind = item.type.split(":", 1)[1]
            lines.append(f"!path:{kind}:{item.value}")
            continue
        if item.help and shell in ("zsh", "fish"):
            lines.append(f"{item.value}\t{item.help}")
        else:
            lines.append(item.value)
    return lines


def registration_script(shell, prog_name, var):
    prog = os.path.basename(prog_name)
    if shell == "bash":
        return (
            f"_{prog.replace('-', '_')}_completion() {{\n"
            f"    local IFS=$'\\n'\n"
            f"    COMPREPLY=()\n"
            f"    local line\n"
            f"    for line in $(env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD {var}=bash_complete {prog}); do\n"
            f"        case \"$line\" in\n"
            f"            !path:dir:*) COMPREPLY+=($(compgen -d -- \"${{line#!path:dir:}}\"));;\n"
            f"            !path:file:*) COMPREPLY+=($(compgen -f -- \"${{line#!path:file:}}\"));;\n"
            f"            *) COMPREPLY+=(\"${{line%%\t*}}\");;\n"
            f"        esac\n"
            f"    done\n"
            f"    return 0\n"
            f"}}\n"
            f"complete -o default -F _{prog.replace('-', '_')}_completion {prog}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog}\n"
            f"_{prog.replace('-', '_')}_completion() {{\n"
            f"    local -a items\n"
            f"    items=(${{(f)\"$(env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog})\"}})\n"
            f"    _describe 'values' items\n"
            f"}}\n"
            f"compdef _{prog.replace('-', '_')}_completion {prog}\n"
        )
    if shell == "fish":
        return (
            f"function _{prog.replace('-', '_')}_completion\n"
            f"    set -l cmd (commandline -opc)\n"
            f"    set -l cur (commandline -ct)\n"
            f"    env COMP_WORDS=\"$cmd $cur\" COMP_CWORD=\"$cur\" {var}=fish_complete {prog}\n"
            f"end\n"
            f"complete -c {prog} -f -a '(_{prog.replace('-', '_')}_completion)'\n"
        )
    return (
        f"Register-ArgumentCompleter -Native -CommandName {prog} -ScriptBlock {{\n"
        f"    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString()\n"
        f"    $env:COMP_CWORD = $wordToComplete\n"
        f"    $env:{var} = 'powershell_complete'\n"
        f"    & {prog} | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_) }}\n"
        f"}}\n"
    )
