"""In-process runner for tests (FP-14, Interface Contract section 9)."""

import contextlib
import io
import os
import sys
import tempfile

from .exceptions import OptlynError


class _BytesSink:
    def __init__(self):
        self.chunks = []

    def write(self, data):
        self.chunks.append(bytes(data))
        return len(data)

    def flush(self):
        pass

    def getvalue(self):
        return b"".join(self.chunks)


class _CaptureStream:
    """A text stream that records writes separately and in a combined buffer."""

    def __init__(self, name, combined, charset, echo_to=None):
        self.name = name
        self.encoding = charset
        self.errors = "strict"
        self._combined = combined
        self._bytes = _BytesSink()
        self.buffer = _BytesWriter(self)
        self._text = []
        self._echo_to = echo_to

    def write(self, text):
        if isinstance(text, bytes):
            return self.buffer.write(text)
        self._text.append(text)
        self._combined.append((self.name, text))
        self._bytes.write(text.encode(self.encoding, "replace"))
        return len(text)

    def _write_bytes(self, data):
        self._bytes.write(data)
        text = data.decode(self.encoding, "replace")
        self._text.append(text)
        self._combined.append((self.name, text))
        return len(data)

    def flush(self):
        pass

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")

    def getvalue(self):
        return "".join(self._text)

    def bytes_value(self):
        return self._bytes.getvalue()


class _BytesWriter:
    def __init__(self, owner):
        self._owner = owner

    def write(self, data):
        return self._owner._write_bytes(bytes(data))

    def flush(self):
        pass


class _InputStream(io.StringIO):
    """Standard input that can echo the lines actually read (FP-14)."""

    def __init__(self, data, echo_to=None):
        super().__init__(data)
        self._echo_to = echo_to

    def readline(self, *args):
        line = super().readline(*args)
        if self._echo_to is not None and line:
            self._echo_to.write(line)
        return line


class Result:
    def __init__(self, runner, stdout_stream, stderr_stream, combined, exit_code, exception, exc_info=None):
        self.runner = runner
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info
        self.stdout = stdout_stream.getvalue()
        self.stderr = stderr_stream.getvalue()
        self.stdout_bytes = stdout_stream.bytes_value()
        self.stderr_bytes = stderr_stream.bytes_value()
        self.output = "".join(text for _, text in combined)

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        combined = []
        stdout = _CaptureStream("stdout", combined, self.charset)
        stderr = _CaptureStream("stderr", combined, self.charset)
        if isinstance(input, bytes):
            input = input.decode(self.charset)
        stdin = _InputStream(input or "", echo_to=stdout if self.echo_stdin else None)
        merged_env = dict(self.env)
        merged_env.update(env or {})
        old_env = {}
        for key, value in merged_env.items():
            old_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        old_streams = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield stdout, stderr, combined
        finally:
            sys.stdin, sys.stdout, sys.stderr = old_streams
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if isinstance(args, str):
            args = args.split()
        args = list(args or [])
        extra.setdefault("color", color)
        prog_name = extra.pop("prog_name", None) or cli.name or "cli"
        standalone = extra.pop("standalone_mode", True)
        with self.isolation(input=input, env=env, color=color) as (stdout, stderr, combined):
            exit_code = 0
            exception = None
            exc_info = None
            try:
                cli.main(args=args, prog_name=prog_name, standalone_mode=standalone, **extra)
            except SystemExit as exc:
                code = exc.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    print(code, file=sys.stderr)
                    exit_code = 1
            except OptlynError as exc:
                exit_code = exc.exit_code
                exception = exc
                exc_info = sys.exc_info()
            except Exception as exc:
                if not catch_exceptions:
                    raise
                exception = exc
                exit_code = 1
                exc_info = sys.exc_info()
            return Result(self, stdout, stderr, combined, exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Chdir into a fresh directory. The directory is left in place on exit (CF-153 choice)."""
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
