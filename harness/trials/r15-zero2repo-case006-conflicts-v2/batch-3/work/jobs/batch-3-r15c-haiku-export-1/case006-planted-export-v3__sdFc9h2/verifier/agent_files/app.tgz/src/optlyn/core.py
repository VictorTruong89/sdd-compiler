"""Context, Command, Group and CommandCollection (FP-01, FP-06, FP-07, FP-10, FP-13)."""

import contextlib
import os
import sys

from . import _state
from .exceptions import (
    Abort,
    BadParameter,
    DeclarationError,
    Exit,
    MissingParameter,
    NoArgsIsHelpError,
    OptlynError,
    UsageError,
)
from .params import (
    Argument,
    Option,
    ParameterSource,
    convert_default_map,
    resolve_value_sources,
)
from .parser import Parser
from .types import Tuple

_CHAIN_MARKER = object()


class Context:
    """Per-invocation state (FP-07, Interface Contract section 6)."""

    def __init__(self, command, info_name=None, parent=None, obj=None, **extra):
        self.command = command
        self.info_name = info_name or command.name
        self.parent = parent
        self.settings = dict(parent.settings) if parent is not None else {}
        self.settings.update(command.context_settings or {})
        self.settings.update(extra)
        self._obj = obj
        self.params = {}
        self.param_sources = {}
        self.invoked_subcommand = None
        self.args_extra = []
        self._rest = []
        self._children = []
        self._close_callbacks = []
        self._closed = False
        if parent is not None:
            parent._children.append(self)
            self.default_map = parent.default_map.get(self.info_name) if isinstance(parent.default_map, dict) else None
        else:
            self.default_map = self.settings.get("default_map")

    # -- settings ----------------------------------------------------------

    @property
    def obj(self):
        if self._obj is None and self.parent is not None:
            return self.parent.obj
        return self._obj

    @obj.setter
    def obj(self, value):
        self._obj = value

    @property
    def auto_envvar_prefix(self):
        return self.settings.get("auto_envvar_prefix")

    @property
    def terminal_width(self):
        return self.settings.get("terminal_width")

    @property
    def max_content_width(self):
        return self.settings.get("max_content_width", 80)

    @property
    def help_option_names(self):
        return list(self.settings.get("help_option_names", ["--help"]))

    @property
    def token_normalize_func(self):
        return self.settings.get("token_normalize_func")

    @property
    def color(self):
        return self.settings.get("color")

    @property
    def show_default(self):
        return self.settings.get("show_default")

    @property
    def allow_extra_args(self):
        return bool(self.settings.get("allow_extra_args", False))

    @property
    def ignore_unknown_options(self):
        return bool(self.settings.get("ignore_unknown_options", False))

    @property
    def allow_interspersed_args(self):
        return self.settings.get("allow_interspersed_args", self.command.allow_interspersed_args)

    @property
    def command_path(self):
        names = []
        node = self
        while node is not None:
            names.append(node.info_name)
            node = node.parent
        return " ".join(reversed(names))

    @property
    def root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    # -- values ------------------------------------------------------------

    def default_map_value(self, param):
        if isinstance(self.default_map, dict) and param.name in self.default_map:
            value = self.default_map[param.name]
            return convert_default_map(param, value, self) if value is not None else None
        return None

    def auto_envvar_name(self, param):
        prefix = self.auto_envvar_prefix
        if not prefix:
            return None
        chain = []
        node = self
        while node is not None:
            chain.append(node.info_name)
            node = node.parent
        below_top = list(reversed(chain))[1:]
        parts = [prefix] + below_top + [param.name]
        return "_".join(str(p).upper().replace("-", "_") for p in parts)

    def get_parameter_source(self, name):
        if not any(p.name == name for p in self.command.get_params()):
            return None
        return self.param_sources.get(name)

    def find_object(self, object_type):
        node = self
        while node is not None:
            obj = node.obj
            if obj is not None and type(obj) is object_type:
                return obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        obj = self.find_object(object_type)
        if obj is None:
            obj = object_type()
            self.obj = obj
        return obj

    # -- lifecycle ---------------------------------------------------------

    def call_on_close(self, func):
        self._close_callbacks.append(func)

    def with_resource(self, cm):
        stack = getattr(self, "_exit_stack", None)
        if stack is None:
            stack = contextlib.ExitStack()
            self._exit_stack = stack
            self.call_on_close(stack.close)
        return stack.enter_context(cm)

    def close(self):
        if self._closed:
            return
        self._closed = True
        for child in reversed(self._children):
            child.close()
        for func in reversed(self._close_callbacks):
            func()

    def __enter__(self):
        _state.push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        _state.pop_context(self)
        return False

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def get_help(self):
        return self.command.format_help(self)

    def get_usage(self):
        return self.command.format_usage(self)

    def invoke(self, cmd, **values):
        """Run another command with exactly the given values (FP-07)."""
        sub = Context(cmd, info_name=cmd.name, parent=self)
        with sub:
            return cmd._run_callback(sub, values)

    def forward(self, cmd, **values):
        merged = {k: v for k, v in self.params.items()}
        merged.update(values)
        return self.invoke(cmd, **merged)


def get_current_context(silent=False):
    ctx = _state.current_context()
    if ctx is None and not silent:
        raise RuntimeError("There is no active click context.")
    return ctx


class Command:
    """A leaf command (FP-01)."""

    def __init__(
        self,
        name,
        callback=None,
        params=None,
        context_settings=None,
        help=None,
        short_help=None,
        epilog=None,
        options_metavar="[OPTIONS]",
        add_help_option=True,
        no_args_is_help=False,
        deprecated=False,
        hidden=False,
        allow_interspersed_args=True,
    ):
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        self.context_settings = dict(context_settings or {})
        self.help = help
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden
        self.allow_interspersed_args = allow_interspersed_args

    def get_params(self):
        return self.params

    def help_option_enabled(self, ctx):
        return bool(self.add_help_option and ctx.help_option_names)

    # -- construction and parsing -------------------------------------------

    def make_context(self, info_name, args, parent=None, **extra):
        ctx = Context(self, info_name=info_name, parent=parent, **extra)
        with ctx:
            if not args and self.no_args_is_help and not isinstance(self, Group):
                self._print_help_for_usage_error(ctx)
            parser = Parser(ctx, self, interspersed=ctx.allow_interspersed_args)
            result = parser.parse(args)
            ctx._rest = result.rest
            ctx.args_extra = result.extra
            self._resolve_params(ctx, result, parser)
        return ctx

    def _print_help_for_usage_error(self, ctx):
        from .utils import echo

        echo(self.format_help(ctx), file=sys.stderr, err=True)
        raise NoArgsIsHelpError("Missing argument; showing help.", ctx, self)

    def _resolve_params(self, ctx, result, parser):
        for p in self.get_params():
            cmd_value, has_cmd, prompt_pending = self._cmdline_value(ctx, p, result)
            if isinstance(p, Option) and p.count:
                value = result.counts.get(id(p), 0)
                source = ParameterSource.COMMANDLINE if has_cmd else ParameterSource.DEFAULT
            else:
                value, source = resolve_value_sources(p, ctx, cmd_value, has_cmd, prompt_pending)
                if source == ParameterSource.DEFAULT_MAP or source == ParameterSource.DEFAULT:
                    value = self._convert_raw(p, value, ctx)
            if source is None:
                if p.multiple or (isinstance(p, Argument) and p.is_variadic()):
                    value = ()
                elif p.required:
                    raise MissingParameter(f"Missing {p.param_type_name} '{p.get_error_hint()}'.", ctx, p)
            if has_cmd and p.deprecated and isinstance(p, Argument):
                self.warn_deprecated_param(ctx, p)
            if source is not None and p.callback is not None and id(p) not in result.eager_fired:
                if p.expose_value:
                    # Parameter callbacks may read values bound so far (FP-03).
                    ctx.params[p.name] = value
                value = p.callback(ctx, p, value)
            ctx.param_sources[p.name] = source
            if p.expose_value:
                ctx.params[p.name] = value

    def _cmdline_value(self, ctx, p, result):
        """Return (converted cmdline value, present?, prompt pending?)."""
        if isinstance(p, Option):
            occ = result.occurrences.get(id(p), [])
            pending = id(p) in result.prompt_pending
            if p.count:
                return None, id(p) in result.present, pending
            if not occ:
                return None, False, pending
            if p.is_flag:
                return occ[-1], True, pending
            if p.multiple:
                return tuple(self._convert_occ(p, o, ctx) for o in occ), True, pending
            return self._convert_occ(p, occ[-1], ctx), True, pending
        values = result.values.get(id(p))
        if values is None or (isinstance(values, list) and not values):
            return None, False, False
        if p.is_variadic():
            return tuple(p._convert_one(v, ctx) for v in values), True, False
        if p.nargs == 1:
            return p._convert_one(values[0], ctx), True, False
        return tuple(p._convert_one(v, ctx) for v in values), True, False

    def _convert_occ(self, p, occ, ctx):
        if isinstance(occ, tuple):
            return p.convert_occurrence(list(occ), ctx)
        if p.is_flag:
            return occ
        return p._convert_one(occ, ctx)

    def _convert_raw(self, p, value, ctx):
        """Convert a default-map or declared default value into the delivered form."""
        if value is None:
            return None
        multi_token = isinstance(p.type, Tuple) or (p.nargs not in (None, 1) and not p.is_flag)
        if p.multiple:
            if isinstance(value, str) or not isinstance(value, (list, tuple)):
                raise BadParameter(
                    f"{p.get_error_hint()} needs an iterable (sequence) default.",
                    ctx,
                    p,
                )
            return tuple(self._convert_occ(p, self._as_occ(v, multi_token), ctx) for v in value)
        if isinstance(p, Argument) and p.is_variadic():
            return tuple(p._convert_one(v, ctx) for v in value)
        if p.is_flag:
            return value
        return self._convert_occ(p, self._as_occ(value, multi_token), ctx)

    @staticmethod
    def _as_occ(value, multi_token):
        if multi_token and isinstance(value, (list, tuple)):
            return tuple(value)
        return value

    # -- running -----------------------------------------------------------

    def _run_callback(self, ctx, values=None):
        if self.callback is None:
            return None
        if values is None:
            kwargs = {k: v for k, v in ctx.params.items()}
        else:
            kwargs = dict(values)
        return self.callback(**kwargs)

    def invoke(self, ctx):
        if self.deprecated:
            self.warn_deprecated_command(ctx)
        return self._run_callback(ctx)

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        if args is None:
            args = sys.argv[1:]
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "main"
        from .completion import maybe_complete

        handled = maybe_complete(self, prog_name, complete_var, args)
        if handled is not None:
            if standalone_mode:
                sys.exit(handled)
            return None
        try:
            ctx = self.make_context(prog_name, list(args), **extra)
            try:
                with ctx:
                    rv = self.invoke(ctx)
            finally:
                ctx.close()
            if standalone_mode:
                sys.exit(0)
            return rv
        except Exit as exc:
            if standalone_mode:
                sys.exit(exc.exit_code)
            return None
        except OptlynError as exc:
            if not standalone_mode:
                raise
            exc.show()
            sys.exit(exc.exit_code)
        except (KeyboardInterrupt, EOFError):
            if not standalone_mode:
                raise Abort()
            from .utils import echo

            echo("Aborted!", file=sys.stderr, err=True)
            sys.exit(1)

    # -- help and deprecation ------------------------------------------------

    def format_help(self, ctx):
        from .helpfmt import format_help

        return format_help(self, ctx)

    def format_usage(self, ctx):
        from .helpfmt import format_usage

        return format_usage(self, ctx)

    def warn_deprecated_command(self, ctx):
        from .utils import echo

        note = self.deprecated if isinstance(self.deprecated, str) else None
        msg = f"DeprecationWarning: command '{ctx.command_path}' is deprecated."
        if note:
            msg += f" {note}"
        echo(msg, file=sys.stderr, err=True)

    def warn_deprecated_param(self, ctx, param):
        from .utils import echo

        note = param.deprecation_note
        msg = f"DeprecationWarning: {param.param_type_name} '{param.get_error_hint()}' is deprecated."
        if note:
            msg += f" {note}"
        echo(msg, file=sys.stderr, err=True)


class Group(Command):
    """A command that dispatches to named subcommands (FP-06)."""

    def __init__(
        self,
        name,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        allow_interspersed_args=False,
        **kwargs,
    ):
        super().__init__(name, allow_interspersed_args=allow_interspersed_args, **kwargs)
        self.commands = dict(commands or {})
        self.invoke_without_command = invoke_without_command
        self.no_args_is_help = (not invoke_without_command) if no_args_is_help is None else no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self.result_callback_fn = result_callback

    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise DeclarationError("Groups cannot be nested under a chaining group.")
        self.commands[name or cmd.name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as command_decorator

        def decorator(f):
            cmd = command_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as group_decorator

        def decorator(f):
            cmd = group_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(f):
            self.result_callback_fn = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def _lookup(self, ctx, name):
        cmd = self.get_command(ctx, name)
        if cmd is not None:
            return cmd
        normalize = ctx.token_normalize_func
        if normalize is None:
            return None
        wanted = normalize(name)
        for candidate in self.list_commands(ctx):
            if normalize(candidate) == wanted:
                return self.get_command(ctx, candidate)
        return None

    def invoke(self, ctx):
        rest = ctx._rest
        if self.chain:
            return self._invoke_chain(ctx, rest)
        if not rest:
            if self.invoke_without_command:
                ctx.invoked_subcommand = None
                rv = self._run_callback(ctx)
                if self.result_callback_fn is not None:
                    rv = self.result_callback_fn(rv, **ctx.params)
                return rv
            if self.no_args_is_help:
                from .utils import echo

                echo(self.format_help(ctx), file=sys.stderr, err=True)
                raise NoArgsIsHelpError("Missing command.", ctx, self)
            raise UsageError("Missing command.", ctx, self)
        name = rest[0]
        cmd = self._lookup(ctx, name)
        if cmd is None:
            raise UsageError(f"No such command '{name}'.", ctx, self)
        ctx.invoked_subcommand = name
        self._run_callback(ctx)
        sub = cmd.make_context(name, rest[1:], parent=ctx)
        with sub:
            value = cmd.invoke(sub)
        if self.result_callback_fn is not None:
            return self.result_callback_fn(value, **ctx.params)
        return value

    def _split_chain(self, ctx, rest):
        """Split the remaining tokens into (name, tokens) segments, one per chained command."""
        segments = []
        for tok in rest:
            if self._lookup(ctx, tok) is not None:
                segments.append((tok, []))
            elif segments:
                segments[-1][1].append(tok)
            else:
                raise UsageError(f"No such command '{tok}'.", ctx, self)
        return segments

    def _invoke_chain(self, ctx, rest):
        segments = self._split_chain(ctx, rest) if rest else []
        if not segments and not self.invoke_without_command:
            raise UsageError("Missing command.", ctx, self)
        ctx.invoked_subcommand = _CHAIN_MARKER
        self._run_callback(ctx)
        results = []
        for name, seg_tokens in segments:
            cmd = self._lookup(ctx, name)
            sub = cmd.make_context(name, seg_tokens, parent=ctx)
            with sub:
                results.append(cmd.invoke(sub))
            sub.close()
        if self.result_callback_fn is not None:
            self.result_callback_fn(results, **ctx.params)
        return results


class CommandCollection(Group):
    """A group that presents the union of several source groups (FP-06)."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        names.update(self.commands)
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None
