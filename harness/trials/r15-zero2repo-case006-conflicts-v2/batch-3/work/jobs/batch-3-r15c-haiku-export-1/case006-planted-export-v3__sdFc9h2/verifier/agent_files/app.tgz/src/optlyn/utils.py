"""Terminal helpers (FP-09, FP-11, Interface Contract section 7)."""

import contextlib
import io
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time

from . import _state
from .exceptions import Abort

_ANSI_RE = re.compile(r"\033\[[0-9;]*[A-Za-z]")

_COLORS = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "reset": 39,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
}

_STYLE_CODES = {
    "bold": (1, 22),
    "dim": (2, 22),
    "italic": (3, 23),
    "underline": (4, 24),
    "blink": (5, 25),
    "reverse": (7, 27),
    "strikethrough": (9, 29),
    "overline": (53, 55),
}


def _is_tty(stream):
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def _ctx_color():
    ctx = _state.current_context()
    return None if ctx is None else ctx.color


def should_strip_ansi(stream, color=None):
    if color is None:
        color = _ctx_color()
    if color is True:
        return False
    if color is False:
        return True
    return not _is_tty(stream)


def unstyle(text):
    return _ANSI_RE.sub("", text)


def _color_code(color, background=False):
    if isinstance(color, str):
        if color not in _COLORS:
            raise TypeError(f"Unknown color {color!r}.")
        code = _COLORS[color]
        if background:
            code = code + 10
        return str(code)
    if isinstance(color, int) and not isinstance(color, bool):
        if not 0 <= color <= 255:
            raise ValueError("Color number must be in 0-255.")
        return f"{'48' if background else '38'};5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3:
        for c in color:
            if not isinstance(c, int) or not 0 <= c <= 255:
                raise ValueError("RGB components must be integers in 0-255.")
        return f"{'48' if background else '38'};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"Invalid color {color!r}.")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    codes = []
    if fg is not None:
        codes.append(_color_code(fg))
    if bg is not None:
        codes.append(_color_code(bg, background=True))
    flags = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline,
        "italic": italic, "blink": blink, "reverse": reverse, "strikethrough": strikethrough,
    }
    for name, on in flags.items():
        if on is not None:
            on_code, off_code = _STYLE_CODES[name]
            codes.append(str(on_code) if on else str(off_code))
    if not codes:
        return text
    prefix = "\033[" + ";".join(codes) + "m"
    suffix = "\033[0m" if reset else ""
    return prefix + text + suffix


def _write(stream, text):
    try:
        stream.write(text)
    except UnicodeEncodeError:
        # Misconfigured (ASCII-only) stream: fall back to raw UTF-8 bytes (FP-11).
        buffer = getattr(stream, "buffer", None)
        if buffer is not None:
            stream.flush()
            buffer.write(text.encode("utf-8"))
        else:
            stream.write(text.encode("ascii", "backslashreplace").decode("ascii"))


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    elif not isinstance(message, (str, bytes)):
        message = str(message)
    if isinstance(message, bytes):
        target = getattr(file, "buffer", None)
        if target is not None:
            file.flush()
            target.write(message + (b"\n" if nl else b""))
            target.flush()
        else:
            file.write(message.decode("utf-8", "replace") + ("\n" if nl else ""))
        return
    if should_strip_ansi(file, color):
        message = unstyle(message)
    if nl:
        message += "\n"
    _write(file, message)
    file.flush()


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None:
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


class _ProgressBar:
    def __init__(self, iterable, length, label, hidden, file):
        self.iterable = iterable
        self.length = length if length is not None else (len(iterable) if hasattr(iterable, "__len__") else None)
        self.label = label
        self.hidden = hidden
        self.file = file
        self.pos = 0
        self.start = time.time()

    def _render(self):
        if self.hidden or not _is_tty(self.file):
            return
        done = self.pos
        if self.length:
            pct = int(100 * done / self.length)
            elapsed = time.time() - self.start
            remaining = (elapsed / done * (self.length - done)) if done else 0
            line = f"\r{self.label or ''} [{pct:3d}%] {done}/{self.length} eta {int(remaining)}s"
        else:
            line = f"\r{self.label or ''} {done}"
        self.file.write(line)
        self.file.flush()

    def update(self, n_steps):
        self.pos += n_steps
        self._render()

    def __iter__(self):
        for item in self.iterable:
            yield item
            self.update(1)

    def finish(self):
        if not self.hidden and _is_tty(self.file):
            self.file.write("\n")
            self.file.flush()
        elif self.label and not self.hidden:
            self.file.write(f"{self.label}\n")
            self.file.flush()


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    bar = _ProgressBar(iterable, length, label, hidden, sys.stdout)
    try:
        yield bar
    finally:
        bar.finish()


def echo_via_pager(text_or_generator, color=None):
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    if not (_is_tty(sys.stdin) and _is_tty(sys.stdout)):
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    pager = os.environ.get("PAGER") or "less"
    proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE)
    try:
        for chunk in chunks:
            proc.stdin.write(chunk.encode("utf-8"))
            proc.stdin.flush()
    except BrokenPipeError:
        pass
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()


@contextlib.contextmanager
def get_pager_file(color=None):
    buf = io.StringIO()
    yield buf
    echo_via_pager(buf.getvalue(), color=color)


def getchar(echo=False):
    import termios
    import tty

    try:
        fd = sys.stdin.fileno()
    except (AttributeError, OSError, io.UnsupportedOperation):
        fd = None
    if fd is None or not os.isatty(fd):
        try:
            fd = os.open("/dev/tty", os.O_RDONLY)
        except OSError:
            ch = sys.stdin.read(1)
            if ch == "":
                raise EOFError()
            return ch
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        ch = os.read(fd, 1).decode("utf-8", "replace")
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    if echo:
        echo_text = ch
        sys.stdout.write(echo_text)
        sys.stdout.flush()
    return ch


def pause(info=None, err=False):
    stream = sys.stderr if err else sys.stdout
    if not (_is_tty(sys.stdin) and _is_tty(stream)):
        return
    echo(info if info is not None else "Press any key to continue...", file=stream, nl=False, err=err)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo("", file=stream, err=err)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    editor = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    if filename is not None:
        path = os.fspath(filename)
        subprocess.call(shlex.split(editor) + [path], env=env)
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text or "")
        before = os.path.getmtime(path)
        subprocess.call(shlex.split(editor) + [path], env=env)
        if require_save and os.path.getmtime(path) == before:
            return None
        with open(path, encoding="utf-8") as f:
            return f.read()
    finally:
        os.unlink(path)


def launch(url, wait=False, locate=False):
    opener = "open" if sys.platform == "darwin" else "xdg-open"
    args = [opener, url]
    if sys.platform.startswith("win"):
        return os.startfile(url) or 0
    try:
        proc = subprocess.Popen(args)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def clear():
    if _is_tty(sys.stdout):
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()


def get_app_dir(app_name, roaming=True, force_posix=False):
    if force_posix or sys.platform not in ("darwin", "win32"):
        folder = re.sub(r"\s+", "-", app_name.lower())
        if force_posix:
            return os.path.join(os.path.expanduser("~"), "." + folder)
        xdg = os.environ.get("XDG_CONFIG_HOME")
        base = xdg if xdg else os.path.join(os.path.expanduser("~"), ".config")
        return os.path.join(base, folder)
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~"), "Library", "Application Support", app_name)
    return os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), app_name)


def format_filename(filename, shorten=False):
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = os.fspath(filename)
    text = text.encode("utf-8", "surrogateescape").decode("utf-8", "replace")
    if shorten:
        text = os.path.basename(text)
    return text


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if filename == "-":
        if "r" in mode:
            stream = sys.stdin.buffer if "b" in mode else sys.stdin
        else:
            stream = sys.stdout.buffer if "b" in mode else sys.stdout
        return _NonClosing(stream)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    if "w" in mode and atomic:
        return _AtomicFile(filename, mode, encoding, errors)
    return open(filename, mode, encoding=None if "b" in mode else encoding, errors=errors)


class _NonClosing:
    """Wrap a standard stream so that leaving the block does not close it."""

    def __init__(self, stream):
        self._stream = stream

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


class _AtomicFile:
    def __init__(self, filename, mode, encoding, errors):
        self._target = filename
        self._dir = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp = tempfile.mkstemp(dir=self._dir, prefix=".optlyn-")
        os.close(fd)
        self._f = open(self._tmp, mode, encoding=None if "b" in mode else encoding, errors=errors)

    def __getattr__(self, name):
        return getattr(self._f, name)

    def write(self, data):
        return self._f.write(data)

    def close(self):
        if self._f.closed:
            return
        self._f.close()
        os.replace(self._tmp, self._target)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


class LazyFile:
    """Opens on first I/O. A write-mode file is not truncated until it is used."""

    def __init__(self, filename, mode, encoding=None, errors="strict", atomic=False):
        self.name = filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None

    def _open(self):
        if self._f is None:
            try:
                self._f = open_file(self.name, self.mode, self.encoding, self.errors,
                                    lazy=False, atomic=self.atomic)
            except OSError as exc:
                from .exceptions import OptlynError

                raise OptlynError(f"Could not open file {self.name!r}: {exc.strerror}")
        return self._f

    def __getattr__(self, name):
        return getattr(self._open(), name)

    def write(self, data):
        return self._open().write(data)

    def read(self, *args):
        return self._open().read(*args)

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intermediate(self):
        self.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


def _default_prompt_text(name):
    return name.replace("_", " ").capitalize()


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False):
    from .types import STRING, _to_type

    ptype = _to_type(type) if type is not None else (STRING if default is None else _to_type(type_from_default(default)))
    stream = sys.stderr if err else sys.stdout
    while True:
        shown = text
        if default is not None and show_default:
            shown = f"{text} [{default}]"
        echo(shown + prompt_suffix, file=stream, nl=False, err=err)
        line = _read_line(hide_input)
        _echo_typed(line, hide_input, stream, err)
        if line == "" and default is not None:
            value = default() if callable(default) else default
        else:
            if line is None:
                raise Abort()
            value = line
        try:
            value = ptype.convert(value)
        except Exception as exc:
            echo(f"Error: {getattr(exc, 'message', exc)}", file=stream, err=err)
            continue
        if confirmation_prompt:
            echo("Repeat for confirmation" + prompt_suffix, file=stream, nl=False, err=err)
            again = _read_line(hide_input)
            if again != line:
                echo("Error: The two entered values do not match.", file=stream, err=err)
                continue
        return value


def type_from_default(default):
    from .types import infer_type, STRING

    return infer_type(default) or STRING


def _echo_typed(line, hide_input, stream, err):
    """Visible input is echoed when it was not typed at a terminal, so captured output shows it."""
    if hide_input or line is None or _is_tty(sys.stdin):
        return
    echo(line, file=stream, err=err)


def _read_line(hide_input):
    if hide_input and _is_tty(sys.stdin):
        import getpass

        try:
            return getpass.getpass(prompt="")
        except EOFError:
            return None
    line = sys.stdin.readline()
    if line == "":
        return None
    return line.rstrip("\r\n")


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True,
            err=False):
    stream = sys.stderr if err else sys.stdout
    if default is True:
        hint = "[Y/n]"
    elif default is False:
        hint = "[y/N]"
    else:
        hint = "[y/n]"
    while True:
        echo(f"{text} {hint}{prompt_suffix}", file=stream, nl=False, err=err)
        line = _read_line(hide_input=False)
        _echo_typed(line, False, stream, err)
        if line is None:
            raise Abort()
        answer = line.strip().lower()
        if answer == "":
            value = default
            break
        if answer in ("y", "yes"):
            value = True
            break
        if answer in ("n", "no"):
            value = False
            break
    if not value and abort:
        raise Abort()
    return value
