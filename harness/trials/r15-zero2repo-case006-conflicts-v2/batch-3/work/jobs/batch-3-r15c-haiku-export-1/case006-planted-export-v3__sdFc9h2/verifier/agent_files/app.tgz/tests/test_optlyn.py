"""Behavioural tests for Optlyn, run with PYTHONPATH=src (pytest)."""

import enum
import os

import pytest

from optlyn import (
    Abort,
    Choice,
    CommandCollection,
    IntRange,
    Path,
    Tuple,
    argument,
    command,
    confirmation_option,
    custom_version_option,
    echo,
    group,
    option,
    pass_context,
    password_option,
    style,
    unstyle,
    version_option,
)
from optlyn.testing import CliRunner


@pytest.fixture
def runner():
    return CliRunner()


def test_command_name_derivation_strips_suffix(runner):
    @command()
    def sync_cmd():
        echo("ok")

    assert sync_cmd.name == "sync"
    assert runner.invoke(sync_cmd, []).output == "ok\n"


def test_explicit_name_replaces_derived_name():
    @command("run-it")
    def runner_fn():
        pass

    assert runner_fn.name == "run-it"


def test_nested_groups_dispatch_outside_in(runner):
    calls = []

    @group()
    def outer():
        calls.append("outer")

    @outer.group()
    def inner():
        calls.append("inner")

    @inner.command()
    def leaf():
        calls.append("leaf")

    r = runner.invoke(outer, ["inner", "leaf"])
    assert r.exit_code == 0
    assert calls == ["outer", "inner", "leaf"]


def test_nested_group_without_child_shows_its_help_as_usage_failure(runner):
    @group()
    def outer():
        pass

    @outer.group()
    def inner():
        """Inner help text."""

    r = runner.invoke(outer, ["inner"])
    assert r.exit_code == 2
    assert "Inner help text." in r.output


def test_help_is_success_and_skips_callback(runner):
    ran = []

    @command()
    @option("--x")
    def cmd(x):
        ran.append(x)

    r = runner.invoke(cmd, ["--help"])
    assert r.exit_code == 0
    assert ran == []
    assert "Usage: cmd" in r.stdout


def test_unknown_option_is_usage_error(runner):
    @command()
    def cmd():
        pass

    r = runner.invoke(cmd, ["--nope"])
    assert r.exit_code == 2
    assert "--nope" in r.output


def test_option_stacking_and_attached_value(runner):
    @command()
    @option("-a", is_flag=True)
    @option("-b", is_flag=True)
    @option("-o", "out")
    def cmd(a, b, out):
        echo(f"{a} {b} {out}")

    assert runner.invoke(cmd, ["-abofile"]).output == "True True file\n"


def test_flag_pair_and_count(runner):
    @command()
    @option("--shout/--no-shout", default=False)
    @option("--cnt", count=True)
    def cmd(shout, cnt):
        echo(f"{shout} {cnt}")

    assert runner.invoke(cmd, ["--shout", "--cnt", "--cnt"]).output == "True 2\n"
    assert runner.invoke(cmd, ["--no-shout"]).output == "False 0\n"


def test_multiple_nargs_tuple_and_variadic_argument(runner):
    @command()
    @option("--tag", multiple=True)
    @option("--pair", nargs=2, type=int)
    @option("--xy", type=Tuple([str, int]))
    @argument("rest", nargs=-1)
    def cmd(tag, pair, xy, rest):
        echo(f"{tag} {pair} {xy} {rest}")

    r = runner.invoke(cmd, ["--tag", "x", "--tag", "y", "--pair", "1", "2", "--xy", "q", "3", "--", "--z"])
    assert r.output == "('x', 'y') (1, 2) ('q', 3) ('--z',)\n"


def test_value_source_order_env_then_default_map_then_default(runner):
    @command(context_settings={"auto_envvar_prefix": "APP"})
    @option("--name", default="dflt")
    def cmd(name):
        echo(name)

    assert runner.invoke(cmd, [], env={"APP_NAME": "env"}).output == "env\n"
    assert runner.invoke(cmd, [], default_map={"name": "map"}).output == "map\n"
    assert runner.invoke(cmd, []).output == "dflt\n"
    assert runner.invoke(cmd, ["--name", "cli"], default_map={"name": "map"}).output == "cli\n"


def test_choice_case_sensitive_and_enum_delivery(runner):
    class Col(enum.Enum):
        red = 1
        blue = 2

    @command()
    @option("--c", type=Choice(Col))
    def cmd(c):
        echo(repr(c))

    assert runner.invoke(cmd, ["--c", "blue"]).output == "<Col.blue: 2>\n"
    assert runner.invoke(cmd, ["--c", "BLUE"]).exit_code == 2


def test_int_range_clamp(runner):
    @command()
    @option("--r", type=IntRange(1, 5, clamp=True), default=3)
    def cmd(r):
        echo(r)

    assert runner.invoke(cmd, ["--r", "99"]).output == "5\n"


def test_prompt_reads_input_and_echoes(runner):
    @command()
    @option("--who", prompt="Your name")
    def cmd(who):
        echo(f"got {who}")

    r = runner.invoke(cmd, [], input="zed\n")
    assert r.exit_code == 0
    assert "got zed" in r.output


def test_password_mismatch_aborts(runner):
    @command()
    @password_option()
    def cmd(password):
        echo("never")

    r = runner.invoke(cmd, [], input="a\nb\n")
    assert r.exit_code == 1
    assert "never" not in r.output


def test_confirmation_option(runner):
    @command()
    @confirmation_option(prompt="Sure?")
    def drop():
        echo("dropped")

    assert "dropped" in runner.invoke(drop, ["--yes"]).output
    assert runner.invoke(drop, [], input="n\n").exit_code == 1
    assert "dropped" in runner.invoke(drop, [], input="y\n").output


def test_eager_first_typed_wins(runner):
    @command()
    @version_option("1.0", prog_name="tool")
    @option("--x")
    def cmd(x):
        pass

    r = runner.invoke(cmd, ["--version", "--help"])
    assert r.exit_code == 0
    assert "tool, version 1.0" in r.output
    assert "Usage:" not in r.output


def test_custom_version_is_exact_callback_text(runner):
    @command()
    @custom_version_option(lambda ctx: "CUSTOM 9")
    def cmd():
        pass

    assert runner.invoke(cmd, ["--version"]).output == "CUSTOM 9\n"


def test_chaining_group_collects_results(runner):
    seen = {}

    @group(chain=True)
    def pipe():
        pass

    @pipe.result_callback()
    def done(results):
        seen["results"] = results

    @pipe.command()
    @argument("v", type=int)
    def add(v):
        return v + 1

    @pipe.command()
    @argument("v", type=int)
    def mul(v):
        return v * 10

    r = runner.invoke(pipe, ["add", "1", "mul", "4"])
    assert r.exit_code == 0
    assert seen["results"] == [2, 40]


def test_chaining_group_refuses_nested_group():
    @group(chain=True)
    def pipe():
        pass

    @group()
    def inner():
        pass

    with pytest.raises(Exception):
        pipe.add_command(inner)


def test_standalone_off_returns_value_and_raises_usage():
    @group()
    def top():
        pass

    @top.command()
    def child():
        return 5

    assert top.main(["child"], prog_name="top", standalone_mode=False) == 5


def test_pass_context_gets_current_context(runner):
    @command()
    @pass_context
    def cmd(ctx):
        echo(ctx.info_name)

    assert runner.invoke(cmd, []).output == "cmd\n"


def test_deprecated_command_still_runs(runner):
    @command(deprecated="use other")
    def old():
        echo("ran")

    r = runner.invoke(old, [])
    assert r.exit_code == 0
    assert "DeprecationWarning" in r.output
    assert "ran" in r.output


def test_path_type_rejects_missing(runner):
    @command()
    @argument("p", type=Path(exists=True))
    def cmd(p):
        echo(p)

    assert runner.invoke(cmd, ["/definitely/not/here"]).exit_code == 2


def test_file_write_dash_and_real_path(runner, tmp_path):
    from optlyn import File

    @command()
    @argument("f", type=File("w"))
    def cmd(f):
        f.write("hello")

    with runner.isolated_filesystem(temp_dir=str(tmp_path)):
        assert runner.invoke(cmd, ["out.txt"]).exit_code == 0
        with open("out.txt") as fh:
            assert fh.read() == "hello"


def test_isolated_filesystem_left_in_place(runner, tmp_path):
    with runner.isolated_filesystem(temp_dir=str(tmp_path)) as path:
        assert os.path.isdir(path)
        cwd = os.getcwd()
        assert cwd == os.path.realpath(path)
    assert os.path.isdir(path)


def test_collection_union_and_dispatch(runner):
    @group()
    def a():
        pass

    @a.command()
    def one():
        echo("one")

    @group()
    def b():
        pass

    @b.command()
    def two():
        echo("two")

    col = CommandCollection(name="col", sources=[a, b])
    assert runner.invoke(col, ["two"]).output == "two\n"
    assert "one" in runner.invoke(col, ["--help"]).output


def test_style_and_unstyle():
    assert unstyle(style("x", fg="red", bold=True)) == "x"
    with pytest.raises(TypeError):
        style("x", fg="nope")


def test_standalone_abort_exits_one(runner):
    @command()
    def cmd():
        raise Abort()

    assert runner.invoke(cmd, []).exit_code == 1
