"""Parameters: options and arguments, declaration checks, and value resolution (FP-03, FP-04, FP-07, FP-08)."""

import os

from . import utils
from .exceptions import BadParameter, DeclarationError, UsageError
from .types import BOOL, STRING, Tuple, _to_type, infer_type


class ParameterSource:
    """The five distinguishable sources of a parameter's value (FP-07)."""

    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"

    ALL = (PROMPT, COMMANDLINE, ENVIRONMENT, DEFAULT_MAP, DEFAULT)


_TRUE_ENV = {"true", "1", "yes", "on", "t", "y"}
_FALSE_ENV = {"false", "0", "no", "off", "f", "n"}
_PREFIX_CHARS = ("-",)


class Parameter:
    param_type_name = "parameter"

    def __init__(
        self,
        param_decls=None,
        type=None,
        required=False,
        default=None,
        callback=None,
        nargs=None,
        multiple=False,
        metavar=None,
        expose_value=True,
        is_eager=False,
        envvar=None,
        shell_complete=None,
        deprecated=False,
        hidden=False,
        help=None,
        show_default=None,
        show_envvar=None,
    ):
        self.name, self.opts, self.secondary_opts = self._parse_decls(param_decls or ())
        self.type = _to_type(type) if type is not None else None
        self.required = required
        self.default = default
        self.callback = callback
        self.nargs = nargs
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.envvar = envvar
        self.shell_complete_func = shell_complete
        self.deprecated = deprecated
        self.hidden = hidden
        self.help = help
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None

    # -- declaration -------------------------------------------------------

    def _parse_decls(self, decls):
        raise NotImplementedError

    def _finish_type(self):
        if self.type is None:
            inferred = None
            if self.default is not None and not callable(self.default):
                probe = self.default
                if self.multiple or (self.nargs not in (None, 1)):
                    seq = probe if isinstance(probe, (list, tuple)) else None
                    if seq:
                        probe = seq[0]
                inferred = infer_type(probe)
            self.type = inferred or STRING
        if self.nargs is not None and (not isinstance(self.nargs, int) or self.nargs == 0 or self.nargs < -1):
            raise DeclarationError("nargs must be a positive integer, or -1 for variadic.")
        if isinstance(self.type, Tuple) and self.nargs is None:
            self.nargs = len(self.type.types)

    def _check_declaration(self):
        if self.deprecated and self.required:
            raise DeclarationError(f"{self.name}: a deprecated parameter cannot also be required.")

    # -- helpers -----------------------------------------------------------

    @property
    def per_occurrence_arity(self):
        if isinstance(self.type, Tuple):
            return len(self.type.types)
        return self.nargs or 1

    def get_error_hint(self):
        raise NotImplementedError

    def get_metavar(self, ctx=None):
        if self.metavar is not None:
            return self.metavar
        return self._default_metavar()

    def _default_metavar(self):
        return self.name.upper()

    def shell_complete(self, ctx, incomplete):
        if self.shell_complete_func is not None:
            return self.shell_complete_func(ctx, self, incomplete)
        return self.type.shell_complete(ctx, self, incomplete)

    def is_variadic(self):
        return False

    def _env_names(self, ctx):
        names = []
        if self.envvar:
            names.extend([self.envvar] if isinstance(self.envvar, str) else list(self.envvar))
        return names

    def _split_env_value(self, raw):
        splitter = getattr(self.type, "envvar_list_splitter", None)
        if isinstance(self.type, Tuple):
            return raw.split()
        if splitter:
            return [p for p in raw.split(splitter)]
        return raw.split()

    def _read_environment(self, ctx):
        """Return (raw_value_or_None) from explicit env names, first set wins."""
        for name in self._env_names(ctx):
            value = os.environ.get(name)
            if value is None or value == "":
                continue
            return value
        return None

    def _is_splitting(self):
        return self.multiple or self.per_occurrence_arity != 1 or self.is_variadic()

    def _convert_one(self, value, ctx):
        return self.type.convert(value, self, ctx)

    def convert_occurrence(self, tokens, ctx):
        """Convert one occurrence (a single token, or a tuple of tokens for nargs>1)."""
        if isinstance(self.type, Tuple):
            return self.type.convert(tuple(tokens), self, ctx)
        if self.nargs not in (None, 1) and not self.is_variadic():
            return tuple(self._convert_one(t, ctx) for t in tokens)
        if self.is_variadic():
            return tuple(self._convert_one(t, ctx) for t in tokens)
        return self._convert_one(tokens[0], ctx)

    def resolve_envvar_value(self, ctx, raw):
        if self._is_splitting() and not isinstance(self.type, Tuple):
            parts = self._split_env_value(raw)
            return self._coerce_list(parts, ctx)
        if isinstance(self.type, Tuple):
            parts = raw.split()
            return self.convert_occurrence(parts, ctx)
        return self._convert_one(raw, ctx)

    def _coerce_list(self, parts, ctx):
        return tuple(self._convert_one(p, ctx) for p in parts)

    def default_value(self, ctx):
        dv = self.default
        if callable(dv):
            dv = dv()
        return dv

    def process_value(self, value, ctx, source, ctx_source=None):
        """Apply the parameter callback. Refusals raise BadParameter."""
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value


class Option(Parameter):
    param_type_name = "option"

    def __init__(self, param_decls=None, cls=None, is_flag=None, flag_value=None, count=False,
                 prompt=False, prompt_required=True, hide_input=False,
                 confirmation_prompt=False, allow_from_autoenv=True, **attrs):
        self.is_flag = is_flag
        self.flag_value = flag_value
        self.count = count
        self.prompt = prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.allow_from_autoenv = allow_from_autoenv
        self._prompt_text_override = prompt if isinstance(prompt, str) else None
        super().__init__(param_decls, **attrs)
        if self.is_flag is None:
            self.is_flag = bool(self.secondary_opts) or isinstance(self.default, bool)
        if self.count:
            self.is_flag = False
        if self.flag_value is None and self.is_flag:
            self.flag_value = not (self.default is True)
        self._check_declaration()
        self._finish_type()
        if self.is_flag:
            if self.type is None or self.type is STRING:
                self.type = BOOL
            if self.default is None:
                self.default = False
            self.nargs = 0 if self.nargs is None else self.nargs
        if self.count:
            self.nargs = 0
        if self.is_flag and self.prompt is not False:
            raise DeclarationError("A flag option cannot take a prompt.")
        if self.deprecated and self.prompt:
            raise DeclarationError("A deprecated option cannot use a prompt.")
        if self.nargs is None:
            self.nargs = 1

    # -- declaration -------------------------------------------------------

    def _parse_decls(self, decls):
        opts, secondary = [], []
        name = None
        for decl in decls:
            if not decl:
                continue
            if decl[0] in _PREFIX_CHARS + ("/", "+") and not decl.isidentifier():
                if "/" in decl[1:] and decl[0] in _PREFIX_CHARS:
                    first, second = decl.split("/", 1)
                    opts.append(first)
                    secondary.append(second)
                    self._pair = True
                    continue
                opts.append(decl)
            elif decl.isidentifier():
                name = decl
            else:
                opts.append(decl)
        if name is None:
            name = self._infer_name(opts)
        return name, opts, secondary

    def _infer_name(self, opts):
        candidates = [o for o in opts]
        for o in candidates:
            bare = o.lstrip("-/+")
            if bare.isidentifier():
                return bare
        longs = [o for o in candidates if o.startswith("--")]
        shorts = [o for o in candidates if not o.startswith("--")]
        pick = (longs or shorts or ["x"])[0]
        return pick.lstrip("-/+").replace("-", "_")

    def get_error_hint(self):
        return "/".join(self.opts) if self.opts else self.name

    def _default_metavar(self):
        if self.is_flag or self.count:
            return None
        return self.type.get_metavar(self) or self.type.name.upper()

    def get_metavar(self, ctx=None):
        if self.metavar is not None:
            return self.metavar
        return self._default_metavar()

    def all_names(self):
        return list(self.opts) + list(self.secondary_opts)

    # -- value resolution --------------------------------------------------

    def value_from_env(self, ctx):
        """Return the value supplied by the environment, or None (ENV tier)."""
        names = self._env_names(ctx)
        auto = None
        prefix = ctx.auto_envvar_prefix if ctx is not None else None
        if prefix and self.allow_from_autoenv:
            auto = ctx.auto_envvar_name(self)
            if auto:
                names = names + [auto]
        for name in names:
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            if self.is_flag:
                return self._flag_from_env(raw, ctx)
            return self.resolve_envvar_value(ctx, raw)
        return None

    def _flag_from_env(self, raw, ctx):
        """Boolean flag environment rules (FP-03). Returns None to mean "unset"."""
        text = raw.strip().lower()
        bool_flag = isinstance(self.flag_value, bool)
        if not bool_flag and raw == str(self.flag_value):
            return self.flag_value
        if text in _TRUE_ENV:
            return self.flag_value
        if text in _FALSE_ENV:
            return False
        if not bool_flag:
            return None  # unrecognized or empty values are unset for non-boolean flag values
        if text == "":
            return False
        raise UsageError(f"Invalid value for {self.get_error_hint()}: {raw!r} is not a valid flag value.", ctx)

    def convert_list(self, values, ctx):
        """Convert repeatable occurrences (already tokenized) into the delivered value."""
        return tuple(self.convert_occurrence(v, ctx) for v in values)


class Argument(Parameter):
    param_type_name = "argument"

    def __init__(self, param_decls=None, cls=None, required=None, nargs=None, **attrs):
        self._required_explicit = required
        super().__init__(param_decls, required=required, nargs=nargs, **attrs)
        self._check_declaration()
        self._finish_type()
        if self.nargs is None:
            self.nargs = 1
        if self.required is None:
            self.required = self.default is None
        self._check_argument_rules()

    def _parse_decls(self, decls):
        if len(decls) != 1:
            raise DeclarationError("An argument takes exactly one destination name.")
        name = decls[0]
        if name.startswith("-"):
            raise DeclarationError("An argument name cannot start with a dash.")
        return name, [], []

    def _check_argument_rules(self):
        if self.deprecated and self.required:
            raise DeclarationError("A deprecated argument cannot be required.")
        if self.deprecated and self.default is None and not self._required_explicit:
            raise DeclarationError("A deprecated argument cannot be left without a default.")

    def _default_metavar(self):
        return self.name.upper()

    def get_error_hint(self):
        return self.get_metavar()

    def is_variadic(self):
        return self.nargs == -1

    def value_from_env(self, ctx):
        raw = self._read_environment(ctx)
        if raw is None:
            return None
        if self.is_variadic() or self.nargs not in (None, 1):
            return self.resolve_envvar_value(ctx, raw)
        return self._convert_one(raw, ctx)

    def convert_list(self, values, ctx):
        if self.is_variadic():
            return tuple(self._convert_one(v, ctx) for v in values)
        if self.nargs == 1:
            return self._convert_one(values[0], ctx)
        return tuple(self._convert_one(v, ctx) for v in values)


def resolve_value_sources(param, ctx, cmdline_value, has_cmdline, prompt_flag_pending):
    """Pick a value by source rank. Returns (value, source) with source None if none applies.

    Ranking (FP-03): prompt, command line, environment, default map, declared default.
    The prompt tier actually runs only when no command-line value exists.
    """
    if has_cmdline:
        return cmdline_value, ParameterSource.COMMANDLINE

    env_value = param.value_from_env(ctx) if hasattr(param, "value_from_env") else None
    if env_value is not None:
        return env_value, ParameterSource.ENVIRONMENT

    dm_value = ctx.default_map_value(param) if ctx is not None else None
    dm_present = dm_value is not None

    if isinstance(param, Option) and param.prompt and (param.prompt_required or prompt_flag_pending):
        if dm_present:
            default = dm_value
        elif param.default is not None:
            default = param.default_value(ctx)
        else:
            default = None
        text = param._prompt_text_override or param.name.replace("_", " ").capitalize()
        value = utils.prompt(
            text,
            default=default,
            hide_input=param.hide_input,
            confirmation_prompt=param.confirmation_prompt,
            type=param.type,
        )
        return value, ParameterSource.PROMPT

    if dm_present:
        return dm_value, ParameterSource.DEFAULT_MAP

    if param.default is not None:
        return param.default_value(ctx), ParameterSource.DEFAULT
    return None, None


def convert_default_map(param, value, ctx):
    """Default-map strings are split for non-unary parameters; refused for single-value repeatables."""
    if isinstance(value, str):
        if param.multiple and param.per_occurrence_arity == 1 and not param.is_variadic():
            raise BadParameter(
                f"{param.get_error_hint()} needs an iterable (sequence) default, not a string.",
                ctx,
                param,
            )
        if param._is_splitting() and not isinstance(param.type, Tuple):
            return tuple(param._convert_one(p, ctx) for p in param._split_env_value(value))
        if isinstance(param.type, Tuple):
            return param.convert_occurrence(value.split(), ctx)
        return param._convert_one(value, ctx)
    return value
