"""Declaration decorators (FP-01, FP-02, FP-03, FP-08; Interface Contract sections 3, 4 and 6)."""

import functools
import importlib.metadata
import sys

from .core import Command, Group, get_current_context
from .exceptions import Exit
from .params import Argument, Option
from . import utils


def _attach(f, param):
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)


def _pop_params(f):
    params = getattr(f, "__optlyn_params__", [])
    try:
        del f.__optlyn_params__
    except AttributeError:
        pass
    return list(reversed(params))


def _derive_name(func_name):
    name = func_name.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _with_doc(f, attrs):
    """The docstring is the description unless an explicit help string is given (FP-02)."""
    attrs = dict(attrs)
    if attrs.get("help") is None and f.__doc__:
        attrs["help"] = f.__doc__
    return attrs


def command(name=None, cls=None, **attrs):
    """Turn a function into a leaf command. Usable as ``@command`` or ``@command()``."""
    if callable(name) and not isinstance(name, str):
        return command()(name)

    def decorator(f):
        params = _pop_params(f)
        cmd_name = name if name is not None else _derive_name(f.__name__)
        cls_ = cls or Command
        return cls_(cmd_name, callback=f, params=params, **_with_doc(f, attrs))

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a group. Usable as ``@group`` or ``@group()``."""
    if callable(name) and not isinstance(name, str):
        return group()(name)

    def decorator(f):
        params = _pop_params(f)
        cmd_name = name if name is not None else _derive_name(f.__name__)
        cls_ = cls or Group
        return cls_(cmd_name, callback=f, params=params, **_with_doc(f, attrs))

    return decorator


def option(*param_decls, cls=None, **attrs):
    def decorator(f):
        _attach(f, (cls or Option)(param_decls, **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    def decorator(f):
        _attach(f, (cls or Argument)(param_decls, **attrs))
        return f

    return decorator


def _invoke_help(ctx):
    utils.echo(ctx.get_help(), file=sys.stdout)
    raise Exit(0)


def _help_callback(ctx, param, value):
    if not value:
        return
    _invoke_help(ctx)


def help_option(*param_decls, **kwargs):
    """An extra eager help flag; prints help and exits 0 (FP-02)."""
    decls = param_decls or ("--help",)

    def decorator(f):
        opts = dict(
            is_flag=True,
            expose_value=False,
            is_eager=True,
            help=kwargs.pop("help", "Show this message and exit."),
            callback=_help_callback,
        )
        opts.update(kwargs)
        _attach(f, Option(decls, **opts))
        return f

    return decorator


def _detect_version(package_name):
    try:
        return importlib.metadata.version(package_name)
    except importlib.metadata.PackageNotFoundError:
        pass
    mapping = importlib.metadata.packages_distributions()
    for dist_name in mapping.get(package_name, []):
        try:
            return importlib.metadata.version(dist_name)
        except importlib.metadata.PackageNotFoundError:
            continue
    raise RuntimeError(f"Could not detect a version for {package_name!r}.")


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """Eager ``--version`` flag printing a version identity and exiting 0 (FP-02)."""
    decls = param_decls or ("--version",)

    def callback(ctx, param, value):
        if not value:
            return
        ident = version
        if ident is None:
            ident = _detect_version(package_name or ctx.root.info_name)
        name = prog_name or ctx.root.info_name
        template = message or "%(prog)s, version %(version)s"
        utils.echo(template % {"prog": name, "package": package_name, "version": ident}, file=sys.stdout)
        raise Exit(0)

    def decorator(f):
        opts = dict(is_flag=True, expose_value=False, is_eager=True, callback=callback,
                    help="Show the version and exit.")
        opts.update(kwargs)
        _attach(f, Option(decls, **opts))
        return f

    return decorator


def custom_version_option(callback_fn, *param_decls, **kwargs):
    """Eager version flag whose identity is exactly ``callback_fn(ctx)`` plus a newline (FP-02)."""
    decls = param_decls or ("--version",)

    def callback(ctx, param, value):
        if not value:
            return
        utils.echo(callback_fn(ctx), file=sys.stdout)
        raise Exit(0)

    def decorator(f):
        opts = dict(is_flag=True, expose_value=False, is_eager=True, callback=callback,
                    help="Show the version and exit.")
        opts.update(kwargs)
        _attach(f, Option(decls, **opts))
        return f

    return decorator


def password_option(*param_decls, **kwargs):
    """Prompting, hidden, confirmed option (FP-08)."""
    decls = param_decls or ("--password",)

    def decorator(f):
        opts = dict(prompt=True, hide_input=True, confirmation_prompt=True)
        opts.update(kwargs)
        _attach(f, Option(decls, **opts))
        return f

    return decorator


def confirmation_option(*param_decls, **kwargs):
    """A yes-flag that asks when omitted and aborts when declined (FP-08)."""
    decls = param_decls or ("--yes",)
    text = kwargs.pop("prompt", "Do you want to continue?")

    def callback(ctx, param, value):
        if not value:
            utils.confirm(text, default=False, abort=True)
        return value

    def decorator(f):
        opts = dict(is_flag=True, expose_value=False, callback=callback,
                    help="Confirm the action without prompting.")
        opts.update(kwargs)
        _attach(f, Option(decls, **opts))
        return f

    return decorator


def pass_context(f):
    """Pass the current Context as the first positional argument (FP-07)."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    """Pass the current context's ``obj`` as the first positional argument (FP-07)."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Pass the nearest object of ``object_type``; with ``ensure`` create one when missing (FP-07)."""

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            return f(obj, *args, **kwargs)

        return new_func

    return decorator
