"""POSIX-style token parser for one command level (FP-01, FP-03, FP-04, FP-10)."""

from .exceptions import BadOptionUsage, NoSuchOption, UsageError
from .params import Argument, Option


class ParseResult:
    def __init__(self):
        self.occurrences = {}  # id(param) -> list of raw occurrences
        self.counts = {}  # id(param) -> int, for counting options
        self.present = set()  # id(param) of parameters given on the command line
        self.prompt_pending = set()  # id(param) of prompting options given without a value
        self.eager_fired = set()  # id(param) of eager parameters whose callback already ran
        self.values = {}  # id(param) -> converted-ready value (arguments and flags)
        self.rest = []  # tokens that belong to a subcommand (groups only)
        self.extra = []  # leftover tokens tolerated by allow_extra_args


class Parser:
    def __init__(self, ctx, command, interspersed=True):
        self.ctx = ctx
        self.command = command
        self.interspersed = interspersed
        self.result = ParseResult()
        self.lookup = {}
        self.help_names = set()
        self.options = [p for p in command.get_params() if isinstance(p, Option)]
        self.arguments = [p for p in command.get_params() if isinstance(p, Argument)]
        # Only prefixes the author declared (besides "-") make a token option-shaped (FP-03).
        self.prefixes = {"-"}
        for p in self.options:
            for name in p.all_names():
                if name and not name[0].isalnum():
                    self.prefixes.add(name[0])
                self.lookup[self._norm(name)] = (p, name in p.secondary_opts)
        if command.help_option_enabled(ctx):
            for name in ctx.help_option_names:
                key = self._norm(name)
                if key not in self.lookup:
                    self.help_names.add(key)

    def _norm(self, name):
        normalize = self.ctx.token_normalize_func
        return normalize(name) if normalize else name

    def _is_option_like(self, tok):
        return len(tok) > 1 and tok[0] in self.prefixes

    def _fire_eager(self, param):
        # Eager callbacks run as soon as the flag is typed, so the first one typed wins (FP-02).
        if param.is_eager and param.callback is not None:
            self.result.eager_fired.add(id(param))
            param.callback(self.ctx, param, True)

    def _mark_present(self, param):
        self.result.present.add(id(param))
        if param.deprecated and self.ctx is not None:
            self.command.warn_deprecated_param(self.ctx, param)

    def _take_values(self, param, tokens, i, eq_value):
        """Consume the value tokens of a value-taking option. Returns (tokens, new_index)."""
        arity = param.nargs or 1
        if eq_value is not None:
            vals = [eq_value]
            if arity > 1:
                raise BadOptionUsage(f"Option {param.get_error_hint()} requires {arity} values.", self.ctx)
            return vals, i
        if param.flag_value is not None and not param.is_flag and arity == 1:
            if i < len(tokens) and not self._is_option_like(tokens[i]):
                return [tokens[i]], i + 1
            return [param.flag_value], i
        vals = []
        j = i
        while len(vals) < arity and j < len(tokens):
            if tokens[j] == "--":
                break
            vals.append(tokens[j])
            j += 1
        if len(vals) < arity:
            if param.prompt:
                self.result.prompt_pending.add(id(param))
                return None, j
            raise BadOptionUsage(f"Option {param.get_error_hint()} requires an argument.", self.ctx)
        return vals, j

    def _add_occurrence(self, param, value):
        self.result.occurrences.setdefault(id(param), []).append(value)

    def _apply_option(self, param, secondary, tokens, i, eq_value):
        """Apply one option. Returns the new token index."""
        self._mark_present(param)
        if param.count:
            self.result.counts[id(param)] = self.result.counts.get(id(param), 0) + 1
            self._fire_eager(param)
            return i
        if param.is_flag:
            if eq_value is not None:
                raise BadOptionUsage(f"Option {param.get_error_hint()} does not take a value.", self.ctx)
            value = (not param.flag_value) if secondary else param.flag_value
            self._add_occurrence(param, value)
            self._fire_eager(param)
            return i
        vals, j = self._take_values(param, tokens, i, eq_value)
        if vals is None:
            self.result.occurrences.setdefault(id(param), [])
            return j
        arity = param.nargs or 1
        occ = tuple(vals) if arity > 1 else vals[0]
        self._add_occurrence(param, occ)
        self._fire_eager(param)
        return j

    def _is_help(self, key):
        return key in self.help_names

    def parse(self, args):
        tokens = list(args)
        r = self.result
        i = 0
        positional = []
        after_dd = False
        capacity = self._capacity()
        while i < len(tokens):
            tok = tokens[i]
            if after_dd:
                positional.append(tok)
                i += 1
                continue
            if tok == "--":
                after_dd = True
                i += 1
                continue
            if not self._is_option_like(tok):
                if not self.interspersed and capacity is not None and len(positional) >= capacity:
                    r.rest = tokens[i:]
                    break
                positional.append(tok)
                i += 1
                continue
            # option-shaped token
            i = self._parse_option_token(tokens, i, positional)
        self._distribute(positional)
        return r

    def _capacity(self):
        total = 0
        for a in self.arguments:
            if a.is_variadic():
                return None
            total += a.nargs
        return total

    def _parse_option_token(self, tokens, i, positional):
        tok = tokens[i]
        if tok.startswith("--") or tok[0] != "-":
            name, eq = (tok.split("=", 1) + [None])[:2]
            key = self._norm(name)
            if key in self.lookup:
                param, secondary = self.lookup[key]
                return self._apply_option(param, secondary, tokens, i + 1, eq)
            if self._is_help(key):
                return self._help_hit(i + 1)
            if self.ctx and self.ctx.ignore_unknown_options:
                positional.append(tok)
                return i + 1
            raise NoSuchOption(f"No such option: {name}", self.ctx, self.command)
        # short option stack, e.g. -abc or -ofile
        prefix = tok[0]
        chars = tok[1:]
        for pos, ch in enumerate(chars):
            name = prefix + ch
            key = self._norm(name)
            if key in self.lookup:
                param, secondary = self.lookup[key]
                rest_stack = chars[pos + 1:]
                if not param.is_flag and not param.count:
                    eq = rest_stack if rest_stack else None
                    return self._apply_option(param, secondary, tokens, i + 1, eq)
                self._apply_option(param, secondary, tokens, i + 1, None)
                continue
            if self._is_help(key):
                return self._help_hit(i + 1)
            leftover = prefix + chars[pos:]
            if self.ctx and self.ctx.ignore_unknown_options:
                positional.append(leftover)
                return i + 1
            raise NoSuchOption(f"No such option: {name}", self.ctx, self.command)
        return i + 1

    def _help_hit(self, next_index):
        from .decorators import _invoke_help

        _invoke_help(self.ctx)
        return next_index

    def _distribute(self, positional):
        r = self.result
        args = self.arguments
        pos = list(positional)
        for idx, a in enumerate(args):
            if a.is_variadic():
                later_fixed = sum(b.nargs for b in args[idx + 1:] if not b.is_variadic())
                take = max(0, len(pos) - later_fixed)
                r.values[id(a)] = pos[:take]
                pos = pos[take:]
                continue
            if len(pos) == 0:
                r.values[id(a)] = None
                continue
            take = min(a.nargs, len(pos))
            if take < a.nargs:
                r.values[id(a)] = pos[:take]
                pos = pos[take:]
                continue
            r.values[id(a)] = pos[: a.nargs]
            pos = pos[a.nargs :]
        if pos:
            if not (self.ctx and self.ctx.allow_extra_args):
                raise UsageError(f"Got unexpected extra argument(s): {' '.join(pos)}", self.ctx, self.command)
            r.extra.extend(pos)
