"""Text wrapping and help-page layout helpers."""

import shutil
import textwrap

DEFAULT_WRAP_WIDTH = 100


def terminal_columns():
    return shutil.get_terminal_size((80, 24)).columns


def wrap_text(text, width=None, initial_indent="", subsequent_indent="", preserve_paragraphs=False):
    """Wrap ``text`` to ``width`` columns. Without ``width``, the caller-visible default is used."""
    if width is None:
        width = min(terminal_columns(), DEFAULT_WRAP_WIDTH)
    width = max(width, 1)
    if not preserve_paragraphs:
        paragraphs = [" ".join(text.split())]
    else:
        paragraphs = [" ".join(p.split()) for p in text.split("\n\n")]
    lines = []
    for p in paragraphs:
        if not p:
            lines.append("")
            continue
        wrapper = textwrap.TextWrapper(
            width=width,
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
            break_long_words=False,
            break_on_hyphens=False,
        )
        lines.append(wrapper.fill(p))
    return "\n\n".join(lines) if preserve_paragraphs else "".join(lines)


def split_help_paragraphs(text):
    """Split help text into blocks. A ``\\b`` first line keeps its own line breaks."""
    blocks = []
    current = []
    for line in text.splitlines():
        if line.strip() == "":
            if current:
                blocks.append(current)
                current = []
        else:
            current.append(line)
    if current:
        blocks.append(current)
    return blocks


def format_help_text(text, width, indent=""):
    """Rewrap help text to ``width``, keeping ``\\b`` paragraphs unwrapped."""
    out = []
    for block in split_help_paragraphs(text):
        if block[0].strip() == "\b":
            body = [line for line in block[1:]]
            out.extend(indent + line.rstrip() for line in body)
        else:
            joined = " ".join(line.strip() for line in block)
            out.append(textwrap.fill(joined, width=max(width, 1), initial_indent=indent,
                                     subsequent_indent=indent, break_long_words=False,
                                     break_on_hyphens=False))
        out.append("")
    if out and out[-1] == "":
        out.pop()
    return "\n".join(out)


def make_short_help(text, max_length):
    """First sentence of the help text, ellipsized to ``max_length`` characters."""
    blocks = split_help_paragraphs(text)
    if not blocks:
        return ""
    joined = " ".join(line.strip() for line in blocks[0])
    end = joined.find(". ")
    sentence = joined if end == -1 else joined[: end + 1]
    if len(sentence) > max_length:
        sentence = sentence[: max(max_length - 3, 0)].rstrip() + "..."
    return sentence


class HelpFormatter:
    """Accumulates a help page: usage, description, sections of two-column rows."""

    def __init__(self, width=80, col_max=30, col_spacing=2, indent_increment=2):
        self.width = width
        self.col_max = col_max
        self.col_spacing = col_spacing
        self.indent_increment = indent_increment
        self.buffer = []

    def write(self, text=""):
        self.buffer.append(text)

    def write_usage(self, usage_line):
        self.write(usage_line)
        self.write("")

    def write_text(self, text):
        self.write(format_help_text(text, self.width))
        self.write("")

    def write_heading(self, heading):
        self.write(f"{heading}:")

    def write_dl(self, rows):
        if not rows:
            return
        first_col = min(max(len(first) for first, _ in rows) + self.col_spacing, self.col_max)
        indent = " " * self.indent_increment
        help_width = max(self.width - first_col - self.indent_increment, 10)
        for first, second in rows:
            if not second:
                self.write(f"{indent}{first}")
                continue
            wrapped = textwrap.wrap(" ".join(second.split()), width=help_width,
                                    break_long_words=False, break_on_hyphens=False)
            if len(first) + self.col_spacing > first_col:
                self.write(f"{indent}{first}")
                pad = " " * (first_col + self.indent_increment)
                for line in wrapped:
                    self.write(pad + line)
            else:
                pad = " " * (first_col - len(first) + self.indent_increment)
                self.write(f"{indent}{first}{pad}{wrapped[0] if wrapped else ''}".rstrip())
                for line in wrapped[1:]:
                    self.write(" " * (first_col + self.indent_increment) + line)
        self.write("")

    def getvalue(self):
        while self.buffer and self.buffer[-1] == "":
            self.buffer.pop()
        return "\n".join(self.buffer) + "\n"
