"""File and standard-stream helpers shared by the file type and terminal helpers."""

import io
import os
import sys
import tempfile

from .exceptions import FileError


def format_filename(filename, shorten=False):
    """Return a printable text form of a filename that always encodes as UTF-8."""
    if isinstance(filename, (bytes, bytearray)):
        filename = os.fsdecode(bytes(filename))
    else:
        filename = os.fspath(filename)
    if shorten:
        filename = os.path.basename(filename)
    return filename.encode("utf-8", "backslashreplace").decode("utf-8")


class _StdProxy:
    """Wraps a standard stream so that closing it does not close the process stream."""

    def __init__(self, stream):
        self._stream = stream

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def close(self):
        try:
            self._stream.flush()
        except (OSError, ValueError):
            pass

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def __del__(self):
        stream = self.__dict__.get("_stream")
        if isinstance(stream, io.TextIOWrapper):
            try:
                stream.detach()
            except (OSError, ValueError):
                pass


def std_stream(writing, mode="r", encoding=None, errors="strict"):
    """Return the standard input (reading) or output (writing) stream for ``-``."""
    stream = sys.stdout if writing else sys.stdin
    buf = getattr(stream, "buffer", None)
    if "b" in mode:
        return _StdProxy(buf if buf is not None else stream)
    if encoding is None or buf is None:
        return _StdProxy(stream)
    wrapper = io.TextIOWrapper(buf, encoding=encoding, errors=errors, write_through=True)
    return _StdProxy(wrapper)


def _writing(mode):
    return any(c in mode for c in "wax+")


class AtomicFile:
    """Writes to a sibling temporary file that replaces the target when closed."""

    def __init__(self, filename, mode, encoding=None, errors="strict"):
        self.name = filename
        self._target = filename
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        os.close(fd)
        mode = mode.replace("x", "w").replace("a", "w")
        binary = "b" in mode
        self._file = open(
            self._tmp, mode,
            encoding=None if binary else encoding,
            errors=None if binary else errors,
        )
        self._closed = False

    def __getattr__(self, name):
        return getattr(self._file, name)

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._file.close()
        os.replace(self._tmp, self._target)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        if exc_type is None:
            self.close()
        else:
            self._closed = True
            self._file.close()
            try:
                os.remove(self._tmp)
            except OSError:
                pass


def _open_now(filename, mode, encoding, errors, atomic):
    if atomic and _writing(mode):
        return AtomicFile(filename, mode, encoding, errors)
    binary = "b" in mode
    return open(
        filename, mode,
        encoding=None if binary else encoding,
        errors=None if binary else errors,
    )


class LazyFile:
    """Opens its file on first use; open failures become general file errors."""

    def __init__(self, filename, mode, encoding=None, errors="strict", atomic=False):
        self.name = filename
        self._args = (mode, encoding, errors, atomic)
        self._file = None

    def _ensure(self):
        if self._file is None:
            mode, encoding, errors, atomic = self._args
            try:
                self._file = _open_now(self.name, mode, encoding, errors, atomic)
            except OSError as e:
                raise FileError(self.name, e.strerror or str(e)) from e
        return self._file

    def __getattr__(self, name):
        return getattr(self._ensure(), name)

    def __iter__(self):
        return iter(self._ensure())

    def close(self):
        if self._file is not None:
            self._file.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open ``filename``; ``-`` is standard input for reading and output for writing."""
    if filename == "-":
        return std_stream(_writing(mode), mode, encoding, errors)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    return _open_now(filename, mode, encoding, errors, atomic)
