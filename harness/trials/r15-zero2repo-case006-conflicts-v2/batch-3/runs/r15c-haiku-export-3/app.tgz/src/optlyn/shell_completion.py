"""Shell completion: registration scripts and suggestion output for bash, zsh, fish and PowerShell."""

import os
import sys

from . import types as _types
from .core import Argument, Context, Group, Option
from .termui import echo

SHELLS = ("bash", "zsh", "fish", "powershell")

# Path requests are sent as ``\x1f<kind>\x1f<incomplete>``; the shell scripts expand them.
_PATH_SEP = "\x1f"


def completion_var_name(prog_name):
    return "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"


def handle_completion(cmd, prog_name, complete_var=None, standalone_mode=True):
    """Serve a completion request if the program was invoked in completion mode.

    Returns True when the request was handled (the caller must not run the command).
    """
    name = complete_var or completion_var_name(prog_name)
    instruction = os.environ.get(name)
    if not instruction:
        return False
    for shell in SHELLS:
        if instruction == f"{shell}_source":
            echo(_source_script(shell, prog_name, name))
            return _finish(standalone_mode, 0)
        if instruction == f"{shell}_complete":
            _emit_suggestions(cmd, prog_name, shell)
            return _finish(standalone_mode, 0)
    # An unrecognised instruction prints nothing and is not a successful run.
    return _finish(standalone_mode, 1)


def _finish(standalone_mode, code):
    if standalone_mode:
        sys.exit(code)
    return True


# --- registration scripts ----------------------------------------------------------------

def _source_script(shell, prog_name, var):
    fn = "_optlyn_complete_" + "".join(c if c.isalnum() else "_" for c in prog_name)
    if shell == "bash":
        return f"""{fn}() {{
    local cur="${{COMP_WORDS[COMP_CWORD]}}"
    local words="${{COMP_WORDS[*]}}"
    local out line p
    out=$(env COMP_WORDS="$words" COMP_CWORD="$COMP_CWORD" {var}=bash_complete "${{COMP_WORDS[0]}}")
    COMPREPLY=()
    while IFS= read -r line; do
        case "$line" in
            $'\\x1f'file$'\\x1f'*) while IFS= read -r p; do COMPREPLY+=("$p"); done < <(compgen -f -- "$cur") ;;
            $'\\x1f'dir$'\\x1f'*) while IFS= read -r p; do COMPREPLY+=("$p"); done < <(compgen -d -- "$cur") ;;
            *) COMPREPLY+=("${{line%%$'\\t'*}}") ;;
        esac
    done <<< "$out"
}}
complete -o default -F {fn} {prog_name}"""
    if shell == "zsh":
        return f"""#compdef {prog_name}
{fn}() {{
    local -a lines items
    local line value help
    lines=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete "${{words[1]}}")}}")
    for line in "${{lines[@]}}"; do
        case "$line" in
            $'\\x1f'file$'\\x1f'*) _files ;;
            $'\\x1f'dir$'\\x1f'*) _path_files -/ ;;
            *)
                value="${{line%%$'\\t'*}}"
                help="${{line#*$'\\t'}}"
                if [[ "$line" == *$'\\t'* ]]; then items+=("${{value//:/\\\\:}}:${{help}}"); else items+=("${{value//:/\\\\:}}"); fi
                ;;
        esac
    done
    (( ${{#items}} )) && _describe 'values' items
}}
compdef {fn} {prog_name}"""
    if shell == "fish":
        return f"""function {fn}
    set -l tok (commandline -ct)
    set -l exe (commandline -opc)[1]
    set -l out (env COMP_WORDS="(commandline -cp)" COMP_CWORD="$tok" {var}=fish_complete $exe)
    for line in $out
        switch $line
            case "*$(printf '\\x1f')file$(printf '\\x1f')*"
                __fish_complete_path $tok
            case "*$(printf '\\x1f')dir$(printf '\\x1f')*"
                __fish_complete_directories $tok
            case '*'
                printf '%s\\n' $line
        end
    end
end
complete -c {prog_name} -f -a '({fn})'"""
    return f"""Register-ArgumentCompleter -Native -CommandName '{prog_name}' -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $words = $commandAst.ToString()
    $cword = $commandAst.CommandElements.Count
    if ($wordToComplete -eq '') {{ $cword = $cword }} else {{ $cword = $cword - 1 }}
    $env:COMP_WORDS = $words
    $env:COMP_CWORD = $cword
    $env:{var} = 'powershell_complete'
    $out = & $commandAst.CommandElements[0].Value
    Remove-Item Env:\\{var}
    foreach ($line in $out) {{
        if ($line.StartsWith([char]0x1f)) {{ continue }}
        $v = $line.Split("`t")[0]
        [System.Management.Automation.CompletionResult]::new($v, $v, 'ParameterValue', $v)
    }}
}}"""


# --- suggestions -------------------------------------------------------------------------

def _emit_suggestions(cmd, prog_name, shell):
    if shell == "bash":
        words = os.environ.get("COMP_WORDS", "").split(" ")
        try:
            cword = int(os.environ.get("COMP_CWORD", "0"))
        except ValueError:
            cword = 0
        incomplete = words[cword] if cword < len(words) else ""
        args = words[1:cword]
    else:
        words = os.environ.get("COMP_WORDS", "").split(" ")
        incomplete = os.environ.get("COMP_CWORD", "")
        if len(words) > 1 and words[-1] == incomplete:
            args = words[1:-1]
        else:
            args = words[1:]
    items = _suggest(cmd, prog_name, args, incomplete)
    for item in items:
        echo(_format_item(item, shell))


def _format_item(item, shell):
    """Path requests are ``("path", kind, token)``; values are ``(value, help)``."""
    if len(item) == 3:
        _, kind, token = item
        return f"{_PATH_SEP}{kind}{_PATH_SEP}{token}"
    value, help_text = item
    if shell in ("zsh", "fish") and help_text:
        return f"{value}\t{help_text}"
    return value


def _path_request(param, incomplete):
    directories_only = isinstance(param.type, _types.Path) and not param.type.file_okay and param.type.dir_okay
    return ("path", "dir" if directories_only else "file", incomplete)


def _param_completions(ctx, param, incomplete):
    if param.shell_complete_func is None and isinstance(param.type, (_types.File, _types.Path)):
        return [_path_request(param, incomplete)]
    results = []
    for entry in param.shell_complete(ctx, incomplete):
        results.append(_normalize_entry(entry))
    return results


def _normalize_entry(entry):
    """Turn a completion entry (str or object with value/help/type) into an output item."""
    if isinstance(entry, str):
        return (entry, None)
    value = getattr(entry, "value", None)
    kind = getattr(entry, "type", "plain")
    if kind in ("file", "dir"):
        return ("path", kind, value)
    return (value, getattr(entry, "help", None))


def _suggest(cmd, prog_name, args, incomplete):
    ctx = Context(cmd, info_name=prog_name)
    current = cmd
    pending = None
    positional = 0
    i = 0
    while i < len(args):
        tok = args[i]
        i += 1
        if pending is not None:
            pending = None
            continue
        if tok == "--":
            break
        if len(tok) > 1 and tok[0] in "-/+":
            opt = _find_option(ctx, current, tok)
            if opt is not None and not opt.is_flag and "=" not in tok:
                pending = opt
            continue
        if isinstance(current, Group):
            child = current.get_command(ctx, tok)
            if child is not None:
                current = child
                ctx = Context(child, info_name=tok, parent=ctx)
                positional = 0
                continue
        positional += 1

    if pending is not None:
        return _param_completions(ctx, pending, incomplete)

    if incomplete[:1] and incomplete[0] in "-/+":
        results = []
        for p in current.get_params(ctx):
            if not isinstance(p, Option) or p.hidden:
                continue
            for flag in p.opts + p.secondary_opts:
                if flag.startswith(incomplete):
                    results.append((flag, p.help))
        return results

    results = []
    if isinstance(current, Group):
        for name in current.list_commands(ctx):
            child = current.get_command(ctx, name)
            if child is None or child.hidden or not name.startswith(incomplete):
                continue
            results.append((name, child.get_short_help_str()))
    arguments = [p for p in current.get_params(ctx) if isinstance(p, Argument)]
    if positional < len(arguments) and not isinstance(current, Group):
        results.extend(_param_completions(ctx, arguments[positional], incomplete))
    return results


def _find_option(ctx, cmd, tok):
    for p in cmd.get_params(ctx):
        if isinstance(p, Option) and tok in p.opts + p.secondary_opts:
            return p
    return None
