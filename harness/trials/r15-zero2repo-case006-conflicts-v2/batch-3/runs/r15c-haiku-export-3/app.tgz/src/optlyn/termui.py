"""Terminal helpers: echo, styling, prompts, pager, progress bars, editor and launch."""

import contextlib
import getpass as _getpass
import io
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time

from . import _files
from ._local import get_current_context
from .exceptions import Abort, OptlynError

_ANSI_RE = re.compile(r"\033\[[0-9;?]*[ -/]*[@-~]")

_FG_COLORS = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
    "reset": 39,
}

_STYLE_CODES = {
    "bold": (1, 22), "dim": (2, 22), "italic": (3, 23), "underline": (4, 24),
    "overline": (53, 55), "blink": (5, 25), "reverse": (7, 27), "strikethrough": (9, 29),
}


def isatty(stream):
    try:
        return bool(stream.isatty())
    except (AttributeError, ValueError):
        return False


def is_interactive():
    """A session is interactive when standard input or standard output is a terminal."""
    return isatty(sys.stdin) or isatty(sys.stdout)


def unstyle(text):
    """Remove ANSI escape sequences, leaving all other text."""
    return _ANSI_RE.sub("", text)


def _color_code(color, base):
    if isinstance(color, str):
        if color in _FG_COLORS:
            code = _FG_COLORS[color]
            if base == 48:
                code = 49 if color == "reset" else code + 10
            return str(code)
        raise TypeError(f"Unknown color {color!r}.")
    if isinstance(color, int) and not isinstance(color, bool) and 0 <= color <= 255:
        return f"{base};5;{color}"
    if (isinstance(color, (tuple, list)) and len(color) == 3
            and all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color)):
        return f"{base};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"Invalid color {color!r}.")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    """Wrap ``text`` in ANSI SGR escape sequences."""
    bits = []
    if fg is not None:
        bits.append(_color_code(fg, 38))
    if bg is not None:
        bits.append(_color_code(bg, 48))
    switches = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline,
        "italic": italic, "blink": blink, "reverse": reverse, "strikethrough": strikethrough,
    }
    for name, value in switches.items():
        if value is None:
            continue
        on, off = _STYLE_CODES[name]
        bits.append(str(on if value else off))
    if not bits:
        return text
    prefix = "\033[" + ";".join(bits) + "m"
    suffix = "\033[0m" if reset else ""
    return prefix + text + suffix


def _resolve_color(file, color):
    if color is None:
        ctx = get_current_context(silent=True)
        if ctx is not None and ctx.color is not None:
            color = ctx.color
    if color is None:
        return isatty(file)
    return bool(color)


def _write_text(file, text):
    try:
        file.write(text)
    except UnicodeEncodeError:
        buf = getattr(file, "buffer", None)
        if buf is None:
            raise
        file.flush()
        buf.write(text.encode("utf-8"))
        buf.flush()
        return
    try:
        file.flush()
    except (OSError, ValueError):
        pass


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes to standard output (or standard error when ``err`` is true)."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if isinstance(message, (bytes, bytearray)):
        data = bytes(message) + (b"\n" if nl else b"")
        buf = getattr(file, "buffer", file)
        buf.write(data)
        try:
            buf.flush()
        except (OSError, ValueError):
            pass
        return
    text = "" if message is None else str(message)
    if not _resolve_color(file, color):
        text = unstyle(text)
    if nl:
        text += "\n"
    _write_text(file, text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    echo(style("" if message is None else str(message), **styles), file=file, nl=nl, err=err, color=color)


class _PagerWriter:
    """A writable text stream that sends its text to standard output."""

    def __init__(self, color):
        self._color = color

    def write(self, text):
        echo(text, nl=False, color=self._color)
        return len(text)

    def flush(self):
        sys.stdout.flush()


def _pager_command():
    return os.environ.get("PAGER") or "less"


def _run_pager(chunks, color):
    proc = subprocess.Popen(_pager_command(), shell=True, stdin=subprocess.PIPE)
    try:
        for chunk in chunks:
            if not color:
                chunk = unstyle(chunk)
            proc.stdin.write(chunk.encode("utf-8", "replace"))
            proc.stdin.flush()
    except BrokenPipeError:
        pass
    finally:
        try:
            proc.stdin.close()
        except BrokenPipeError:
            pass
        proc.wait()


def echo_via_pager(text_or_generator, color=None):
    """Write long text through a pager when the session is interactive."""
    value = text_or_generator() if callable(text_or_generator) else text_or_generator
    chunks = [value] if isinstance(value, str) else value
    if not is_interactive():
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    _run_pager(chunks, _resolve_color(sys.stdout, color))


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream that goes through the pager when interactive."""
    if not is_interactive():
        yield _PagerWriter(color)
        return
    proc = subprocess.Popen(_pager_command(), shell=True, stdin=subprocess.PIPE)
    stream = io.TextIOWrapper(proc.stdin, encoding="utf-8", write_through=True)
    try:
        yield stream
    finally:
        try:
            stream.close()
        except BrokenPipeError:
            pass
        proc.wait()


class ProgressBar:
    """Iterable progress bar. Renders only when standard output is a terminal."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, file=None):
        self.iterable = iterable
        if length is None and iterable is not None and hasattr(iterable, "__len__"):
            length = len(iterable)
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.file = file or sys.stdout
        self.pos = 0
        self.start = time.time()
        self.is_tty = not hidden and isatty(self.file)
        self._label_printed = False
        self._finished = False

    def _print_label_once(self):
        if self.hidden or self._label_printed or isatty(self.file):
            return
        self._label_printed = True
        if self.label:
            echo(self.label, file=self.file)

    def _eta(self):
        if not self.length or self.pos == 0:
            return 0
        elapsed = time.time() - self.start
        return max(0, int(elapsed / self.pos * (self.length - self.pos)))

    def render_progress(self):
        if not self.is_tty:
            return
        if self.length:
            width = 30
            filled = int(width * min(self.pos, self.length) / self.length)
            bar = "#" * filled + "-" * (width - filled)
            text = f"\r{self.label} [{bar}] {self.pos}/{self.length} eta {self._eta()}s"
        else:
            text = f"\r{self.label} {self.pos}"
        self.file.write(text)
        self.file.flush()

    def update(self, n_steps):
        self.pos += n_steps
        self.render_progress()

    def finish(self):
        if self._finished:
            return
        self._finished = True
        if self.is_tty:
            self.file.write("\n")
            self.file.flush()

    def __iter__(self):
        if self.iterable is None:
            raise TypeError("Iterating a progress bar requires an iterable.")
        self._print_label_once()
        self.render_progress()
        for item in self.iterable:
            yield item
            self.update(1)
        self.finish()


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    bar = ProgressBar(iterable, length=length, label=label, hidden=hidden, file=options.get("file"))
    bar._print_label_once()
    try:
        yield bar
    finally:
        bar.finish()


def _read_line(prompt_text, hide_input=False, err=False):
    stream = sys.stderr if err else sys.stdout
    try:
        if hide_input and isatty(sys.stdin):
            return _getpass.getpass(prompt_text, stream=stream)
        echo(prompt_text, nl=False, err=err)
        line = sys.stdin.readline()
    except (EOFError, KeyboardInterrupt) as e:
        raise Abort() from e
    if line == "":
        raise Abort()
    line = line.rstrip("\r\n")
    if not hide_input and not isatty(sys.stdin) and not getattr(sys.stdin, "echoes_input", False):
        echo(line, err=err)
    return line


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    """Ask for a value, convert it, and re-ask until it converts or input ends."""
    from .types import convert_type

    ptype = convert_type(type, default)
    shown = f"{text}"
    if show_default and default is not None:
        shown += f" [{default}]"
    prompt_text = shown + prompt_suffix
    while True:
        value = _read_line(prompt_text, hide_input, err)
        if value == "" and default is not None:
            return ptype(default)
        try:
            result = ptype(value)
        except OptlynError as e:
            echo(f"Error: {e.format_message()}", err=True)
            continue
        if confirmation_prompt:
            again = _read_line(f"Repeat for confirmation{prompt_suffix}", hide_input, err)
            if again != value:
                echo("Error: The two entered values do not match.", err=True)
                continue
        return result


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question; an empty answer takes the default."""
    if show_default:
        hint = "[Y/n]" if default else "[y/N]"
        text = f"{text} {hint}"
    while True:
        answer = _read_line(text + prompt_suffix, False, err).strip().lower()
        if answer == "":
            result = default
            break
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        echo("Error: invalid input", err=err)
    if abort and not result:
        raise Abort()
    return result


def getchar(echo=False):
    """Read one character from the terminal, even when standard input is a pipe."""
    try:
        fd = os.open("/dev/tty", os.O_RDONLY | os.O_NOCTTY)
    except OSError:
        fd = None
    if fd is None or not os.isatty(fd):
        if fd is not None:
            os.close(fd)
        try:
            ch = sys.stdin.read(1)
        except (EOFError, ValueError) as e:
            raise EOFError() from e
    else:
        try:
            import termios
            import tty

            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                ch = os.read(fd, 1).decode("utf-8", "replace")
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        finally:
            os.close(fd)
    if ch == "":
        raise EOFError()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    if echo:
        sys.stdout.write(ch)
        sys.stdout.flush()
    return ch


def pause(info=None, err=False):
    """Print a message and wait for a key press when the session is interactive."""
    if not is_interactive():
        return
    echo(info if info is not None else "Press any key to continue...", err=err, nl=False)
    try:
        getchar()
    except (EOFError, KeyboardInterrupt):
        pass
    echo(err=err)


def _find_editor(env=None):
    for key in ("VISUAL", "EDITOR"):
        value = (env or {}).get(key) or os.environ.get(key)
        if value:
            return value
    return "notepad" if sys.platform == "win32" else "vi"


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open text (or a file) in an editor. Returns the saved text, or None."""
    command = editor or _find_editor(env)
    original = "" if text is None else text
    temp = filename is None
    if temp:
        fd, path = tempfile.mkstemp(suffix=extension)
        with os.fdopen(fd, "wb") as f:
            f.write(original.encode("utf-8"))
    else:
        path = filename
    try:
        environ = dict(os.environ)
        environ.update(env or {})
        rc = subprocess.call(shlex.split(command) + [path], env=environ)
        if rc != 0:
            raise OptlynError(f"Editor exited with status {rc}.")
        if not temp:
            return None
        with open(path, "rb") as f:
            result = f.read().decode("utf-8").replace("\r\n", "\n")
        if require_save and result == original:
            return None
        return result
    finally:
        if temp:
            try:
                os.remove(path)
            except OSError:
                pass


def launch(url, wait=False, locate=False):
    """Open a URL or file with the default application. Returns a status value."""
    if sys.platform == "win32":
        os.startfile(url)  # noqa: S606 - documented launch behaviour
        return 0
    if sys.platform == "darwin":
        command = ["open", "-R", url] if locate else ["open", url]
    else:
        target = os.path.dirname(os.path.abspath(url)) if locate else url
        command = ["xdg-open", target]
    try:
        proc = subprocess.Popen(command, stdin=subprocess.DEVNULL,
                                stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def clear():
    """Clear the visible terminal. Does nothing when standard output is not a terminal."""
    if not isatty(sys.stdout):
        return
    sys.stdout.write("\033[2J\033[1;1H")
    sys.stdout.flush()


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user configuration directory for ``app_name``."""
    home = os.path.expanduser("~")
    unix_name = re.sub(r"\s+", "-", app_name.lower())
    if force_posix and sys.platform != "win32":
        return os.path.join(home, "." + unix_name)
    if sys.platform == "win32":
        base = os.environ.get("APPDATA" if roaming else "LOCALAPPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    xdg = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(xdg, unix_name)


def format_filename(filename, shorten=False):
    return _files.format_filename(filename, shorten=shorten)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    return _files.open_file(filename, mode, encoding, errors, lazy=lazy, atomic=atomic)


def get_binary_stdin():
    return _files.std_stream(False, "rb")


def get_binary_stdout():
    return _files.std_stream(True, "wb")


def get_text_stdin(encoding=None, errors=None):
    return _files.std_stream(False, "r", encoding, errors or "strict")


def get_text_stdout(encoding=None, errors=None):
    return _files.std_stream(True, "w", encoding, errors or "strict")
