"""Exception classes and the exit-status classes they map to."""

import sys


class OptlynError(Exception):
    """Base error. Standalone mode prints it and exits with ``exit_code``."""

    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def show(self, file=None):
        from .termui import echo

        echo(f"Error: {self.format_message()}", file=file or sys.stderr)


class UsageError(OptlynError):
    """Incorrect command line. Exit status 2, with a usage line on stderr."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self, file=None):
        from .termui import echo

        file = file or sys.stderr
        if self.ctx is not None:
            echo(self.ctx.get_usage(), file=file)
            hint = self.ctx.help_option_names[0] if self.ctx.help_option_names else None
            if hint:
                echo(f"Try '{self.ctx.command_path} {hint}' for help.", file=file)
            echo("", file=file)
        echo(f"Error: {self.format_message()}", file=file)


class BadParameter(UsageError):
    """A value was refused: bad conversion, failed check, or refusing callback."""

    def __init__(self, message=None, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return self.message


class MissingParameter(BadParameter):
    """A required parameter received no value from any source."""

    def format_message(self):
        kind = "option" if getattr(self.param, "param_type_name", "") == "option" else "argument"
        hint = self.param.get_error_hint(self.ctx) if self.param is not None else ""
        return f"Missing {kind} {hint}.".replace("  ", " ")


class NoSuchOption(UsageError):
    def __init__(self, option_name, message=None, ctx=None):
        super().__init__(message or f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """Option used incorrectly, e.g. a value option without its value."""


class BadArgumentUsage(UsageError):
    """Argument used incorrectly."""


class NoArgsIsHelp(UsageError):
    """Help was shown because no arguments were given (usage class, exit 2)."""

    def __init__(self, ctx):
        super().__init__("", ctx)

    def show(self, file=None):
        from .termui import echo

        echo(self.ctx.get_help(), file=file or sys.stderr)


class FileError(OptlynError):
    """A file could not be opened at first I/O (general error class, exit 1)."""

    def __init__(self, filename, detail):
        super().__init__(f"Could not open file {filename!r}: {detail}")
        self.filename = filename


class Abort(RuntimeError):
    """User or author aborted the run. Standalone mode exits with 1."""


class Exit(RuntimeError):
    """Author clean stop with an explicit status."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
