"""Decorators that declare commands, groups, parameters and ready-made options."""

import functools
import importlib.metadata

from ._local import get_current_context
from .core import Argument, Command, Group, Option
from .termui import echo


def _attach_param(f, param):
    if hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__.append(param)
    else:
        f.__optlyn_params__ = [param]
    return f


def _pop_params(f):
    params = getattr(f, "__optlyn_params__", [])
    if hasattr(f, "__optlyn_params__"):
        del f.__optlyn_params__
    params.reverse()
    return params


def _derive_name(func_name):
    name = func_name.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _make_command(f, name, cls, attrs):
    params = _pop_params(f)
    if name is None:
        name = _derive_name(f.__name__)
    return cls(name=name, callback=f, params=params, **attrs)


def command(name=None, cls=None, **attrs):
    """Turn a function into a command. Used as ``@command()`` or ``@command``."""
    if callable(name) and cls is None and not attrs:
        return _make_command(name, None, Command, {})

    def decorator(f):
        return _make_command(f, name, cls or Command, attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a group. Used as ``@group()`` or ``@group``."""
    if callable(name) and cls is None and not attrs:
        return _make_command(name, None, Group, {})

    def decorator(f):
        return _make_command(f, name, cls or Group, attrs)

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to the function that the decorator is applied to."""

    def decorator(f):
        return _attach_param(f, (cls or Option)(param_decls, **attrs))

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to the function that the decorator is applied to."""

    def decorator(f):
        return _attach_param(f, (cls or Argument)(param_decls, **attrs))

    return decorator


def _show_help(ctx, param, value):
    if not value:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit(0)


def help_option(*param_decls, **kwargs):
    """Attach an extra eager help flag that prints help and exits."""
    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help)

    def decorator(f):
        return _attach_param(f, Option(param_decls, **kwargs))

    return decorator


def _detect_version(package_name):
    try:
        return importlib.metadata.version(package_name)
    except importlib.metadata.PackageNotFoundError:
        pass
    providers = importlib.metadata.packages_distributions().get(package_name)
    if providers:
        return importlib.metadata.version(providers[0])
    raise RuntimeError(f"Could not detect the version of {package_name!r}.")


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """Attach an eager ``--version`` flag that prints the version identity and exits."""
    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value:
            return
        ver = version if version is not None else _detect_version(package_name)
        prog = prog_name or ctx.find_root().info_name
        text = (message or "%(prog)s, version %(version)s") % {"prog": prog, "version": ver}
        echo(text, color=ctx.color)
        ctx.exit()

    kwargs["callback"] = callback

    def decorator(f):
        return _attach_param(f, Option(param_decls, **kwargs))

    return decorator


def custom_version_option(callback_fn, *param_decls, **kwargs):
    """Attach an eager version flag whose identity is the string ``callback_fn(ctx)`` returns."""
    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value:
            return
        echo(callback_fn(ctx), color=True)
        ctx.exit()

    kwargs["callback"] = callback

    def decorator(f):
        return _attach_param(f, Option(param_decls, **kwargs))

    return decorator


def password_option(*param_decls, **kwargs):
    """A prompting, hidden-input, confirmed option (``--password`` by default)."""
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("help", "The password to use.")

    def decorator(f):
        return _attach_param(f, Option(param_decls, **kwargs))

    return decorator


def confirmation_option(*param_decls, **kwargs):
    """A confirmation flag (``--yes`` by default) that asks when omitted and aborts when declined."""
    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def decorator(f):
        return _attach_param(f, Option(param_decls, **kwargs))

    return decorator


def pass_context(f):
    """Pass the current context as the first positional argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    """Pass the current context's author object as the first positional argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Return a decorator that passes the nearest author object of ``object_type``."""

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            node = ctx
            found = None
            while node is not None:
                if isinstance(node.obj, object_type):
                    found = node.obj
                    break
                node = node.parent
            if found is None:
                if not ensure:
                    raise RuntimeError(f"Managed to invoke callback without a context object of type {object_type.__name__!r} existing.")
                found = object_type()
                ctx.obj = found
            return f(found, *args, **kwargs)

        return new_func

    return decorator


__all__ = [
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option", "pass_context",
    "pass_obj", "make_pass_decorator",
]
