"""Core model: invocation contexts, parameters, the option parser, commands and groups."""

import contextlib
import enum
import inspect
import os
import sys

from ._local import get_current_context, pop_context, push_context
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingParameter,
    NoArgsIsHelp,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import HelpFormatter, make_short_help
from .termui import confirm, echo, prompt
from .types import BOOL, FALSE_VALUES, INT, TRUE_VALUES, STRING, Tuple, convert_type


class ParameterSource(enum.Enum):
    """Where a parameter's value came from, most explicit first."""

    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


_SOURCE_RANK = {
    ParameterSource.PROMPT: 5,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.ENVIRONMENT: 3,
    ParameterSource.DEFAULT_MAP: 2,
    ParameterSource.DEFAULT: 1,
}

# Marks the subcommand position of a chaining group; it is neither None nor a child name.
CHAIN_INVOCATION = object()

_CONTEXT_SETTINGS = (
    "auto_envvar_prefix", "default_map", "terminal_width", "max_content_width",
    "help_option_names", "token_normalize_func", "color", "show_default",
    "allow_extra_args", "ignore_unknown_options", "allow_interspersed_args",
)


class Context:
    """Per-invocation state: parsed values, parent linkage, author object and settings."""

    def __init__(self, command, parent=None, info_name=None, obj=None, default_map=None, **settings):
        unknown = set(settings) - set(_CONTEXT_SETTINGS)
        if unknown:
            raise TypeError(f"Unknown context setting(s): {', '.join(sorted(unknown))}")
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.params = {}
        self.args = []
        self.protected_args = []
        self.invoked_subcommand = None
        self._param_sources = {}
        self._scores = {}
        self._chained = False
        self._exit_stack = contextlib.ExitStack() if parent is None else None

        cmd_settings = dict(getattr(command, "context_settings", None) or {})

        def pick(key):
            if settings.get(key) is not None:
                return settings[key]
            if cmd_settings.get(key) is not None:
                return cmd_settings[key]
            if parent is not None:
                return getattr(parent, key)
            return None

        self.terminal_width = pick("terminal_width")
        max_width = pick("max_content_width")
        self.max_content_width = 80 if max_width is None else max_width
        names = pick("help_option_names")
        self.help_option_names = list(names) if names is not None else ["--help"]
        self.token_normalize_func = pick("token_normalize_func")
        self.color = pick("color")
        self.show_default = bool(pick("show_default"))
        self.auto_envvar_prefix = pick("auto_envvar_prefix")
        self.ignore_unknown_options = bool(pick("ignore_unknown_options"))
        self.allow_extra_args = bool(pick("allow_extra_args"))
        interspersed = settings.get("allow_interspersed_args")
        if interspersed is None:
            interspersed = cmd_settings.get("allow_interspersed_args")
        if interspersed is None and parent is not None:
            interspersed = parent._explicit_interspersed
        self._explicit_interspersed = interspersed
        if interspersed is None:
            interspersed = getattr(command, "allow_interspersed_args", True)
        self.allow_interspersed_args = bool(interspersed)

        if default_map is None:
            default_map = cmd_settings.get("default_map")
        if default_map is None and isinstance(getattr(parent, "default_map", None), dict):
            default_map = parent.default_map.get(info_name)
        self.default_map = default_map

    # --- context manager and lifecycle -------------------------------------------------

    def __enter__(self):
        push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        pop_context()

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def close(self):
        if self._exit_stack is not None:
            self._exit_stack.close()

    def resource_owner(self):
        """The nearest context that owns resources: the root, or a chained subcommand."""
        node = self
        while node._exit_stack is None:
            node = node.parent
        return node._exit_stack

    def with_resource(self, cm):
        """Enter ``cm`` and keep it open until the invocation ends."""
        return self.resource_owner().enter_context(cm)

    # --- information -------------------------------------------------------------------

    @property
    def command_path(self):
        parts = []
        if self.parent is not None:
            parts.append(self.parent.command_path)
        if self.info_name is not None:
            parts.append(self.info_name)
        return " ".join(p for p in parts if p)

    def get_width(self):
        if self.terminal_width is not None:
            return self.terminal_width
        from .formatting import terminal_columns

        return min(terminal_columns(), self.max_content_width)

    def get_usage(self):
        return self.command.get_usage(self)

    def get_help(self):
        return self.command.get_help(self)

    def get_parameter_source(self, name):
        declared = {p.name for p in self.command.get_params(self)}
        if name not in declared:
            return None
        return self._param_sources.get(name, ParameterSource.DEFAULT)

    # --- control -----------------------------------------------------------------------

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def fail(self, message):
        raise UsageError(message, ctx=self)

    def invoke(*args, **kwargs):
        self, callback, positional = args[0], args[1], args[2:]
        if isinstance(callback, Command):
            other = callback
            sub = Context(other, info_name=other.name, parent=self)
            for p in other.params:
                if p.expose_value and p.name not in kwargs:
                    kwargs[p.name] = p.get_default(sub)
            with sub:
                if other.callback is None:
                    return None
                return other.callback(*positional, **kwargs)
        with self:
            return callback(*positional, **kwargs)

    def forward(*args, **kwargs):
        self, cmd = args[0], args[1]
        merged = dict(self.params)
        merged.update(kwargs)
        return self.invoke(cmd, **merged)


class Parameter:
    """Common behaviour of options and arguments."""

    param_type_name = "parameter"

    def _setup(self, name, opts, secondary_opts, type_, default, required, nargs, multiple,
               metavar, expose_value, is_eager, envvar, shell_complete, deprecated,
               allow_from_autoenv, callback, help):
        self.name = name
        self.opts = list(opts)
        self.secondary_opts = list(secondary_opts)
        self.default = default
        self._default_explicit = default is not None
        self.required = required
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.envvar = [envvar] if isinstance(envvar, str) else (list(envvar) if envvar else None)
        self.shell_complete_func = shell_complete
        self.deprecated = deprecated
        self.allow_from_autoenv = allow_from_autoenv
        self.callback = callback
        self.help = help
        self.hidden = False
        if nargs is None:
            nargs = len(type_.types) if isinstance(type_, Tuple) else 1
        self.nargs = nargs
        self.type = convert_type(type_, default)
        if isinstance(self.type, Tuple) and nargs != len(self.type.types):
            raise ValueError("nargs must match the number of Tuple types.")

    def is_variadic(self):
        return self.nargs == -1 or self.multiple

    def get_error_hint(self, ctx):
        raise NotImplementedError

    def get_metavar(self, ctx):
        return self.metavar

    def get_default(self, ctx, call=True):
        value = self.default
        if callable(value) and call:
            value = value()
        return value

    def shell_complete(self, ctx, incomplete):
        if self.shell_complete_func is not None:
            return list(self.shell_complete_func(ctx, self, incomplete))
        return list(self.type.shell_complete(ctx, self, incomplete))

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


def _is_flag_name(decl):
    return bool(decl) and not (decl[0].isalnum() or decl[0] == "_")


def _split_pair(decl):
    """Split ``--on/--off`` into its two flags; return None when it is not a pair."""
    idx = decl.find("/", 1)
    if idx == -1:
        return None
    first, second = decl[:idx], decl[idx + 1:]
    if _is_flag_name(first) and _is_flag_name(second):
        return first, second
    return None


def _dest_from_flags(flags):
    longs = [f for f in flags if len(f) > 1 and f[1] in "-/+" and f[0] in "-/+"]
    for flag in longs[:1] or flags[:1]:
        return flag.lstrip("-/+").replace("-", "_")
    return None


class Option(Parameter):
    param_type_name = "option"

    def __init__(self, param_decls=None, *, type=None, default=None, required=False, is_flag=None,
                 flag_value=None, count=False, multiple=False, nargs=None, envvar=None,
                 allow_from_autoenv=True, prompt=False, prompt_required=True, hide_input=False,
                 confirmation_prompt=False, callback=None, is_eager=False, expose_value=True,
                 hidden=False, deprecated=False, help=None, metavar=None, show_default=None,
                 show_envvar=False, shell_complete=None):
        decls = list(param_decls or [])
        flags, secondary, name = [], [], None
        for decl in decls:
            if _is_flag_name(decl):
                pair = _split_pair(decl)
                if pair is not None:
                    flags.append(pair[0])
                    secondary.append(pair[1])
                else:
                    flags.append(decl)
            else:
                if name is not None:
                    raise TypeError(f"Option has more than one destination name: {name!r}, {decl!r}")
                name = decl
        if name is None:
            name = _dest_from_flags(flags or secondary)
        if name is None:
            raise TypeError("Option needs a flag name or a destination name.")
        name = name.replace("-", "_")

        if count:
            is_flag = True
            flag_value = 1 if flag_value is None else flag_value
            if default is None:
                default = 0
        if is_flag is None:
            is_flag = bool(secondary) or isinstance(default, bool) or isinstance(flag_value, bool)
        if is_flag and flag_value is None:
            flag_value = True
        if is_flag and type is None and not count:
            type = BOOL if isinstance(flag_value, bool) else STRING
        if is_flag and default is None and not count and isinstance(flag_value, bool):
            default = False
        optional_value = not is_flag and flag_value is not None

        if nargs is None:
            nargs = len(type.types) if isinstance(type, Tuple) else 1
        if nargs < 1:
            raise ValueError("Option nargs must be a positive integer.")
        if deprecated and required:
            raise ValueError("A deprecated option cannot also be required.")
        if deprecated and prompt:
            raise ValueError("A deprecated option cannot use a prompt.")
        if is_flag and multiple and not count:
            raise ValueError("A flag cannot be repeatable.")

        self._setup(name, flags, secondary, type, default, required, nargs, multiple, metavar,
                    expose_value, is_eager, envvar, shell_complete, deprecated,
                    allow_from_autoenv, callback, help)
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self.flag_value = flag_value
        self.optional_value = optional_value
        self.hidden = hidden
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.prompt_text = None
        if prompt:
            self.prompt_text = prompt if isinstance(prompt, str) else name.replace("_", " ").capitalize()
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.confirm_when_omitted = bool(is_flag and prompt)

    def get_error_hint(self, ctx):
        return " / ".join(f"'{f}'" for f in self.opts + self.secondary_opts)

    def get_metavar(self, ctx):
        if self.is_flag or self.count:
            return None
        if self.metavar is not None:
            return self.metavar
        placeholder = self.type.get_metavar(self)
        if placeholder:
            return placeholder
        if isinstance(self.type, Tuple):
            return self.type.get_metavar(self)
        return self.type.name.upper()


class Argument(Parameter):
    param_type_name = "argument"

    def __init__(self, param_decls=None, *, type=None, default=None, required=None, nargs=None,
                 envvar=None, deprecated=False, help=None, metavar=None, callback=None,
                 expose_value=True, is_eager=False, shell_complete=None, hidden=False):
        decls = list(param_decls or [])
        if len(decls) != 1:
            raise TypeError("An argument takes exactly one destination name.")
        name = decls[0].replace("-", "_")
        if nargs is None:
            nargs = 1
        if nargs == 0 or nargs < -1:
            raise ValueError("Argument nargs must be a positive integer or -1.")
        if required is None:
            required = nargs != -1 and default is None
        if deprecated and required:
            raise ValueError("A deprecated argument cannot be required.")
        self._setup(name, [], [], type, default, required, nargs, False, metavar, expose_value,
                    is_eager, envvar, shell_complete, deprecated, True, callback, help)
        self.hidden = hidden

    def get_error_hint(self, ctx):
        return f"'{self.name.upper()}'"

    def get_metavar(self, ctx):
        return self.metavar or self.name.upper()


# --- option parser -------------------------------------------------------------------

class _OptionParser:
    """Splits a token list into option entries and positional tokens."""

    def __init__(self, ctx, params, interspersed, group):
        self.ctx = ctx
        self.interspersed = interspersed
        self.group = group
        self.ignore_unknown = ctx.ignore_unknown_options
        self.normalize = ctx.token_normalize_func
        self.flags = {}
        for p in params:
            if not isinstance(p, Option):
                continue
            for flag in p.opts:
                self.flags[flag] = (p,) + self._action(p, True)
            for flag in p.secondary_opts:
                self.flags[flag] = (p,) + self._action(p, False)
        self.normalized = {}
        if self.normalize is not None:
            for flag in self.flags:
                self.normalized[self.normalize(flag)] = flag
        self.prefix_chars = {f[0] for f in self.flags} | {"-"}

    @staticmethod
    def _action(p, on):
        if p.count:
            return ("count", 1)
        if p.optional_value:
            return ("value", None)
        if p.is_flag:
            return ("flag", p.flag_value if on else False)
        return ("value", None)

    def _optlike(self, tok):
        return len(tok) > 1 and tok[0] in self.prefix_chars

    def _find(self, flag):
        if flag in self.flags:
            return self.flags[flag]
        if self.normalize is not None and flag:
            key = self.normalized.get(self.normalize(flag))
            if key is not None:
                return self.flags[key]
        return None

    def parse(self, tokens):
        entries, order, positional = {}, {}, []
        state = {"entries": entries, "order": order, "positional": positional}
        i, n = 0, len(tokens)
        dd = False
        no_opts = False
        while i < n:
            tok = tokens[i]
            if dd:
                positional.append((tok, True))
                i += 1
                continue
            if no_opts:
                if tok == "--" and not self.group:
                    dd = True
                else:
                    positional.append((tok, False))
                i += 1
                continue
            if tok == "--":
                dd = True
                i += 1
                continue
            if self._optlike(tok):
                i = self._handle(tok, i, tokens, state)
                continue
            positional.append((tok, False))
            i += 1
            if not self.interspersed:
                no_opts = True
        return entries, order, positional

    def _handle(self, tok, i, tokens, state):
        found = self._find(tok)
        if found is not None:
            return self._take(found, tok, None, i, tokens, state)
        if tok[1] == tok[0]:
            name, eq, inline = tok.partition("=")
            found = self._find(name)
            if found is None:
                return self._unknown(name, i, state)
            return self._take(found, name, inline if eq else None, i, tokens, state)
        prefix = tok[0]
        j = 1
        while j < len(tok):
            flag = prefix + tok[j]
            found = self._find(flag)
            if found is None:
                return self._unknown_short(prefix, tok, j, i, state)
            if found[1] == "value":
                rest = tok[j + 1:]
                return self._take(found, flag, rest or None, i, tokens, state)
            self._record(found, i, state)
            j += 1
        return i + 1

    def _record(self, found, i, state):
        p, action, value = found
        state["order"].setdefault(p, i)
        state["entries"].setdefault(p, []).append(("val", value))

    def _take(self, found, flag, inline, i, tokens, state):
        p, action, value = found
        if action in ("flag", "count"):
            self._record(found, i, state)
            return i + 1
        state["order"].setdefault(p, i)
        n = len(tokens)
        if inline is None and p.optional_value:
            if i + 1 < n and not self._optlike(tokens[i + 1]):
                state["entries"].setdefault(p, []).append(("tok", (tokens[i + 1],)))
                return i + 2
            if p.prompt_text is not None:
                state["entries"].setdefault(p, []).append(("prompt", None))
            else:
                state["entries"].setdefault(p, []).append(("val", p.flag_value))
            return i + 1
        if inline is not None and p.optional_value:
            state["entries"].setdefault(p, []).append(("tok", (inline,)))
            return i + 1
        toks = [inline] if inline is not None else []
        j = i + 1
        while len(toks) < p.nargs and j < n:
            toks.append(tokens[j])
            j += 1
        if len(toks) < p.nargs:
            raise BadOptionUsage(
                f"Option '{flag}' requires {p.nargs} argument{'s' if p.nargs > 1 else ''}.",
                ctx=self.ctx,
            )
        state["entries"].setdefault(p, []).append(("tok", tuple(toks)))
        return j

    def _unknown(self, name, i, state):
        if self.ignore_unknown or (self.group and self.interspersed):
            state["positional"].append((name, False))
            return i + 1
        raise NoSuchOption(name, ctx=self.ctx)

    def _unknown_short(self, prefix, tok, j, i, state):
        if self.ignore_unknown or (self.group and self.interspersed):
            state["positional"].append((prefix + tok[j:], False))
            return i + 1
        raise NoSuchOption(prefix + tok[j], ctx=self.ctx)


# --- value resolution ------------------------------------------------------------------

def _env_names(ctx, p):
    names = list(p.envvar or [])
    if ctx.auto_envvar_prefix and p.allow_from_autoenv and isinstance(p, Option):
        chain = []
        node = ctx
        while node.parent is not None:
            chain.append(node.info_name)
            node = node.parent
        parts = [ctx.auto_envvar_prefix] + list(reversed(chain)) + [p.name]
        names.append("_".join(str(x) for x in parts).upper().replace("-", "_"))
    return names


def _first_env(names):
    for name in names:
        value = os.environ.get(name)
        if value:
            return value
    return None


def _split_tokens(p, raw):
    """Split an environment or default-map string into occurrence payloads."""
    if not (p.multiple or p.nargs != 1 or isinstance(p.type, Tuple)):
        return [(raw,)]
    splitter = getattr(p.type, "split_envvar_value", None)
    tokens = splitter(raw) if splitter else raw.split()
    size = len(p.type.types) if isinstance(p.type, Tuple) else p.nargs
    if size == -1:
        return [tuple(tokens)]
    if len(tokens) % size:
        raise BadOptionUsage(f"{p.get_error_hint(None)} needs {size} values per occurrence.")
    return [tuple(tokens[k:k + size]) for k in range(0, len(tokens), size)]


def _convert_payload(ctx, p, payload):
    """Convert one token payload (a tuple of raw tokens) for parameter ``p``."""
    if isinstance(p.type, Tuple):
        return p.type(list(payload), p, ctx)
    if p.nargs == 1:
        return p.type(payload[0], p, ctx)
    return tuple(p.type(t, p, ctx) for t in payload)


def _convert_item(ctx, p, item):
    if isinstance(p.type, Tuple):
        return p.type(item, p, ctx)
    if p.nargs > 1 and isinstance(item, (list, tuple)):
        return tuple(p.type(v, p, ctx) for v in item)
    return p.type(item, p, ctx)


def _convert_default(ctx, p, raw, error_cls):
    if p.is_variadic():
        if raw is None:
            return ()
        if isinstance(raw, (str, bytes)) or not isinstance(raw, (list, tuple)):
            raise error_cls(
                f"{p.get_error_hint(ctx)} needs an iterable (sequence) default, not a single value.",
                ctx=ctx,
            )
        return tuple(_convert_item(ctx, p, item) for item in raw)
    if raw is None:
        return None
    if p.nargs > 1 and not isinstance(p.type, Tuple) and isinstance(raw, (list, tuple)):
        return tuple(p.type(v, p, ctx) for v in raw)
    return p.type(raw, p, ctx)


def _is_missing(p, value):
    return value is None or (p.is_variadic() and value == ())


def _emit_deprecation(ctx, p):
    note = p.deprecated if isinstance(p.deprecated, str) else None
    kind = p.param_type_name
    label = p.get_error_hint(ctx) if kind == "argument" else p.opts[0] if p.opts else p.name
    text = f"DeprecationWarning: The {kind} '{label}' is deprecated."
    if note:
        text += f" {note}"
    echo(text, err=True)


def _show_help(ctx, param, value):
    if not value:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit(0)


def _make_help_option(names):
    return Option(
        list(names), is_flag=True, expose_value=False, is_eager=True,
        help="Show this message and exit.", callback=_show_help,
    )


# --- commands ----------------------------------------------------------------------------

class Command:
    """A leaf command: parses a slice of the command line and runs a callback."""

    allow_interspersed_args = True

    def __init__(self, name=None, context_settings=None, callback=None, params=None, help=None,
                 epilog=None, short_help=None, options_metavar="[OPTIONS]", add_help_option=True,
                 no_args_is_help=False, hidden=False, deprecated=False):
        self.name = name
        self.context_settings = context_settings
        self.callback = callback
        self.params = list(params or [])
        if help is None and callback is not None and callback.__doc__:
            help = inspect.cleandoc(callback.__doc__)
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # --- parameters --------------------------------------------------------------------

    def get_params(self, ctx):
        params = list(self.params)
        if self.add_help_option and ctx is not None:
            declared = {f for p in params if isinstance(p, Option) for f in p.opts + p.secondary_opts}
            names = [n for n in ctx.help_option_names if n not in declared]
            if names:
                params.append(_make_help_option(names))
        return params

    # --- context creation and parsing --------------------------------------------------

    def make_context(self, info_name, args, parent=None, chained=False, **extra):
        ctx = Context(self, info_name=info_name, parent=parent, **extra)
        if chained:
            ctx._chained = True
            ctx._exit_stack = contextlib.ExitStack()
            ctx.allow_extra_args = True
            ctx.allow_interspersed_args = False
        with ctx:
            try:
                self.parse_args(ctx, list(args))
            except UsageError as e:
                if e.ctx is None:
                    e.ctx = ctx
                raise
        return ctx

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help:
            raise NoArgsIsHelp(ctx)
        params = self.get_params(ctx)
        parser = _OptionParser(ctx, params, ctx.allow_interspersed_args, isinstance(self, Group))
        entries, order, positional = parser.parse(args)
        options = [p for p in params if isinstance(p, Option)]
        arguments = [p for p in params if isinstance(p, Argument)]

        eager = sorted((p for p in options if p.is_eager and p in order), key=lambda p: order[p])
        rest = [p for p in options if p not in eager]
        for p in eager + rest:
            self._process_option(ctx, p, entries.get(p))

        leftover = self._bind_arguments(ctx, arguments, positional)
        for a in arguments:
            self._process_argument(ctx, a, leftover.get(a))
        remaining = leftover["__rest__"]
        self._handle_leftover(ctx, remaining)

    def _handle_leftover(self, ctx, remaining):
        tokens = [t for t, _ in remaining]
        if isinstance(self, Group):
            ctx.protected_args = tokens[:1]
            ctx.args = tokens[1:]
            return
        if not tokens:
            return
        if ctx._chained:
            ctx.args = tokens
            return
        if ctx.allow_extra_args:
            if not ctx.ignore_unknown_options:
                for tok, literal in remaining:
                    if not literal and len(tok) > 1 and tok[0] in "-/+":
                        raise NoSuchOption(tok, ctx=ctx)
            ctx.args = tokens
            return
        plural = "s" if len(tokens) > 1 else ""
        raise UsageError(f"Got unexpected extra argument{plural} ({' '.join(tokens)})", ctx=ctx)

    def _bind_arguments(self, ctx, arguments, positional):
        """Assign positional tokens to arguments; returns per-argument tokens and the rest."""
        bound = {}
        i, n = 0, len(positional)
        for idx, a in enumerate(arguments):
            later = sum(b.nargs for b in arguments[idx + 1:] if b.required and b.nargs != -1)
            avail = n - i - later
            if a.nargs == -1:
                take = max(avail, 0)
            else:
                take = a.nargs if avail >= a.nargs else 0
            if take:
                bound[a] = tuple(tok for tok, _ in positional[i:i + take])
                i += take
            else:
                bound[a] = None
        bound["__rest__"] = positional[i:]
        return bound

    # --- processing --------------------------------------------------------------------

    def _store(self, ctx, p, value, src):
        rank = (_SOURCE_RANK[src], 1 if (src is ParameterSource.DEFAULT and p._default_explicit) else 0)
        prev = ctx._scores.get(p.name)
        if prev is not None and rank < prev:
            return
        ctx._scores[p.name] = rank
        ctx._param_sources[p.name] = src
        if p.expose_value:
            ctx.params[p.name] = value

    def _process_option(self, ctx, p, entries):
        value, src = self._resolve_option(ctx, p, entries or [])
        if p.required and _is_missing(p, value):
            raise MissingParameter(ctx=ctx, param=p)
        if src is ParameterSource.COMMANDLINE and p.deprecated:
            _emit_deprecation(ctx, p)
        if p.callback is not None:
            value = p.callback(ctx, p, value)
        self._store(ctx, p, value, src)

    def _process_argument(self, ctx, a, toks):
        value, src = self._resolve_argument(ctx, a, toks)
        if a.required and _is_missing(a, value):
            raise MissingParameter(ctx=ctx, param=a)
        if src is ParameterSource.COMMANDLINE and a.deprecated:
            _emit_deprecation(ctx, a)
        if a.callback is not None:
            value = a.callback(ctx, a, value)
        self._store(ctx, a, value, src)

    def _resolve_option(self, ctx, p, entries):
        given = [e for e in entries if e[0] != "prompt"]
        asked = len(given) != len(entries)
        dm = ctx.default_map if isinstance(ctx.default_map, dict) else {}

        if p.is_flag and not p.count:
            if given:
                return p.type(given[-1][1], p, ctx), ParameterSource.COMMANDLINE
            found = self._flag_env(ctx, p)
            if found is not None:
                return found, ParameterSource.ENVIRONMENT
            if p.confirm_when_omitted:
                confirm(p.prompt_text, default=False, abort=True)
                return True, ParameterSource.PROMPT
            if p.name in dm:
                return p.type(dm[p.name], p, ctx), ParameterSource.DEFAULT_MAP
            return _convert_default(ctx, p, p.get_default(ctx), BadOptionUsage), ParameterSource.DEFAULT

        if p.count:
            if given:
                return len(given), ParameterSource.COMMANDLINE
            if p.name in dm:
                return p.type(dm[p.name], p, ctx), ParameterSource.DEFAULT_MAP
            default = p.get_default(ctx)
            return (0 if default is None else default), ParameterSource.DEFAULT

        if given:
            converted = [
                _convert_payload(ctx, p, payload) if kind == "tok" else p.type(payload, p, ctx)
                for kind, payload in given
            ]
            return self._assemble(p, converted), ParameterSource.COMMANDLINE

        env_payloads = self._env_payloads(ctx, p)
        if env_payloads is not None:
            converted = [_convert_payload(ctx, p, payload) for payload in env_payloads]
            return self._assemble(p, converted), ParameterSource.ENVIRONMENT

        if p.prompt_text is not None and (asked or p.prompt_required):
            raw_default = dm[p.name] if p.name in dm else p.get_default(ctx)
            value = prompt(
                p.prompt_text,
                default=raw_default,
                hide_input=p.hide_input,
                confirmation_prompt=p.confirmation_prompt,
                type=p.type,
            )
            return value, ParameterSource.PROMPT

        if p.name in dm:
            raw = dm[p.name]
            if isinstance(raw, str) and (p.multiple or p.nargs != 1 or isinstance(p.type, Tuple)):
                if p.multiple and p.nargs == 1 and not isinstance(p.type, Tuple):
                    raise BadOptionUsage(f"{p.get_error_hint(ctx)} needs an iterable (sequence) default.", ctx=ctx)
                converted = [_convert_payload(ctx, p, payload) for payload in _split_tokens(p, raw)]
                return self._assemble(p, converted), ParameterSource.DEFAULT_MAP
            return _convert_default(ctx, p, raw, BadOptionUsage), ParameterSource.DEFAULT_MAP

        return _convert_default(ctx, p, p.get_default(ctx), BadOptionUsage), ParameterSource.DEFAULT

    @staticmethod
    def _assemble(p, converted):
        if p.multiple:
            return tuple(converted)
        return converted[-1]

    def _flag_env(self, ctx, p):
        for name in _env_names(ctx, p):
            raw = os.environ.get(name)
            if not raw:
                continue
            text = raw.strip().lower()
            if not isinstance(p.flag_value, bool) and raw == str(p.flag_value):
                return p.flag_value
            if text in TRUE_VALUES:
                return p.flag_value
            if text in FALSE_VALUES or (text == "" and isinstance(p.flag_value, bool)):
                return False
            if isinstance(p.flag_value, bool):
                raise BadParameter(f"{raw!r} is not a valid boolean.", ctx=ctx, param=p)
        return None

    def _env_payloads(self, ctx, p):
        raw = _first_env(_env_names(ctx, p))
        if raw is None:
            return None
        if p.is_flag:
            return None
        return _split_tokens(p, raw)

    def _resolve_argument(self, ctx, a, toks):
        dm = ctx.default_map if isinstance(ctx.default_map, dict) else {}
        if toks is not None and len(toks) > 0:
            return _convert_payload(ctx, a, toks) if a.nargs != -1 else tuple(a.type(t, a, ctx) for t in toks), ParameterSource.COMMANDLINE
        if a.envvar:
            raw = _first_env(a.envvar)
            if raw is not None:
                payloads = _split_tokens(a, raw)
                if a.nargs == -1:
                    return tuple(a.type(t, a, ctx) for t in payloads[0]), ParameterSource.ENVIRONMENT
                return _convert_payload(ctx, a, payloads[0]), ParameterSource.ENVIRONMENT
        if a.name in dm:
            raw = dm[a.name]
            if isinstance(raw, str) and a.nargs != 1:
                payloads = _split_tokens(a, raw)
                if a.nargs == -1:
                    return tuple(a.type(t, a, ctx) for t in payloads[0]), ParameterSource.DEFAULT_MAP
                return _convert_payload(ctx, a, payloads[0]), ParameterSource.DEFAULT_MAP
            return _convert_default(ctx, a, raw, BadArgumentUsage), ParameterSource.DEFAULT_MAP
        return _convert_default(ctx, a, a.get_default(ctx), BadArgumentUsage), ParameterSource.DEFAULT

    # --- invocation --------------------------------------------------------------------

    def invoke(self, ctx):
        if self.deprecated:
            self._emit_command_deprecation(ctx)
        return self._run_callback(ctx)

    def _emit_command_deprecation(self, ctx):
        text = f"DeprecationWarning: The command {self.name!r} is deprecated."
        if self.deprecation_note:
            text += f" {self.deprecation_note}"
        echo(text, err=True)

    def _run_callback(self, ctx):
        if self.callback is None:
            return None
        kwargs = {p.name: ctx.params[p.name] for p in self.get_params(ctx)
                  if p.expose_value and p.name in ctx.params}
        with ctx:
            return self.callback(**kwargs)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        """Run this command as a program (or in-process when ``standalone_mode`` is false)."""
        from .shell_completion import handle_completion

        args = sys.argv[1:] if args is None else list(args)
        if prog_name is None:
            prog_name = _detect_prog_name()
        if handle_completion(self, prog_name, complete_var, standalone_mode):
            return None
        ctx = None
        try:
            try:
                ctx = self.make_context(prog_name, args, **extra)
                with ctx:
                    rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                ctx.exit()
            finally:
                if ctx is not None:
                    ctx.close()
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return None
        except OptlynError as e:
            if not standalone_mode:
                raise
            if isinstance(e, UsageError) and e.ctx is None:
                e.ctx = ctx
            e.show()
            sys.exit(e.exit_code)
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", err=True)
            sys.exit(1)
        except (EOFError, KeyboardInterrupt) as e:
            if not standalone_mode:
                raise Abort() from e
            echo("Aborted!", err=True)
            sys.exit(1)

    # --- help --------------------------------------------------------------------------

    def get_short_help_str(self, limit=45):
        if self.short_help is not None:
            return self.short_help
        return make_short_help(self._description(), limit)

    def _description(self):
        text = self.help or ""
        return text.split("\f")[0]

    def _usage_pieces(self, ctx):
        parts = [ctx.command_path]
        if self.options_metavar:
            parts.append(self.options_metavar)
        for a in self.params:
            if isinstance(a, Argument):
                parts.append(_argument_usage(a))
        if isinstance(self, Group):
            if self.chain:
                parts.append("COMMAND1 [ARGS]... [COMMAND2 [ARGS]...]...")
            elif self.invoke_without_command:
                parts.append("[COMMAND] [ARGS]...")
            else:
                parts.append("COMMAND [ARGS]...")
        return " ".join(p for p in parts if p)

    def get_usage(self, ctx):
        return "Usage: " + self._usage_pieces(ctx)

    def get_help(self, ctx):
        formatter = HelpFormatter(width=ctx.get_width())
        self.format_help(ctx, formatter)
        return formatter.getvalue()

    def format_help(self, ctx, formatter):
        formatter.write_usage(self.get_usage(ctx))
        if self.deprecated:
            formatter.write("(Deprecated)")
            formatter.write("")
        description = self._description()
        if description:
            formatter.write_text(description)

        arg_rows = []
        for a in self.params:
            if isinstance(a, Argument) and a.help and not a.hidden:
                arg_rows.append((a.get_metavar(ctx), a.help))
        if arg_rows:
            formatter.write_heading("Positional arguments")
            formatter.write_dl(arg_rows)

        rows = []
        for p in self.get_params(ctx):
            if isinstance(p, Option) and not p.hidden:
                rows.append(self._option_row(ctx, p))
        if rows:
            formatter.write_heading("Options")
            formatter.write_dl(rows)

        self.format_extra_help(ctx, formatter)

        if self.epilog:
            formatter.write_text(self.epilog)

    def format_extra_help(self, ctx, formatter):
        """Hook for subclasses to add sections (groups list their subcommands)."""

    def _option_row(self, ctx, p):
        names = [f"{o}/{s}" if s else o for o, s in _pair_names(p)]
        left = ", ".join(names)
        metavar = p.get_metavar(ctx)
        if metavar:
            left = f"{left} {metavar}"
        extras = []
        if p.help:
            help_text = p.help.split("\f")[0]
        else:
            help_text = ""
        show = p.show_default if p.show_default is not None else ctx.show_default
        if show and not p.count:
            default_text = self._default_text(ctx, p, show)
            if default_text is not None:
                extras.append(f"[default: {default_text}]")
        if p.show_envvar:
            envs = _env_names(ctx, p)
            if envs:
                extras.append(f"[env var: {', '.join(envs)}]")
        if p.required:
            extras.append("[required]")
        if p.deprecated:
            extras.append("(DEPRECATED)")
        if extras:
            help_text = (help_text + " " if help_text else "") + " ".join(extras)
        return left, help_text

    def _default_text(self, ctx, p, show):
        if isinstance(show, str):
            return show
        if p.is_flag:
            default = p.default
            if default is None or default is False:
                return None
            return str(default)
        default = p.default
        if default is None:
            return None
        if callable(default):
            return "(dynamic)"
        if isinstance(default, (list, tuple)):
            return ", ".join(str(x) for x in default)
        return str(default)


def _pair_names(p):
    if p.secondary_opts:
        return [(on, off) for on, off in zip(p.opts, p.secondary_opts)]
    return [(o, "") for o in p.opts]


def _argument_usage(a):
    name = a.metavar or a.name.upper()
    if a.nargs == -1:
        text = f"{name}..."
    elif a.nargs > 1:
        text = " ".join([name] * a.nargs)
    else:
        text = name
    return text if a.required else f"[{text}]"


class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_interspersed_args = False

    def __init__(self, name=None, commands=None, invoke_without_command=False, no_args_is_help=None,
                 subcommand_metavar=None, chain=False, result_callback=None, **kwargs):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name, no_args_is_help=no_args_is_help, **kwargs)
        self.commands = {}
        if isinstance(commands, dict):
            for key, cmd in commands.items():
                self.add_command(cmd, key)
        elif commands:
            for cmd in commands:
                self.add_command(cmd)
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback

    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise RuntimeError("A chaining group cannot have a nested group.")
        key = name or cmd.name
        if key is None:
            raise ValueError("A command needs a name to be added to a group.")
        self.commands[key] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as command_decorator

        def decorator(f):
            cmd = command_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as group_decorator

        def decorator(f):
            cmd = group_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self, replace=False):
        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def resolve_command(self, ctx, name):
        """Return ``(command, canonical_name)``; ``(None, name)`` when unknown."""
        cmd = self.get_command(ctx, name)
        if cmd is not None:
            return cmd, name
        if ctx.token_normalize_func is not None:
            wanted = ctx.token_normalize_func(name)
            for candidate in self.list_commands(ctx):
                if ctx.token_normalize_func(candidate) == wanted:
                    found = self.get_command(ctx, candidate)
                    if found is not None:
                        return found, candidate
        return None, name

    def format_extra_help(self, ctx, formatter):
        rows = []
        limit = max(formatter.width - 34, 20)
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            rows.append((name, cmd.get_short_help_str(limit)))
        if rows:
            formatter.write_heading("Commands")
            formatter.write_dl(rows)

    def invoke(self, ctx):
        if self.deprecated:
            self._emit_command_deprecation(ctx)
        if self.chain:
            return self._invoke_chain(ctx)
        return self._invoke_single(ctx)

    def _invoke_single(self, ctx):
        if not ctx.protected_args:
            if self.invoke_without_command:
                ctx.invoked_subcommand = None
                rv = self._run_callback(ctx)
                if self._result_callback is not None:
                    return ctx.invoke(self._result_callback, rv, **ctx.params)
                return rv
            raise UsageError("Missing command.", ctx=ctx)

        name = ctx.protected_args[0]
        cmd, canonical = self.resolve_command(ctx, name)
        if cmd is None:
            raise UsageError(f"No such command {name!r}.", ctx=ctx)
        ctx.invoked_subcommand = canonical
        self._run_callback(ctx)
        sub = cmd.make_context(canonical, ctx.args, parent=ctx)
        with sub:
            rv = cmd.invoke(sub)
        if self._result_callback is not None:
            return ctx.invoke(self._result_callback, rv, **ctx.params)
        return rv

    def _invoke_chain(self, ctx):
        remaining = list(ctx.protected_args) + list(ctx.args)
        if not remaining and not self.invoke_without_command:
            raise UsageError("Missing command.", ctx=ctx)
        ctx.invoked_subcommand = CHAIN_INVOCATION
        self._run_callback(ctx)
        results = []
        while remaining:
            name = remaining[0]
            cmd, canonical = self.resolve_command(ctx, name)
            if cmd is None:
                raise UsageError(f"No such command {name!r}.", ctx=ctx)
            sub = cmd.make_context(canonical, remaining[1:], parent=ctx, chained=True)
            try:
                with sub:
                    results.append(cmd.invoke(sub))
            finally:
                sub.close()
            remaining = list(sub.protected_args) + list(sub.args)
        if self._result_callback is not None:
            ctx.invoke(self._result_callback, results, **ctx.params)
        return results


class CommandCollection(Group):
    """A group that presents the subcommands of several source groups as one."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


def _detect_prog_name():
    argv0 = sys.argv[0] if sys.argv and sys.argv[0] else ""
    name = os.path.basename(argv0)
    return name or "root"


__all__ = [
    "Command", "Group", "CommandCollection", "Context", "Option", "Argument", "Parameter",
    "ParameterSource", "CHAIN_INVOCATION", "get_current_context",
]
