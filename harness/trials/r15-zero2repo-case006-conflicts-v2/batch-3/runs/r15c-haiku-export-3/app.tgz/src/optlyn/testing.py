"""In-process runner: invoke a command with tokens and capture its output and status."""

import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile


class _CaptureBuffer(io.BytesIO):
    """Binary capture buffer that also appends every write to a shared, ordered log."""

    def __init__(self, log):
        super().__init__()
        self._log = log

    def write(self, data):
        data = bytes(data)
        self._log.append(data)
        return super().write(data)


class _CaptureText(io.TextIOBase):
    """Text stream over a :class:`_CaptureBuffer`."""

    def __init__(self, buffer, encoding, errors="strict"):
        self._buffer = buffer
        self._encoding = encoding
        self._errors = errors

    @property
    def encoding(self):
        return self._encoding

    @property
    def errors(self):
        return self._errors

    @property
    def buffer(self):
        return self._buffer

    def write(self, text):
        self._buffer.write(text.encode(self._encoding, self._errors))
        return len(text)

    def flush(self):
        pass

    def isatty(self):
        return False

    def writable(self):
        return True


class _InputStream(io.TextIOWrapper):
    """Standard input for a run; with echo enabled it copies every line read into the output."""

    def __init__(self, data, encoding, echo_sink=None):
        super().__init__(io.BytesIO(data), encoding=encoding)
        self._echo_sink = echo_sink
        self.echoes_input = echo_sink is not None

    def readline(self, size=-1):
        line = super().readline(size)
        if self._echo_sink is not None and line:
            self._echo_sink(line)
        return line

    def read(self, size=-1):
        text = super().read(size)
        if self._echo_sink is not None and text:
            self._echo_sink(text)
        return text


class Result:
    """Outcome of :meth:`CliRunner.invoke`."""

    def __init__(self, runner_output, stdout_bytes, stderr_bytes, return_value, exit_code,
                 exception, exc_info):
        self._output_bytes = runner_output
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self._output_bytes.decode("utf-8", "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode("utf-8", "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode("utf-8", "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Runs a command in-process with captured streams. Not thread-safe."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        """Swap the standard streams and environment; yields a dict of captured data."""
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        log = []
        state = {"log": log}
        merged = dict(self.env)
        merged.update(env or {})

        saved_env = {}
        for key, value in merged.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        saved_streams = (sys.stdin, sys.stdout, sys.stderr)
        out_buf = _CaptureBuffer(log)
        err_buf = _CaptureBuffer(log)
        echo_sink = None
        if self.echo_stdin:
            def echo_sink(text):
                sys.stdout.write(text if isinstance(text, str) else text.decode(self.charset, "replace"))
        stdin = _InputStream(data, self.charset, echo_sink)
        stdout = _CaptureText(out_buf, self.charset)
        stderr = _CaptureText(err_buf, self.charset)
        fd_files = None
        try:
            if self.capture == "fd":
                fd_files = (tempfile.TemporaryFile(), tempfile.TemporaryFile())
                saved_fds = (os.dup(1), os.dup(2))
                os.dup2(fd_files[0].fileno(), 1)
                os.dup2(fd_files[1].fileno(), 2)
                stdout = io.TextIOWrapper(io.FileIO(1, "w", closefd=False), encoding=self.charset,
                                          write_through=True)
                stderr = io.TextIOWrapper(io.FileIO(2, "w", closefd=False), encoding=self.charset,
                                          write_through=True)
            sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
            state["stdout_buf"] = out_buf
            state["stderr_buf"] = err_buf
            yield state
        finally:
            sys.stdin, sys.stdout, sys.stderr = saved_streams
            try:
                sys.stdout.flush()
                sys.stderr.flush()
            except (OSError, ValueError):
                pass
            if fd_files is not None:
                os.dup2(saved_fds[0], 1)
                os.dup2(saved_fds[1], 2)
                os.close(saved_fds[0])
                os.close(saved_fds[1])
                fd_files[0].seek(0)
                fd_files[1].seek(0)
                state["fd_stdout"] = fd_files[0].read()
                state["fd_stderr"] = fd_files[1].read()
                fd_files[0].close()
                fd_files[1].close()
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        """Invoke ``cli`` with the token list ``args`` and return a :class:`Result`."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            args = shlex.split(args)
        extra.setdefault("prog_name", cli.name or "root")
        extra.setdefault("color", color)
        standalone = extra.pop("standalone_mode", True)

        exit_code = 0
        exception = None
        exc_info = None
        return_value = None
        with self.isolation(input=input, env=env, color=color) as state:
            try:
                return_value = cli.main(args=args, standalone_mode=standalone, **extra)
            except SystemExit as e:
                if e.code is None:
                    exit_code = 0
                elif isinstance(e.code, int):
                    exit_code = e.code
                else:
                    exit_code = 1
                if exit_code != 0:
                    exception = e
                exc_info = sys.exc_info()
            except Exception as e:
                if not catch_exceptions:
                    raise
                exit_code = 1
                exception = e
                exc_info = sys.exc_info()

        if "fd_stdout" in state:
            stdout_bytes = state["fd_stdout"]
            stderr_bytes = state["fd_stderr"]
            output = stdout_bytes + stderr_bytes
        else:
            stdout_bytes = state["stdout_buf"].getvalue()
            stderr_bytes = state["stderr_buf"].getvalue()
            output = b"".join(state["log"])
        return Result(output, stdout_bytes, stderr_bytes, return_value, exit_code,
                      exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Work in a new empty directory. Without ``temp_dir`` the directory is removed on exit."""
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(path, ignore_errors=True)
