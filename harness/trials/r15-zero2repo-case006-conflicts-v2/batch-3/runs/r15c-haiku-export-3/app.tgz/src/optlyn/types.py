"""Parameter types: conversion of command-line tokens into Python values."""

import datetime as _dt
import enum
import os
import pathlib
import uuid

from ._files import open_file
from ._local import get_current_context  # noqa: F401  (re-exported for custom types)
from .exceptions import BadParameter, FileError

TRUE_VALUES = ("1", "true", "t", "yes", "y", "on")
FALSE_VALUES = ("0", "false", "f", "no", "n", "off")

DEFAULT_DATETIME_FORMATS = (
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
)


class ParamType:
    """Base class for parameter types. Subclasses set ``name`` and override ``convert``."""

    name = "text"
    is_composite = False

    def __call__(self, value, param=None, ctx=None):
        if value is None:
            return None
        return self.convert(value, param, ctx)

    def convert(self, value, param, ctx):
        return value

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def get_metavar(self, param):
        return None

    def split_envvar_value(self, rv):
        return rv.split()

    def shell_complete(self, ctx, param, incomplete):
        return []

    def normalize(self, ctx, value):
        func = getattr(ctx, "token_normalize_func", None)
        return func(value) if func is not None else value

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, (bytes, bytearray)):
            try:
                return bytes(value).decode("utf-8")
            except UnicodeDecodeError:
                self.fail(f"{value!r} is not valid text.", param, ctx)
        return str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param, ctx):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        try:
            return int(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param, ctx):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in TRUE_VALUES:
            return True
        if text in FALSE_VALUES:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParameterType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


class FuncParamType(ParamType):
    """Wraps a conversion function ``f(token) -> value`` that refuses by raising ValueError."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param, ctx):
        try:
            return self.func(value)
        except ValueError:
            self.fail(f"{value!r} is not a valid value.", param, ctx)


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.enum = choices
            self.choices = list(choices)
        else:
            self.enum = None
            self.choices = list(choices)

    def _token(self, choice):
        if self.enum is not None:
            return choice.name
        return str(choice)

    def get_metavar(self, param):
        return "[" + "|".join(self._token(c) for c in self.choices) + "]"

    def convert(self, value, param, ctx):
        for choice in self.choices:
            if value is choice:
                return choice
        if not isinstance(value, str):
            value = str(value)
        normalized = self.normalize(ctx, value)
        for choice in self.choices:
            token = self._token(choice)
            if self.case_sensitive:
                if normalized == token:
                    return choice
            elif normalized.casefold() == token.casefold():
                return choice
        options = ", ".join(repr(self._token(c)) for c in self.choices)
        self.fail(f"{value!r} is not {options}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        results = []
        for choice in self.choices:
            token = self._token(choice)
            if self.case_sensitive:
                matches = token.startswith(incomplete)
            else:
                matches = token.casefold().startswith(incomplete.casefold())
            if matches:
                results.append(token)
        return results


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(DEFAULT_DATETIME_FORMATS)

    def convert(self, value, param, ctx):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        formats = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the formats {formats}.", param, ctx)


class _NumberRange:
    """Shared range logic for IntRange and FloatRange."""

    def _init_range(self, min, max, min_open, max_open, clamp):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def _describe(self):
        lo = "" if self.min is None else f"{self.min}{'<' if self.min_open else '<='}"
        hi = "" if self.max is None else f"{'<' if self.max_open else '<='}{self.max}"
        if lo and hi:
            return f"{lo}x{hi}"
        if lo:
            return f"x{lo[:-1] if lo.endswith('<') else lo}"
        if hi:
            return f"x{hi}"
        return "any value"

    def _range_check(self, value, param, ctx, open_step):
        below = above = False
        if self.min is not None:
            below = value <= self.min if self.min_open else value < self.min
        if self.max is not None:
            above = value >= self.max if self.max_open else value > self.max
        if not (below or above):
            return value
        if self.clamp:
            if below:
                return self.min + open_step if self.min_open else self.min
            return self.max - open_step if self.max_open else self.max
        self.fail(f"{value} is not in the range {self._describe()}.", param, ctx)


class IntRange(_NumberRange, IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self._init_range(min, max, min_open, max_open, clamp)

    def convert(self, value, param, ctx):
        value = IntParamType.convert(self, value, param, ctx)
        return self._range_check(value, param, ctx, 1)


class FloatRange(_NumberRange, FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise ValueError("FloatRange cannot clamp when a bound is open.")
        self._init_range(min, max, min_open, max_open, clamp)

    def convert(self, value, param, ctx):
        value = FloatParamType.convert(self, value, param, ctx)
        return self._range_check(value, param, ctx, 0)


class Tuple(ParamType):
    """A fixed-length product of inner types, one converted value per position."""

    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(t) for t in types]

    @property
    def arity(self):
        return len(self.types)

    def get_metavar(self, param):
        return " ".join(t.name.upper() for t in self.types)

    def convert(self, value, param, ctx):
        values = list(value)
        if len(values) != len(self.types):
            self.fail(f"{len(self.types)} values are required, but {len(values)} were given.", param, ctx)
        return tuple(t(v, param, ctx) for t, v in zip(self.types, values))


class File(ParamType):
    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def convert(self, value, param, ctx):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        writing = any(c in self.mode for c in "wax+")
        lazy = self.lazy if self.lazy is not None else writing
        try:
            handle = open_file(value, self.mode, self.encoding, self.errors, lazy=lazy, atomic=self.atomic)
        except OSError as e:
            self.fail(f"Could not open file {value!r}: {e.strerror or e}", param, ctx)
        if ctx is not None:
            ctx.resource_owner().callback(handle.close)
        return handle


class Path(ParamType):
    name = "path"

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def _finish(self, value):
        if self.resolve_path:
            value = os.path.realpath(value)
        if self.path_type is pathlib.Path:
            return pathlib.Path(value)
        return value

    def convert(self, value, param, ctx):
        text = os.fspath(value)
        if self.allow_dash and text == "-":
            return pathlib.Path("-") if self.path_type is pathlib.Path else "-"
        if os.path.exists(text):
            if not self.file_okay and os.path.isfile(text):
                self.fail(f"{text!r} is a file.", param, ctx)
            if not self.dir_okay and os.path.isdir(text):
                self.fail(f"{text!r} is a directory.", param, ctx)
            if self.readable and not os.access(text, os.R_OK):
                self.fail(f"{text!r} is not readable.", param, ctx)
            if self.writable and not os.access(text, os.W_OK):
                self.fail(f"{text!r} is not writable.", param, ctx)
            if self.executable and not os.access(text, os.X_OK):
                self.fail(f"{text!r} is not executable.", param, ctx)
        elif self.exists:
            self.fail(f"{text!r} does not exist.", param, ctx)
        return self._finish(text)


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParameterType()
UNPROCESSED = UnprocessedParamType()

_PYTHON_TYPES = {str: STRING, int: INT, float: FLOAT, bool: BOOL, uuid.UUID: UUID}


def convert_type(ty, default=None):
    """Resolve a declared type, or infer one from ``default`` when ``ty`` is None."""
    if ty is None:
        if default is None:
            return STRING
        if isinstance(default, bool):
            return BOOL
        if isinstance(default, int):
            return INT
        if isinstance(default, float):
            return FLOAT
        if isinstance(default, uuid.UUID):
            return UUID
        if isinstance(default, (list, tuple)) and default:
            return convert_type(None, default[0])
        return STRING
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, tuple):
        return Tuple(ty)
    if ty in _PYTHON_TYPES:
        return _PYTHON_TYPES[ty]
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")
