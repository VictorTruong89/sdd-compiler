"""Behavioural tests for Optlyn, organised by feature point of the specification."""

import os
import uuid

import pytest

import optlyn
from optlyn import (
    Abort,
    Choice,
    Context,
    File,
    FloatRange,
    IntRange,
    Path,
    argument,
    command,
    confirmation_option,
    custom_version_option,
    echo,
    group,
    help_option,
    make_pass_decorator,
    option,
    password_option,
    pass_context,
    pass_obj,
    style,
    unstyle,
)
from optlyn.formatting import wrap_text
from optlyn.testing import CliRunner


def invoke(cli, args=None, **kwargs):
    return CliRunner().invoke(cli, args or [], **kwargs)


# --- FP-01: declaration, naming, invocation ----------------------------------------------

def test_name_derivation_strips_suffix_and_dashes():
    @command()
    def init_db_command():
        pass

    @group()
    def tools_grp():
        pass

    assert init_db_command.name == "init-db"
    assert tools_grp.name == "tools"


def test_explicit_name_only_accepts_that_name():
    @group()
    def cli():
        pass

    @cli.command("ship")
    def deploy():
        print("shipped")

    assert invoke(cli, ["ship"]).output == "shipped\n"
    assert invoke(cli, ["deploy"]).exit_code == 2


def test_standalone_disabled_returns_value_and_raises_failures():
    @command()
    def add():
        return 42

    assert add.main([], standalone_mode=False) == 42

    @command()
    @option("--n", type=int, required=True)
    def need(n):
        pass

    with pytest.raises(optlyn.BadParameter):
        need.main([], standalone_mode=False)


def test_deprecated_command_runs_and_warns_on_stderr_channel():
    @command(deprecated="use new-thing")
    def old():
        print("ran")

    result = invoke(old)
    assert result.exit_code == 0
    assert "ran" in result.output
    assert "deprecated" in result.output
    assert "use new-thing" in result.output


def test_unknown_option_on_deprecated_command_is_usage_error():
    @command(deprecated=True)
    def old():
        pass

    assert invoke(old, ["--bogus"]).exit_code == 2


def test_extra_arguments_rejected_unless_allowed():
    @command()
    def cmd():
        pass

    assert invoke(cmd, ["extra"]).exit_code == 2

    @command(context_settings={"allow_extra_args": True})
    def cmd2(**kwargs):
        print("ok")

    assert invoke(cmd2, ["extra"]).exit_code == 0


def test_decorator_moves_params_and_redecorating_starts_empty():
    def f(a):
        pass

    option("--a")(f)
    cmd = command()(f)
    assert [p.name for p in cmd.params] == ["a"]
    assert not hasattr(f, "__optlyn_params__")


# --- FP-02: help ----------------------------------------------------------------------------

def test_help_prints_page_and_skips_callback():
    ran = []

    @command()
    @option("--x")
    def cmd(x):
        """Describe things.

        Second paragraph.
        """
        ran.append(x)

    result = invoke(cmd, ["--help"])
    assert result.exit_code == 0
    assert ran == []
    assert "Usage: cmd [OPTIONS]" in result.output
    assert "Describe things." in result.output
    assert "Options:" in result.output
    assert "--x" in result.output


def test_formfeed_truncates_help():
    @command(help="visible\fhidden")
    def cmd():
        pass

    out = invoke(cmd, ["--help"]).output
    assert "visible" in out
    assert "hidden" not in out
    assert "\f" not in out


def test_group_without_subcommand_is_usage_failure_with_help():
    @group()
    def cli():
        """Group help."""

    result = invoke(cli)
    assert result.exit_code == 2
    assert "Group help." in result.output


def test_default_metavar_and_show_default():
    @command()
    @option("--count", type=int, default=3, show_default=True)
    @argument("src")
    def cmd(count, src):
        pass

    out = invoke(cmd, ["--help"]).output
    assert "--count INTEGER" in out
    assert "[default: 3]" in out
    assert "SRC" in out


def test_flag_default_false_is_hidden_when_show_default_on():
    @command(context_settings={"show_default": True})
    @option("--verbose", is_flag=True)
    def cmd(verbose):
        pass

    assert "[default" not in invoke(cmd, ["--help"]).output


def test_version_option_is_eager_and_prints_identity():
    ran = []

    @command()
    @optlyn.version_option("1.2.3", prog_name="tool")
    @option("--must", required=True)
    def cmd(must):
        ran.append(True)

    result = invoke(cmd, ["--version"])
    assert result.exit_code == 0
    assert "1.2.3" in result.output
    assert ran == []


def test_custom_version_option_prints_exact_string():
    @command()
    @custom_version_option(lambda ctx: "custom build 9")
    def cmd():
        pass

    assert invoke(cmd, ["--version"]).output == "custom build 9\n"


def test_first_eager_flag_wins():
    @command()
    @custom_version_option(lambda ctx: "VER")
    @help_option()
    def cmd():
        """Help text."""

    assert invoke(cmd, ["--version", "--help"]).output == "VER\n"
    assert "Help text." in invoke(cmd, ["--help", "--version"]).output


def test_help_option_names_can_be_replaced_via_context():
    @command()
    def cmd():
        """Hi."""

    result = invoke(cmd, ["-h"], help_option_names=["-h"])
    assert result.exit_code == 0
    assert "Hi." in result.output
    assert invoke(cmd, ["--help"], help_option_names=["-h"]).exit_code == 2


def test_author_option_reusing_help_names_wins():
    @command()
    @option("--help", is_flag=True)
    def cmd(help):
        print("author", help)

    assert invoke(cmd, ["--help"]).output == "author True\n"


def test_help_with_no_args_is_help_for_leaf():
    @command(no_args_is_help=True)
    @argument("x", required=False)
    def cmd(x):
        """Leaf help."""

    result = invoke(cmd)
    assert result.exit_code == 2
    assert "Leaf help." in result.output


def test_hidden_option_omitted_from_help_but_accepted():
    @command()
    @option("--secret", hidden=True, default="s")
    def cmd(secret):
        print(secret)

    assert "--secret" not in invoke(cmd, ["--help"]).output
    assert invoke(cmd, ["--secret", "t"]).output == "t\n"


# --- FP-03: options -----------------------------------------------------------------------

def test_stacked_short_flags_and_value_attached():
    @command()
    @option("-a", is_flag=True)
    @option("-b", is_flag=True)
    @option("-n", type=int)
    def cmd(a, b, n):
        print(a, b, n)

    assert invoke(cmd, ["-abn5"]).output == "True True 5\n"
    assert invoke(cmd, ["-ab", "-n", "7"]).output == "True True 7\n"


def test_long_option_equals_and_separate_forms():
    @command()
    @option("--name")
    def cmd(name):
        print(name)

    assert invoke(cmd, ["--name=x"]).output == "x\n"
    assert invoke(cmd, ["--name", "y"]).output == "y\n"


def test_double_dash_ends_options():
    @command()
    @option("--flag", is_flag=True)
    @argument("rest", nargs=-1)
    def cmd(flag, rest):
        print(flag, rest)

    assert invoke(cmd, ["--", "--flag", "x"]).output == "False ('--flag', 'x')\n"


def test_counting_option():
    @command()
    @option("-v", "--verbose", count=True)
    def cmd(verbose):
        print(verbose)

    assert invoke(cmd, ["-vvv"]).output == "3\n"
    assert invoke(cmd).output == "0\n"


def test_repeatable_option_and_multi_value():
    @command()
    @option("--tag", multiple=True)
    @option("--pair", nargs=2, type=int)
    def cmd(tag, pair):
        print(tag, pair)

    result = invoke(cmd, ["--tag", "a", "--tag", "b", "--pair", "1", "2"])
    assert result.output == "('a', 'b') (1, 2)\n"
    assert invoke(cmd, ["--pair", "1"]).exit_code == 2


def test_bare_string_default_on_repeatable_is_usage_error():
    @command()
    @option("--tag", multiple=True, default="x")
    def cmd(tag):
        pass

    result = invoke(cmd)
    assert result.exit_code == 2
    assert "tag" in result.output or "TAG" in result.output


def test_boolean_pair_flags():
    @command()
    @option("--shout/--no-shout", default=False)
    def cmd(shout):
        print(shout)

    assert invoke(cmd, ["--shout"]).output == "True\n"
    assert invoke(cmd, ["--no-shout"]).output == "False\n"


def test_optional_value_option():
    @command()
    @option("--opt", is_flag=False, flag_value="flagged", default="dflt")
    def cmd(opt):
        print(opt)

    assert invoke(cmd).output == "dflt\n"
    assert invoke(cmd, ["--opt"]).output == "flagged\n"
    assert invoke(cmd, ["--opt", "given"]).output == "given\n"


def test_required_option_missing_is_usage_error_and_no_callback():
    ran = []

    @command()
    @option("--req", required=True)
    def cmd(req):
        ran.append(req)

    result = invoke(cmd)
    assert result.exit_code == 2
    assert "--req" in result.output
    assert ran == []


def test_unknown_option_is_usage_error_naming_it():
    @command()
    def cmd():
        pass

    result = invoke(cmd, ["--nope"])
    assert result.exit_code == 2
    assert "--nope" in result.output


def test_ignore_unknown_options_passes_them_to_arguments():
    @command(context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
    @argument("rest", nargs=-1)
    def cmd(rest):
        print(rest)

    assert invoke(cmd, ["--zzz", "a"]).output == "('--zzz', 'a')\n"


def test_alternative_prefix_slash():
    @command()
    @option("/x", is_flag=True)
    def cmd(x):
        print(x)

    assert invoke(cmd, ["/x"]).output == "True\n"


def test_feature_switch_last_declared_wins_on_tie():
    @command()
    @option("--a", "dest", flag_value="A", is_flag=True, default=False)
    @option("--b", "dest", flag_value="B", is_flag=True, default=False)
    def cmd(dest):
        print(dest)

    assert invoke(cmd, ["--a"]).output == "A\n"


def test_callback_refusal_is_usage_error():
    def check(ctx, param, value):
        if value < 0:
            raise optlyn.BadParameter("must be positive", ctx=ctx, param=param)
        return value * 2

    @command()
    @option("--n", type=int, callback=check)
    def cmd(n):
        print(n)

    assert invoke(cmd, ["--n", "4"]).output == "8\n"
    result = invoke(cmd, ["--n", "-1"])
    assert result.exit_code == 2
    assert "must be positive" in result.output


def test_callback_can_default_from_earlier_parameter():
    @command()
    @option("--a", default="x")
    @option("--b", default=None)
    def cmd(a, b):
        print(a, b)

    assert invoke(cmd).output == "x None\n"


# --- FP-04: arguments --------------------------------------------------------------------

def test_arguments_bind_in_order_with_variadic_last():
    @command()
    @argument("first")
    @argument("rest", nargs=-1)
    def cmd(first, rest):
        print(first, rest)

    assert invoke(cmd, ["a", "b", "c"]).output == "a ('b', 'c')\n"
    assert invoke(cmd, ["a"]).output == "a ()\n"


def test_missing_required_argument_names_it():
    @command()
    @argument("target")
    def cmd(target):
        pass

    result = invoke(cmd)
    assert result.exit_code == 2
    assert "TARGET" in result.output


def test_optional_argument_default_and_none_when_absent():
    @command()
    @argument("opt", required=False)
    @argument("dflt", default="d", required=False)
    def cmd(opt, dflt):
        print(opt, dflt)

    assert invoke(cmd).output == "None d\n"


def test_argument_env_requires_explicit_name(monkeypatch):
    monkeypatch.setenv("SRC", "from-env")

    @command()
    @argument("src", required=False)
    def cmd(src):
        print(src)

    assert invoke(cmd).output == "None\n"

    @command()
    @argument("src2", envvar="SRC_NAME", required=True)
    def cmd2(src2):
        print(src2)

    monkeypatch.setenv("SRC_NAME", "named")
    assert invoke(cmd2).output == "named\n"


# --- FP-05: parameter types --------------------------------------------------------------

@pytest.mark.parametrize("token, expected", [("1", True), ("no", False), ("ON", True)])
def test_bool_type(token, expected):
    @command()
    @option("--b", type=optlyn.BOOL)
    def cmd(b):
        print(b)

    assert invoke(cmd, ["--b", token]).output == f"{expected}\n"


def test_int_rejects_fraction():
    @command()
    @option("--n", type=int)
    def cmd(n):
        pass

    assert invoke(cmd, ["--n", "1.5"]).exit_code == 2


def test_choice_returns_original_object_case_insensitive():
    import enum

    class Color(enum.Enum):
        RED = 1

    @command()
    @option("--c", type=Choice(Color, case_sensitive=False))
    def cmd(c):
        print(repr(c))

    assert invoke(cmd, ["--c", "red"]).output == "<Color.RED: 1>\n"
    assert invoke(cmd, ["--c", "blue"]).exit_code == 2


def test_choice_list_matching_and_metavar():
    @command()
    @option("--mode", type=Choice(["fast", "slow"]))
    def cmd(mode):
        print(mode)

    assert invoke(cmd, ["--mode", "fast"]).output == "fast\n"
    assert "[fast|slow]" in invoke(cmd, ["--help"]).output


def test_int_range_clamp_and_refuse():
    @command()
    @option("--n", type=IntRange(0, 10, clamp=True))
    def cmd(n):
        print(n)

    assert invoke(cmd, ["--n", "99"]).output == "10\n"

    @command()
    @option("--n", type=IntRange(0, 10))
    def strict(n):
        pass

    assert invoke(strict, ["--n", "11"]).exit_code == 2


def test_float_range_refuses_open_clamp():
    with pytest.raises(ValueError):
        FloatRange(0.0, 1.0, min_open=True, clamp=True)


def test_datetime_formats_and_custom_list():
    import datetime

    @command()
    @option("--when", type=optlyn.DateTime())
    def cmd(when):
        print(repr(when))

    assert invoke(cmd, ["--when", "2024-01-02"]).output == repr(datetime.datetime(2024, 1, 2)) + "\n"
    assert invoke(cmd, ["--when", "2024-01-02 03:04:05"]).exit_code == 0
    assert invoke(cmd, ["--when", "02/01/2024"]).exit_code == 2


def test_uuid_type_and_custom_function_type():
    @command()
    @option("--u", type=optlyn.UUID)
    @option("--d", type=lambda s: s.upper())
    def cmd(u, d):
        print(type(u).__name__, d)

    value = str(uuid.uuid4())
    assert invoke(cmd, ["--u", value, "--d", "abc"]).output == "UUID ABC\n"


def test_tuple_type_option():
    @command()
    @option("--point", type=optlyn.Tuple([str, int]))
    def cmd(point):
        print(point)

    assert invoke(cmd, ["--point", "a", "3"]).output == "('a', 3)\n"


def test_envvar_splits_multiple_values(monkeypatch):
    monkeypatch.setenv("NUMS", "1  2 3")

    @command()
    @option("--n", type=int, multiple=True, envvar="NUMS")
    def cmd(n):
        print(n)

    assert invoke(cmd).output == "(1, 2, 3)\n"


# --- FP-06: groups ------------------------------------------------------------------------

def _tree():
    @group()
    @option("--root-opt", default="r")
    def cli(root_opt):
        print("group", root_opt)

    @cli.command()
    @option("--x", default="1")
    def leaf(x):
        print("leaf", x)

    @cli.group()
    def inner():
        print("inner callback")

    @inner.command()
    def deep():
        print("deep")

    return cli


def test_group_callback_runs_before_child_and_parent_options_precede():
    cli = _tree()
    out = invoke(cli, ["--root-opt", "z", "leaf", "--x", "2"]).output
    assert out == "group z\nleaf 2\n"


def test_nested_group_runs_outer_then_leaf():
    cli = _tree()
    assert invoke(cli, ["inner", "deep"]).output == "group r\ninner callback\ndeep\n"


def test_nested_group_without_name_shows_its_own_help_as_usage_failure():
    cli = _tree()
    result = invoke(cli, ["inner"])
    assert result.exit_code == 2
    assert "inner callback" not in result.output
    assert "Usage: cli inner" in result.output


def test_skipping_middle_name_is_unknown_command():
    cli = _tree()
    assert invoke(cli, ["deep"]).exit_code == 2


def test_help_before_subcommand_is_for_group():
    cli = _tree()
    result = invoke(cli, ["--help", "leaf"])
    assert result.exit_code == 0
    assert "Usage: cli" in result.output


def test_invoke_without_command_callback_and_context_flag():
    seen = []

    @group(invoke_without_command=True)
    def cli(ctx=None):
        seen.append(None)

    @group(invoke_without_command=True)
    @pass_context
    def cli2(ctx):
        seen.append(ctx.invoked_subcommand)

    @cli2.command()
    def sub():
        print("sub")

    invoke(cli2, [])
    invoke(cli2, ["sub"])
    assert seen == [None, "sub"]


def test_command_collection_union_of_sources():
    @group()
    def a():
        pass

    @a.command()
    def one():
        print("one")

    @group()
    def b():
        pass

    @b.command()
    def two():
        print("two")

    coll = optlyn.CommandCollection(sources=[a, b])
    assert invoke(coll, ["one"]).output == "one\n"
    assert invoke(coll, ["two"]).output == "two\n"


def test_custom_group_lazy_lookup():
    class Lazy(optlyn.Group):
        def list_commands(self, ctx):
            return ["dyn"]

        def get_command(self, ctx, name):
            if name != "dyn":
                return None

            @optlyn.command()
            def dyn():
                print("loaded")

            return dyn

    lazy = Lazy(name="lazy", no_args_is_help=False)
    assert invoke(lazy, ["dyn"]).output == "loaded\n"
    assert invoke(lazy, ["nope"]).exit_code == 2


def test_chaining_group_runs_each_and_result_callback():
    @group(chain=True)
    def cli():
        pass

    @cli.result_callback()
    def done(results):
        print("results", results)

    @cli.command()
    @option("--v", default="a")
    def one(v):
        return f"one-{v}"

    @cli.command()
    @argument("w")
    def two(w):
        return f"two-{w}"

    out = invoke(cli, ["one", "--v", "z", "two", "q"]).output
    assert out == "results ['one-z', 'two-q']\n"


def test_chain_nested_group_refused_at_declaration():
    @group(chain=True)
    def cli():
        pass

    @group()
    def inner():
        pass

    with pytest.raises(RuntimeError):
        cli.add_command(inner)


def test_chain_standalone_off_returns_list():
    @group(chain=True)
    def cli():
        pass

    @cli.command()
    def one():
        return 1

    assert cli.main(["one", "one"], standalone_mode=False) == [1, 1]


# --- FP-07: context, defaults, environment -----------------------------------------------

def test_default_map_fills_and_command_line_beats_it():
    @command()
    @option("--a", default="d")
    @option("--b", default="d")
    def cmd(a, b):
        print(a, b)

    assert invoke(cmd, ["--b", "cli"], default_map={"a": "map", "b": "map"}).output == "map cli\n"


def test_default_map_nested_under_subcommand_name():
    @group()
    def cli():
        pass

    @cli.command()
    @option("--a", default="d")
    def sub(a):
        print(a)

    assert invoke(cli, ["sub"], default_map={"sub": {"a": "mapped"}}).output == "mapped\n"
    assert invoke(cli, ["sub"], default_map={"other": {"a": "mapped"}}).output == "d\n"


def test_envvar_before_default_map_and_auto_prefix(monkeypatch):
    monkeypatch.setenv("APP_SUB_OPT", "from-env")

    @group()
    def tool():
        pass

    @tool.command()
    @option("--opt", default="d")
    def sub(opt):
        print(opt)

    assert invoke(tool, ["sub"], auto_envvar_prefix="APP").output == "from-env\n"


def test_auto_prefix_satisfies_required_option(monkeypatch):
    monkeypatch.setenv("TOOL_TOKEN", "abc")

    @command()
    @option("--token", required=True)
    def cmd(token):
        print(token)

    assert invoke(cmd, auto_envvar_prefix="TOOL").output == "abc\n"


def test_parameter_source_inspection():
    seen = {}

    @command()
    @option("--a", default="d")
    @option("--b")
    def cmd(ctx, a, b):
        pass

    @command()
    @option("--a", default="d")
    @option("--b")
    @pass_context
    def cmd2(ctx, a, b):
        seen["a"] = ctx.get_parameter_source("a")
        seen["b"] = ctx.get_parameter_source("b")
        seen["none"] = ctx.get_parameter_source("nope")

    invoke(cmd2, ["--b", "x"])
    assert seen["a"] == optlyn.ParameterSource.DEFAULT
    assert seen["b"] == optlyn.ParameterSource.COMMANDLINE
    assert seen["none"] is None


def test_author_object_lookup_and_ensure():
    class Settings:
        pass

    @command()
    @make_pass_decorator(Settings, ensure=True)
    def cmd(obj):
        print(type(obj).__name__)

    assert invoke(cmd).output == "Settings\n"


def test_pass_obj_passes_context_object():
    @command()
    @pass_obj
    def cmd(obj):
        print(obj)

    assert invoke(cmd, obj="hello").output == "hello\n"


def test_invoke_another_command_from_callback():
    @command()
    @option("--x", default="dx")
    def other(x):
        print("other", x)

    @command()
    @option("--x", default="own")
    @pass_context
    def cmd(ctx, x):
        ctx.forward(other)
        ctx.invoke(other, x="explicit")

    assert invoke(cmd).output == "other own\nother explicit\n"


def test_with_resource_closed_when_invocation_ends(tmp_path):
    closed = []

    class Res:
        def __enter__(self):
            return "R"

        def __exit__(self, *a):
            closed.append(True)

    @group()
    @pass_context
    def cli(ctx):
        ctx.with_resource(Res())

    @cli.command()
    def sub():
        raise optlyn.BadParameter("boom")

    assert invoke(cli, ["sub"]).exit_code == 2
    assert closed == [True]


# --- FP-08: prompts, confirmation, hidden input ------------------------------------------

def test_prompt_reads_when_omitted_and_uses_default_on_empty_line():
    @command()
    @option("--name", prompt=True)
    def cmd(name):
        print("hi", name)

    assert invoke(cmd, input="bob\n").output.endswith("hi bob\n")
    assert invoke(cmd, ["--name", "x"], input="bob\n").output == "hi x\n"


def test_prompt_reasks_on_conversion_failure():
    @command()
    @option("--n", type=int, prompt=True)
    def cmd(n):
        print("n", n)

    out = invoke(cmd, input="abc\n7\n").output
    assert "n 7" in out


def test_prompt_eof_is_abort():
    @command()
    @option("--name", prompt=True)
    def cmd(name):
        pass

    result = invoke(cmd, input="")
    assert result.exit_code == 1
    assert "Aborted!" in result.output


def test_hidden_prompt_does_not_echo():
    @command()
    @option("--pw", prompt=True, hide_input=True)
    def cmd(pw):
        print("pw", pw)

    result = invoke(cmd, input="secret\n")
    assert "secret" not in result.stdout.split("pw")[0]
    assert "pw secret" in result.output


def test_password_option_confirms_and_rejects_mismatch():
    @command()
    @password_option()
    def cmd(password):
        print("got", password)

    assert invoke(cmd, input="a\na\n").output.endswith("got a\n")
    result = invoke(cmd, input="a\nb\n")
    assert "do not match" in result.output
    assert "got" not in result.output


def test_confirmation_option_flag_skips_question():
    ran = []

    @command()
    @confirmation_option()
    def cmd():
        ran.append(1)

    assert invoke(cmd, ["--yes"]).exit_code == 0
    assert ran == [1]


def test_confirmation_declined_aborts_without_callback():
    ran = []

    @command()
    @confirmation_option()
    def cmd():
        ran.append(1)

    result = invoke(cmd, input="n\n")
    assert result.exit_code == 1
    assert ran == []


def test_standalone_confirm_and_prompt_helpers():
    @command()
    def cmd():
        print(optlyn.confirm("Sure?"))
        print(optlyn.prompt("Name", type=int))

    result = invoke(cmd, input="maybe\nyes\n5\n")
    assert "True" in result.output
    assert "5" in result.output


def test_deprecated_with_prompt_refused_at_declaration():
    with pytest.raises(ValueError):
        optlyn.Option(["--x"], deprecated=True, prompt=True)


# --- FP-09: files and paths --------------------------------------------------------------

def test_file_read_missing_is_usage_error(tmp_path):
    @command()
    @option("--f", type=File("r"))
    def cmd(f):
        pass

    result = invoke(cmd, ["--f", str(tmp_path / "nope.txt")])
    assert result.exit_code == 2
    assert "nope.txt" in result.output


def test_file_write_lazy_then_lazy_failure_is_general_error(tmp_path):
    @command()
    @argument("f", type=File("w"))
    def cmd(f):
        f.write("hello")

    target = tmp_path / "out.txt"
    result = invoke(cmd, [str(target)])
    assert result.exit_code == 0
    assert target.read_text() == "hello"

    bad = tmp_path / "missing-dir" / "x.txt"
    result = invoke(cmd, [str(bad)])
    assert result.exit_code == 1


def test_non_lazy_write_truncates_before_callback(tmp_path):
    target = tmp_path / "t.txt"
    target.write_text("old")

    @command()
    @option("--f", type=File("w", lazy=False))
    def cmd(f):
        pass

    invoke(cmd, ["--f", str(target)])
    assert target.read_text() == ""


def test_atomic_write_keeps_original_until_close(tmp_path):
    target = tmp_path / "a.txt"
    target.write_text("original")

    @command()
    @argument("f", type=File("w", atomic=True))
    def cmd(f):
        f.write("new")
        assert target.read_text() == "original"

    invoke(cmd, [str(target)])
    assert target.read_text() == "new"


def test_dash_stdout_not_closed():
    @command()
    @argument("f", type=File("w"))
    def cmd(f):
        f.write("via dash\n")
        f.close()
        print("after")

    result = invoke(cmd, ["-"])
    assert "via dash" in result.output
    assert "after" in result.output


def test_path_checks(tmp_path):
    existing = tmp_path / "exists.txt"
    existing.write_text("x")

    @command()
    @argument("p", type=Path(exists=True, dir_okay=False))
    def cmd(p):
        print(p)

    assert invoke(cmd, [str(existing)]).exit_code == 0
    assert invoke(cmd, [str(tmp_path)]).exit_code == 2
    assert invoke(cmd, [str(tmp_path / "gone")]).exit_code == 2


def test_path_dash_allowed_without_stream():
    @command()
    @argument("p", type=Path(allow_dash=True))
    def cmd(p):
        print(p)

    assert invoke(cmd, ["-"]).output == "-\n"


def test_filename_format_is_utf8_safe():
    assert optlyn.format_filename(b"caf\xc3\xa9") == "café"
    assert "\\udcff" in optlyn.format_filename(b"\xff")


# --- FP-11: terminal helpers ---------------------------------------------------------------

def test_echo_strips_styles_when_not_terminal():
    @command()
    def cmd():
        echo(style("hi", fg="red"))

    assert invoke(cmd).output == "hi\n"
    assert invoke(cmd, color=True).output == style("hi", fg="red") + "\n"


def test_echo_to_stderr():
    @command()
    def cmd():
        echo("oops", err=True)

    result = invoke(cmd)
    assert result.stdout == ""
    assert result.stderr == "oops\n"


def test_style_roundtrip_and_invalid_color():
    assert unstyle(style("abc", bold=True, fg=(1, 2, 3))) == "abc"
    assert style("x", fg="red") != style("x", bg="red")
    assert style("x", bold=True) != style("x", italic=True)
    with pytest.raises(TypeError):
        style("x", fg="nope")


def test_wrap_text_accepts_any_string():
    assert wrap_text("") == ""
    assert "word" in wrap_text("word " * 50, width=20)


def test_get_app_dir_posix_forced(monkeypatch):
    monkeypatch.setenv("XDG_CONFIG_HOME", "/somewhere")
    assert optlyn.get_app_dir("My App", force_posix=True).endswith("/.my-app")
    if os.name == "posix":
        assert optlyn.get_app_dir("My App").startswith("/somewhere")


def test_clear_does_nothing_when_not_terminal():
    @command()
    def cmd():
        optlyn.clear()

    assert invoke(cmd).output == ""


def test_pause_non_interactive_returns_immediately():
    @command()
    def cmd():
        optlyn.pause("waiting")

    assert invoke(cmd).output == ""


# --- FP-12: shell completion -------------------------------------------------------------

def _complete(cmd, words, cword, prog="tool", shell="bash"):
    env = {
        "_TOOL_COMPLETE": f"{shell}_complete",
        "COMP_WORDS": " ".join(words),
        "COMP_CWORD": str(cword),
    }
    return CliRunner().invoke(cmd, [], env=env, prog_name=prog).output


def test_complete_subcommands_and_options():
    @group()
    def tool():
        pass

    @tool.command()
    def alpha():
        pass

    @tool.command(hidden=True)
    def secret():
        pass

    @tool.command()
    @option("--verbose", is_flag=True)
    def beta(verbose):
        pass

    assert _complete(tool, ["tool", "a"], 1) == "alpha\n"
    assert _complete(tool, ["tool", ""], 1).split() == ["alpha", "beta"]
    assert "--verbose" in _complete(tool, ["tool", "beta", "--"], 2)
    assert _complete(tool, ["tool", "beta", "--"], 2).find("--help") >= 0


def test_complete_choice_values_and_path_request(tmp_path):
    @command()
    @option("--mode", type=Choice(["alpha", "beta"]))
    @argument("f", type=Path())
    def cmd(mode, f):
        pass

    assert _complete(cmd, ["tool", "--mode", "al"], 2, shell="bash") == "alpha\n"
    out = _complete(cmd, ["tool", "x"], 1)
    assert "\x1ffile\x1f" in out


def test_source_script_and_unknown_instruction():
    @command()
    def cmd():
        print("should not run")

    src = CliRunner().invoke(cmd, [], env={"_TOOL_COMPLETE": "bash_source"}, prog_name="tool").output
    assert "complete -o default" in src
    assert "should not run" not in src

    result = CliRunner().invoke(cmd, [], env={"_TOOL_COMPLETE": "nope"}, prog_name="tool")
    assert result.output == ""


def test_completion_ignored_for_other_program_name():
    @command()
    def cmd():
        print("ran")

    result = CliRunner().invoke(cmd, [], env={"_OTHER_COMPLETE": "bash_source"}, prog_name="tool")
    assert result.output == "ran\n"


# --- FP-13: exit statuses ----------------------------------------------------------------

def test_author_exit_status_and_clean_stop():
    @command()
    def stop():
        print("before")
        pass_ctx_exit()
        print("never")

    def pass_ctx_exit():
        get_ctx = optlyn.get_current_context()
        get_ctx.exit(7)

    result = invoke(stop)
    assert result.exit_code == 7
    assert "never" not in result.output


def test_author_abort_exit_one_with_indication():
    @command()
    def cmd():
        raise Abort()

    result = invoke(cmd)
    assert result.exit_code == 1
    assert "Aborted!" in result.output


def test_success_exit_zero():
    @command()
    def cmd():
        pass

    assert invoke(cmd).exit_code == 0


# --- FP-14: in-process runner ------------------------------------------------------------

def test_runner_captures_stdout_stderr_and_exception():
    @command()
    def cmd():
        print("out")
        echo("err", err=True)
        raise ValueError("bad")

    result = invoke(cmd)
    assert result.exit_code == 1
    assert result.stdout == "out\n"
    assert result.stderr == "err\n"
    assert isinstance(result.exception, ValueError)
    assert result.output == "out\nerr\n"


def test_runner_can_propagate_exceptions():
    @command()
    def cmd():
        raise ValueError("bad")

    with pytest.raises(ValueError):
        CliRunner(catch_exceptions=False).invoke(cmd, [])


def test_runner_env_unset_and_restore(monkeypatch):
    monkeypatch.setenv("KEEP_ME", "yes")

    @command()
    def cmd():
        print(os.environ.get("KEEP_ME"), os.environ.get("TEMP_VAR"))

    result = invoke(cmd, env={"KEEP_ME": None, "TEMP_VAR": "t"})
    assert result.output == "None t\n"
    assert os.environ.get("KEEP_ME") == "yes"
    assert "TEMP_VAR" not in os.environ


def test_runner_isolated_filesystem_removed_without_parent(tmp_path):
    runner = CliRunner()
    with runner.isolated_filesystem() as path:
        assert os.getcwd() == os.path.realpath(path)
        leftover = path
    assert not os.path.exists(leftover)

    with runner.isolated_filesystem(temp_dir=str(tmp_path)) as path:
        kept = path
    assert os.path.isdir(kept)


def test_runner_input_is_consumed_and_visible_prompt_echoed():
    @command()
    @option("--name", prompt=True)
    def cmd(name):
        print(name)

    result = invoke(cmd, input="zed\n")
    assert "zed" in result.output


def test_runner_fd_capture_mode():
    @command()
    def cmd():
        os.write(1, b"raw-fd\n")
        print("py")

    result = CliRunner(capture="fd").invoke(cmd, [])
    assert "raw-fd" in result.stdout
    assert "py" in result.stdout


def test_runner_default_capture_has_no_real_fileno():
    @command()
    def cmd():
        try:
            sys_fileno = optlyn.get_current_context().command  # noqa: F841
        except Exception:
            pass
        import sys

        try:
            sys.stdout.fileno()
            print("has-fd")
        except Exception:
            print("no-fd")

    assert invoke(cmd).output == "no-fd\n"


def test_runner_prog_name_and_extra_settings():
    @command()
    @option("--x", type=int, default=1)
    def cmd(x):
        print(optlyn.get_current_context().command_path)

    assert invoke(cmd).output == "cmd\n"


def test_runner_accepts_string_args():
    @command()
    @option("--name")
    def cmd(name):
        print(name)

    assert CliRunner().invoke(cmd, "--name bob").output == "bob\n"


def test_get_current_context_raises_outside_invocation():
    with pytest.raises(RuntimeError):
        optlyn.get_current_context()
    assert optlyn.get_current_context(silent=True) is None


def test_public_exports_present():
    for name in ("command", "group", "option", "argument", "Context", "Command", "Group",
                 "CommandCollection", "BadParameter", "Abort", "STRING", "INT", "FLOAT", "BOOL",
                 "UUID", "UNPROCESSED", "Choice", "DateTime", "IntRange", "FloatRange", "Tuple",
                 "File", "Path", "echo", "secho", "style", "unstyle", "echo_via_pager",
                 "get_pager_file", "progressbar", "prompt", "confirm", "getchar", "pause", "edit",
                 "launch", "clear", "get_app_dir", "get_current_context", "format_filename",
                 "open_file"):
        assert hasattr(optlyn, name), name
    from optlyn.testing import CliRunner as R  # noqa: F401
    from optlyn.formatting import wrap_text as W  # noqa: F401
