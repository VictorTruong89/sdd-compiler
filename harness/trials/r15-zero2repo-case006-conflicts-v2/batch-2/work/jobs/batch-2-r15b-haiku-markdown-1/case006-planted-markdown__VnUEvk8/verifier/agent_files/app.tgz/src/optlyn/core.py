"""Commands, groups, invocation context, and the standalone entry point."""

import enum
import os
import sys
from contextlib import ExitStack

from ._state import peek_context, pop_context, push_context
from .exceptions import (Abort, BadParameter, Exit, MissingParameter, OptlynError,
                         UsageError)
from .parameters import PREFIX_CHARS, Argument, Option
from .parser import PROMPT, Parser
from .termui import echo
from .types import Tuple

_MISSING = object()


class ParameterSource(enum.Enum):
    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


class NoArgsHelp(UsageError):
    """No arguments were given to a command that shows help in that case (usage failure)."""

    def __init__(self, ctx):
        super().__init__("", ctx)

    def show(self, file=None):
        from .help import format_help

        target = file or sys.stderr
        echo(format_help(self.ctx), err=True, file=target, nl=False)


class _ChainMarker:
    """Stands in for ``invoked_subcommand`` on a chaining group that runs children."""

    def __repr__(self):
        return "<chain>"


CHAIN_MARKER = _ChainMarker()


class Context:
    """Per-invocation state."""

    def __init__(self, command, parent=None, info_name=None, obj=None, default_map=None,
                 terminal_width=None, max_content_width=None, help_option_names=None,
                 token_normalize_func=None, color=None, show_default=None,
                 allow_extra_args=None, ignore_unknown_options=None,
                 allow_interspersed_args=None, auto_envvar_prefix=None):
        def inherit(value, attr, fallback):
            if value is not None:
                return value
            if parent is not None:
                return getattr(parent, attr)
            return fallback

        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.default_map = default_map
        self.terminal_width = inherit(terminal_width, "terminal_width", None)
        self.max_content_width = inherit(max_content_width, "max_content_width", None)
        self.help_option_names = list(inherit(help_option_names, "help_option_names", ["--help"]))
        self.token_normalize_func = inherit(token_normalize_func, "token_normalize_func", None)
        self.color = inherit(color, "color", None)
        self.show_default = inherit(show_default, "show_default", False)
        self.allow_extra_args = bool(allow_extra_args) if allow_extra_args is not None else False
        self.ignore_unknown_options = bool(ignore_unknown_options) if ignore_unknown_options is not None else False
        self.allow_interspersed_args = (
            allow_interspersed_args if allow_interspersed_args is not None
            else command.interspersed)
        self.auto_envvar_prefix = inherit(auto_envvar_prefix, "auto_envvar_prefix", None)
        self.params = {}
        self.args = []
        self.invoked_subcommand = None
        self._tokens = []
        self._sources = {}
        self._ensured = {}
        self._env_path = (parent._env_path + [info_name]) if parent is not None else []
        self._exit_stack = ExitStack() if parent is None else None

    # Context-manager protocol: makes this context current on the thread.
    def __enter__(self):
        push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        pop_context()
        return False

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if object_type in node._ensured:
                return node._ensured[object_type]
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self._ensured[object_type] = found
        return found

    def auto_envvar_prefix_for(self, param):
        """Environment name built from the prefix, subcommand path, and destination."""
        if not self.auto_envvar_prefix:
            return None
        parts = [self.auto_envvar_prefix] + self._env_path + [param.name]
        return "_".join(p for p in parts if p).upper().replace("-", "_")

    def get_parameter_source(self, name):
        if not any(p.name == name for p in self.command.params):
            return None
        return self._sources.get(name)

    def with_resource(self, cm):
        return self.find_root()._exit_stack.enter_context(cm)

    def close(self):
        if self._exit_stack is not None:
            self._exit_stack.close()

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def get_help(self):
        from .help import format_help

        return format_help(self)

    def invoke(self, other, **values):
        """Run another command with exactly the given values (other defaults filled in)."""
        return _call_target(self, other, dict(values))

    def forward(self, other, **values):
        """Run another command, passing this command's values first, then ``values``."""
        merged = {k: v for k, v in self.params.items()}
        merged.update(values)
        return _call_target(self, other, merged)


def _call_target(ctx, target, values):
    if not isinstance(target, Command):
        return target(**values)
    sub = target.make_context(target.name, [], parent=ctx)
    kwargs = {}
    with sub:
        for p in target.params:
            if p.name in values:
                kwargs[p.name] = values[p.name]
            elif p.expose_value:
                default = p.get_default() if not isinstance(p, Argument) else p.get_default()
                if default is None and (p.multiple or getattr(p, "variadic", False)):
                    default = ()
                kwargs[p.name] = default
        sub.params = {k: v for k, v in kwargs.items()}
        return target.callback(**{k: v for k, v in kwargs.items()}) if target.callback else None


def get_current_context(silent=False):
    ctx = peek_context()
    if ctx is None and not silent:
        raise RuntimeError("There is no active Optlyn context.")
    return ctx


# Value helpers ------------------------------------------------------------

def _shape_tokens(param, tokens):
    """Shape a flat token list into the form ``convert_value`` expects."""
    if isinstance(param, Argument):
        if param.variadic or param.nargs != 1:
            return tuple(tokens)
        return tokens[0]
    if param.multiple:
        if param.nargs == 1:
            return list(tokens)
        n = param.nargs
        return [tuple(tokens[i:i + n]) for i in range(0, len(tokens), n)]
    if param.nargs == 1:
        return tokens[0]
    return tuple(tokens)


def _convert_default(param, value, ctx):
    """Convert a declared or default-map value that is already in delivered shape."""
    if value is None:
        return None
    if isinstance(param, Argument):
        if param.variadic:
            return tuple(param.convert_one(v, ctx) for v in value)
        if param.nargs == 1:
            return param.convert_one(value, ctx)
        if isinstance(param.type, Tuple):
            return param.type.convert(value, param, ctx)
        return tuple(param.convert_one(v, ctx) for v in value)
    if param.multiple:
        items = []
        for item in value:
            if param.nargs == 1:
                items.append(param.convert_one(item, ctx))
            elif isinstance(param.type, Tuple):
                items.append(param.type.convert(item, param, ctx))
            else:
                items.append(tuple(param.convert_one(v, ctx) for v in item))
        return tuple(items)
    if param.nargs == 1:
        return param.convert_one(value, ctx)
    if isinstance(param.type, Tuple):
        return param.type.convert(value, param, ctx)
    return tuple(param.convert_one(v, ctx) for v in value)


def _empty_value(param):
    if isinstance(param, Argument) and param.variadic:
        return ()
    if param.multiple:
        return ()
    if getattr(param, "count", False):
        return 0
    if param.is_flag:
        return False
    return None


class Command:
    """A bare command: options, arguments, and a callback."""

    interspersed = True

    def __init__(self, name, callback=None, params=None, help=None, short_help=None,
                 epilog=None, options_metavar="[OPTIONS]", context_settings=None,
                 add_help_option=True, no_args_is_help=False, deprecated=False,
                 hidden=False):
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        self.help = help
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden
        self._check_params()

    def _check_params(self):
        seen = set()
        for p in self.params:
            if p.name in seen and not isinstance(p, Option):
                raise ValueError(f"Duplicate parameter destination {p.name!r}.")
            seen.add(p.name)

    @property
    def options(self):
        return [p for p in self.params if isinstance(p, Option)]

    @property
    def arguments(self):
        return [p for p in self.params if isinstance(p, Argument)]

    @property
    def deprecation_note(self):
        return self.deprecated if isinstance(self.deprecated, str) else None

    def get_short_help_str(self, limit=45):
        from .formatting import first_sentence

        text = self.short_help or first_sentence(self.help or "")
        if len(text) > limit:
            text = text[: max(0, limit - 3)].rstrip() + "..."
        return text

    # Context construction ----------------------------------------------------

    def make_context(self, info_name, args, parent=None, **extra):
        settings = dict(self.context_settings)
        settings.update(extra)
        default_map = settings.pop("default_map", None)
        if parent is not None and parent.default_map:
            child_map = parent.default_map.get(info_name)
            if child_map is not None:
                default_map = child_map
        ctx = Context(self, parent=parent, info_name=info_name,
                      default_map=default_map, **settings)
        ctx._tokens = list(args)
        return ctx

    # Invocation --------------------------------------------------------------

    def invoke(self, ctx):
        """Run this command in ``ctx``. Caller holds ``ctx`` as current."""
        if self.deprecated:
            _warn_deprecated("command", self.name, self.deprecation_note)
        if not ctx._tokens and self.no_args_is_help:
            raise NoArgsHelp(ctx)
        parser = Parser(self, ctx, interspersed=ctx.allow_interspersed_args,
                        ignore_unknown=ctx.ignore_unknown_options,
                        allow_extra=ctx.allow_extra_args)
        res = parser.parse(ctx._tokens)
        ctx.args = res.leftover
        self._bind(ctx, res)
        return self._run_callback(ctx)

    def _run_callback(self, ctx):
        if self.callback is None:
            return None
        kwargs = {p.name: ctx.params[p.name] for p in self.params
                  if p.expose_value and p.name in ctx.params}
        return self.callback(**kwargs)

    def _bind(self, ctx, res):
        """Resolve every parameter from its sources, in order, and run callbacks."""
        for p in res.used_deprecated:
            _warn_deprecated("option" if isinstance(p, Option) else "argument",
                             p.human_readable_name if isinstance(p, Option) else p.name,
                             p.deprecation_note)
        ordered = [p for p in self.params if p.is_eager] + [
            p for p in self.params if not p.is_eager]
        for p in ordered:
            raw = res.raw.get(p, _MISSING)
            value, source = self._resolve(p, ctx, raw)
            if p.required and source is None:
                raise MissingParameter(f"Missing parameter '{p.name}'.", ctx=ctx, param=p)
            # An eager flag typed on the command line already ran its callback during parsing.
            if p.callback is not None and not (
                    p.is_eager and source is ParameterSource.COMMANDLINE):
                value = p.callback(ctx, p, value)
            ctx._sources[p.name] = source
            if p.expose_value:
                ctx.params[p.name] = value

    def _resolve(self, p, ctx, raw):
        """Return (value, source) for one parameter.

        Order: prompt, command line, environment, default map, declared default.
        """
        if raw is not _MISSING and raw is not PROMPT:
            return self._from_cmdline(p, ctx, raw), ParameterSource.COMMANDLINE

        found, env_raw = p.value_from_env(ctx)
        if found:
            if p.is_flag:
                ok, value = p.get_envvar_flag_value(env_raw)
                if ok:
                    return value, ParameterSource.ENVIRONMENT
            else:
                return self._from_tokens(p, ctx, p.split_env(env_raw)), ParameterSource.ENVIRONMENT

        fallback, fallback_source = self._fallback(p, ctx)
        wants_prompt = raw is PROMPT or (
            p.prompt is not None and p.prompt_required and raw is _MISSING)
        if wants_prompt and not p.is_flag:
            return self._prompt(p, ctx, fallback), ParameterSource.PROMPT
        if fallback is None:
            return _empty_value(p), None
        return fallback, fallback_source

    def _from_cmdline(self, p, ctx, raw):
        if p.is_flag or p.count:
            return raw
        return p.convert_value(raw, ctx)

    def _from_tokens(self, p, ctx, tokens):
        return p.convert_value(_shape_tokens(p, tokens), ctx)

    def _fallback(self, p, ctx):
        """Default-map value, then declared default. Returns (converted value or None, source)."""
        if ctx.default_map and p.name in ctx.default_map:
            raw = ctx.default_map[p.name]
            if isinstance(raw, str) and (p.multiple or p.nargs != 1 or isinstance(p.type, Tuple)):
                if p.multiple and p.nargs == 1:
                    raise BadParameter("needs an iterable (sequence) default for a repeatable option.",
                                       ctx=ctx, param=p)
                raw = tuple(p.split_env(raw))
            elif isinstance(raw, str) and p.multiple:
                raise BadParameter("needs an iterable (sequence) default for a repeatable option.",
                                   ctx=ctx, param=p)
            return _convert_default(p, raw, ctx), ParameterSource.DEFAULT_MAP
        if p.is_flag:
            default = p.get_default()
            if default is None:
                default = False
            return default if isinstance(default, bool) else default, ParameterSource.DEFAULT
        default = p.get_default()
        if default is None:
            return None, None
        return _convert_default(p, default, ctx), ParameterSource.DEFAULT

    def _prompt(self, p, ctx, fallback):
        from .termui import prompt as _prompt

        text = p.prompt if isinstance(p.prompt, str) else p.name.replace("_", " ").capitalize()
        default = fallback
        if default is not None and not isinstance(default, str):
            default = _display_default(default)
        return _prompt(text, default=default, hide_input=p.hide_input,
                       confirmation_prompt=p.confirmation_prompt, type=p.type)

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # Standalone entry point --------------------------------------------------

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        if args is None:
            args = sys.argv[1:]
        else:
            args = list(args)
        if prog_name is None:
            prog_name = _default_prog_name()
        from .shell_completion import maybe_complete

        if maybe_complete(self, prog_name, complete_var, args):
            return None
        ctx = self.make_context(prog_name, args, **extra)
        try:
            try:
                with ctx:
                    rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                sys.exit(0)
            except Exit as e:
                if not standalone_mode:
                    return e.exit_code
                sys.exit(e.exit_code)
            except OptlynError as e:
                if not standalone_mode:
                    raise
                e.show()
                sys.exit(e.exit_code)
            except (EOFError, KeyboardInterrupt):
                if not standalone_mode:
                    raise
                echo("Aborted!", err=True)
                sys.exit(1)
        finally:
            ctx.close()


def _default_prog_name():
    if not sys.argv or not sys.argv[0]:
        return "main"
    return os.path.basename(sys.argv[0])


def _display_default(value):
    if isinstance(value, (list, tuple)):
        return " ".join(str(v) for v in value)
    return value


def _warn_deprecated(kind, name, note):
    msg = f"DeprecationWarning: The {kind} '{name}' is deprecated."
    if note:
        msg += f" {note}"
    echo(msg, err=True)


class Group(Command):
    """A command that dispatches to named subcommands."""

    interspersed = False

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, **kwargs):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name, no_args_is_help=no_args_is_help, **kwargs)
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback
        self.commands = {}
        if isinstance(commands, dict):
            for cname, cmd in commands.items():
                self.add_command(cmd, cname)
        elif commands:
            for cmd in commands:
                self.add_command(cmd)

    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise ValueError("Groups cannot be nested under a chaining group.")
        self.commands[name or cmd.name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as _command

        def decorator(f):
            cmd = _command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as _group

        def decorator(f):
            cmd = _group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def make_context(self, info_name, args, parent=None, **extra):
        return super().make_context(info_name, args, parent=parent, **extra)

    def invoke(self, ctx):
        if self.deprecated:
            _warn_deprecated("command", self.name, self.deprecation_note)
        if not ctx._tokens and self.no_args_is_help:
            raise NoArgsHelp(ctx)
        parser = Parser(self, ctx, is_group=True, interspersed=ctx.allow_interspersed_args,
                        ignore_unknown=ctx.ignore_unknown_options,
                        allow_extra=ctx.allow_extra_args)
        res = parser.parse(ctx._tokens)
        ctx.args = res.leftover
        self._bind(ctx, res)

        if res.subcommand is None:
            if not self.invoke_without_command:
                raise UsageError("Missing command.", ctx=ctx)
            ctx.invoked_subcommand = None
            if self.chain:
                ctx.invoked_subcommand = CHAIN_MARKER
            rv = self._run_callback(ctx)
            if self.chain and self._result_callback is not None:
                return self._result_callback([], **ctx.params)
            return rv

        if self.chain:
            return self._invoke_chain(ctx, [res.subcommand] + res.subargs)

        cmd = self.get_command(ctx, res.subcommand)
        if cmd is None:
            raise UsageError(f"No such command '{res.subcommand}'.", ctx=ctx)
        ctx.invoked_subcommand = res.subcommand
        self._run_callback(ctx)
        sub = cmd.make_context(res.subcommand, res.subargs, parent=ctx)
        with sub:
            value = cmd.invoke(sub)
        if self._result_callback is not None:
            return self._result_callback(value, **ctx.params)
        return value

    def _invoke_chain(self, ctx, tokens):
        ctx.invoked_subcommand = CHAIN_MARKER
        self._run_callback(ctx)
        results = []
        rest = tokens
        while rest:
            name, rest = rest[0], rest[1:]
            cmd = self.get_command(ctx, name)
            if cmd is None:
                raise UsageError(f"No such command '{name}'.", ctx=ctx)
            child_tokens, rest = _split_chain_tokens(cmd, rest)
            sub = cmd.make_context(name, child_tokens, parent=ctx)
            with sub:
                results.append(cmd.invoke(sub))
        if self._result_callback is not None:
            return self._result_callback(results, **ctx.params)
        return results


def _split_chain_tokens(cmd, tokens):
    """Split leading tokens belonging to one chained subcommand (options first, then args)."""
    by_name = {n: o for o in cmd.options for n in o.all_names}
    i, n = 0, len(tokens)
    while i < n:
        tok = tokens[i]
        if tok == "--" or not (len(tok) > 1 and tok[0] in PREFIX_CHARS):
            break
        name = tok.split("=", 1)[0]
        opt = by_name.get(name)
        i += 1
        if opt is not None and opt.takes_value and "=" not in tok:
            i += opt.nargs
    for arg in cmd.arguments:
        if arg.variadic:
            i = n
            break
        i = min(n, i + arg.nargs)
    return tokens[:i], tokens[i:]


class CommandCollection(Group):
    """Presents subcommands gathered from several groups under one dispatch surface."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set(self.commands)
        for src in self.sources:
            names.update(src.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for src in self.sources:
            cmd = src.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None
