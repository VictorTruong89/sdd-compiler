"""Exception classes used by Optlyn."""


class OptlynError(Exception):
    """Base class for Optlyn-signalled errors."""

    exit_code = 1

    def __init__(self, message=""):
        super().__init__(message)
        self.message = message

    def show(self, file=None):
        import sys

        from .termui import echo

        echo(f"Error: {self.message}", err=True, file=file or sys.stderr)


class UsageError(OptlynError):
    """Incorrect usage; exit status 2."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self, file=None):
        import sys

        from .termui import echo

        echo(f"Usage error: {self.message}", err=True, file=file or sys.stderr)


class BadParameter(UsageError):
    """A value was refused. Names the offending parameter."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.param is not None:
            hint = self.param_hint or _param_identity(self.param)
            return f"Invalid value for {hint}: {self.message}"
        if self.param_hint:
            return f"Invalid value for {self.param_hint}: {self.message}"
        return f"Invalid value: {self.message}"

    def show(self, file=None):
        import sys

        from .termui import echo

        echo(f"Usage error: {self.format_message()}", err=True, file=file or sys.stderr)


class MissingParameter(BadParameter):
    """A required parameter was not supplied."""

    def format_message(self):
        hint = self.param_hint or (_param_identity(self.param) if self.param else "parameter")
        return f"Missing parameter: {hint}"


class NoSuchOption(UsageError):
    """An unknown option token."""

    def __init__(self, option_name, ctx=None):
        super().__init__(f"No such option: {option_name}", ctx)
        self.option_name = option_name


class UsageNoCommand(UsageError):
    """A group was invoked without a subcommand name."""


class Abort(OptlynError):
    """Abort: user declined, EOF on a prompt, interrupt, or author abort. Exit 1."""

    exit_code = 1

    def __init__(self, message="Aborted!"):
        super().__init__(message)

    def show(self, file=None):
        import sys

        from .termui import echo

        echo(self.message, err=True, file=file or sys.stderr)


class Exit(Exception):
    """Author clean stop."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code


class HelpRequested(Exception):
    """Internal: an eager flag asked for output and exit with status 0."""

    exit_code = 0


def _param_identity(param):
    decls = getattr(param, "opts", None) or []
    if decls:
        return " / ".join(decls)
    return getattr(param, "name", "parameter")
