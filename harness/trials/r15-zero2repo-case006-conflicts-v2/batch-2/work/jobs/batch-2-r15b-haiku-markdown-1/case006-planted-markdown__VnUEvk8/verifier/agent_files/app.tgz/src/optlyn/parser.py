"""POSIX-style token parsing for one command invocation.

The parser walks the token list once. It records command-line values per
parameter and collects positional tokens. For groups it stops at the
subcommand name, so the remaining tokens belong to the child.
"""

from .exceptions import BadParameter, Exit, MissingParameter, NoSuchOption, UsageError


class _Prompt:
    """Sentinel: the value must come from an interactive prompt."""

    def __repr__(self):
        return "PROMPT"


PROMPT = _Prompt()


class ParseResult:
    def __init__(self):
        self.raw = {}              # Parameter -> command-line value (or PROMPT)
        self.positional = []       # list of (token, after_double_dash)
        self.leftover = []         # tokens not bound to arguments
        self.subcommand = None     # subcommand name, for groups
        self.subargs = []          # tokens for the subcommand
        self.used_deprecated = []  # parameters the user actually supplied


class Parser:
    def __init__(self, command, ctx, *, is_group=False, interspersed=True,
                 ignore_unknown=False, allow_extra=False):
        self.command = command
        self.ctx = ctx
        self.is_group = is_group
        self.interspersed = interspersed
        self.ignore_unknown = ignore_unknown
        self.allow_extra = allow_extra
        self.res = ParseResult()
        self.by_name = {}
        for opt in command.options:
            for name in opt.all_names:
                self.by_name[name] = opt
        self.prefixes = {"-"} | {name[0] for name in self.by_name}
        self.help_names = list(ctx.help_option_names) if command.add_help_option else []

    def _is_option_like(self, tok):
        return len(tok) > 1 and tok[0] in self.prefixes

    # Entry point ------------------------------------------------------------

    def parse(self, tokens):
        res = self.res
        stopped = False
        i = 0
        n = len(tokens)
        while i < n:
            tok = tokens[i]
            if not stopped and tok == "--":
                stopped = True
                i += 1
                continue
            seen_positional = bool(res.positional)
            if not stopped and self._is_option_like(tok) and (
                    self.interspersed or not seen_positional):
                consumed = self._handle_option(tokens, i)
                if consumed is not None:
                    i += consumed
                    continue
            if self.is_group and self._group_args_full():
                # This token is the subcommand name; the rest belong to the child.
                self._bind_arguments()
                res.subcommand = tok
                res.subargs = list(tokens[i + 1:])
                return res
            res.positional.append((tok, stopped))
            i += 1
        self._bind_arguments()
        return res

    # Options ----------------------------------------------------------------

    def _handle_option(self, tokens, i):
        tok = tokens[i]
        if len(tok) > 2 and tok[1] == tok[0]:
            return self._handle_long(tokens, i)
        return self._handle_short(tokens, i)

    def _handle_long(self, tokens, i):
        tok = tokens[i]
        name, eq, inline = tok.partition("=")
        opt = self.by_name.get(name)
        if opt is None:
            if name in self.help_names:
                self._show_help()
            if self.ignore_unknown:
                return None
            raise NoSuchOption(name, ctx=self.ctx)
        return self._take(opt, name, tokens, i, inline if eq else None)

    def _handle_short(self, tokens, i):
        tok = tokens[i]
        prefix = tok[0]
        chars = tok[1:]
        for k, ch in enumerate(chars):
            name = prefix + ch
            opt = self.by_name.get(name)
            if opt is None:
                if name in self.help_names:
                    self._show_help()
                if self.ignore_unknown:
                    if k == 0:
                        return None
                    # Known flags before k were consumed; the unknown rest stays as a token.
                    self.res.positional.append((prefix + chars[k:], False))
                    return 1
                raise NoSuchOption(name, ctx=self.ctx)
            if opt.takes_value:
                rest = chars[k + 1:] or None
                return self._take(opt, name, tokens, i, rest)
            self._record_flag(opt, name)
        return 1

    def _take(self, opt, name, tokens, i, inline=None):
        """Consume value tokens for ``opt`` and record the occurrence.

        Returns the number of tokens consumed, starting at ``i``.
        """
        if not opt.takes_value:
            if inline is not None:
                raise UsageError(f"Option {name} does not take a value.", ctx=self.ctx)
            self._record_flag(opt, name)
            return 1
        values = []
        if inline is not None:
            values.append(inline)
        j = i + 1
        while len(values) < opt.nargs and j < len(tokens):
            values.append(tokens[j])
            j += 1
        if len(values) < opt.nargs:
            if opt.prompt is not None and not values:
                # Flag present without a value on a prompting option: prompt later.
                self.res.raw[opt] = PROMPT
                self._note_deprecated(opt)
                return j - i
            raise BadParameter(f"Option {name} requires an argument.", ctx=self.ctx,
                               param=opt)
        self._note_deprecated(opt)
        value = values[0] if opt.nargs == 1 else tuple(values)
        if opt.multiple:
            self.res.raw.setdefault(opt, []).append(value)
        else:
            self.res.raw[opt] = value
        self._maybe_eager(opt)
        return j - i

    def _record_flag(self, opt, name):
        self._note_deprecated(opt)
        if opt.count:
            self.res.raw[opt] = self.res.raw.get(opt, 0) + 1
        elif opt.multiple:
            self.res.raw.setdefault(opt, []).append(opt.flag_value_for(name))
        else:
            self.res.raw[opt] = opt.flag_value_for(name)
        self._maybe_eager(opt)

    def _maybe_eager(self, opt):
        """Eager parameters act at the point they are typed; they may exit."""
        if opt.is_eager and opt.callback is not None:
            opt.callback(self.ctx, opt, self.res.raw.get(opt))

    def _note_deprecated(self, param):
        if param.deprecated and param not in self.res.used_deprecated:
            self.res.used_deprecated.append(param)

    def _show_help(self):
        from .help import echo_help

        echo_help(self.ctx)
        raise Exit(0)

    # Arguments --------------------------------------------------------------

    def _group_args_full(self):
        """True when all of a group's fixed arguments already have their tokens."""
        needed = sum(a.nargs for a in self.command.arguments if not a.variadic)
        return len(self.res.positional) >= needed

    def _bind_arguments(self):
        res = self.res
        toks = res.positional
        idx = 0
        args = self.command.arguments
        for k, arg in enumerate(args):
            if arg.variadic:
                reserve = sum(a.nargs for a in args[k + 1:] if not a.variadic)
                take = max(0, len(toks) - idx - reserve)
                if take:
                    res.raw[arg] = tuple(t for t, _ in toks[idx: idx + take])
                    idx += take
                    self._note_deprecated(arg)
                elif arg.required:
                    raise MissingParameter(f"Missing argument '{arg.name}'.",
                                           ctx=self.ctx, param=arg,
                                           param_hint=arg.name.upper())
                continue
            remaining = len(toks) - idx
            if remaining == 0:
                if arg.required:
                    raise MissingParameter(f"Missing argument '{arg.name}'.",
                                           ctx=self.ctx, param=arg,
                                           param_hint=arg.name.upper())
                continue
            if remaining < arg.nargs:
                raise BadParameter(f"Argument '{arg.name}' requires {arg.nargs} values.",
                                   ctx=self.ctx, param=arg)
            chunk = [t for t, _ in toks[idx: idx + arg.nargs]]
            idx += arg.nargs
            res.raw[arg] = chunk[0] if arg.nargs == 1 else tuple(chunk)
            self._note_deprecated(arg)
        for tok, after_dd in toks[idx:]:
            if not self.allow_extra:
                raise UsageError(f"Got unexpected extra argument ({tok})", ctx=self.ctx)
            if not after_dd and self._is_option_like(tok):
                raise UsageError(f"No such option: {tok}", ctx=self.ctx)
            res.leftover.append(tok)
