"""Help page generation."""

import shutil

from .core import Group
from .formatting import wrap_text
from .termui import echo

_DEFAULT_MAX_WIDTH = 80
_COL = 26


def _command_path(ctx):
    names = []
    node = ctx
    while node is not None:
        if node.info_name:
            names.append(node.info_name)
        node = node.parent
    return " ".join(reversed(names))


def _width(ctx):
    if ctx.terminal_width:
        return ctx.terminal_width
    detected = shutil.get_terminal_size((80, 24)).columns
    cap = ctx.max_content_width or _DEFAULT_MAX_WIDTH
    return min(detected, cap) - 2


def _arg_usage(arg):
    name = arg.get_metavar()
    if arg.variadic:
        name = f"{name}..."
    elif arg.nargs != 1:
        name = " ".join([name] * arg.nargs)
    return name if arg.required else f"[{name}]"


def _usage_line(ctx):
    cmd = ctx.command
    parts = [_command_path(ctx)]
    if cmd.options:
        parts.append(cmd.options_metavar)
    for arg in cmd.arguments:
        parts.append(_arg_usage(arg))
    if isinstance(cmd, Group) and cmd.commands is not None and (
            cmd.list_commands(ctx) or getattr(cmd, "sources", None)):
        if cmd.chain:
            parts.append("COMMAND [ARGS]... [COMMAND [ARGS]...]...")
        elif cmd.invoke_without_command:
            parts.append("[COMMAND] [ARGS]...")
        else:
            parts.append("COMMAND [ARGS]...")
    return "Usage: " + " ".join(p for p in parts if p)


def _option_entry(ctx, opt):
    decls = ", ".join(opt.all_names)
    metavar = opt.get_metavar()
    head = f"{decls} {metavar}" if metavar else decls
    extras = []
    show_default = opt.show_default if opt.show_default is not None else ctx.show_default
    if show_default and opt.default is not None and not (opt.is_flag and opt.default is False):
        if isinstance(opt.show_default, str):
            extras.append(f"[default: {opt.show_default}]")
        else:
            value = opt.default
            if callable(value):
                value = "(dynamic)"
            extras.append(f"[default: {value}]")
    if opt.show_envvar and opt.envvar:
        extras.append(f"[env var: {', '.join(opt.envvar)}]")
    if opt.deprecated:
        extras.append("[deprecated]")
    text = " ".join(filter(None, [opt.help or "", *extras]))
    return head, text


def _section(title, rows, width):
    if not rows:
        return []
    lines = [title + ":"]
    col = min(max(len(h) for h, _ in rows) + 2, _COL)
    for head, text in rows:
        wrapped = wrap_text(text, width=max(10, width - col - 2)).splitlines() if text else []
        if not wrapped:
            lines.append("  " + head)
            continue
        if len(head) + 2 <= col:
            lines.append("  " + head.ljust(col) + wrapped[0])
            rest = wrapped[1:]
        else:
            lines.append("  " + head)
            rest = wrapped
        lines.extend(" " * (col + 2) + w for w in rest)
    lines.append("")
    return lines


def format_help(ctx):
    """Return the help page text for ``ctx``'s command."""
    cmd = ctx.command
    width = _width(ctx)
    lines = [_usage_line(ctx), ""]
    if cmd.deprecated:
        note = cmd.deprecation_note or "This command is deprecated."
        lines.append(f"DEPRECATED: {note}")
        lines.append("")
    description = cmd.help or ""
    if description:
        lines.append(wrap_text(description, width=width, initial_indent="  ",
                               subsequent_indent="  ").rstrip())
        lines.append("")

    arg_rows = [(arg.get_metavar(), arg.help or "") for arg in cmd.arguments
                if arg.help]
    lines.extend(_section("Positional arguments", arg_rows, width))

    opt_rows = [_option_entry(ctx, o) for o in cmd.options if not o.hidden]
    if cmd.add_help_option:
        opt_rows.append((", ".join(ctx.help_option_names), "Show this message and exit."))
    lines.extend(_section("Options", opt_rows, width))

    if isinstance(cmd, Group):
        rows = []
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is None or sub.hidden:
                continue
            rows.append((name, sub.get_short_help_str(limit=max(20, width - _COL - 4))))
        lines.extend(_section("Commands", rows, width))

    if cmd.epilog:
        lines.append(wrap_text(cmd.epilog, width=width))
        lines.append("")
    return "\n".join(lines).rstrip("\n") + "\n"


def echo_help(ctx):
    """Write the help page of ``ctx`` to standard output."""
    echo(format_help(ctx), nl=False)
