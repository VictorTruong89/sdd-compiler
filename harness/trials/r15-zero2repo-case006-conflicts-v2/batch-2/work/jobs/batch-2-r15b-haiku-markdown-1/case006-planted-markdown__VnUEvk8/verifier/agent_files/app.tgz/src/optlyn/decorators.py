"""Declaration decorators: command, group, option, argument, and callback helpers."""

from .core import Command, Group, get_current_context
from .parameters import Argument, Option

_NAME_SUFFIXES = ("_command", "_cmd", "_group", "_grp")


def _derive_name(func_name):
    name = func_name.lower().replace("_", "-")
    for suffix in _NAME_SUFFIXES:
        suffix = suffix.replace("_", "-")
        if name.endswith(suffix) and len(name) > len(suffix):
            return name[: -len(suffix)]
    return name


def _attach_param(f, param):
    if isinstance(f, Command):
        f.params.insert(0, param)
        return
    f.__dict__.setdefault("__optlyn_params__", []).append(param)


def _pop_params(f):
    params = f.__dict__.pop("__optlyn_params__", [])
    params.reverse()
    return params


def _docstring(f):
    doc = f.__doc__
    if doc and "\f" in doc:
        doc = doc.split("\f", 1)[0]
    return doc


def _make(f, name, cls, default_cls, attrs):
    if cls is None:
        cls = default_cls
    attrs = dict(attrs)
    if attrs.get("help") is None:
        attrs["help"] = _docstring(f)
    params = _pop_params(f)
    if name is None:
        name = _derive_name(f.__name__)
    return cls(name=name, callback=f, params=params, **attrs)


def command(name=None, cls=None, **attrs):
    """Turn a function into a ``Command``. Usable as ``@command()`` or ``@command``."""
    if callable(name) and not isinstance(name, str):
        return command()(name)

    def decorator(f):
        return _make(f, name, cls, Command, attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a ``Group`` (or ``cls``). Usable as ``@group()`` or ``@group``."""
    if callable(name) and not isinstance(name, str):
        return group()(name)

    def decorator(f):
        return _make(f, name, cls, Group, attrs)

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to the function (or command) below it."""
    option_cls = cls or Option

    def decorator(f):
        _attach_param(f, option_cls(param_decls, **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to the function (or command) below it."""
    argument_cls = cls or Argument

    def decorator(f):
        _attach_param(f, argument_cls(param_decls, **attrs))
        return f

    return decorator


def pass_context(f):
    """Pass the current ``Context`` as the first argument."""

    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    new_func.__name__ = f.__name__
    new_func.__doc__ = f.__doc__
    return new_func


def pass_obj(f):
    """Pass the current context's ``obj`` as the first argument."""

    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    new_func.__name__ = f.__name__
    new_func.__doc__ = f.__doc__
    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Build a decorator passing the nearest object of ``object_type`` from the context."""

    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            return f(obj, *args, **kwargs)

        new_func.__name__ = f.__name__
        new_func.__doc__ = f.__doc__
        return new_func

    return decorator
