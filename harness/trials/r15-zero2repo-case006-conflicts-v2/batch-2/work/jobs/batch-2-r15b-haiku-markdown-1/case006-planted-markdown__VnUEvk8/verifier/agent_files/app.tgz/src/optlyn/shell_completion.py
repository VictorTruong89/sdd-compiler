"""Shell completion: registration scripts and suggestion output."""

import os
import sys

from .types import Choice, File, ParamType, Path

SHELLS = ("bash", "zsh", "fish", "powershell")
_PATH_DIR = "\x00dir"
_PATH_ANY = "\x00path"


def _default_var(prog_name):
    name = os.path.basename(prog_name).replace("-", "_").replace(".", "_")
    return f"_{name.upper()}_COMPLETE"


def maybe_complete(cmd, prog_name, complete_var, args):
    """Handle completion mode. Returns True when the run was a completion run."""
    var = complete_var or _default_var(prog_name)
    value = os.environ.get(var)
    if not value:
        return False
    shell, _, instruction = value.partition("_")
    if shell not in SHELLS or instruction not in ("source", "complete"):
        print(f"Unknown completion instruction: {value!r}", file=sys.stderr)
        raise SystemExit(1)
    prog = os.path.basename(prog_name)
    if instruction == "source":
        sys.stdout.write(_source_script(shell, prog, var) + "\n")
        sys.stdout.flush()
        return True
    words_raw = os.environ.get("COMP_WORDS", prog)
    words = words_raw.split(" ")
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        preceding = words[1:-1] if words and words[-1] == incomplete and len(words) > 1 else words[1:]
    else:
        try:
            cword = int(os.environ.get("COMP_CWORD", str(len(words) - 1)))
        except ValueError:
            cword = len(words) - 1
        incomplete = words[cword] if 0 <= cword < len(words) else ""
        preceding = words[1:cword] if cword > 0 else []
    for item in complete(cmd, prog, preceding, incomplete):
        sys.stdout.write(item + "\n")
    sys.stdout.flush()
    return True


def _resolve_command(cmd, preceding):
    """Walk groups by the given tokens. Returns (command, last option awaiting a value)."""
    node = cmd
    pending = None
    i = 0
    while i < len(preceding):
        tok = preceding[i]
        i += 1
        if tok.startswith("-"):
            opt = next((o for o in node.options if tok in o.all_names), None)
            if opt is not None and opt.takes_value and "=" not in tok:
                if i < len(preceding):
                    i += opt.nargs
                else:
                    pending = opt
            continue
        if hasattr(node, "get_command") and getattr(node, "commands", None) is not None:
            child = node.get_command(None, tok)
            if child is not None:
                node = child
                continue
    return node, pending


def complete(cmd, prog, preceding, incomplete):
    """Return suggestion lines for the incomplete token."""
    node, pending = _resolve_command(cmd, preceding)
    if pending is not None:
        return _value_suggestions(pending, incomplete, None)
    lines = []
    if incomplete.startswith("-"):
        names = set()
        for opt in node.options:
            if not opt.hidden:
                names.update(opt.all_names)
        if node.add_help_option:
            names.add("--help")
        lines = sorted(n for n in names if n.startswith(incomplete))
        return lines
    if hasattr(node, "commands") and getattr(node, "commands", None) is not None:
        for name in node.list_commands(None):
            child = node.get_command(None, name)
            if child is not None and not child.hidden and name.startswith(incomplete):
                lines.append(name)
    return lines


def _value_suggestions(param, incomplete, ctx=None):
    custom = param.shell_complete or getattr(param.type, "shell_complete", None)
    if param.shell_complete is None and custom is not None and type(param.type).shell_complete is not ParamType.shell_complete:
        items = param.type.shell_complete(ctx, param, incomplete)
    elif param.shell_complete is not None:
        items = param.shell_complete(ctx, param, incomplete)
    elif isinstance(param.type, Choice):
        return [t for t in param.type._tokens if t.startswith(incomplete)]
    elif isinstance(param.type, (File, Path)):
        return [_PATH_ANY + "\t" + incomplete]
    else:
        return []
    lines = []
    for item in items:
        if isinstance(item, str):
            lines.append(item)
        else:
            help_text = getattr(item, "help", None)
            lines.append(item.value + ("\t" + help_text if help_text else ""))
    return lines


def _source_script(shell, prog, var):
    if shell == "bash":
        return (
            f"_{prog.replace('-', '_')}_completion() {{\n"
            f"    local IFS=$'\\n'\n"
            f"    COMPREPLY=( $(env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
            f"{var}=bash_complete {prog}) )\n"
            f"    return 0\n}}\n"
            f"complete -o default -F _{prog.replace('-', '_')}_completion {prog}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog}\n"
            f"_{prog.replace('-', '_')}_completion() {{\n"
            f"    local -a suggestions\n"
            f"    suggestions=(${{(f)\"$(env COMP_WORDS=\"${{words[*]}}\" "
            f"COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog})\"}})\n"
            f"    _describe 'values' suggestions\n}}\n"
            f"compdef _{prog.replace('-', '_')}_completion {prog}\n"
        )
    if shell == "fish":
        return (
            f"complete --command {prog} --no-files --arguments "
            f"\"(env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) "
            f"{var}=fish_complete {prog})\"\n"
        )
    return (
        f"Register-ArgumentCompleter -Native -CommandName {prog} -ScriptBlock {{\n"
        f"    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString()\n"
        f"    $env:COMP_CWORD = $commandAst.CommandElements.Count\n"
        f"    $env:{var} = 'powershell_complete'\n"
        f"    & {prog} | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_) }}\n"
        f"}}\n"
    )
