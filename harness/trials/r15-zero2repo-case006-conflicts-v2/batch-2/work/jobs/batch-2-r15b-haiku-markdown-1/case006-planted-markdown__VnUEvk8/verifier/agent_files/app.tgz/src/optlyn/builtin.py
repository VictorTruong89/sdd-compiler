"""Ready-made option decorators: help, version, password, and confirmation."""

from importlib import metadata

from .exceptions import Exit
from .termui import confirm, echo


def _flag_option(decls, default_decls, kwargs):
    decls = list(decls) or list(default_decls)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    return decls, kwargs


def help_option(*param_decls, **kwargs):
    """An extra eager flag (default ``--help``) that prints help and exits 0."""
    decls, kwargs = _flag_option(param_decls, ["--help"], kwargs)
    kwargs.setdefault("help", "Show this message and exit.")

    def callback(ctx, param, value):
        if not value:
            return
        from .help import echo_help

        echo_help(ctx)
        raise Exit(0)

    kwargs["callback"] = callback
    return _option_decorator(decls, kwargs)


def _option_decorator(decls, kwargs):
    from .decorators import option

    return option(*decls, **kwargs)


def _detect_version(package_name):
    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    dists = metadata.packages_distributions().get(package_name, [])
    if dists:
        return metadata.version(dists[0])
    raise RuntimeError(f"Could not detect the version of {package_name!r}.")


def version_option(version=None, *param_decls, package_name=None, prog_name=None,
                   message=None, **kwargs):
    """An eager ``--version`` flag printing the identity and exiting 0."""
    decls, kwargs = _flag_option(param_decls, ["--version"], kwargs)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value:
            return
        ver = version
        if ver is None:
            if package_name is None:
                raise RuntimeError("version_option needs a version or a package_name.")
            ver = _detect_version(package_name)
        prog = prog_name or ctx.find_root().info_name or ""
        template = message or "%(prog)s, version %(version)s"
        echo(template % {"prog": prog, "version": ver, "package": package_name})
        raise Exit(0)

    kwargs["callback"] = callback
    return _option_decorator(decls, kwargs)


def custom_version_option(callback_fn, *param_decls, **kwargs):
    """An eager ``--version`` flag whose identity is exactly ``callback_fn(ctx)``."""
    decls, kwargs = _flag_option(param_decls, ["--version"], kwargs)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value:
            return
        echo(callback_fn(ctx))
        raise Exit(0)

    kwargs["callback"] = callback
    return _option_decorator(decls, kwargs)


def password_option(*param_decls, **kwargs):
    """A prompting, hidden, confirmed option (default ``--password``)."""
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return _option_decorator(decls, kwargs)


def confirmation_option(*param_decls, **kwargs):
    """A yes flag (default ``--yes``); when omitted, asks, and aborts on decline."""
    decls = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def callback(ctx, param, value):
        if not value:
            confirm(question, abort=True)
        return value

    kwargs["callback"] = callback
    return _option_decorator(decls, kwargs)
