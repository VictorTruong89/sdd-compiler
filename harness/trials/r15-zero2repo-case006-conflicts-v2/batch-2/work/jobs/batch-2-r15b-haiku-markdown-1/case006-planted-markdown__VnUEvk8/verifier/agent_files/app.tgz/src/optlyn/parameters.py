"""Option and Argument declarations."""

import os

from .exceptions import BadParameter
from .types import BOOL, INT, File, Path, Tuple, convert_type

PREFIX_CHARS = ("-", "/", "+")

_TRUE_ENV = {"true", "1", "yes", "on", "t", "y"}
_FALSE_ENV = {"false", "0", "no", "off", "f", "n", ""}


def _split_decls(param_decls):
    """Separate a declaration list into (flag names, secondary flag names, destination)."""
    opts, secondary, dest = [], [], None
    for decl in param_decls:
        if decl and decl[0] in PREFIX_CHARS:
            if "/" in decl[1:]:
                on, off = decl.split("/", 1)
                opts.append(on)
                secondary.append(off)
            else:
                opts.append(decl)
        elif decl.isidentifier():
            if dest is not None:
                raise ValueError(f"Parameter declared with two destinations: {dest!r}, {decl!r}")
            dest = decl
        else:
            raise ValueError(f"Invalid parameter declaration: {decl!r}")
    return opts, secondary, dest


def _strip_prefix(name):
    return name.lstrip("".join(PREFIX_CHARS))


def _infer_dest(opts):
    """Destination from flag names: identifier-valid name, then first long, then first short."""
    stripped = [(_strip_prefix(o), o) for o in opts]
    for name, _ in stripped:
        if name.isidentifier():
            return name
    for name, decl in stripped:
        if decl[:2] in ("--", "//", "++"):
            return name.replace("-", "_")
    for name, _ in stripped:
        if name:
            return name.replace("-", "_")
    raise ValueError("Could not infer a destination name.")


class Parameter:
    """Base class for options and arguments."""

    param_kind = "parameter"

    def __init__(self, name, type=None, default=None, required=False, callback=None,
                 nargs=1, multiple=False, metavar=None, expose_value=True, is_eager=False,
                 envvar=None, shell_complete=None, deprecated=False, hidden=False,
                 help=None, show_default=None, show_envvar=False, allow_from_autoenv=True,
                 prompt=None, prompt_required=True, hide_input=False,
                 confirmation_prompt=False, is_flag=False, count=False, flag_value=None,
                 opts=None, secondary_opts=None):
        self.name = name
        self.opts = list(opts or [])
        self.secondary_opts = list(secondary_opts or [])
        self.default = default
        self.required = required
        self.callback = callback
        self.nargs = nargs
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.envvar = _normalize_envvar(envvar)
        self.shell_complete = shell_complete
        self.deprecated = deprecated
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None
        self.hidden = hidden
        self.help = help
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.allow_from_autoenv = allow_from_autoenv
        self.prompt = prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.is_flag = is_flag
        self.count = count
        self.flag_value = flag_value
        self.type = self._make_type(type)
        if isinstance(self.type, Tuple):
            self.nargs = len(self.type.types)

    def _make_type(self, ty):
        if self.count:
            return INT
        if self.is_flag and ty is None:
            return BOOL
        if ty is None and self.default is not None and not callable(self.default):
            return convert_type(None, self.default)
        return convert_type(ty)

    # Presentation -----------------------------------------------------------

    @property
    def human_readable_name(self):
        if self.opts:
            return " / ".join(self.opts)
        return self.name

    def get_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return None

    @property
    def takes_value(self):
        return not (self.is_flag or self.count)

    # Defaults and env ------------------------------------------------------

    def get_default(self):
        """The declared default, with callables invoked."""
        value = self.default
        if callable(value):
            value = value()
        if self.multiple and value is not None and isinstance(value, str):
            raise BadParameter("needs an iterable (sequence) default for a repeatable option.",
                               param=self)
        if self.multiple and value is not None:
            value = tuple(value)
        return value

    def envvar_names(self, ctx):
        names = list(self.envvar or [])
        if self.allow_from_autoenv and ctx is not None and self.param_kind == "option":
            prefix = ctx.auto_envvar_prefix_for(self)
            if prefix:
                names.append(prefix)
        return names

    def value_from_env(self, ctx):
        """Return (found, raw text) from the environment, or (False, None)."""
        for name in self.envvar_names(ctx):
            raw = os.environ.get(name)
            if raw is not None and raw != "":
                return True, raw
        return False, None

    def split_env(self, raw):
        """Split a non-empty env string into tokens for multi-value parameters."""
        if self.multiple or self.nargs != 1:
            if isinstance(self.type, (File, Path)):
                return [t for t in raw.split(os.pathsep) if t != ""]
            return raw.split()
        return [raw]

    # Conversion -------------------------------------------------------------

    def convert_one(self, value, ctx):
        if self.is_flag:
            return value
        return self.type.convert(value, self, ctx)

    def convert_value(self, raw, ctx):
        """Convert a delivered value: scalar, fixed-arity tuple, or repeated occurrences."""
        if self.nargs == 1 and not self.multiple:
            return self.convert_one(raw, ctx)
        if self.multiple:
            # raw is a list of per-occurrence entries
            return tuple(self._convert_occurrence(item, ctx) for item in raw)
        return self._convert_occurrence(raw, ctx)

    def _convert_occurrence(self, item, ctx):
        if self.nargs == 1:
            return self.convert_one(item, ctx)
        if isinstance(self.type, Tuple):
            return self.type.convert(item, self, ctx)
        return tuple(self.convert_one(v, ctx) for v in item)

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


def _normalize_envvar(envvar):
    if envvar is None:
        return None
    if isinstance(envvar, str):
        return [envvar]
    return list(envvar)


class Option(Parameter):
    """A named parameter introduced by a prefix character."""

    param_kind = "option"

    def __init__(self, param_decls=None, cls=None, **attrs):
        param_decls = list(param_decls or [])
        opts, secondary, dest = _split_decls(param_decls)
        if not opts:
            raise ValueError("An option needs at least one flag name.")
        is_flag = attrs.pop("is_flag", None)
        count = bool(attrs.pop("count", False))
        flag_value = attrs.pop("flag_value", None)
        default = attrs.get("default")
        if is_flag is None:
            is_flag = bool(secondary) or isinstance(default, bool)
        if count and is_flag:
            raise ValueError("A counting option cannot also be a flag.")
        if attrs.get("multiple") and is_flag:
            raise ValueError("A flag cannot be repeatable.")
        if is_flag and flag_value is None:
            if secondary:
                flag_value = True
            elif isinstance(default, bool):
                flag_value = not default
            else:
                flag_value = True
        if count:
            is_flag = False
            if default is None:
                attrs["default"] = 0
        if attrs.get("deprecated") and attrs.get("required"):
            raise ValueError("A deprecated option cannot also be required.")
        if attrs.get("deprecated") and attrs.get("prompt"):
            raise ValueError("A deprecated option cannot use a prompt.")
        if dest is None:
            dest = _infer_dest(opts)
        if is_flag:
            attrs.setdefault("nargs", 1)
        if "prompt_required" not in attrs:
            attrs["prompt_required"] = True
        if attrs.get("nargs", 1) < 1 and attrs.get("nargs") != -1:
            raise ValueError("nargs must be positive.")
        if attrs.get("nargs", 1) == -1:
            raise ValueError("An option cannot be variadic.")
        self.is_secondary_pair = bool(secondary)
        super().__init__(dest, opts=opts, secondary_opts=secondary, is_flag=is_flag,
                         count=count, flag_value=flag_value, **attrs)

    def match(self, token_name):
        return token_name in self.opts or token_name in self.secondary_opts

    def is_secondary(self, token_name):
        return token_name in self.secondary_opts

    def flag_value_for(self, token_name):
        if self.is_secondary(token_name):
            return False
        return self.flag_value

    @property
    def all_names(self):
        return self.opts + self.secondary_opts

    def get_metavar(self):
        if self.metavar is not None:
            return self.metavar
        if self.is_flag or self.count:
            return None
        return self.type.get_metavar(self) or self.type.name.upper()

    def get_missing_value_message(self):
        return f"Option {self.human_readable_name} requires an argument."

    def get_envvar_flag_value(self, raw):
        """Interpret an env string for a flag. Returns (found, value)."""
        text = raw.strip().lower()
        if self.flag_value is not None and not isinstance(self.flag_value, bool):
            if text == str(self.flag_value).lower():
                return True, self.flag_value
        if text in _TRUE_ENV:
            return True, True
        if text in _FALSE_ENV:
            return True, False
        return False, None


class Argument(Parameter):
    """A positional parameter."""

    param_kind = "argument"

    def __init__(self, param_decls=None, cls=None, **attrs):
        param_decls = list(param_decls or [])
        if len(param_decls) != 1 or not param_decls[0].isidentifier():
            raise ValueError("An argument takes exactly one destination name.")
        name = param_decls[0]
        nargs = attrs.pop("nargs", 1)
        if nargs != -1 and nargs < 1:
            raise ValueError("nargs must be positive or -1.")
        default = attrs.get("default")
        required = attrs.pop("required", None)
        variadic = nargs == -1
        if required is None:
            required = default is None and not variadic
            if variadic:
                required = False
        if attrs.get("deprecated") and required:
            raise ValueError("A deprecated argument cannot be required.")
        self.variadic = variadic
        super().__init__(name, required=required, nargs=nargs, **attrs)

    def get_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()

    def get_default(self):
        value = self.default
        if callable(value):
            value = value()
        return value

    def split_env(self, raw):
        if self.nargs == 1 and not self.variadic:
            return [raw]
        if isinstance(self.type, (File, Path)):
            return [t for t in raw.split(os.pathsep) if t != ""]
        return raw.split()

    def convert_value(self, raw, ctx):
        if self.variadic:
            return tuple(self.convert_one(v, ctx) for v in raw)
        if self.nargs == 1:
            return self.convert_one(raw, ctx)
        if isinstance(self.type, Tuple):
            return self.type.convert(raw, self, ctx)
        return tuple(self.convert_one(v, ctx) for v in raw)

    @property
    def arity(self):
        return None if self.variadic else self.nargs
