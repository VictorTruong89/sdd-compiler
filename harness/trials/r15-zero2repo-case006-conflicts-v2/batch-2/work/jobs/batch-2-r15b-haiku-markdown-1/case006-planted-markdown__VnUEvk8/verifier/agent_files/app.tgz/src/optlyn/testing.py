"""In-process runner for invoking commands in tests."""

import io
import os
import shutil
import sys
import tempfile
from contextlib import contextmanager


class Result:
    def __init__(self, runner_output, stdout_bytes, stderr_bytes, exit_code, exception, charset):
        self._combined = runner_output
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.exit_code = exit_code
        self.exception = exception
        self._charset = charset

    @property
    def output(self):
        return self._combined.decode(self._charset, "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self._charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self._charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class _Snapshot:
    combined = b""
    stdout = b""
    stderr = b""


class _CaptureBytes(io.BytesIO):
    """A BytesIO that also appends everything it receives to a shared combined buffer."""

    def __init__(self, combined):
        super().__init__()
        self._combined = combined

    def write(self, data):
        self._combined.write(data)
        return super().write(data)


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextmanager
    def isolation(self, input=None, env=None):
        combined = io.BytesIO()
        out_b = _CaptureBytes(combined)
        err_b = _CaptureBytes(combined)
        if isinstance(input, str):
            input = input.encode(self.charset)
        in_b = io.BytesIO(input or b"")
        stdin = io.TextIOWrapper(in_b, encoding=self.charset)
        stdout = io.TextIOWrapper(out_b, encoding=self.charset, errors="replace",
                                  write_through=True)
        stderr = io.TextIOWrapper(err_b, encoding=self.charset, errors="replace",
                                  write_through=True)
        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {}
        for key, value in merged_env.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        old = sys.stdin, sys.stdout, sys.stderr
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        snap = _Snapshot()
        try:
            yield snap
        finally:
            sys.stdin, sys.stdout, sys.stderr = old
            stdout.flush()
            stderr.flush()
            snap.combined = combined.getvalue()
            snap.stdout = out_b.getvalue()
            snap.stderr = err_b.getvalue()
            # Detach so closing the wrappers does not close the capture buffers.
            for stream in (stdin, stdout, stderr):
                stream.detach()
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None,
               color=False, **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            import shlex

            args = shlex.split(args)
        extra.setdefault("prog_name", "cli")
        exit_code = 0
        exception = None
        with self.isolation(input=input, env=env) as snap:
            try:
                cli.main(args=list(args), standalone_mode=extra.pop("standalone_mode", True),
                         color=color, **extra)
            except SystemExit as e:
                code = e.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    sys.stderr.write(str(code) + "\n")
                    exit_code = 1
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
        return Result(snap.combined, snap.stdout, snap.stderr, exit_code, exception,
                      self.charset)

    @contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(dt, ignore_errors=True)
