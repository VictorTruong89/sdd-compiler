"""Terminal helpers: echo, styling, prompts, pager, progress, and friends."""

import os
import re
import shlex
import subprocess
import sys
import tempfile
import time
from contextlib import contextmanager
from pathlib import Path as _Path

from ._state import peek_context
from .exceptions import Abort

_ANSI_RE = re.compile(r"\033\[[0-9;?]*[A-Za-z]")

_COLORS = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}

_STYLE_CODES = {
    "bold": 1, "dim": 2, "italic": 3, "underline": 4,
    "blink": 5, "reverse": 7, "strikethrough": 9, "overline": 53,
}

def _is_tty(stream):
    try:
        return bool(stream and stream.isatty())
    except Exception:
        return False


def _resolve_color(color, stream):
    """Decide whether styles are kept for a write to ``stream``."""
    if color is None:
        ctx = peek_context()
        if ctx is not None and ctx.color is not None:
            color = ctx.color
    if color is None:
        return _is_tty(stream)
    return bool(color)


def unstyle(text):
    """Remove ANSI escape sequences from ``text``."""
    return _ANSI_RE.sub("", text)


def _color_code(color, background=False):
    base = 40 if background else 30
    if isinstance(color, str):
        if color == "reset":
            return "49" if background else "39"
        if color not in _COLORS:
            raise ValueError(f"Unknown color '{color}'.")
        code = _COLORS[color]
        if background:
            code += 10
        return str(code)
    if isinstance(color, bool):
        raise TypeError("Color must be a name, an int, or an RGB sequence.")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ValueError("Color index must be in 0-255.")
        return f"{base + 8}8;5;{color}"
    if isinstance(color, (list, tuple)) and len(color) == 3:
        for c in color:
            if not isinstance(c, int) or not 0 <= c <= 255:
                raise ValueError("RGB components must be integers in 0-255.")
        return f"{base + 8}8;2;{color[0]};{color[1]};{color[2]}"
    raise ValueError(f"Invalid color: {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    """Wrap ``text`` in ANSI SGR sequences."""
    codes = []
    if fg is not None:
        codes.append(_color_code(fg))
    if bg is not None:
        codes.append(_color_code(bg, background=True))
    switches = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline,
        "italic": italic, "blink": blink, "reverse": reverse, "strikethrough": strikethrough,
    }
    for name, on in switches.items():
        if on is not None:
            codes.append(str(_STYLE_CODES[name]) if on else str(_STYLE_CODES[name] + 20))
            if name == "overline" and not on:
                codes[-1] = "55"
    if not codes:
        return text
    prefix = f"\033[{';'.join(codes)}m"
    return prefix + text + ("\033[0m" if reset else "")


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    """Echo ``message`` with ``style`` applied."""
    if message is not None:
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes, stripping styles unless the stream is a terminal or color is forced."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, (bytes, bytearray)):
        out = bytes(message)
        if nl:
            out += b"\n"
        target = getattr(file, "buffer", file)
        target.write(out)
        target.flush()
        return
    if not _resolve_color(color, file):
        message = unstyle(message)
    if nl:
        message += "\n"
    try:
        file.write(message)
    except UnicodeEncodeError:
        enc = getattr(file, "encoding", None) or "ascii"
        data = message.encode("utf-8")
        target = getattr(file, "buffer", None)
        if target is not None:
            file.flush()
            target.write(data)
        else:
            file.write(message.encode(enc, "replace").decode(enc))
    file.flush()


def _read_line(prompt_text, hide_input=False):
    if hide_input:
        import getpass

        try:
            return getpass.getpass(prompt_text)
        except (EOFError, KeyboardInterrupt):
            raise Abort()
    sys.stdout.write(prompt_text)
    sys.stdout.flush()
    line = sys.stdin.readline()
    if line == "":
        raise Abort()
    line = line.rstrip("\n").rstrip("\r")
    if not _is_tty(sys.stdin):
        # Echo the typed line into captured output, as a terminal would.
        sys.stdout.write(line + "\n")
        sys.stdout.flush()
    return line


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False):
    """Ask for a value until conversion succeeds. Returns the converted value."""
    from .types import convert_type

    if type is None:
        if default is not None and not callable(default):
            type = convert_type(None, default)
        else:
            type = convert_type(None)
    if callable(default):
        default_value = default()
    else:
        default_value = default
    suffix = ""
    if show_default and default_value is not None and default_value != "":
        suffix = f" [{default_value}]"
    while True:
        line = _read_line(f"{text}{suffix}{prompt_suffix}", hide_input=hide_input)
        if line == "" and default_value is not None:
            value_text = default_value
            if isinstance(value_text, str):
                pass
            else:
                return default_value
        else:
            value_text = line
        if confirmation_prompt:
            again = _read_line("Repeat for confirmation" + prompt_suffix, hide_input=hide_input)
            if again != line:
                echo("Error: the two entered values do not match", err=True)
                continue
        try:
            return type.convert(value_text, None, None)
        except Exception as e:  # ParamType refusal
            echo(f"Error: {getattr(e, 'message', e)}", err=True)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True,
            err=False):
    """Ask a yes/no question. Returns a bool; aborts on a negative answer when requested."""
    hint = " [Y/n]" if default else " [y/N]" if default is False else " [y/n]"
    while True:
        answer = _read_line(f"{text}{hint}{prompt_suffix}").strip().lower()
        if answer == "":
            result = bool(default)
            break
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
    if abort and not result:
        raise Abort()
    return result


def getchar(echo=False):
    """Read one character from the terminal, even if stdin is a pipe."""
    if os.name == "nt":
        import msvcrt

        ch = msvcrt.getwch()
        if ch == "\x03":
            raise KeyboardInterrupt()
        if ch == "\x1a":
            raise EOFError()
        return ch
    import termios
    import tty

    try:
        fd = os.open(os.ctermid(), os.O_RDONLY)
    except OSError:
        fd = sys.stdin.fileno()
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 1).decode("utf-8", "replace")
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    finally:
        if fd != sys.stdin.fileno():
            os.close(fd)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04" or ch == "":
        raise EOFError()
    if echo:
        echo_text = ch
        sys.stdout.write(echo_text)
        sys.stdout.flush()
    return ch


def pause(info=None, err=False):
    """Print a message and wait for a key when interactive; otherwise do nothing."""
    if not (_is_tty(sys.stdin) and _is_tty(sys.stdout)):
        return
    if info is None:
        info = "Press any key to continue..."
    echo(info, err=err, nl=False)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo(file=sys.stderr if err else sys.stdout)


def clear():
    """Clear the terminal screen; does nothing when not connected to a terminal."""
    if not _is_tty(sys.stdout):
        return
    if os.name == "nt":
        os.system("cls")
    else:
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()


class ProgressBar:
    """Iterable progress bar. Visits every item whether or not it renders."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden or not _is_tty(sys.stdout)
        self.pos = 0
        self.start = time.time()
        self.options = options
        if self.hidden and self.label and not hidden:
            sys.stdout.write(self.label + "\n")
            sys.stdout.flush()

    def __iter__(self):
        if self.iterable is None:
            raise TypeError("Bar has no iterable.")
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps):
        self.pos += n_steps
        if self.hidden:
            return
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            filled = int(frac * 30)
            elapsed = time.time() - self.start
            remaining = (elapsed / frac - elapsed) if frac > 0 else 0
            line = f"\r{self.label} [{'#' * filled}{'-' * (30 - filled)}] {self.pos}/{self.length} eta {int(remaining)}s"
        else:
            line = f"\r{self.label} {self.pos}"
        sys.stdout.write(line)
        sys.stdout.flush()


@contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    bar = ProgressBar(iterable, length=length, label=label, hidden=hidden, **options)
    try:
        yield bar
    finally:
        if not bar.hidden:
            sys.stdout.write("\n")
            sys.stdout.flush()


@contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream routed through PAGER when interactive."""
    if not (_is_tty(sys.stdin) and _is_tty(sys.stdout)):
        yield sys.stdout
        return
    pager_cmd = os.environ.get("PAGER")
    if not pager_cmd:
        yield sys.stdout
        return
    proc = subprocess.Popen(shlex.split(pager_cmd), stdin=subprocess.PIPE, text=True)
    try:
        yield proc.stdin
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()


def echo_via_pager(text_or_generator, color=None):
    """Write text, an iterable of text chunks, or a callable returning either, via pager."""
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    with get_pager_file(color=color) as f:
        keep = _resolve_color(color, f)
        for chunk in chunks:
            if not keep:
                chunk = unstyle(chunk)
            f.write(chunk)
            f.flush()


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Launch an editor on text or a file. Returns the saved text, or None."""
    if filename is not None:
        path = str(filename)
        _run_editor(editor, path, env)
        return None
    fd, tmp = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            if text:
                f.write(text)
        before = _Path(tmp).read_bytes()
        _run_editor(editor, tmp, env)
        after = _Path(tmp).read_bytes()
        if require_save and before == after:
            return None
        return after.decode("utf-8")
    finally:
        try:
            os.remove(tmp)
        except OSError:
            pass


def _run_editor(editor, path, env):
    cmd = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or (
        "notepad" if os.name == "nt" else "vi")
    args = shlex.split(cmd) + [path]
    full_env = dict(os.environ)
    if env:
        full_env.update(env)
    subprocess.call(args, env=full_env)


def launch(url, wait=False, locate=False):
    """Open ``url`` or a filename with the default application. Returns the process status."""
    if sys.platform == "darwin":
        args = ["open"]
    elif os.name == "nt":
        os.startfile(url)  # type: ignore[attr-defined]
        return 0
    else:
        args = ["xdg-open"]
    if locate and sys.platform == "darwin":
        args.append("-R")
    args.append(url)
    try:
        proc = subprocess.Popen(args)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user config directory for ``app_name``."""
    if os.name == "nt" and not force_posix:
        base = os.environ.get("APPDATA") or str(_Path.home() / "AppData" / "Roaming")
        return os.path.join(base, app_name)
    if sys.platform == "darwin" and not force_posix:
        return str(_Path.home() / "Library" / "Application Support" / app_name)
    if force_posix:
        return str(_Path.home() / ("." + app_name.lower().replace(" ", "-")))
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = xdg if xdg else str(_Path.home() / ".config")
    folder = re.sub(r"\s+", "-", app_name.lower())
    return os.path.join(base, folder)


def format_filename(filename, shorten=False):
    """Return a printable text form of a filename."""
    if isinstance(filename, (bytes, bytearray)):
        text = os.fsdecode(bytes(filename))
    else:
        text = os.fspath(filename)
    text = text.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")
    if shorten:
        text = os.path.basename(text)
    return text


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or a standard stream when ``filename`` is ``-``."""
    from .types import open_stream

    return open_stream(filename, mode=mode, encoding=encoding, errors=errors,
                       lazy=lazy, atomic=atomic)
