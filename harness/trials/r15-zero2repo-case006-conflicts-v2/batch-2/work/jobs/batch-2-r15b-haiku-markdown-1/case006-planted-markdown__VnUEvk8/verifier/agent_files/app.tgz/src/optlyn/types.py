"""Parameter types and conversion."""

import datetime as _dt
import enum
import io
import os
import sys
import uuid as _uuid
from pathlib import Path as _PathLib

from .exceptions import BadParameter

_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class ParamType:
    """Base class for parameter types. Subclasses implement ``convert``."""

    name = "text"
    is_composite = False
    envvar_list_splitter = None

    def convert(self, value, param=None, ctx=None):
        return value

    def __call__(self, value, param=None, ctx=None):
        return self.convert(value, param, ctx)

    def get_metavar(self, param=None):
        return None

    def get_missing_message(self, param=None):
        return None

    def shell_complete(self, ctx, param, incomplete):
        return []

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self):
        return self.name.upper()


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class _IntType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid integer", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid float", param, ctx)


class _BoolType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value))
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid UUID", param, ctx)


STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self._is_enum = True
            self.choices = list(choices.__members__.values())
            self._tokens = [m.name for m in self.choices]
        else:
            self._is_enum = False
            self.choices = list(choices)
            self._tokens = [str(c) for c in self.choices]

    def _norm(self, s):
        return s if self.case_sensitive else s.casefold()

    def get_metavar(self, param=None):
        return "[" + "|".join(self._tokens) + "]"

    def convert(self, value, param=None, ctx=None):
        if self._is_enum and isinstance(value, enum.Enum) and value in self.choices:
            return value
        if not self._is_enum and value in self.choices:
            return value
        token = str(value)
        norm = self._norm(token)
        for original, tok in zip(self.choices, self._tokens):
            if self._norm(tok) == norm:
                return original
        self.fail(f"{value!r} is not one of {', '.join(repr(t) for t in self._tokens)}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        return [t for t in self._tokens if t.startswith(incomplete)]


_DEFAULT_DT_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DT_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value).strip(), fmt)
            except ValueError:
                continue
        self.fail(f"{value!r} does not match the formats {', '.join(self.formats)}.", param, ctx)


class IntRange(_IntType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        lo_ok = self.min is None or (v > self.min if self.min_open else v >= self.min)
        hi_ok = self.max is None or (v < self.max if self.max_open else v <= self.max)
        if lo_ok and hi_ok:
            return v
        if self.clamp:
            if self.min is not None and not lo_ok:
                v = self.min + 1 if self.min_open else self.min
            if self.max is not None and not hi_ok:
                v = self.max - 1 if self.max_open else self.max
            return v
        self.fail(f"{v} is not in the valid range {self._range_text()}.", param, ctx)

    def _range_text(self):
        lo = "-inf" if self.min is None else self.min
        hi = "inf" if self.max is None else self.max
        lb = "(" if self.min_open else "["
        rb = ")" if self.max_open else "]"
        return f"{lb}{lo}, {hi}{rb}"


class FloatRange(_FloatType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise ValueError("Clamp is only allowed when both bounds are closed.")
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        if self.min is not None and v < self.min:
            if self.clamp:
                return float(self.min)
            self.fail(f"{v} is not in the valid range.", param, ctx)
        if self.max is not None and v > self.max:
            if self.clamp:
                return float(self.max)
            self.fail(f"{v} is not in the valid range.", param, ctx)
        return v


class Tuple(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(t) for t in types]

    @property
    def arity(self):
        return len(self.types)

    def convert(self, value, param=None, ctx=None):
        if len(value) != len(self.types):
            self.fail(f"expected {len(self.types)} values, got {len(value)}.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


def open_stream(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a real file, or return a standard stream for ``-``."""
    if filename == "-":
        if "r" in mode:
            stream = sys.stdin
        else:
            stream = sys.stdout
        if "b" in mode:
            return getattr(stream, "buffer", stream)
        return stream
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    return _open_real(filename, mode, encoding, errors, atomic)


def _open_real(filename, mode, encoding, errors, atomic):
    if atomic and "w" in mode:
        return AtomicFile(filename, mode, encoding, errors)
    kwargs = {} if "b" in mode else {"encoding": encoding, "errors": errors}
    return open(filename, mode, **kwargs)


class AtomicFile(io.IOBase):
    """Writes to a sibling temp file and replaces the target on close."""

    def __init__(self, filename, mode, encoding, errors):
        self._target = os.fspath(filename)
        self._tmp = self._target + ".tmp-optlyn"
        kwargs = {} if "b" in mode else {"encoding": encoding, "errors": errors}
        self._f = open(self._tmp, mode, **kwargs)

    def write(self, data):
        return self._f.write(data)

    def flush(self):
        self._f.flush()

    def close(self):
        if self.closed:
            return
        self._f.close()
        os.replace(self._tmp, self._target)
        super().close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()


class LazyFile:
    """Defers opening a write-mode file until first I/O."""

    def __init__(self, filename, mode, encoding, errors, atomic):
        self._args = (filename, mode, encoding, errors, atomic)
        self._f = None

    def _real(self):
        if self._f is None:
            self._f = _open_real(*self._args)
        return self._f

    def __getattr__(self, name):
        return getattr(self._real(), name)

    def write(self, data):
        return self._real().write(data)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    def close(self):
        if self._f is not None:
            self._f.close()


class File(ParamType):
    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        if lazy is None:
            lazy = "r" not in mode
        self.lazy = lazy

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        if value == "-":
            return open_stream("-", self.mode, self.encoding, self.errors)
        try:
            if self.lazy:
                return LazyFile(value, self.mode, self.encoding, self.errors, self.atomic)
            return _open_real(value, self.mode, self.encoding, self.errors, self.atomic)
        except OSError as e:
            self.fail(f"'{value}': {e.strerror or e}", param, ctx)


class Path(ParamType):
    name = "path"

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param=None, ctx=None):
        raw = os.fspath(value)
        if self.allow_dash and raw == "-":
            return self._out("-")
        rv = raw
        if self.resolve_path:
            rv = os.path.realpath(rv)
            if not os.path.isabs(rv):
                rv = os.path.abspath(rv)
        if not os.path.exists(rv):
            if self.exists:
                self.fail(f"'{raw}' does not exist.", param, ctx)
            return self._out(rv)
        if not self.file_okay and os.path.isfile(rv):
            self.fail(f"'{raw}' is a file.", param, ctx)
        if not self.dir_okay and os.path.isdir(rv):
            self.fail(f"'{raw}' is a directory.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"'{raw}' is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"'{raw}' is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"'{raw}' is not executable.", param, ctx)
        return self._out(rv)

    def _out(self, p):
        if self.path_type is _PathLib:
            return _PathLib(p)
        if self.path_type is str or self.path_type is None:
            return p
        return self.path_type(p)

    def shell_complete(self, ctx, param, incomplete):
        return []


_BUILTIN = {
    str: STRING,
    int: INT,
    float: FLOAT,
    bool: BOOL,
    _uuid.UUID: UUID,
}


def convert_type(ty, default=None):
    """Turn a type spec (instance, class, callable, tuple of types, or None) into a ParamType."""
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, tuple):
        return Tuple(ty)
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if ty is None and default is not None:
        if isinstance(default, bool):
            return BOOL
        if isinstance(default, int):
            return INT
        if isinstance(default, float):
            return FLOAT
        if isinstance(default, tuple):
            return Tuple([type(v) for v in default])
        if isinstance(default, (list, tuple)) and default:
            return convert_type(None, default[0])
        return STRING
    if ty is None:
        return STRING
    if ty in _BUILTIN:
        return _BUILTIN[ty]
    if callable(ty):
        return FuncType(ty)
    raise TypeError(f"Unsupported type: {ty!r}")


class FuncType(ParamType):
    """Wraps a conversion function ``f(token) -> value`` that refuses by raising ValueError."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        if not isinstance(value, str):
            return value
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is invalid", param, ctx)
