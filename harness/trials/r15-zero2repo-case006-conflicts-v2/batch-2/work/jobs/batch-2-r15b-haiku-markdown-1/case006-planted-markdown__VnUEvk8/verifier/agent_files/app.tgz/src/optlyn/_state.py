"""Thread-local stack of the current invocation context."""

import threading

_local = threading.local()


def _stack():
    s = getattr(_local, "stack", None)
    if s is None:
        s = _local.stack = []
    return s


def push_context(ctx):
    _stack().append(ctx)


def pop_context():
    _stack().pop()


def peek_context():
    s = _stack()
    return s[-1] if s else None
