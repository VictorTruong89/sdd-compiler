"""Text wrapping helpers used by help pages."""

import re
import textwrap

_SENTENCE_END = re.compile(r"(?<=[.!?])\s")


def first_sentence(text):
    """The first sentence of ``text``, with internal whitespace collapsed."""
    flat = " ".join(text.split())
    if not flat:
        return ""
    match = _SENTENCE_END.search(flat)
    return flat[: match.start() + 1].rstrip() if match else flat


def _paragraphs(text):
    """Split on blank lines; each paragraph is a list of its raw lines."""
    paras, current = [], []
    for line in text.splitlines():
        if line.strip() == "":
            if current:
                paras.append(current)
                current = []
        else:
            current.append(line)
    if current:
        paras.append(current)
    return paras


def wrap_text(text, width=100, initial_indent="", subsequent_indent="",
              preserve_paragraphs=False):
    """Rewrap ``text`` to ``width`` columns.

    Single newlines inside a paragraph are not preserved. A paragraph whose
    first line is only a backspace character is not rewrapped; its line
    breaks are kept and the backspace line is removed.
    """
    out = []
    for para in _paragraphs(text):
        if para and para[0].strip("\b") == "" and "\b" in para[0]:
            body = para[1:]
            for line in body:
                out.append(initial_indent + line if not out else subsequent_indent + line)
            out.append("")
            continue
        flat = " ".join(line.strip() for line in para)
        wrapped = textwrap.fill(
            flat, width=width,
            initial_indent=initial_indent if not out else subsequent_indent,
            subsequent_indent=subsequent_indent)
        out.append(wrapped)
        out.append("")
    if out and out[-1] == "":
        out.pop()
    return "\n".join(out)
