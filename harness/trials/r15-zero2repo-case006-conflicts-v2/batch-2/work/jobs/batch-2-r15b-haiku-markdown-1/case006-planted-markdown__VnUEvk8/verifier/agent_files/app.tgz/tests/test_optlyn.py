import os

import pytest

from optlyn import (Abort, Choice, IntRange, argument, command, confirmation_option,
                    custom_version_option, group, option, pass_obj)
from optlyn.formatting import first_sentence, wrap_text
from optlyn.shell_completion import complete
from optlyn.testing import CliRunner
from optlyn.termui import style, unstyle


@pytest.fixture
def runner():
    return CliRunner()


def make_tool():
    @group()
    @option("--verbose", "-v", is_flag=True)
    def tool(verbose):
        """Top-level tool."""

    @tool.command()
    @argument("name")
    @option("--count", type=int, default=2)
    @option("--mode", type=Choice(["a", "b"]))
    def hello(name, count, mode):
        """Say hello. More text."""
        print("hello", name, count, mode)

    @tool.command(hidden=True)
    def secret():
        print("secret")

    return tool


def test_command_name_derivation():
    @command()
    def my_thing_command():
        pass

    assert my_thing_command.name == "my-thing"


def test_group_dispatch_and_defaults(runner):
    tool = make_tool()
    r = runner.invoke(tool, ["hello", "bob", "--count", "3", "--mode", "a"])
    assert r.exit_code == 0
    assert "hello bob 3 a" in r.output


def test_group_no_args_is_usage_failure(runner):
    r = runner.invoke(make_tool(), [])
    assert r.exit_code == 2
    assert "Commands:" in r.stderr


def test_help_is_success_and_skips_callback(runner):
    tool = make_tool()
    r = runner.invoke(tool, ["hello", "--help"])
    assert r.exit_code == 0
    assert "Say hello." in r.stdout
    assert "hello bob" not in r.output


def test_unknown_option_and_missing_argument(runner):
    tool = make_tool()
    r = runner.invoke(tool, ["hello", "--bogus"])
    assert r.exit_code == 2
    r = runner.invoke(tool, ["hello"])
    assert r.exit_code == 2
    assert "NAME" in r.stderr


def test_bad_choice_names_parameter(runner):
    r = runner.invoke(make_tool(), ["hello", "x", "--mode", "zz"])
    assert r.exit_code == 2
    assert "--mode" in r.stderr


def test_hidden_command_still_dispatches(runner):
    r = runner.invoke(make_tool(), ["secret"])
    assert r.exit_code == 0
    assert r.stdout == "secret\n"


def test_hidden_command_not_completed():
    assert "secret" not in complete(make_tool(), "tool", [], "")
    assert complete(make_tool(), "tool", [], "sec") == []


def test_int_range_clamp(runner):
    @command()
    @option("--level", type=IntRange(1, 5, clamp=True), default=3)
    def c(level):
        print("level", level)

    assert runner.invoke(c, ["--level", "9"]).stdout == "level 5\n"


def test_env_var_fills_option(runner):
    @command()
    @option("--name", envvar="OPTLYN_TEST_NAME")
    def c(name):
        print("name", name)

    r = runner.invoke(c, [], env={"OPTLYN_TEST_NAME": "zed"})
    assert r.stdout == "name zed\n"


def test_default_map_and_command_line_precedence(runner):
    @command()
    @option("--name")
    def c(name):
        print("name", name)

    assert runner.invoke(c, [], default_map={"name": "dm"}).stdout == "name dm\n"
    assert runner.invoke(c, ["--name", "cli"], default_map={"name": "dm"}).stdout == "name cli\n"


def test_chain_collects_results(runner):
    @group(chain=True)
    def ch():
        pass

    @ch.command()
    @option("--n", type=int, default=0)
    def a(n):
        return ("a", n)

    @ch.command()
    @argument("rest", nargs=-1)
    def b(rest):
        return ("b", rest)

    res = ch.main(["a", "--n", "2", "b", "x", "y"], standalone_mode=False, prog_name="ch")
    assert res == [("a", 2), ("b", ("x", "y"))]


def test_custom_version_prints_exact_string(runner):
    @command()
    @custom_version_option(lambda ctx: "custom 1.2")
    def c():
        print("should not run")

    r = runner.invoke(c, ["--version"])
    assert r.exit_code == 0
    assert r.output == "custom 1.2\n"


def test_confirmation_decline_aborts(runner):
    @command()
    @confirmation_option("--yes", prompt="Sure?")
    def c():
        print("confirmed")

    r = runner.invoke(c, [], input="n\n")
    assert r.exit_code == 1
    assert "confirmed" not in r.output
    assert runner.invoke(c, ["--yes"]).stdout == "confirmed\n"


def test_pass_obj_visible_to_child(runner):
    @group()
    @option("--x", default="root")
    def g(x):
        pass

    @g.command()
    @pass_obj
    def sub(obj):
        print("obj", obj)

    @command()
    def unused():
        pass

    assert runner.invoke(g, ["sub"], obj="thing").exit_code == 0


def test_style_and_unstyle():
    styled = style("x", fg="red", bold=True)
    assert styled != "x"
    assert unstyle(styled) == "x"
    with pytest.raises(ValueError):
        style("x", fg="nope")


def test_text_helpers():
    assert first_sentence("One thing. Two things.") == "One thing."
    assert wrap_text("aaa bbb ccc", width=7) == "aaa bbb\nccc"


def test_isolated_filesystem_creates_cwd(runner):
    before = os.getcwd()
    with runner.isolated_filesystem() as d:
        assert os.getcwd() == d
    assert os.getcwd() == before


def test_abort_is_exit_one_standalone(runner):
    @command()
    def c():
        raise Abort()

    r = runner.invoke(c, [])
    assert r.exit_code == 1
