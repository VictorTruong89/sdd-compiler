"""Decorators that declare commands, groups, options and arguments."""

import inspect
from functools import update_wrapper

from ._globals import get_current_context
from .core import Argument, Command, Group, Option
from .termui import confirm, echo

_PARAMS_ATTR = "__optlyn_params__"
_COMMAND_SUFFIXES = ("_command", "_cmd", "_group", "_grp")


def _default_name(func_name):
    name = func_name.lower()
    for suffix in _COMMAND_SUFFIXES:
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _take_params(func):
    """Return the declarations attached to ``func`` and clear them from it."""
    params = func.__dict__.pop(_PARAMS_ATTR, [])
    return list(reversed(params))


def _attach_param(func, param):
    if isinstance(func, Command):
        raise TypeError("Parameters must be declared before the command is created.")
    func.__dict__.setdefault(_PARAMS_ATTR, []).append(param)


def _doc(func):
    doc = inspect.getdoc(func)
    return doc if doc else None


def command(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Command`."""
    if callable(name) and not isinstance(name, str):
        return command(None, cls, **attrs)(name)

    def decorator(func):
        params = _take_params(func)
        cmd_name = name if name is not None else _default_name(func.__name__)
        kwargs = dict(attrs)
        kwargs.setdefault("help", _doc(func))
        return (cls or Command)(cmd_name, callback=func, params=params, **kwargs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Group` (or ``cls``)."""
    if callable(name) and not isinstance(name, str):
        return group(None, cls, **attrs)(name)

    def decorator(func):
        params = _take_params(func)
        grp_name = name if name is not None else _default_name(func.__name__)
        kwargs = dict(attrs)
        kwargs.setdefault("help", _doc(func))
        return (cls or Group)(grp_name, callback=func, params=params, **kwargs)

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an :class:`Option` to the function below the decorator."""

    def decorator(func):
        _attach_param(func, (cls or Option)(param_decls, **attrs))
        return func

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach an :class:`Argument` to the function below the decorator."""

    def decorator(func):
        _attach_param(func, (cls or Argument)(param_decls, **attrs))
        return func

    return decorator


def _show_help(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def help_option(*param_decls, **kwargs):
    """An extra eager help flag. Defaults to ``--help``."""
    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("callback", _show_help)
    kwargs.setdefault("help", "Show this message and exit.")
    return option(*param_decls, **kwargs)


def _detect_version(package_name):
    from importlib import metadata

    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    dists = metadata.packages_distributions().get(package_name, [])
    if dists:
        return metadata.version(dists[0])
    raise RuntimeError(f"{package_name!r} is not an installed distribution or import name.")


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """An eager ``--version`` flag that prints a version identity and exits."""
    if not param_decls:
        param_decls = ("--version",)

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        prog = prog_name or ctx.find_root().info_name
        ver = version if version is not None else _detect_version(package_name)
        template = message or "%(prog)s, version %(version)s"
        echo(template % {"prog": prog, "package": package_name, "version": ver}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show the version and exit.")
    return option(*param_decls, callback=callback, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    """An eager ``--version`` flag whose whole output is ``callback(ctx)``."""
    if not param_decls:
        param_decls = ("--version",)

    def show_version(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=True)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show the version and exit.")
    return option(*param_decls, callback=show_version, **kwargs)


def password_option(*param_decls, **kwargs):
    """A prompting option with hidden input and a confirmation prompt."""
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("help", "The password to use.")
    return option(*param_decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    """A yes-style flag that asks for confirmation when omitted and aborts on no."""
    if not param_decls:
        param_decls = ("--yes",)
    question = kwargs.pop("prompt", "Do you want to continue?")

    def callback(ctx, param, value):
        if ctx.resilient_parsing:
            return value
        if not value:
            confirm(question, default=False, abort=True)
        return value

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("callback", callback)
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*param_decls, **kwargs)


def pass_context(func):
    """Pass the current :class:`Context` as the first argument."""

    def new_func(*args, **kwargs):
        return func(get_current_context(), *args, **kwargs)

    return update_wrapper(new_func, func)


def pass_obj(func):
    """Pass the current context's author object as the first argument."""

    def new_func(*args, **kwargs):
        return func(get_current_context().obj, *args, **kwargs)

    return update_wrapper(new_func, func)


def make_pass_decorator(object_type, ensure=False):
    """Pass the nearest author object of ``object_type`` as the first argument."""

    def decorator(func):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            return func(obj, *args, **kwargs)

        return update_wrapper(new_func, func)

    return decorator
