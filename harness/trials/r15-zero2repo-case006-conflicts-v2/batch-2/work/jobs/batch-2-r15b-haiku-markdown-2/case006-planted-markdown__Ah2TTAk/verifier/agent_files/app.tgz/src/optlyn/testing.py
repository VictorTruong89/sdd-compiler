"""In-process runner for invoking commands in tests and tooling."""

import contextlib
import io
import os
import shutil
import shlex
import sys
import tempfile


class _Sink(io.BytesIO):
    """A byte sink that also appends every write to a shared, ordered buffer."""

    def __init__(self, shared):
        super().__init__()
        self._shared = shared

    def write(self, data):
        self._shared.write(data)
        return super().write(data)


class _Input(io.TextIOWrapper):
    """Standard input fed from bytes, optionally echoing what was read."""

    def __init__(self, data, charset, echo=None):
        super().__init__(io.BytesIO(data), encoding=charset)
        self._echo = echo

    def readline(self, size=-1):
        line = super().readline(size)
        if self._echo is not None and line:
            self._echo(line)
        return line


class Result:
    """The outcome of :meth:`CliRunner.invoke`."""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, exit_code, exception, exc_info):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _decode(self, data):
        return data.decode(self.runner.charset, "replace")

    @property
    def output(self):
        return self._decode(self.output_bytes)

    @property
    def stdout(self):
        return self._decode(self.stdout_bytes)

    @property
    def stderr(self):
        return self._decode(self.stderr_bytes)

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invokes a command with a list of tokens and captures its output."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        data = input.encode(self.charset) if isinstance(input, str) else (input or b"")
        shared = io.BytesIO()
        stdout_sink = _Sink(shared)
        stderr_sink = _Sink(shared)
        stdout = io.TextIOWrapper(stdout_sink, encoding=self.charset, write_through=True, newline="\n")
        stderr = io.TextIOWrapper(stderr_sink, encoding=self.charset, write_through=True, newline="\n")
        stdin = _Input(data, self.charset, echo=(stdout.write if self.echo_stdin else None))
        merged_env = dict(self.env)
        merged_env.update(env or {})
        old_env = {}
        for key, value in merged_env.items():
            old_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        old_streams = sys.stdin, sys.stdout, sys.stderr
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield (stdout_sink, stderr_sink, shared)
        finally:
            stdout.flush()
            stderr.flush()
            sys.stdin, sys.stdout, sys.stderr = old_streams
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        """Run ``cli`` with ``args`` and return a :class:`Result`."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            args = shlex.split(args)
        prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
        standalone = extra.pop("standalone_mode", True)
        exit_code = 0
        exception = None
        exc_info = None
        if self.capture == "fd":
            return self._invoke_fd(cli, list(args), input, env, catch_exceptions, color, prog_name, standalone, extra)
        with self.isolation(input=input, env=env, color=color) as (out, err, shared):
            try:
                cli.main(
                    args=list(args),
                    prog_name=prog_name,
                    standalone_mode=standalone,
                    color=color,
                    **extra,
                )
            except SystemExit as e:
                exit_code = _exit_status(e)
                if exit_code != 0:
                    exception = e
                    exc_info = sys.exc_info()
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            sys.stdout.flush()
            sys.stderr.flush()
            stdout_bytes = out.getvalue()
            stderr_bytes = err.getvalue()
            output_bytes = shared.getvalue()
        return Result(self, stdout_bytes, stderr_bytes, output_bytes, exit_code, exception, exc_info)

    def _invoke_fd(self, cli, args, input, env, catch_exceptions, color, prog_name, standalone, extra):
        """Capture OS-level writes to descriptors 1 and 2 as well as interpreter writes."""
        sys.stdout.flush()
        sys.stderr.flush()
        saved_out, saved_err = os.dup(1), os.dup(2)
        out_file, err_file = tempfile.TemporaryFile(), tempfile.TemporaryFile()
        exit_code, exception, exc_info = 0, None, None
        try:
            os.dup2(out_file.fileno(), 1)
            os.dup2(err_file.fileno(), 2)
            data_out = io.TextIOWrapper(io.FileIO(out_file.fileno(), "w", closefd=False), encoding=self.charset, write_through=True, newline="\n")
            data_err = io.TextIOWrapper(io.FileIO(err_file.fileno(), "w", closefd=False), encoding=self.charset, write_through=True, newline="\n")
            with self.isolation(input=input, env=env, color=color) as _:
                sys.stdout, sys.stderr = data_out, data_err
                try:
                    cli.main(args=args, prog_name=prog_name, standalone_mode=standalone, color=color, **extra)
                except SystemExit as e:
                    exit_code = _exit_status(e)
                    if exit_code != 0:
                        exception = e
                        exc_info = sys.exc_info()
                except Exception as e:
                    if not catch_exceptions:
                        raise
                    exception = e
                    exit_code = 1
                    exc_info = sys.exc_info()
                finally:
                    data_out.flush()
                    data_err.flush()
                    sys.stdout, sys.stderr = sys.__stdout__, sys.__stderr__
        finally:
            os.dup2(saved_out, 1)
            os.dup2(saved_err, 2)
            os.close(saved_out)
            os.close(saved_err)
        out_file.seek(0)
        err_file.seek(0)
        stdout_bytes = out_file.read()
        stderr_bytes = err_file.read()
        out_file.close()
        err_file.close()
        return Result(self, stdout_bytes, stderr_bytes, stdout_bytes + stderr_bytes, exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Work inside a new empty directory. It is removed on exit unless ``temp_dir`` is given."""
        cwd = os.getcwd()
        directory = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(directory)
        try:
            yield directory
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(directory, ignore_errors=True)


def _exit_status(e):
    if e.code is None:
        return 0
    if isinstance(e.code, int):
        return e.code
    sys.stderr.write(str(e.code) + "\n")
    return 1
