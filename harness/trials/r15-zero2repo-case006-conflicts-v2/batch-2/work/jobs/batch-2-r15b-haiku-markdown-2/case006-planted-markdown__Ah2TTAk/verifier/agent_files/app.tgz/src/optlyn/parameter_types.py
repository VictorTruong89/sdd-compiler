"""Built-in parameter types and type conversion."""

import datetime as _dt
import enum
import os
import pathlib
import uuid

from ._files import _is_writing
from .exceptions import BadParameter, FileError
from .shell_completion import CompletionItem


class ParamType:
    """Base class for parameter types. Subclasses implement :meth:`convert`."""

    name = "text"
    envvar_list_splitter = None

    def convert(self, value, param, ctx):
        return value

    def get_metavar(self, param):
        return None

    def split_envvar_value(self, rv):
        return rv.split()

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx, param, incomplete):
        return []

    def __call__(self, value, param=None, ctx=None):
        return self.convert(value, param, ctx)

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        if isinstance(value, str):
            return value
        return str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param, ctx):
        if isinstance(value, float):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return float(value)
        try:
            return float(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return value
        lowered = str(value).strip().lower()
        if lowered in _TRUE:
            return True
        if lowered in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


class FuncParamType(ParamType):
    """Adapts a plain conversion function that raises ``ValueError`` on refusal."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text") or "text"

    def convert(self, value, param, ctx):
        if not isinstance(value, str):
            return value
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is not valid.", param, ctx)


class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration."""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self.keys = [member.name for member in self.choices]
        else:
            self.choices = list(choices)
            self.keys = [str(choice) for choice in self.choices]
        self.case_sensitive = case_sensitive

    def get_metavar(self, param):
        return "[" + "|".join(self.keys) + "]"

    def _norm(self, text, ctx):
        func = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
        if func is not None:
            text = func(text)
        if not self.case_sensitive:
            text = text.casefold()
        return text

    def convert(self, value, param, ctx):
        for choice in self.choices:
            if choice is value:
                return choice
        text = value if isinstance(value, str) else str(value)
        wanted = self._norm(text, ctx)
        for key, choice in zip(self.keys, self.choices):
            if self._norm(key, ctx) == wanted:
                return choice
        shown = ", ".join(repr(k) for k in self.keys)
        self.fail(f"{text!r} is not {shown}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        return [CompletionItem(key) for key in self.keys if key.startswith(incomplete)]


_DEFAULT_DATETIME_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DATETIME_FORMATS)

    def convert(self, value, param, ctx):
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value), fmt)
            except ValueError:
                continue
        shown = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the formats {shown}.", param, ctx)


def _range_desc(lo, hi, lo_open, hi_open):
    left = "(" if lo_open else "["
    right = ")" if hi_open else "]"
    lo_s = "" if lo is None else str(lo)
    hi_s = "" if hi is None else str(hi)
    return f"{left}{lo_s}, {hi_s}{right}"


class IntRange(IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        v = super().convert(value, param, ctx)
        below = self.min is not None and (v < self.min or (self.min_open and v == self.min))
        above = self.max is not None and (v > self.max or (self.max_open and v == self.max))
        if not below and not above:
            return v
        if self.clamp:
            if below:
                return self.min + 1 if self.min_open else self.min
            return self.max - 1 if self.max_open else self.max
        desc = _range_desc(self.min, self.max, self.min_open, self.max_open)
        self.fail(f"{v} is not in the valid range of {desc}.", param, ctx)


class FloatRange(FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise TypeError("Clamp is not allowed when a bound is open.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        v = super().convert(value, param, ctx)
        below = self.min is not None and (v < self.min or (self.min_open and v == self.min))
        above = self.max is not None and (v > self.max or (self.max_open and v == self.max))
        if not below and not above:
            return v
        if self.clamp:
            return float(self.min) if below else float(self.max)
        desc = _range_desc(self.min, self.max, self.min_open, self.max_open)
        self.fail(f"{v} is not in the valid range of {desc}.", param, ctx)


class Tuple(ParamType):
    """A fixed-length product of inner types."""

    def __init__(self, types):
        self.types = [convert_type(t) for t in types]

    @property
    def name(self):
        return "<" + " ".join(t.name for t in self.types) + ">"

    def get_metavar(self, param):
        return " ".join((t.get_metavar(param) or t.name.upper()) for t in self.types)

    def convert(self, value, param, ctx):
        if isinstance(value, str) or len(value) != len(self.types):
            self.fail(f"{value!r} does not have {len(self.types)} items.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


def _is_writing_mode(mode):
    return _is_writing(mode)


class File(ParamType):
    """Opens a file. The value delivered is an open file object."""

    name = "filename"
    envvar_list_splitter = os.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param, ctx):
        from ._files import open_file

        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        lazy = self.lazy if self.lazy is not None else _is_writing_mode(self.mode)
        try:
            f = open_file(value, self.mode, self.encoding, self.errors, lazy=lazy, atomic=self.atomic)
        except FileError as e:
            self.fail(e.message, param, ctx)
        if ctx is not None:
            ctx.call_on_close(f.close)
        return f

    def shell_complete(self, ctx, param, incomplete):
        return [CompletionItem(incomplete, type="file")]


class Path(ParamType):
    """Validates a filesystem path and delivers it as ``str`` or ``pathlib.Path``."""

    name = "path"
    envvar_list_splitter = os.pathsep

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def _coerce(self, rv):
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return rv

    def convert(self, value, param, ctx):
        if isinstance(value, pathlib.PurePath):
            value = os.fspath(value)
        if self.allow_dash and value == "-":
            return self._coerce("-")
        rv = value
        exists = os.path.exists(rv)
        if not exists:
            if self.exists:
                self.fail(f"{value!r} does not exist.", param, ctx)
            if self.resolve_path:
                rv = os.path.realpath(rv)
            return self._coerce(rv)
        if not self.file_okay and os.path.isfile(rv):
            self.fail(f"{value!r} is a file.", param, ctx)
        if not self.dir_okay and os.path.isdir(rv):
            self.fail(f"{value!r} is a directory.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{value!r} is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{value!r} is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{value!r} is not executable.", param, ctx)
        if self.resolve_path:
            rv = os.path.realpath(rv)
        return self._coerce(rv)

    def shell_complete(self, ctx, param, incomplete):
        kind = "dir" if self.dir_okay and not self.file_okay else "file"
        return [CompletionItem(incomplete, type=kind)]


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()


def infer_type(value):
    """Infer a parameter type from a default value."""
    if isinstance(value, bool):
        return BOOL
    if isinstance(value, int):
        return INT
    if isinstance(value, float):
        return FLOAT
    if isinstance(value, (list, tuple)):
        return infer_type(value[0]) if value else STRING
    if isinstance(value, uuid.UUID):
        return UUID
    return STRING


def convert_type(ty, default=None):
    """Turn a type specification into a :class:`ParamType` instance."""
    if ty is None:
        if default is None:
            return STRING
        return infer_type(default)
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if ty is str:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if ty is uuid.UUID:
        return UUID
    if isinstance(ty, tuple):
        return Tuple(ty)
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")
