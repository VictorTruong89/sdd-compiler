"""Shell completion: registration scripts and suggestion output."""

import os
import re
import sys

SHELLS = ("bash", "zsh", "fish", "powershell")


class CompletionItem:
    """A suggestion. ``type`` is ``plain`` for values, or ``file``/``dir`` for path requests."""

    def __init__(self, value, help=None, type="plain"):
        self.value = value
        self.help = help
        self.type = type


_BASH = """\
__FN__() {
    local IFS=$'\\n'
    local line value
    COMPREPLY=()
    for line in $(env COMP_WORDS="${COMP_WORDS[*]}" COMP_CWORD=$COMP_CWORD __VAR__=bash_complete __PROG__); do
        case "$line" in
            plain,*) value="${line#plain,}"; COMPREPLY+=("${value%%$'\\t'*}") ;;
            file,*) COMPREPLY+=($(compgen -f -- "${line#file,}")) ;;
            dir,*) COMPREPLY+=($(compgen -d -- "${line#dir,}")) ;;
        esac
    done
    return 0
}
complete -o default -F __FN__ __PROG__
"""

_ZSH = """\
#compdef __PROG__
__FN__() {
    local line kind rest value help
    local -a plain_items
    local -a out
    out=("${(@f)$(env COMP_WORDS="${words[*]}" COMP_CWORD=$((CURRENT-1)) __VAR__=zsh_complete __PROG__)}")
    for line in "${out[@]}"; do
        kind="${line%%,*}"
        rest="${line#*,}"
        value="${rest%%$'\\t'*}"
        help=""
        if [[ "$rest" == *$'\\t'* ]]; then help="${rest#*$'\\t'}"; fi
        case "$kind" in
            plain) plain_items+=("${value//:/\\\\:}:${help}") ;;
            file) _files ;;
            dir) _files -/ ;;
        esac
    done
    if (( ${#plain_items} )); then _describe 'values' plain_items; fi
}
compdef __FN__ __PROG__
"""

_FISH = """\
function __FN__
    set -l current (commandline -ct)
    for line in (env COMP_WORDS="(commandline -p)" COMP_CWORD="$current" __VAR__=fish_complete __PROG__)
        switch $line
            case 'plain,*'
                string replace -r '^plain,' '' -- $line
            case 'file,*'
                __fish_complete_path $current
            case 'dir,*'
                __fish_complete_directories $current
        end
    end
end
complete -c __PROG__ -f -a '(__FN__)'
"""

_POWERSHELL = """\
Register-ArgumentCompleter -Native -CommandName '__PROG__' -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)
    $env:COMP_WORDS = $commandAst.ToString()
    $env:COMP_CWORD = ($commandAst.CommandElements.Count)
    $env:__VAR__ = 'powershell_complete'
    $out = & '__PROG__'
    Remove-Item Env:__VAR__
    foreach ($line in $out) {
        if ($line -like 'plain,*') {
            $value = ($line.Substring(6)).Split("`t")[0]
            [System.Management.Automation.CompletionResult]::new($value, $value, 'ParameterValue', $value)
        }
    }
}
"""

_TEMPLATES = {"bash": _BASH, "zsh": _ZSH, "fish": _FISH, "powershell": _POWERSHELL}


def _function_name(prog_name):
    return "_" + re.sub(r"\W", "_", prog_name) + "_completion"


def _complete_var(prog_name):
    return "_" + prog_name.replace("-", "_").upper() + "_COMPLETE"


def source_script(shell, prog_name):
    template = _TEMPLATES[shell]
    return (
        template.replace("__FN__", _function_name(prog_name))
        .replace("__VAR__", _complete_var(prog_name))
        .replace("__PROG__", prog_name)
    )


def _read_words(shell):
    raw = os.environ.get("COMP_WORDS", "")
    words = raw.split(" ")
    cword = os.environ.get("COMP_CWORD", "")
    if shell == "fish":
        incomplete = cword
        args = words[1:-1] if words and words[-1] == incomplete else words[1:]
        return args, incomplete
    try:
        index = int(cword)
    except ValueError:
        index = len(words)
    incomplete = words[index] if 0 <= index < len(words) else ""
    return words[1:index], incomplete


def _find_option(params, token):
    from .core import Option

    for p in params:
        if isinstance(p, Option) and token in p.all_names:
            return p
    return None


def _value_items(ctx, param, incomplete):
    if param.shell_complete is not None:
        found = param.shell_complete(ctx, param, incomplete)
    else:
        found = param.type.shell_complete(ctx, param, incomplete)
    items = []
    for item in found or []:
        items.append(item if isinstance(item, CompletionItem) else CompletionItem(str(item)))
    return items


def complete_words(cli, prog_name, args, incomplete):
    """Return the suggestions (``CompletionItem`` list) for an incomplete token."""
    from .core import Context, Group

    ctx = Context(cli, info_name=prog_name, resilient_parsing=True)
    cmd = cli
    pending = None
    for tok in args:
        if pending is not None:
            pending = None
            continue
        if tok.startswith("-") and len(tok) > 1:
            opt = _find_option(cmd.get_params(ctx), tok.partition("=")[0])
            if opt is not None and not opt.takes_no_value and "=" not in tok:
                pending = opt
            continue
        if isinstance(cmd, Group):
            sub = cmd.get_command(ctx, tok)
            if sub is not None:
                ctx = Context(sub, info_name=tok, parent=ctx, resilient_parsing=True)
                cmd = sub
    if pending is not None:
        return _value_items(ctx, pending, incomplete)
    if incomplete.startswith("-"):
        items = []
        for p in cmd.get_params(ctx):
            if getattr(p, "hidden", False) or not hasattr(p, "all_names"):
                continue
            for name in p.all_names:
                if name.startswith(incomplete):
                    items.append(CompletionItem(name, help=p.help))
        return items
    if isinstance(cmd, Group):
        items = []
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            items.append(CompletionItem(name, help=sub.get_short_help_str()))
        return items
    for p in cmd.params:
        if p.is_argument:
            return _value_items(ctx, p, incomplete)
    return []


def format_items(items):
    lines = []
    for item in items:
        line = f"{item.type},{item.value}"
        if item.help:
            line += "\t" + " ".join(str(item.help).split())
        lines.append(line)
    return lines


def run_completion(cli, prog_name, instruction):
    """Handle a completion instruction. Returns False for an unknown instruction."""
    shell, _, mode = instruction.rpartition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        return False
    if mode == "source":
        sys.stdout.write(source_script(shell, prog_name))
        sys.stdout.flush()
        return True
    args, incomplete = _read_words(shell)
    items = complete_words(cli, prog_name, args, incomplete)
    for line in format_items(items):
        sys.stdout.write(line + "\n")
    sys.stdout.flush()
    return True
