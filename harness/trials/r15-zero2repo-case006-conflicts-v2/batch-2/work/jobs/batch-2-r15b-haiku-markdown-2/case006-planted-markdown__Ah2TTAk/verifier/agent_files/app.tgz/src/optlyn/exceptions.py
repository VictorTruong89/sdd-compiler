"""Exception classes used by Optlyn.

Usage failures exit with status 2, aborts and other library errors with
status 1, and an author clean stop carries its own status.
"""

import sys


class OptlynError(Exception):
    """Base class for errors that Optlyn reports to the user."""

    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def show(self, file=None):
        file = file or sys.stderr
        file.write(f"Error: {self.format_message()}\n")


class FileError(OptlynError):
    """A file could not be opened when I/O started (general error class)."""

    def __init__(self, filename, message):
        super().__init__(message)
        self.filename = filename


class UsageError(OptlynError):
    """Incorrect command line usage (exit status 2)."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self, file=None):
        file = file or sys.stderr
        lines = []
        if self.ctx is not None:
            lines.append(self.ctx.get_usage())
            hint = self.ctx.get_help_hint()
            if hint:
                lines.append(hint)
            lines.append("")
        lines.append(f"Error: {self.format_message()}")
        file.write("\n".join(lines) + "\n")


class BadParameter(UsageError):
    """A value was refused, either by conversion or by a callback."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value from any source."""

    def format_message(self):
        hint = self.param.get_error_hint(self.ctx) if self.param else None
        kind = "argument" if self.param is not None and self.param.is_argument else "option"
        if hint:
            return f"Missing {kind} {hint}."
        return self.message


class NoSuchOption(UsageError):
    """An unknown option token."""

    def __init__(self, option_name, message=None, ctx=None):
        super().__init__(message or f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example, a missing value)."""


class BadArgumentUsage(UsageError):
    """An argument was used incorrectly."""


class NoArgsIsHelpError(UsageError):
    """No arguments were given where the command shows help instead.

    The help page is printed by the command before this is raised, so
    ``show`` prints nothing further.
    """

    def show(self, file=None):
        return None


class Abort(RuntimeError):
    """The user or the author aborted the run (exit status 1)."""


class Exit(RuntimeError):
    """An author clean stop with an explicit status."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
