"""File opening helpers shared by the File type and ``open_file``."""

import io
import os
import sys
import tempfile

from .exceptions import FileError


def _is_binary(mode):
    return "b" in mode


def _is_writing(mode):
    return any(c in mode for c in "wax+")


class _NoClose:
    """Wraps a standard stream so that closing it does not close the process stream."""

    def __init__(self, stream, detach=None):
        self._stream = stream
        self._detach = detach

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def close(self):
        try:
            self._stream.flush()
        except (OSError, ValueError):
            pass
        if self._detach is not None:
            try:
                self._detach.detach()
            except (OSError, ValueError):
                pass


class _AtomicFile:
    """Writes to a sibling temporary file and replaces the target on close."""

    def __init__(self, filename, mode, encoding, errors):
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
        os.close(fd)
        self._target = filename
        if _is_binary(mode):
            self._f = open(self._tmp, mode)
        else:
            self._f = open(self._tmp, mode, encoding=encoding, errors=errors)
        self.closed = False

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __iter__(self):
        return iter(self._f)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def close(self):
        if self.closed:
            return
        self.closed = True
        self._f.close()
        os.replace(self._tmp, self._target)


class LazyFile:
    """A file that is opened on first I/O rather than at construction."""

    def __init__(self, filename, mode, encoding=None, errors="strict", atomic=False):
        self.name = filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self._closed = False

    def _open(self):
        if self._f is None:
            if self._closed:
                raise ValueError("I/O operation on closed file.")
            try:
                if self.atomic:
                    self._f = _AtomicFile(self.name, self.mode, self.encoding, self.errors)
                elif _is_binary(self.mode):
                    self._f = open(self.name, self.mode)
                else:
                    self._f = open(self.name, self.mode, encoding=self.encoding, errors=self.errors)
            except OSError as e:
                raise FileError(self.name, f"Could not open file '{self.name}': {e.strerror}") from e
        return self._f

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    @property
    def closed(self):
        return self._closed or (self._f is not None and self._f.closed)

    def close(self):
        if self._f is not None and not self._closed:
            self._f.close()
        self._closed = True


def _std_stream(filename, mode, encoding, errors):
    writing = _is_writing(mode)
    base = sys.stdout if writing else sys.stdin
    if _is_binary(mode):
        return _NoClose(getattr(base, "buffer", base))
    if encoding:
        buffer = getattr(base, "buffer", None)
        if buffer is not None:
            wrapper = io.TextIOWrapper(buffer, encoding=encoding, errors=errors or "strict")
            return _NoClose(wrapper, detach=wrapper)
    return _NoClose(base)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or a standard stream for ``-``.

    Files opened for reading (and standard streams) open immediately. Write
    mode files open immediately unless ``lazy`` is true.
    """
    if filename == "-":
        return _std_stream(filename, mode, encoding, errors)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    try:
        if atomic and _is_writing(mode):
            return _AtomicFile(filename, mode, encoding, errors)
        if _is_binary(mode):
            return open(filename, mode)
        return open(filename, mode, encoding=encoding, errors=errors)
    except OSError as e:
        raise FileError(filename, f"Could not open file '{filename}': {e.strerror}") from e
