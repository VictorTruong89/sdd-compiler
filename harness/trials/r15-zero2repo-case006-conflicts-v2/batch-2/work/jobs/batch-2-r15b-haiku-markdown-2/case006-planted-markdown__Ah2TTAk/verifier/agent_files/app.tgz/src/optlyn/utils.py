"""Application-level helpers: app directories, launching, editing and filenames."""

import os
import re
import shlex
import subprocess
import sys
import tempfile

from ._files import open_file

__all__ = ["edit", "format_filename", "get_app_dir", "launch", "open_file"]


def _unix_folder(app_name):
    return re.sub(r"\s+", "-", app_name.lower())


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user configuration directory for ``app_name``."""
    home = os.path.expanduser("~")
    if force_posix:
        return os.path.join(home, "." + _unix_folder(app_name))
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or home
        return os.path.join(base, app_name)
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(config_home, _unix_folder(app_name))


def format_filename(filename, shorten=False):
    """Return ``filename`` as printable text that always encodes as strict UTF-8."""
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    elif hasattr(filename, "__fspath__"):
        text = os.fspath(filename)
        if isinstance(text, bytes):
            text = os.fsdecode(text)
    else:
        text = str(filename)
    if shorten:
        text = os.path.basename(text)
    return text.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")


def launch(url, wait=False, locate=False):
    """Open ``url`` or a filename with the default associated application."""
    if sys.platform == "darwin":
        argv = ["open"]
        if locate:
            argv.append("-R")
        argv.append(url)
    elif sys.platform.startswith("win"):
        os.startfile(url)  # noqa: S606 - platform opener is the documented behaviour
        return 0
    else:
        target = os.path.dirname(os.path.abspath(url)) if locate and os.path.exists(url) else url
        argv = ["xdg-open", target]
    try:
        proc = subprocess.Popen(argv)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor. Returns the saved text, or ``None`` when nothing was saved."""
    if editor is None:
        default = "notepad" if sys.platform.startswith("win") else "vi"
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR") or default
    run_env = dict(os.environ)
    run_env.update(env or {})
    argv = shlex.split(editor)

    if filename is not None:
        subprocess.call(argv + [os.fspath(filename)], env=run_env)
        return None

    fd, path = tempfile.mkstemp(prefix="optlyn-edit-", suffix=extension)
    original = (text or "").encode("utf-8")
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(original)
        subprocess.call(argv + [path], env=run_env)
        with open(path, "rb") as handle:
            content = handle.read()
    finally:
        os.remove(path)
    if require_save and content == original:
        return None
    return content.decode("utf-8", "replace").replace("\r\n", "\n")
