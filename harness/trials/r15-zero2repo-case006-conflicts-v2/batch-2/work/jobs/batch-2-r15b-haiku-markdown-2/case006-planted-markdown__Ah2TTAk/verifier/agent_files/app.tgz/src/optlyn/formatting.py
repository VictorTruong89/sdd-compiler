"""Text wrapping helpers used by help pages and by ``wrap_text``."""

import re
import shutil
import textwrap

_PARAGRAPH_SPLIT = re.compile(r"\n\s*\n")


def wrap_text(text, width=100, initial_indent="", subsequent_indent="", preserve_paragraphs=False):
    """Rewrap ``text`` to ``width`` columns.

    Paragraphs are separated by blank lines. Single newlines inside a
    paragraph are not kept as hard breaks. A paragraph whose first line is
    only a backspace character is not rewrapped: its line breaks are kept
    and the backspace line itself is dropped.
    """
    if not text:
        return ""
    wrapper = textwrap.TextWrapper(
        width,
        initial_indent=initial_indent,
        subsequent_indent=subsequent_indent,
        replace_whitespace=False,
        break_long_words=True,
        break_on_hyphens=False,
    )
    out = []
    for paragraph in _PARAGRAPH_SPLIT.split(text.strip("\n")):
        lines = paragraph.split("\n")
        if lines and lines[0] == "\b":
            out.append("\n".join(initial_indent + line for line in lines[1:]))
            continue
        words = " ".join(line.strip() for line in lines).split()
        out.append(wrapper.fill(" ".join(words)))
    return "\n\n".join(out)


def get_default_width(max_content_width=80, terminal_width=None):
    """Return the wrap width for help pages.

    An explicit terminal width is used as-is. Otherwise the detected
    terminal width (minus a margin) is capped by ``max_content_width``.
    """
    if terminal_width is not None:
        return terminal_width
    cols = shutil.get_terminal_size((80, 24)).columns
    return max(min(cols - 2, max_content_width), 20)


def ellipsize(text, width):
    if len(text) <= width:
        return text
    if width <= 3:
        return text[:width]
    return text[: width - 3].rstrip() + "..."
