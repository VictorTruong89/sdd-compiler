"""Command model: invocation contexts, parameters, commands and groups."""

import enum
import os
import re
import sys
from collections import OrderedDict

from ._globals import pop_context, push_context
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingParameter,
    NoArgsIsHelpError,
    NoSuchOption,
    UsageError,
)
from .formatting import ellipsize, get_default_width, wrap_text
from .parameter_types import BOOL, INT, Tuple, convert_type
from .termui import confirm, echo, prompt

_MISSING = object()
_FLAG = object()
_CHAIN = object()
_PROMPT = object()
_UNSET = object()

_TRUE_VALUES = {"true", "1", "yes", "on", "t", "y"}
_FALSE_VALUES = {"false", "0", "no", "off", "f", "n"}
_NEG_NUMBER = re.compile(r"-\d+(\.\d+)?$")


class ParameterSource(enum.Enum):
    """Where a parameter's value came from."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


_SOURCE_RANK = {
    ParameterSource.PROMPT: 5,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.ENVIRONMENT: 3,
    ParameterSource.DEFAULT_MAP: 2,
    ParameterSource.DEFAULT: 1,
}


class _Literal(str):
    """A token that followed ``--`` and therefore may never be an option."""


def _is_flag_decl(decl):
    return bool(decl) and not decl[0].isalnum() and decl[0] != "_"


def _is_long(name):
    return len(name) > 2 and (name[1] == name[0] or name[0] != "-")


def _auto_env_name(prefix, dest):
    return f"{prefix}_{dest}".replace("-", "_").upper()


def _normalizer(ctx):
    func = getattr(ctx, "token_normalize_func", None)
    return func if func is not None else (lambda s: s)


class Context:
    """The state for one invocation of a command."""

    def __init__(
        self,
        command,
        parent=None,
        info_name=None,
        obj=None,
        default_map=None,
        terminal_width=None,
        max_content_width=None,
        help_option_names=None,
        token_normalize_func=None,
        color=None,
        show_default=None,
        allow_extra_args=None,
        allow_interspersed_args=None,
        ignore_unknown_options=None,
        auto_envvar_prefix=None,
        resilient_parsing=False,
    ):
        self.parent = parent
        self.command = command
        self.info_name = info_name
        self._obj = obj
        if default_map is None and parent is not None and info_name is not None:
            if isinstance(parent.default_map, dict):
                child = parent.default_map.get(info_name)
                default_map = child if isinstance(child, dict) else None
        self.default_map = default_map

        def inherit(value, name, fallback):
            if value is not None:
                return value
            if parent is not None:
                return getattr(parent, name)
            return fallback

        self.terminal_width = inherit(terminal_width, "terminal_width", None)
        self.max_content_width = inherit(max_content_width, "max_content_width", 80)
        self.help_option_names = list(inherit(help_option_names, "help_option_names", ["--help"]))
        self.token_normalize_func = inherit(token_normalize_func, "token_normalize_func", None)
        self.color = inherit(color, "color", None)
        self.show_default = inherit(show_default, "show_default", False)
        self.ignore_unknown_options = inherit(ignore_unknown_options, "ignore_unknown_options", False)
        self.allow_extra_args = (
            allow_extra_args if allow_extra_args is not None else command.allow_extra_args
        )
        self.allow_interspersed_args = (
            allow_interspersed_args
            if allow_interspersed_args is not None
            else command.allow_interspersed_args
        )
        if auto_envvar_prefix is None and parent is not None and parent.auto_envvar_prefix:
            auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{info_name}"
        self.auto_envvar_prefix = auto_envvar_prefix
        self.resilient_parsing = resilient_parsing or (parent.resilient_parsing if parent else False)

        self.params = {}
        self.protected_args = []
        self.args = []
        self.invoked_subcommand = None
        self._sources = {}
        self._close_callbacks = []

    @property
    def obj(self):
        if self._obj is None and self.parent is not None:
            return self.parent.obj
        return self._obj

    @obj.setter
    def obj(self, value):
        self._obj = value

    @property
    def command_path(self):
        rv = self.info_name or ""
        if self.parent is not None:
            parent_path = self.parent.command_path
            if parent_path:
                rv = f"{parent_path} {rv}" if rv else parent_path
        return rv

    def get_usage(self):
        pieces = self.command.get_usage_pieces(self)
        return " ".join(["Usage:", self.command_path, *pieces])

    def get_help_hint(self):
        if self.command.add_help_option and self.help_option_names:
            return f"Try '{self.command_path} {self.help_option_names[0]}' for help."
        return None

    def get_help(self):
        return self.command.get_help(self)

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if node._obj is not None and isinstance(node._obj, object_type):
                return node._obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    def lookup_default(self, name):
        if isinstance(self.default_map, dict) and name in self.default_map:
            return self.default_map[name]
        return _MISSING

    def get_parameter_source(self, name):
        declared = {p.name for p in self.command.get_params(self)}
        if name not in declared:
            return None
        return self._sources.get(name)

    def call_on_close(self, func):
        self._close_callbacks.append(func)

    def close(self):
        callbacks, self._close_callbacks = self._close_callbacks, []
        for func in reversed(callbacks):
            func()

    def with_resource(self, cm):
        value = cm.__enter__()
        self.call_on_close(lambda: cm.__exit__(None, None, None))
        return value

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def invoke(self, callback, *args, **kwargs):
        """Run ``callback`` (a command or a function) with exactly ``kwargs``."""
        if isinstance(callback, Command):
            cmd = callback
            ctx = Context(cmd, info_name=cmd.name, parent=self)
            for p in cmd.params:
                if p.expose_value and p.name not in kwargs:
                    kwargs[p.name] = p.get_default_value()
            with ctx:
                try:
                    if cmd.callback is None:
                        return None
                    return cmd.callback(*args, **kwargs)
                finally:
                    ctx.close()
        with self:
            return callback(*args, **kwargs)

    def forward(self, cmd, *args, **kwargs):
        merged = dict(self.params)
        merged.update(kwargs)
        return self.invoke(cmd, *args, **merged)

    def __enter__(self):
        push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        pop_context()


class Parameter:
    """Shared behaviour of options and arguments."""

    is_argument = False
    is_eager = False

    def __init__(
        self,
        name,
        opts=(),
        type=None,
        default=None,
        required=False,
        callback=None,
        nargs=1,
        multiple=False,
        metavar=None,
        expose_value=True,
        is_eager=False,
        envvar=None,
        shell_complete=None,
        deprecated=False,
        help=None,
        hidden=False,
        show_default=None,
        show_envvar=False,
        allow_from_autoenv=True,
    ):
        self.name = name
        self.opts = list(opts)
        self.type = convert_type(type, default)
        self.default = default
        self.required = bool(required)
        self.callback = callback
        self.nargs = nargs
        self.multiple = bool(multiple)
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = bool(is_eager)
        self.envvar = [envvar] if isinstance(envvar, str) else list(envvar or [])
        self.shell_complete = shell_complete
        self.deprecated = deprecated
        self.help = help
        self.hidden = hidden
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.allow_from_autoenv = allow_from_autoenv
        self.decl_index = 0

    @property
    def _tuple_type(self):
        return isinstance(self.type, Tuple)

    @property
    def _scalar(self):
        return not self.multiple and self.nargs == 1 and not self._tuple_type

    def process_value(self, ctx, value):
        if self.callback is not None:
            return self.callback(ctx, self, value)
        return value

    def get_error_hint(self, ctx=None):
        return f"'{self.name.upper()}'"

    def _default_value(self):
        return self.default() if callable(self.default) else self.default

    def _empty(self):
        return None

    def get_default_value(self):
        if self.default is None:
            return self._empty()
        return self._default_value()

    def _warn_deprecated(self, kind, note_source):
        note = self.deprecated if isinstance(self.deprecated, str) else ""
        message = f"DeprecationWarning: The {kind} '{self.name}' is deprecated."
        if note:
            message += f" {note}"
        echo(message, err=True)

    def _split(self, raw):
        sep = getattr(self.type, "envvar_list_splitter", None)
        if sep:
            return [part for part in raw.split(sep) if part]
        return raw.split()

    def _chunk(self, ctx, tokens):
        if self._tuple_type:
            return self.type.convert(tuple(tokens), self, ctx)
        if self.nargs == 1:
            return self.type.convert(tokens[0], self, ctx)
        if len(tokens) != self.nargs:
            raise BadParameter(f"Takes {self.nargs} values but {len(tokens)} were given.", ctx, self)
        return tuple(self.type.convert(t, self, ctx) for t in tokens)

    def _from_items(self, ctx, items):
        if self.multiple:
            if self.nargs == 1 and not self._tuple_type:
                return tuple(self.type.convert(i, self, ctx) for i in items)
            n = len(self.type.types) if self._tuple_type else self.nargs
            if len(items) % n:
                raise BadParameter(f"Takes {n} values per occurrence.", ctx, self)
            return tuple(self._chunk(ctx, items[k : k + n]) for k in range(0, len(items), n))
        return self._chunk(ctx, items)

    def _convert_raw(self, ctx, raw):
        """Convert a default-map or declared default value."""
        if self._scalar:
            return self.type.convert(raw, self, ctx)
        if isinstance(raw, str):
            if self.multiple and self.nargs == 1 and not self._tuple_type:
                raise BadParameter("Needs an iterable (sequence) default, not a string.", ctx, self)
            return self._from_items(ctx, self._split(raw))
        if not isinstance(raw, (list, tuple)):
            raise BadParameter("Needs an iterable (sequence) default.", ctx, self)
        if self.multiple:
            out = []
            for item in raw:
                if self.nargs == 1 and not self._tuple_type:
                    out.append(self.type.convert(item, self, ctx))
                else:
                    out.append(self._chunk(ctx, list(item)))
            return tuple(out)
        return self._chunk(ctx, list(raw))

    def _convert_env(self, ctx, raw):
        if self._scalar:
            return self.type.convert(raw, self, ctx)
        return self._from_items(ctx, self._split(raw))


class Option(Parameter):
    """A named parameter introduced by a prefix character."""

    def __init__(
        self,
        param_decls,
        type=None,
        default=None,
        required=False,
        is_flag=None,
        flag_value=None,
        count=False,
        multiple=False,
        nargs=None,
        envvar=None,
        allow_from_autoenv=True,
        prompt=None,
        prompt_required=True,
        hide_input=False,
        confirmation_prompt=False,
        callback=None,
        is_eager=False,
        expose_value=True,
        hidden=False,
        deprecated=False,
        help=None,
        metavar=None,
        show_default=None,
        show_envvar=False,
        shell_complete=None,
    ):
        opts, secondary, dest = [], [], None
        for decl in param_decls:
            if _is_flag_decl(decl):
                idx = decl.find("/", 1)
                if idx > 0:
                    opts.append(decl[:idx])
                    secondary.append(decl[idx + 1 :])
                else:
                    opts.append(decl)
            elif decl:
                dest = decl
        if not opts:
            raise TypeError("An option needs at least one flag name.")
        if dest is None:
            first = next((o for o in opts if _is_long(o)), opts[0])
            dest = re.sub(r"^[^A-Za-z0-9]+", "", first).replace("-", "_")
        self.secondary_opts = secondary
        pair = bool(secondary)
        if is_flag is None:
            is_flag = pair or (isinstance(default, bool) and flag_value is None)
        if count:
            is_flag = False
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self.takes_no_value = self.is_flag or self.count
        if self.is_flag and nargs not in (None, 1):
            raise TypeError("A flag takes exactly one value.")
        if self.count:
            if type is None:
                type = INT
            if default is None:
                default = 0
        elif self.is_flag and type is None:
            type = BOOL
        if self.is_flag:
            self.on_value = True if flag_value is None else flag_value
            self.off_value = False
            self.optional_value = False
        else:
            self.on_value = flag_value
            self.off_value = None
            self.optional_value = flag_value is not None
        if deprecated and required:
            raise TypeError("A deprecated option cannot be required.")
        if deprecated and prompt:
            raise TypeError("A deprecated option cannot use a prompt.")
        converted = convert_type(type, default)
        if isinstance(converted, Tuple):
            nargs = len(converted.types)
        nargs = 1 if nargs is None else nargs
        if not isinstance(nargs, int) or nargs < 1:
            raise TypeError("nargs must be a positive integer.")
        if self.takes_no_value:
            nargs = 1
        super().__init__(
            dest,
            opts=opts,
            type=converted,
            default=default,
            required=required,
            callback=callback,
            nargs=nargs,
            multiple=multiple,
            metavar=metavar,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=envvar,
            shell_complete=shell_complete,
            deprecated=deprecated,
            help=help,
            hidden=hidden,
            show_default=show_default,
            show_envvar=show_envvar,
            allow_from_autoenv=allow_from_autoenv,
        )
        self.prompt = None
        if prompt is not None and prompt is not False:
            self.prompt = prompt if isinstance(prompt, str) else True
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt

    @property
    def all_names(self):
        return self.opts + self.secondary_opts

    def get_error_hint(self, ctx=None):
        return " / ".join(f"'{o}'" for o in self.opts)

    def _empty(self):
        if self.count:
            return 0
        if self.is_flag:
            return False
        if self.multiple:
            return ()
        return None

    def get_default_value(self):
        if self.default is None:
            if self.is_flag:
                return False
            return self._empty()
        return self._default_value()

    def make_metavar(self):
        if self.takes_no_value:
            return None
        if self.metavar is not None:
            text = self.metavar
        else:
            text = self.type.get_metavar(self) or self.type.name.upper()
            if self.nargs > 1 and not self._tuple_type:
                text = " ".join([text] * self.nargs)
        if self.optional_value:
            return f"[{text}]"
        return text

    def _env_names(self, ctx):
        names = list(self.envvar)
        if self.allow_from_autoenv and ctx.auto_envvar_prefix:
            names.append(_auto_env_name(ctx.auto_envvar_prefix, self.name))
        return names

    def _parse_env_flag(self, raw):
        text = raw.strip().lower()
        fv = self.on_value
        if not isinstance(fv, bool) and text == str(fv).lower():
            return fv
        if text in _TRUE_VALUES:
            return fv if isinstance(fv, bool) else fv
        if text in _FALSE_VALUES or text == "":
            return False if isinstance(fv, bool) else _UNSET
        if not isinstance(fv, bool):
            return _UNSET
        raise BadParameter(f"{raw!r} is not a valid boolean.", None, self)

    def _prompt_value(self, ctx):
        dm = ctx.lookup_default(self.name)
        if dm is not _MISSING:
            default = dm
        else:
            default = self._default_value() if self.default is not None else None
        text = self.prompt if isinstance(self.prompt, str) else self.name.replace("_", " ").capitalize()
        if self.is_flag:
            return confirm(text, default=bool(default))
        value = prompt(
            text,
            default=default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            type=self.type,
        )
        if self.multiple:
            return (value,)
        return value

    def _occurrence_value(self, ctx, kind, payload):
        if kind == "flag":
            return payload
        if kind == "optional":
            return self.on_value if payload is _FLAG else self.type.convert(payload, self, ctx)
        return self._chunk(ctx, payload)

    def _from_occurrences(self, ctx, occs):
        if self.count:
            return len(occs)
        if self.is_flag and not self.multiple:
            return occs[-1][1]
        values = [self._occurrence_value(ctx, kind, payload) for kind, payload, _ in occs]
        if self.multiple:
            return tuple(values)
        return values[-1]

    def resolve(self, ctx, occs):
        """Return ``(value, source, explicit)`` or ``None`` when no source supplies one."""
        if occs:
            if self.deprecated:
                self._warn_deprecated("option", "commandline")
            if any(kind == "prompt" for kind, _, _ in occs):
                return (self._prompt_value(ctx), ParameterSource.PROMPT, True)
            return (self._from_occurrences(ctx, occs), ParameterSource.COMMANDLINE, True)
        for name in self._env_names(ctx):
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            if self.is_flag:
                value = self._parse_env_flag(raw)
                if value is _UNSET:
                    continue
                return (value, ParameterSource.ENVIRONMENT, True)
            return (self._convert_env(ctx, raw), ParameterSource.ENVIRONMENT, True)
        if self.prompt is not None and self.prompt_required:
            return (self._prompt_value(ctx), ParameterSource.PROMPT, True)
        dm = ctx.lookup_default(self.name)
        if dm is not _MISSING:
            return (self._convert_raw(ctx, dm), ParameterSource.DEFAULT_MAP, True)
        if self.default is not None:
            return (self._convert_raw(ctx, self._default_value()), ParameterSource.DEFAULT, True)
        if self.required:
            return None
        return (self._empty(), ParameterSource.DEFAULT, False)


class Argument(Parameter):
    """A positional parameter."""

    is_argument = True

    def __init__(
        self,
        param_decls,
        type=None,
        default=None,
        required=None,
        nargs=None,
        envvar=None,
        deprecated=False,
        help=None,
        metavar=None,
        callback=None,
        expose_value=True,
        hidden=False,
        shell_complete=None,
    ):
        names = [d for d in param_decls if d and not _is_flag_decl(d)]
        if len(names) != 1:
            raise TypeError("An argument takes exactly one destination name.")
        name = names[0]
        converted = convert_type(type, default)
        if isinstance(converted, Tuple):
            nargs = len(converted.types) if nargs is None else nargs
        nargs = 1 if nargs is None else nargs
        if nargs == 0 or nargs < -1:
            raise TypeError("nargs must be a positive integer or -1.")
        if required is None:
            required = default is None and nargs != -1
        if deprecated and required:
            raise TypeError("A deprecated argument cannot be required.")
        super().__init__(
            name,
            type=converted,
            default=default,
            required=required,
            callback=callback,
            nargs=nargs,
            metavar=metavar,
            expose_value=expose_value,
            envvar=envvar,
            shell_complete=shell_complete,
            deprecated=deprecated,
            help=help,
            hidden=hidden,
            allow_from_autoenv=False,
        )

    @property
    def variadic(self):
        return self.nargs == -1

    def get_error_hint(self, ctx=None):
        return f"'{self.name.upper()}'"

    def usage_piece(self):
        text = self.metavar or self.name.upper()
        if self.variadic:
            text += "..."
        if not self.required:
            text = f"[{text}]"
        return text

    def _empty(self):
        if self.variadic or self.nargs != 1 or self._tuple_type:
            return ()
        return None

    def _chunk_tokens(self, ctx, tokens):
        if self.variadic:
            if self._tuple_type:
                return self.type.convert(tuple(tokens), self, ctx)
            return tuple(self.type.convert(t, self, ctx) for t in tokens)
        if self.nargs == 1 and not self._tuple_type:
            return self.type.convert(tokens[0], self, ctx)
        return self._chunk(ctx, tokens)

    def resolve(self, ctx, tokens):
        if tokens:
            if self.deprecated:
                self._warn_deprecated("argument", "commandline")
            if not self.variadic and len(tokens) < self.nargs and self.required:
                raise BadArgumentUsage(
                    f"Argument '{self.name}' takes {self.nargs} values.", ctx
                )
            return (self._chunk_tokens(ctx, list(tokens)), ParameterSource.COMMANDLINE, True)
        for name in self.envvar:
            raw = os.environ.get(name)
            if raw:
                if self.nargs == 1 and not self._tuple_type and not self.variadic:
                    value = self.type.convert(raw, self, ctx)
                else:
                    value = self._from_items(ctx, self._split(raw)) if not self.variadic else tuple(
                        self.type.convert(i, self, ctx) for i in self._split(raw)
                    )
                return (value, ParameterSource.ENVIRONMENT, True)
        dm = ctx.lookup_default(self.name)
        if dm is not _MISSING:
            return (self._convert_raw(ctx, dm), ParameterSource.DEFAULT_MAP, True)
        if self.default is not None:
            return (self._convert_raw(ctx, self._default_value()), ParameterSource.DEFAULT, True)
        if self.required:
            return None
        return (self._empty(), ParameterSource.DEFAULT, False)


def _show_help(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


class Command:
    """A callable unit that parses a slice of the command line and runs a callback."""

    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False

    def __init__(
        self,
        name,
        context_settings=None,
        callback=None,
        params=None,
        help=None,
        epilog=None,
        short_help=None,
        options_metavar="[OPTIONS]",
        add_help_option=True,
        no_args_is_help=False,
        hidden=False,
        deprecated=False,
    ):
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # ----- parameters -------------------------------------------------------

    def _help_option_names_for(self, ctx):
        names = list(ctx.help_option_names)
        declared = set()
        for p in self.params:
            if isinstance(p, Option):
                declared.update(p.all_names)
        return [n for n in names if n not in declared]

    def get_params(self, ctx):
        params = list(self.params)
        if self.add_help_option:
            names = self._help_option_names_for(ctx)
            if names:
                params.append(
                    Option(
                        names,
                        is_flag=True,
                        is_eager=True,
                        expose_value=False,
                        callback=_show_help,
                        help="Show this message and exit.",
                    )
                )
        return params

    def _arguments(self):
        return [p for p in self.params if p.is_argument]

    # ----- help -------------------------------------------------------------

    def _help_text(self):
        text = self.help or ""
        if "\f" in text:
            text = text.split("\f", 1)[0]
        return text.strip("\n")

    def get_short_help_str(self, limit=None):
        if self.short_help is not None:
            return self.short_help
        text = self._help_text().strip()
        if not text:
            return ""
        match = re.match(r"(.*?[.!?])(\s|$)", " ".join(text.split()))
        short = match.group(1) if match else " ".join(text.split())
        if limit is not None:
            short = ellipsize(short, limit)
        return short

    def get_usage_pieces(self, ctx):
        pieces = []
        if any(isinstance(p, Option) for p in self.get_params(ctx)):
            pieces.append(self.options_metavar)
        for arg in self._arguments():
            pieces.append(arg.usage_piece())
        return pieces

    def get_help(self, ctx):
        width = get_default_width(ctx.max_content_width, ctx.terminal_width)
        lines = []
        pieces = self.get_usage_pieces(ctx)
        lines.append("Usage: " + " ".join([ctx.command_path, *pieces]).rstrip())
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            lines.append("")
            lines.append(wrap_text("(Deprecated) This command is deprecated." + (f" {note}" if note else ""), width))
        text = self._help_text()
        if text:
            lines.append("")
            lines.append(wrap_text(text, width))
        args = [a for a in self._arguments() if a.help and not a.hidden]
        if args:
            lines.append("")
            lines.append("Positional arguments:")
            rows = [(a.metavar or a.name.upper(), a.help) for a in args]
            lines.extend(self._format_rows(rows, width))
        opts = [p for p in self.get_params(ctx) if isinstance(p, Option) and not p.hidden]
        if opts:
            lines.append("")
            lines.append("Options:")
            rows = [self._option_row(ctx, p) for p in opts]
            lines.extend(self._format_rows(rows, width))
        if isinstance(self, Group):
            rows = []
            for name in self.list_commands(ctx):
                sub = self.get_command(ctx, name)
                if sub is None or sub.hidden:
                    continue
                rows.append((name, sub.get_short_help_str(limit=max(width - 30, 20))))
            if rows:
                lines.append("")
                lines.append("Commands:")
                lines.extend(self._format_rows(rows, width))
        if self.epilog:
            lines.append("")
            lines.append(wrap_text(self.epilog, width))
        return "\n".join(lines) + "\n"

    def _option_row(self, ctx, p):
        first = ", ".join(p.opts)
        if p.secondary_opts:
            first += " / " + ", ".join(p.secondary_opts)
        metavar = p.make_metavar()
        if metavar:
            first += " " + metavar
        extras = []
        show = p.show_default if p.show_default is not None else ctx.show_default
        if show and p.default is not None and not (p.is_flag and not p.secondary_opts and not p.default):
            if isinstance(show, str):
                extras.append(f"default: {show}")
            elif callable(p.default):
                extras.append("default: (dynamic)")
            else:
                extras.append(f"default: {p.default}")
        if p.show_envvar:
            names = p._env_names(ctx)
            if names:
                extras.append("env var: " + ", ".join(names))
        if p.deprecated:
            extras.append("DEPRECATED")
        help_text = p.help or ""
        if extras:
            help_text = (help_text + " " if help_text else "") + "[" + "; ".join(extras) + "]"
        return (first, help_text)

    @staticmethod
    def _format_rows(rows, width):
        """Lay out ``(first, help)`` rows in two columns, indented by two spaces."""
        if not rows:
            return []
        col = min(max(len(first) for first, _ in rows), 28)
        help_indent = " " * (col + 4)
        body_width = max(width - len(help_indent), 20)
        out = []
        for first, text in rows:
            if not text:
                out.append(f"  {first}")
                continue
            body = wrap_text(text, body_width).split("\n")
            if len(first) > col:
                out.append(f"  {first}")
                out.extend(help_indent + line for line in body)
            else:
                out.append(f"  {first.ljust(col)}  {body[0]}")
                out.extend(help_indent + line for line in body[1:])
        return out

    # ----- parsing ----------------------------------------------------------

    def make_context(self, info_name, args, parent=None, **extra):
        settings = dict(self.context_settings)
        settings.update(extra)
        ctx = Context(self, info_name=info_name, parent=parent, **settings)
        with ctx:
            try:
                self.parse_args(ctx, list(args))
            except BaseException:
                ctx.close()
                raise
        return ctx

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            echo(self.get_help(ctx), file=sys.stderr)
            raise NoArgsIsHelpError("No arguments given; showing help.", ctx)
        params = self.get_params(ctx)
        occs, positional = self._parse_options(ctx, args, params)
        arg_tokens, leftover = self._bind_arguments(params, positional)
        self._finish_leftover(ctx, leftover)
        self._process_params(ctx, params, occs, arg_tokens)

    def _finish_leftover(self, ctx, leftover):
        if leftover and not ctx.resilient_parsing:
            if not ctx.allow_extra_args:
                plural = "s" if len(leftover) > 1 else ""
                raise UsageError(
                    f"Got unexpected extra argument{plural} ({', '.join(leftover)})", ctx
                )
            in_chain = ctx.parent is not None and ctx.parent.command.chain
            if not ctx.ignore_unknown_options and not in_chain:
                for tok in leftover:
                    if not isinstance(tok, _Literal) and self._option_shaped(ctx, tok):
                        raise NoSuchOption(tok, ctx=ctx)
        ctx.args = list(leftover)

    def _option_shaped(self, ctx, tok):
        return len(tok) > 1 and tok[0] in self._prefix_chars and not _NEG_NUMBER.match(tok)

    @property
    def _prefix_chars(self):
        chars = {"-"}
        for p in self.params:
            if isinstance(p, Option):
                for name in p.all_names:
                    chars.add(name[0])
        return chars

    def _option_maps(self, ctx, params):
        norm = _normalizer(ctx)
        long_map, short_map = {}, {}
        for p in params:
            if not isinstance(p, Option):
                continue
            for name in p.opts:
                target = long_map if _is_long(name) else short_map
                target[norm(name)] = (p, True)
            for name in p.secondary_opts:
                target = long_map if _is_long(name) else short_map
                target[norm(name)] = (p, False)
        return long_map, short_map

    def _parse_options(self, ctx, args, params):
        long_map, short_map = self._option_maps(ctx, params)
        norm = _normalizer(ctx)
        prefixes = {"-"}
        for key in list(long_map) + list(short_map):
            prefixes.add(key[0])
        occs, positional = [], []
        interspersed = ctx.allow_interspersed_args
        i, n, dd = 0, len(args), False

        def looks_like_option(tok):
            if len(tok) < 2 or tok[0] not in prefixes:
                return False
            if _NEG_NUMBER.match(tok) and norm(tok[:2]) not in short_map:
                return False
            return True

        def take_value(opt, first, index, name):
            """Collect the value tokens of an option that takes a value."""
            if opt.optional_value:
                if first is not None:
                    return "optional", first, index
                nxt = index + 1
                if nxt < n and not looks_like_option(args[nxt]) and args[nxt] != "--":
                    return "optional", args[nxt], nxt
                return "optional", _FLAG, index
            tokens = [] if first is None else [first]
            nxt = index
            while len(tokens) < opt.nargs and nxt + 1 < n:
                candidate = args[nxt + 1]
                if looks_like_option(candidate) or candidate == "--":
                    break
                tokens.append(candidate)
                nxt += 1
            if len(tokens) < opt.nargs:
                if opt.prompt is not None and first is None:
                    return "prompt", None, index
                if opt.nargs == 1:
                    raise BadOptionUsage(f"Option '{name}' requires an argument.", ctx)
                raise BadOptionUsage(f"Option '{name}' requires {opt.nargs} arguments.", ctx)
            return "tokens", tokens, nxt

        while i < n:
            tok = args[i]
            order = i
            if dd:
                positional.append(_Literal(tok))
                i += 1
                continue
            if tok == "--":
                dd = True
                i += 1
                continue
            if not looks_like_option(tok):
                if not interspersed:
                    positional.extend(args[i:])
                    break
                positional.append(tok)
                i += 1
                continue
            prefix = tok[0]
            if tok[:2] == prefix * 2 or _is_long(tok.partition("=")[0]):
                name, eq, value = tok.partition("=")
                entry = long_map.get(norm(name))
                if entry is None:
                    if ctx.ignore_unknown_options:
                        positional.append(tok)
                        i += 1
                        continue
                    raise NoSuchOption(name, ctx=ctx)
                opt, on = entry
                if opt.takes_no_value:
                    if eq:
                        raise BadOptionUsage(f"Option '{name}' does not take a value.", ctx)
                    occs.append((opt, "flag", (opt.on_value if on else opt.off_value), order))
                    i += 1
                    continue
                kind, payload, last = take_value(opt, value if eq else None, i, name)
                occs.append((opt, kind, payload, order))
                i = last + 1
                continue
            # A stack of single-character flags, possibly ending in a value.
            chars = tok[1:]
            j = 0
            consumed_to = i
            while j < len(chars):
                key = norm(prefix + chars[j])
                entry = short_map.get(key)
                if entry is None:
                    if ctx.ignore_unknown_options:
                        positional.append(prefix + chars[j:])
                        break
                    raise NoSuchOption(prefix + chars[j], ctx=ctx)
                opt, on = entry
                if opt.takes_no_value:
                    occs.append((opt, "flag", (opt.on_value if on else opt.off_value), order))
                    j += 1
                    continue
                rest = chars[j + 1 :]
                first = rest if rest else None
                kind, payload, last = take_value(opt, first, i, prefix + chars[j])
                occs.append((opt, kind, payload, order))
                consumed_to = last
                break
            i = consumed_to + 1
        return occs, positional

    def _bind_arguments(self, params, tokens):
        args = [p for p in params if p.is_argument]
        raw = {}
        remaining = list(tokens)
        for idx, arg in enumerate(args):
            if arg.variadic:
                later = sum(a.nargs for a in args[idx + 1 :] if a.nargs > 0 and a.required)
                take = max(len(remaining) - later, 0)
            else:
                take = min(arg.nargs, len(remaining))
            raw[id(arg)] = remaining[:take]
            remaining = remaining[take:]
        return raw, remaining

    def _process_params(self, ctx, params, occs, arg_tokens):
        occ_map = {}
        for opt, kind, payload, order in occs:
            occ_map.setdefault(id(opt), []).append((kind, payload, order))
        eager_done = set()
        eager = [p for p in params if p.is_eager and id(p) in occ_map]
        eager.sort(key=lambda p: min(o for _, _, o in occ_map[id(p)]))
        for p in eager:
            resolved = p.resolve(ctx, occ_map[id(p)])
            value = p.process_value(ctx, resolved[0])
            if p.expose_value:
                ctx.params[p.name] = value
                ctx._sources[p.name] = resolved[1]
            eager_done.add(id(p))

        groups = OrderedDict()
        for idx, p in enumerate(params):
            p.decl_index = idx
            key = p.name if p.expose_value else id(p)
            groups.setdefault(key, []).append(p)

        for key, plist in groups.items():
            if all(id(p) in eager_done for p in plist):
                continue
            candidates = []
            for p in plist:
                if id(p) in eager_done:
                    continue
                if p.is_argument:
                    resolved = p.resolve(ctx, arg_tokens.get(id(p), []))
                else:
                    resolved = p.resolve(ctx, occ_map.get(id(p), []))
                if resolved is not None:
                    value, source, explicit = resolved
                    rank = (_SOURCE_RANK[source], explicit, p.decl_index)
                    candidates.append((rank, p, value, source))
            if candidates:
                _, winner, value, source = max(candidates, key=lambda c: c[0])
            else:
                required = next(p for p in plist if p.required)
                raise MissingParameter(
                    f"Missing {'argument' if required.is_argument else 'option'} {required.get_error_hint(ctx)}.",
                    ctx=ctx,
                    param=required,
                )
            value = winner.process_value(ctx, value)
            if winner.expose_value:
                ctx.params[winner.name] = value
                ctx._sources[winner.name] = source

    # ----- invocation -------------------------------------------------------

    def invoke(self, ctx):
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            message = f"DeprecationWarning: The command '{self.name}' is deprecated."
            echo((message + (f" {note}" if note else "")), err=True)
        try:
            with ctx:
                if self.callback is None:
                    return None
                kwargs = {p.name: ctx.params.get(p.name) for p in self.params if p.expose_value}
                return self.callback(**kwargs)
        finally:
            ctx.close()

    def main(
        self,
        args=None,
        prog_name=None,
        complete_var=None,
        standalone_mode=True,
        **extra,
    ):
        """Run the command as a program."""
        from .shell_completion import run_completion

        if args is None:
            args = sys.argv[1:]
        else:
            args = list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else (self.name or "root")
        if complete_var is None:
            complete_var = "_" + prog_name.replace("-", "_").upper() + "_COMPLETE"
        instruction = os.environ.get(complete_var)
        if instruction:
            handled = run_completion(self, prog_name, instruction)
            if standalone_mode:
                sys.exit(0 if handled else 1)
            return None

        try:
            try:
                ctx = self.make_context(prog_name, args, **extra)
                rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                sys.exit(0)
            except (EOFError, KeyboardInterrupt) as e:
                echo(file=sys.stderr)
                raise Abort() from e
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", file=sys.stderr)
            sys.exit(1)
        except UsageError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)
        except Exception as e:
            from .exceptions import OptlynError

            if isinstance(e, OptlynError) and standalone_mode:
                e.show()
                sys.exit(e.exit_code)
            raise


class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_interspersed_args = False

    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        **kwargs,
    ):
        super().__init__(name, **kwargs)
        self.commands = OrderedDict()
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_cb = result_callback
        for cmd in commands or []:
            self.add_command(cmd)

    def add_command(self, cmd, name=None):
        name = name or cmd.name
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Groups cannot be nested under a chaining group.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as command_decorator

        def decorator(f):
            cmd = command_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as group_decorator

        def decorator(f):
            cmd = group_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(f):
            self._result_cb = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def _resolve_command(self, ctx, name):
        cmd = self.get_command(ctx, name)
        if cmd is not None:
            return name, cmd
        if ctx.token_normalize_func is not None:
            wanted = ctx.token_normalize_func(name)
            for candidate in self.list_commands(ctx):
                if ctx.token_normalize_func(candidate) == wanted:
                    cmd = self.get_command(ctx, candidate)
                    if cmd is not None:
                        return candidate, cmd
        raise UsageError(f"No such command '{name}'.", ctx)

    def _finish_leftover(self, ctx, leftover):
        if self.chain:
            ctx.protected_args = []
            ctx.args = list(leftover)
        else:
            ctx.protected_args = list(leftover[:1])
            ctx.args = list(leftover[1:])

    def get_usage_pieces(self, ctx):
        pieces = super().get_usage_pieces(ctx)
        metavar = self.subcommand_metavar or "COMMAND"
        if self.chain:
            pieces.append(f"{metavar} [ARGS]... [{metavar} [ARGS]...]...")
        elif self.invoke_without_command:
            pieces.append(f"[{metavar}] [ARGS]...")
        else:
            pieces.append(f"{metavar} [ARGS]...")
        return pieces

    def parse_args(self, ctx, args):
        super().parse_args(ctx, args)
        if not self.chain and not ctx.protected_args and not self.invoke_without_command:
            raise UsageError("Missing command.", ctx)
        if self.chain and not ctx.args and not self.invoke_without_command:
            raise UsageError("Missing command.", ctx)

    def _run_callback(self, ctx):
        if self.callback is None:
            return None
        kwargs = {p.name: ctx.params.get(p.name) for p in self.params if p.expose_value}
        return self.callback(**kwargs)

    def _group_kwargs(self, ctx):
        return {p.name: ctx.params.get(p.name) for p in self.params if p.expose_value}

    def invoke(self, ctx):
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            message = f"DeprecationWarning: The command '{self.name}' is deprecated."
            echo((message + (f" {note}" if note else "")), err=True)
        try:
            with ctx:
                if self.chain:
                    return self._invoke_chain(ctx)
                return self._invoke_single(ctx)
        finally:
            ctx.close()

    def _invoke_single(self, ctx):
        rest = list(ctx.protected_args) + list(ctx.args)
        if not rest:
            ctx.invoked_subcommand = None
            rv = self._run_callback(ctx)
            if self._result_cb is not None:
                return self._result_cb(rv, **self._group_kwargs(ctx))
            return rv
        name, cmd = self._resolve_command(ctx, rest[0])
        ctx.invoked_subcommand = name
        self._run_callback(ctx)
        sub_ctx = cmd.make_context(name, rest[1:], parent=ctx)
        rv = cmd.invoke(sub_ctx)
        if self._result_cb is not None:
            return self._result_cb(rv, **self._group_kwargs(ctx))
        return rv

    def _invoke_chain(self, ctx):
        rest = list(ctx.protected_args) + list(ctx.args)
        ctx.invoked_subcommand = _CHAIN
        self._run_callback(ctx)
        results = []
        while rest:
            name, cmd = self._resolve_command(ctx, rest[0])
            sub_ctx = cmd.make_context(
                name,
                rest[1:],
                parent=ctx,
                allow_extra_args=True,
                allow_interspersed_args=False,
            )
            rest = list(sub_ctx.args)
            results.append(cmd.invoke(sub_ctx))
        if self._result_cb is not None:
            return self._result_cb(results, **self._group_kwargs(ctx))
        return results


class CommandCollection(Group):
    """A group whose subcommands are the union of several source groups."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


__all__ = [
    "Abort",
    "Argument",
    "Command",
    "CommandCollection",
    "Context",
    "Group",
    "Option",
    "Parameter",
    "ParameterSource",
]
