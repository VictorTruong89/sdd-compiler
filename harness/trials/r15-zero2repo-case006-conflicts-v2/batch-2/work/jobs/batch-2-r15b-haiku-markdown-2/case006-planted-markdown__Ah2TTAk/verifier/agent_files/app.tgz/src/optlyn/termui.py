"""Terminal input and output helpers."""

import contextlib
import os
import re
import subprocess
import sys
import time

from ._globals import get_current_context
from .exceptions import Abort, BadParameter

_ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")

_COLORS = {
    "black": 0,
    "red": 1,
    "green": 2,
    "yellow": 3,
    "blue": 4,
    "magenta": 5,
    "cyan": 6,
    "white": 7,
    "reset": 9,
    "bright_black": 60,
    "bright_red": 61,
    "bright_green": 62,
    "bright_yellow": 63,
    "bright_blue": 64,
    "bright_magenta": 65,
    "bright_cyan": 66,
    "bright_white": 67,
}

_SWITCHES = [
    ("bold", 1, 22),
    ("dim", 2, 22),
    ("italic", 3, 23),
    ("underline", 4, 24),
    ("blink", 5, 25),
    ("reverse", 7, 27),
    ("strikethrough", 9, 29),
    ("overline", 53, 55),
]


def _color_codes(color, background):
    base = 40 if background else 30
    if isinstance(color, str):
        if color not in _COLORS:
            raise ValueError(f"Unknown color '{color}'.")
        offset = _COLORS[color]
        if color == "reset":
            return [49 if background else 39]
        if offset >= 60:
            return [base + 60 + (offset - 60)]
        return [base + offset]
    if isinstance(color, int) and not isinstance(color, bool):
        if not 0 <= color <= 255:
            raise ValueError("Color integers must be between 0 and 255.")
        return [48 if background else 38, 5, color]
    if isinstance(color, (tuple, list)) and len(color) == 3:
        if not all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color):
            raise ValueError("RGB colors must be three integers between 0 and 255.")
        return [48 if background else 38, 2, *color]
    raise ValueError(f"Invalid color {color!r}.")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
):
    """Wrap ``text`` in ANSI SGR escape sequences."""
    codes = []
    if fg is not None:
        codes.extend(_color_codes(fg, False))
    if bg is not None:
        codes.extend(_color_codes(bg, True))
    values = {
        "bold": bold,
        "dim": dim,
        "underline": underline,
        "overline": overline,
        "italic": italic,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for name, on_code, off_code in _SWITCHES:
        value = values[name]
        if value is None:
            continue
        codes.append(on_code if value else off_code)
    if not codes:
        return str(text)
    prefix = "\x1b[" + ";".join(str(c) for c in codes) + "m"
    suffix = "\x1b[0m" if reset else ""
    return f"{prefix}{text}{suffix}"


def unstyle(text):
    """Remove ANSI escape sequences from ``text``."""
    return _ANSI_RE.sub("", text)


def _strip_for(stream, color):
    if color is None:
        ctx = get_current_context(silent=True)
        color = ctx.color if ctx is not None else None
    if color is True:
        return False
    if color is False:
        return True
    return not _isatty(stream)


def _isatty(stream):
    try:
        return bool(stream is not None and stream.isatty())
    except (AttributeError, ValueError):
        return False


def _write_text(stream, text):
    try:
        stream.write(text)
    except UnicodeEncodeError:
        buffer = getattr(stream, "buffer", None)
        if buffer is None:
            raise
        stream.flush()
        buffer.write(text.encode("utf-8"))
        buffer.flush()
        return
    stream.flush()


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write ``message`` (text or bytes) to standard output or standard error."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, (bytes, bytearray)):
        buffer = getattr(file, "buffer", None)
        if buffer is not None:
            file.flush()
            buffer.write(bytes(message))
            if nl:
                buffer.write(b"\n")
            buffer.flush()
        else:
            file.write(bytes(message).decode("utf-8", "replace") + ("\n" if nl else ""))
            file.flush()
        return
    text = str(message)
    if _strip_for(file, color):
        text = unstyle(text)
    if nl:
        text += "\n"
    _write_text(file, text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    """Echo ``message`` after applying :func:`style` with ``styles``."""
    if message is not None:
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def _is_interactive():
    return _isatty(sys.stdin) or _isatty(sys.stdout)


def _read_line(hide_input=False, err=False):
    """Read one line from standard input; EOF aborts."""
    stream = sys.stdin
    old = None
    fd = None
    if hide_input and _isatty(stream):
        try:
            import termios

            fd = stream.fileno()
            old = termios.tcgetattr(fd)
            new = termios.tcgetattr(fd)
            new[3] &= ~termios.ECHO
            termios.tcsetattr(fd, termios.TCSADRAIN, new)
        except (ImportError, OSError, ValueError, AttributeError):
            fd = None
    try:
        line = stream.readline()
    finally:
        if fd is not None and old is not None:
            import termios

            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.write("\n")
    if line == "":
        raise Abort()
    return line.rstrip("\r\n")


def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    value_proc=None,
    prompt_suffix=": ",
    show_default=True,
    err=False,
    show_choices=True,
):
    """Ask for a value, converting and re-asking on conversion failure."""
    from .parameter_types import convert_type

    ptype = convert_type(type, default)
    file = sys.stderr if err else sys.stdout
    dflt = default() if callable(default) else default
    shown = text
    if show_default and dflt is not None and dflt != "":
        shown_default = dflt if not hide_input else "********"
        shown = f"{text} [{shown_default}]"
    while True:
        echo(shown + prompt_suffix, file=file, nl=False)
        value = _read_line(hide_input)
        if not hide_input and not _isatty(sys.stdin):
            echo(value, file=file)
        if value == "":
            if dflt is None:
                continue
            value = dflt
        try:
            result = ptype.convert(value, None, None)
        except BadParameter as e:
            echo(f"Error: {e.message}", file=file, err=err)
            continue
        if value_proc is not None:
            result = value_proc(result)
        if confirmation_prompt:
            echo(f"Repeat for confirmation{prompt_suffix}", file=file, nl=False)
            again = _read_line(hide_input)
            if not hide_input and not _isatty(sys.stdin):
                echo(again, file=file)
            if again != value:
                echo("Error: The two entered values do not match.", file=file, err=err)
                continue
        return result


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question and return the answer as a bool."""
    file = sys.stderr if err else sys.stdout
    suffix = " [Y/n]" if default else " [y/N]"
    if not show_default:
        suffix = ""
    while True:
        echo(text + suffix + prompt_suffix, file=file, nl=False)
        value = _read_line()
        if not _isatty(sys.stdin):
            echo(value, file=file)
        lowered = value.strip().lower()
        if lowered == "":
            result = default
            break
        if lowered in ("y", "yes"):
            result = True
            break
        if lowered in ("n", "no"):
            result = False
            break
        echo("Error: invalid input", file=file, err=err)
    if abort and not result:
        raise Abort()
    return result


def getchar(echo_char=False):
    """Read one character from the terminal, even when standard input is a pipe."""
    if sys.stdin is not sys.__stdin__:
        ch = sys.stdin.read(1)
    else:
        ch = _read_terminal_char()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch in ("\x04", "\x1a"):
        raise EOFError()
    if echo_char:
        echo(ch, nl=False)
    return ch


def _read_terminal_char():
    try:
        import termios
        import tty

        fd = os.open("/dev/tty", os.O_RDONLY)
    except (ImportError, OSError):
        return sys.stdin.read(1)
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            return os.read(fd, 1).decode("utf-8", "replace")
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    finally:
        os.close(fd)


def pause(info=None, err=False):
    """Wait for a key press when running interactively; do nothing otherwise."""
    if not _is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    file = sys.stderr if err else sys.stdout
    echo(info, file=file, nl=False)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo("", file=file)


def clear():
    """Clear the terminal screen when standard output is a terminal."""
    if _isatty(sys.stdout):
        sys.stdout.write("\033[2J\033[1;1H")
        sys.stdout.flush()


class _NoCloseWriter:
    """Pager destination that forwards writes to standard output without closing it."""

    def __init__(self, stream):
        self._stream = stream

    def write(self, text):
        return self._stream.write(text)

    def flush(self):
        self._stream.flush()

    def isatty(self):
        return _isatty(self._stream)

    def close(self):
        self.flush()

    def __getattr__(self, name):
        return getattr(self._stream, name)


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream that is shown through the pager."""
    command = os.environ.get("PAGER") or "less"
    proc = None
    try:
        import shlex

        proc = subprocess.Popen(shlex.split(command), stdin=subprocess.PIPE, text=True)
    except (OSError, ValueError):
        proc = None
    if proc is None or proc.stdin is None:
        yield _NoCloseWriter(sys.stdout)
        return
    try:
        yield proc.stdin
    finally:
        try:
            proc.stdin.close()
        except OSError:
            pass
        proc.wait()


def echo_via_pager(text_or_generator, color=None):
    """Write text through a pager when interactive, else to standard output."""
    if callable(text_or_generator):
        chunks = text_or_generator()
    else:
        chunks = text_or_generator
    if isinstance(chunks, str):
        chunks = [chunks]
    if not _is_interactive():
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    with get_pager_file(color=color) as pager:
        strip = _strip_for(pager, color)
        for chunk in chunks:
            text = unstyle(chunk) if strip else chunk
            pager.write(text)
            pager.flush()


class ProgressBar:
    """A simple progress indicator that also iterates over ``iterable``."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, width=36, file=None):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.width = width
        self.file = file
        self.pos = 0
        self._start = time.time()
        self._finished = False
        self._labelled = False

    @property
    def _stream(self):
        return self.file or sys.stdout

    @property
    def _visible(self):
        return not self.hidden and _isatty(self._stream)

    def __enter__(self):
        if not self.hidden and not _isatty(self._stream) and self.label and not self._labelled:
            echo(self.label, file=self._stream)
            self._labelled = True
        if self._visible:
            self.render()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.finish()

    def __iter__(self):
        if self.iterable is None:
            raise TypeError("Progress bar has no iterable.")
        for item in self.iterable:
            yield item
            self.update(1)
        self.finish()

    def update(self, n_steps):
        self.pos += n_steps
        if self._visible:
            self.render()

    def _eta(self):
        if not self.length or self.pos == 0:
            return ""
        elapsed = time.time() - self._start
        remaining = elapsed / self.pos * max(self.length - self.pos, 0)
        return time.strftime("%H:%M:%S", time.gmtime(remaining))

    def render(self):
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            filled = int(self.width * frac)
            bar = "#" * filled + "-" * (self.width - filled)
            eta = self._eta()
            line = f"\r{self.label} [{bar}] {int(frac * 100):3d}%  {eta}"
        else:
            line = f"\r{self.label} {self.pos}"
        self._stream.write(line)
        self._stream.flush()

    def finish(self):
        if self._finished:
            return
        self._finished = True
        if self._visible:
            self._stream.write("\n")
            self._stream.flush()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    """Create a :class:`ProgressBar`. Use it as a context manager."""
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)
