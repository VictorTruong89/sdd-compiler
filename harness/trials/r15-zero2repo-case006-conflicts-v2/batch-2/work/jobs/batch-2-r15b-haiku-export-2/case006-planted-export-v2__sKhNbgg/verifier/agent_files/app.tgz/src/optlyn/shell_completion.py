"""Shell completion. # spec: Contract 8 (N-000983..N-001005), FP-12 (N-000677..N-000703)"""

import os
import sys

from . import paramtypes as _types
from .core import Argument, Context, Option

SHELLS = ("bash", "zsh", "fish", "powershell")
PATH_FILE = "\x01file"
PATH_DIR = "\x01dir"

_BASH = """\
___FN__() {
    local response line
    response=$(env COMP_WORDS="${COMP_WORDS[*]}" COMP_CWORD=$COMP_CWORD __VAR__=bash_complete __PROG__)
    COMPREPLY=()
    local IFS=$'\\n'
    for line in $response; do
        if [[ $line == $'\\x01'file ]]; then
            COMPREPLY+=($(compgen -f -- "${COMP_WORDS[COMP_CWORD]}"))
        elif [[ $line == $'\\x01'dir ]]; then
            COMPREPLY+=($(compgen -d -- "${COMP_WORDS[COMP_CWORD]}"))
        else
            COMPREPLY+=("${line%%$'\\t'*}")
        fi
    done
    return 0
}
complete -o default -F ___FN__ __PROG__
"""

_ZSH = """\
#compdef __PROG__
___FN__() {
    local -a response items
    local line
    response=("${(@f)$(env COMP_WORDS="${words[*]}" COMP_CWORD=$((CURRENT-1)) __VAR__=zsh_complete __PROG__)}")
    for line in $response; do
        if [[ $line == $'\\x01'file ]]; then
            _files
        elif [[ $line == $'\\x01'dir ]]; then
            _files -/
        else
            items+=("${line//$'\\t'/:}")
        fi
    done
    _describe 'values' items
}
compdef ___FN__ __PROG__
"""

_FISH = """\
complete -c __PROG__ -f -a '(env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) __VAR__=fish_complete __PROG__)'
"""

_POWERSHELL = """\
Register-ArgumentCompleter -Native -CommandName '__PROG__' -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)
    $env:COMP_WORDS = $commandAst.ToString()
    $env:COMP_CWORD = $wordToComplete
    $env:__VAR__ = 'powershell_complete'
    & __PROG__ | ForEach-Object {
        [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_)
    }
    Remove-Item Env:__VAR__
}
"""


def _names(prog):
    return prog.replace("-", "_"), "_" + prog.upper().replace("-", "_") + "_COMPLETE"


def _source_script(shell, prog):
    fn, var = _names(prog)
    template = {"bash": _BASH, "zsh": _ZSH, "fish": _FISH, "powershell": _POWERSHELL}[shell]
    return template.replace("__FN__", fn).replace("__VAR__", var).replace("__PROG__", prog)


def _option_for(node, ctx, token):
    for p in node.get_params(ctx):
        if isinstance(p, Option) and (token in p.opts or token in p.secondary_opts):
            return p
    return None


def _option_suggestions(node, ctx, incomplete):
    out = []
    for p in node.get_params(ctx):
        if not isinstance(p, Option) or p.hidden:
            continue
        for name in p.opts + p.secondary_opts:
            if name.startswith(incomplete):
                out.append((name, p.help or "", "plain"))
    return out


def _normalise(items):
    """Turn str items or objects with value/help/type into (value, help, type) tuples. # spec: N-001003..N-001005"""
    out = []
    for item in items or []:
        if isinstance(item, str):
            out.append((item, "", "plain"))
        else:
            out.append((item.value, getattr(item, "help", None) or "", getattr(item, "type", "plain")))
    return out


def _value_suggestions(param, ctx, incomplete):
    """Suggestions for a parameter's value. Returns (items, path_kind). # spec: FP-12 (N-000682..N-000699)"""
    if param.shell_complete is not None:
        return _normalise(param.shell_complete(ctx, param, incomplete)), None
    ptype = param.type
    if isinstance(ptype, _types.Path):
        if not ptype.file_okay and ptype.dir_okay:
            return [], "dir"
        return [], "file"
    if isinstance(ptype, _types.File):
        return [], "file"
    if ptype is not None and hasattr(ptype, "shell_complete"):
        return _normalise(ptype.shell_complete(ctx, param, incomplete)), None
    return [], None


def suggest(cmd, prog, words, incomplete):
    """Return a list of (value, help, type) tuples plus an optional path kind."""
    from .commands import Group

    root = Context(cmd, info_name=prog)
    node, nctx = cmd, root
    pending = None
    arg_index = 0
    for tok in words:
        if pending is not None:
            pending = None
            continue
        if tok.startswith("-") and len(tok) > 1 and tok != "--":
            hit = _option_for(node, nctx, tok)
            if hit is not None and not hit.is_flag and not hit.count and "=" not in tok:
                pending = hit
            continue
        if isinstance(node, Group):
            sub = node.get_command(nctx, tok)
            if sub is not None:
                node = sub
                nctx = Context(sub, parent=nctx, info_name=sub.name)
                arg_index = 0
                continue
        arg_index += 1

    if pending is not None:
        return _value_suggestions(pending, nctx, incomplete)

    if incomplete.startswith("-"):
        return _option_suggestions(node, nctx, incomplete), None

    items = []
    if isinstance(node, Group):
        for name in node.list_commands(nctx):
            sub = node.get_command(nctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            items.append((name, sub.get_short_help(), "plain"))
        if items:
            return items, None

    args = node.arguments
    if arg_index < len(args):
        return _value_suggestions(args[arg_index], nctx, incomplete)
    return [], None


def _emit_suggestions(cmd, prog, shell, env):
    words_raw = env.get("COMP_WORDS", "")
    words = words_raw.split(" ")
    if shell == "fish":
        incomplete = env.get("COMP_CWORD", "")
        preceding = words[1:]
        if preceding and preceding[-1] in (incomplete, ""):
            preceding = preceding[:-1]
    else:
        try:
            idx = int(env.get("COMP_CWORD", str(len(words))))
        except ValueError:
            idx = len(words)
        preceding = words[1:idx]
        incomplete = words[idx] if idx < len(words) else ""
    items, path_kind = suggest(cmd, prog, preceding, incomplete)
    lines = []
    if path_kind is not None:
        lines.append(PATH_DIR if path_kind == "dir" else PATH_FILE)
    for value, help_text, _kind in items:
        if shell in ("zsh", "fish") and help_text:
            lines.append(f"{value}\t{help_text}")
        else:
            lines.append(value)
    sys.stdout.write("\n".join(lines) + ("\n" if lines else ""))
    return 0


def run_completion(cmd, prog, instruction, args=None):
    """Handle a completion instruction; returns the exit status. # spec: FP-12 (N-000689..N-000703)"""
    if "_" not in instruction:
        return 1
    shell, _, action = instruction.partition("_")
    if shell not in SHELLS:
        return 1
    if action == "source":
        sys.stdout.write(_source_script(shell, prog) + "\n")
        return 0
    if action == "complete":
        return _emit_suggestions(cmd, prog, shell, os.environ)
    return 1
