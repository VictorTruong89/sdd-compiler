"""Context and parameter objects.

# spec: FP-03 (N-000165..N-000272), FP-04 (N-000273..N-000317),
#       FP-07 (N-000424..N-000473), Contract 4 and 6 (N-000868..N-000962)
"""

import enum
import threading

from . import paramtypes as _types
from .exceptions import Abort, Exit


class ParameterSource(enum.Enum):
    """Where a parameter value came from. # spec: N-000453..N-000456"""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


class _Omitted:
    def __repr__(self):
        return "<omitted>"


OMITTED = _Omitted()
CHAIN_MARKER = object()

_local = threading.local()


def _stack():
    if not hasattr(_local, "stack"):
        _local.stack = []
    return _local.stack


def get_current_context(silent=False):
    """Return the context current on this thread. # spec: N-000960..N-000962"""
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


class Context:
    """Per-invocation state. # spec: Contract 6 (N-000932..N-000956)"""

    DEFAULT_MAX_CONTENT_WIDTH = 80

    def __init__(self, command, parent=None, info_name=None, obj=None, settings=None):
        self.command = command
        self.parent = parent
        self.info_name = info_name or (command.name if command is not None else None)
        merged = dict(parent.settings) if parent is not None else {}
        merged.update(settings or {})
        self.settings = merged
        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.default_map = merged.get("default_map")
        if parent is not None and isinstance(parent.default_map, dict):
            self.default_map = parent.default_map.get(command.name)
        self.params = {}
        self.args = []
        self.protected_args = []
        self.invoked_subcommand = None
        self.auto_envvar_prefix = merged.get("auto_envvar_prefix")
        self.terminal_width = merged.get("terminal_width")
        self.max_content_width = merged.get("max_content_width", self.DEFAULT_MAX_CONTENT_WIDTH)
        self.help_option_names = list(merged.get("help_option_names", ["--help"]))
        self.token_normalize_func = merged.get("token_normalize_func")
        self.color = merged.get("color")
        self.show_default = merged.get("show_default")
        self.allow_extra_args = merged.get("allow_extra_args", False)
        self.ignore_unknown_options = merged.get("ignore_unknown_options", False)
        self.allow_interspersed_args = merged.get("allow_interspersed_args", True)
        self.resilient_parsing = False
        self._sources = {}
        self._close_callbacks = []
        # the top-level command's own name is not part of the env prefix. # spec: N-000436
        self.env_parts = list(parent.env_parts) + [command.name] if parent is not None else []

    # --- context manager protocol -------------------------------------
    def __enter__(self):
        _stack().append(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        stack = _stack()
        if stack and stack[-1] is self:
            stack.pop()
        return False

    # --- resources -----------------------------------------------------
    def call_on_close(self, fn):
        self._close_callbacks.append(fn)

    def close(self):
        callbacks, self._close_callbacks = self._close_callbacks, []
        for fn in reversed(callbacks):
            try:
                fn()
            except Exception:
                pass

    def with_resource(self, cm):
        value = cm.__enter__()
        self.call_on_close(lambda: cm.__exit__(None, None, None))
        return value

    # --- control -------------------------------------------------------
    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    # --- help ----------------------------------------------------------
    def get_help(self):
        from .formatting import format_help

        return format_help(self.command, self)

    def get_usage(self):
        from .formatting import format_usage

        return format_usage(self.command, self)

    def get_parameter_source(self, name):
        """Source of a declared parameter's value, or None. # spec: N-000453..N-000456"""
        if self.command is None or name not in {p.name for p in self.command.params}:
            return None
        return self._sources.get(name, ParameterSource.DEFAULT)

    # --- invocation ----------------------------------------------------
    def invoke(self, cmd, **kwargs):
        """Run another command with exactly the given values. # spec: N-000461..N-000466"""
        return self._run_other(cmd, kwargs)

    def forward(self, cmd, **kwargs):
        """Run another command with this command's values plus overrides. # spec: N-000461"""
        merged = dict(self.params)
        merged.update(kwargs)
        return self._run_other(cmd, merged)

    def _run_other(self, cmd, values):
        child = Context(cmd, parent=self, info_name=cmd.name)
        child.params = dict(values)
        with child:
            return cmd.callback(**values)

    def __repr__(self):
        return f"<Context {self.info_name}>"


class Parameter:
    """Common base for options and arguments. # spec: N-000908..N-000910"""

    def __init__(self, type=None, default=None, required=None, multiple=False, nargs=1,
                 envvar=None, allow_from_autoenv=True, callback=None, is_eager=False,
                 expose_value=True, hidden=False, deprecated=False, help=None, metavar=None,
                 shell_complete=None, prompt=False, prompt_required=True, hide_input=False,
                 confirmation_prompt=False, show_default=None, show_envvar=False):
        if not isinstance(nargs, int) or nargs == 0 or nargs < -1:
            raise TypeError("nargs must be a positive integer, or -1 for variadic")
        self.name = None
        self.type = _types._as_type(type) if type is not None else None
        self.default = default
        self.multiple = bool(multiple)
        self.nargs = nargs
        self.envvar = [envvar] if isinstance(envvar, str) else (list(envvar) if envvar else [])
        self.allow_from_autoenv = allow_from_autoenv
        self.callback = callback
        self.is_eager = is_eager
        self.expose_value = expose_value
        self.hidden = hidden
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None
        self.help = help
        self.metavar = metavar
        self.shell_complete = shell_complete
        self.prompt = prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.required = bool(required)
        self.is_flag = False
        self.is_bool_flag = False
        self.flag_value = None
        self.count = False

    @property
    def variadic(self):
        return self.nargs == -1

    @property
    def per_occurrence_arity(self):
        """Tokens taken per occurrence (a Tuple type sets it). # spec: N-000201"""
        if isinstance(self.type, _types.Tuple):
            return self.type.arity
        return self.nargs

    def _infer_type(self):
        if self.type is not None:
            return
        if self.is_flag:
            self.type = _types.BOOL
            return
        if self.count:
            self.type = _types.INT
            return
        probe = self.default
        if self.multiple or self.nargs != 1:
            probe = probe[0] if isinstance(probe, (list, tuple)) and probe else None
        if isinstance(probe, bool):
            self.type = _types.BOOL
        elif isinstance(probe, int):
            self.type = _types.INT
        elif isinstance(probe, float):
            self.type = _types.FLOAT
        else:
            self.type = _types.STRING

    def get_error_hint(self):
        return self.name or "parameter"

    def convert_one(self, raw, ctx):
        """Convert one occurrence: a token, or a tuple of tokens for multi-value. # spec: N-000201"""
        ptype = self.type or _types.STRING
        if isinstance(ptype, _types.Tuple):
            return ptype.convert(raw, self, ctx)
        if isinstance(raw, (list, tuple)):
            return tuple(ptype.convert(v, self, ctx) for v in raw)
        return ptype.convert(raw, self, ctx)

    def split_env(self, text):
        """Split env text for repeatable or multi-value parameters. # spec: N-000220"""
        if self.multiple or self.nargs != 1 or isinstance(self.type, _types.Tuple):
            if isinstance(self.type, (_types.File, _types.Path)):
                import os

                return [t for t in text.split(os.pathsep) if t != ""]
            return text.split()
        return text

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class Option(Parameter):
    """A named option. # spec: N-000868..N-000896"""

    def __init__(self, param_decls=None, is_flag=None, flag_value=None, count=False, **attrs):
        super().__init__(**attrs)
        self.opts = []
        self.secondary_opts = []
        self.count = bool(count)
        self._parse_decls(list(param_decls or []))
        if self.count and (is_flag or self.multiple or self.nargs != 1):
            raise TypeError("A counting option cannot be a flag, repeatable or multi-value.")
        if self.deprecated and self.required:
            raise TypeError("A deprecated option cannot be required.")
        if self.deprecated and self.prompt:
            raise TypeError("A deprecated option cannot use a prompt.")
        if self.count:
            self.flag_value = 1
            if self.default is None:
                self.default = 0
        elif is_flag or (is_flag is None and self.secondary_opts):
            self.is_flag = True
            self.is_bool_flag = True
            self.flag_value = True if flag_value is None else flag_value
            if self.default is None:
                self.default = False
        elif flag_value is not None:
            # optional value: the bare flag yields flag_value
            self.flag_value = flag_value
        if self.is_flag and self.prompt and self.default is None:
            self.default = False
        self._infer_type()

    def _parse_decls(self, decls):
        on_names, off_names = [], []
        for decl in decls:
            if decl.isidentifier():
                self.name = decl
                continue
            if "/" in decl[1:]:
                idx = decl.find("/", 1)
                on_names.append(decl[:idx])
                off_names.append(decl[idx + 1:])
            else:
                on_names.append(decl)
        self.opts = on_names
        self.secondary_opts = off_names
        if self.name is None:
            self.name = self._derive_name(on_names)
        if not self.opts and not self.secondary_opts:
            raise TypeError("An option needs a flag name or a destination.")

    @staticmethod
    def _derive_name(names):
        longs = [n for n in names if len(n) > 2 and n[0] == n[1]]
        pick = longs[0] if longs else (names[0] if names else "")
        if pick == "":
            return ""
        return pick.lstrip("-/+").replace("-", "_")

    def get_error_hint(self):
        return "/".join(self.opts + self.secondary_opts) or self.name

    def get_default_metavar(self):
        """Default metavar for the help page. # spec: N-000325..N-000329, N-001013"""
        if self.metavar is not None:
            return self.metavar
        if self.is_flag or self.count:
            return None
        # the destination name in uppercase, e.g. "--count COUNT"; choice types list their values. # spec: N-001013, N-000326
        if isinstance(self.type, _types.Choice):
            return self.type.get_metavar()
        return self.name.upper()

    def __repr__(self):
        return f"<Option {self.name} {self.opts}>"


class Argument(Parameter):
    """A positional argument. # spec: N-000897..N-000899"""

    def __init__(self, param_decls=None, **attrs):
        decls = list(param_decls or [])
        if len(decls) != 1:
            raise TypeError("An argument takes exactly one destination name.")
        if attrs.get("required") is None:
            attrs["required"] = attrs.get("default") is None
        if attrs.get("prompt"):
            raise TypeError("Arguments cannot prompt.")
        super().__init__(**attrs)
        self.name = decls[0]
        if self.deprecated and self.required:
            raise TypeError("A deprecated argument cannot be required.")
        self._infer_type()

    def get_error_hint(self):
        return self.metavar or self.name.upper()

    def get_default_metavar(self):
        return self.metavar or self.name.upper()

    def __repr__(self):
        return f"<Argument {self.name}>"
