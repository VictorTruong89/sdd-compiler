"""Basic behaviour checks for Optlyn. Run with PYTHONPATH=src."""

import os

from optlyn import Choice, IntRange, argument, command, group, option
from optlyn.testing import CliRunner


@command()
@option("--count", "-c", type=int, default=1)
@option("--shout/--no-shout", default=False)
@argument("name")
def hello(count, shout, name):
    """Say hello. Second sentence."""
    for _ in range(count):
        print(f"hello {name}{'!' if shout else ''}")


@group()
@option("--verbose", is_flag=True)
def cli(verbose):
    """Top group."""
    print("verbose", verbose)


cli.add_command(hello)


def test_command_runs_with_options_and_argument():
    res = CliRunner().invoke(cli, ["hello", "-c", "2", "--shout", "bob"], prog_name="tool")
    assert res.exit_code == 0
    assert res.output == "verbose False\nhello bob!\nhello bob!\n"


def test_help_is_success_and_skips_callback():
    res = CliRunner().invoke(hello, ["--help"], prog_name="tool")
    assert res.exit_code == 0
    assert "Usage: tool [OPTIONS] NAME" in res.output
    assert "hello bob" not in res.output


def test_missing_argument_is_usage_error():
    res = CliRunner().invoke(hello, [], prog_name="tool")
    assert res.exit_code == 2
    assert "NAME" in res.output


def test_group_without_subcommand_is_usage_error_with_help():
    res = CliRunner().invoke(cli, [], prog_name="tool")
    assert res.exit_code == 2
    assert "Commands:" in res.output


def test_unknown_subcommand_is_usage_error():
    res = CliRunner().invoke(cli, ["nope"], prog_name="tool")
    assert res.exit_code == 2
    assert "No such command" in res.output


def test_range_and_choice_conversion():
    @command()
    @option("--num", type=IntRange(1, 5), required=True)
    @option("--mode", type=Choice(["fast", "slow"]), default="fast")
    def run(num, mode):
        print(num, mode)

    runner = CliRunner()
    assert runner.invoke(run, ["--num", "3"]).output == "3 fast\n"
    assert runner.invoke(run, ["--num", "9"]).exit_code == 2
    assert runner.invoke(run, ["--num", "1", "--mode", "x"]).exit_code == 2


def test_env_var_fills_option():
    @command()
    @option("--retries", type=int, default=3, envvar="OPTLYN_TEST_RETRIES")
    def run(retries):
        print(retries)

    res = CliRunner().invoke(run, [], env={"OPTLYN_TEST_RETRIES": "7"})
    assert res.output == "7\n"


def test_default_map_nests_by_subcommand_name():
    res = CliRunner().invoke(cli, ["hello", "x"], default_map={"hello": {"count": 2}})
    assert res.output.count("hello x") == 2


def test_chain_group_returns_list_of_results():
    @group(chain=True)
    def chained():
        pass

    @chained.command()
    @argument("v")
    def a(v):
        return v.upper()

    @chained.command()
    def b():
        return 2

    rv = chained.main(["a", "1", "b", "a", "2"], prog_name="t", standalone_mode=False)
    assert rv == ["1".upper(), 2, "2".upper()]


def test_completion_suggests_subcommands():
    os.environ["_CLI_COMPLETE"] = "bash_complete"
    os.environ["COMP_WORDS"] = "cli "
    os.environ["COMP_CWORD"] = "1"
    try:
        res = CliRunner().invoke(cli, [], prog_name="cli")
    finally:
        del os.environ["_CLI_COMPLETE"]
        del os.environ["COMP_WORDS"]
        del os.environ["COMP_CWORD"]
    assert res.output == "hello\n"
