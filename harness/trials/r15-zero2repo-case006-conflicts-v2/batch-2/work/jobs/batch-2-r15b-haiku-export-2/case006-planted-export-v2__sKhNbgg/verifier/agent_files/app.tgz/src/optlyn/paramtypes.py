"""Parameter types and conversion.

# spec: N-000318 through N-000365 (FP-05), N-000923 through N-000931 (Contract 5)
"""

import datetime as _dt
import enum
import io
import os
import pathlib
import uuid as _uuid

from .exceptions import BadParameter, FileError


class ParamType:
    """Base class for parameter types. # spec: N-000929"""

    name = "text"
    envvar_list_splitter = None  # None means whitespace split

    def __call__(self, value, param=None, ctx=None):
        if value is None:
            return None
        return self.convert(value, param, ctx)

    def convert(self, value, param=None, ctx=None):
        return value

    def get_metavar(self, param=None):
        return None

    def get_default_placeholder(self):
        return self.name.upper()

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx, param, incomplete):
        return []

    def split_envvar_value(self, value):
        return value.split()

    def __repr__(self):
        return self.name.upper()


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class _IntType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


class _BoolType(ParamType):
    name = "boolean"

    TRUE = {"1", "true", "t", "yes", "y", "on"}
    FALSE = {"0", "false", "f", "no", "n", "off"}

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in self.TRUE:
            return True
        if text in self.FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value))
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()


class Choice(ParamType):
    """A closed list of values or an enum. # spec: N-000339 through N-000343"""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._is_enum = True
        else:
            self.choices = list(choices)
            self._is_enum = False

    def _token(self, choice):
        if self._is_enum:
            return choice.name
        return str(choice)

    def get_metavar(self, param=None):
        return "[" + "|".join(self._token(c) for c in self.choices) + "]"

    def get_default_placeholder(self):
        return self.get_metavar()

    def convert(self, value, param=None, ctx=None):
        if not self.case_sensitive:
            norm = str(value).casefold()
        for choice in self.choices:
            tok = self._token(choice)
            if self.case_sensitive:
                if tok == value or choice == value:
                    return choice
            elif tok.casefold() == norm:
                return choice
        choices = ", ".join(repr(self._token(c)) for c in self.choices)
        self.fail(f"{value!r} is not {choices}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        out = []
        for c in self.choices:
            tok = self._token(c)
            a, b = (tok, incomplete) if self.case_sensitive else (tok.casefold(), incomplete.casefold())
            if a.startswith(b):
                out.append(tok)
        return out


class DateTime(ParamType):
    """Parses date-times. # spec: N-000344 through N-000348"""

    name = "datetime"
    DEFAULT_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(self.DEFAULT_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value), fmt)
            except ValueError:
                continue
        formats = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the formats {formats}.", param, ctx)


class _RangeMixin:
    def _check(self, value, param, ctx):
        lo, hi = self.min, self.max
        if lo is not None:
            if self.min_open and value <= lo:
                if self.clamp:
                    return self._clamp_value(lo, lo_side=True)
                self.fail(f"{value} is not in the valid range of {self._desc()}.", param, ctx)
            if not self.min_open and value < lo:
                if self.clamp:
                    return lo
                self.fail(f"{value} is not in the valid range of {self._desc()}.", param, ctx)
        if hi is not None:
            if self.max_open and value >= hi:
                if self.clamp:
                    return self._clamp_value(hi, lo_side=False)
                self.fail(f"{value} is not in the valid range of {self._desc()}.", param, ctx)
            if not self.max_open and value > hi:
                if self.clamp:
                    return hi
                self.fail(f"{value} is not in the valid range of {self._desc()}.", param, ctx)
        return value

    def _desc(self):
        lo = "" if self.min is None else ("(" if self.min_open else "[") + str(self.min)
        hi = "" if self.max is None else str(self.max) + (")" if self.max_open else "]")
        if self.min is None:
            lo = "-inf"
        if self.max is None:
            hi = "inf"
        return f"{lo}, {hi}"


class IntRange(_RangeMixin, _IntType):
    """Integer in a range. # spec: N-000349 through N-000353"""

    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def _clamp_value(self, bound, lo_side):
        return bound + 1 if lo_side else bound - 1

    def convert(self, value, param=None, ctx=None):
        v = _IntType.convert(self, value, param, ctx)
        return self._check(v, param, ctx)


class FloatRange(_RangeMixin, _FloatType):
    """Float in a range. # spec: N-000354 through N-000356"""

    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is not supported for open bounds.")
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def _clamp_value(self, bound, lo_side):
        return bound

    def convert(self, value, param=None, ctx=None):
        v = _FloatType.convert(self, value, param, ctx)
        return self._check(v, param, ctx)


class Tuple(ParamType):
    """Fixed-length product of types. # spec: N-000357"""

    name = "tuple"

    def __init__(self, types):
        self.types = [_as_type(t) for t in types]

    @property
    def arity(self):
        return len(self.types)

    def convert(self, value, param=None, ctx=None):
        value = tuple(value)
        if len(value) != len(self.types):
            self.fail(f"{len(self.types)} values are required, but {len(value)} were given.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


class File(ParamType):
    """An open file. # spec: N-000358, FP-09 (N-000522 through N-000535)"""

    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"unsupported mode {mode!r}")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        from .termui import open_file

        lazy = self.lazy
        if lazy is None:
            lazy = self.mode.startswith("w")
        try:
            f = open_file(
                str(value),
                self.mode,
                self.encoding,
                self.errors,
                lazy=lazy,
                atomic=self.atomic,
            )
        except OSError as exc:
            self.fail(f"'{value}': {exc.strerror or exc}", param, ctx)
        if ctx is not None:
            ctx.call_on_close(f.close)
        return f


class Path(ParamType):
    """A filesystem path. # spec: N-000359, FP-09 (N-000538 through N-000564)"""

    name = "path"

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param=None, ctx=None):
        raw = os.fspath(value) if isinstance(value, os.PathLike) else value
        if isinstance(raw, bytes):
            raw = os.fsdecode(raw)
        if self.allow_dash and raw == "-":
            return self._result("-")
        if self.resolve_path:
            raw = os.path.realpath(raw)
        if not os.path.exists(raw):
            if self.exists:
                self.fail(f"{raw!r} does not exist.", param, ctx)
            return self._result(raw)
        if os.path.isdir(raw):
            if not self.dir_okay:
                self.fail(f"{raw!r} is a directory.", param, ctx)
        elif not self.file_okay:
            self.fail(f"{raw!r} is a file.", param, ctx)
        if self.readable and not os.access(raw, os.R_OK):
            self.fail(f"{raw!r} is not readable.", param, ctx)
        if self.writable and not os.access(raw, os.W_OK):
            self.fail(f"{raw!r} is not writable.", param, ctx)
        if self.executable and not os.access(raw, os.X_OK):
            self.fail(f"{raw!r} is not executable.", param, ctx)
        return self._result(raw)

    def _result(self, raw):
        if self.path_type is pathlib.Path:
            return pathlib.Path(raw)
        return raw


class _Passthrough(ParamType):
    pass


def _as_type(value):
    """Turn a type-ish value into a ParamType. # spec: N-000361"""
    if isinstance(value, ParamType):
        return value
    if value is str:
        return STRING
    if value is int:
        return INT
    if value is float:
        return FLOAT
    if value is bool:
        return BOOL
    if value is _uuid.UUID:
        return UUID
    if callable(value):
        return FuncType(value)
    raise TypeError(f"unsupported type {value!r}")


class FuncType(ParamType):
    """Wraps a conversion function that refuses by raising ValueError. # spec: N-000872"""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError:
            self.fail(f"{value!r} is not a valid value.", param, ctx)
