"""Exception classes used by Optlyn.

# spec: N-000704, N-000707, N-000711, N-000714
"""

import sys


class OptlynError(Exception):
    """Base class for Optlyn exceptions."""

    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def show(self, file=None):
        file = file or sys.stderr
        file.write(f"Error: {self.message}\n")


class UsageError(OptlynError):
    """A usage failure: exit status 2. # spec: N-000707"""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self, file=None):
        file = file or sys.stderr
        if self.ctx is not None and getattr(self.ctx, "command", None) is not None:
            file.write(self.ctx.get_usage() + "\n")
        file.write(f"Error: {self.message}\n")


class BadParameter(UsageError):
    """Refuses a value. # spec: N-000920

    ``param`` identifies the offending parameter in the report.
    """

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.param_hint:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint()
        else:
            return self.message
        return f"Invalid value for {hint}: {self.message}"

    def show(self, file=None):
        file = file or sys.stderr
        if self.ctx is not None and getattr(self.ctx, "command", None) is not None:
            file.write(self.ctx.get_usage() + "\n")
        file.write(f"Error: {self.format_message()}\n")


class MissingParameter(BadParameter):
    """A required parameter was not supplied."""

    def format_message(self):
        hint = self.param_hint or (
            self.param.get_error_hint() if self.param is not None else "parameter"
        )
        return f"Missing parameter: {hint}"


class NoSuchOption(UsageError):
    """An unknown option token was given."""


class UsageRecordError(UsageError):
    """Other usage problems (unknown subcommand, extra args, etc.)."""


class Abort(OptlynError):
    """Abort: exit status 1. # spec: N-000711"""

    exit_code = 1

    def __init__(self, message="Aborted!"):
        super().__init__(message)

    def show(self, file=None):
        file = file or sys.stderr
        file.write("Aborted!\n")


class Exit(Exception):
    """Author clean stop with an exit status. # spec: N-000705"""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code


class FileError(OptlynError):
    """A general file-open error (exit 1, not usage). # spec: N-000714"""

    exit_code = 1
