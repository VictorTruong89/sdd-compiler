"""Help pages, usage lines, and text wrapping.

# spec: FP-02 (N-000103..N-000164), Contract 2 help page (N-000812..N-000829),
#       FP-11 wrapping (N-000669), N-001014 (100 wide cap; see NOTES.md for the 80 choice)
"""

import shutil
import textwrap

from . import paramtypes as _types
from .core import Argument, Option


def wrap_text(text, width=78, initial_indent="", subsequent_indent="",
              preserve_paragraphs=False):
    """Wrap text to a width. Accepts any string. # spec: N-000669, N-000965"""
    text = "" if text is None else str(text)
    paragraphs = text.split("\n\n") if preserve_paragraphs else [text]
    out = []
    for para in paragraphs:
        lines = para.split("\n")
        # a paragraph starting with a backspace line keeps its own line breaks. # spec: N-000127..N-000131
        if lines and lines[0].strip("\b") == "" and "\b" in lines[0]:
            kept = [ln for ln in lines[1:]]
            out.append("\n".join(kept))
            continue
        out.append(textwrap.fill(
            " ".join(s.strip() for s in lines if s.strip() != "") or "",
            width=max(width, 10),
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
        ))
    return "\n\n".join(out)


def _width(ctx):
    """Wrap width: explicit terminal width is used as-is, auto-detected width is capped. # spec: N-000126..N-000127"""
    if ctx is not None and ctx.terminal_width:
        return max(ctx.terminal_width - 2, 10)
    cap = ctx.max_content_width if ctx is not None else 80
    detected = shutil.get_terminal_size((80, 24)).columns
    return max(min(detected, cap) - 2, 10)


def _command_path(ctx):
    names = []
    node = ctx
    while node is not None:
        names.append(node.info_name or "")
        node = node.parent
    return " ".join(reversed(names))


def _visible_params(command, ctx):
    params = command.get_params(ctx) if ctx is not None else list(command.params)
    return [p for p in params if not p.hidden]


def _arg_placeholder(arg):
    base = arg.metavar or arg.name.upper()
    if arg.variadic:
        return f"[{base}]..." if not arg.required else f"{base}..."
    if arg.required:
        return base
    return f"[{base}]"


def format_usage(command, ctx):
    """Usage line. # spec: N-000120..N-000125, N-000813..N-000818"""
    pieces = [_command_path(ctx)]
    params = _visible_params(command, ctx)
    if any(isinstance(p, Option) for p in params):
        pieces.append(command.options_metavar)
    for arg in command.arguments:
        pieces.append(_arg_placeholder(arg))
    if command.is_group:
        if command.chain:
            pieces.append("COMMAND [ARGS]... [COMMAND [ARGS]...]...")
        elif command.invoke_without_command:
            pieces.append("[COMMAND] [ARGS]...")
        else:
            pieces.append("COMMAND [ARGS]...")
    return "Usage: " + " ".join(p for p in pieces if p)


def _option_entry(p, ctx):
    names = ", ".join(p.opts + p.secondary_opts) if (p.opts or p.secondary_opts) else p.name
    metavar = p.get_default_metavar()
    head = f"{names} {metavar}" if metavar else names
    extras = []
    show_default = p.show_default if p.show_default is not None else (
        ctx.show_default if ctx is not None and ctx.show_default is not None else False
    )
    if show_default and p.default is not None and not (p.is_flag and p.default is False):
        shown = p.show_default if isinstance(p.show_default, str) else p.default
        if callable(p.default) and not isinstance(p.show_default, str):
            shown = "(dynamic)"
        extras.append(f"default: {shown}")
    if p.show_envvar and p.envvar:
        extras.append("env var: " + ", ".join(p.envvar))
    help_text = p.help or ""
    if extras:
        help_text = (help_text + " " if help_text else "") + "[" + "; ".join(extras) + "]"
    if p.deprecated:
        help_text = ("(deprecated) " + help_text).strip()
    return head, help_text


def _section(title, rows, width):
    if not rows:
        return []
    lines = [title + ":"]
    col = min(max(len(h) for h, _ in rows) + 2, max(width // 2, 10))
    for head, text in rows:
        if not text:
            lines.append("  " + head)
            continue
        wrapped = textwrap.wrap(text, width=max(width - col - 2, 10)) or [""]
        if len(head) + 2 > col:
            lines.append("  " + head)
            for w in wrapped:
                lines.append(" " * (col + 2) + w)
        else:
            lines.append("  " + head.ljust(col) + wrapped[0])
            for w in wrapped[1:]:
                lines.append(" " * (col + 2) + w)
    return lines + [""]


def format_help(command, ctx):
    """Full help page. # spec: N-000812..N-000829"""
    width = _width(ctx)
    lines = [format_usage(command, ctx), ""]
    if command.help:
        text = command.help
        if command.deprecated:
            text = "(Deprecated) " + text
        lines += [wrap_text(text, width=width), ""]
    elif command.deprecated:
        lines += ["(Deprecated)", ""]

    args = [a for a in command.arguments if a.help and not a.hidden]
    arg_rows = [(_arg_placeholder(a), a.help) for a in args]
    lines += _section("Positional arguments", arg_rows, width)

    opts = [p for p in _visible_params(command, ctx) if isinstance(p, Option)]
    opts.sort(key=lambda p: getattr(p, "is_help", False))
    opt_rows = [_option_entry(p, ctx) for p in opts]
    lines += _section("Options", opt_rows, width)

    if command.is_group:
        rows = []
        for name in command.list_commands(ctx):
            sub = command.get_command(ctx, name)
            if sub is None or sub.hidden:
                continue
            rows.append((name, sub.get_short_help() if hasattr(sub, "get_short_help") else ""))
        lines += _section("Commands", rows, width)

    if command.epilog:
        lines += [wrap_text(command.epilog, width=width), ""]
    while lines and lines[-1] == "":
        lines.pop()
    return "\n".join(lines)
