"""Commands, groups, and the decorators that declare them.

# spec: FP-01 (N-000073..N-000102), FP-02 (N-000103..N-000164),
#       FP-06 (N-000375..N-000423), FP-10 (N-000582..N-000607),
#       Contract 3 (N-000834..N-000867), Contract 4 ready-made options (N-000911..N-000922)
"""

import inspect
import os
import sys

from .core import CHAIN_MARKER, Argument, Context, Option
from .exceptions import Abort, Exit, OptlynError, UsageError
from .parser import assign_arguments, parse_tokens, resolve_params
from .termui import echo

_SUFFIXES = ("_command", "_cmd", "_group", "_grp")


def _default_name(func_name):
    """Derive a command name from a function name. # spec: N-000073..N-000076"""
    name = func_name.lower().replace("_", "-")
    for suffix in _SUFFIXES:
        dashed = suffix.replace("_", "-")
        if name.endswith(dashed) and len(name) > len(dashed):
            return name[: -len(dashed)]
    return name


def _default_prog_name():
    argv0 = sys.argv[0] if sys.argv and sys.argv[0] else "main"
    base = os.path.basename(argv0)
    if base.endswith(".py"):
        base = base[:-3]
    return base or "main"


class _NoArgsHelp(UsageError):
    """No arguments on a command that shows help: usage failure, exit 2. # spec: N-000157"""

    def show(self, file=None):
        file = file or sys.stderr
        file.write(self.ctx.get_help() + "\n")


def _help_callback(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return value
    echo(ctx.get_help())
    raise Exit(0)


def _make_help_option():
    opt = Option(
        ["--help"],
        is_flag=True,
        is_eager=True,
        expose_value=False,
        callback=_help_callback,
        help="Show this message and exit.",
    )
    opt.is_help = True
    return opt


class Command:
    """A leaf command. # spec: N-000834..N-000849"""

    allow_extra_args = False
    interspersed_args = True
    is_group = False

    def __init__(self, name, callback=None, params=None, help=None, short_help=None,
                 epilog=None, options_metavar="[OPTIONS]", context_settings=None,
                 add_help_option=True, no_args_is_help=False, deprecated=False, hidden=False,
                 **kwargs):
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        self.help = help
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None
        self.hidden = hidden
        self._help_param = _make_help_option() if add_help_option else None

    @property
    def arguments(self):
        return [p for p in self.params if isinstance(p, Argument)]

    @property
    def options(self):
        return [p for p in self.params if isinstance(p, Option)]

    def get_params(self, ctx):
        """Parameters active for this invocation, including the automatic help option. # spec: N-000142..N-000148"""
        params = list(self.params)
        if self._help_param is None:
            return params
        names = list(ctx.help_option_names)
        authored = {n for p in self.params if isinstance(p, Option) for n in p.opts}
        if names and all(n in authored for n in names):
            return params
        self._help_param.opts = names
        # first, so an author option that reuses a help name wins that name. # spec: N-000146
        return [self._help_param] + params

    def get_short_help(self):
        if self.short_help is not None:
            return self.short_help
        text = self.help or ""
        first = text.strip().split(". ")[0] if text.strip() else ""
        return first

    def get_help_text(self):
        return self.help or ""

    # ---- invocation -----------------------------------------------------
    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        """Run as a program. # spec: N-000842..N-000848, FP-13"""
        args = sys.argv[1:] if args is None else list(args)
        prog = prog_name if prog_name is not None else _default_prog_name()
        var = complete_var or ("_" + prog.upper().replace("-", "_") + "_COMPLETE")
        instruction = os.environ.get(var)
        if instruction:
            from .shell_completion import run_completion

            status = run_completion(self, prog, instruction, args)
            if standalone_mode:
                sys.exit(status)
            return None
        try:
            rv = self._invoke_tokens(prog, args, None, extra)
        except Exit as exc:
            if standalone_mode:
                sys.exit(exc.exit_code)
            return None
        except OptlynError as exc:
            if not standalone_mode:
                raise
            exc.show()
            sys.exit(exc.exit_code)
        except (KeyboardInterrupt, EOFError):
            if not standalone_mode:
                raise
            echo("Aborted!", err=True)
            sys.exit(1)
        if standalone_mode:
            sys.exit(0)
        return rv

    def _new_context(self, info_name, parent, extra):
        settings = dict(self.context_settings)
        default_map = settings.pop("default_map", None)
        if parent is None:
            settings.update(extra)
            obj = settings.pop("obj", None)
            default_map = settings.pop("default_map", default_map)
        else:
            obj = None
        ctx = Context(self, parent=parent, info_name=info_name, obj=obj, settings=settings)
        if parent is None:
            ctx.default_map = default_map
        else:
            nested = parent.default_map.get(self.name) if isinstance(parent.default_map, dict) else None
            ctx.default_map = nested if nested is not None else default_map
        return ctx

    def _invoke_tokens(self, info_name, args, parent, extra, chained=False):
        ctx = self._new_context(info_name, parent, extra)
        close_here = parent is None or chained
        try:
            return self._run(ctx, list(args), parent)
        finally:
            if close_here:
                ctx.close()
            elif parent is not None:
                parent._close_callbacks.extend(ctx._close_callbacks)
                ctx._close_callbacks = []

    def _run(self, ctx, args, parent):
        if self.deprecated:
            self._warn_deprecated(ctx)
        if not args and self.no_args_is_help and not self.is_group:
            raise _NoArgsHelp("Missing arguments.", ctx=ctx)
        return self._run_parsed(ctx, args, parent)

    def _run_parsed(self, ctx, args, parent):
        params = self.get_params(ctx)
        parsed = _parse_for(self, ctx, args, params)
        arg_values, leftover = assign_arguments(self, ctx, parsed.leftover)
        parsed.arg_values = arg_values
        if leftover and not ctx.allow_extra_args:
            raise UsageError(f"Got unexpected extra argument(s) ({' '.join(leftover)}).", ctx)
        ctx.args = leftover
        kwargs = _resolve_for(self, ctx, parsed, params)
        with ctx:
            return self.callback(**kwargs) if self.callback is not None else None

    def _warn_deprecated(self, ctx):
        msg = f"DeprecationWarning: The command {self.name!r} is deprecated."
        if self.deprecation_note:
            msg += f" {self.deprecation_note}"
        echo(msg, err=True)

    def __repr__(self):
        return f"<Command {self.name}>"


def _parse_for(command, ctx, args, params):
    """Parse with a parameter list that may include the automatic help option."""
    saved = command.params
    command.params = params
    try:
        return parse_tokens(command, ctx, args)
    finally:
        command.params = saved


def _resolve_for(command, ctx, parsed, params):
    saved = command.params
    command.params = params
    try:
        return resolve_params(command, ctx, parsed)
    finally:
        command.params = saved


class Group(Command):
    """A command that dispatches to subcommands. # spec: N-000850..N-000865"""

    is_group = True
    interspersed_args = False

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, **kwargs):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name, no_args_is_help=no_args_is_help, **kwargs)
        self.commands = {}
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self.result_callback_func = result_callback
        for cmd in (commands or []):
            self.add_command(cmd)

    def add_command(self, cmd, name=None):
        """Register a subcommand. # spec: N-000857..N-000859"""
        if self.chain and isinstance(cmd, Group):
            raise TypeError("A chained group cannot contain nested groups.")
        self.commands[name or cmd.name] = cmd

    def command(self, *args, **kwargs):
        """Decorator registering a leaf command on this group. # spec: N-000860, N-000861"""
        return _decorator_for(self, Command, args, kwargs)

    def group(self, *args, **kwargs):
        return _decorator_for(self, Group, args, kwargs)

    def result_callback(self):
        """Decorator registering the result callback. # spec: N-000862, N-000863"""
        def decorator(f):
            self.result_callback_func = f
            return f
        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        """Look up a subcommand; overridable for lazy loading. # spec: N-000864, N-000865"""
        func = ctx.token_normalize_func
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        if func is not None:
            for name, cmd in self.commands.items():
                if func(name) == func(cmd_name):
                    return cmd
        return None

    def _run_parsed(self, ctx, args, parent):
        params = self.get_params(ctx)
        parsed = _parse_for(self, ctx, args, params)
        arg_values, leftover = assign_arguments(self, ctx, parsed.leftover)
        parsed.arg_values = arg_values
        ctx.args = leftover
        if not args and self.no_args_is_help:
            raise _NoArgsHelp("Missing command.", ctx=ctx)

        # eager flags such as --help take effect before the missing-command check. # spec: N-000157
        if not leftover:
            kwargs = _resolve_for(self, ctx, parsed, params)
            if not self.invoke_without_command:
                raise UsageError("Missing command.", ctx)
            ctx.invoked_subcommand = None
            return self._call_group(ctx, kwargs, None)

        if self.chain:
            return self._run_chain(ctx, parsed, leftover, params)

        name, rest = leftover[0], leftover[1:]
        cmd = self.get_command(ctx, name)
        kwargs = _resolve_for(self, ctx, parsed, params)
        if cmd is None:
            raise UsageError(f"No such command {name!r}.", ctx)
        ctx.invoked_subcommand = name
        self._call_group(ctx, kwargs, None)
        child_value = cmd._invoke_tokens(name, rest, ctx, {}, chained=False)
        if self.result_callback_func is not None:
            with ctx:
                return self.result_callback_func(child_value, **kwargs)
        return child_value

    def _call_group(self, ctx, kwargs, _unused):
        with ctx:
            if self.callback is None:
                return None
            return self.callback(**kwargs)

    def _run_chain(self, ctx, parsed, leftover, params):
        if self.chain and leftover and not self.get_command(ctx, leftover[0]):
            raise UsageError(f"No such command {leftover[0]!r}.", ctx)
        kwargs = _resolve_for(self, ctx, parsed, params)
        ctx.invoked_subcommand = CHAIN_MARKER
        self._call_group(ctx, kwargs, None)
        results = []
        tokens = list(leftover)
        while tokens:
            name = tokens[0]
            cmd = self.get_command(ctx, name)
            if cmd is None:
                raise UsageError(f"No such command {name!r}.", ctx)
            j = 1
            while j < len(tokens) and self.get_command(ctx, tokens[j]) is None:
                j += 1
            results.append(cmd._invoke_tokens(name, tokens[1:j], ctx, {}, chained=True))
            tokens = tokens[j:]
        if self.result_callback_func is not None:
            with ctx:
                self.result_callback_func(results, **kwargs)
        return results

    def __repr__(self):
        return f"<Group {self.name}>"


class CommandCollection(Group):
    """A group presenting the union of several groups' subcommands. # spec: N-000866, N-000867"""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources) if sources is not None else []

    def list_commands(self, ctx):
        names = set(self.commands)
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        cmd = super().get_command(ctx, cmd_name)
        if cmd is not None:
            return cmd
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


def _decorator_for(parent, cls, args, kwargs):
    """Shared implementation of the command/group decorators used on a group."""
    if args and callable(args[0]) and len(args) == 1 and not kwargs:
        child = _make_command(cls, args[0], [], {})
        parent.add_command(child)
        return child

    def decorator(f):
        child = _make_command(cls, f, args, kwargs)
        parent.add_command(child)
        return child
    return decorator


def _make_command(cls, f, args, kwargs):
    name = args[0] if args else kwargs.pop("name", None)
    cls = kwargs.pop("cls", None) or cls
    params = _take_params(f)
    attrs = dict(kwargs)
    doc = f.__doc__
    if doc is not None:
        doc = inspect.cleandoc(doc.split("\f")[0])
    attrs.setdefault("help", doc)
    name = name if name is not None else _default_name(f.__name__)
    return cls(name=name, callback=f, params=params, **attrs)


def _take_params(f):
    """Move declarations off the function and return them in declaration order. # spec: N-000085..N-000089"""
    params = getattr(f, "__optlyn_params__", [])
    try:
        del f.__optlyn_params__
    except AttributeError:
        pass
    return list(reversed(params))


def _add_param(f, param):
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)


def command(name=None, cls=None, **attrs):
    """Declare a command from a function. # spec: N-000834..N-000841"""
    if callable(name) and not attrs and cls is None:
        return _make_command(Command, name, [], {})

    def decorator(f):
        return _make_command(cls or Command, f, [name] if name is not None else [], dict(attrs))
    return decorator


def group(name=None, cls=None, **attrs):
    """Declare a group from a function. # spec: N-000850..N-000852"""
    if callable(name) and not attrs and cls is None:
        return _make_command(Group, name, [], {})
    if cls is None:
        cls = Group

    def decorator(f):
        return _make_command(cls, f, [name] if name is not None else [], dict(attrs))
    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to a function. # spec: N-000868..N-000871"""
    def decorator(f):
        _add_param(f, (cls or Option)(list(param_decls), **attrs))
        return f
    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach an argument to a function. # spec: N-000897"""
    def decorator(f):
        _add_param(f, (cls or Argument)(list(param_decls), **attrs))
        return f
    return decorator


def help_option(*param_decls, **kwargs):
    """Attach an extra eager help flag. # spec: N-000911, N-000916"""
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("callback", _help_callback)
    kwargs.setdefault("help", "Show this message and exit.")

    def decorator(f):
        _add_param(f, Option(decls, **kwargs))
        return f
    return decorator


def _version_text(version, package_name):
    if version is not None:
        return version
    if package_name is None:
        return "unknown"
    try:
        import importlib.metadata as md
    except ImportError:  # pragma: no cover
        return "unknown"
    try:
        return md.version(package_name)
    except md.PackageNotFoundError:
        try:
            dists = md.packages_distributions().get(package_name, [])
        except Exception:
            dists = []
        if dists:
            return md.version(dists[0])
        return "unknown"


def version_option(version=None, *param_decls, package_name=None, prog_name=None,
                   message=None, **kwargs):
    """Eager version flag. # spec: N-000912, N-000917, N-000918, N-000830"""
    decls = list(param_decls) or ["--version"]
    resolved = _version_text(version, package_name)

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return value
        prog = prog_name or ctx.info_name
        text = message % {"prog": prog, "package": package_name, "version": resolved} \
            if message else f"{prog}, version {resolved}"
        echo(text)
        raise Exit(0)

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("callback", callback)
    kwargs.setdefault("help", "Show the version and exit.")

    def decorator(f):
        _add_param(f, Option(decls, **kwargs))
        return f
    return decorator


def custom_version_option(callback, *param_decls, **kwargs):
    """Eager version flag whose identity is the callback's return value. # spec: N-000913, N-000919"""
    decls = list(param_decls) or ["--version"]

    def on_flag(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return value
        echo(callback(ctx))
        raise Exit(0)

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("callback", on_flag)
    kwargs.setdefault("help", "Show the version and exit.")

    def decorator(f):
        _add_param(f, Option(decls, **kwargs))
        return f
    return decorator


def password_option(*param_decls, **kwargs):
    """Prompting, hidden, confirmed option. # spec: N-000914, FP-08 (N-000500..N-000502)"""
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)

    def decorator(f):
        _add_param(f, Option(decls, **kwargs))
        return f
    return decorator


def confirmation_option(*param_decls, **kwargs):
    """Yes flag that asks when omitted and aborts on no. # spec: N-000915, FP-08 (N-000503..N-000509)"""
    decls = list(param_decls) or ["--yes"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def decorator(f):
        _add_param(f, Option(decls, **kwargs))
        return f
    return decorator


def pass_context(f):
    """Pass the current context as the first argument. # spec: N-000957"""
    from .core import get_current_context

    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)
    return _update_wrapper(new_func, f)


def pass_obj(f):
    """Pass the current context's object as the first argument. # spec: N-000958"""
    from .core import get_current_context

    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)
    return _update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    """Pass the nearest object of the given type. # spec: N-000959, FP-07 (N-000424..N-000433)"""
    from .core import get_current_context

    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            node = ctx
            found = None
            while node is not None:
                if isinstance(node.obj, object_type):
                    found = node.obj
                    break
                node = node.parent
            if found is None:
                if not ensure:
                    raise RuntimeError(
                        f"Managed to invoke callback without a context object of type "
                        f"{object_type.__name__!r} existing."
                    )
                found = object_type()
                ctx.obj = found
            return f(found, *args, **kwargs)
        return _update_wrapper(new_func, f)
    return decorator


def _update_wrapper(new_func, f):
    new_func.__name__ = f.__name__
    new_func.__doc__ = f.__doc__
    return new_func
