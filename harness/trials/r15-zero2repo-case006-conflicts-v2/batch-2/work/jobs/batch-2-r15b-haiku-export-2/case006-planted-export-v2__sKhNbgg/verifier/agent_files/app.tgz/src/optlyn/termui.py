"""Terminal helpers. # spec: FP-11 (N-000608..N-000676), Contract 7 (N-000963..N-000982)"""

import contextlib
import io
import os
import re
import subprocess
import sys
import tempfile
import time

from .exceptions import Abort

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")

_COLORS = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
    "reset": 39,
}

_SWITCHES = [
    ("bold", 1, 22), ("dim", 2, 22), ("underline", 4, 24), ("overline", 53, 55),
    ("italic", 3, 23), ("blink", 5, 25), ("reverse", 7, 27), ("strikethrough", 9, 29),
]


def _color_code(color, base):
    """Return SGR parameter string for a color. # spec: N-000618..N-000630"""
    if isinstance(color, str):
        if color not in _COLORS:
            raise TypeError(f"unknown color {color!r}")
        code = _COLORS[color]
        if color == "reset":
            return "0"
        return str(code + (10 if base == "bg" else 0))
    if isinstance(color, int) and not isinstance(color, bool):
        if not 0 <= color <= 255:
            raise TypeError(f"color index {color} out of range")
        return f"{48 if base == 'bg' else 38};5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and 0 <= c <= 255 for c in color
    ):
        return f"{48 if base == 'bg' else 38};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"invalid color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    """Wrap text in ANSI SGR sequences. # spec: N-000618..N-000630"""
    bits = []
    if fg is not None:
        bits.append(_color_code(fg, "fg"))
    if bg is not None:
        bits.append(_color_code(bg, "bg"))
    flags = dict(bold=bold, dim=dim, underline=underline, overline=overline,
                 italic=italic, blink=blink, reverse=reverse, strikethrough=strikethrough)
    for name, on, off in _SWITCHES:
        if flags[name] is not None:
            bits.append(str(on if flags[name] else off))
    if not bits:
        return str(text)
    prefix = f"\x1b[{';'.join(bits)}m"
    end = "\x1b[0m" if reset else ""
    return f"{prefix}{text}{end}"


def unstyle(text):
    """Remove ANSI sequences. # spec: N-000630"""
    return _ANSI_RE.sub("", str(text))


def _stream_is_tty(stream):
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def _should_strip(stream, color):
    if color is True:
        return False
    if color is False:
        return True
    return not _stream_is_tty(stream)


def _write(stream, text):
    try:
        stream.write(text)
    except UnicodeEncodeError:
        # ASCII-only encodings: fall back to UTF-8 bytes. # spec: N-000609
        buf = getattr(stream, "buffer", None)
        if buf is not None:
            buf.write(text.encode("utf-8"))
            buf.flush()
        else:
            stream.write(text.encode("utf-8", "replace").decode("ascii", "replace"))


def _current_color():
    from .core import get_current_context

    ctx = get_current_context(silent=True)
    return None if ctx is None else ctx.color


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes. # spec: N-000609..N-000617"""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        buf = getattr(file, "buffer", None)
        if buf is not None:
            buf.write(message + (b"\n" if nl else b""))
            buf.flush()
        else:
            file.write(message.decode("utf-8", "replace") + ("\n" if nl else ""))
        return
    if color is None:
        color = _current_color()
    text = str(message)
    if _should_strip(file, color):
        text = unstyle(text)
    if nl:
        text += "\n"
    _write(file, text)
    try:
        file.flush()
    except Exception:
        pass


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    """Echo styled text. # spec: N-000618"""
    if message is not None:
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False):
    """Ask for a value. Re-asks on conversion failure. # spec: FP-08 (N-000491..N-000512)"""
    from .paramtypes import STRING, _as_type

    ptype = STRING if type is None else _as_type(type)
    while True:
        shown = text
        if default is not None and show_default:
            shown += f" [{default}]"
        echo(shown + prompt_suffix, nl=False, err=err)
        value = _read_line(hide_input)
        if value == "" and default is not None:
            value = default
        if confirmation_prompt:
            echo("Repeat for confirmation" + prompt_suffix, nl=False, err=err)
            second = _read_line(hide_input)
            if second != value:
                echo("Error: the two entered values do not match", err=True)
                continue
        try:
            return ptype(value)
        except Exception as exc:
            echo(f"Error: {getattr(exc, 'message', exc)}", err=True)


def _read_line(hide_input=False):
    line = sys.stdin.readline()
    if line == "":
        raise Abort()
    # in-process runs echo visible answers into the captured output. # spec: N-000516
    if not hide_input and getattr(sys.stdin, "_optlyn_runner", False):
        sys.stdout.write(line if line.endswith("\n") else line + "\n")
    return line.rstrip("\r\n")


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True,
            err=False):
    """Yes/no question. # spec: FP-08 (N-000491..N-000499), N-001016"""
    suffix = " [Y/n]: " if default else " [y/N]: "
    echo(text + suffix, nl=False, err=err)
    answer = _read_line().strip().lower()
    # any answer other than yes, no or an empty line counts as no. # spec: N-001016
    if answer == "":
        value = default
    else:
        value = answer in ("y", "yes")
    if not value and abort:
        raise Abort()
    return value


def getchar(echo=False):
    """Read one character. # spec: N-000648..N-000651"""
    try:
        import termios
        import tty
    except ImportError:  # pragma: no cover
        ch = sys.stdin.read(1)
    else:
        fd = sys.stdin.fileno()
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 1).decode("utf-8", "replace")
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04" or ch == "":
        raise EOFError()
    if echo:
        echo(ch, nl=False)
    return ch


def pause(info=None, err=False):
    """Wait for a key when interactive. # spec: N-000652, N-000675"""
    if not (_stream_is_tty(sys.stdin) and _stream_is_tty(sys.stdout)):
        return
    echo(info or "Press any key to continue...", err=err, nl=False)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo("", err=err)


def clear():
    """Clear the screen when on a terminal. # spec: N-000662"""
    if not _stream_is_tty(sys.stdout):
        return
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()


def echo_via_pager(text_or_generator, color=None):
    """Write text through $PAGER when interactive. # spec: N-000631..N-000638"""
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    interactive = _stream_is_tty(sys.stdin) and _stream_is_tty(sys.stdout)
    pager = os.environ.get("PAGER")
    if not interactive or not pager:
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    proc = subprocess.Popen(pager, shell=True, stdin=subprocess.PIPE)
    try:
        for chunk in chunks:
            proc.stdin.write(str(chunk).encode("utf-8"))
            proc.stdin.flush()
    except BrokenPipeError:
        pass
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream for pager output. # spec: N-000631"""
    buf = io.StringIO()
    yield buf
    echo_via_pager(buf.getvalue(), color=color)


class ProgressBar:
    """Iterable progress bar. # spec: N-000639..N-000647"""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options):
        self.iterable = iterable
        self.length = length if length is not None else (
            len(iterable) if iterable is not None and hasattr(iterable, "__len__") else None
        )
        self.label = label
        self.hidden = hidden
        self.pos = 0
        self.start = time.time()
        self.options = options
        self.tty = (not hidden) and _stream_is_tty(sys.stdout)
        if not self.tty and not hidden and label:
            echo(label)

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)
        self._finish()

    def update(self, n_steps):
        self.pos += n_steps
        if self.tty:
            if self.length:
                pct = min(self.pos / self.length, 1.0)
                filled = int(pct * 30)
                elapsed = time.time() - self.start
                eta = (elapsed / pct - elapsed) if pct > 0 else 0
                bar = "#" * filled + "-" * (30 - filled)
                sys.stdout.write(f"\r{self.label or ''} [{bar}] {self.pos}/{self.length} eta {int(eta)}s")
            else:
                sys.stdout.write(f"\r{self.label or ''} {self.pos}")
            sys.stdout.flush()

    def _finish(self):
        if self.tty:
            sys.stdout.write("\n")
            sys.stdout.flush()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    """Context manager yielding a progress bar. # spec: N-000639"""
    bar = ProgressBar(iterable, length, label, hidden, **options)
    yield bar
    bar._finish()


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor. # spec: N-000654..N-000656"""
    editor = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    if filename is not None:
        subprocess.call(editor.split() + [str(filename)], env=env)
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text or "")
        mtime = os.path.getmtime(path)
        subprocess.call(editor.split() + [path], env=env)
        with open(path, encoding="utf-8") as f:
            result = f.read()
        if require_save and os.path.getmtime(path) == mtime and text is not None:
            return None
        return result
    finally:
        os.remove(path)


def launch(url, wait=False, locate=False):
    """Open a URL or file with the default app. # spec: N-000657..N-000661"""
    opener = "open" if sys.platform == "darwin" else "xdg-open"
    args = [opener, str(url)]
    if sys.platform == "win32":
        os.startfile(str(url))  # type: ignore[attr-defined]
        return 0
    if wait:
        return subprocess.call(args)
    subprocess.Popen(args)
    return 0


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Per-user config directory. # spec: N-000664..N-000668"""
    home = os.path.expanduser("~")
    if force_posix:
        return os.path.join(home, "." + app_name.lower().replace(" ", "-"))
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or home
        return os.path.join(base, app_name)
    config = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    folder = re.sub(r"\s+", "-", app_name.lower())
    return os.path.join(config, folder)


def format_filename(filename, shorten=False):
    """Printable filename. # spec: N-000566..N-000568"""
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = os.fspath(filename)
    text = text.encode("utf-8", "surrogateescape").decode("utf-8", "replace")
    if shorten:
        text = os.path.basename(text)
    return text


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file or standard stream. # spec: FP-09 (N-000522..N-000535)"""
    if filename == "-":
        if "r" in mode:
            return _StdStream(sys.stdin, mode, encoding)
        return _StdStream(sys.stdout, mode, encoding)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    return _open_real(filename, mode, encoding, errors, atomic)


def _open_real(filename, mode, encoding, errors, atomic):
    binary = "b" in mode
    if "w" in mode and atomic:
        directory = os.path.dirname(os.path.abspath(filename))
        fd, tmp = tempfile.mkstemp(dir=directory)
        os.close(fd)
        return _AtomicFile(tmp, filename, mode, None if binary else encoding, errors)
    if binary:
        return open(filename, mode)
    return open(filename, mode, encoding=encoding or "utf-8", errors=errors)


class _StdStream:
    """Standard stream wrapper that is not closed by a with-block. # spec: N-000579"""

    def __init__(self, stream, mode, encoding):
        self._stream = stream
        self._mode = mode

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def close(self):
        pass


class _AtomicFile:
    """Writes to a temp file, replacing the target on close. # spec: N-000535"""

    def __init__(self, tmp, target, mode, encoding, errors):
        self._tmp = tmp
        self._target = target
        self._f = open(tmp, mode, encoding=encoding, errors=errors) if encoding or "b" not in mode \
            else open(tmp, mode)
        self._closed = False

    def __getattr__(self, name):
        return getattr(self._f, name)

    def close(self):
        if not self._closed:
            self._f.close()
            os.replace(self._tmp, self._target)
            self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


class LazyFile:
    """Opens on first I/O. # spec: N-000528..N-000531"""

    def __init__(self, filename, mode, encoding, errors, atomic):
        self._args = (filename, mode, encoding, errors, atomic)
        self._f = None

    def _open(self):
        if self._f is None:
            from .exceptions import FileError

            try:
                self._f = _open_real(*self._args)
            except OSError as exc:
                raise FileError(f"Could not open file {self._args[0]!r}: {exc.strerror or exc}")
        return self._f

    def __getattr__(self, name):
        return getattr(self._open(), name)

    def write(self, data):
        return self._open().write(data)

    def read(self, *a):
        return self._open().read(*a)

    def close(self):
        if self._f is not None:
            self._f.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False
