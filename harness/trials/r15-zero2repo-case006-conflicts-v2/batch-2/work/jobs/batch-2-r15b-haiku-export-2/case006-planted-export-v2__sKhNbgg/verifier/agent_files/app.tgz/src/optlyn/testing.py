"""In-process runner. # spec: Contract 9 (N-001006..N-001012), FP-14 (N-000724..N-000749)"""

import contextlib
import io
import os
import shutil
import sys
import tempfile


class _CaptureSink:
    """Holds one captured stream's text and bytes, and the combined write order."""

    def __init__(self, combined):
        self.text = []
        self.raw = []
        self.combined = combined


class _CaptureStream(io.TextIOBase):
    encoding = "utf-8"
    errors = "strict"

    def __init__(self, sink):
        super().__init__()
        self._sink = sink
        self.buffer = _CaptureBuffer(self)

    def writable(self):
        return True

    def readable(self):
        return False

    def isatty(self):
        return False

    def write(self, s):
        if isinstance(s, bytes):
            return self.buffer.write(s)
        self._sink.text.append(s)
        self._sink.combined.append(s)
        return len(s)

    def _write_bytes(self, data):
        text = data.decode("utf-8", "replace")
        self._sink.raw.append(data)
        self._sink.text.append(text)
        self._sink.combined.append(text)
        return len(data)

    def flush(self):
        pass


class _CaptureBuffer(io.RawIOBase):
    def __init__(self, owner):
        super().__init__()
        self._owner = owner

    def writable(self):
        return True

    def write(self, data):
        return self._owner._write_bytes(bytes(data))

    def flush(self):
        pass


class _RunnerStdin(io.StringIO):
    """Standard input for a run; visible prompt answers are echoed. # spec: N-000515..N-000517"""

    _optlyn_runner = True

    def isatty(self):
        return False


class Result:
    """Outcome of one in-process invocation. # spec: Contract 9 Result (N-001007..N-001011)"""

    def __init__(self, runner, stdout_sink, stderr_sink, combined, exit_code, exception):
        self.runner = runner
        self.exit_code = exit_code
        self.exception = exception
        self.stdout_bytes = b"".join(stdout_sink.raw) or "".join(stdout_sink.text).encode("utf-8")
        self.stderr_bytes = b"".join(stderr_sink.raw) or "".join(stderr_sink.text).encode("utf-8")
        self.stdout = "".join(stdout_sink.text)
        self.stderr = "".join(stderr_sink.text)
        self.output = "".join(combined)

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invoke a command with tokens and capture its output. # spec: Contract 9"""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        combined = []
        out_sink = _CaptureSink(combined)
        err_sink = _CaptureSink(combined)
        stdout = _CaptureStream(out_sink)
        stderr = _CaptureStream(err_sink)
        if input is None:
            data = ""
        elif isinstance(input, bytes):
            data = input.decode(self.charset, "replace")
        else:
            data = str(input)
        stdin = _RunnerStdin(data)
        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {}
        for key, value in merged_env.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        saved = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield out_sink, err_sink, combined
        finally:
            sys.stdin, sys.stdout, sys.stderr = saved
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        """Run cli with args and return a Result. # spec: Contract 9 invoke"""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            import shlex

            args = shlex.split(args)
        standalone = extra.pop("standalone_mode", True)
        prog_name = extra.pop("prog_name", None) or "cli"
        exit_code = 0
        exception = None
        with self.isolation(input=input, env=env, color=color) as (out_sink, err_sink, combined):
            settings = dict(extra)
            settings["color"] = color
            try:
                cli.main(args=list(args), prog_name=prog_name, standalone_mode=standalone,
                         **settings)
            except SystemExit as exc:
                code = exc.code
                exit_code = code if isinstance(code, int) else (0 if code is None else 1)
                if code not in (None, 0) and not isinstance(code, int):
                    combined.append(str(code))
            except Exception as exc:  # noqa: BLE001 - reported on the result
                if not catch_exceptions:
                    raise
                exception = exc
                exit_code = 1
        return Result(self, out_sink, err_sink, combined, exit_code, exception)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Run inside a new empty directory. # spec: N-001012, N-001015, N-000731..N-000733"""
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(path, ignore_errors=True)
