"""Token parsing and value resolution.

# spec: FP-01 (N-000094..N-000102), FP-03 (N-000165..N-000272),
#       FP-04 (N-000273..N-000317), FP-07 (N-000434..N-000452), FP-08 (N-000478..N-000514)
"""

import os

from . import paramtypes as _types
from .core import OMITTED, Argument, Option, ParameterSource
from .exceptions import BadParameter, MissingParameter, NoSuchOption, UsageError

_BOOL_TRUE = {"true", "1", "yes", "on", "t", "y"}
_BOOL_FALSE = {"false", "0", "no", "off", "f", "n"}
_PROMPT = object()  # option flag given without a value


def _norm(ctx, name):
    func = ctx.token_normalize_func
    return func(name) if func else name


def _build_lookup(command, ctx):
    """Map each option name to (param, mode, value). # spec: N-000175..N-000193"""
    lookup = {}
    for p in command.params:
        if not isinstance(p, Option):
            continue
        if p.count:
            for n in p.opts:
                lookup[_norm(ctx, n)] = (p, "flag", 1)
            continue
        if p.is_flag:
            for n in p.opts:
                lookup[_norm(ctx, n)] = (p, "flag", p.flag_value if not p.secondary_opts else True)
            for n in p.secondary_opts:
                lookup[_norm(ctx, n)] = (p, "flag", False)
            continue
        mode = "optval" if p.flag_value is not None else "value"
        for n in p.opts:
            lookup[_norm(ctx, n)] = (p, mode, None)
    return lookup


def _looks_like_option(tok, prefixes):
    return len(tok) > 1 and tok[0] in prefixes


def _is_long(tok, prefixes):
    return len(tok) > 2 and tok[0] in prefixes and tok[1] in prefixes


class ParseResult:
    def __init__(self):
        self.occurrences = {}  # name -> [(index, value)]
        self.arg_values = {}  # name -> raw token(s) or OMITTED
        self.leftover = []


def parse_tokens(command, ctx, args):
    """Split tokens into option occurrences, argument values, and leftovers."""
    from .commands import Group

    lookup = _build_lookup(command, ctx)
    prefixes = {n[0] for n in lookup} | {"-"}
    result = ParseResult()
    positional = []
    interspersed = getattr(command, "interspersed_args", True)
    args = list(args)
    n = len(args)
    i = 0
    stop = False

    def record(p, idx, value):
        result.occurrences.setdefault(p.name, []).append((idx, value))

    def take_value(p, idx, nxt, inline):
        """Consume the value tokens of a value-taking option. Returns next index."""
        if inline is not None:
            record(p, idx, inline if p.nargs == 1 else tuple([inline]))
            return nxt
        width = p.per_occurrence_arity
        if p.flag_value is not None and not p.is_flag:
            if nxt < n and not (args[nxt] == "--" or _looks_like_option(args[nxt], prefixes)):
                record(p, idx, args[nxt])
                return nxt + 1
            record(p, idx, p.flag_value)
            return nxt
        if nxt + width <= n and width >= 1:
            chunk = args[nxt:nxt + width]
            record(p, idx, chunk[0] if width == 1 else tuple(chunk))
            return nxt + width
        if p.prompt:
            record(p, idx, _PROMPT)
            return nxt
        raise UsageError(f"Option {p.get_error_hint()} requires {width} argument(s).", ctx)

    while i < n:
        tok = args[i]
        if stop:
            positional.append(tok)
            i += 1
            continue
        if tok == "--":
            stop = True
            i += 1
            continue
        if not _looks_like_option(tok, prefixes):
            if isinstance(command, Group) and not interspersed:
                positional.extend(args[i:])
                break
            positional.append(tok)
            i += 1
            continue

        if _is_long(tok, prefixes):
            name, eq, val = tok.partition("=")
            hit = lookup.get(_norm(ctx, name))
            if hit is None:
                if ctx.ignore_unknown_options:
                    positional.append(tok)
                    i += 1
                    continue
                raise NoSuchOption(f"No such option: {name}", ctx)
            p, mode, value = hit
            if mode == "flag":
                if eq:
                    raise UsageError(f"Option {name} does not take a value.", ctx)
                record(p, i, value)
                i += 1
                continue
            i = take_value(p, i, i + 1, val if eq else None)
            continue

        # short option stack: -abc, or -nVALUE
        j = 1
        next_i = i + 1
        while j < len(tok):
            key = tok[0] + tok[j]
            hit = lookup.get(_norm(ctx, key))
            if hit is None:
                if ctx.ignore_unknown_options:
                    positional.append(tok[0] + tok[j:])
                    break
                raise NoSuchOption(f"No such option: {key}", ctx)
            p, mode, value = hit
            if mode == "flag":
                record(p, i, value)
                j += 1
                continue
            rest = tok[j + 1:]
            next_i = take_value(p, i, i + 1, rest if rest else None)
            break
        i = next_i

    result.leftover = positional
    return result


def assign_arguments(command, ctx, tokens):
    """Bind positional tokens to declared arguments. # spec: N-000273..N-000291"""
    args = list(command.arguments)
    out = {}
    idx = 0
    for k, a in enumerate(args):
        later_min = sum(
            b.per_occurrence_arity for b in args[k + 1:] if b.required and not b.variadic
        )
        avail = len(tokens) - idx
        # A missing required argument is reported by resolve_params, after eager flags such as --help. # spec: N-000309
        if a.variadic:
            take = max(0, avail - later_min)
            if take == 0:
                out[a.name] = OMITTED
            else:
                out[a.name] = list(tokens[idx:idx + take])
                idx += take
            continue
        width = a.per_occurrence_arity
        if avail - (0 if a.required else later_min) >= width and avail >= width:
            chunk = tokens[idx:idx + width]
            idx += width
            out[a.name] = chunk[0] if (width == 1 and not isinstance(a.type, _types.Tuple)) else tuple(chunk)
        else:
            out[a.name] = OMITTED
    return out, tokens[idx:]


def _env_flag(p, text):
    """Interpret an env value for a boolean flag. # spec: N-000221..N-000229"""
    stripped = text.strip().lower()
    if stripped == "":
        return None
    if p.flag_value not in (True, False, None) and text == str(p.flag_value):
        return p.flag_value
    if stripped in _BOOL_TRUE:
        return True
    if stripped in _BOOL_FALSE:
        return False
    raise BadParameter(f"{text!r} is not a valid boolean.", param=p)


def _env_names(p, ctx):
    names = list(p.envvar)
    if isinstance(p, Option) and p.allow_from_autoenv and ctx.auto_envvar_prefix and not p.secondary_opts:
        parts = list(ctx.env_parts) + [p.name]
        auto = "_".join([ctx.auto_envvar_prefix] + parts)
        names.append(auto.upper().replace("-", "_"))
    return names


def _convert_default_value(p, value, ctx, from_map):
    """Convert a default-map or declared default value. # spec: N-000446..N-000452, N-000263"""
    if p.multiple:
        if isinstance(value, str) or not isinstance(value, (list, tuple)):
            raise UsageError(
                f"The default for {p.get_error_hint()} must be an iterable (sequence) of values.",
                ctx,
            )
        return tuple(p.convert_one(v, ctx) for v in value)
    if from_map and isinstance(value, str) and p.per_occurrence_arity != 1:
        value = tuple(p.split_env(value))
    if isinstance(value, (list, tuple)) and p.per_occurrence_arity != 1:
        return p.convert_one(tuple(value), ctx)
    return p.convert_one(value, ctx)


def _prompt_text(p):
    if isinstance(p.prompt, str):
        return p.prompt
    return p.name.replace("_", " ").capitalize()


def _resolve_one(ctx, p, occ, raw):
    """Return (value, source) for one parameter. # spec: N-000230..N-000252"""
    from . import termui

    # 1. command line
    cmdline_prompt = False
    if isinstance(p, Option):
        cmdline_prompt = any(v is _PROMPT for _, v in occ)
        if occ:
            if p.count:
                return sum(v for _, v in occ), ParameterSource.COMMANDLINE
            if p.is_flag:
                return occ[-1][1], ParameterSource.COMMANDLINE
            if p.multiple:
                vals = [v for _, v in occ if v is not _PROMPT]
                if vals:
                    return tuple(p.convert_one(v, ctx) for v in vals), ParameterSource.COMMANDLINE
            elif not cmdline_prompt:
                return p.convert_one(occ[-1][1], ctx), ParameterSource.COMMANDLINE
    elif raw is not OMITTED and raw is not None:
        if isinstance(raw, list):
            return tuple(p.convert_one(v, ctx) for v in raw), ParameterSource.COMMANDLINE
        return p.convert_one(raw, ctx), ParameterSource.COMMANDLINE

    # 2. environment
    for name in _env_names(p, ctx):
        text = os.environ.get(name)
        if text is None or text == "":
            continue
        if p.is_flag:
            flag = _env_flag(p, text)
            if flag is None:
                continue
            return flag, ParameterSource.ENVIRONMENT
        if p.multiple or p.per_occurrence_arity != 1:
            parts = p.split_env(text)
            if not parts:
                continue
            if p.multiple:
                return tuple(p.convert_one(v, ctx) for v in parts), ParameterSource.ENVIRONMENT
            return p.convert_one(tuple(parts), ctx), ParameterSource.ENVIRONMENT
        return p.convert_one(text, ctx), ParameterSource.ENVIRONMENT

    # map and declared default, used both as plain sources and as prompt defaults
    dm = ctx.default_map
    map_value = dm.get(p.name) if isinstance(dm, dict) and p.name in dm else None
    has_map = isinstance(dm, dict) and p.name in dm
    declared = p.default() if callable(p.default) else p.default

    # 3. prompt
    if isinstance(p, Option) and p.prompt and (cmdline_prompt or p.prompt_required):
        shown_default = map_value if has_map else declared
        if p.is_flag:
            ok = termui.confirm(_prompt_text(p), default=False, abort=True)
            return ok, ParameterSource.PROMPT
        if shown_default is not None and not isinstance(shown_default, str):
            shown_default = (
                ", ".join(str(v) for v in shown_default)
                if isinstance(shown_default, (list, tuple)) else shown_default
            )
        value = termui.prompt(
            _prompt_text(p),
            default=shown_default,
            hide_input=p.hide_input,
            confirmation_prompt=p.confirmation_prompt,
            type=p.type,
        )
        return value, ParameterSource.PROMPT

    # 4. default map
    if has_map and map_value is not None:
        return _convert_default_value(p, map_value, ctx, from_map=True), ParameterSource.DEFAULT_MAP

    # 5. declared default
    if declared is not None:
        return _convert_default_value(p, declared, ctx, from_map=False), ParameterSource.DEFAULT

    if p.multiple or p.variadic:
        return (), None
    return None, None


def resolve_params(command, ctx, parsed):
    """Fill ctx.params, run callbacks, and return the callback kwargs. # spec: FP-03, Contract 4"""
    occ = parsed.occurrences
    raw = parsed.arg_values
    eager = []
    for p in command.params:
        if p.is_eager and occ.get(p.name):
            eager.append((min(i for i, _ in occ[p.name]), p))
    eager.sort(key=lambda t: t[0])
    eager_params = [p for _, p in eager]
    order = eager_params + [p for p in command.params if p not in eager_params]

    kwargs = {}
    for p in order:
        p_occ = occ.get(p.name, [])
        p_raw = raw.get(p.name, OMITTED) if isinstance(p, Argument) else OMITTED
        value, source = _resolve_one(ctx, p, p_occ, p_raw)
        if source is None and p.required:
            raise MissingParameter("missing", ctx=ctx, param=p)
        if p.deprecated and source is ParameterSource.COMMANDLINE:
            _warn_deprecated(p, ctx)
        if p.callback is not None and source is not None:
            value = p.callback(ctx, p, value)
        ctx._sources[p.name] = source or ParameterSource.DEFAULT
        if p.expose_value:
            ctx.params[p.name] = value
            kwargs[p.name] = value
    return kwargs


def _warn_deprecated(p, ctx):
    from .termui import echo

    kind = "Option" if isinstance(p, Option) else "Argument"
    label = p.get_error_hint()
    msg = f"DeprecationWarning: {kind} {label!r} is deprecated."
    note = getattr(p, "deprecation_note", None)
    if note:
        msg += f" {note}"
    echo(msg, err=True)
