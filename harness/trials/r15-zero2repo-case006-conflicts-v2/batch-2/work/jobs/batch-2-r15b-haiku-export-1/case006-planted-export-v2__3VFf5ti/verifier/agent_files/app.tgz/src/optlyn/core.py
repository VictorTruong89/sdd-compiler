"""Contexts, parameters, parsing, dispatch and help pages."""

import enum
import inspect
import os
import re
import shutil
import sys
import textwrap
import typing as t

from . import termui
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingCommand,
    MissingParameter,
    NoArgsIsHelp,
    NoSuchCommand,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import rewrap_help
from .globals import pop_context, push_context
from .paramtypes import BOOL, INT, STRING, Choice, ParamType, Tuple, convert_type
from .utils import echo

CHAIN_SENTINEL = "*"

_TRUE_WORDS = {"1", "true", "t", "yes", "y", "on"}
_FALSE_WORDS = {"0", "false", "f", "no", "n", "off"}
_SENTENCE_RE = re.compile(r".*?[.!?](?=\s|$)")


class ParameterSource(enum.Enum):
    """Where a parameter's value came from."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


_TIER = {
    ParameterSource.PROMPT: 5,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.ENVIRONMENT: 3,
    ParameterSource.DEFAULT_MAP: 2,
    ParameterSource.DEFAULT: 1,
}

_MAP_SETTINGS = {
    "auto_envvar_prefix": None,
    "terminal_width": None,
    "max_content_width": 80,
    "help_option_names": None,
    "token_normalize_func": None,
    "color": None,
    "show_default": False,
    "ignore_unknown_options": False,
}


class Context:
    """The state of one invocation of a command.

    Built by the library. Settings come from ``main(**extra)``, from the
    command's ``context_settings`` and from the parent context.
    """

    def __init__(
        self,
        command: "Command",
        parent: t.Optional["Context"] = None,
        info_name: t.Optional[str] = None,
        obj: t.Any = None,
        default_map: t.Optional[t.Dict[str, t.Any]] = None,
        **settings: t.Any,
    ) -> None:
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.params: t.Dict[str, t.Any] = {}
        self._sources: t.Dict[str, ParameterSource] = {}
        self._ranks: t.Dict[str, t.Tuple[int, int, int]] = {}
        self.invoked_subcommand: t.Optional[str] = None
        self.resilient_parsing = False
        self._rest: t.List[str] = []
        self._close_callbacks: t.List[t.Callable[[], t.Any]] = []
        self._depth = 0

        merged = dict(command.context_settings)
        merged.update({k: v for k, v in settings.items() if v is not None})

        def inherit(key: str) -> t.Any:
            if merged.get(key) is not None:
                return merged[key]
            if parent is not None:
                return getattr(parent, key)
            return _MAP_SETTINGS[key]

        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.auto_envvar_prefix = inherit("auto_envvar_prefix")
        self.terminal_width = inherit("terminal_width")
        self.max_content_width = inherit("max_content_width")
        self.help_option_names = list(inherit("help_option_names") or ["--help"])
        self.token_normalize_func = inherit("token_normalize_func")
        self.color = inherit("color")
        self.show_default = inherit("show_default")
        self.ignore_unknown_options = inherit("ignore_unknown_options")
        self.allow_extra_args = merged.get("allow_extra_args", command.allow_extra_args)
        self.allow_interspersed_args = merged.get(
            "allow_interspersed_args", command.allow_interspersed_args
        )
        if default_map is None:
            default_map = merged.get("default_map")
        self.default_map = default_map

    # -- structure -------------------------------------------------------

    @property
    def command_path(self) -> str:
        parts = []
        node: t.Optional[Context] = self
        while node is not None:
            if node.info_name:
                parts.append(node.info_name)
            node = node.parent
        return " ".join(reversed(parts))

    def find_root(self) -> "Context":
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type: type) -> t.Any:
        node: t.Optional[Context] = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type: type) -> t.Any:
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    # -- scope and cleanup ----------------------------------------------

    def __enter__(self) -> "Context":
        self._depth += 1
        push_context(self)
        return self

    def __exit__(self, *exc_info: t.Any) -> None:
        self._depth -= 1
        pop_context()

    def call_on_close(self, func: t.Callable[[], t.Any]) -> t.Callable[[], t.Any]:
        self._close_callbacks.append(func)
        return func

    def with_resource(self, cm: t.Any) -> t.Any:
        value = cm.__enter__()
        self.call_on_close(lambda: cm.__exit__(None, None, None))
        return value

    def close(self) -> None:
        callbacks, self._close_callbacks = self._close_callbacks, []
        for func in reversed(callbacks):
            func()

    # -- control ----------------------------------------------------------

    def exit(self, code: int = 0) -> t.NoReturn:
        raise Exit(code)

    def abort(self) -> t.NoReturn:
        raise Abort()

    def get_parameter_source(self, name: str) -> t.Optional[ParameterSource]:
        if name not in {p.name for p in self.command.get_params(self)}:
            return None
        return self._sources.get(name)

    def get_help(self) -> str:
        return self.command.get_help(self)

    def get_usage(self) -> str:
        return self.command.get_usage(self)

    def get_wrap_width(self) -> int:
        if self.terminal_width is not None:
            return self.terminal_width
        try:
            columns = shutil.get_terminal_size((80, 24)).columns
        except OSError:
            columns = 80
        return min(columns, self.max_content_width)

    def invoke(self, callback: t.Any, *args: t.Any, **kwargs: t.Any) -> t.Any:
        """Run a command or a plain function from inside a callback.

        A command runs with the given values; missing parameters take their
        declared defaults. A plain function is called with the given arguments.
        """
        if isinstance(callback, Command):
            child = Context(callback, parent=self, info_name=callback.name)
            for param in callback.params:
                if param.expose_value and param.name not in kwargs:
                    kwargs[param.name] = param.get_default(child)
            child.params.update(kwargs)
            return callback.invoke(child)
        with self:
            return callback(*args, **kwargs)

    def forward(self, cmd: "Command", *args: t.Any, **kwargs: t.Any) -> t.Any:
        """Run ``cmd`` with this context's current values plus ``kwargs``."""
        merged = dict(self.params)
        merged.update(kwargs)
        return self.invoke(cmd, *args, **merged)



class Parameter:
    """Shared behaviour of options and arguments."""

    param_kind = "parameter"
    is_flag = False
    count = False
    optional_value = False

    def __init__(self, name: str, **attrs: t.Any) -> None:
        self.name = name
        self.opts: t.List[str] = []
        self.secondary_opts: t.List[str] = []
        self.type: ParamType = STRING
        self.default: t.Any = None
        self.default_explicit = False
        self.required = False
        self.callback: t.Optional[t.Callable[..., t.Any]] = None
        self.nargs = 1
        self.multiple = False
        self.metavar: t.Optional[str] = None
        self.expose_value = True
        self.is_eager = False
        self.envvar: t.Optional[t.List[str]] = None
        self.allow_from_autoenv = True
        self.shell_complete_func: t.Optional[t.Callable[..., t.Any]] = None
        self.deprecated = False
        self.deprecation_note: t.Optional[str] = None
        self.hidden = False
        self.help: t.Optional[str] = None
        self.show_default: t.Any = None
        self.show_envvar = False
        self.prompt: t.Optional[str] = None
        self.prompt_required = False
        self.hide_input = False
        self.confirmation_prompt = False
        self.flag_value: t.Any = None

    # -- helpers used by callers and messages -----------------------------

    @property
    def identity(self) -> str:
        return self.name

    def get_error_hint(self, ctx: t.Any = None) -> str:
        raise NotImplementedError

    def get_default(self, ctx: t.Any, call: bool = True) -> t.Any:
        default = self.default
        if callable(default) and not isinstance(default, type):
            return default() if call else default
        return default

    def _auto_env_name(self, ctx: "Context") -> t.Optional[str]:
        prefix = ctx.auto_envvar_prefix
        if not prefix:
            return None
        chain: t.List[str] = []
        node: t.Optional[Context] = ctx
        while node is not None and node.parent is not None:
            chain.append(node.info_name or "")
            node = node.parent
        parts = [prefix] + list(reversed(chain)) + [self.name]
        return "_".join(p.replace("-", "_") for p in parts if p).upper()

    def get_envvar_names(self, ctx: "Context") -> t.List[str]:
        names = list(self.envvar or [])
        if self.allow_from_autoenv and self.param_kind == "option":
            auto = self._auto_env_name(ctx)
            if auto and auto not in names:
                names.append(auto)
        return names

    def _env_raw(self, ctx: "Context") -> t.Optional[str]:
        for name in self.get_envvar_names(ctx):
            value = os.environ.get(name)
            if value is not None and value != "":
                return value
        return None

    def _env_flag(self, ctx: "Context", raw: str) -> t.Any:
        text = raw.strip().lower()
        flag_value = self.flag_value
        is_bool_flag = isinstance(flag_value, bool)
        if not is_bool_flag and raw.strip() == str(flag_value):
            return flag_value
        if text in _TRUE_WORDS:
            return flag_value if not is_bool_flag else True
        if text in _FALSE_WORDS or text == "":
            return False if is_bool_flag else None
        if is_bool_flag:
            raise BadParameter(f"{raw!r} is not a valid boolean.", ctx=ctx, param=self)
        return None

    def _chunk(self, tokens: t.List[str], ctx: "Context") -> t.List[t.Tuple[t.Any, ...]]:
        if self.nargs == -1:
            return [tuple(tokens)] if tokens else []
        n = self.nargs
        if self.multiple:
            if len(tokens) % n:
                raise BadOptionUsage(
                    f"{self.get_error_hint(ctx)} takes {n} values per occurrence.", ctx
                )
            return [tuple(tokens[i : i + n]) for i in range(0, len(tokens), n)]
        if len(tokens) != n:
            raise BadOptionUsage(f"{self.get_error_hint(ctx)} takes {n} values.", ctx)
        return [tuple(tokens)]

    def _as_occurrence(self, value: t.Any, ctx: "Context") -> t.Tuple[t.Any, ...]:
        if self.nargs > 1 or isinstance(self.type, Tuple):
            if isinstance(value, (str, bytes)) or not isinstance(value, (list, tuple)):
                raise BadOptionUsage(
                    f"{self.get_error_hint(ctx)} needs a sequence of {self.nargs} values.", ctx
                )
            return tuple(value)
        return (value,)

    def _occurrences_from_value(self, value: t.Any, ctx: "Context", from_map: bool) -> t.List[t.Any]:
        if self.multiple:
            if isinstance(value, (str, bytes)) or not isinstance(value, (list, tuple)):
                raise BadOptionUsage(
                    f"{self.get_error_hint(ctx)} needs an iterable (sequence) default, "
                    "not a single value.",
                    ctx,
                )
            return [self._as_occurrence(v, ctx) for v in value]
        if isinstance(value, str) and (self.nargs > 1 or isinstance(self.type, Tuple)):
            return self._chunk(self.type.split_envvar_value(value), ctx)
        return [self._as_occurrence(value, ctx)]

    def _shape(self, ctx: "Context", occurrences: t.List[t.Tuple[t.Any, ...]]) -> t.Any:
        if self.nargs == -1:
            flat: t.List[t.Any] = []
            for occ in occurrences:
                flat.extend(occ)
            return tuple(self.type.convert(v, self, ctx) for v in flat)
        converted = []
        for occ in occurrences:
            if isinstance(self.type, Tuple):
                converted.append(self.type.convert(occ, self, ctx))
            elif self.nargs > 1:
                converted.append(tuple(self.type.convert(v, self, ctx) for v in occ))
            else:
                converted.append(self.type.convert(occ[0], self, ctx))
        if self.multiple:
            return tuple(converted)
        if not converted:
            return None
        return converted[-1]

    def _env_value(self, ctx: "Context") -> t.Tuple[bool, t.Any]:
        """Return (supplied, value) for the environment source."""
        raw = self._env_raw(ctx)
        if raw is None:
            return False, None
        if self.is_flag:
            value = self._env_flag(ctx, raw)
            return (value is not None), value
        if self.nargs == 1 and not self.multiple and not isinstance(self.type, Tuple):
            occurrences = [(raw,)]
        else:
            tokens = self.type.split_envvar_value(raw)
            if not tokens:
                return False, None
            occurrences = self._chunk(tokens, ctx)
        return True, self._shape(ctx, occurrences)

    def _map_occurrences(self, ctx: "Context") -> t.Optional[t.List[t.Any]]:
        mapping = ctx.default_map
        if not isinstance(mapping, dict) or self.name not in mapping:
            return None
        value = mapping[self.name]
        if self.is_flag or self.count:
            return [("const", value)]
        return self._occurrences_from_value(value, ctx, from_map=True)

    def _default_value(self, ctx: "Context") -> t.Tuple[bool, t.Any]:
        """Return (supplied, value) for the declared default."""
        value = self.get_default(ctx)
        if value is None:
            return False, None
        if self.is_flag or self.count:
            return True, value
        return True, self._shape(ctx, self._occurrences_from_value(value, ctx, from_map=False))

    def _prompt_text(self) -> str:
        if isinstance(self.prompt, str) and self.prompt:
            return self.prompt
        return self.name.replace("_", " ").capitalize()

    def _prompt_value(self, ctx: "Context", default: t.Any) -> t.Any:
        if self.is_flag:
            return termui.confirm(self._prompt_text(), default=bool(default))
        if callable(default):
            default = default()
        if self.multiple or self.nargs > 1 or isinstance(self.type, Tuple):
            default = None
        answer = termui.prompt(
            self._prompt_text(),
            default=default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            type=self.type,
        )
        if self.multiple:
            return (answer,)
        return answer

    def process(self, ctx: "Context", occurrences: t.Optional[t.List[t.Any]]) -> t.Tuple[t.Any, t.Optional[ParameterSource]]:
        """Resolve the value of this parameter and where it came from."""
        occurrences = list(occurrences or [])
        marker = any(occ[0] == "prompt" for occ in occurrences if isinstance(occ, tuple))

        if self.is_flag:
            consts = [occ for occ in occurrences if occ[0] == "const"]
            if consts:
                return consts[-1][1], ParameterSource.COMMANDLINE
            supplied, value = self._env_value(ctx)
            if supplied:
                return value, ParameterSource.ENVIRONMENT
            if self.prompt is not None:
                return self._prompt_value(ctx, self.get_default(ctx)), ParameterSource.PROMPT
        elif self.count:
            counted = [occ for occ in occurrences if occ[0] == "count"]
            if counted:
                return len(counted), ParameterSource.COMMANDLINE
        else:
            tokens = [occ[1] if occ[0] == "tokens" else (occ[1],) for occ in occurrences if occ[0] in ("tokens", "const")]
            if tokens:
                return self._shape(ctx, tokens), ParameterSource.COMMANDLINE
            supplied, value = self._env_value(ctx)
            if supplied:
                return value, ParameterSource.ENVIRONMENT

        map_occurrences = self._map_occurrences(ctx)
        if self.prompt is not None and not self.is_flag and (
            marker or ((self.required or self.prompt_required) and map_occurrences is None)
        ):
            if map_occurrences is not None:
                default = self._shape(ctx, map_occurrences)
            else:
                default = self.get_default(ctx)
            return self._prompt_value(ctx, default), ParameterSource.PROMPT

        if map_occurrences is not None:
            if self.is_flag or self.count:
                return map_occurrences[-1][1], ParameterSource.DEFAULT_MAP
            return self._shape(ctx, map_occurrences), ParameterSource.DEFAULT_MAP

        supplied, value = self._default_value(ctx)
        if supplied:
            return value, ParameterSource.DEFAULT
        return None, None

    def _rank(self, source: t.Optional[ParameterSource], index: int) -> t.Tuple[int, int, int]:
        if source is None:
            return (0, 0, index)
        explicit = 1 if (source is ParameterSource.DEFAULT and self.default_explicit) else 0
        return (_TIER[source], explicit, index)


class Option(Parameter):
    """A named parameter, given as ``--flag``, ``-f`` or ``--name VALUE``."""

    param_kind = "option"

    def __init__(self, param_decls: t.Sequence[str], **attrs: t.Any) -> None:
        dest, opts, secondary = _parse_option_decls(param_decls)
        if dest is None:
            dest = _infer_dest(opts)
        super().__init__(dest, **{})
        self.opts = opts
        self.secondary_opts = secondary
        if not self.opts and not self.secondary_opts:
            raise TypeError("An option needs at least one flag name.")

        flag_value = attrs.pop("flag_value", None)
        is_flag = attrs.pop("is_flag", None)
        count = bool(attrs.pop("count", False))
        default = attrs.pop("default", None)
        type_arg = attrs.pop("type", None)
        nargs = attrs.pop("nargs", None)
        self.multiple = bool(attrs.pop("multiple", False))
        required = bool(attrs.pop("required", False))
        prompt = attrs.pop("prompt", None)
        self.prompt_required = bool(attrs.pop("prompt_required", False))
        self.hide_input = bool(attrs.pop("hide_input", False))
        self.confirmation_prompt = bool(attrs.pop("confirmation_prompt", False))
        self.allow_from_autoenv = bool(attrs.pop("allow_from_autoenv", True))
        self.envvar = _listify(attrs.pop("envvar", None))

        if is_flag is None:
            if self.secondary_opts or flag_value is not None:
                is_flag = True
            else:
                is_flag = isinstance(default, bool) and not self.multiple
        if count and is_flag:
            raise TypeError("A counting option cannot also be a flag.")
        if count and self.multiple:
            raise TypeError("A counting option cannot be repeatable.")

        self.is_flag = bool(is_flag)
        self.count = count
        self.optional_value = (not self.is_flag) and flag_value is not None and not count
        self.default_explicit = default is not None
        if self.is_flag:
            self.flag_value = True if flag_value is None else flag_value
            if default is None and isinstance(self.flag_value, bool):
                default = False
        elif self.optional_value:
            self.flag_value = flag_value
        if count and default is None:
            default = 0
        self.default = default

        if self.is_flag or count:
            nargs = 1
        elif nargs is None:
            nargs = type_arg.arity if isinstance(type_arg, Tuple) else 1
        if not isinstance(nargs, int) or nargs < 1:
            raise TypeError("'nargs' must be a positive integer for options.")
        self.nargs = nargs

        if type_arg is None:
            if self.is_flag:
                self.type = BOOL
            elif count:
                self.type = INT
            else:
                self.type = convert_type(None, default)
        else:
            self.type = convert_type(type_arg, default)
        if isinstance(self.type, Tuple) and nargs != self.type.arity:
            raise TypeError("A tuple type's length must match 'nargs'.")

        self.required = required
        self.prompt = _prompt_text_option(prompt)
        if self.prompt is not None and not self.prompt and self.is_flag:
            self.prompt = "Do you want to continue?"

        self.callback = attrs.pop("callback", None)
        self.is_eager = bool(attrs.pop("is_eager", False))
        self.expose_value = bool(attrs.pop("expose_value", True))
        self.hidden = bool(attrs.pop("hidden", False))
        deprecated = attrs.pop("deprecated", False)
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None
        self.help = attrs.pop("help", None)
        self.metavar = attrs.pop("metavar", None)
        self.show_default = attrs.pop("show_default", None)
        self.show_envvar = bool(attrs.pop("show_envvar", False))
        self.shell_complete_func = attrs.pop("shell_complete", None)
        if attrs:
            raise TypeError(f"Unknown option keyword(s): {', '.join(sorted(attrs))}")

        if self.deprecated and self.required:
            raise TypeError("A deprecated option cannot also be required.")
        if self.deprecated and self.prompt is not None:
            raise TypeError("A deprecated option cannot use a prompt.")

    def get_error_hint(self, ctx: t.Any = None) -> str:
        return " / ".join(f"'{n}'" for n in self.opts + self.secondary_opts)

    def get_help_metavar(self) -> t.Optional[str]:
        if self.is_flag or self.count:
            return None
        if self.optional_value:
            return f"[{self.metavar or self.name.upper()}]"
        if self.metavar is not None:
            return self.metavar
        if isinstance(self.type, Choice):
            return self.type.get_metavar()
        if isinstance(self.type, Tuple):
            return self.type.get_metavar()
        base = self.name.upper()
        if self.nargs > 1:
            return " ".join([base] * self.nargs)
        return base

    def flag_value_for(self, role: str) -> t.Any:
        if role == "off":
            return False
        return self.flag_value


class Argument(Parameter):
    """A positional parameter bound in declaration order."""

    param_kind = "argument"

    def __init__(self, param_decls: t.Sequence[str], **attrs: t.Any) -> None:
        if len(param_decls) != 1 or not str(param_decls[0]).isidentifier():
            raise TypeError("An argument takes exactly one destination name.")
        super().__init__(str(param_decls[0]))
        nargs = attrs.pop("nargs", 1)
        if nargs != -1 and (not isinstance(nargs, int) or nargs < 1):
            raise TypeError("'nargs' must be a positive integer or -1 for arguments.")
        self.nargs = nargs
        self.multiple = False
        default = attrs.pop("default", None)
        required = attrs.pop("required", None)
        if nargs == -1:
            self.required = required is True
        elif required is None:
            self.required = default is None
        else:
            self.required = bool(required)
        self.default = default
        self.default_explicit = default is not None
        type_arg = attrs.pop("type", None)
        if isinstance(type_arg, Tuple):
            if nargs == 1:
                self.nargs = type_arg.arity
        self.type = convert_type(type_arg, default if nargs != -1 else None)
        self.envvar = _listify(attrs.pop("envvar", None))
        deprecated = attrs.pop("deprecated", False)
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None
        if self.deprecated and self.required:
            raise TypeError("A deprecated argument cannot be required.")
        self.help = attrs.pop("help", None)
        self.metavar = attrs.pop("metavar", None)
        self.expose_value = True
        self.hidden = bool(attrs.pop("hidden", False))
        self.callback = attrs.pop("callback", None)
        self.is_eager = False
        self.shell_complete_func = attrs.pop("shell_complete", None)
        if attrs:
            raise TypeError(f"Unknown argument keyword(s): {', '.join(sorted(attrs))}")

    def get_error_hint(self, ctx: t.Any = None) -> str:
        return f"'{self.name}'"

    def get_placeholder(self) -> str:
        if self.metavar is not None:
            base = self.metavar
        elif isinstance(self.type, Tuple):
            base = self.type.get_metavar()
        else:
            base = self.name.upper()
        if self.nargs == -1:
            return base + "..."
        if self.nargs > 1 and self.metavar is None and not isinstance(self.type, Tuple):
            return " ".join([base] * self.nargs)
        return base

    def get_usage_piece(self) -> str:
        placeholder = self.get_placeholder()
        if self.nargs == -1:
            return placeholder if self.required else f"[{placeholder.rstrip('.')}]..."
        return placeholder if self.required else f"[{placeholder}]"


def _listify(value: t.Any) -> t.Optional[t.List[str]]:
    if value is None:
        return None
    if isinstance(value, str):
        return [value]
    return list(value)


def _prompt_text_option(prompt: t.Any) -> t.Optional[str]:
    if prompt is None or prompt is False:
        return None
    if prompt is True:
        return ""
    return str(prompt)


def _parse_option_decls(decls: t.Sequence[str]) -> t.Tuple[t.Optional[str], t.List[str], t.List[str]]:
    dest: t.Optional[str] = None
    opts: t.List[str] = []
    secondary: t.List[str] = []
    for decl in decls:
        decl = str(decl)
        if decl and decl[0] in "-/+":
            if "/" in decl[1:]:
                left, right = decl.split("/", 1)
                if not left or not right:
                    raise TypeError(f"Invalid on/off option declaration {decl!r}.")
                opts.append(left)
                secondary.append(right)
            else:
                opts.append(decl)
        elif decl.isidentifier():
            if dest is not None:
                raise TypeError("An option takes only one destination name.")
            dest = decl
        else:
            raise TypeError(f"Invalid option declaration {decl!r}.")
    return dest, opts, secondary


def _infer_dest(opts: t.List[str]) -> str:
    long_names = [o for o in opts if len(o.lstrip("-/+")) > 1 and o[:2] == o[0] * 2]
    chosen = long_names[0] if long_names else opts[0]
    return chosen.lstrip("-/+").replace("-", "_")


class _OptionParser:
    """Turns option tokens into per-parameter occurrences and collects the rest."""

    def __init__(
        self,
        ctx: Context,
        options: t.List[Option],
        interspersed: bool,
        passthrough: bool,
        ignore_unknown: bool,
    ) -> None:
        self.ctx = ctx
        self.normalize = ctx.token_normalize_func or (lambda s: s)
        self.interspersed = interspersed
        self.passthrough = passthrough
        self.ignore_unknown = ignore_unknown
        self.opts: t.Dict[str, t.Tuple[Option, str]] = {}
        self.prefixes = {"-"}
        for option in options:
            for name in option.opts:
                self._register(name, option, "on")
            for name in option.secondary_opts:
                self._register(name, option, "off")
        self.occurrences: t.Dict[Parameter, t.List[t.Tuple[t.Any, ...]]] = {}
        self.first: t.Dict[Parameter, int] = {}
        self.largs: t.List[str] = []
        self.literal: t.Set[int] = set()

    def _register(self, name: str, option: Option, role: str) -> None:
        self.prefixes.add(name[0])
        self.opts[self.normalize(name)] = (option, role)

    def _is_option_like(self, token: str) -> bool:
        return len(token) > 1 and token[0] in self.prefixes

    def _is_known(self, token: str) -> bool:
        return self.normalize(token.partition("=")[0]) in self.opts

    def _record(self, param: Parameter, occ: t.Tuple[t.Any, ...]) -> None:
        self.first.setdefault(param, len(self.first))
        self.occurrences.setdefault(param, []).append(occ)

    def _add_positional(self, token: str, literal: bool = False) -> None:
        self.largs.append(token)
        if literal:
            self.literal.add(len(self.largs) - 1)

    def _unknown(self, token: str, name: str) -> None:
        if self.passthrough or self.ignore_unknown:
            self.largs.append(token)
            return
        raise NoSuchOption(name, ctx=self.ctx)

    def parse(self, args: t.Sequence[str]) -> None:
        i = 0
        after_dd = False
        n = len(args)
        while i < n:
            token = args[i]
            i += 1
            if after_dd:
                self._add_positional(token, literal=True)
                continue
            if token == "--":
                after_dd = True
                continue
            if not self._is_option_like(token):
                self._add_positional(token)
                if not self.interspersed:
                    self.largs.extend(args[i:])
                    break
                continue
            i = self._handle_option(token, args, i)

    def _handle_option(self, token: str, args: t.Sequence[str], i: int) -> int:
        name, eq, attached = token.partition("=")
        attached_value: t.Optional[str] = attached if eq else None
        entry = self.opts.get(self.normalize(name))
        if entry is not None:
            option, role = entry
            return self._take(option, role, name, attached_value, args, i)
        if len(token) > 1 and token[1] == token[0]:
            self._unknown(token, name)
            return i
        stack = token[1:]
        j = 0
        while j < len(stack):
            short = token[0] + stack[j]
            entry = self.opts.get(self.normalize(short))
            if entry is None:
                if self.passthrough or self.ignore_unknown:
                    self.largs.append(token[0] + stack[j:])
                    return i
                raise NoSuchOption(short, ctx=self.ctx)
            option, role = entry
            if option.is_flag or option.count:
                self._record_flag(option, role)
                j += 1
                continue
            rest = stack[j + 1 :]
            return self._take(option, role, short, rest or None, args, i)
        return i

    def _record_flag(self, option: Option, role: str) -> None:
        if option.count:
            self._record(option, ("count",))
        else:
            self._record(option, ("const", option.flag_value_for(role)))

    def _take(
        self,
        option: Option,
        role: str,
        name: str,
        attached: t.Optional[str],
        args: t.Sequence[str],
        i: int,
    ) -> int:
        if option.is_flag or option.count:
            if attached is not None:
                raise BadOptionUsage(f"Option '{name}' does not take a value.", self.ctx)
            self._record_flag(option, role)
            return i
        if option.optional_value:
            if attached is not None:
                self._record(option, ("tokens", (attached,)))
                return i
            if i < len(args) and not self._is_option_like(args[i]) and not self._is_known(args[i]):
                self._record(option, ("tokens", (args[i],)))
                return i + 1
            self._record(option, ("const", option.flag_value))
            return i
        nargs = option.nargs
        tokens: t.List[str] = []
        if attached is not None:
            if nargs == 1:
                self._record(option, ("tokens", (attached,)))
                return i
            tokens.append(attached)
        need = nargs - len(tokens)
        available = len(args) - i
        blocked = available > 0 and self._is_known(args[i])
        if need > 0 and (available < need or blocked):
            if option.prompt is not None and not tokens and (available == 0 or self._is_option_like(args[i])):
                self._record(option, ("prompt",))
                return i
            if nargs == 1:
                raise BadOptionUsage(f"Option '{name}' requires an argument.", self.ctx)
            raise BadOptionUsage(f"Option '{name}' requires {nargs} arguments.", self.ctx)
        tokens.extend(args[i : i + need])
        self._record(option, ("tokens", tuple(tokens)))
        return i + need


def _consume_arguments(
    arguments: t.List[Argument], tokens: t.List[str], literal: t.Set[int], ctx: Context
) -> t.Tuple[t.Dict[Argument, t.List[t.Tuple[t.Any, ...]]], t.List[t.Tuple[str, bool]]]:
    result: t.Dict[Argument, t.List[t.Tuple[t.Any, ...]]] = {}
    pos = 0
    for index, arg in enumerate(arguments):
        remaining = len(tokens) - pos
        if arg.nargs == -1:
            needed_after = sum(a.nargs for a in arguments[index + 1 :] if a.nargs > 0 and a.required)
            take = max(0, remaining - needed_after)
            result[arg] = [("tokens", tuple(tokens[pos : pos + take]))] if take else []
            pos += take
            continue
        need = arg.nargs
        if remaining >= need:
            result[arg] = [("tokens", tuple(tokens[pos : pos + need]))]
            pos += need
        elif remaining > 0:
            raise BadArgumentUsage(f"Argument '{arg.name}' takes {need} values.", ctx)
        else:
            result[arg] = []
    leftover = [(tok, (pos + k) in literal) for k, tok in enumerate(tokens[pos:])]
    return result, leftover


class Command:
    """A leaf command: parses its parameters and runs the author's callback."""

    allow_extra_args_default = False

    def __init__(
        self,
        name: t.Optional[str] = None,
        callback: t.Optional[t.Callable[..., t.Any]] = None,
        params: t.Optional[t.Iterable[Parameter]] = None,
        **attrs: t.Any,
    ) -> None:
        self.name = name
        self.callback = callback
        self.params: t.List[Parameter] = list(params or [])
        doc = attrs.pop("help", None)
        if doc is None and callback is not None:
            doc = callback.__doc__
        if doc is not None:
            doc = inspect.cleandoc(str(doc).split("\f", 1)[0])
        self.help: t.Optional[str] = doc
        self.short_help: t.Optional[str] = attrs.pop("short_help", None)
        self.epilog: t.Optional[str] = attrs.pop("epilog", None)
        self.options_metavar: t.Optional[str] = attrs.pop("options_metavar", "[OPTIONS]")
        self.context_settings: t.Dict[str, t.Any] = dict(attrs.pop("context_settings", None) or {})
        self.add_help_option: bool = bool(attrs.pop("add_help_option", True))
        self.no_args_is_help: bool = bool(attrs.pop("no_args_is_help", False))
        deprecated = attrs.pop("deprecated", False)
        self.deprecated = bool(deprecated)
        self.deprecation_note = deprecated if isinstance(deprecated, str) else None
        self.hidden: bool = bool(attrs.pop("hidden", False))
        self.allow_extra_args: bool = bool(attrs.pop("allow_extra_args", self.allow_extra_args_default))
        self.allow_interspersed_args: bool = bool(attrs.pop("allow_interspersed_args", True))
        if attrs:
            raise TypeError(f"Unknown command keyword(s): {', '.join(sorted(attrs))}")
        variadic = [p for p in self.params if isinstance(p, Argument) and p.nargs == -1]
        if len(variadic) > 1:
            raise TypeError("Only one variadic argument is allowed per command.")

    # -- introspection ----------------------------------------------------

    def __call__(self, *args: t.Any, **kwargs: t.Any) -> t.Any:
        return self.main(*args, **kwargs)

    def __repr__(self) -> str:
        return f"<{type(self).__name__} {self.name}>"

    def get_help_text(self) -> t.Optional[str]:
        return self.help

    def get_params(self, ctx: Context) -> t.List[Parameter]:
        params = list(self.params)
        if self.add_help_option:
            declared = {n for p in self.params if isinstance(p, Option) for n in p.opts + p.secondary_opts}
            names = [n for n in ctx.help_option_names if n not in declared]
            if names:
                params.append(_make_help_option(names))
        return params

    def get_short_help_str(self, limit: int = 45) -> str:
        if self.short_help is not None:
            text = self.short_help
        else:
            text = " ".join((self.help or "").split())
            match = _SENTENCE_RE.match(text)
            if match:
                text = match.group(0)
        if len(text) > limit:
            text = text[: max(limit - 3, 0)].rstrip() + "..."
        return text

    def get_usage(self, ctx: Context) -> str:
        pieces = [ctx.command_path]
        if self.options_metavar:
            pieces.append(self.options_metavar)
        for param in self.params:
            if isinstance(param, Argument):
                pieces.append(param.get_usage_piece())
        if isinstance(self, Group):
            meta = self.subcommand_metavar or "COMMAND"
            if self.chain:
                pieces.append(f"{meta} [ARGS]... [{meta} [ARGS]...]...")
            elif self.invoke_without_command:
                pieces.append(f"[{meta}] [ARGS]...")
            else:
                pieces.append(f"{meta} [ARGS]...")
        return "Usage: " + " ".join(p for p in pieces if p)

    def get_help(self, ctx: Context) -> str:
        width = ctx.get_wrap_width()
        out: t.List[str] = [self.get_usage(ctx), ""]
        if self.deprecated:
            mark = "(Deprecated)" if not self.deprecation_note else f"(Deprecated) {self.deprecation_note}"
            out.extend([mark, ""])
        text = self.get_help_text()
        if text:
            out.extend(rewrap_help(text, width))
            out.append("")
        arg_rows = [
            (p.get_placeholder(), p.help)
            for p in self.params
            if isinstance(p, Argument) and p.help and not p.hidden
        ]
        if arg_rows:
            out.append("Positional arguments:")
            out.extend(_rows(arg_rows, width))
            out.append("")
        option_rows = []
        for param in self.get_params(ctx):
            if isinstance(param, Option) and not param.hidden:
                option_rows.append(_option_row(param, ctx, width))
        if option_rows:
            out.append("Options:")
            out.extend(_rows(option_rows, width))
            out.append("")
        if isinstance(self, Group):
            cmd_rows = []
            for name in self.list_commands(ctx):
                child = self.get_command(ctx, name)
                if child is None or child.hidden:
                    continue
                cmd_rows.append((name, child.get_short_help_str(max(width - 30, 20))))
            if cmd_rows:
                out.append("Commands:")
                out.extend(_rows(cmd_rows, width))
                out.append("")
        if self.epilog:
            out.extend(rewrap_help(self.epilog, width))
            out.append("")
        while out and out[-1] == "":
            out.pop()
        return "\n".join(out)

    # -- parsing ----------------------------------------------------------

    def make_context(
        self,
        info_name: t.Optional[str],
        args: t.Sequence[str],
        parent: t.Optional[Context] = None,
        chained: bool = False,
        **extra: t.Any,
    ) -> Context:
        child_map = extra.pop("default_map", None)
        if child_map is None and parent is not None and isinstance(parent.default_map, dict):
            child_map = parent.default_map.get(info_name or "")
            if not isinstance(child_map, dict):
                child_map = None
        ctx = Context(self, parent=parent, info_name=info_name, default_map=child_map, **extra)
        try:
            with ctx:
                ctx._rest = self._parse(ctx, list(args), chained)
        except BaseException:
            ctx.close()
            raise
        return ctx

    def parse_args(self, ctx: Context, args: t.Sequence[str]) -> t.List[str]:
        return self._parse(ctx, list(args), chained=False)

    def _parse(self, ctx: Context, args: t.List[str], chained: bool) -> t.List[str]:
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            echo(self.get_help(ctx), err=True)
            raise NoArgsIsHelp(ctx=ctx)
        params = self.get_params(ctx)
        options = [p for p in params if isinstance(p, Option)]
        arguments = [p for p in params if isinstance(p, Argument)]
        parser = _OptionParser(
            ctx,
            options,
            interspersed=bool(ctx.allow_interspersed_args),
            passthrough=isinstance(self, Group) and bool(ctx.allow_interspersed_args),
            ignore_unknown=bool(ctx.ignore_unknown_options),
        )
        parser.parse(args)
        arg_occurrences, leftover = _consume_arguments(arguments, parser.largs, parser.literal, ctx)
        occurrences = dict(parser.occurrences)
        occurrences.update(arg_occurrences)
        first = dict(parser.first)
        self._process(ctx, params, occurrences, first)
        if isinstance(self, Group):
            return [tok for tok, _ in leftover]
        if chained:
            return [tok for tok, _ in leftover]
        if leftover:
            if ctx.allow_extra_args:
                for tok, literal in leftover:
                    if not literal and len(tok) > 1 and tok[0] in parser.prefixes and not ctx.ignore_unknown_options:
                        raise NoSuchOption(tok, ctx=ctx)
                return []
            names = " ".join(tok for tok, _ in leftover)
            raise UsageError(
                f"Got unexpected extra argument{'s' if len(leftover) != 1 else ''} ({names})",
                ctx=ctx,
            )
        return []

    def _process(
        self,
        ctx: Context,
        params: t.List[Parameter],
        occurrences: t.Dict[Parameter, t.List[t.Tuple[t.Any, ...]]],
        first: t.Dict[Parameter, int],
    ) -> None:
        indexed = {id(p): i for i, p in enumerate(params)}
        seen_eager = sorted(
            (p for p in params if p.is_eager and p in first), key=lambda p: first[p]
        )
        unseen_eager = [p for p in params if p.is_eager and p not in first]
        rest = [p for p in params if not p.is_eager]
        for param in seen_eager + unseen_eager + rest:
            self._process_one(ctx, param, occurrences.get(param), indexed[id(param)])

    def _process_one(self, ctx: Context, param: Parameter, occurrences: t.Any, index: int) -> None:
        value, source = param.process(ctx, occurrences)
        if source is None and param.required:
            raise MissingParameter(ctx=ctx, param=param)
        if value is None and (param.multiple or param.nargs == -1):
            value = ()
        if param.deprecated and source is ParameterSource.COMMANDLINE:
            _warn_deprecated_param(ctx, param)
        if param.callback is not None:
            try:
                value = param.callback(ctx, param, value)
            except BadParameter as e:
                if e.ctx is None:
                    e.ctx = ctx
                if e.param is None and e.param_hint is None:
                    e.param = param
                raise
        rank = param._rank(source, index)
        previous = ctx._ranks.get(param.name)
        if previous is None or rank >= previous:
            ctx._ranks[param.name] = rank
            ctx._sources[param.name] = source
            if param.expose_value:
                ctx.params[param.name] = value

    # -- running ------------------------------------------------------------

    def _run_callback(self, ctx: Context) -> t.Any:
        if self.callback is None:
            return None
        kwargs = {p.name: ctx.params[p.name] for p in self.params if p.expose_value and p.name in ctx.params}
        return ctx.invoke(self.callback, **kwargs)

    def invoke(self, ctx: Context) -> t.Any:
        try:
            with ctx:
                if self.deprecated:
                    _warn_deprecated_command(ctx, self)
                return self._run_callback(ctx)
        finally:
            ctx.close()

    def main(
        self,
        args: t.Optional[t.Sequence[str]] = None,
        prog_name: t.Optional[str] = None,
        complete_var: t.Optional[str] = None,
        standalone_mode: bool = True,
        **extra: t.Any,
    ) -> t.Any:
        """Run this command as a program (or in-process when standalone mode is off)."""
        args = list(sys.argv[1:] if args is None else args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0] or "") or "main"
            if prog_name.endswith(".py"):
                prog_name = prog_name[:-3]
        if complete_var is None:
            complete_var = "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"
        instruction = os.environ.get(complete_var)
        if instruction:
            from .shell_completion import run_completion

            status = run_completion(self, args, prog_name, instruction)
            if standalone_mode:
                sys.exit(status)
            return None
        try:
            try:
                ctx = self.make_context(prog_name, args, **extra)
                rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                sys.exit(0)
            except (EOFError, KeyboardInterrupt) as e:
                raise Abort() from e
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return None
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", err=True)
            sys.exit(1)
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)


class Group(Command):
    """A command that dispatches to named subcommands."""

    def __init__(
        self,
        name: t.Optional[str] = None,
        commands: t.Any = None,
        invoke_without_command: bool = False,
        no_args_is_help: t.Optional[bool] = None,
        subcommand_metavar: t.Optional[str] = None,
        chain: bool = False,
        result_callback: t.Optional[t.Callable[..., t.Any]] = None,
        **kwargs: t.Any,
    ) -> None:
        kwargs.setdefault("allow_interspersed_args", False)
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name, no_args_is_help=no_args_is_help, **kwargs)
        self.commands: t.Dict[str, Command] = {}
        if isinstance(commands, dict):
            for key, cmd in commands.items():
                self.add_command(cmd, key)
        elif commands:
            for cmd in commands:
                self.add_command(cmd)
        self.invoke_without_command = bool(invoke_without_command)
        self.subcommand_metavar = subcommand_metavar
        self.chain = bool(chain)
        self._result_callback = result_callback

    def add_command(self, cmd: Command, name: t.Optional[str] = None) -> None:
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Groups cannot be nested under a chaining group.")
        key = name or cmd.name
        if not key:
            raise TypeError("A subcommand needs a name.")
        self.commands[key] = cmd

    def command(self, *args: t.Any, **kwargs: t.Any) -> t.Callable[[t.Callable[..., t.Any]], Command]:
        from .decorators import command as command_decorator

        def decorator(f: t.Callable[..., t.Any]) -> Command:
            cmd = command_decorator(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args: t.Any, **kwargs: t.Any) -> t.Callable[[t.Callable[..., t.Any]], "Group"]:
        from .decorators import group as group_decorator

        def decorator(f: t.Callable[..., t.Any]) -> Group:
            grp = group_decorator(*args, **kwargs)(f)
            self.add_command(grp)
            return grp

        return decorator

    def result_callback(self) -> t.Callable[[t.Callable[..., t.Any]], t.Callable[..., t.Any]]:
        def decorator(f: t.Callable[..., t.Any]) -> t.Callable[..., t.Any]:
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx: Context) -> t.List[str]:
        return sorted(self.commands)

    def get_command(self, ctx: Context, cmd_name: str) -> t.Optional[Command]:
        return self.commands.get(cmd_name)

    def _lookup(self, ctx: Context, name: str) -> t.Optional[Command]:
        cmd = self.get_command(ctx, name)
        if cmd is None and ctx.token_normalize_func is not None:
            wanted = ctx.token_normalize_func(name)
            for candidate in self.list_commands(ctx):
                if ctx.token_normalize_func(candidate) == wanted:
                    cmd = self.get_command(ctx, candidate)
                    break
        return cmd

    def invoke(self, ctx: Context) -> t.Any:
        try:
            with ctx:
                if self.deprecated:
                    _warn_deprecated_command(ctx, self)
                if self.chain:
                    return self._invoke_chain(ctx)
                rest = ctx._rest
                if not rest:
                    if not self.invoke_without_command:
                        raise MissingCommand(ctx=ctx)
                    ctx.invoked_subcommand = None
                    rv = self._run_callback(ctx)
                    return self._finish(ctx, rv)
                name, child_args = rest[0], rest[1:]
                cmd = self._lookup(ctx, name)
                if cmd is None:
                    raise NoSuchCommand(name, ctx=ctx)
                ctx.invoked_subcommand = name
                self._run_callback(ctx)
                child = cmd.make_context(name, child_args, parent=ctx)
                rv = child.command.invoke(child)
                return self._finish(ctx, rv)
        finally:
            ctx.close()

    def _finish(self, ctx: Context, value: t.Any) -> t.Any:
        if self._result_callback is None:
            return value
        return ctx.invoke(self._result_callback, value, **ctx.params)

    def _invoke_chain(self, ctx: Context) -> t.List[t.Any]:
        subs: t.List[Context] = []
        rest = ctx._rest
        while rest:
            name = rest[0]
            cmd = self._lookup(ctx, name)
            if cmd is None:
                raise NoSuchCommand(name, ctx=ctx)
            sub = cmd.make_context(name, rest[1:], parent=ctx, chained=True)
            rest = sub._rest
            subs.append(sub)
        if not subs and not self.invoke_without_command:
            raise MissingCommand(ctx=ctx)
        ctx.invoked_subcommand = CHAIN_SENTINEL
        self._run_callback(ctx)
        results = [sub.command.invoke(sub) for sub in subs]
        if self._result_callback is not None:
            ctx.invoke(self._result_callback, results, **ctx.params)
        return results


class CommandCollection(Group):
    """A group whose subcommands are the union of several source groups."""

    def __init__(self, name: t.Optional[str] = None, sources: t.Optional[t.Iterable[Group]] = None, **kwargs: t.Any) -> None:
        super().__init__(name, **kwargs)
        self.sources: t.List[Group] = list(sources or [])

    def list_commands(self, ctx: Context) -> t.List[str]:
        names: t.Set[str] = set(self.commands)
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx: Context, cmd_name: str) -> t.Optional[Command]:
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


def _make_help_option(names: t.List[str]) -> Option:
    def _callback(ctx: Context, param: Parameter, value: t.Any) -> None:
        if not value or ctx.resilient_parsing:
            return
        echo(ctx.get_help(), color=ctx.color)
        ctx.exit()

    return Option(
        names,
        is_flag=True,
        expose_value=False,
        is_eager=True,
        callback=_callback,
        help="Show this message and exit.",
        default=False,
    )


def _option_row(option: Option, ctx: Context, width: int) -> t.Tuple[str, str]:
    names = ", ".join(option.opts)
    if option.secondary_opts:
        names = f"{names}/{', '.join(option.secondary_opts)}"
    metavar = option.get_help_metavar()
    first = f"{names} {metavar}" if metavar else names
    parts: t.List[str] = []
    if option.help:
        parts.append(" ".join(option.help.split()))
    if option.deprecated:
        parts.append("(deprecated)" if not option.deprecation_note else f"(deprecated: {option.deprecation_note})")
    show = option.show_default if option.show_default is not None else ctx.show_default
    if show:
        default_text = _default_text(option, show)
        if default_text is not None:
            parts.append(f"[default: {default_text}]")
    if option.show_envvar:
        names_env = option.get_envvar_names(ctx)
        if names_env:
            parts.append(f"[env var: {', '.join(names_env)}]")
    return first, " ".join(parts)


def _default_text(param: Parameter, show: t.Any) -> t.Optional[str]:
    if isinstance(show, str):
        return show
    default = param.default
    if callable(default):
        return "(dynamic)"
    if default is None:
        return None
    if param.is_flag and default is False:
        return None
    if isinstance(default, (list, tuple)):
        return ", ".join(str(v) for v in default) if default else None
    return str(default)


def _rows(rows: t.List[t.Tuple[str, str]], width: int) -> t.List[str]:
    if not rows:
        return []
    col = min(max(len(first) for first, _ in rows) + 2, 30)
    text_width = max(width - col - 4, 20)
    lines: t.List[str] = []
    for first, second in rows:
        wrapped = textwrap.wrap(second, text_width) if second else []
        if len(first) + 2 > col or not wrapped:
            lines.append("  " + first)
            for line in wrapped:
                lines.append(" " * (col + 2) + line)
            continue
        lines.append("  " + first.ljust(col) + wrapped[0])
        for line in wrapped[1:]:
            lines.append(" " * (col + 2) + line)
    return lines


def _warn_deprecated_command(ctx: Context, cmd: Command) -> None:
    note = cmd.deprecation_note
    message = f"DeprecationWarning: The command '{ctx.command_path}' is deprecated."
    if note:
        message += f" {note}"
    echo(message, err=True)


def _warn_deprecated_param(ctx: Context, param: Parameter) -> None:
    note = param.deprecation_note
    if param.param_kind == "option":
        label = f"option '{param.opts[0] if param.opts else param.name}'"
    else:
        label = f"argument '{param.name}'"
    message = f"DeprecationWarning: The {label} is deprecated."
    if note:
        message += f" {note}"
    echo(message, err=True)

