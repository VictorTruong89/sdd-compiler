"""Output, styling, file-opening and directory helpers."""

import os
import re
import sys
import tempfile
import typing as t

from .exceptions import FileError
from .globals import get_current_context

_ANSI_RE = re.compile(r"\x1b\[[0-9;?]*[ -/]*[@-~]")

_NAMED_COLORS = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
}


def isatty(stream: t.Any) -> bool:
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def is_interactive() -> bool:
    """A session is interactive when stdin is a terminal, or stdin/stdout is a TTY."""
    return isatty(sys.stdin) or isatty(sys.stdout)


def unstyle(text: str) -> str:
    """Remove ANSI style sequences, leaving all other text."""
    return _ANSI_RE.sub("", text)


def _color_code(color: t.Any, background: bool) -> str:
    offset = 10 if background else 0
    if isinstance(color, str):
        if color == "reset":
            return str(49 if background else 39)
        if color in _NAMED_COLORS:
            return str(_NAMED_COLORS[color] + offset)
        raise ValueError(f"Unknown color '{color}'.")
    if isinstance(color, bool):
        raise ValueError(f"Invalid color {color!r}.")
    if isinstance(color, int):
        if 0 <= color <= 255:
            return f"{48 if background else 38};5;{color}"
        raise ValueError(f"Color index {color} is outside 0-255.")
    if isinstance(color, (tuple, list)) and len(color) == 3:
        if all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color):
            r, g, b = color
            return f"{48 if background else 38};2;{r};{g};{b}"
    raise ValueError(f"Invalid color {color!r}.")


def style(
    text: t.Any,
    fg: t.Any = None,
    bg: t.Any = None,
    bold: t.Optional[bool] = None,
    dim: t.Optional[bool] = None,
    underline: t.Optional[bool] = None,
    overline: t.Optional[bool] = None,
    italic: t.Optional[bool] = None,
    blink: t.Optional[bool] = None,
    reverse: t.Optional[bool] = None,
    strikethrough: t.Optional[bool] = None,
    reset: bool = True,
) -> str:
    """Wrap ``text`` in ANSI SGR sequences for the given styles."""
    codes: t.List[str] = []
    if fg is not None:
        codes.append(_color_code(fg, False))
    if bg is not None:
        codes.append(_color_code(bg, True))
    switches = (
        (bold, 1, 22),
        (dim, 2, 22),
        (italic, 3, 23),
        (underline, 4, 24),
        (blink, 5, 25),
        (reverse, 7, 27),
        (strikethrough, 9, 29),
        (overline, 53, 55),
    )
    for flag, on_code, off_code in switches:
        if flag is not None:
            codes.append(str(on_code if flag else off_code))
    message = str(text)
    if not codes:
        return message
    prefix = "".join(f"\x1b[{c}m" for c in codes)
    return prefix + message + ("\x1b[0m" if reset else "")


def _keep_styles(file: t.Any, color: t.Optional[bool]) -> bool:
    if color is None:
        ctx = get_current_context(silent=True)
        if ctx is not None and ctx.color is not None:
            color = ctx.color
    if color is None:
        return isatty(file)
    return bool(color)


def _write_bytes(file: t.Any, data: bytes) -> None:
    buffer = getattr(file, "buffer", None)
    if buffer is not None:
        file.flush()
        buffer.write(data)
        buffer.flush()
    else:
        file.write(data.decode("utf-8", "replace"))


def _write_text(file: t.Any, text: str) -> None:
    encoding = (getattr(file, "encoding", None) or "").lower().replace("_", "-")
    if encoding in ("ascii", "us-ascii"):
        # An ASCII-only stream cannot take ordinary Unicode text; send UTF-8 instead.
        _write_bytes(file, text.encode("utf-8"))
        return
    try:
        file.write(text)
    except UnicodeEncodeError:
        _write_bytes(file, text.encode("utf-8"))


def echo(
    message: t.Any = None,
    file: t.Any = None,
    nl: bool = True,
    err: bool = False,
    color: t.Optional[bool] = None,
) -> None:
    """Write text or bytes to standard output (or standard error, or ``file``)."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        _write_bytes(file, message + (b"\n" if nl else b""))
        return
    text = str(message)
    if nl:
        text += "\n"
    if not _keep_styles(file, color):
        text = unstyle(text)
    _write_text(file, text)
    file.flush()


def secho(
    message: t.Any = None,
    file: t.Any = None,
    nl: bool = True,
    err: bool = False,
    color: t.Optional[bool] = None,
    **styles: t.Any,
) -> None:
    """Echo text with the given styles applied."""
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


class _StdStreamProxy:
    """Standard stream returned by :func:`open_file` for ``-``; closing it does nothing."""

    def __init__(self, stream: t.Any) -> None:
        self._stream = stream

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._stream, name)

    def __iter__(self) -> t.Iterator[t.Any]:
        return iter(self._stream)

    def __next__(self) -> t.Any:
        return next(self._stream)

    def close(self) -> None:
        pass

    def __enter__(self) -> "_StdStreamProxy":
        return self

    def __exit__(self, *exc: t.Any) -> None:
        pass


class LazyFile:
    """A file that is opened on first use, optionally through an atomic temporary file."""

    def __init__(
        self,
        filename: str,
        mode: str = "r",
        encoding: t.Optional[str] = None,
        errors: str = "strict",
        atomic: bool = False,
    ) -> None:
        self.name = filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._writing = any(c in mode for c in "wax+")
        self._file: t.Any = None
        self._tmp_path: t.Optional[str] = None

    def open(self) -> t.Any:
        if self._file is not None:
            return self._file
        target = self.name
        try:
            if self.atomic and self._writing:
                directory = os.path.dirname(os.path.abspath(self.name))
                fd, tmp_path = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
                os.close(fd)
                self._tmp_path = tmp_path
                target = tmp_path
            if "b" in self.mode:
                handle = open(target, self.mode)
            else:
                handle = open(target, self.mode, encoding=self.encoding, errors=self.errors)
        except OSError as e:
            if self._tmp_path is not None:
                try:
                    os.remove(self._tmp_path)
                except OSError:
                    pass
                self._tmp_path = None
            raise FileError(self.name, e.strerror or str(e)) from e
        self._file = handle
        return handle

    def close(self) -> None:
        if self._file is None:
            return
        self._file.close()
        self._file = None
        if self._tmp_path is not None:
            os.replace(self._tmp_path, self.name)
            self._tmp_path = None

    def __getattr__(self, name: str) -> t.Any:
        if name.startswith("__"):
            raise AttributeError(name)
        return getattr(self.open(), name)

    def __iter__(self) -> t.Iterator[t.Any]:
        return iter(self.open())

    def __enter__(self) -> "LazyFile":
        return self

    def __exit__(self, *exc: t.Any) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"<LazyFile {self.name!r} mode={self.mode!r}>"


def open_file(
    filename: str,
    mode: str = "r",
    encoding: t.Optional[str] = None,
    errors: str = "strict",
    lazy: bool = False,
    atomic: bool = False,
) -> t.Any:
    """Open a file, or the standard stream when ``filename`` is ``-``.

    Standard streams are never closed by the returned object.
    """
    if filename == "-":
        reading = "r" in mode and "+" not in mode
        stream = sys.stdin if reading else sys.stdout
        if "b" in mode:
            stream = stream.buffer
        return _StdStreamProxy(stream)
    lazy_file = LazyFile(filename, mode, encoding, errors, atomic)
    if not lazy:
        lazy_file.open()
    return lazy_file


def format_filename(filename: t.Any, shorten: bool = False) -> str:
    """Turn a path into text that prints and encodes as strict UTF-8 without failing."""
    if isinstance(filename, bytes):
        filename = os.fsdecode(filename)
    else:
        filename = os.fspath(filename)
    if shorten:
        filename = os.path.basename(filename)
    try:
        raw = filename.encode("utf-8", "surrogateescape")
    except UnicodeEncodeError:
        return ascii(filename)[1:-1]
    return raw.decode("utf-8", "backslashreplace")


def get_app_dir(app_name: str, roaming: bool = True, force_posix: bool = False) -> str:
    """Return the per-user configuration directory for ``app_name``."""
    folder = re.sub(r"\s+", "-", app_name.lower())
    home = os.path.expanduser("~")
    if force_posix:
        return os.path.join(home, "." + folder)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(config_home, folder)
