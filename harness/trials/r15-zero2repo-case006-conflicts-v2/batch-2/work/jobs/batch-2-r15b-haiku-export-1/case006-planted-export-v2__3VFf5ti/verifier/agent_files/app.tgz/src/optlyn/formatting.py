"""Text wrapping used by help pages and by :func:`wrap_text`."""

import re
import textwrap
import typing as t

_PARAGRAPH_SPLIT = re.compile(r"\n\s*\n")


def _wrap_one(text: str, width: int, initial_indent: str, subsequent_indent: str) -> str:
    wrapper = textwrap.TextWrapper(
        width=max(width, len(initial_indent) + 1, len(subsequent_indent) + 1, 10),
        initial_indent=initial_indent,
        subsequent_indent=subsequent_indent,
        break_long_words=False,
        break_on_hyphens=False,
    )
    return wrapper.fill(" ".join(text.split()))


def wrap_text(
    text: str,
    width: int = 100,
    initial_indent: str = "",
    subsequent_indent: str = "",
    preserve_paragraphs: bool = False,
) -> str:
    """Rewrap ``text`` to ``width`` columns.

    Single newlines inside a paragraph are not kept as breaks. Blank lines
    separate paragraphs. Any string is accepted.
    """
    text = str(text)
    paragraphs = [p for p in _PARAGRAPH_SPLIT.split(text.strip("\n")) if p.strip()]
    if not paragraphs:
        return ""
    out = []
    for paragraph in paragraphs:
        out.append(_wrap_one(paragraph, width, initial_indent, subsequent_indent))
    return "\n\n".join(out)


def rewrap_help(text: str, width: int, indent: str = "") -> t.List[str]:
    """Return help-page lines for ``text``, rewrapped to ``width``.

    A paragraph whose first line is only a backspace keeps its own line breaks,
    and that backspace line is dropped.
    """
    lines: t.List[str] = []
    for paragraph in _PARAGRAPH_SPLIT.split(text.strip("\n")):
        if not paragraph.strip():
            continue
        para_lines = paragraph.split("\n")
        if para_lines[0].strip() == "\b":
            for line in para_lines[1:]:
                lines.append(indent + line.rstrip())
        else:
            lines.append(_wrap_one(paragraph, width, indent, indent))
        lines.append("")
    if lines and lines[-1] == "":
        lines.pop()
    return lines
