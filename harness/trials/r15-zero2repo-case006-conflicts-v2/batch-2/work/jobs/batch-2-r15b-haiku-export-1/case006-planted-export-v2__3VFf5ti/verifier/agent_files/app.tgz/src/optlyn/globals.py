"""Per-thread storage for the invocation context that is currently running."""

import threading
import typing as t

if t.TYPE_CHECKING:
    from .core import Context

_local = threading.local()


def _stack() -> t.List["Context"]:
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = []
        _local.stack = stack
    return stack


def push_context(ctx: "Context") -> None:
    _stack().append(ctx)


def pop_context() -> None:
    _stack().pop()


def get_current_context(silent: bool = False) -> t.Optional["Context"]:
    """Return the context current on the calling thread.

    Raises ``RuntimeError`` when there is none, unless ``silent`` is true, in
    which case ``None`` is returned.
    """
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context on this thread.")
