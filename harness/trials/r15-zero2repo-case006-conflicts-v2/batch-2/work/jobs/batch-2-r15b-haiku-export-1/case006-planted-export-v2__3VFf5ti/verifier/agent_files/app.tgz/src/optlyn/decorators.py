"""Decorators that declare commands, groups, options and arguments."""

import functools
import importlib.metadata
import typing as t

from .core import Argument, Command, Context, Group, Option, Parameter
from .globals import get_current_context
from .utils import echo

F = t.TypeVar("F", bound=t.Callable[..., t.Any])

_SUFFIXES = ("_command", "_cmd", "_group", "_grp")


def _param_memo(f: t.Any, param: Parameter) -> None:
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    f.__optlyn_params__.append(param)


def _pop_params(f: t.Any) -> t.List[Parameter]:
    params = list(getattr(f, "__optlyn_params__", []))
    params.reverse()
    if hasattr(f, "__optlyn_params__"):
        del f.__optlyn_params__
    return params


def _derive_name(func_name: str) -> str:
    name = func_name.lower().replace("_", "-")
    for suffix in _SUFFIXES:
        suffix = suffix.replace("_", "-")
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name


def command(
    name: t.Any = None, cls: t.Optional[type] = None, **attrs: t.Any
) -> t.Callable[[t.Callable[..., t.Any]], Command]:
    """Turn a function into a :class:`Command`. Used as ``@command()`` or ``@command``."""
    if callable(name) and not isinstance(name, str):
        return command()(name)

    def decorator(f: t.Callable[..., t.Any]) -> Command:
        cmd_name = name if name is not None else _derive_name(f.__name__)
        params = _pop_params(f)
        factory = cls or Command
        return factory(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


def group(
    name: t.Any = None, cls: t.Optional[type] = None, **attrs: t.Any
) -> t.Callable[[t.Callable[..., t.Any]], Group]:
    """Turn a function into a :class:`Group`. Used as ``@group()`` or ``@group``."""
    if callable(name) and not isinstance(name, str):
        return group()(name)

    def decorator(f: t.Callable[..., t.Any]) -> Group:
        grp_name = name if name is not None else _derive_name(f.__name__)
        params = _pop_params(f)
        factory = cls or Group
        return factory(name=grp_name, callback=f, params=params, **attrs)

    return decorator


def option(*param_decls: str, cls: t.Optional[type] = None, **attrs: t.Any) -> t.Callable[[F], F]:
    """Attach an option to the function that follows it."""

    def decorator(f: F) -> F:
        factory = cls or Option
        _param_memo(f, factory(param_decls, **attrs))
        return f

    return decorator


def argument(*param_decls: str, cls: t.Optional[type] = None, **attrs: t.Any) -> t.Callable[[F], F]:
    """Attach a positional argument to the function that follows it."""

    def decorator(f: F) -> F:
        factory = cls or Argument
        _param_memo(f, factory(param_decls, **attrs))
        return f

    return decorator


def pass_context(f: F) -> F:
    """Pass the current :class:`Context` as the first argument."""

    @functools.wraps(f)
    def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
        return f(get_current_context(), *args, **kwargs)

    return t.cast(F, new_func)


def pass_obj(f: F) -> F:
    """Pass the current context's author object as the first argument."""

    @functools.wraps(f)
    def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
        return f(get_current_context().obj, *args, **kwargs)

    return t.cast(F, new_func)


def make_pass_decorator(object_type: type, ensure: bool = False) -> t.Callable[[F], F]:
    """Build a decorator that passes the nearest object of ``object_type``."""

    def decorator(f: F) -> F:
        @functools.wraps(f)
        def new_func(*args: t.Any, **kwargs: t.Any) -> t.Any:
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(f"Managed to invoke callback without a context object of type {object_type.__name__!r} existing.")
            return f(obj, *args, **kwargs)

        return t.cast(F, new_func)

    return decorator


def _help_callback(ctx: Context, param: Parameter, value: t.Any) -> None:
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def help_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[F], F]:
    """Attach an extra eager help flag. Default name is ``--help``."""
    decls = param_decls or ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("callback", _help_callback)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("default", False)

    def decorator(f: F) -> F:
        _param_memo(f, Option(decls, **kwargs))
        return f

    return decorator


def _detect_version(package_name: str) -> str:
    try:
        return importlib.metadata.version(package_name)
    except importlib.metadata.PackageNotFoundError:
        pass
    try:
        mapping = importlib.metadata.packages_distributions()
        for dist_name in mapping.get(package_name, []):
            return importlib.metadata.version(dist_name)
    except Exception:
        pass
    return "unknown"


def version_option(
    version: t.Optional[str] = None,
    *param_decls: str,
    package_name: t.Optional[str] = None,
    prog_name: t.Optional[str] = None,
    message: t.Optional[str] = None,
    **kwargs: t.Any,
) -> t.Callable[[F], F]:
    """Attach an eager ``--version`` flag that prints the version identity and exits."""
    decls = param_decls or ("--version",)
    template = message or "%(prog)s, version %(version)s"

    def callback(ctx: Context, param: Parameter, value: t.Any) -> None:
        if not value or ctx.resilient_parsing:
            return
        identity = version
        if identity is None:
            pkg = package_name
            if pkg is None:
                module = getattr(ctx.command.callback, "__module__", "") or ""
                pkg = module.partition(".")[0] or "__main__"
            identity = _detect_version(pkg)
        name = prog_name or ctx.find_root().info_name or ""
        echo(template % {"prog": name, "package": package_name, "version": identity}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs.setdefault("callback", callback)
    kwargs.setdefault("default", False)

    def decorator(f: F) -> F:
        _param_memo(f, Option(decls, **kwargs))
        return f

    return decorator


def custom_version_option(
    callback_fn: t.Callable[[Context], str], *param_decls: str, **kwargs: t.Any
) -> t.Callable[[F], F]:
    """Attach an eager version flag whose identity is exactly ``callback_fn(ctx)``."""
    decls = param_decls or ("--version",)

    def callback(ctx: Context, param: Parameter, value: t.Any) -> None:
        if not value or ctx.resilient_parsing:
            return
        echo(callback_fn(ctx), color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    kwargs.setdefault("default", False)

    def decorator(f: F) -> F:
        _param_memo(f, Option(decls, **kwargs))
        return f

    return decorator


def password_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[F], F]:
    """A hidden-input option that prompts and asks for confirmation. Default name ``--password``."""
    decls = param_decls or ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)

    def decorator(f: F) -> F:
        _param_memo(f, Option(decls, **kwargs))
        return f

    return decorator


def _confirmation_callback(ctx: Context, param: Parameter, value: t.Any) -> t.Any:
    if not value and not ctx.resilient_parsing:
        ctx.abort()
    return value


def confirmation_option(*param_decls: str, **kwargs: t.Any) -> t.Callable[[F], F]:
    """A yes-flag that asks when omitted and aborts when declined. Default name ``--yes``."""
    decls = param_decls or ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs["callback"] = _confirmation_callback

    def decorator(f: F) -> F:
        _param_memo(f, Option(decls, **kwargs))
        return f

    return decorator
