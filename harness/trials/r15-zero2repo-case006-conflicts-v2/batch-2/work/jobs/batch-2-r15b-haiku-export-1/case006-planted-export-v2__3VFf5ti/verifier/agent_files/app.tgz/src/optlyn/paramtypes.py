"""Parameter types: how command-line tokens become Python values."""

import datetime as dt
import enum
import os
import typing as t
import uuid

from .exceptions import BadParameter
from .utils import LazyFile, open_file


class ParamType:
    """Base class for parameter types.

    Subclasses set :attr:`name` and implement :meth:`convert`. Values that are
    already of the right type must pass through unchanged.
    """

    name = "text"
    #: Separator used to split environment values for multi-value parameters.
    envvar_separator: t.Optional[str] = None

    def __call__(self, value: t.Any, param: t.Any = None, ctx: t.Any = None) -> t.Any:
        return self.convert(value, param, ctx)

    def convert(self, value: t.Any, param: t.Any = None, ctx: t.Any = None) -> t.Any:
        return value

    def fail(self, message: str, param: t.Any = None, ctx: t.Any = None) -> t.NoReturn:
        raise BadParameter(message, ctx=ctx, param=param)

    def get_metavar(self) -> t.Optional[str]:
        """Placeholder shown on help pages, or ``None`` to use the parameter name."""
        return None

    def shell_complete(self, ctx: t.Any, param: t.Any, incomplete: str) -> t.List[t.Any]:
        return []

    def split_envvar_value(self, rv: str) -> t.List[str]:
        sep = self.envvar_separator
        if sep is None:
            return rv.split()
        return [p for p in rv.split(sep) if p != ""]

    def __repr__(self) -> str:
        return self.name.upper()


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        if isinstance(value, str):
            return value
        return str(value)


class UnprocessedParamType(ParamType):
    """Pass the raw token through unchanged."""

    name = "text"


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, float):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)
        try:
            return int(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return float(value)
        try:
            return float(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


class Choice(ParamType):
    """A closed list of allowed values, or the members of an enumeration."""

    name = "choice"

    def __init__(self, choices: t.Iterable[t.Any], case_sensitive: bool = True) -> None:
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices: t.List[t.Any] = list(choices)
            self._is_enum = True
        else:
            self.choices = list(choices)
            self._is_enum = False
        self.case_sensitive = case_sensitive

    def _token(self, choice: t.Any) -> str:
        if self._is_enum:
            return choice.name
        return str(choice)

    def get_metavar(self) -> str:
        return "[" + "|".join(self._token(c) for c in self.choices) + "]"

    def convert(self, value, param=None, ctx=None):
        for choice in self.choices:
            if choice is value or (not self._is_enum and choice == value):
                return choice
        token = value.name if isinstance(value, enum.Enum) else str(value)
        normalize = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
        if normalize is not None:
            token = normalize(token)
        for choice in self.choices:
            candidate = self._token(choice)
            if normalize is not None:
                candidate = normalize(candidate)
            if candidate == token or (
                not self.case_sensitive and candidate.casefold() == token.casefold()
            ):
                return choice
        options = ", ".join(repr(self._token(c)) for c in self.choices)
        self.fail(f"{value!r} is not one of {options}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        out = []
        for choice in self.choices:
            token = self._token(choice)
            if self.case_sensitive:
                matches = token.startswith(incomplete)
            else:
                matches = token.casefold().startswith(incomplete.casefold())
            if matches:
                out.append(token)
        return out


_DEFAULT_DATETIME_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats: t.Optional[t.Sequence[str]] = None) -> None:
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DATETIME_FORMATS)

    def get_metavar(self) -> str:
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        self.fail(
            f"{value!r} does not match the format{'s' if len(self.formats) != 1 else ''} "
            f"{', '.join(repr(f) for f in self.formats)}.",
            param,
            ctx,
        )


class _RangeMixin:
    min: t.Any
    max: t.Any
    min_open: bool
    max_open: bool
    clamp: bool

    def _range_text(self) -> str:
        lo = "" if self.min is None else f"{'>' if self.min_open else '>='}{self.min}"
        hi = "" if self.max is None else f"{'<' if self.max_open else '<='}{self.max}"
        if lo and hi:
            return f"{self.min}{'<' if self.min_open else '<='}x{'<' if self.max_open else '<='}{self.max}"
        if lo:
            return lo
        return hi

    def _check(self, value, param, ctx):
        below = self.min is not None and (value < self.min or (self.min_open and value == self.min))
        above = self.max is not None and (value > self.max or (self.max_open and value == self.max))
        if not below and not above:
            return value
        if self.clamp:
            if below:
                return self.min + 1 if self.min_open else self.min
            return self.max - 1 if self.max_open else self.max
        self.fail(f"{value!r} is not in the range {self._range_text()}.", param, ctx)


class IntRange(_RangeMixin, IntParamType):
    name = "integer range"

    def __init__(
        self,
        min: t.Optional[int] = None,
        max: t.Optional[int] = None,
        min_open: bool = False,
        max_open: bool = False,
        clamp: bool = False,
    ) -> None:
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp
        if min is not None and max is not None and min > max:
            raise ValueError("'min' must not be greater than 'max'.")

    def convert(self, value, param=None, ctx=None):
        value = IntParamType.convert(self, value, param, ctx)
        return self._check(value, param, ctx)


class FloatRange(_RangeMixin, FloatParamType):
    name = "float range"

    def __init__(
        self,
        min: t.Optional[float] = None,
        max: t.Optional[float] = None,
        min_open: bool = False,
        max_open: bool = False,
        clamp: bool = False,
    ) -> None:
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp
        if min is not None and max is not None and min > max:
            raise ValueError("'min' must not be greater than 'max'.")
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is only allowed when both bounds are closed.")

    def convert(self, value, param=None, ctx=None):
        value = FloatParamType.convert(self, value, param, ctx)
        return self._check(value, param, ctx)


class Tuple(ParamType):
    """A fixed-length product of types, one value per position."""

    name = "tuple"

    def __init__(self, types: t.Sequence[t.Any]) -> None:
        self.types = [convert_type(ty) for ty in types]

    @property
    def arity(self) -> int:
        return len(self.types)

    def get_metavar(self) -> str:
        return " ".join((ty.get_metavar() or ty.name.upper()) for ty in self.types)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, (str, bytes)) or not hasattr(value, "__len__"):
            self.fail(f"{value!r} is not a sequence of {len(self.types)} values.", param, ctx)
        if len(value) != len(self.types):
            self.fail(f"Takes {len(self.types)} values but {len(value)} were given.", param, ctx)
        return tuple(ty.convert(v, param, ctx) for ty, v in zip(self.types, value))


class File(ParamType):
    """An open file. ``-`` is standard input for reading and standard output for writing."""

    name = "filename"
    envvar_separator = os.pathsep

    def __init__(
        self,
        mode: str = "r",
        encoding: t.Optional[str] = None,
        errors: str = "strict",
        lazy: t.Optional[bool] = None,
        atomic: bool = False,
    ) -> None:
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        filename = os.fspath(value) if not isinstance(value, bytes) else os.fsdecode(value)
        if filename == "-":
            return open_file(filename, self.mode, self.encoding, self.errors)
        writing = "w" in self.mode
        lazy = self.lazy if self.lazy is not None else writing
        handle = LazyFile(filename, self.mode, self.encoding, self.errors, self.atomic)
        if not lazy:
            try:
                handle.open()
            except Exception as e:
                self.fail(f"'{filename}': {getattr(e, 'message', e)}", param, ctx)
        if ctx is not None:
            ctx.call_on_close(handle.close)
        return handle

    def get_metavar(self) -> None:
        return None

    def shell_complete(self, ctx, param, incomplete):
        return [PathRequest("file", incomplete)]


class PathRequest:
    """Completion entry that asks the shell to complete filesystem paths."""

    def __init__(self, kind: str, incomplete: str) -> None:
        self.kind = kind
        self.incomplete = incomplete


class Path(ParamType):
    """A filesystem path, checked against the requested properties."""

    name = "path"
    envvar_separator = os.pathsep

    def __init__(
        self,
        exists: bool = False,
        file_okay: bool = True,
        dir_okay: bool = True,
        writable: bool = False,
        readable: bool = True,
        resolve_path: bool = False,
        allow_dash: bool = False,
        path_type: t.Any = None,
        executable: bool = False,
    ) -> None:
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def _result(self, value: str) -> t.Any:
        if self.path_type is None or self.path_type is str:
            return value
        return self.path_type(value)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            value = os.fsdecode(value)
        value = os.fspath(value)
        if self.allow_dash and value == "-":
            return self._result(value)
        path = value
        if self.resolve_path:
            path = os.path.realpath(os.path.abspath(path))
        if not os.path.exists(path):
            if self.exists:
                self.fail(f"{value!r} does not exist.", param, ctx)
            return self._result(path)
        if os.path.isdir(path):
            if not self.dir_okay:
                self.fail(f"{value!r} is a directory.", param, ctx)
        elif not self.file_okay:
            self.fail(f"{value!r} is a file.", param, ctx)
        if self.readable and not os.access(path, os.R_OK):
            self.fail(f"{value!r} is not readable.", param, ctx)
        if self.writable and not os.access(path, os.W_OK):
            self.fail(f"{value!r} is not writable.", param, ctx)
        if self.executable and not os.access(path, os.X_OK):
            self.fail(f"{value!r} is not executable.", param, ctx)
        return self._result(path)

    def shell_complete(self, ctx, param, incomplete):
        kind = "dir" if (self.dir_okay and not self.file_okay) else "file"
        return [PathRequest(kind, incomplete)]


class FuncParamType(ParamType):
    """Adapts a conversion function ``f(token) -> value`` that refuses with ``ValueError``."""

    def __init__(self, func: t.Callable[[t.Any], t.Any]) -> None:
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is not valid.", param, ctx)


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()

_PY_TYPES = {str: STRING, int: INT, float: FLOAT, bool: BOOL, uuid.UUID: UUID}


def _infer_from_default(default: t.Any) -> ParamType:
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, str):
        return STRING
    return STRING


def convert_type(ty: t.Any, default: t.Any = None) -> ParamType:
    """Return a :class:`ParamType` for ``ty``, inferring it from ``default`` when ``ty`` is None."""
    if ty is None:
        if default is None or callable(default):
            return STRING
        if isinstance(default, (list, tuple)):
            if not default:
                return STRING
            return _infer_from_default(default[0])
        return _infer_from_default(default)
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type):
        if issubclass(ty, ParamType):
            return ty()
        if ty in _PY_TYPES:
            return _PY_TYPES[ty]
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")
