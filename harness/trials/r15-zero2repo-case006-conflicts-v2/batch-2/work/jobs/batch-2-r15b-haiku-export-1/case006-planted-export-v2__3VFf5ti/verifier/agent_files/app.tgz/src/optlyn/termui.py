"""Interactive helpers: prompts, confirmation, pagers, progress bars, editor and launcher."""

import contextlib
import os
import shlex
import shutil
import subprocess
import sys
import tempfile
import time
import typing as t

from .exceptions import Abort, BadParameter
from .paramtypes import ParamType, convert_type
from .utils import echo, is_interactive, isatty, style, unstyle

__all__ = [
    "echo",
    "style",
    "unstyle",
    "prompt",
    "confirm",
    "getchar",
    "pause",
    "edit",
    "launch",
    "clear",
    "progressbar",
    "echo_via_pager",
    "get_pager_file",
]

_echo_stdin = False


def set_echo_stdin(flag: bool) -> bool:
    """Used by the in-process runner to echo standard-input reads. Returns the previous value."""
    global _echo_stdin
    previous = _echo_stdin
    _echo_stdin = flag
    return previous


def _read_line(hide_input: bool) -> t.Optional[str]:
    stdin = sys.stdin
    if hide_input and isatty(stdin):
        try:
            import termios

            fd = stdin.fileno()
            old = termios.tcgetattr(fd)
            new = termios.tcgetattr(fd)
            new[3] &= ~termios.ECHO
            termios.tcsetattr(fd, termios.TCSADRAIN, new)
            try:
                line = stdin.readline()
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        except (ImportError, OSError, ValueError, AttributeError):
            line = stdin.readline()
    else:
        line = stdin.readline()
    if line == "":
        return None
    return line.rstrip("\r\n")


def _ask(text: str, hide_input: bool = False, err: bool = False) -> str:
    out = sys.stderr if err else sys.stdout
    if not isatty(out):
        text = unstyle(text)
    out.write(text)
    out.flush()
    line = _read_line(hide_input)
    if line is None:
        out.write("\n")
        out.flush()
        raise Abort()
    if hide_input:
        out.write("\n")
    elif _echo_stdin or not isatty(sys.stdin):
        out.write(line + "\n")
    out.flush()
    return line


def prompt(
    text: str,
    default: t.Any = None,
    hide_input: bool = False,
    confirmation_prompt: bool = False,
    type: t.Any = None,
    value_proc: t.Optional[t.Callable[[str], t.Any]] = None,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
) -> t.Any:
    """Ask for a value until it converts, returning the converted value.

    An empty answer takes ``default`` when one is given. End of input aborts.
    """
    ptype: ParamType = convert_type(type, default)
    while True:
        shown = ""
        if default is not None and show_default and not hide_input:
            shown = f" [{default}]"
        answer = _ask(f"{text}{shown}{prompt_suffix}", hide_input, err)
        if answer == "":
            if default is None:
                continue
            value: t.Any = default
        else:
            value = answer
        try:
            converted = ptype.convert(value, None, None)
        except BadParameter as e:
            echo(f"Error: {e.message}", err=True)
            continue
        if value_proc is not None:
            converted = value_proc(converted)
        if confirmation_prompt:
            second = _ask(f"Repeat for confirmation{prompt_suffix}", hide_input, err)
            if second != answer:
                echo("Error: The two entered values do not match.", err=True)
                continue
        return converted


def confirm(
    text: str,
    default: bool = False,
    abort: bool = False,
    prompt_suffix: str = ": ",
    show_default: bool = True,
    err: bool = False,
) -> bool:
    """Ask a yes/no question. Abort is raised on a no when ``abort`` is true."""
    suffix = " [Y/n]" if default else " [y/N]"
    if not show_default:
        suffix = ""
    while True:
        answer = _ask(f"{text}{suffix}{prompt_suffix}", False, err).strip().lower()
        if answer == "":
            result = default
            break
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        echo("Error: invalid input", err=True)
    if abort and not result:
        raise Abort()
    return result


def getchar(echo: bool = False) -> str:
    """Read one character from the terminal, even when standard input is a pipe."""
    if sys.stdin is sys.__stdin__ and not isatty(sys.stdin):
        tty = None
        try:
            tty = open("/dev/tty", "rb", buffering=0)
        except OSError:
            tty = None
        if tty is not None:
            try:
                import termios
                import tty as _tty

                fd = tty.fileno()
                old = termios.tcgetattr(fd)
                try:
                    _tty.setraw(fd)
                    data = os.read(fd, 1)
                finally:
                    termios.tcsetattr(fd, termios.TCSADRAIN, old)
            except (ImportError, OSError, termios_error()):
                data = b""
            finally:
                tty.close()
            if not data:
                raise EOFError()
            char = data.decode("utf-8", "replace")
            if char == "\x03":
                raise KeyboardInterrupt()
            if char == "\x04":
                raise EOFError()
            if echo:
                sys.stdout.write(char)
                sys.stdout.flush()
            return char
    char = sys.stdin.read(1)
    if char == "":
        raise EOFError()
    if char == "\x03":
        raise KeyboardInterrupt()
    if char == "\x04":
        raise EOFError()
    if echo:
        sys.stdout.write(char)
        sys.stdout.flush()
    return char


def termios_error() -> t.Any:
    try:
        import termios

        return termios.error
    except ImportError:  # pragma: no cover - non-POSIX
        return OSError


def pause(info: t.Optional[str] = None, err: bool = False) -> None:
    """Wait for a key press when the session is interactive; otherwise return at once."""
    if not is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    echo(info, err=err, nl=False)
    try:
        getchar()
    except (EOFError, KeyboardInterrupt):
        pass
    echo("", err=err)


def edit(
    text: t.Optional[t.Union[str, bytes]] = None,
    editor: t.Optional[str] = None,
    env: t.Optional[t.Mapping[str, str]] = None,
    require_save: bool = True,
    extension: str = ".txt",
    filename: t.Optional[str] = None,
) -> t.Optional[str]:
    """Open ``text`` (or ``filename``) in an editor. Returns the saved text, or None."""
    command_line = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    run_env = dict(os.environ)
    if env:
        run_env.update(env)
    if filename is not None:
        path = filename
        created = False
    else:
        data = text or ""
        if isinstance(data, str):
            data = data.replace("\n", "\r\n") if os.name == "nt" else data
            payload = data.encode("utf-8")
        else:
            payload = data
        fd, path = tempfile.mkstemp(suffix=extension)
        with os.fdopen(fd, "wb") as handle:
            handle.write(payload)
        created = True
    try:
        before = _file_stamp(path)
        subprocess.call(shlex.split(command_line) + [path], env=run_env)
        if filename is not None:
            return None
        with open(path, "rb") as handle:
            result = handle.read().decode("utf-8", "replace")
        if require_save and _file_stamp(path) == before and result == (text or ""):
            return None
        return result
    finally:
        if created:
            try:
                os.remove(path)
            except OSError:
                pass


def _file_stamp(path: str) -> t.Tuple[float, int]:
    st = os.stat(path)
    return (st.st_mtime, st.st_size)


def launch(url: str, wait: bool = False, locate: bool = False) -> int:
    """Open ``url`` or a file with the default application. Returns the opener's status."""
    opener = shutil.which("xdg-open") or shutil.which("open") or shutil.which("start")
    if opener is None:
        return 127
    args = [opener]
    if locate and os.path.exists(url):
        args = [opener, os.path.dirname(os.path.abspath(url))]
    else:
        args.append(url)
    process = subprocess.Popen(args)
    if wait:
        return process.wait()
    return 0


def clear() -> None:
    """Clear the terminal screen. Does nothing when standard output is not a terminal."""
    if not isatty(sys.stdout):
        return
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()


class ProgressBar:
    """Iterates a sequence while showing progress when attached to a terminal."""

    def __init__(
        self,
        iterable: t.Optional[t.Iterable[t.Any]],
        length: t.Optional[int] = None,
        label: t.Optional[str] = None,
        hidden: bool = False,
        file: t.Any = None,
        width: int = 36,
        **options: t.Any,
    ) -> None:
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)  # type: ignore[arg-type]
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.file = file or sys.stdout
        self.width = width
        self.pos = 0
        self.start = time.time()
        self.show = (not hidden) and isatty(self.file)
        self._printed_label = False

    def _render(self) -> None:
        if not self.show:
            return
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            filled = int(self.width * frac)
            bar = "#" * filled + "-" * (self.width - filled)
            elapsed = time.time() - self.start
            eta = int(elapsed / frac - elapsed) if frac > 0 else 0
            text = f"\r{self.label} [{bar}] {self.pos}/{self.length} eta {eta}s"
        else:
            text = f"\r{self.label} {self.pos}"
        self.file.write(text)
        self.file.flush()

    def _print_label_once(self) -> None:
        if self.label and not self.hidden and not self.show and not self._printed_label:
            self._printed_label = True
            self.file.write(self.label + "\n")
            self.file.flush()

    def update(self, n_steps: int = 1) -> None:
        self.pos += n_steps
        self._render()

    def __iter__(self) -> t.Iterator[t.Any]:
        self._print_label_once()
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)
        if self.show:
            self.file.write("\n")
            self.file.flush()


@contextlib.contextmanager
def progressbar(
    iterable: t.Optional[t.Iterable[t.Any]] = None,
    length: t.Optional[int] = None,
    label: t.Optional[str] = None,
    hidden: bool = False,
    **options: t.Any,
) -> t.Iterator[ProgressBar]:
    """Context manager yielding a progress bar."""
    bar = ProgressBar(iterable, length=length, label=label, hidden=hidden, **options)
    bar._print_label_once()
    try:
        yield bar
    finally:
        if bar.show:
            bar.file.write("\n")
            bar.file.flush()


def _pager_command() -> t.Optional[t.List[str]]:
    pager = os.environ.get("PAGER")
    if pager:
        return shlex.split(pager)
    return None


def _strip_for(color: t.Optional[bool], stream: t.Any) -> bool:
    if color is None:
        return not isatty(stream)
    return not color


@contextlib.contextmanager
def get_pager_file(color: t.Optional[bool] = None) -> t.Iterator[t.Any]:
    """Yield a writable text stream that goes through the pager when the session is interactive."""
    command = _pager_command() if is_interactive() else None
    if command is None:
        yield _StrippingStream(sys.stdout, color)
        return
    process = subprocess.Popen(command, stdin=subprocess.PIPE, text=True, encoding="utf-8", errors="replace")
    try:
        yield _StrippingStream(process.stdin, color, keep_tty=True)
    finally:
        try:
            process.stdin.close()
        except OSError:
            pass
        process.wait()


class _StrippingStream:
    def __init__(self, stream: t.Any, color: t.Optional[bool], keep_tty: bool = False) -> None:
        self._stream = stream
        self._strip = (not color) if color is not None else (not keep_tty and not isatty(stream))

    def write(self, text: str) -> int:
        if self._strip:
            text = unstyle(text)
        self._stream.write(text)
        self._stream.flush()
        return len(text)

    def flush(self) -> None:
        self._stream.flush()

    def __getattr__(self, name: str) -> t.Any:
        return getattr(self._stream, name)


def echo_via_pager(text_or_generator: t.Any, color: t.Optional[bool] = None) -> None:
    """Write text through the pager when interactive, else straight to standard output.

    Accepts a string, an iterable of strings, or a zero-argument callable returning either.
    """
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks: t.Iterable[str] = [text_or_generator]
    else:
        chunks = text_or_generator
    with get_pager_file(color) as stream:
        for chunk in chunks:
            stream.write(str(chunk))
            stream.flush()
