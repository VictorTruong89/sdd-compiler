import os

import pytest

import optlyn as o
from optlyn.testing import CliRunner


@pytest.fixture
def runner():
    return CliRunner()


# -- FP-01: declaration and naming ---------------------------------------


def test_command_name_derived_from_function():
    @o.command()
    def sync_cmd():
        pass

    @o.group()
    def top_grp():
        pass

    assert sync_cmd.name == "sync"
    assert top_grp.name == "top"


def test_explicit_name_replaces_derived_name(runner):
    @o.command("go")
    def run_it():
        o.echo("ran")

    assert runner.invoke(run_it, []).output == "ran\n"
    assert runner.invoke(run_it, []).exit_code == 0


def test_command_runs_once_and_returns_success(runner):
    calls = []

    @o.command()
    def once():
        calls.append(1)

    result = runner.invoke(once, [])
    assert result.exit_code == 0
    assert calls == [1]


def test_deprecated_command_still_runs(runner):
    @o.command(deprecated="use other")
    def old():
        o.echo("body")

    result = runner.invoke(old, [])
    assert result.exit_code == 0
    assert "body" in result.output
    assert "deprecated" in result.stderr.lower()
    assert "use other" in result.stderr


def test_unknown_option_is_usage_error(runner):
    @o.command()
    def cmd():
        raise AssertionError("must not run")

    result = runner.invoke(cmd, ["--nope"])
    assert result.exit_code == 2
    assert "No such option" in result.stderr


# -- FP-02: help -----------------------------------------------------------


def test_AC_N_001013_count_metavar(runner):
    @o.command()
    @o.option("--count", type=int, default=1)
    def cmd(count):
        pass

    assert "--count COUNT" in runner.invoke(cmd, ["--help"]).output


def test_help_exits_zero_and_skips_callback(runner):
    ran = []

    @o.command()
    def cmd():
        ran.append(1)

    result = runner.invoke(cmd, ["--help"])
    assert result.exit_code == 0
    assert ran == []
    assert "Usage:" in result.stdout


def test_form_feed_truncates_docstring(runner):
    @o.command()
    def cmd():
        """Visible text.

        \f
        Hidden text.
        """

    out = runner.invoke(cmd, ["--help"]).output
    assert "Visible text." in out
    assert "Hidden text" not in out
    assert "\f" not in out


def test_group_without_subcommand_is_usage_failure(runner):
    @o.group()
    def grp():
        """Group help."""

    @grp.command()
    def child():
        pass

    result = runner.invoke(grp, [])
    assert result.exit_code == 2
    assert "Usage:" in result.output or "Usage:" in result.stderr


def test_eager_version_option_prints_custom_identity(runner):
    @o.command()
    @o.custom_version_option(lambda ctx: "v9.9")
    def cmd():
        raise AssertionError

    result = runner.invoke(cmd, ["--version"])
    assert result.exit_code == 0
    assert result.stdout == "v9.9\n"


def test_help_before_and_after_subcommand(runner):
    @o.group()
    def grp():
        """G"""

    ran = []

    @grp.command()
    def sub():
        ran.append(1)

    assert runner.invoke(grp, ["--help"]).exit_code == 0
    assert ran == []
    r = runner.invoke(grp, ["sub", "--help"])
    assert r.exit_code == 0 and ran == []


# -- FP-03: options ----------------------------------------------------------


def test_short_flag_stacking(runner):
    @o.command()
    @o.option("-a", is_flag=True)
    @o.option("-b", is_flag=True)
    @o.option("-c", default="x")
    def cmd(a, b, c):
        o.echo(f"{a} {b} {c}")

    assert runner.invoke(cmd, ["-ab", "-c", "v"]).output == "True True v\n"
    assert runner.invoke(cmd, ["-abcZ"]).output == "True True Z\n"


def test_long_option_forms(runner):
    @o.command()
    @o.option("--name")
    def cmd(name):
        o.echo(name)

    assert runner.invoke(cmd, ["--name=ann"]).output == "ann\n"
    assert runner.invoke(cmd, ["--name", "bo"]).output == "bo\n"


def test_double_dash_ends_options(runner):
    @o.command()
    @o.option("--flag", is_flag=True)
    @o.argument("rest", nargs=-1)
    def cmd(flag, rest):
        o.echo(f"{flag} {rest}")

    assert runner.invoke(cmd, ["--", "--flag", "x"]).output == "False ('--flag', 'x')\n"


def test_on_off_pair(runner):
    @o.command()
    @o.option("--shout/--no-shout", default=False)
    def cmd(shout):
        o.echo(str(shout))

    assert runner.invoke(cmd, ["--shout"]).output == "True\n"
    assert runner.invoke(cmd, ["--no-shout"]).output == "False\n"
    assert runner.invoke(cmd, []).output == "False\n"


def test_counting_option(runner):
    @o.command()
    @o.option("-v", count=True)
    def cmd(v):
        o.echo(str(v))

    assert runner.invoke(cmd, ["-vvv"]).output == "3\n"
    assert runner.invoke(cmd, []).output == "0\n"


def test_repeatable_option_collects_in_order(runner):
    @o.command()
    @o.option("--tag", multiple=True)
    def cmd(tag):
        o.echo(repr(tag))

    assert runner.invoke(cmd, ["--tag", "a", "--tag", "b"]).output == "('a', 'b')\n"
    assert runner.invoke(cmd, []).output == "()\n"


def test_multi_value_option(runner):
    @o.command()
    @o.option("--pos", nargs=2, type=int)
    def cmd(pos):
        o.echo(repr(pos))

    assert runner.invoke(cmd, ["--pos", "1", "2"]).output == "(1, 2)\n"
    assert runner.invoke(cmd, ["--pos", "1"]).exit_code == 2


def test_required_option_missing(runner):
    @o.command()
    @o.option("--key", required=True)
    def cmd(key):
        raise AssertionError

    result = runner.invoke(cmd, [])
    assert result.exit_code == 2
    assert "--key" in result.stderr


def test_env_var_fills_option(runner):
    @o.command()
    @o.option("--level", envvar="LVL_TEST_X")
    def cmd(level):
        o.echo(level)

    assert runner.invoke(cmd, [], env={"LVL_TEST_X": "high"}).output == "high\n"
    assert runner.invoke(cmd, ["--level", "low"], env={"LVL_TEST_X": "high"}).output == "low\n"


def test_empty_env_var_is_not_a_value(runner):
    @o.command()
    @o.option("--level", envvar="LVL_EMPTY_X", default="d")
    def cmd(level):
        o.echo(level)

    assert runner.invoke(cmd, [], env={"LVL_EMPTY_X": ""}).output == "d\n"


def test_bool_env_flag_rules(runner):
    @o.command()
    @o.option("--debug", is_flag=True, envvar="DBG_X")
    def cmd(debug):
        o.echo(str(debug))

    assert runner.invoke(cmd, [], env={"DBG_X": " YES "}).output == "True\n"
    assert runner.invoke(cmd, [], env={"DBG_X": "off"}).output == "False\n"
    assert runner.invoke(cmd, [], env={"DBG_X": "maybe"}).exit_code == 2


def test_auto_envvar_prefix(runner):
    @o.command()
    @o.option("--port", type=int, default=1)
    def cmd(port):
        o.echo(str(port))

    r = runner.invoke(cmd, [], env={"APP_PORT": "9"}, auto_envvar_prefix="APP")
    assert r.output == "9\n"


def test_default_map_fills_and_env_wins_over_declared_default(runner):
    @o.command()
    @o.option("--n", type=int, default=1)
    def cmd(n):
        o.echo(str(n))

    assert runner.invoke(cmd, [], default_map={"n": 5}).output == "5\n"
    assert runner.invoke(cmd, ["--n", "7"], default_map={"n": 5}).output == "7\n"


def test_parameter_callback_refuses_value(runner):
    def check(ctx, param, value):
        if value < 0:
            raise o.BadParameter("must be positive")
        return value

    @o.command()
    @o.option("--n", type=int, callback=check)
    def cmd(n):
        raise AssertionError

    result = runner.invoke(cmd, ["--n", "-1"])
    assert result.exit_code == 2
    assert "must be positive" in result.stderr


def test_callable_default(runner):
    @o.command()
    @o.option("--name", default=lambda: "dynamic")
    def cmd(name):
        o.echo(name)

    assert runner.invoke(cmd, []).output == "dynamic\n"


def test_get_parameter_source(runner):
    seen = {}

    @o.command()
    @o.option("--a", default=1)
    @o.option("--b", default=2)
    @o.pass_context
    def cmd(ctx, a, b):
        seen["a"] = ctx.get_parameter_source("a")
        seen["b"] = ctx.get_parameter_source("b")
        seen["zz"] = ctx.get_parameter_source("zz")

    runner.invoke(cmd, ["--a", "5"])
    assert seen["a"] is o.ParameterSource.COMMANDLINE
    assert seen["b"] is o.ParameterSource.DEFAULT
    assert seen["zz"] is None


# -- FP-04: arguments ------------------------------------------------------


def test_variadic_argument_and_omitted_is_empty_tuple(runner):
    @o.command()
    @o.argument("items", nargs=-1)
    def cmd(items):
        o.echo(repr(items))

    assert runner.invoke(cmd, ["a", "b"]).output == "('a', 'b')\n"
    assert runner.invoke(cmd, []).output == "()\n"


def test_extra_arguments_are_usage_error(runner):
    @o.command()
    @o.argument("one")
    def cmd(one):
        raise AssertionError

    assert runner.invoke(cmd, ["a", "b"]).exit_code == 2


def test_allow_extra_args_tolerates_plain_extra(runner):
    @o.command(context_settings={"allow_extra_args": True})
    @o.argument("one")
    def cmd(one):
        o.echo(one)

    r = runner.invoke(cmd, ["a", "b"])
    assert r.exit_code == 0 and r.output == "a\n"


# -- FP-05: types -------------------------------------------------------------


def test_choice_delivers_original_member(runner):
    import enum

    class Color(enum.Enum):
        RED = 1

    @o.command()
    @o.option("--c", type=o.Choice(Color, case_sensitive=False))
    def cmd(c):
        o.echo(repr(c))

    assert runner.invoke(cmd, ["--c", "red"]).output == "<Color.RED: 1>\n"
    assert runner.invoke(cmd, ["--c", "blue"]).exit_code == 2


def test_datetime_default_formats(runner):
    @o.command()
    @o.option("--when", type=o.ParamType and __import__("optlyn").DateTime())
    def cmd(when):
        o.echo(when.isoformat())

    assert runner.invoke(cmd, ["--when", "2024-01-02 03:04:05"]).output == "2024-01-02T03:04:05\n"
    assert runner.invoke(cmd, ["--when", "2024/01/02"]).exit_code == 2


def test_int_range_clamp_open_bound(runner):
    @o.command()
    @o.option("--n", type=o.IntRange(0, 10, min_open=True, clamp=True), default=5)
    def cmd(n):
        o.echo(str(n))

    assert runner.invoke(cmd, ["--n", "0"]).output == "1\n"
    assert runner.invoke(cmd, ["--n", "99"]).output == "10\n"


def test_float_range_refuses_open_clamp():
    with pytest.raises(ValueError):
        o.FloatRange(0.0, 1.0, min_open=True, clamp=True)


def test_bool_text_conversion(runner):
    @o.command()
    @o.option("--b", type=bool)
    def cmd(b):
        o.echo(str(b))

    assert runner.invoke(cmd, ["--b", "Y"]).output == "True\n"
    assert runner.invoke(cmd, ["--b", "nah"]).exit_code == 2


def test_tuple_type(runner):
    @o.command()
    @o.option("--pair", type=o.Tuple([str, int]))
    def cmd(pair):
        o.echo(repr(pair))

    assert runner.invoke(cmd, ["--pair", "a", "3"]).output == "('a', 3)\n"


def test_custom_paramtype(runner):
    class Upper(o.ParamType):
        name = "upper"

        def convert(self, value, param, ctx):
            if isinstance(value, str):
                return value.upper()
            return value

    @o.command()
    @o.argument("word", type=Upper())
    def cmd(word):
        o.echo(word)

    assert runner.invoke(cmd, ["hi"]).output == "HI\n"


# -- FP-06: groups -----------------------------------------------------------


def test_group_callback_runs_before_child(runner):
    order = []

    @o.group()
    @o.option("--x", default="d")
    def grp(x):
        order.append(("grp", x))

    @grp.command()
    def child():
        order.append("child")

    runner.invoke(grp, ["--x", "1", "child"])
    assert order == [("grp", "1"), "child"]


def test_unknown_subcommand_skips_group_callback(runner):
    ran = []

    @o.group()
    def grp():
        ran.append(1)

    @grp.command()
    def child():
        pass

    result = runner.invoke(grp, ["nope"])
    assert result.exit_code == 2
    assert ran == []
    assert "No such command" in result.stderr


def test_nested_groups(runner):
    @o.group()
    def outer():
        pass

    @outer.group()
    def inner():
        pass

    @inner.command()
    def leaf():
        o.echo("leaf")

    assert runner.invoke(outer, ["inner", "leaf"]).output == "leaf\n"


def test_invoke_without_command_and_context_flag(runner):
    seen = []

    @o.group(invoke_without_command=True)
    @o.pass_context
    def grp(ctx):
        seen.append(ctx.invoked_subcommand)

    runner.invoke(grp, [])
    assert seen == [None]


def test_chain_group_collects_results(runner):
    @o.group(chain=True)
    def grp():
        pass

    @grp.command()
    @o.argument("v")
    def a(v):
        return "A" + v

    @grp.command()
    @o.argument("v")
    def b(v):
        return "B" + v

    result = grp.main(["a", "1", "b", "2"], prog_name="g", standalone_mode=False)
    assert result == ["A1", "B2"]


def test_chain_result_callback_receives_list(runner):
    @o.group(chain=True)
    def grp():
        pass

    got = []

    @grp.result_callback()
    def done(results):
        got.append(results)

    @grp.command()
    def a():
        return 1

    grp.main(["a", "a"], prog_name="g", standalone_mode=False)
    assert got == [[1, 1]]


def test_command_collection_union():
    @o.group()
    def first():
        pass

    @first.command()
    def one():
        o.echo("one")

    @o.group()
    def second():
        pass

    @second.command()
    def two():
        o.echo("two")

    coll = o.CommandCollection(name="all", sources=[first, second])
    r = CliRunner().invoke(coll, ["two"])
    assert r.output == "two\n"
    assert coll.list_commands(None) == ["one", "two"]


def test_hidden_command_still_dispatches_but_not_listed(runner):
    @o.group()
    def grp():
        pass

    @grp.command(hidden=True)
    def secret():
        o.echo("s")

    assert runner.invoke(grp, ["secret"]).output == "s\n"
    assert "secret" not in runner.invoke(grp, ["--help"]).output


def test_chain_group_cannot_contain_group():
    @o.group(chain=True)
    def grp():
        pass

    with pytest.raises(TypeError):
        @grp.group()
        def nested():
            pass


# -- FP-07: context ----------------------------------------------------------


def test_pass_obj_and_ensure_object(runner):
    class Config:
        def __init__(self):
            self.v = 3

    @o.group(context_settings={})
    @o.pass_context
    def grp(ctx):
        ctx.obj = Config()

    @grp.command()
    @o.make_pass_decorator(Config)
    def child(cfg):
        o.echo(str(cfg.v))

    assert runner.invoke(grp, ["child"]).output == "3\n"


def test_context_invoke_forward(runner):
    @o.command()
    @o.option("--x", default=1)
    def target(x):
        o.echo(f"target {x}")

    @o.command()
    @o.option("--x", default=7)
    @o.pass_context
    def caller(ctx, x):
        ctx.forward(target)

    assert runner.invoke(caller, []).output == "target 7\n"


# -- FP-08: prompts --------------------------------------------------------


def test_prompt_when_required_and_missing(runner):
    @o.command()
    @o.option("--name", prompt=True, required=True)
    def cmd(name):
        o.echo(f"hi {name}")

    result = runner.invoke(cmd, [], input="ann\n")
    assert "hi ann" in result.stdout


def test_prompt_on_flag_present_without_value_uses_default(runner):
    @o.command()
    @o.option("--name", prompt=True, default="zed")
    def cmd(name):
        o.echo(name)

    result = runner.invoke(cmd, ["--name"], input="\n")
    assert result.output.strip().endswith("zed")


def test_omitted_non_required_prompt_does_not_read_input(runner):
    @o.command()
    @o.option("--name", prompt=True, default="dflt")
    def cmd(name):
        o.echo(name)

    result = runner.invoke(cmd, [], input="typed\n")
    assert result.output == "dflt\n"


def test_confirmation_option_declines_aborts(runner):
    @o.command()
    @o.confirmation_option(prompt="Sure?")
    def cmd():
        o.echo("ran")

    result = runner.invoke(cmd, [], input="n\n")
    assert result.exit_code == 1
    assert "ran" not in result.output
    assert "Aborted" in result.stderr


def test_confirmation_option_flag_skips_question(runner):
    @o.command()
    @o.confirmation_option()
    def cmd():
        o.echo("ran")

    result = runner.invoke(cmd, ["--yes"])
    assert result.output == "ran\n"


def test_password_option_confirms(runner):
    @o.command()
    @o.password_option()
    def cmd(password):
        o.echo(password)

    result = runner.invoke(cmd, ["--password"], input="abc\nabc\n")
    assert result.exit_code == 0
    assert result.output.endswith("abc\n")
    assert "Password: abc" not in result.output


def test_password_option_mismatch_asks_pair_again(runner):
    @o.command()
    @o.password_option()
    def cmd(password):
        o.echo(password)

    result = runner.invoke(cmd, ["--password"], input="abc\nxyz\nsecret\nsecret\n")
    assert result.exit_code == 0
    assert result.output.endswith("secret\n")
    assert "do not match" in result.stderr


def test_standalone_confirm_yes_no_and_default():
    runner = CliRunner()

    @o.command()
    def cmd():
        o.echo(str(o.confirm("Go?", default=True)))

    assert runner.invoke(cmd, [], input="\n").output.strip().endswith("True")
    assert runner.invoke(cmd, [], input="YES\n").output.strip().endswith("True")
    assert runner.invoke(cmd, [], input="no\n").output.strip().endswith("False")


def test_eof_in_prompt_is_abort(runner):
    @o.command()
    @o.option("--name", prompt=True, required=True)
    def cmd(name):
        raise AssertionError

    result = runner.invoke(cmd, [], input="")
    assert result.exit_code == 1


# -- FP-09: files and paths ----------------------------------------------------


def test_file_write_is_lazy_and_read_fails_for_missing(runner):
    @o.command()
    @o.argument("out", type=o.File("w"))
    def cmd(out):
        pass

    with runner.isolated_filesystem():
        result = runner.invoke(cmd, ["never.txt"])
        assert result.exit_code == 0
        assert not os.path.exists("never.txt")


def test_file_read_missing_is_usage_error(runner):
    @o.command()
    @o.argument("src", type=o.File("r"))
    def cmd(src):
        raise AssertionError

    with runner.isolated_filesystem():
        result = runner.invoke(cmd, ["missing.txt"])
        assert result.exit_code == 2
        assert "missing.txt" in result.stderr


def test_file_write_and_read_round_trip(runner):
    @o.command()
    @o.argument("out", type=o.File("w", encoding="utf-8"))
    def cmd(out):
        out.write("héllo\n")

    with runner.isolated_filesystem():
        assert runner.invoke(cmd, ["f.txt"]).exit_code == 0
        assert open("f.txt", encoding="utf-8").read() == "héllo\n"


def test_path_exists_check(runner):
    @o.command()
    @o.argument("p", type=o.Path(exists=True))
    def cmd(p):
        o.echo(p)

    with runner.isolated_filesystem():
        open("here.txt", "w").close()
        assert runner.invoke(cmd, ["here.txt"]).output == "here.txt\n"
        assert runner.invoke(cmd, ["gone.txt"]).exit_code == 2


def test_dash_file_is_stdin(runner):
    @o.command()
    @o.argument("src", type=o.File("r"))
    def cmd(src):
        o.echo(src.read().upper())

    assert runner.invoke(cmd, ["-"], input="abc").output == "ABC\n"


# -- FP-11: terminal helpers ------------------------------------------------


def test_echo_strips_styles_when_not_terminal(runner):
    @o.command()
    def cmd():
        o.echo(o.style("plain", fg="red", bold=True))

    out = runner.invoke(cmd, []).output
    assert out == "plain\n"


def test_color_true_keeps_styles(runner):
    @o.command()
    def cmd():
        o.echo(o.style("x", fg="red"))

    out = runner.invoke(cmd, [], color=True).output
    assert "\x1b[31m" in out


def test_style_invalid_color_raises():
    with pytest.raises(ValueError):
        o.style("x", fg="ultraviolet")


def test_style_rgb_and_index():
    assert o.style("x", fg=(1, 2, 3)).startswith("\x1b[38;2;1;2;3m")
    assert o.style("x", bg=200).startswith("\x1b[48;5;200m")
    assert o.unstyle(o.style("x", bold=True)) == "x"


def test_echo_to_stderr(runner):
    @o.command()
    def cmd():
        o.echo("to-err", err=True)

    r = runner.invoke(cmd, [])
    assert r.stderr == "to-err\n"
    assert r.stdout == ""


def test_progressbar_visits_every_item_without_tty(runner):
    @o.command()
    def cmd():
        with o.progressbar(range(4), label="work") as bar:
            for _ in bar:
                pass
        o.echo("done")

    r = runner.invoke(cmd, [])
    assert "done" in r.output
    assert "work" in r.output


def test_progressbar_known_length_without_iterable(runner):
    @o.command()
    def cmd():
        with o.progressbar(length=3, label="steps", hidden=True) as bar:
            bar.update(3)
        o.echo("ok")

    r = runner.invoke(cmd, [])
    assert r.output == "ok\n"


def test_optional_value_option(runner):
    @o.command()
    @o.option("--color", is_flag=False, flag_value="auto", default="never")
    def cmd(color):
        o.echo(color)

    assert runner.invoke(cmd, []).output == "never\n"
    assert runner.invoke(cmd, ["--color"]).output == "auto\n"
    assert runner.invoke(cmd, ["--color", "always"]).output == "always\n"


def test_wrap_text_accepts_any_string():
    from optlyn.formatting import wrap_text

    assert wrap_text("a b c " * 30, width=20)
    assert wrap_text("", width=10) == ""


def test_format_filename_and_app_dir():
    assert o.format_filename("abc") == "abc"
    assert o.get_app_dir("My App", force_posix=True).endswith("/.my-app")


# -- FP-12: shell completion -------------------------------------------------


def test_bash_source_script(runner):
    @o.group()
    def tool():
        pass

    @tool.command()
    def run():
        pass

    r = runner.invoke(tool, [], prog_name="tool", env={"_TOOL_COMPLETE": "bash_source"})
    assert r.exit_code == 0
    assert "complete -o default -F" in r.output
    assert "_TOOL_COMPLETE=bash_complete" in r.output
    assert "Usage" not in r.output


def test_complete_suggests_subcommands(runner):
    @o.group()
    def tool():
        pass

    @tool.command()
    def build():
        pass

    @tool.command()
    def bench():
        pass

    r = runner.invoke(
        tool,
        [],
        prog_name="tool",
        env={"_TOOL_COMPLETE": "bash_complete", "COMP_WORDS": "tool b", "COMP_CWORD": "1"},
    )
    assert "plain,build" in r.output
    assert "plain,bench" in r.output


def test_complete_choice_values(runner):
    @o.command()
    @o.option("--mode", type=o.Choice(["fast", "slow"]))
    def cmd(mode):
        pass

    r = runner.invoke(
        cmd,
        [],
        prog_name="cli",
        env={"_CLI_COMPLETE": "bash_complete", "COMP_WORDS": "cli --mode f", "COMP_CWORD": "2"},
    )
    assert "plain,fast" in r.output
    assert "slow" not in r.output


def test_unknown_completion_instruction_prints_nothing(runner):
    @o.command()
    def cmd():
        raise AssertionError

    r = runner.invoke(cmd, [], prog_name="cli", env={"_CLI_COMPLETE": "tcsh_source"})
    assert r.output == ""


# -- FP-13: exit statuses ----------------------------------------------------


def test_author_clean_stop_status(runner):
    @o.command()
    @o.pass_context
    def cmd(ctx):
        ctx.exit(4)
        o.echo("never")

    r = runner.invoke(cmd, [])
    assert r.exit_code == 4
    assert "never" not in r.output


def test_abort_status(runner):
    @o.command()
    def cmd():
        raise o.Abort()

    r = runner.invoke(cmd, [])
    assert r.exit_code == 1
    assert "Aborted" in r.stderr


def test_standalone_off_returns_value_and_raises_failures():
    @o.command()
    def cmd():
        return 42

    assert cmd.main([], prog_name="c", standalone_mode=False) == 42

    @o.command()
    def bad():
        pass

    with pytest.raises(o.UsageError):
        bad.main(["--zz"], prog_name="c", standalone_mode=False)


# -- FP-14: in-process runner -----------------------------------------------


def test_runner_result_has_separate_streams(runner):
    @o.command()
    def cmd():
        o.echo("out")
        o.echo("err", err=True)

    r = runner.invoke(cmd, [])
    assert r.stdout == "out\n"
    assert r.stderr == "err\n"
    assert r.output == "out\nerr\n"
    assert r.stdout_bytes == b"out\n"


def test_runner_passes_exception_on_result(runner):
    @o.command()
    def cmd():
        raise ValueError("boom")

    r = runner.invoke(cmd, [])
    assert r.exit_code == 1
    assert isinstance(r.exception, ValueError)


def test_runner_can_propagate_exception():
    runner = CliRunner(catch_exceptions=False)

    @o.command()
    def cmd():
        raise ValueError("boom")

    with pytest.raises(ValueError):
        runner.invoke(cmd, [])


def test_runner_fd_capture_mode():
    runner = CliRunner(capture="fd")

    @o.command()
    def cmd():
        o.echo("fd-out")

    r = runner.invoke(cmd, [])
    assert "fd-out" in r.stdout


def test_isolated_filesystem_creates_child_under_parent(tmp_path):
    runner = CliRunner()
    with runner.isolated_filesystem(temp_dir=str(tmp_path)) as path:
        assert os.path.dirname(path) == str(tmp_path)
        assert os.getcwd() == os.path.realpath(path) or os.getcwd() == path
    assert os.path.isdir(path)


def test_runner_feeds_input_and_echoes_visible_prompt(runner):
    @o.command()
    @o.option("--n", prompt="N")
    def cmd(n):
        o.echo(f"got {n}")

    r = runner.invoke(cmd, ["--n"], input="5\n")
    assert "got 5" in r.output


# -- regression checks from manual verification -------------------------------


def test_chain_group_usage_line(runner):
    @o.group(chain=True)
    def pipe():
        """Pipeline."""

    @pipe.command()
    @o.argument("x")
    def a(x):
        pass

    usage = runner.invoke(pipe, ["--help"]).stdout.splitlines()[0]
    assert usage == "Usage: pipe [OPTIONS] COMMAND [ARGS]... [COMMAND [ARGS]...]..."


def test_eager_flag_typed_first_wins(runner):
    @o.command()
    @o.version_option("1.0", prog_name="t")
    @o.option("--x", required=True)
    def cmd(x):
        raise AssertionError

    assert runner.invoke(cmd, ["--version", "--help"]).stdout == "t, version 1.0\n"
    assert runner.invoke(cmd, ["--help", "--version"]).stdout.startswith("Usage:")


def test_version_detects_installed_package(runner):
    @o.command()
    @o.version_option(package_name="pytest", prog_name="t")
    def cmd():
        pass

    out = runner.invoke(cmd, ["--version"]).stdout
    assert out.startswith("t, version ") and out.strip().split()[-1][0].isdigit()


def test_feature_switch_without_default_is_none(runner):
    @o.command()
    @o.option("--a", "mode", flag_value="a")
    @o.option("--b", "mode", flag_value="b")
    def cmd(mode):
        o.echo(str(mode))

    assert runner.invoke(cmd, []).output == "None\n"
    assert runner.invoke(cmd, ["--b"]).output == "b\n"


def test_prefix_characters_other_than_dash(runner):
    @o.command()
    @o.option("+x", is_flag=True)
    @o.option("/y", default="d")
    def cmd(x, y):
        o.echo(f"{x} {y}")

    assert runner.invoke(cmd, ["+x", "/y", "v"]).output == "True v\n"


def test_add_help_option_disabled(runner):
    @o.command(add_help_option=False)
    def cmd():
        pass

    assert runner.invoke(cmd, ["--help"]).exit_code == 2


def test_backspace_paragraph_keeps_line_breaks(runner):
    @o.command()
    def cmd():
        """\b
        Line one
          kept indent
        """

    out = runner.invoke(cmd, ["--help"]).stdout
    assert "Line one\n  kept indent" in out
    assert "\b" not in out


def test_nested_default_map_and_env_prefix_for_subcommand(runner):
    @o.group()
    def top():
        pass

    @top.command()
    @o.option("--k", default="kk")
    def leaf(k):
        o.echo(f"k={k}")

    assert runner.invoke(top, ["leaf"], default_map={"leaf": {"k": "mapped"}}).output == "k=mapped\n"
    env_out = runner.invoke(top, ["leaf"], env={"APP_LEAF_K": "envk"}, auto_envvar_prefix="APP").output
    assert env_out == "k=envk\n"


def test_group_option_after_subcommand_is_usage_error(runner):
    @o.group()
    @o.option("--g", is_flag=True)
    def g(g):
        pass

    @g.command()
    @o.option("--s", is_flag=True)
    def sub(s):
        o.echo(f"s={s}")

    assert runner.invoke(g, ["--g", "sub"]).output == "s=False\n"
    assert runner.invoke(g, ["sub", "--g"]).exit_code == 2


def test_hidden_options_not_completed_but_still_parsed(runner):
    @o.command()
    @o.option("--visible")
    @o.option("--hidden-opt", hidden=True)
    def cmd(visible, hidden_opt):
        o.echo(str(hidden_opt))

    r = runner.invoke(
        cmd, [], prog_name="cmd", env={"_CMD_COMPLETE": "bash_complete", "COMP_WORDS": "cmd --", "COMP_CWORD": "1"}
    )
    assert "plain,--visible" in r.output
    assert "--hidden-opt" not in r.output
    assert runner.invoke(cmd, ["--hidden-opt", "3"]).output == "3\n"


def test_ascii_stream_echo_writes_utf8():
    import io

    buf = io.BytesIO()
    stream = io.TextIOWrapper(buf, encoding="ascii", errors="strict")
    o.echo("h\u00e9llo", file=stream)
    stream.flush()
    assert buf.getvalue() == "h\u00e9llo\n".encode("utf-8")


def test_prompt_reasks_until_valid(runner):
    @o.command()
    @o.option("--n", type=int, prompt=True, required=True)
    def cmd(n):
        o.echo(f"n={n}")

    result = runner.invoke(cmd, [], input="abc\n7\n")
    assert result.output.endswith("n=7\n")
    assert "not a valid integer" in result.stdout + result.stderr


def test_context_invoke_fills_defaults_for_missing_values(runner):
    @o.command()
    @o.option("--a", default=1)
    def inner(a):
        o.echo(f"inner a={a}")

    @o.command()
    @o.pass_context
    def outer(ctx):
        ctx.invoke(inner, a=9)
        ctx.invoke(inner)

    assert runner.invoke(outer, []).output == "inner a=9\ninner a=1\n"


def test_deprecated_argument_warns_only_when_supplied(runner):
    @o.command()
    @o.argument("old", required=False, deprecated="gone soon")
    def dep(old):
        pass

    assert runner.invoke(dep, []).stderr == ""
    assert "gone soon" in runner.invoke(dep, ["x"]).stderr


def test_deprecated_required_is_declaration_error():
    with pytest.raises(TypeError):
        o.option("--x", deprecated=True, required=True)(lambda x: None)


def test_bare_string_default_on_repeatable_option_is_usage_error(runner):
    @o.command()
    @o.option("--tag", multiple=True, default="single")
    def cmd(tag):
        pass

    result = runner.invoke(cmd, [])
    assert result.exit_code == 2
    assert "iterable" in result.stderr


def test_resource_closed_after_child_usage_failure(runner):
    closed = []

    class Res:
        def __enter__(self):
            return self

        def __exit__(self, *exc):
            closed.append(True)

    @o.group()
    @o.pass_context
    def grp(ctx):
        ctx.with_resource(Res())

    @grp.command()
    @o.option("--q", type=int, required=True)
    def child(q):
        pass

    assert runner.invoke(grp, ["child"]).exit_code == 2
    assert closed == [True]


def test_nested_group_without_leaf_shows_nested_help(runner):
    ran = []

    @o.group()
    def outer():
        ran.append("outer")

    @outer.group()
    def inner():
        """Inner help text."""
        ran.append("inner")

    result = runner.invoke(outer, ["inner"])
    assert result.exit_code == 2
    assert ran == ["outer"]
    assert "Inner help text." in result.stderr


def test_edit_returns_saved_text(tmp_path, monkeypatch):
    script = tmp_path / "ed.sh"
    script.write_text('#!/bin/sh\necho edited > "$1"\n')
    script.chmod(0o755)
    assert o.edit("orig", editor=str(script)) == "edited\n"
