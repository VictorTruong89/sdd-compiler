"""Exceptions Optlyn raises, and how usage failures are reported."""

import typing as t


class OptlynError(Exception):
    """Base class for errors Optlyn reports to the user.

    Standalone programs show the message on standard error and exit with
    :attr:`exit_code`.
    """

    exit_code = 1

    def __init__(self, message: str) -> None:
        super().__init__(message)
        self.message = message

    def format_message(self) -> str:
        return self.message

    def show(self) -> None:
        from .utils import echo

        echo(f"Error: {self.format_message()}", err=True)


class UsageError(OptlynError):
    """A command line that cannot be run as given. Exit status 2."""

    exit_code = 2

    def __init__(self, message: str, ctx: t.Any = None) -> None:
        super().__init__(message)
        self.ctx = ctx

    def show(self) -> None:
        from .utils import echo

        if self.ctx is not None:
            echo(self.ctx.get_usage(), err=True)
            hint_name = self.ctx.help_option_names[0] if self.ctx.help_option_names else None
            if hint_name:
                echo(f"Try '{self.ctx.command_path} {hint_name}' for help.", err=True)
            echo("", err=True)
        echo(f"Error: {self.format_message()}", err=True)


class BadParameter(UsageError):
    """A value was refused. Raise it from a type, a callback or a completion hook.

    The message is prefixed with the parameter's identity when the parameter is known.
    """

    def __init__(
        self,
        message: str = "",
        ctx: t.Any = None,
        param: t.Any = None,
        param_hint: t.Optional[str] = None,
    ) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def _hint(self) -> t.Optional[str]:
        if self.param_hint is not None:
            return self.param_hint
        if self.param is not None:
            return self.param.get_error_hint(self.ctx)
        return None

    def format_message(self) -> str:
        hint = self._hint()
        if hint is None:
            return self.message
        return f"Invalid value for {hint}: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter received no value."""

    def format_message(self) -> str:
        kind = getattr(self.param, "param_kind", "option")
        hint = self._hint()
        if hint is None:
            return self.message
        return f"Missing {kind} {hint}."


class BadOptionUsage(UsageError):
    """An option was used incorrectly (for example, it is missing its value)."""


class BadArgumentUsage(UsageError):
    """A positional argument was used incorrectly."""


class NoSuchOption(UsageError):
    """An option token matches no declared option."""

    def __init__(self, option_name: str, ctx: t.Any = None) -> None:
        super().__init__(f"No such option: {option_name}", ctx)
        self.option_name = option_name


class NoSuchCommand(UsageError):
    """A subcommand name matches no child of the group."""

    def __init__(self, name: str, ctx: t.Any = None) -> None:
        super().__init__(f"No such command '{name}'.", ctx)
        self.name = name


class MissingCommand(UsageError):
    """A group was invoked without naming a subcommand."""

    def __init__(self, ctx: t.Any = None) -> None:
        super().__init__("Missing command.", ctx)


class NoArgsIsHelp(UsageError):
    """Help was shown because the command was run with no arguments.

    The help page is already on standard error; only the usage exit status remains.
    """

    def __init__(self, message: str = "", ctx: t.Any = None) -> None:
        super().__init__(message, ctx)

    def show(self) -> None:
        return None


class FileError(OptlynError):
    """A file could not be opened at first I/O. General error, exit status 1."""

    def __init__(self, filename: str, message: str) -> None:
        super().__init__(f"Could not open file '{filename}': {message}")
        self.filename = filename


class Abort(RuntimeError):
    """The user or the author stopped the run. Reported as 'Aborted!' with status 1."""


class Exit(RuntimeError):
    """An author clean stop (or intentional help/version) with an exit status."""

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code
