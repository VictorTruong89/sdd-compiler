"""Shell completion: registration scripts and suggestion output."""

import os
import re
import typing as t

from .core import Argument, Command, Context, Group, Option, Parameter
from .paramtypes import PathRequest
from .utils import echo

SHELLS = ("bash", "zsh", "fish", "powershell")

_SAFE = re.compile(r"[^A-Za-z0-9_]")


class CompletionItem:
    """A suggestion: a value, an optional help string, and its kind (``plain`` by default)."""

    def __init__(self, value: str, help: t.Optional[str] = None, type: str = "plain") -> None:
        self.value = value
        self.help = help
        self.type = type

    def __repr__(self) -> str:
        return f"CompletionItem({self.value!r}, {self.help!r}, {self.type!r})"


def _func_name(prog_name: str) -> str:
    return "_" + _SAFE.sub("_", prog_name) + "_completion"


def _complete_var(prog_name: str) -> str:
    return "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"


_BASH = """\
__FUNC__() {
    local words="${COMP_WORDS[*]}"
    local IFS=$'\\n'
    local line kind value
    COMPREPLY=()
    for line in $(env COMP_WORDS="$words" COMP_CWORD=$COMP_CWORD __VAR__=bash_complete "$1"); do
        kind="${line%%,*}"
        value="${line#*,}"
        case "$kind" in
            file) COMPREPLY+=( $(compgen -f -- "$value") ) ;;
            dir) COMPREPLY+=( $(compgen -d -- "$value") ) ;;
            *) COMPREPLY+=( "$value" ) ;;
        esac
    done
    return 0
}
complete -o default -F __FUNC__ __PROG__
"""

_ZSH = """\
#compdef __PROG__
__FUNC__() {
    local -a lines items
    local line kind rest value help
    lines=("${(@f)$(env COMP_WORDS="${words[*]}" COMP_CWORD=$((CURRENT-1)) __VAR__=zsh_complete __PROG__)}")
    for line in "${lines[@]}"; do
        kind="${line%%,*}"
        rest="${line#*,}"
        case "$kind" in
            file) _files ;;
            dir) _directories ;;
            *)
                value="${rest%%$'\\t'*}"
                help=""
                if [[ "$rest" == *$'\\t'* ]]; then help="${rest#*$'\\t'}"; fi
                items+=("${value//:/\\\\:}:${help}")
                ;;
        esac
    done
    if (( ${#items} )); then _describe 'values' items; fi
}
compdef __FUNC__ __PROG__
"""

_FISH = """\
function __FUNC__
    set -l words (commandline -opc)
    set -l cur (commandline -ct)
    for line in (env COMP_WORDS="$words" COMP_CWORD="$cur" __VAR__=fish_complete __PROG__)
        set -l parts (string split -m1 , -- $line)
        switch $parts[1]
            case file
                __fish_complete_path $cur
            case dir
                __fish_complete_directories $cur
            case '*'
                echo $parts[2]
        end
    end
end
complete -c __PROG__ -f -a '(__FUNC__)'
"""

_POWERSHELL = """\
Register-ArgumentCompleter -Native -CommandName '__PROG__' -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)
    $words = $commandAst.ToString()
    $cword = $commandAst.CommandElements.Count
    if ($wordToComplete -eq '') { $cword = $cword } else { $cword = $cword - 1 }
    $env:COMP_WORDS = $words
    $env:COMP_CWORD = $cword
    $env:__VAR__ = 'powershell_complete'
    $output = & '__PROG__' 2>$null
    Remove-Item Env:__VAR__ -ErrorAction SilentlyContinue
    foreach ($line in $output) {
        $parts = $line -split ',', 2
        if ($parts[0] -eq 'plain') {
            [System.Management.Automation.CompletionResult]::new($parts[1], $parts[1], 'ParameterValue', $parts[1])
        }
    }
}
"""


def source_script(shell: str, prog_name: str) -> str:
    template = {"bash": _BASH, "zsh": _ZSH, "fish": _FISH, "powershell": _POWERSHELL}[shell]
    return (
        template.replace("__FUNC__", _func_name(prog_name))
        .replace("__VAR__", _complete_var(prog_name))
        .replace("__PROG__", prog_name)
    )


def _is_option_like(token: str) -> bool:
    return len(token) > 1 and token[0] in "-/+"


def _find_option(cmd: Command, ctx: Context, name: str) -> t.Optional[Option]:
    for param in cmd.get_params(ctx):
        if isinstance(param, Option) and name in param.opts + param.secondary_opts:
            return param
    return None


def _walk(cli: Command, prog_name: str, tokens: t.List[str]) -> t.Tuple[Command, Context, t.Optional[Option], int]:
    """Follow already-typed tokens down the command tree.

    Returns the command reached, its context, an option still waiting for a
    value (if any), and the number of positional tokens seen.
    """
    ctx = Context(cli, info_name=prog_name)
    cmd: Command = cli
    pending: t.Optional[Option] = None
    positionals = 0
    i = 0
    n = len(tokens)
    while i < n:
        tok = tokens[i]
        i += 1
        if tok == "--":
            positionals += n - i
            break
        if _is_option_like(tok):
            name, eq, _ = tok.partition("=")
            option = _find_option(cmd, ctx, name)
            if option is not None and not option.is_flag and not option.count and not eq:
                if i < n:
                    i += 1
                else:
                    pending = option
            continue
        if isinstance(cmd, Group):
            child = cmd._lookup(ctx, tok)
            if child is not None:
                ctx = Context(child, parent=ctx, info_name=tok)
                cmd = child
                continue
        positionals += 1
    return cmd, ctx, pending, positionals


def _items_from(result: t.Any, incomplete: str) -> t.List[CompletionItem]:
    items: t.List[CompletionItem] = []
    for entry in result or []:
        if isinstance(entry, PathRequest):
            items.append(CompletionItem(entry.incomplete, None, entry.kind))
        elif isinstance(entry, CompletionItem):
            items.append(entry)
        elif isinstance(entry, str):
            items.append(CompletionItem(entry))
        else:
            value = getattr(entry, "value", None)
            if value is None:
                continue
            items.append(CompletionItem(str(value), getattr(entry, "help", None), getattr(entry, "type", "plain") or "plain"))
    return items


def _param_items(param: Parameter, ctx: Context, incomplete: str) -> t.List[CompletionItem]:
    if param.shell_complete_func is not None:
        result = param.shell_complete_func(ctx, param, incomplete)
    else:
        result = param.type.shell_complete(ctx, param, incomplete)
    return _items_from(result, incomplete)


def get_completions(cli: Command, prog_name: str, words: t.List[str], incomplete: str) -> t.List[CompletionItem]:
    """Suggestions for ``incomplete`` after the already-typed ``words`` (excluding the program name)."""
    cmd, ctx, pending, positionals = _walk(cli, prog_name, words)
    if pending is not None:
        return [i for i in _param_items(pending, ctx, incomplete) if i.value.startswith(incomplete) or i.type != "plain"]
    if incomplete.startswith("-"):
        items = []
        for param in cmd.get_params(ctx):
            if not isinstance(param, Option) or param.hidden:
                continue
            for name in param.opts + param.secondary_opts:
                if name.startswith(incomplete):
                    items.append(CompletionItem(name, param.help))
        return items
    items: t.List[CompletionItem] = []
    if isinstance(cmd, Group):
        for name in cmd.list_commands(ctx):
            child = cmd.get_command(ctx, name)
            if child is None or child.hidden or not name.startswith(incomplete):
                continue
            items.append(CompletionItem(name, child.get_short_help_str(60)))
    arguments = [p for p in cmd.params if isinstance(p, Argument)]
    if arguments and not isinstance(cmd, Group) and positionals < len(arguments):
        items.extend(_param_items(arguments[positionals], ctx, incomplete))
    return items


def _format(items: t.List[CompletionItem], shell: str) -> t.List[str]:
    lines = []
    for item in items:
        if item.type != "plain":
            lines.append(f"{item.type},{item.value}")
            continue
        text = f"plain,{item.value}"
        if shell in ("zsh", "fish") and item.help:
            text += "\t" + " ".join(item.help.split())
        lines.append(text)
    return lines


def run_completion(cli: Command, args: t.List[str], prog_name: str, instruction: str) -> int:
    """Handle a completion request. Returns the process status to use.

    ``<shell>_source`` prints the registration script. ``<shell>_complete``
    prints suggestions from ``COMP_WORDS`` and ``COMP_CWORD``.
    """
    shell, _, mode = instruction.rpartition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        return 1
    if mode == "source":
        echo(source_script(shell, prog_name))
        return 0
    line = os.environ.get("COMP_WORDS", "")
    raw_cword = os.environ.get("COMP_CWORD", "")
    words = line.split(" ")
    if shell == "fish":
        tokens = words[1:]
        incomplete = raw_cword
    else:
        try:
            cword = int(raw_cword)
        except ValueError:
            cword = len(words)
        if cword >= len(words):
            incomplete = ""
            tokens = words[1:]
        else:
            incomplete = words[cword]
            tokens = words[1:cword]
    tokens = [tok for tok in tokens if tok != ""]
    items = get_completions(cli, prog_name, tokens, incomplete)
    for line_out in _format(items, shell):
        echo(line_out)
    return 0
