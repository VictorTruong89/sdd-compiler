"""In-process runner: invoke a command with tokens and capture its output and status."""

import contextlib
import io
import os
import shutil
import sys
import tempfile
import typing as t

from . import termui
from .core import Command


class _Recorder:
    """Keeps all writes in the order they happened, across stdout and stderr."""

    def __init__(self) -> None:
        self.buffer = io.BytesIO()


class _CaptureBuffer(io.BytesIO):
    def __init__(self, recorder: _Recorder) -> None:
        super().__init__()
        self._recorder = recorder

    def write(self, data: t.Any) -> int:
        self._recorder.buffer.write(data)
        return super().write(data)


class Result:
    """Outcome of :meth:`CliRunner.invoke`."""

    def __init__(
        self,
        runner: "CliRunner",
        stdout_bytes: bytes,
        stderr_bytes: bytes,
        output_bytes: bytes,
        return_value: t.Any,
        exit_code: int,
        exception: t.Optional[BaseException],
        exc_info: t.Any = None,
    ) -> None:
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self) -> str:
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self) -> str:
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self) -> str:
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self) -> str:
        return f"<Result exit_code={self.exit_code!r}>"


class CliRunner:
    """Runs commands in the current process and captures what they write."""

    def __init__(
        self,
        charset: str = "utf-8",
        env: t.Optional[t.Mapping[str, t.Optional[str]]] = None,
        echo_stdin: bool = False,
        catch_exceptions: bool = True,
        capture: str = "sys",
    ) -> None:
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli: Command) -> str:
        return cli.name or "root"

    @contextlib.contextmanager
    def isolation(
        self,
        input: t.Any = None,
        env: t.Optional[t.Mapping[str, t.Optional[str]]] = None,
        color: bool = False,
    ) -> t.Iterator[t.Tuple[t.Any, t.Any, t.Any]]:
        """Swap the standard streams for captures; yields (stdin, stdout, stderr)."""
        data: bytes
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env: t.Dict[str, t.Optional[str]] = {}
        for key, value in merged_env.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)

        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        recorder = _Recorder()
        if self.capture == "sys":
            stdin = io.TextIOWrapper(io.BytesIO(data), encoding=self.charset)
            out_bytes = _CaptureBuffer(recorder)
            err_bytes = _CaptureBuffer(recorder)
            stdout = io.TextIOWrapper(out_bytes, encoding=self.charset, write_through=True)
            stderr = io.TextIOWrapper(err_bytes, encoding=self.charset, write_through=True)
            fd_files = None
        else:
            fd_files = (tempfile.TemporaryFile(), tempfile.TemporaryFile())
            saved_fds = (os.dup(1), os.dup(2))
            os.dup2(fd_files[0].fileno(), 1)
            os.dup2(fd_files[1].fileno(), 2)
            stdin = io.TextIOWrapper(io.BytesIO(data), encoding=self.charset)
            stdout = io.TextIOWrapper(io.BufferedWriter(io.FileIO(1, "wb", closefd=False)), encoding=self.charset, write_through=True)
            stderr = io.TextIOWrapper(io.BufferedWriter(io.FileIO(2, "wb", closefd=False)), encoding=self.charset, write_through=True)
            out_bytes = err_bytes = None

        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        previous_echo = termui.set_echo_stdin(self.echo_stdin)
        try:
            yield stdin, stdout, stderr
        finally:
            termui.set_echo_stdin(previous_echo)
            stdout.flush()
            stderr.flush()
            sys.stdin, sys.stdout, sys.stderr = old_stdin, old_stdout, old_stderr
            if fd_files is not None:
                os.dup2(saved_fds[0], 1)
                os.dup2(saved_fds[1], 2)
                os.close(saved_fds[0])
                os.close(saved_fds[1])
                fd_files[0].seek(0)
                fd_files[1].seek(0)
                self._captured = (fd_files[0].read(), fd_files[1].read())
                fd_files[0].close()
                fd_files[1].close()
            else:
                self._captured = (out_bytes.getvalue(), err_bytes.getvalue())
                self._ordered = recorder.buffer.getvalue()
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(
        self,
        cli: Command,
        args: t.Any = None,
        input: t.Any = None,
        env: t.Optional[t.Mapping[str, t.Optional[str]]] = None,
        catch_exceptions: t.Optional[bool] = None,
        color: bool = False,
        **extra: t.Any,
    ) -> Result:
        """Run ``cli`` with ``args`` and capture its output and exit status."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if isinstance(args, str):
            import shlex

            args = shlex.split(args)
        args = list(args or [])
        prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
        standalone = extra.pop("standalone_mode", True)
        extra.setdefault("color", color)

        return_value: t.Any = None
        exit_code = 0
        exception: t.Optional[BaseException] = None
        exc_info: t.Any = None
        with self.isolation(input=input, env=env, color=color):
            try:
                return_value = cli.main(
                    args=args,
                    prog_name=prog_name,
                    standalone_mode=standalone,
                    **extra,
                )
                if not standalone:
                    exit_code = 0
            except SystemExit as e:
                if e.code is None:
                    exit_code = 0
                elif isinstance(e.code, int):
                    exit_code = e.code
                else:
                    sys.stderr.write(str(e.code) + "\n")
                    exit_code = 1
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
        stdout_bytes, stderr_bytes = self._captured
        output_bytes = self._ordered if self.capture == "sys" else stdout_bytes + stderr_bytes
        return Result(
            runner=self,
            stdout_bytes=stdout_bytes,
            stderr_bytes=stderr_bytes,
            output_bytes=output_bytes,
            return_value=return_value,
            exit_code=exit_code,
            exception=exception,
            exc_info=exc_info,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir: t.Optional[str] = None) -> t.Iterator[str]:
        """Change into a new empty directory for the duration of the block."""
        previous = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(previous)
            if temp_dir is None:
                shutil.rmtree(path, ignore_errors=True)
