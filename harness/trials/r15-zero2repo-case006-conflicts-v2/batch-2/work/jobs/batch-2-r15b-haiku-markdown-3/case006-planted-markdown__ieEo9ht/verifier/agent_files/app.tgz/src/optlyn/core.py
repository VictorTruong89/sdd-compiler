import contextlib
import enum
import os
import re
import shutil
import sys
from collections import deque

from . import termui
from ._globals import pop_context, push_context
from .exceptions import (
    Abort,
    BadArgumentUsage,
    BadOptionUsage,
    BadParameter,
    Exit,
    MissingParameter,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import HelpFormatter
from .types import (
    BOOL,
    FALSE_VALUES,
    INT,
    TRUE_VALUES,
    Choice,
    CompletionItem,
    convert_type,
    Tuple as TupleType,
)


class ParameterSource(enum.Enum):
    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


class _Marker:
    def __init__(self, name):
        self.name = name

    def __repr__(self):
        return f"<{self.name}>"


_NEEDS_PROMPT = _Marker("needs-prompt")
MULTIPLE_SUBCOMMANDS = _Marker("multiple-subcommands")

_RANKS = {
    ParameterSource.PROMPT: 5,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.ENVIRONMENT: 3,
    ParameterSource.DEFAULT_MAP: 2,
}


def _is_long(name):
    return len(name) > 2 and name[0] == name[1]


def _parse_option_decls(decls):
    name = None
    opts = []
    secondary = []
    for decl in decls:
        if not decl:
            raise TypeError("Empty parameter declaration.")
        if decl[0].isalnum() or decl[0] == "_":
            if name is not None:
                raise TypeError("A parameter destination can only be given once.")
            name = decl
            continue
        idx = decl.find("/", 1)
        if idx > 0:
            opts.append(decl[:idx])
            secondary.append(decl[idx + 1 :])
        else:
            opts.append(decl)
    if name is None:
        names = opts + secondary
        if not names:
            raise TypeError("A parameter needs at least a name or a flag.")
        longs = [n for n in names if _is_long(n)]
        name = (longs or names)[0].lstrip("-+/").replace("-", "_")
    return name, opts, secondary


def _is_missing(value):
    return value is None or (isinstance(value, tuple) and not value)


def _rank(param, source):
    if source is ParameterSource.DEFAULT:
        return 1 if param.default is not None else 0
    return _RANKS[source]


class Context:
    def __init__(
        self,
        command,
        parent=None,
        info_name=None,
        obj=None,
        default_map=None,
        terminal_width=None,
        max_content_width=None,
        help_option_names=None,
        token_normalize_func=None,
        color=None,
        show_default=None,
        allow_extra_args=None,
        allow_interspersed_args=None,
        ignore_unknown_options=None,
        auto_envvar_prefix=None,
    ):
        self.command = command
        self.parent = parent
        self.info_name = info_name

        def inherit(value, attr, default):
            if value is not None:
                return value
            if parent is not None:
                return getattr(parent, attr)
            return default

        self.terminal_width = inherit(terminal_width, "terminal_width", None)
        self.max_content_width = inherit(max_content_width, "max_content_width", None)
        if help_option_names is not None:
            self.help_option_names = list(help_option_names)
        elif parent is not None:
            self.help_option_names = parent.help_option_names
        else:
            self.help_option_names = ["--help"]
        self.token_normalize_func = inherit(token_normalize_func, "token_normalize_func", None)
        self.color = inherit(color, "color", None)
        self.show_default = inherit(show_default, "show_default", None)
        self.allow_extra_args = inherit(allow_extra_args, "allow_extra_args", False)
        self.ignore_unknown_options = inherit(ignore_unknown_options, "ignore_unknown_options", False)
        if allow_interspersed_args is None:
            allow_interspersed_args = not isinstance(command, Group)
        self.allow_interspersed_args = allow_interspersed_args

        if parent is None:
            self.auto_envvar_prefix = auto_envvar_prefix
        elif parent.auto_envvar_prefix is not None and info_name:
            self.auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{info_name}"
        else:
            self.auto_envvar_prefix = None

        if default_map is None and parent is not None and parent.default_map is not None:
            default_map = parent.default_map.get(info_name)
        self.default_map = default_map

        self._obj = obj
        self._obj_set = obj is not None
        self.params = {}
        self._sources = {}
        self._ranks = {}
        self.protected_args = []
        self.args = []
        self.invoked_subcommand = None
        self._exit_stack = contextlib.ExitStack()

    @property
    def obj(self):
        if self._obj_set:
            return self._obj
        return self.parent.obj if self.parent is not None else None

    @obj.setter
    def obj(self, value):
        self._obj = value
        self._obj_set = True

    @property
    def command_path(self):
        path = self.info_name or ""
        if self.parent is not None:
            parent_path = self.parent.command_path
            path = f"{parent_path} {path}" if parent_path else path
        return path

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if node._obj_set and type(node._obj) is object_type:
                return node._obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    def make_formatter(self):
        if self.terminal_width is not None:
            width = self.terminal_width
        else:
            columns = shutil.get_terminal_size((80, 24)).columns
            width = min(columns, self.max_content_width or 80)
        return HelpFormatter(width)

    def get_help(self):
        return self.command.get_help(self)

    def get_usage(self):
        return self.command.get_usage(self)

    def get_parameter_source(self, name):
        return self._sources.get(name)

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def call_on_close(self, func):
        self._exit_stack.callback(func)

    def with_resource(self, cm):
        return self._exit_stack.enter_context(cm)

    def close(self):
        self._exit_stack.close()

    def __enter__(self):
        push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        pop_context()

    def invoke(self, other_cmd, **kwargs):
        if isinstance(other_cmd, Command):
            sub = Context(other_cmd, parent=self, info_name=other_cmd.name)
            try:
                with sub:
                    for param in other_cmd.get_params(sub):
                        if not param.expose_value:
                            continue
                        if param.name in kwargs:
                            sub.params[param.name] = kwargs[param.name]
                        else:
                            sub.params[param.name] = param.get_default_for_invoke(sub)
                    for key, value in kwargs.items():
                        sub.params.setdefault(key, value)
                    return other_cmd._invoke_callback(sub)
            finally:
                sub.close()
        with self:
            return other_cmd(**kwargs)

    def forward(self, other_cmd, **kwargs):
        values = dict(self.params)
        values.update(kwargs)
        return self.invoke(other_cmd, **values)


class Parameter:
    is_flag = False
    count = False

    def __init__(
        self,
        name,
        opts,
        secondary,
        *,
        type=None,
        default=None,
        required=False,
        callback=None,
        nargs=1,
        multiple=False,
        metavar=None,
        expose_value=True,
        is_eager=False,
        envvar=None,
        shell_complete=None,
        deprecated=False,
        help=None,
        hidden=False,
        show_default=None,
        show_envvar=False,
    ):
        self.name = name
        self.opts = list(opts)
        self.secondary_opts = list(secondary)
        self.default = default
        self.type = convert_type(type, default)
        if isinstance(self.type, TupleType):
            nargs = len(self.type.types)
        if nargs == 0 or nargs < -1:
            raise ValueError("nargs must be a positive number or -1.")
        self.nargs = nargs
        self.multiple = multiple
        self.required = required
        self.callback = callback
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        if envvar is None:
            self.envvar = []
        elif isinstance(envvar, str):
            self.envvar = [envvar]
        else:
            self.envvar = list(envvar)
        self._shell_complete = shell_complete
        self.deprecated = deprecated
        self.help = help
        self.hidden = hidden
        self.show_default = show_default
        self.show_envvar = show_envvar

    def get_default(self, ctx):
        value = self.default
        if callable(value):
            value = value()
        return value

    def get_default_for_invoke(self, ctx):
        value = self.get_default(ctx)
        if value is None:
            if self.is_flag:
                return False
            if self.count:
                return 0
            if self.multiple or self.nargs == -1:
                return ()
        return value

    def get_error_hint(self, ctx):
        return " / ".join(f"'{n}'" for n in self.opts + self.secondary_opts)

    def _annotate(self, exc, ctx):
        if exc.param is None:
            exc.param = self
        if exc.param_hint is None:
            exc.param_hint = self.get_error_hint(ctx)
        if exc.ctx is None:
            exc.ctx = ctx
        return exc

    def _convert_token(self, ctx, ty, value):
        try:
            return ty.convert(value, self, ctx)
        except BadParameter as e:
            raise self._annotate(e, ctx)

    def _convert_occ(self, ctx, occ):
        if isinstance(self.type, TupleType):
            return tuple(
                self._convert_token(ctx, ty, value) for ty, value in zip(self.type.types, occ)
            )
        if self.nargs != 1:
            return tuple(self._convert_token(ctx, self.type, value) for value in occ)
        return self._convert_token(ctx, self.type, occ)

    def run_callback(self, ctx, value):
        if self.callback is None:
            return value
        try:
            return self.callback(ctx, self, value)
        except BadParameter as e:
            raise self._annotate(e, ctx)

    def shell_complete(self, ctx, incomplete):
        if self._shell_complete is not None:
            return _normalize_completions(self._shell_complete(ctx, self, incomplete))
        return self.type.shell_complete(ctx, self, incomplete)


def _normalize_completions(items):
    out = []
    for item in items or []:
        if isinstance(item, CompletionItem):
            out.append(item)
        elif isinstance(item, str):
            out.append(CompletionItem(item))
        else:
            out.append(
                CompletionItem(
                    item.value,
                    getattr(item, "help", None),
                    getattr(item, "type", "plain") or "plain",
                )
            )
    return out


class Option(Parameter):
    def __init__(
        self,
        param_decls=(),
        *,
        is_flag=None,
        flag_value=None,
        count=False,
        prompt=False,
        prompt_required=True,
        hide_input=False,
        confirmation_prompt=False,
        allow_from_autoenv=True,
        type=None,
        default=None,
        required=False,
        **kwargs,
    ):
        name, opts, secondary = _parse_option_decls(tuple(param_decls))
        if is_flag is None:
            is_flag = bool(secondary) or isinstance(default, bool)
        if count:
            is_flag = True
            if type is None:
                type = INT
        elif is_flag and type is None:
            type = BOOL
        if is_flag and flag_value is None:
            flag_value = (not default) if isinstance(default, bool) else True
        if kwargs.get("deprecated") and required:
            raise ValueError("A deprecated option cannot also be required.")
        if kwargs.get("deprecated") and prompt:
            raise ValueError("A deprecated option cannot use a prompt.")
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self.flag_value = flag_value
        self.optional_value = not self.is_flag and flag_value is not None
        if prompt is False or prompt is None:
            self.prompt = None
        elif prompt is True:
            self.prompt = name.replace("_", " ").capitalize()
        else:
            self.prompt = prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.allow_from_autoenv = allow_from_autoenv
        super().__init__(
            name,
            opts,
            secondary,
            type=type,
            default=default,
            required=required,
            **kwargs,
        )

    @property
    def takes_value(self):
        return not self.is_flag

    def get_metavar(self, ctx):
        if self.metavar:
            return self.metavar
        if not self.takes_value or self.count:
            return None
        return self.type.get_metavar(self)

    def get_help_record(self, ctx):
        names = ", ".join(self.opts)
        if self.secondary_opts:
            names += "/" + "/".join(self.secondary_opts)
        metavar = self.get_metavar(ctx)
        first = f"{names} {metavar}" if metavar else names
        extras = []
        show = self.show_default if self.show_default is not None else ctx.show_default
        if show and self.default is not None and not (self.is_flag and self.default is False):
            if isinstance(show, str):
                extras.append(f"default: {show}")
            elif not callable(self.default):
                extras.append(f"default: {self.default}")
        if self.show_envvar and self.envvar:
            extras.append("env var: " + ", ".join(self.envvar))
        if isinstance(self.type, Choice):
            extras.append("choices: " + ", ".join(self.type._keys))
        text = self.help or ""
        if self.deprecated:
            text = ("(deprecated) " + text).strip()
        if extras:
            text = (text + " " if text else "") + "[" + "; ".join(extras) + "]"
        return first, text

    def _warn_deprecated(self, ctx):
        note = self.deprecated if isinstance(self.deprecated, str) else ""
        message = f"DeprecationWarning: The option '{self.opts[0] if self.opts else self.name}' is deprecated."
        termui.echo(f"{message} {note}".rstrip(), err=True)

    def _items_from_value(self, ctx, value):
        if self.multiple:
            if isinstance(value, str):
                if self.nargs == 1:
                    raise self._annotate(
                        BadParameter("needs an iterable (sequence) default, not a string."),
                        ctx,
                    )
                tokens = value.split()
                return [tuple(tokens[i : i + self.nargs]) for i in range(0, len(tokens), self.nargs)]
            if not isinstance(value, (list, tuple)):
                raise self._annotate(
                    BadParameter("needs an iterable (sequence) default."),
                    ctx,
                )
            if self.nargs > 1:
                return [tuple(item) for item in value]
            return list(value)
        if self.nargs > 1 or isinstance(self.type, TupleType):
            if isinstance(value, str):
                value = value.split()
            return [tuple(value)]
        return [value]

    def _from_items(self, ctx, items):
        if self.count:
            return sum(items)
        if self.is_flag:
            return items[-1]
        if self.multiple:
            return tuple(self._convert_occ(ctx, item) for item in items)
        return self._convert_occ(ctx, items[-1])

    def _convert_default(self, ctx, value):
        if self.count:
            return 0 if value is None else value
        if self.is_flag:
            return False if value is None else value
        if value is None:
            return () if self.multiple else None
        return self._from_items(ctx, self._items_from_value(ctx, value))

    def _env_items(self, raw):
        if self.multiple or self.nargs > 1:
            tokens = self.type.split_envvar_value(raw)
            if not self.multiple:
                return [tuple(tokens)]
            if self.nargs > 1:
                return [tuple(tokens[i : i + self.nargs]) for i in range(0, len(tokens), self.nargs)]
            return tokens
        return [raw]

    def _flag_from_env(self, ctx, raw):
        text = raw.strip().lower()
        if isinstance(self.flag_value, bool):
            if text == "":
                return True, False
            if text in TRUE_VALUES:
                return True, True
            if text in FALSE_VALUES:
                return True, False
            raise self._annotate(BadParameter(f"{raw!r} is not a valid boolean."), ctx)
        if raw == str(self.flag_value) or text == str(self.flag_value).lower():
            return True, self.flag_value
        if text in TRUE_VALUES:
            return True, self.flag_value
        if text in FALSE_VALUES:
            return True, False
        return False, None

    def _from_env(self, ctx):
        names = list(self.envvar)
        if self.allow_from_autoenv and ctx.auto_envvar_prefix is not None:
            names.append(f"{ctx.auto_envvar_prefix}_{self.name}".replace("-", "_").upper())
        if self.count:
            return None, False
        for name in names:
            raw = os.environ.get(name)
            if not raw:
                continue
            if self.is_flag:
                found, value = self._flag_from_env(ctx, raw)
                return value, found
            items = self._env_items(raw)
            if not items:
                continue
            return self._from_items(ctx, items), True
        return None, False

    def _prompt(self, ctx, default):
        if self.multiple:
            default = None
        value = termui.prompt(
            self.prompt,
            default=default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            type=self.type,
        )
        return (value,) if self.multiple else value

    def process_parse(self, ctx, items):
        cli = [item for item in items if item is not _NEEDS_PROMPT]
        needs_prompt = len(cli) != len(items)
        if cli:
            if self.deprecated:
                self._warn_deprecated(ctx)
            return self._from_items(ctx, cli), ParameterSource.COMMANDLINE

        value, found = self._from_env(ctx)
        if found:
            return value, ParameterSource.ENVIRONMENT

        if self.prompt is not None and (needs_prompt or self.prompt_required):
            if ctx.default_map is not None and self.name in ctx.default_map:
                default = ctx.default_map[self.name]
            else:
                default = self.get_default(ctx)
            return self._prompt(ctx, default), ParameterSource.PROMPT

        if ctx.default_map is not None and ctx.default_map.get(self.name) is not None:
            value = self._convert_default(ctx, ctx.default_map[self.name])
            return value, ParameterSource.DEFAULT_MAP

        value = self._convert_default(ctx, self.get_default(ctx))
        return value, ParameterSource.DEFAULT

    def consume(self, ctx, items):
        value, source = self.process_parse(ctx, items)
        if self.required and not self.is_flag and not self.count and _is_missing(value):
            raise MissingParameter(f"Missing option {self.get_error_hint(ctx)}.", ctx)
        return value, source


class Argument(Parameter):
    def __init__(self, param_decls=(), *, required=None, nargs=None, default=None, **kwargs):
        decls = tuple(param_decls)
        if len(decls) != 1 or decls[0].startswith("-"):
            raise TypeError("An argument takes exactly one destination name.")
        name = decls[0]
        if nargs is None:
            nargs = 1
        if required is None:
            required = default is None and nargs != -1
        if kwargs.get("deprecated") and required:
            raise ValueError("A deprecated argument cannot be required.")
        super().__init__(name, [], [], default=default, required=required, nargs=nargs, **kwargs)

    def get_error_hint(self, ctx):
        return f"'{self.name.upper()}'"

    def get_usage_piece(self):
        placeholder = self.metavar or self.name.upper()
        if self.nargs > 1:
            placeholder = " ".join([placeholder] * self.nargs)
        if not self.required:
            placeholder = f"[{placeholder}]"
        if self.nargs == -1:
            placeholder += "..."
        return placeholder

    def _from_tokens(self, ctx, tokens):
        if self.nargs == 1:
            return self._convert_token(ctx, self.type, tokens[0])
        if self.nargs == -1:
            return tuple(self._convert_token(ctx, self.type, t) for t in tokens)
        return self._convert_occ(ctx, tuple(tokens))

    def _convert_default(self, ctx, value):
        if value is None:
            return () if self.nargs == -1 else None
        if self.nargs == -1:
            if isinstance(value, str):
                value = value.split()
            return tuple(self._convert_token(ctx, self.type, t) for t in value)
        if self.nargs == 1:
            return self._convert_token(ctx, self.type, value)
        if isinstance(value, str):
            value = value.split()
        return self._convert_occ(ctx, tuple(value))

    def process_parse(self, ctx, tokens):
        if tokens is not None:
            if self.deprecated:
                termui.echo(
                    f"DeprecationWarning: The argument '{self.name.upper()}' is deprecated.",
                    err=True,
                )
            return self._from_tokens(ctx, tokens), ParameterSource.COMMANDLINE
        for name in self.envvar:
            raw = os.environ.get(name)
            if raw:
                if self.nargs == 1:
                    tokens = [raw]
                else:
                    tokens = self.type.split_envvar_value(raw)
                return self._from_tokens(ctx, tokens), ParameterSource.ENVIRONMENT
        if ctx.default_map is not None and ctx.default_map.get(self.name) is not None:
            value = self._convert_default(ctx, ctx.default_map[self.name])
            return value, ParameterSource.DEFAULT_MAP
        value = self._convert_default(ctx, self.get_default(ctx))
        return value, ParameterSource.DEFAULT

    def consume(self, ctx, tokens):
        value, source = self.process_parse(ctx, tokens)
        if self.required and _is_missing(value):
            raise MissingParameter(f"Missing argument {self.get_error_hint(ctx)}.", ctx)
        return value, source


class _OptionParser:
    def __init__(self, ctx, params, is_group):
        self.ctx = ctx
        self.normalize = ctx.token_normalize_func or (lambda token: token)
        self.interspersed = ctx.allow_interspersed_args
        self.ignore_unknown = ctx.ignore_unknown_options
        self.is_group = is_group
        self.seen_positional = False
        self.prefixes = {"-"}
        self.options = {}
        self.items = []
        for param in params:
            if not isinstance(param, Option):
                continue
            for name in param.opts:
                self.prefixes.add(name[0])
                self.options[self.normalize(name)] = (param, self._kind(param, False))
            for name in param.secondary_opts:
                self.prefixes.add(name[0])
                self.options[self.normalize(name)] = (param, "off")

    @staticmethod
    def _kind(param, off):
        if off:
            return "off"
        if param.count:
            return "count"
        if param.is_flag:
            return "flag"
        return "value"

    def is_opt(self, token):
        return len(token) > 1 and token[0] in self.prefixes

    def _flag_item(self, param, kind):
        if kind == "count":
            return 1
        if kind == "off":
            return False
        return param.flag_value

    def _value_for(self, param, name, first, it):
        if first is None and param.optional_value:
            if it and not self.is_opt(it[0]):
                return it.popleft()
            return param.flag_value
        if first is None and param.prompt is not None:
            return _NEEDS_PROMPT
        tokens = [first] if first is not None else []
        while len(tokens) < param.nargs:
            if not it:
                raise BadOptionUsage(f"Option '{name}' requires an argument.", self.ctx)
            tokens.append(it.popleft())
        return tokens[0] if param.nargs == 1 else tuple(tokens)

    def _take(self, name, key, value, it):
        param, kind = self.options[key]
        if kind == "value":
            self.items.append((param, self._value_for(param, name, value, it)))
            return
        if value is not None:
            raise BadOptionUsage(f"Option '{name}' does not take a value.", self.ctx)
        self.items.append((param, self._flag_item(param, kind)))

    def _process_stack(self, arg, it, largs):
        prefix = arg[0]
        chars = arg[1:]
        for index, ch in enumerate(chars):
            name = prefix + ch
            key = self.normalize(name)
            if key not in self.options:
                if index == 0:
                    return False
                if not (self.ignore_unknown or (self.is_group and self.seen_positional and self.interspersed)):
                    raise NoSuchOption(f"No such option: {name}", self.ctx)
                largs.append(prefix + chars[index:])
                return True
            param, kind = self.options[key]
            if kind == "value":
                rest = chars[index + 1 :]
                self.items.append((param, self._value_for(param, name, rest or None, it)))
                return True
            self.items.append((param, self._flag_item(param, kind)))
        return True

    def _process_opt(self, arg, it, largs):
        key = self.normalize(arg)
        if key in self.options:
            self._take(arg, key, None, it)
            return True
        if "=" in arg:
            name, value = arg.split("=", 1)
            key = self.normalize(name)
            if key in self.options:
                self._take(name, key, value, it)
                return True
        if _is_long(arg):
            return False
        return self._process_stack(arg, it, largs)

    def parse(self, args):
        self.items = []
        largs = []
        literal_start = None
        it = deque(args)
        self.seen_positional = False
        while it:
            arg = it.popleft()
            if arg == "--":
                literal_start = len(largs)
                largs.extend(it)
                it.clear()
                break
            if self.is_opt(arg):
                if self._process_opt(arg, it, largs):
                    continue
                if self.ignore_unknown or (self.is_group and self.seen_positional and self.interspersed):
                    largs.append(arg)
                    continue
                raise NoSuchOption(f"No such option: {arg}", self.ctx)
            largs.append(arg)
            self.seen_positional = True
            if not self.interspersed:
                largs.extend(it)
                it.clear()
                break
        if literal_start is None:
            literal_start = len(largs)
        return self.items, largs, literal_start


def _assign_arguments(ctx, arguments, tokens, reserve=0):
    assigned = {}
    rest = list(tokens)
    for index, arg in enumerate(arguments):
        if arg.nargs == -1:
            need = sum(a.nargs for a in arguments[index + 1 :] if a.nargs > 0) + reserve
            take = max(len(rest) - need, 0)
            taken = rest[:take]
            rest = rest[take:]
            if taken:
                assigned[arg] = taken
            continue
        if not rest:
            continue
        taken = rest[: arg.nargs]
        rest = rest[arg.nargs :]
        if len(taken) < arg.nargs:
            raise BadArgumentUsage(
                f"Argument '{arg.name.upper()}' takes {arg.nargs} values.", ctx
            )
        assigned[arg] = taken
    return assigned, rest


def _looks_like_option(token):
    return len(token) > 1 and token[0] == "-"


class Command:
    def __init__(
        self,
        name,
        context_settings=None,
        callback=None,
        params=None,
        help=None,
        epilog=None,
        short_help=None,
        options_metavar="[OPTIONS]",
        add_help_option=True,
        no_args_is_help=False,
        hidden=False,
        deprecated=False,
    ):
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        if sum(1 for p in self.params if isinstance(p, Argument) and p.nargs == -1) > 1:
            raise TypeError("Only one variadic argument is allowed per command.")
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def get_params(self, ctx):
        params = list(self.params)
        if self.add_help_option:
            taken = set()
            for param in params:
                taken.update(getattr(param, "opts", []))
                taken.update(getattr(param, "secondary_opts", []))
            names = [n for n in ctx.help_option_names if n not in taken]
            if names:
                params.append(_make_help_option(names))
        return params

    def _warn_deprecated(self, ctx):
        if not self.deprecated:
            return
        note = self.deprecated if isinstance(self.deprecated, str) else ""
        message = f"DeprecationWarning: The command '{ctx.info_name}' is deprecated."
        termui.echo(f"{message} {note}".rstrip(), err=True)

    def get_usage_pieces(self, ctx):
        pieces = [self.options_metavar]
        pieces += [p.get_usage_piece() for p in self.params if isinstance(p, Argument)]
        return pieces

    def get_usage(self, ctx):
        fmt = ctx.make_formatter()
        return fmt.usage(f"Usage: {ctx.command_path} ", self.get_usage_pieces(ctx))

    def get_help_text(self):
        text = self.help or ""
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            mark = ("(Deprecated) " + note).strip()
            text = mark + ("\n\n" + text if text else "")
        return text

    def get_short_help_str(self):
        if self.short_help:
            return self.short_help
        text = (self.help or "").strip()
        if not text:
            return ""
        first = re.split(r"\n\s*\n", text)[0]
        paragraph = " ".join(first.split())
        match = re.match(r"(.*?[.!?])(\s|$)", paragraph)
        return match.group(1) if match else paragraph

    def get_help(self, ctx):
        fmt = ctx.make_formatter()
        out = [fmt.usage(f"Usage: {ctx.command_path} ", self.get_usage_pieces(ctx))]
        description = self.get_help_text()
        if description:
            out += ["", fmt.paragraph(description)]
        args = [p for p in self.params if isinstance(p, Argument) and p.help]
        if args:
            rows = [(p.metavar or p.name.upper(), p.help) for p in args]
            out += ["", "Positional arguments:", fmt.definition_list(rows)]
        options = [p for p in self.get_params(ctx) if isinstance(p, Option) and not p.hidden]
        if options:
            out += ["", "Options:", fmt.definition_list([p.get_help_record(ctx) for p in options])]
        out += self._extra_sections(ctx, fmt)
        if self.epilog:
            out += ["", fmt.paragraph(self.epilog)]
        return "\n".join(out)

    def _extra_sections(self, ctx, fmt):
        return []

    def make_context(self, info_name, args, parent=None, **extra):
        settings = {**self.context_settings, **extra}
        ctx = Context(self, parent=parent, info_name=info_name, **settings)
        try:
            with ctx:
                self.parse_args(ctx, list(args))
        except BaseException:
            ctx.close()
            raise
        return ctx

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help:
            raise UsageError("", ctx, show_help=True)
        params = self.get_params(ctx)
        parser = _OptionParser(ctx, params, is_group=isinstance(self, Group))
        items, largs, literal_start = parser.parse(args)
        arguments = [p for p in params if isinstance(p, Argument)]
        reserve = 1 if isinstance(self, Group) else 0
        assigned, rest = _assign_arguments(ctx, arguments, largs, reserve)
        self._process_params(ctx, params, items, assigned)
        if isinstance(self, Group):
            ctx.protected_args = rest[:1]
            ctx.args = rest[1:]
            if self.chain:
                ctx.protected_args = list(rest)
                ctx.args = []
            return
        offset = len(largs) - len(rest)
        for index, token in enumerate(rest):
            literal = offset + index >= literal_start
            if not literal and _looks_like_option(token) and not ctx.ignore_unknown_options:
                raise NoSuchOption(f"No such option: {token}", ctx)
        if rest and not ctx.allow_extra_args:
            raise UsageError(f"Got unexpected extra argument(s) ({' '.join(rest)}).", ctx)
        ctx.args = list(rest)

    def _process_params(self, ctx, params, items, assigned):
        raw = {}
        order = {}
        for index, (param, item) in enumerate(items):
            raw.setdefault(param, []).append(item)
            order.setdefault(param, index)
        eager = sorted(
            [p for p in params if p.is_eager and p in raw],
            key=lambda p: order[p],
        )
        ordered = eager + [p for p in params if p not in eager]
        for param in ordered:
            if isinstance(param, Argument):
                value, source = param.consume(ctx, assigned.get(param))
            else:
                value, source = param.consume(ctx, raw.get(param, []))
            value = param.run_callback(ctx, value)
            if not param.expose_value:
                continue
            rank = _rank(param, source)
            if param.name in ctx._ranks and ctx._ranks[param.name] > rank:
                continue
            ctx.params[param.name] = value
            ctx._sources[param.name] = source
            ctx._ranks[param.name] = rank

    def _invoke_callback(self, ctx):
        if self.callback is None:
            return None
        with ctx:
            return self.callback(**ctx.params)

    def invoke(self, ctx):
        try:
            with ctx:
                self._warn_deprecated(ctx)
                return self._invoke_callback(ctx)
        finally:
            ctx.close()

    def main(
        self,
        args=None,
        prog_name=None,
        complete_var=None,
        standalone_mode=True,
        **extra,
    ):
        args = list(sys.argv[1:] if args is None else args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "root"
        var = complete_var or f"_{prog_name.replace('-', '_').upper()}_COMPLETE"
        instruction = os.environ.get(var)
        if instruction:
            from .shell_completion import run_completion

            sys.exit(run_completion(self, prog_name, var, instruction))
        try:
            ctx = self.make_context(prog_name, args, **extra)
            rv = self.invoke(ctx)
            if not standalone_mode:
                return rv
            sys.exit(0)
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except Abort:
            if not standalone_mode:
                raise
            termui.echo("Aborted!", err=True)
            sys.exit(1)
        except UsageError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(2)
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)
        except (EOFError, KeyboardInterrupt):
            if not standalone_mode:
                raise
            termui.echo(file=sys.stderr)
            termui.echo("Aborted!", err=True)
            sys.exit(1)


def _make_help_option(names):
    def callback(ctx, param, value):
        if not value:
            return
        termui.echo(ctx.get_help(), color=ctx.color)
        ctx.exit()

    return Option(
        tuple(names),
        is_flag=True,
        expose_value=False,
        is_eager=True,
        callback=callback,
        help="Show this message and exit.",
    )


class Group(Command):
    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        **kwargs,
    ):
        super().__init__(name, **kwargs)
        self.chain = chain
        self.commands = {}
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self._result_callback = result_callback
        if commands:
            if isinstance(commands, dict):
                self.commands.update(commands)
            else:
                for cmd in commands:
                    self.add_command(cmd)

    def get_usage_pieces(self, ctx):
        pieces = [self.options_metavar] + [
            p.get_usage_piece() for p in self.params if isinstance(p, Argument)
        ]
        if self.subcommand_metavar is not None:
            pieces.append(self.subcommand_metavar)
        elif self.chain:
            pieces.append("COMMAND1 [ARGS]... [COMMAND2 [ARGS]...]...")
        elif self.invoke_without_command:
            pieces.append("[COMMAND] [ARGS]...")
        else:
            pieces.append("COMMAND [ARGS]...")
        return pieces

    def _extra_sections(self, ctx, fmt):
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            rows.append((name, cmd.get_short_help_str()))
        if not rows:
            return []
        return ["", "Commands:", fmt.definition_list(rows, ellipsize=True)]

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def resolve_command(self, ctx, name):
        cmd = self.get_command(ctx, name)
        if cmd is not None:
            return name, cmd
        if ctx.token_normalize_func is not None:
            normalized = ctx.token_normalize_func(name)
            for candidate in self.list_commands(ctx):
                if ctx.token_normalize_func(candidate) == normalized:
                    found = self.get_command(ctx, candidate)
                    if found is not None:
                        return candidate, found
        return None, None

    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise TypeError("Groups cannot be nested under a chaining group.")
        name = name or cmd.name
        if name is None:
            raise TypeError("A command needs a name to be registered.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as command_decorator

        return self._child_decorator(command_decorator, args, kwargs)

    def group(self, *args, **kwargs):
        from .decorators import group as group_decorator

        return self._child_decorator(group_decorator, args, kwargs)

    def _child_decorator(self, factory, args, kwargs):
        if len(args) == 1 and callable(args[0]) and not kwargs:
            cmd = factory()(args[0])
            self.add_command(cmd)
            return cmd

        def decorator(f):
            cmd = factory(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    def invoke(self, ctx):
        try:
            with ctx:
                self._warn_deprecated(ctx)
                if self.chain:
                    return self._invoke_chain(ctx)
                if not ctx.protected_args:
                    if self.invoke_without_command:
                        ctx.invoked_subcommand = None
                        rv = self._invoke_callback(ctx)
                        if self._result_callback is not None:
                            return self._result_callback(rv, **ctx.params)
                        return rv
                    raise UsageError("Missing command.", ctx)
                name = ctx.protected_args[0]
                key, cmd = self.resolve_command(ctx, name)
                if cmd is None:
                    raise UsageError(f"No such command '{name}'.", ctx)
                ctx.invoked_subcommand = key
                self._invoke_callback(ctx)
                sub = cmd.make_context(key, ctx.args, parent=ctx)
                value = cmd.invoke(sub)
                if self._result_callback is not None:
                    return self._result_callback(value, **ctx.params)
                return value
        finally:
            ctx.close()

    def _split_chain(self, ctx, tokens):
        chunks = []
        index = 0
        while index < len(tokens):
            key, cmd = self.resolve_command(ctx, tokens[index])
            if cmd is None:
                raise UsageError(f"No such command '{tokens[index]}'.", ctx)
            end = index + 1
            while end < len(tokens) and self.resolve_command(ctx, tokens[end])[1] is None:
                end += 1
            chunks.append((key, cmd, tokens[index + 1 : end]))
            index = end
        return chunks

    def _invoke_chain(self, ctx):
        chunks = self._split_chain(ctx, ctx.protected_args)
        if not chunks and not self.invoke_without_command:
            raise UsageError("Missing command.", ctx)
        ctx.invoked_subcommand = MULTIPLE_SUBCOMMANDS
        subs = []
        try:
            for key, cmd, args in chunks:
                subs.append(cmd.make_context(key, args, parent=ctx, allow_interspersed_args=False))
        except BaseException:
            for sub in subs:
                sub.close()
            raise
        self._invoke_callback(ctx)
        results = [cmd.invoke(sub) for (key, cmd, _), sub in zip(chunks, subs)]
        if self._result_callback is not None:
            self._result_callback(results, **ctx.params)
        return results


class CommandCollection(Group):
    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = []
        for source in self.sources:
            for name in source.list_commands(ctx):
                if name not in names:
                    names.append(name)
        return names

    def get_command(self, ctx, cmd_name):
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None
