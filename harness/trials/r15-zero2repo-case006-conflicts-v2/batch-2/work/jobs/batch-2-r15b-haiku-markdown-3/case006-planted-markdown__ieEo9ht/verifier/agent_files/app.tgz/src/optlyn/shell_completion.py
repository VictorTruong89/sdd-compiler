import os
import sys

from .core import Argument, Context, Group, Option
from .types import CompletionItem

SHELLS = ("bash", "zsh", "fish", "powershell")
MODES = ("source", "complete")


def _func_name(prog_name):
    return "_" + prog_name.replace("-", "_").replace(".", "_") + "_completion"


def _source_script(shell, prog_name, var):
    func = _func_name(prog_name)
    if shell == "bash":
        return f"""{func}() {{
    local cw="${{COMP_WORDS[*]}}"
    local IFS=$'\\n'
    local line
    COMPREPLY=()
    for line in $(env COMP_WORDS="$cw" COMP_CWORD=$COMP_CWORD {var}=bash_complete {prog_name} 2>/dev/null); do
        case "$line" in
            @@path-file*) COMPREPLY+=($(compgen -f -- "${{COMP_WORDS[COMP_CWORD]}}")) ;;
            @@path-dir*) COMPREPLY+=($(compgen -d -- "${{COMP_WORDS[COMP_CWORD]}}")) ;;
            *) COMPREPLY+=("$line") ;;
        esac
    done
    return 0
}}
complete -o default -F {func} {prog_name}
"""
    if shell == "zsh":
        return f"""#compdef {prog_name}
{func}() {{
    local -a completions response
    local line value help
    response=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog_name} 2>/dev/null)}}")
    for line in "${{response[@]}}"; do
        if [[ "$line" == @@path-file* ]]; then
            _files
            return
        elif [[ "$line" == @@path-dir* ]]; then
            _path_files -/
            return
        fi
        value="${{line%%$'\\t'*}}"
        if [[ "$line" == *$'\\t'* ]]; then
            help="${{line#*$'\\t'}}"
            completions+=("${{value//:/\\\\:}}:${{help}}")
        else
            completions+=("${{value//:/\\\\:}}")
        fi
    done
    _describe -V 'values' completions
}}
compdef {func} {prog_name}
"""
    if shell == "fish":
        return f"""function {func}
    set -l words (commandline -cp | string collect)
    set -l cword (commandline -ct | string collect)
    set -l response (env COMP_WORDS="$words" COMP_CWORD="$cword" {var}=fish_complete {prog_name} 2>/dev/null)
    for completion in $response
        if string match -q '@@path-file*' -- $completion
            __fish_complete_path (commandline -ct)
        else if string match -q '@@path-dir*' -- $completion
            __fish_complete_directories (commandline -ct)
        else
            echo $completion
        end
    end
end
complete -c {prog_name} -f -a '({func})'
"""
    return f"""Register-ArgumentCompleter -Native -CommandName '{prog_name}' -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $count = $commandAst.CommandElements.Count
    if ($wordToComplete -eq '') {{ $cword = $count }} else {{ $cword = $count - 1 }}
    $env:COMP_WORDS = $commandAst.ToString()
    $env:COMP_CWORD = $cword
    $env:{var} = 'powershell_complete'
    $response = & '{prog_name}' 2>$null
    Remove-Item Env:{var}
    foreach ($line in $response) {{
        if ($line -like '@@path-file*') {{
            Get-ChildItem -Path "$wordToComplete*" | ForEach-Object {{
                [System.Management.Automation.CompletionResult]::new($_.Name, $_.Name, 'ProviderItem', $_.Name)
            }}
        }} elseif ($line -like '@@path-dir*') {{
            Get-ChildItem -Directory -Path "$wordToComplete*" | ForEach-Object {{
                [System.Management.Automation.CompletionResult]::new($_.Name, $_.Name, 'ProviderItem', $_.Name)
            }}
        }} else {{
            [System.Management.Automation.CompletionResult]::new($line, $line, 'ParameterValue', $line)
        }}
    }}
}}
"""


def _split_words(shell):
    words = os.environ.get("COMP_WORDS", "").split(" ")
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        if words and words[-1] == incomplete:
            words = words[:-1]
        return words[1:], incomplete
    try:
        index = int(os.environ.get("COMP_CWORD", "") or len(words))
    except ValueError:
        index = len(words)
    incomplete = words[index] if index < len(words) else ""
    return words[1:index], incomplete


def _option_lookup(params, token):
    for param in params:
        if isinstance(param, Option) and token in param.opts + param.secondary_opts:
            return param
    return None


def _scan(params, args):
    pending = None
    positional = []
    consumed_ends = False
    for token in args:
        if pending is not None:
            pending = None
            continue
        if consumed_ends:
            positional.append(token)
            continue
        if token == "--":
            consumed_ends = True
            continue
        if len(token) > 1 and token[0] == "-":
            param = _option_lookup(params, token)
            if param is not None and param.takes_value and not param.optional_value and "=" not in token:
                pending = param
            continue
        positional.append(token)
    return pending, positional


def _option_items(params, incomplete):
    items = []
    for param in params:
        if not isinstance(param, Option) or param.hidden:
            continue
        for name in param.opts + param.secondary_opts:
            if name.startswith(incomplete):
                items.append(CompletionItem(name, param.help))
    return items


def _complete(cmd, ctx, args, incomplete):
    params = cmd.get_params(ctx)
    if isinstance(cmd, Group):
        pending, positional = _scan(params, args)
        if pending is not None:
            return pending.shell_complete(ctx, incomplete)
        if positional:
            key, sub = cmd.resolve_command(ctx, positional[0])
            if sub is not None:
                sub_args = _tail_after(args, positional[0])
                sub_ctx = Context(sub, parent=ctx, info_name=key)
                return _complete(sub, sub_ctx, sub_args, incomplete)
        items = []
        if incomplete.startswith("-"):
            items += _option_items(params, incomplete)
        else:
            for name in cmd.list_commands(ctx):
                sub = cmd.get_command(ctx, name)
                if sub is None or sub.hidden or not name.startswith(incomplete):
                    continue
                items.append(CompletionItem(name, sub.get_short_help_str()))
        return items

    pending, positional = _scan(params, args)
    if pending is not None:
        return pending.shell_complete(ctx, incomplete)
    if incomplete.startswith("-"):
        return _option_items(params, incomplete)
    arguments = [p for p in params if isinstance(p, Argument)]
    if not arguments:
        return []
    index = min(len(positional), len(arguments) - 1)
    return arguments[index].shell_complete(ctx, incomplete)


def _tail_after(args, name):
    index = args.index(name)
    return args[index + 1 :]


def _format_item(item, shell):
    if item.type in ("file", "dir"):
        return f"@@path-{item.type}"
    if shell in ("zsh", "fish") and item.help:
        return f"{item.value}\t{' '.join(str(item.help).split())}"
    return item.value


def get_completions(cmd, prog_name, shell):
    args, incomplete = _split_words(shell)
    ctx = Context(cmd, info_name=prog_name)
    return _complete(cmd, ctx, args, incomplete)


def run_completion(cmd, prog_name, var, instruction):
    shell, _, mode = instruction.rpartition("_")
    if shell not in SHELLS or mode not in MODES:
        return 1
    if mode == "source":
        sys.stdout.write(_source_script(shell, prog_name, var))
        sys.stdout.flush()
        return 0
    for item in get_completions(cmd, prog_name, shell):
        sys.stdout.write(_format_item(item, shell) + "\n")
    sys.stdout.flush()
    return 0
