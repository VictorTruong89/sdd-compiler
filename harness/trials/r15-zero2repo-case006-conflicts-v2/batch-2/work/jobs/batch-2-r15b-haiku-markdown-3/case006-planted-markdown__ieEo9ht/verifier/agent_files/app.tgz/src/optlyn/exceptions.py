import sys


class OptlynError(Exception):
    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def show(self, file=None):
        from .termui import echo

        echo(f"Error: {self.format_message()}", file=file or sys.stderr, err=True)


class UsageError(OptlynError):
    exit_code = 2

    def __init__(self, message, ctx=None, show_help=False):
        super().__init__(message)
        self.ctx = ctx
        self.show_help = show_help

    def show(self, file=None):
        from .termui import echo

        if self.show_help and self.ctx is not None:
            echo(self.ctx.get_help(), file=file or sys.stderr, err=True)
            return
        if self.ctx is not None:
            echo(self.ctx.get_usage(), file=file or sys.stderr, err=True)
            echo(
                f"Try '{self.ctx.command_path} {self.ctx.help_option_names[0]}' for help.",
                file=file or sys.stderr,
                err=True,
            )
        echo(f"\nError: {self.format_message()}", file=file or sys.stderr, err=True)


class BadParameter(UsageError):
    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.param_hint:
            return f"Invalid value for {self.param_hint}: {self.message}"
        return self.message


class MissingParameter(UsageError):
    pass


class NoSuchOption(UsageError):
    pass


class BadOptionUsage(UsageError):
    pass


class BadArgumentUsage(UsageError):
    pass


class FileError(OptlynError):
    exit_code = 1


class Abort(RuntimeError):
    pass


class Exit(RuntimeError):
    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
