import contextlib
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time

from ._globals import get_current_context
from .exceptions import Abort, BadParameter
from .types import convert_type
from .utils import is_interactive, is_terminal, launch  # noqa: F401

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")

_COLORS = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
}

_IN_PROMPT = [False]


def unstyle(text):
    return _ansi_re.sub("", text)


def _color_code(color, bg):
    if isinstance(color, str):
        if color == "reset":
            return "49" if bg else "39"
        if color in _COLORS:
            return str(_COLORS[color] + (10 if bg else 0))
    elif isinstance(color, int) and not isinstance(color, bool):
        if 0 <= color <= 255:
            return f"{48 if bg else 38};5;{color}"
    elif isinstance(color, (tuple, list)) and len(color) == 3:
        if all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color):
            return f"{48 if bg else 38};2;{color[0]};{color[1]};{color[2]}"
    raise ValueError(f"Unknown color {color!r}.")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
):
    bits = []
    if fg is not None:
        bits.append(_color_code(fg, False))
    if bg is not None:
        bits.append(_color_code(bg, True))
    switches = (
        (bold, 1),
        (dim, 2),
        (italic, 3),
        (underline, 4),
        (blink, 5),
        (reverse, 7),
        (strikethrough, 9),
        (overline, 53),
    )
    for flag, code in switches:
        if flag:
            bits.append(str(code))
    if not bits:
        return text
    result = f"\033[{';'.join(bits)}m{text}"
    if reset:
        result += "\033[0m"
    return result


def _write_text(file, text):
    encoding = (getattr(file, "encoding", None) or "").lower()
    ascii_only = encoding in ("ascii", "us-ascii")
    if ascii_only and not text.isascii():
        file.flush()
        file.buffer.write(text.encode("utf-8"))
        return
    try:
        file.write(text)
    except UnicodeEncodeError:
        file.flush()
        file.buffer.write(text.encode("utf-8"))


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    elif not isinstance(message, (str, bytes)):
        message = str(message)
    if color is None:
        ctx = get_current_context(silent=True)
        if ctx is not None:
            color = ctx.color
    if isinstance(message, bytes):
        data = message + (b"\n" if nl else b"")
        buffer = getattr(file, "buffer", None)
        if buffer is not None:
            file.flush()
            buffer.write(data)
        else:
            file.write(data.decode("utf-8", "replace"))
    else:
        if color is False or (color is None and not is_terminal(file)):
            message = unstyle(message)
        if nl:
            message += "\n"
        _write_text(file, message)
    try:
        file.flush()
    except (AttributeError, ValueError):
        pass


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, bytes):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def _read_line(prompt_text, hide_input=False, err=False):
    echo(prompt_text, nl=False, err=err)
    stdin = sys.stdin
    _IN_PROMPT[0] = True
    try:
        if hide_input and is_terminal(stdin):
            line = _read_hidden(stdin)
        else:
            line = stdin.readline()
    finally:
        _IN_PROMPT[0] = False
    if line == "":
        raise Abort()
    line = line.rstrip("\r\n")
    if hide_input:
        echo("", err=err)
    elif not is_terminal(stdin):
        echo(line, err=err)
    return line


def _read_hidden(stdin):
    import termios

    fd = stdin.fileno()
    old = termios.tcgetattr(fd)
    new = termios.tcgetattr(fd)
    new[3] &= ~termios.ECHO
    termios.tcsetattr(fd, termios.TCSADRAIN, new)
    try:
        return stdin.readline()
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    value_proc=None,
    prompt_suffix=": ",
    show_default=True,
    err=False,
    show_choices=True,
):
    ptype = convert_type(type, default)
    if callable(default):
        default = default()
    prompt_text = text
    if default is not None and show_default:
        shown = ", ".join(map(str, default)) if isinstance(default, (list, tuple)) else default
        prompt_text = f"{text} [{shown}]"
    while True:
        value = _read_line(prompt_text + prompt_suffix, hide_input, err)
        if value == "":
            if default is not None:
                if isinstance(default, str):
                    try:
                        return ptype.convert(default, None, None)
                    except BadParameter as e:
                        echo(f"Error: {e.message}", err=err)
                        continue
                return default
            continue
        try:
            result = ptype.convert(value, None, None)
        except BadParameter as e:
            echo(f"Error: {e.message}", err=err)
            continue
        if confirmation_prompt:
            second = _read_line(
                "Repeat for confirmation" + prompt_suffix, hide_input, err
            )
            if second != value:
                echo("Error: The two entered values do not match.", err=err)
                continue
        return result


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    if show_default:
        hint = " [Y/n]" if default else " [y/N]"
    else:
        hint = ""
    while True:
        answer = _read_line(text + hint + prompt_suffix, False, err).strip().lower()
        if answer in ("y", "yes"):
            rv = True
            break
        if answer in ("n", "no"):
            rv = False
            break
        if answer == "":
            rv = default
            break
    if not rv and abort:
        raise Abort()
    return rv


def getchar(echo_char=False):
    fd = None
    opened = None
    try:
        import termios
        import tty

        if is_terminal(sys.stdin):
            fd = sys.stdin.fileno()
        else:
            opened = os.open("/dev/tty", os.O_RDONLY)
            fd = opened
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            data = os.read(fd, 1)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        ch = data.decode("utf-8", "replace")
    except (ImportError, OSError, ValueError):
        ch = sys.stdin.read(1)
    finally:
        if opened is not None:
            os.close(opened)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    if echo_char:
        echo(ch, nl=False)
    return ch


def pause(info=None, err=False):
    if not is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    echo(info, nl=False, err=err)
    getchar(True)
    echo("", err=err)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    if editor is None:
        editor = (
            (env or {}).get("EDITOR")
            or os.environ.get("VISUAL")
            or os.environ.get("EDITOR")
            or ("notepad" if sys.platform == "win32" else "vi")
        )
    command = shlex.split(editor)
    run_env = None
    if env:
        run_env = {**os.environ, **env}
    if filename is not None:
        subprocess.call(command + [os.fspath(filename)], env=run_env)
        return None
    original = text or ""
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            f.write(original)
        subprocess.call(command + [path], env=run_env)
        with open(path, encoding="utf-8", newline="") as f:
            result = f.read()
    finally:
        os.remove(path)
    if require_save and result == original:
        return None
    return result


def clear():
    if not is_terminal(sys.stdout):
        return
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()


def _start_pager():
    pager = os.environ.get("PAGER") or "less"
    proc = subprocess.Popen(pager, shell=True, stdin=subprocess.PIPE)
    return proc


class _PagerWriter:
    def __init__(self, stream, keep_styles):
        self._stream = stream
        self._keep = keep_styles

    def write(self, text):
        if not self._keep:
            text = unstyle(text)
        self._stream.write(text.encode("utf-8"))
        self._stream.flush()
        return len(text)

    def flush(self):
        self._stream.flush()


def _chunks(text_or_generator):
    if isinstance(text_or_generator, str):
        return [text_or_generator]
    if callable(text_or_generator):
        return text_or_generator()
    return text_or_generator


def echo_via_pager(text_or_generator, color=None):
    chunks = _chunks(text_or_generator)
    if not is_interactive():
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    proc = _start_pager()
    writer = _PagerWriter(proc.stdin, color is True)
    try:
        for chunk in chunks:
            writer.write(chunk)
    except BrokenPipeError:
        pass
    finally:
        try:
            proc.stdin.close()
        except BrokenPipeError:
            pass
        proc.wait()


class _EchoWriter:
    def __init__(self, color):
        self._color = color

    def write(self, text):
        echo(text, nl=False, color=self._color)
        return len(text)

    def flush(self):
        sys.stdout.flush()


@contextlib.contextmanager
def get_pager_file(color=None):
    if not is_interactive():
        yield _EchoWriter(color)
        return
    proc = _start_pager()
    writer = _PagerWriter(proc.stdin, color is True)
    try:
        yield writer
    finally:
        try:
            proc.stdin.close()
        except BrokenPipeError:
            pass
        proc.wait()


def _fmt_time(seconds):
    seconds = int(seconds)
    hours, rest = divmod(seconds, 3600)
    minutes, secs = divmod(rest, 60)
    return f"{hours}:{minutes:02d}:{secs:02d}"


class ProgressBar:
    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options):
        self.iterable = iterable
        if length is None and iterable is not None and hasattr(iterable, "__len__"):
            length = len(iterable)
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.pos = 0
        self.width = options.get("width", 36)
        self.start = time.time()
        self.is_tty = not hidden and is_terminal(sys.stdout)

    def __enter__(self):
        if not self.hidden and not self.is_tty and self.label:
            echo(self.label)
        return self

    def __exit__(self, exc_type, exc, tb):
        if self.is_tty:
            self._render()
            echo("")

    def __iter__(self):
        if self.iterable is None:
            raise TypeError("No iterable was given to the progress bar.")
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps):
        self.pos += n_steps
        if self.is_tty:
            self._render()

    def _render(self):
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            filled = int(frac * self.width)
            bar = "#" * filled + "-" * (self.width - filled)
            elapsed = time.time() - self.start
            remaining = elapsed / self.pos * (self.length - self.pos) if self.pos else 0
            line = f"\r{self.label} [{bar}] {self.pos}/{self.length}  eta {_fmt_time(remaining)}"
        else:
            line = f"\r{self.label} {self.pos}"
        sys.stdout.write(line)
        sys.stdout.flush()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)
