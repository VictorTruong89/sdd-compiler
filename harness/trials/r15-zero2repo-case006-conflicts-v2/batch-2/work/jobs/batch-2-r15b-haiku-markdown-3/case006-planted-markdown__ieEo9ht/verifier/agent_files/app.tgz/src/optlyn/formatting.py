import re
import textwrap


def _paragraphs(text):
    return [p for p in re.split(r"\n\s*\n", text.strip("\n")) if p.strip()]


def format_paragraphs(text, width):
    out = []
    for para in _paragraphs(text):
        lines = para.split("\n")
        if lines[0].strip() == "\b":
            out.append("\n".join(line.rstrip() for line in lines[1:]))
        else:
            words = " ".join(line.strip() for line in lines)
            out.append(textwrap.fill(words, width=max(width, 10)))
    return "\n\n".join(out)


def wrap_text(
    text,
    width=100,
    initial_indent="",
    subsequent_indent="",
    preserve_paragraphs=False,
):
    if not text:
        return ""
    width = max(width, 10)
    out = []
    for para in _paragraphs(text):
        lines = para.split("\n")
        if lines[0].strip() == "\b" or (preserve_paragraphs and len(lines) > 1):
            body = [line for line in lines if line.strip() != "\b"]
            out.append("\n".join(initial_indent + line for line in body))
        else:
            words = " ".join(line.strip() for line in lines)
            out.append(
                textwrap.fill(
                    words,
                    width=width,
                    initial_indent=initial_indent,
                    subsequent_indent=subsequent_indent,
                )
            )
    return "\n\n".join(out)


class HelpFormatter:
    def __init__(self, width=80):
        self.width = width

    def usage(self, prefix, pieces):
        text = prefix + " ".join(p for p in pieces if p)
        return textwrap.fill(
            text,
            width=max(self.width, 20),
            subsequent_indent=" " * len(prefix),
            break_long_words=False,
            break_on_hyphens=False,
        )

    def paragraph(self, text):
        return format_paragraphs(text, self.width)

    def definition_list(self, rows, ellipsize=False, col_max=30, indent=2):
        if not rows:
            return ""
        first_width = min(max(len(first) for first, _ in rows), col_max)
        text_col = indent + first_width + 2
        text_width = max(self.width - text_col, 10)
        pad = " " * text_col
        lines = []
        for first, second in rows:
            head = " " * indent + first
            if not second:
                lines.append(head)
                continue
            if len(first) <= first_width:
                head = " " * indent + first.ljust(first_width + 2)
                wrapped = textwrap.wrap(" ".join(second.split()), width=text_width)
                if ellipsize and len(wrapped) > 1:
                    wrapped = [wrapped[0][: max(text_width - 3, 1)].rstrip() + "..."]
                lines.append(head + (wrapped[0] if wrapped else ""))
                lines.extend(pad + w for w in wrapped[1:])
            else:
                lines.append(head)
                wrapped = textwrap.wrap(" ".join(second.split()), width=text_width)
                if ellipsize and len(wrapped) > 1:
                    wrapped = [wrapped[0][: max(text_width - 3, 1)].rstrip() + "..."]
                lines.extend(pad + w for w in wrapped)
        return "\n".join(lines)
