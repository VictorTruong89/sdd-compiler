import os
import shutil
import subprocess
import sys
import tempfile

from .exceptions import FileError


class _NonClosingIO:
    def __init__(self, stream):
        self._stream = stream

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.flush()

    def close(self):
        self.flush()


def _std_stream(name, mode):
    stream = sys.stdin if name == "stdin" else sys.stdout
    if "b" in mode:
        stream = getattr(stream, "buffer", stream)
    return _NonClosingIO(stream)


def _open_real(filename, mode, encoding, errors, atomic):
    if atomic and any(c in mode for c in "wax"):
        return _AtomicFile(filename, mode, encoding, errors)
    if "b" in mode:
        return open(filename, mode)
    return open(filename, mode, encoding=encoding, errors=errors)


class _AtomicFile:
    def __init__(self, filename, mode, encoding, errors):
        self._filename = filename
        self._f = None
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".~", suffix=".tmp")
        os.close(fd)
        self._f = _open_real(self._tmp, mode, encoding, errors, False)

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def __iter__(self):
        return iter(self._f)

    def close(self):
        if self._f.closed:
            return
        self._f.close()
        os.replace(self._tmp, self._filename)


class LazyFile:
    def __init__(self, filename, mode, encoding, errors, atomic):
        self._filename = filename
        self._args = (mode, encoding, errors, atomic)
        self._f = None

    def _open(self):
        if self._f is None:
            mode, encoding, errors, atomic = self._args
            try:
                self._f = _open_real(self._filename, mode, encoding, errors, atomic)
            except OSError as e:
                raise FileError(
                    f"Could not open file '{self._filename}': {e.strerror}"
                ) from e
        return self._f

    @property
    def closed(self):
        return self._f is None or self._f.closed

    def __getattr__(self, name):
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def close(self):
        if self._f is not None:
            self._f.close()


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if filename == "-":
        return _std_stream("stdin" if "r" in mode else "stdout", mode)
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    return _open_real(filename, mode, encoding, errors, atomic)


def is_terminal(stream):
    try:
        return stream is not None and stream.isatty()
    except (AttributeError, ValueError):
        return False


def is_interactive():
    return is_terminal(sys.stdin) or is_terminal(sys.stdout)


def get_app_dir(app_name, roaming=True, force_posix=False):
    home = os.path.expanduser("~")
    if sys.platform.startswith("win") and not force_posix:
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(home, "Library", "Application Support", app_name)
    folder = "-".join(app_name.lower().split())
    if force_posix:
        return os.path.join(home, "." + folder)
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(base, folder)


def format_filename(filename, shorten=False):
    if isinstance(filename, bytes):
        filename = os.fsdecode(filename)
    else:
        filename = os.fspath(filename)
    if shorten:
        filename = os.path.basename(filename)
    return filename.encode("utf-8", "backslashreplace").decode("utf-8")


def launch(url, wait=False, locate=False):
    if sys.platform == "win32":
        os.startfile(url)  # type: ignore[attr-defined]
        return 0
    if sys.platform == "darwin":
        args = ["open"] + (["-R"] if locate else []) + [url]
    else:
        args = ["xdg-open", url]
    if shutil.which(args[0]) is None:
        return 127
    try:
        proc = subprocess.Popen(args, stdin=subprocess.DEVNULL)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0
