import datetime as _dt
import enum
import os
import pathlib
import uuid

from .exceptions import BadParameter
from .utils import format_filename, open_file

TRUE_VALUES = ("1", "true", "t", "yes", "y", "on")
FALSE_VALUES = ("0", "false", "f", "no", "n", "off")


class CompletionItem:
    def __init__(self, value, help=None, type="plain"):
        self.value = value
        self.help = help
        self.type = type

    def __repr__(self):
        return f"CompletionItem({self.value!r}, {self.help!r}, {self.type!r})"


class ParamType:
    name = "text"
    is_composite = False

    def __call__(self, value, param=None, ctx=None):
        if value is None:
            return None
        return self.convert(value, param, ctx)

    def convert(self, value, param, ctx):
        return value

    def get_metavar(self, param):
        return self.name.upper()

    def split_envvar_value(self, rv):
        return rv.split()

    def shell_complete(self, ctx, param, incomplete):
        return []

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self):
        return self.name.upper()


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        if isinstance(value, str):
            return value
        return str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param, ctx):
        if isinstance(value, int) and not isinstance(value, bool):
            return value
        if isinstance(value, float) and value.is_integer():
            return int(value)
        try:
            return int(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param, ctx):
        if isinstance(value, float):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return float(value)
        try:
            return float(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in TRUE_VALUES:
            return True
        if text in FALSE_VALUES:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


STRING = StringParamType()
UNPROCESSED = UnprocessedParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._keys = [member.name for member in choices]
        else:
            self.choices = list(choices)
            self._keys = [str(c) for c in self.choices]
        self.case_sensitive = case_sensitive

    def get_metavar(self, param):
        return "[" + "|".join(self._keys) + "]"

    def _normalize(self, token, ctx):
        if ctx is not None and ctx.token_normalize_func is not None:
            token = ctx.token_normalize_func(token)
        if not self.case_sensitive:
            token = token.casefold()
        return token

    def convert(self, value, param, ctx):
        for choice in self.choices:
            if value is choice:
                return choice
        normalized = self._normalize(str(value), ctx)
        for key, original in zip(self._keys, self.choices):
            if self._normalize(key, ctx) == normalized:
                return original
        choices_str = ", ".join(repr(k) for k in self._keys)
        self.fail(f"{value!r} is not {choices_str}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        return [
            CompletionItem(key)
            for key in self._keys
            if key.startswith(incomplete)
        ]


class DateTime(ParamType):
    name = "datetime"
    default_formats = ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S")

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(self.default_formats)

    def convert(self, value, param, ctx):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        self.fail(f"{value!r} does not match the formats {', '.join(self.formats)}.", param, ctx)


def _range_check(rng, value, param, ctx):
    low, high = rng.min, rng.max
    if low is not None and (value <= low if rng.min_open else value < low):
        if not rng.clamp:
            rng.fail(_range_message(rng, value), param, ctx)
        if rng.min_open:
            value = low + 1 if isinstance(low, int) else low
        else:
            value = low
    if high is not None and (value >= high if rng.max_open else value > high):
        if not rng.clamp:
            rng.fail(_range_message(rng, value), param, ctx)
        if rng.max_open:
            value = high - 1 if isinstance(high, int) else high
        else:
            value = high
    return value


def _range_message(rng, value):
    parts = []
    if rng.min is not None:
        parts.append(f"{'>' if rng.min_open else '>='} {rng.min}")
    if rng.max is not None:
        parts.append(f"{'<' if rng.max_open else '<='} {rng.max}")
    return f"{value} is not in the range {' and '.join(parts)}."


class IntRange(IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        value = super().convert(value, param, ctx)
        return _range_check(self, value, param, ctx)


class FloatRange(FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is not supported for open bounds.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        value = super().convert(value, param, ctx)
        return _range_check(self, value, param, ctx)


class Tuple(ParamType):
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(t) for t in types]
        self.name = " ".join(t.name for t in self.types)

    def get_metavar(self, param):
        return " ".join(t.get_metavar(param) for t in self.types)

    def convert(self, value, param, ctx):
        if len(value) != len(self.types):
            self.fail(f"{len(self.types)} values are required, but {len(value)} were given.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


class File(ParamType):
    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = ("w" in mode) if lazy is None else lazy
        self.atomic = atomic

    def get_metavar(self, param):
        return "FILENAME"

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def convert(self, value, param, ctx):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        if isinstance(value, bytes):
            value = os.fsdecode(value)
        value = os.fspath(value)
        try:
            f = open_file(
                value,
                self.mode,
                self.encoding,
                self.errors,
                lazy=self.lazy,
                atomic=self.atomic,
            )
        except OSError as e:
            self.fail(f"Could not open file '{format_filename(value)}': {e.strerror}", param, ctx)
        if value != "-" and ctx is not None:
            ctx.call_on_close(f.close)
        return f

    def shell_complete(self, ctx, param, incomplete):
        return [CompletionItem("@@file", type="file")]


class Path(ParamType):
    name = "path"

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def get_metavar(self, param):
        return "PATH"

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            value = os.fsdecode(value)
        rv = os.fspath(value)
        shown = format_filename(rv)
        if not (self.allow_dash and rv == "-"):
            if os.path.exists(rv):
                if not self.file_okay and os.path.isfile(rv):
                    self.fail(f"'{shown}' is a file.", param, ctx)
                if not self.dir_okay and os.path.isdir(rv):
                    self.fail(f"'{shown}' is a directory.", param, ctx)
                if self.readable and not os.access(rv, os.R_OK):
                    self.fail(f"'{shown}' is not readable.", param, ctx)
                if self.writable and not os.access(rv, os.W_OK):
                    self.fail(f"'{shown}' is not writable.", param, ctx)
                if self.executable and not os.access(rv, os.X_OK):
                    self.fail(f"'{shown}' is not executable.", param, ctx)
            elif self.exists:
                self.fail(f"'{shown}' does not exist.", param, ctx)
            if self.resolve_path:
                rv = os.path.realpath(rv)
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return rv

    def shell_complete(self, ctx, param, incomplete):
        kind = "dir" if self.dir_okay and not self.file_okay else "file"
        return [CompletionItem("@@" + kind, type=kind)]


class _FuncType(ParamType):
    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text").lower()

    def convert(self, value, param, ctx):
        if not isinstance(value, str):
            return value
        try:
            return self.func(value)
        except ValueError:
            self.fail(f"{value!r} is not a valid {self.name}.", param, ctx)


def convert_type(ty, default=None):
    if ty is None:
        if isinstance(default, bool):
            return BOOL
        if isinstance(default, int):
            return INT
        if isinstance(default, float):
            return FLOAT
        if isinstance(default, tuple) and default:
            return Tuple([convert_type(None, d) for d in default])
        if isinstance(default, list) and default:
            return convert_type(None, default[0])
        return STRING
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, (tuple, list)):
        return Tuple(ty)
    if isinstance(ty, type):
        if issubclass(ty, enum.Enum):
            return Choice(ty)
        simple = {
            str: STRING,
            int: INT,
            float: FLOAT,
            bool: BOOL,
            uuid.UUID: UUID,
        }
        if ty in simple:
            return simple[ty]
    if callable(ty):
        return _FuncType(ty)
    raise TypeError(f"Unsupported parameter type {ty!r}.")
