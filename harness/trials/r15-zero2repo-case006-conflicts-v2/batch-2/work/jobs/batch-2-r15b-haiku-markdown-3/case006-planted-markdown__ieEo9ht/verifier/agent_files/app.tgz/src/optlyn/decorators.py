import functools
import inspect
from importlib import metadata

from . import termui
from ._globals import get_current_context
from .core import Argument, Command, Group, Option
from .types import STRING

_CHILD_SUFFIXES = ("_command", "_cmd", "_group", "_grp")


def _attach_param(f, param):
    if isinstance(f, Command):
        f.params.append(param)
        return f
    f.__dict__.setdefault("__optlyn_params__", []).append(param)
    return f


def _pop_params(f):
    params = f.__dict__.pop("__optlyn_params__", [])
    return list(reversed(params))


def _default_name(func_name):
    name = func_name.lower()
    for suffix in _CHILD_SUFFIXES:
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _doc_text(func):
    doc = func.__doc__
    if not doc:
        return None
    return inspect.cleandoc(doc).split("\f")[0]


def _command_factory(default_cls, name, cls, attrs):
    def decorator(f):
        params = _pop_params(f)
        cmd_name = name if name is not None else _default_name(f.__name__)
        attrs_copy = dict(attrs)
        help_text = attrs_copy.pop("help", None)
        if help_text is None:
            help_text = _doc_text(f)
        else:
            help_text = inspect.cleandoc(help_text).split("\f")[0]
        klass = cls or default_cls
        return klass(name=cmd_name, callback=f, params=params, help=help_text, **attrs_copy)

    return decorator


def command(name=None, cls=None, **attrs):
    if callable(name) and not isinstance(name, str):
        return command()(name)
    return _command_factory(Command, name, cls, attrs)


def group(name=None, cls=None, **attrs):
    if callable(name) and not isinstance(name, str):
        return group()(name)
    return _command_factory(Group, name, cls, attrs)


def option(*param_decls, cls=None, **attrs):
    klass = cls or Option

    def decorator(f):
        return _attach_param(f, klass(param_decls, **attrs))

    return decorator


def argument(*param_decls, cls=None, **attrs):
    klass = cls or Argument

    def decorator(f):
        return _attach_param(f, klass(param_decls, **attrs))

    return decorator


def help_option(*param_decls, **kwargs):
    names = list(param_decls) or ["--help"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")

    def callback(ctx, param, value):
        if not value:
            return
        termui.echo(ctx.get_help(), color=ctx.color)
        ctx.exit()

    kwargs.setdefault("callback", callback)
    return option(*names, **kwargs)


def _detect_version(package_name):
    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    providers = metadata.packages_distributions().get(package_name, [])
    for dist in providers:
        try:
            return metadata.version(dist)
        except metadata.PackageNotFoundError:
            continue
    return "unknown"


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    names = list(param_decls) or ["--version"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value:
            return
        prog = prog_name or ctx.find_root().info_name
        identity = version
        if identity is None:
            identity = _detect_version(package_name or prog)
        template = message or "%(prog)s, version %(version)s"
        termui.echo(template % {"prog": prog, "version": identity}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("callback", callback)
    return option(*names, **kwargs)


def custom_version_option(callback_func, *param_decls, **kwargs):
    names = list(param_decls) or ["--version"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")

    def callback(ctx, param, value):
        if not value:
            return
        termui.echo(callback_func(ctx), color=ctx.color)
        ctx.exit()

    kwargs.setdefault("callback", callback)
    return option(*names, **kwargs)


def password_option(*param_decls, **kwargs):
    names = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("type", STRING)
    return option(*names, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    names = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")

    def callback(ctx, param, value):
        if not value:
            termui.confirm(question, default=False, abort=True)
        return value

    kwargs.setdefault("callback", callback)
    return option(*names, **kwargs)


def pass_context(f):
    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return new_func


def pass_obj(f):
    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            return f(obj, *args, **kwargs)

        return new_func

    return decorator
