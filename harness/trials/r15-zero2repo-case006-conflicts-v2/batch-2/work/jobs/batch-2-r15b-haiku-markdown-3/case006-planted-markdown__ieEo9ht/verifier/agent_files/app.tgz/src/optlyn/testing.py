import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import termui


class _Tee(io.BufferedIOBase):
    def __init__(self, *targets):
        self.targets = targets

    def writable(self):
        return True

    def write(self, data):
        for target in self.targets:
            target.write(data)
        return len(data)

    def flush(self):
        pass


class _RunnerStdin:
    def __init__(self, stream, echo_reads, echo_out):
        self._stream = stream
        self._echo_reads = echo_reads
        self._echo_out = echo_out

    def _maybe_echo(self, text):
        if self._echo_reads and text and not termui._IN_PROMPT[0]:
            self._echo_out(text)

    def readline(self, *args):
        line = self._stream.readline(*args)
        self._maybe_echo(line)
        return line

    def read(self, *args):
        data = self._stream.read(*args)
        self._maybe_echo(data)
        return data

    def isatty(self):
        return False

    def __iter__(self):
        return iter(self.readline, "")

    def __getattr__(self, name):
        return getattr(self._stream, name)


def _decode(data, charset):
    try:
        return data.decode(charset)
    except (UnicodeDecodeError, LookupError):
        return data.decode("utf-8", "replace")


class Result:
    def __init__(self, exit_code, output_bytes, stdout_bytes, stderr_bytes, exception, charset):
        self.exit_code = exit_code
        self.exception = exception
        self._charset = charset
        self.output_bytes = output_bytes
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes

    @property
    def output(self):
        return _decode(self.output_bytes, self._charset)

    @property
    def stdout(self):
        return _decode(self.stdout_bytes, self._charset)

    @property
    def stderr(self):
        return _decode(self.stderr_bytes, self._charset)

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        input_bytes = input.encode(self.charset) if isinstance(input, str) else (input or b"")
        merged_env = {**self.env, **(env or {})}
        if self.capture == "fd":
            with self._fd_isolation(input_bytes, merged_env) as streams:
                yield streams
            return
        out_buf = io.BytesIO()
        err_buf = io.BytesIO()
        combined = io.BytesIO()
        stdout = io.TextIOWrapper(_Tee(out_buf, combined), encoding=self.charset, write_through=True)
        stderr = io.TextIOWrapper(_Tee(err_buf, combined), encoding=self.charset, write_through=True)
        stdin = _RunnerStdin(
            io.TextIOWrapper(io.BytesIO(input_bytes), encoding=self.charset),
            self.echo_stdin,
            stdout.write,
        )
        with self._swap_streams(stdin, stdout, stderr, merged_env):
            streams = {"combined": combined, "stdout": out_buf, "stderr": err_buf}
            yield _Capture(streams, [stdout, stderr])

    @contextlib.contextmanager
    def _swap_streams(self, stdin, stdout, stderr, env):
        old_streams = (sys.stdin, sys.stdout, sys.stderr)
        old_env = {}
        for key, value in env.items():
            old_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield
        finally:
            stdout.flush()
            stderr.flush()
            sys.stdin, sys.stdout, sys.stderr = old_streams
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    @contextlib.contextmanager
    def _fd_isolation(self, input_bytes, env):
        out_file = tempfile.TemporaryFile()
        err_file = tempfile.TemporaryFile()
        sys.stdout.flush()
        sys.stderr.flush()
        saved_out = os.dup(1)
        saved_err = os.dup(2)
        os.dup2(out_file.fileno(), 1)
        os.dup2(err_file.fileno(), 2)
        stdout = io.TextIOWrapper(out_file, encoding=self.charset, write_through=True)
        stderr = io.TextIOWrapper(err_file, encoding=self.charset, write_through=True)
        stdin = _RunnerStdin(
            io.TextIOWrapper(io.BytesIO(input_bytes), encoding=self.charset),
            self.echo_stdin,
            stdout.write,
        )
        try:
            with self._swap_streams(stdin, stdout, stderr, env):
                yield _Capture({"fd": (out_file, err_file)}, [stdout, stderr])
        finally:
            stdout.flush()
            stderr.flush()
            os.dup2(saved_out, 1)
            os.dup2(saved_err, 2)
            os.close(saved_out)
            os.close(saved_err)

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            args = shlex.split(args)
        else:
            args = list(args)
        prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
        standalone = extra.pop("standalone_mode", True)
        exit_code = 0
        exception = None
        with self.isolation(input=input, env=env, color=color) as capture:
            try:
                cli.main(
                    args=args,
                    prog_name=prog_name,
                    standalone_mode=standalone,
                    color=color,
                    **extra,
                )
            except SystemExit as e:
                code = e.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    exit_code = 1
                if exit_code != 0:
                    exception = e
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
            output_bytes, stdout_bytes, stderr_bytes = capture.collect()
        return Result(exit_code, output_bytes, stdout_bytes, stderr_bytes, exception, self.charset)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(dt, ignore_errors=True)


class _Capture:
    def __init__(self, streams, text_streams):
        self._streams = streams
        self._text_streams = text_streams

    def collect(self):
        for stream in self._text_streams:
            stream.flush()
        if "fd" in self._streams:
            out_file, err_file = self._streams["fd"]
            out_file.seek(0)
            err_file.seek(0)
            stdout = out_file.read()
            stderr = err_file.read()
            return stdout + stderr, stdout, stderr
        return (
            self._streams["combined"].getvalue(),
            self._streams["stdout"].getvalue(),
            self._streams["stderr"].getvalue(),
        )
