"""Behavioral tests for the LINGORA toolkit. Packaged models are synthesised in a
temporary data directory, so no download is needed."""

import io
import json
import os
import sys

import pytest

from lingora import data
from lingora import chunk as chunk_mod
from lingora import classify as classify_mod
from lingora import metrics
from lingora import stem
from lingora import tag as tag_mod
from lingora import tokenize as tok
from lingora.cli import cli
from lingora.grammar import CFG
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.translate import bleu
from lingora.tree import Tree


@pytest.fixture
def model_dir(tmp_path, monkeypatch):
    """A data directory with a tiny Punkt model and a tiny perceptron tagger."""
    punkt = tmp_path / "tokenizers" / "punkt_tab" / "english"
    punkt.mkdir(parents=True)
    (punkt / "abbrev_types.txt").write_text("mr\ndr\n", encoding="utf-8")
    (punkt / "sent_starters.txt").write_text("the\n", encoding="utf-8")
    (punkt / "collocations.tab").write_text("", encoding="utf-8")
    (punkt / "ortho_context.tab").write_text("the\t2\nsmith\t32\n", encoding="utf-8")

    tagger = tmp_path / "taggers" / "averaged_perceptron_tagger_eng"
    tagger.mkdir(parents=True)
    (tagger / "averaged_perceptron_tagger_eng.weights.json").write_text(
        json.dumps({"bias": {"NN": 1.0}}), encoding="utf-8")
    (tagger / "averaged_perceptron_tagger_eng.tagdict.json").write_text(
        json.dumps({"the": "DT", "dog": "NN"}), encoding="utf-8")
    (tagger / "averaged_perceptron_tagger_eng.classes.json").write_text(
        json.dumps(["DT", "NN"]), encoding="utf-8")

    universal = tmp_path / "taggers" / "universal_tagset"
    universal.mkdir(parents=True)
    (universal / "en-ptb.map").write_text("DT\tDET\nNN\tNOUN\n", encoding="utf-8")

    monkeypatch.setattr(data, "path", [str(tmp_path)])
    return tmp_path


@pytest.fixture
def no_models(monkeypatch):
    monkeypatch.setattr(data, "path", [])


# --- tokenizers ----------------------------------------------------------------

def test_wordpunct_and_spans():
    text = "Hello, world! It's 3.50."
    assert tok.wordpunct_tokenize(text) == ["Hello", ",", "world", "!", "It", "'", "s", "3", ".", "50", "."]
    spans = list(tok.WordPunctTokenizer().span_tokenize(text))
    assert all(text[a:b] == t for (a, b), t in zip(spans, tok.wordpunct_tokenize(text)))


def test_empty_and_whitespace_yield_empty_lists():
    for t in (tok.WhitespaceTokenizer(), tok.TreebankWordTokenizer(), tok.TweetTokenizer()):
        assert t.tokenize("") == []
        assert t.tokenize("  \n\t ") == []
    assert tok.wordpunct_tokenize("") == []


def test_treebank_conventions():
    t = tok.TreebankWordTokenizer().tokenize
    assert t('"Hi," she said.') == ["``", "Hi", ",", "''", "she", "said", "."]
    assert t("I can't go") == ["I", "ca", "n't", "go"]
    assert t("gonna wanna") == ["gon", "na", "wan", "na"]
    assert t("it's 3,000 dollars") == ["it", "'s", "3,000", "dollars"]


def test_recommended_word_tokenizer_one_line():
    r = tok._recommended_line
    assert r("I cannot go -- really...") == ["I", "cannot", "go", "--", "really", "..."]
    assert r("a—b *x*") == ["a", "—", "b", "*", "x", "*"]


def test_whitespace_blankline_regexp_tweet():
    assert tok.WhitespaceTokenizer().tokenize(" a  b\tc\n") == ["a", "b", "c"]
    assert tok.blankline_tokenize("a\nb\n\n  \n c\n\n\n d") == ["a\nb", "c", "d"]
    assert tok.RegexpTokenizer(r"\w+").tokenize("x, y!") == ["x", "y"]
    assert tok.RegexpTokenizer(r",", gaps=True).tokenize("a,,b") == ["a", "", "b"]
    assert tok.RegexpTokenizer(r",", gaps=True, discard_empty=True).tokenize("a,,b") == ["a", "b"]
    assert tok.TweetTokenizer(preserve_case=False).tokenize("Hi :D @bob #Tag") == ["hi", ":D", "@bob", "#tag"]
    assert tok.TweetTokenizer(strip_handles=True).tokenize("hi @bob x") == ["hi", "x"]
    # an @ that continues a word is not a handle
    assert tok.TweetTokenizer(strip_handles=True).tokenize("hi@bob x") == ["hi", "@bob", "x"]
    assert tok.TweetTokenizer(reduce_len=True).tokenize("aaaab") == ["aaab"]


def test_sentence_and_word_tokenize_with_model(model_dir):
    sents = tok.sent_tokenize("Mr. Smith went home. The end!")
    assert sents == ["Mr. Smith went home.", "The end!"]
    assert tok.word_tokenize("Hello there.") == ["Hello", "there", "."]


def test_sentence_tokenizer_fails_without_model(no_models):
    with pytest.raises(LookupError):
        tok.sent_tokenize("One. Two.")
    with pytest.raises(LookupError):
        tok.word_tokenize("One. Two.")
    # preserve_line does not need the model
    assert tok.word_tokenize("One two.", preserve_line=True) == ["One", "two", "."]


# --- CLI ------------------------------------------------------------------------

def test_cli_tokenize_with_model(model_dir, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("Mr. Smith went home. The end!\nOne more.\n"))
    status = cli.main(args=["tokenize"], standalone_mode=False)
    assert status == 0
    assert capsys.readouterr().out == "Mr. Smith went home . The end !\nOne more .\n"


def test_cli_tokenize_fails_without_model(no_models, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("One line.\n"))
    with pytest.raises(SystemExit) as info:
        cli.main(args=["tokenize"], standalone_mode=True)
    assert info.value.code != 0
    assert capsys.readouterr().out == ""


# --- stemmers ------------------------------------------------------------------

def test_porter_defaults_and_extensions():
    p = stem.PorterStemmer()
    assert p.stem("caresses") == "caress"
    assert p.stem("ponies") == "poni"
    assert p.stem("ties") == "tie"
    assert p.stem("ab") == "ab"
    assert p.stem("Running") == "Run"
    assert p.stem("Running", to_lowercase=True) == "run"
    assert stem.PorterStemmer(mode="original").stem("ties") == "ti"


def test_lancaster_and_snowball():
    assert stem.LancasterStemmer().stem("maximum") == "maxim"
    assert stem.LancasterStemmer().stem("nation") == "nat"
    e = stem.SnowballStemmer("english")
    assert e.stem("generalization") == "general"
    assert e.stem("generously") == "generous"
    assert stem.SnowballStemmer("porter").stem("relational") == "relat"


def test_snowball_rejects_unknown_language():
    with pytest.raises(ValueError) as info:
        stem.SnowballStemmer("klingon")
    assert "klingon" in str(info.value)


def test_snowball_stopwords_need_list(no_models):
    with pytest.raises(LookupError):
        stem.SnowballStemmer("english", ignore_stopwords=True)


def test_regexp_stemmer_removes_matches():
    assert stem.RegexpStemmer("ing$|s$").stem("cats") == "cat"
    assert stem.RegexpStemmer("ing$").stem("cats") == "cats"


def test_wordnet_missing_raises(no_models):
    with pytest.raises(LookupError):
        stem.WordNetLemmatizer()


# --- taggers ---------------------------------------------------------------------

def test_default_unigram_regexp_backoff():
    d = tag_mod.DefaultTagger("NN")
    assert d.tag(["a", "b"]) == [("a", "NN"), ("b", "NN")]
    train = [[("the", "DT"), ("dog", "NN")], [("the", "DT"), ("dog", "VB")], [("dog", "NN")]]
    u = tag_mod.UnigramTagger(train=train)
    assert u.tag(["the", "dog", "zebra"]) == [("the", "DT"), ("dog", "NN"), ("zebra", None)]
    r = tag_mod.RegexpTagger([(r"\d+$", "CD"), (r".*", "NN")])
    assert r.tag(["3", "cat"]) == [("3", "CD"), ("cat", "NN")]
    chained = tag_mod.UnigramTagger(train=train, backoff=tag_mod.DefaultTagger("X"))
    assert chained.tag(["zebra", "the"]) == [("zebra", "X"), ("the", "DT")]
    assert tag_mod.DefaultTagger("X").tag([]) == []


def test_pos_tag_rejects_strings_and_bad_lang(model_dir):
    with pytest.raises(TypeError):
        tag_mod.pos_tag("the dog")
    with pytest.raises(ValueError):
        tag_mod.pos_tag(["the"], lang="fra")


def test_pos_tag_missing_resource(no_models):
    with pytest.raises(LookupError):
        tag_mod.pos_tag(["the", "dog"])


def test_pos_tag_uses_tagdict_and_universal(model_dir):
    assert tag_mod.pos_tag(["the", "dog"]) == [("the", "DT"), ("dog", "NN")]
    assert tag_mod.pos_tag(["the", "dog"], tagset="universal") == [("the", "DET"), ("dog", "NOUN")]


# --- chunking ----------------------------------------------------------------------

TAGGED = [("the", "DT"), ("big", "JJ"), ("dog", "NN"), ("ran", "VBD"), ("home", "NN")]


def test_chunk_rule_and_root():
    parser = chunk_mod.RegexpParser("NP: {<DT>?<JJ>*<NN>}")
    t = parser.parse(TAGGED)
    assert t.label() != "NP"
    assert [c.label() for c in t if isinstance(c, Tree)] == ["NP", "NP"]
    assert t.leaves() == TAGGED


def test_chunk_chink_splits_chunk():
    grammar = "NP: {<.*>+}\n  }<VBD>{"
    t = chunk_mod.RegexpParser(grammar).parse(TAGGED)
    labels = [c.label() if isinstance(c, Tree) else c[0] for c in t]
    assert labels == ["NP", "ran", "NP"]


def test_chunk_cascade_sees_earlier_chunk_as_unit():
    grammar = "NP: {<DT><JJ>*<NN>}\nVP: {<NP><VBD><NP>}"
    tagged = [("the", "DT"), ("dog", "NN"), ("ran", "VBD"), ("the", "DT"), ("home", "NN")]
    t = chunk_mod.RegexpParser(grammar).parse(tagged)
    assert [c.label() for c in t] == ["VP"]
    assert t.leaves()[0] == ("the", "DT")


def test_chunk_refuses_bad_grammar_type():
    with pytest.raises(TypeError):
        chunk_mod.RegexpParser(42)


def test_chunk_empty_input():
    t = chunk_mod.RegexpParser("NP: {<DT>}").parse([])
    assert len(t) == 0


# --- grammars, parsing, trees -----------------------------------------------------

GRAMMAR = """
S -> NP VP
NP -> 'the' N | 'a' N | NP PP
N -> 'dog' | 'cat'
VP -> V NP | V
V -> 'sees' | 'runs'
PP -> 'with' NP
"""


def test_grammar_reader_and_productions():
    g = CFG.fromstring(GRAMMAR)
    assert str(g.start()) == "S"
    assert len(g.productions()) == 11
    empty = CFG.fromstring("A -> |'x'")
    assert [list(p.rhs()) for p in empty.productions()] == [[], ["x"]]
    quoted = CFG.fromstring("A -> '' 'b'")
    assert list(quoted.productions()[0].rhs()) == ["", "b"]
    assert not isinstance(g.productions()[0].rhs()[0], str)


def test_chart_parser_ambiguous_and_empty():
    g = CFG.fromstring(GRAMMAR)
    trees = list(ChartParser(g).parse("the dog sees a cat with the dog".split()))
    assert len(trees) == 1
    assert trees[0].label() == "S"
    assert trees[0].leaves() == "the dog sees a cat with the dog".split()
    assert list(ChartParser(g).parse(["the", "dog", "runs"])) != []
    assert list(ChartParser(g).parse(["dog"])) == []


def test_parser_refuses_unknown_token():
    g = CFG.fromstring(GRAMMAR)
    with pytest.raises(ValueError):
        list(ChartParser(g).parse(["the", "zebra"]))
    with pytest.raises(ValueError):
        list(ShiftReduceParser(g).parse(["the", "zebra"]))


def test_shift_reduce_matches_chart_on_simple_sentence():
    g = CFG.fromstring(GRAMMAR)
    sr = list(ShiftReduceParser(g).parse(["the", "dog", "runs"]))
    ch = list(ChartParser(g).parse(["the", "dog", "runs"]))
    assert sr == ch


def test_generator_bounds():
    g = CFG.fromstring(GRAMMAR)
    sentences = list(generate(g, depth=5, n=3))
    assert len(sentences) == 3
    assert all(isinstance(t, str) for s in sentences for t in s)
    empty = CFG.fromstring("S -> '' | A\nA -> 'x'")
    assert ["x"] in list(generate(empty, depth=3))


def test_tree_construction_and_equality():
    t = Tree.fromstring("(S (NP (DT the) (NN dog)) (VP (VBZ barks)))")
    assert t.label() == "S" and len(t) == 2 and t[0].label() == "NP"
    assert t.leaves() == ["the", "dog", "barks"]
    assert t == Tree("S", [Tree("NP", [Tree("DT", ["the"]), Tree("NN", ["dog"])]),
                           Tree("VP", [Tree("VBZ", ["barks"])])])
    assert Tree("X", []) != Tree("X", ["a"])
    assert len(Tree("X", [])) == 0
    with pytest.raises(TypeError):
        Tree("S", "x")
    with pytest.raises(TypeError):
        Tree("S")
    assert t.pformat().startswith("(S ")


# --- classifiers and metrics ---------------------------------------------------------

def test_naive_bayes_and_tree():
    nb = classify_mod.NaiveBayesClassifier.train([
        ({"a": True, "b": 1}, "x"), ({"a": False, "b": 2}, "y"), ({"a": True, "b": 3}, "x")])
    assert nb.classify({"a": True}) == "x"
    assert set(nb.labels()) == {"x", "y"}
    dist = nb.prob_classify({"a": False})
    assert abs(sum(dist.prob(s) for s in dist.samples()) - 1.0) < 1e-9
    assert nb.classify({"never": 1}) in {"x", "y"}
    dt = classify_mod.DecisionTreeClassifier.train([
        ({"f": "a"}, "x"), ({"f": "b"}, "y"), ({"f": "a", "g": 1}, "x")])
    assert dt.classify({"f": "b"}) == "y"
    assert dt.classify({"zzz": 1}) in {"x", "y"}
    assert classify_mod.accuracy(dt, [({"f": "b"}, "y"), ({"f": "a"}, "x")]) == 1.0


def test_metrics():
    assert metrics.edit_distance("kitten", "sitting") == 3
    assert metrics.edit_distance("ab", "ba", transpositions=True) == 1
    assert metrics.edit_distance("ab", "ba") == 2
    assert metrics.edit_distance("", "") == 0
    assert metrics.accuracy([1, 2, 3], [1, 0, 3]) == pytest.approx(2 / 3)
    with pytest.raises(ValueError):
        metrics.accuracy([1], [1, 2])
    assert metrics.jaccard_distance({1, 2, 3}, {2, 3, 4}) == 0.5
    assert metrics.precision({1, 2}, {2, 3}) == 0.5
    assert metrics.recall({1, 2}, {2, 3}) == 0.5
    assert metrics.f_measure({1, 2}, {3}) is None
    assert metrics.precision({1}, set()) is None
    with pytest.raises(TypeError):
        metrics.precision([1], {1})


def test_bleu():
    ref = [["the", "cat", "is", "on", "the", "mat"]]
    assert bleu(ref, ref[0]) == pytest.approx(1.0)
    assert bleu(ref, ["zebra", "zebra"]) == 0.0
    assert 0 < bleu(ref, ["the", "cat", "sat", "on", "mat"]) < 1
