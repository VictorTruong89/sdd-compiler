# Root conftest: its presence makes pytest put the project root on sys.path,
# so `import lingora` works from the source tree without installation.
