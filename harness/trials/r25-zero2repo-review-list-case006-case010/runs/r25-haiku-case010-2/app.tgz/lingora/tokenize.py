"""Tokenizers: word/punctuation, Penn Treebank, recommended word and sentence
tokenizers, whitespace, blank-line, regular-expression and tweet tokenizers."""

import re

from . import _punkt

__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]


def _check_text(text, name="text"):
    if not isinstance(text, str):
        raise TypeError("%s must be str, not %s" % (name, type(text).__name__))


# --- word/punctuation -------------------------------------------------------

_WORDPUNCT = re.compile(r"\w+|[^\w\s]+")


class WordPunctTokenizer(object):
    """Maximal runs of word characters, and maximal runs of characters that are
    neither word characters nor whitespace."""

    def tokenize(self, text):
        _check_text(text)
        return _WORDPUNCT.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        for match in _WORDPUNCT.finditer(text):
            yield match.span()


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


# --- Penn Treebank -----------------------------------------------------------

_STARTING_QUOTES = [
    (re.compile(r'^"'), "``"),
    (re.compile(r"(``)"), r" \1 "),
    (re.compile(r'([ \(\[{<])(")'), r"\1 `` "),
    (re.compile(r"([ \(\[{<])(\'{2})"), r"\1 `` "),
]

_PUNCTUATION = [
    (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
    (re.compile(r"([:,])([^\d])"), r" \1 \2"),
    (re.compile(r"([:,])$"), r" \1 "),
    (re.compile(r"\.\.\."), r" ... "),
    (re.compile(r"[;@#$%&]"), r" \g<0> "),
    (re.compile(r"[?!]"), r" \g<0> "),
    (re.compile(r"([^'])' "), r"\1 ' "),
    (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> "),
    (re.compile(r"--"), r" -- "),
]

_ENDING_QUOTES = [
    (re.compile(r"([^' ])(?i:('ll|'re|'ve|n't)) "), r"\1 \2 "),
    (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
    (re.compile(r'"'), " '' "),
]

_CONTRACTIONS_CANNOT = (re.compile(r"(?i)\b(can)(not)\b"), r" \1 \2 ")
_CONTRACTIONS2 = [
    (re.compile(r"(?i)\b(d)('ye)\b"), r" \1 \2 "),
    (re.compile(r"(?i)\b(gim)(me)\b"), r" \1 \2 "),
    (re.compile(r"(?i)\b(gon)(na)\b"), r" \1 \2 "),
    (re.compile(r"(?i)\b(got)(ta)\b"), r" \1 \2 "),
    (re.compile(r"(?i)\b(lem)(me)\b"), r" \1 \2 "),
    (re.compile(r"(?i)\b(more)('n)\b"), r" \1 \2 "),
    (re.compile(r"(?i)\b(wan)(na)\s"), r" \1 \2 "),
]
_CONTRACTIONS3 = [
    (re.compile(r"(?i) ('t)(is)\b"), r" \1 \2 "),
    (re.compile(r"(?i) ('t)(was)\b"), r" \1 \2 "),
]

_TYPOGRAPHIC_QUOTES = re.compile("([“”„‟«»‘‚‛‹›])")
_DASHES_AND_STARS = re.compile("([\u2012-\u2015*])")
_RUN_OF_POINTS = re.compile(r"\.{2,}")
_QUOTE_PLACEHOLDER = "\x01"


def _treebank(text, improved):
    if improved and text[:1] == '"':
        # A straight double quote at the very start of the text is a closing quote.
        text = " " + _QUOTE_PLACEHOLDER + " " + text[1:]
    text = " " + text + " "
    if improved:
        text = _TYPOGRAPHIC_QUOTES.sub(r" \1 ", text)
        text = _DASHES_AND_STARS.sub(r" \1 ", text)
        text = _RUN_OF_POINTS.sub(r" \g<0> ", text)
    for regexp, substitution in _STARTING_QUOTES:
        text = regexp.sub(substitution, text)
    for regexp, substitution in _PUNCTUATION:
        text = regexp.sub(substitution, text)
    for regexp, substitution in _ENDING_QUOTES:
        text = regexp.sub(substitution, text)
    contractions = list(_CONTRACTIONS2)
    if not improved:
        contractions.insert(0, _CONTRACTIONS_CANNOT)
    for regexp, substitution in contractions + _CONTRACTIONS3:
        text = regexp.sub(substitution, text)
    tokens = text.split()
    if improved:
        tokens = [("''" if tok == _QUOTE_PLACEHOLDER else tok) for tok in tokens]
    return tokens


class TreebankWordTokenizer(object):
    """Penn Treebank word tokenizer (FP-01)."""

    def tokenize(self, text):
        _check_text(text)
        return _treebank(text, improved=False)


def _recommended_line(line):
    return _treebank(line, improved=True)


# --- recommended word and sentence tokenizers --------------------------------

def sent_tokenize(text, language="english"):
    """Split ``text`` into sentences with the packaged Punkt models for
    ``language``. Raises LookupError when those models are not visible."""
    _check_text(text)
    return _punkt.split_sentences(text, language)


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer (an improved Penn Treebank
    tokenizer). Unless ``preserve_line`` is true, the text is first split into
    sentences with the Punkt models for ``language``."""
    _check_text(text)
    if preserve_line:
        sentences = [text]
    else:
        sentences = sent_tokenize(text, language)
    tokens = []
    for sentence in sentences:
        tokens.extend(_recommended_line(sentence))
    return tokens


# --- whitespace, blank-line, regular-expression -----------------------------

class WhitespaceTokenizer(object):
    _pattern = re.compile(r"\S+")

    def tokenize(self, text):
        _check_text(text)
        return self._pattern.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        for match in self._pattern.finditer(text):
            yield match.span()


_BLANK_SEPARATOR = re.compile(r"\s*\n[^\S\n]*\n\s*")


def blankline_tokenize(text):
    """Segments of ``text`` separated by blank lines, with empty pieces dropped."""
    _check_text(text)
    pieces = []
    for piece in _BLANK_SEPARATOR.split(text):
        piece = piece.strip()
        if piece:
            pieces.append(piece)
    return pieces


class RegexpTokenizer(object):
    """Tokens are the matches of ``pattern`` (token mode), or the pieces between
    matches (gap mode). Empty pieces are dropped only when ``discard_empty``."""

    def __init__(self, pattern, gaps=False, discard_empty=False, flags=0):
        self._regexp = re.compile(pattern, flags) if isinstance(pattern, str) else pattern
        self._gaps = bool(gaps)
        self._discard_empty = bool(discard_empty)

    def _spans(self, text):
        if not self._gaps:
            for match in self._regexp.finditer(text):
                yield match.span()
            return
        position = 0
        for match in self._regexp.finditer(text):
            yield (position, match.start())
            position = match.end()
        yield (position, len(text))

    def tokenize(self, text):
        _check_text(text)
        tokens = []
        for start, end in self._spans(text):
            piece = text[start:end]
            if self._discard_empty and piece == "":
                continue
            tokens.append(piece)
        return tokens

    def span_tokenize(self, text):
        _check_text(text)
        for start, end in self._spans(text):
            if self._discard_empty and start == end:
                continue
            yield (start, end)


# --- tweet tokenizer ----------------------------------------------------------

_TWEET_TOKEN = re.compile(
    r"""
      (?P<emoticon>(?:[:;=8][\-o\*']?[\)\]\(\[dDpP/\\OoPs3]|<3|\^_\^|:'\())
    | (?P<url>(?:https?://|www\.)\S+)
    | (?P<hashtag_handle>[\#@]\w+)
    | (?P<number>\d+(?:[.,]\d+)+)
    | (?P<word>\w+(?:['’]\w+)*)
    | (?P<dots>\.{2,})
    | (?P<other>\S)
    """,
    re.VERBOSE,
)
_HANDLE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}")
_REPEATED = re.compile(r"(.)\1{3,}", re.DOTALL)


class TweetTokenizer(object):
    """Tweet-style tokenizer. Emoticons, URLs, hashtags and @-handles are single
    tokens; contractions with an internal apostrophe stay whole."""

    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self._preserve_case = bool(preserve_case)
        self._reduce_len = bool(reduce_len)
        self._strip_handles = bool(strip_handles)

    def tokenize(self, text):
        _check_text(text)
        if self._strip_handles:
            text = _HANDLE.sub(" ", text)
        if self._reduce_len:
            text = _REPEATED.sub(r"\1\1\1", text)
        tokens = []
        for match in _TWEET_TOKEN.finditer(text):
            token = match.group(0)
            if match.lastgroup == "emoticon" or self._preserve_case:
                tokens.append(token)
            else:
                tokens.append(token.lower())
        return tokens
