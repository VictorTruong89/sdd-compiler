"""Command line: ``lingora tokenize`` applies the recommended word tokenizer, with
sentence splitting, to each line of standard input."""

import sys

from . import _punkt
from .tokenize import word_tokenize

__all__ = ["cli"]

USAGE = "usage: lingora tokenize [--language LANG] [--delimiter DELIM] [--encoding ENC]"


class _Group(object):
    """Minimal command group with a ``main`` entry point (no third-party deps)."""

    def __init__(self):
        self._commands = {"tokenize": _tokenize_command}

    def main(self, args=None, standalone_mode=True):
        argv = list(sys.argv[1:]) if args is None else list(args)
        status = self._run(argv)
        if standalone_mode:
            sys.exit(status)
        return status

    def _run(self, argv):
        if not argv or argv[0] not in self._commands:
            sys.stderr.write(USAGE + "\n")
            return 2
        return self._commands[argv[0]](argv[1:])


def _parse_options(argv):
    options = {"language": "english", "delimiter": " ", "encoding": "utf-8"}
    names = {"--language": "language", "-l": "language",
             "--delimiter": "delimiter", "-d": "delimiter",
             "--encoding": "encoding"}
    i = 0
    while i < len(argv):
        arg = argv[i]
        key, sep, value = arg.partition("=")
        if key in names:
            if not sep:
                if i + 1 >= len(argv):
                    raise ValueError("option %s needs a value" % key)
                value = argv[i + 1]
                i += 1
            options[names[key]] = value
        else:
            raise ValueError("unknown option %r" % arg)
        i += 1
    return options


def _read_input(encoding):
    buffer = getattr(sys.stdin, "buffer", None)
    if buffer is not None:
        return buffer.read().decode(encoding)
    return sys.stdin.read()


def _tokenize_command(argv):
    try:
        options = _parse_options(argv)
    except ValueError as exc:
        sys.stderr.write("lingora tokenize: %s\n%s\n" % (exc, USAGE))
        return 2
    language = options["language"]
    try:
        _punkt.load_parameters(language)
    except LookupError as exc:
        sys.stderr.write("lingora tokenize: Punkt models for %r are not installed: %s\n"
                         % (language, exc))
        return 1
    try:
        text = _read_input(options["encoding"])
    except (UnicodeDecodeError, LookupError, OSError) as exc:
        sys.stderr.write("lingora tokenize: cannot read input: %s\n" % exc)
        return 1
    out = sys.stdout
    for line in text.splitlines():
        try:
            tokens = word_tokenize(line, language=language)
        except Exception as exc:  # any failure ends the run with no token line
            sys.stderr.write("lingora tokenize: %s\n" % exc)
            return 1
        out.write(options["delimiter"].join(tokens) + "\n")
    out.flush()
    return 0


cli = _Group()
