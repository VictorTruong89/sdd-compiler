"""LINGORA Language Toolkit: a pure-Python NLP library.

Importing the package downloads nothing; packaged resources are located through
``lingora.data.path``."""

from . import data
from . import tokenize
from . import stem
from . import tag
from . import chunk
from . import grammar
from . import tree
from . import parse
from . import classify
from . import metrics
from . import translate
from . import cli as _cli_module

cli = _cli_module.cli

__all__ = [
    "chunk", "classify", "cli", "data", "grammar", "metrics", "parse", "stem",
    "tag", "tokenize", "translate", "tree",
]
__version__ = "0.1.0"
