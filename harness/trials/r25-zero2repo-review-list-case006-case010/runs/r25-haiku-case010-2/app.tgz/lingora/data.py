"""Packaged-resource finder.

``path`` is a mutable list of directories searched for packaged resources.
Callers may replace its contents in place. The initial contents come from the
``LINGORA_DATA`` environment variable (os.pathsep separated); it is empty when
the variable is unset, so no packaged resource is visible by default.
"""

import os

path = [p for p in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if p]


def find(resource):
    """Return the absolute location of ``resource`` (a relative name such as
    ``tokenizers/punkt_tab/english``) in the first directory of ``path`` that
    holds it. Raises ``LookupError`` when no listed directory holds it."""
    for directory in list(path):
        candidate = os.path.join(directory, *resource.split("/"))
        if os.path.exists(candidate):
            return candidate
    raise LookupError(
        "packaged resource %r not found in data path %r" % (resource, list(path))
    )


def read_lines(resource_file):
    """Read a UTF-8 text file and return its lines without terminators."""
    with open(resource_file, encoding="utf-8") as handle:
        return handle.read().splitlines()
