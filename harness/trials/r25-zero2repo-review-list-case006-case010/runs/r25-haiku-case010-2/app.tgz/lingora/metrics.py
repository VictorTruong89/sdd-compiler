"""Evaluation metrics: edit distance, Jaccard distance, accuracy, precision,
recall and f-measure."""

__all__ = [
    "accuracy",
    "edit_distance",
    "f_measure",
    "jaccard_distance",
    "precision",
    "recall",
]


def accuracy(reference, test):
    """Fraction of positions at which two equal-length lists hold equal values.
    Lists of different lengths are refused."""
    reference = list(reference)
    test = list(test)
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length (%d != %d)"
                         % (len(reference), len(test)))
    if not reference:
        raise ValueError("accuracy needs at least one position")
    matches = sum(1 for a, b in zip(reference, test) if a == b)
    return matches / float(len(reference))


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance. With ``transpositions=True`` two adjacent characters
    may be swapped at cost 1 (restricted Damerau-Levenshtein: nothing may be
    inserted or deleted between the two transposed characters)."""
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance takes two str arguments")
    n, m = len(s1), len(s2)
    d = [[0] * (m + 1) for _ in range(n + 1)]
    for i in range(n + 1):
        d[i][0] = i
    for j in range(m + 1):
        d[0][j] = j
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            cost = 0 if s1[i - 1] == s2[j - 1] else substitution_cost
            best = min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
            if transpositions and i > 1 and j > 1 and s1[i - 1] == s2[j - 2] \
                    and s1[i - 2] == s2[j - 1]:
                best = min(best, d[i - 2][j - 2] + 1)
            d[i][j] = best
    return d[n][m]


def jaccard_distance(label1, label2):
    """Size of the symmetric difference divided by the size of the union."""
    a = set(label1)
    b = set(label2)
    union = a | b
    if not union:
        return 0.0
    return len(a ^ b) / float(len(union))


def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("precision, recall and f_measure take sets")


def precision(reference, test):
    """|reference & test| / |test|; None when ``test`` is empty."""
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / float(len(test))


def recall(reference, test):
    """|reference & test| / |reference|; None when ``reference`` is empty."""
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / float(len(reference))


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean of precision and recall. None when either set is
    empty or the two sets share no element."""
    _check_sets(reference, test)
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if not (reference & test):
        return None
    return 1.0 / (alpha / p + (1 - alpha) / r)
