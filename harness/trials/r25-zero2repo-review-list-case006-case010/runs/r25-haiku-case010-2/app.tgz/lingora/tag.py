"""Part-of-speech taggers: sequential taggers (default, unigram, n-gram, affix,
regular-expression) with backoff, and LINGORA's recommended averaged perceptron
tagger for English and Russian (``pos_tag``)."""

import json
import os
import re
from collections import Counter, defaultdict

from . import data

__all__ = [
    "AffixTagger",
    "BigramTagger",
    "DefaultTagger",
    "RegexpTagger",
    "TrigramTagger",
    "UnigramTagger",
    "pos_tag",
]


def _check_tokens(tokens):
    if isinstance(tokens, (str, bytes)):
        raise TypeError("tokens must be a list of str, not a string")
    tokens = list(tokens)
    for token in tokens:
        if not isinstance(token, str):
            raise TypeError("every token must be str, not %s" % type(token).__name__)
    return tokens


class _SequentialTagger(object):
    """Base class: ``_choose`` assigns a tag (or None) to one token; a backoff
    tagger is consulted only for the tokens left without a tag."""

    def __init__(self, backoff=None):
        if backoff is not None and not isinstance(backoff, _SequentialTagger):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def _choose_all(self, tokens):
        return [self._choose(token) for token in tokens]

    def _choose(self, token):  # pragma: no cover - overridden
        raise NotImplementedError

    def tag(self, tokens):
        tokens = _check_tokens(tokens)
        tags = self._choose_all(tokens)
        if self._backoff is not None:
            missing = [i for i, t in enumerate(tags) if t is None]
            if missing:
                sub = self._backoff.tag([tokens[i] for i in missing])
                for i, (_, t) in zip(missing, sub):
                    tags[i] = t
        return list(zip(tokens, tags))


class DefaultTagger(_SequentialTagger):
    """Assigns one configured tag to every token."""

    def __init__(self, tag):
        super(DefaultTagger, self).__init__(None)
        self._tag = tag

    def _choose(self, token):
        return self._tag


class UnigramTagger(_SequentialTagger):
    """Each word receives the tag it most often had in training; unseen words
    receive no tag (or the backoff tagger's tag)."""

    def __init__(self, train=None, model=None, backoff=None):
        super(UnigramTagger, self).__init__(backoff)
        counts = defaultdict(Counter)
        for sentence in train or []:
            for word, tag in sentence:
                if tag is not None:
                    counts[word][tag] += 1
        self._model = dict(model) if model else {}
        for word, counter in counts.items():
            self._model[word] = counter.most_common(1)[0][0]

    def _choose(self, token):
        return self._model.get(token)


class RegexpTagger(_SequentialTagger):
    """Rules are tried in order; the first whose pattern matches the token from
    its first character gives the tag."""

    def __init__(self, regexps, backoff=None):
        super(RegexpTagger, self).__init__(backoff)
        self._rules = []
        for pattern, tag in regexps:
            self._rules.append((re.compile(pattern), tag))

    def _choose(self, token):
        for regexp, tag in self._rules:
            if regexp.match(token):
                return tag
        return None


class NgramTagger(_SequentialTagger):
    """Tags a token from its word and the previously assigned tags (n-1 of them)."""

    def __init__(self, n, train=None, model=None, backoff=None):
        super(NgramTagger, self).__init__(backoff)
        if n < 1:
            raise ValueError("n must be at least 1")
        self._n = n
        counts = defaultdict(Counter)
        for sentence in train or []:
            history = ("<START>",) * (n - 1)
            for word, tag in sentence:
                if tag is not None:
                    counts[(history, word)][tag] += 1
                history = (history + (tag,))[1:] if n > 1 else history
        self._model = dict(model) if model else {}
        for key, counter in counts.items():
            self._model[key] = counter.most_common(1)[0][0]

    def tag(self, tokens):
        tokens = _check_tokens(tokens)
        history = ("<START>",) * (self._n - 1)
        result = []
        for word in tokens:
            tag = self._model.get((history, word))
            if tag is None and self._backoff is not None:
                tag = self._backoff.tag([word])[0][1]
            result.append((word, tag))
            if self._n > 1:
                history = (history + (tag,))[1:]
        return result


class BigramTagger(NgramTagger):
    def __init__(self, train=None, model=None, backoff=None):
        super(BigramTagger, self).__init__(2, train, model, backoff)


class TrigramTagger(NgramTagger):
    def __init__(self, train=None, model=None, backoff=None):
        super(TrigramTagger, self).__init__(3, train, model, backoff)


class AffixTagger(_SequentialTagger):
    """Tags a word by its prefix or suffix of ``affix_length`` characters."""

    def __init__(self, train=None, model=None, affix_length=-3, min_stem_length=2, backoff=None):
        super(AffixTagger, self).__init__(backoff)
        self._affix_length = affix_length
        self._min_stem_length = min_stem_length
        counts = defaultdict(Counter)
        for sentence in train or []:
            for word, tag in sentence:
                if tag is not None and len(word) >= min_stem_length:
                    counts[self._affix(word)][tag] += 1
        self._model = dict(model) if model else {}
        for affix, counter in counts.items():
            self._model[affix] = counter.most_common(1)[0][0]

    def _affix(self, word):
        if self._affix_length > 0:
            return word[:self._affix_length]
        return word[self._affix_length:]

    def _choose(self, token):
        if len(token) < self._min_stem_length:
            return None
        return self._model.get(self._affix(token))


# --- averaged perceptron (recommended tagger) -----------------------------------

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]

# Russian National Corpus part-of-speech categories -> universal tagset.
_RNC_TO_UNIVERSAL = {
    "A": "ADJ", "ANUM": "ADJ", "ADV": "ADV", "ADVPRO": "ADV", "APRO": "DET",
    "COM": "ADJ", "CONJ": "CONJ", "INTJ": "X", "NUM": "NUM", "PART": "PRT",
    "PR": "ADP", "S": "NOUN", "SPRO": "PRON", "V": "VERB", "PNCT": ".",
}


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


class _Perceptron(object):
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        if not self.classes:
            return None
        return max(self.classes, key=lambda label: scores.get(label, 0.0))

    def tag(self, tokens):
        prev, prev2 = _START
        context = _START + [_normalize(w) for w in tokens] + _END
        output = []
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                features = _features(i, word, context, prev, prev2)
                tag = self.predict(features)
            output.append((word, tag))
            prev2, prev = prev, tag
        return output


def _features(i, word, context, prev, prev2):
    features = defaultdict(int)

    def add(name, *args):
        features[" ".join((name,) + tuple(args))] += 1

    i += len(_START)
    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[0] if word else "")
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return features


_PERCEPTRON_CACHE = {}


def _load_perceptron(lang):
    resource = "taggers/averaged_perceptron_tagger_" + lang
    directory = data.find(resource)
    if directory in _PERCEPTRON_CACHE:
        return _PERCEPTRON_CACHE[directory]
    base = os.path.join(directory, "averaged_perceptron_tagger_" + lang)
    try:
        with open(base + ".weights.json", encoding="utf-8") as handle:
            weights = json.load(handle)
        with open(base + ".tagdict.json", encoding="utf-8") as handle:
            tagdict = json.load(handle)
        with open(base + ".classes.json", encoding="utf-8") as handle:
            classes = json.load(handle)
    except OSError as exc:
        raise LookupError("averaged perceptron tagger for %r incomplete: %s" % (lang, exc))
    model = _Perceptron(weights, tagdict, classes)
    _PERCEPTRON_CACHE[directory] = model
    return model


_UNIVERSAL_EN_CACHE = {}


def _load_english_universal_map():
    directory = data.find("taggers/universal_tagset")
    if directory in _UNIVERSAL_EN_CACHE:
        return _UNIVERSAL_EN_CACHE[directory]
    mapping = {}
    for line in data.read_lines(os.path.join(directory, "en-ptb.map")):
        parts = line.split("\t")
        if len(parts) == 2:
            mapping[parts[0]] = parts[1]
    _UNIVERSAL_EN_CACHE[directory] = mapping
    return mapping


def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag a token list with LINGORA's recommended averaged perceptron tagger.

    ``lang`` is ``'eng'`` (Penn Treebank tags) or ``'rus'`` (Russian National
    Corpus tags). ``tagset`` is ``None`` (native tags) or ``'universal'``."""
    tokens = _check_tokens(tokens)
    if lang not in ("eng", "rus"):
        raise ValueError("unsupported language %r for pos_tag; use 'eng' or 'rus'" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset %r" % (tagset,))
    if not tokens:
        _load_perceptron(lang)
        return []
    model = _load_perceptron(lang)
    tagged = model.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            mapping = _load_english_universal_map()
            tagged = [(w, mapping.get(t, "X") if t is not None else None) for w, t in tagged]
        else:
            tagged = [(w, _map_rnc(t)) for w, t in tagged]
    return tagged


def _map_rnc(tag):
    if tag is None:
        return None
    category = tag.split("=", 1)[0]
    return _RNC_TO_UNIVERSAL.get(category, "X")
