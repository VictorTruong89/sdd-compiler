"""Stemmers: Porter (with LINGORA extensions), Lancaster (Paice/Husk), Snowball
(English Porter2 and original Porter), regular-expression stemmer, and the
WordNet lemmatizer."""

import os
import re

from . import data

__all__ = [
    "ARLSTem",
    "ARLSTem2",
    "LancasterStemmer",
    "PorterStemmer",
    "RegexpStemmer",
    "SnowballStemmer",
    "WordNetLemmatizer",
]

_VOWELS = "aeiou"


def _check_word(word):
    if not isinstance(word, str):
        raise TypeError("word must be str, not %s" % type(word).__name__)


def _restore_case(original, result):
    """Keep the letter case of ``original`` on positions the stem still shares
    with it (used when lowercasing is off)."""
    lowered = original.lower()
    chars = []
    for index, ch in enumerate(result):
        if index < len(original) and index < len(lowered) and ch == lowered[index]:
            chars.append(original[index])
        else:
            chars.append(ch)
    return "".join(chars)


# --- Porter -------------------------------------------------------------------

_PORTER_IRREGULAR = {
    "skies": "sky",
    "dying": "die",
    "lying": "lie",
    "tying": "tie",
    "innings": "inning",
    "outings": "outing",
    "cannings": "canning",
}

_STEP2_ORIGINAL = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_STEP2_LINGORA = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("bli", "ble"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"), ("fulli", "ful"),
]
_STEP3 = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""),
]
_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
    "ent", "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]


def _is_cons(word, index):
    ch = word[index]
    if ch in _VOWELS:
        return False
    if ch == "y":
        return index == 0 or not _is_cons(word, index - 1)
    return True


def _measure(stem):
    n = len(stem)
    i = 0
    while i < n and _is_cons(stem, i):
        i += 1
    m = 0
    while i < n:
        while i < n and not _is_cons(stem, i):
            i += 1
        if i >= n:
            break
        m += 1
        while i < n and _is_cons(stem, i):
            i += 1
    return m


def _has_vowel(stem):
    return any(not _is_cons(stem, i) for i in range(len(stem)))


def _ends_double_cons(word):
    return len(word) >= 2 and word[-1] == word[-2] and _is_cons(word, len(word) - 1)


def _ends_cvc(word, lingora):
    n = len(word)
    if n >= 3:
        return (_is_cons(word, n - 3) and not _is_cons(word, n - 2)
                and _is_cons(word, n - 1) and word[-1] not in "wxy")
    if lingora and n == 2:
        return (not _is_cons(word, 0) and _is_cons(word, 1)
                and word[1] not in "wxy")
    return False


def _longest_suffix(word, table):
    best = None
    for suffix, replacement in table:
        if word.endswith(suffix) and (best is None or len(suffix) > len(best[0])):
            best = (suffix, replacement)
    return best


def _porter_stem(word, lingora):
    if lingora and word in _PORTER_IRREGULAR:
        return _PORTER_IRREGULAR[word]
    if len(word) <= 2:
        return word
    w = word

    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith("ies"):
        if lingora and len(w) == 4:
            w = w[:-1]
        else:
            w = w[:-2]
    elif w.endswith("ss"):
        pass
    elif w.endswith("s"):
        w = w[:-1]

    # Step 1b
    if lingora and w.endswith("ied"):
        w = w[:-1] if len(w) == 4 else w[:-2]
    else:
        step1b_done = False
        if w.endswith("eed"):
            if _measure(w[:-3]) > 0:
                w = w[:-1]
            step1b_done = True
        elif w.endswith("ed") and _has_vowel(w[:-2]):
            w = w[:-2]
        elif w.endswith("ing") and _has_vowel(w[:-3]):
            w = w[:-3]
        else:
            step1b_done = True
        if not step1b_done:
            if w.endswith(("at", "bl", "iz")):
                w = w + "e"
            elif _ends_double_cons(w) and w[-1] not in "lsz":
                w = w[:-1]
            elif _measure(w) == 1 and _ends_cvc(w, lingora):
                w = w + "e"

    # Step 1c
    if lingora:
        if w.endswith("y") and len(w) >= 3 and _is_cons(w, len(w) - 2):
            w = w[:-1] + "i"
    elif w.endswith("y") and _has_vowel(w[:-1]):
        w = w[:-1] + "i"

    # Step 2
    if lingora:
        if w.endswith("alli") and _measure(w[:-4]) > 0:
            w = w[:-2]
            w = _porter_step2(w, _STEP2_LINGORA, lingora)
        else:
            w = _porter_step2(w, _STEP2_LINGORA, lingora)
        if w.endswith("logi") and _measure(w[:-3]) > 0:
            w = w[:-1]
    else:
        w = _porter_step2(w, _STEP2_ORIGINAL, lingora)

    # Step 3
    best = _longest_suffix(w, _STEP3)
    if best and _measure(w[:-len(best[0])]) > 0:
        w = w[:-len(best[0])] + best[1]

    # Step 4
    suffix = None
    for candidate in _STEP4:
        if w.endswith(candidate) and (suffix is None or len(candidate) > len(suffix)):
            suffix = candidate
    if suffix is not None:
        stem = w[:-len(suffix)]
        if _measure(stem) > 1 and (suffix != "ion" or stem[-1:] in ("s", "t")):
            w = stem

    # Step 5
    if w.endswith("e"):
        stem = w[:-1]
        if _measure(stem) > 1 or (_measure(stem) == 1 and not _ends_cvc(stem, lingora)):
            w = stem
    if w.endswith("l") and _measure(w) > 1 and _ends_double_cons(w):
        w = w[:-1]
    return w


def _porter_step2(w, table, lingora):
    best = _longest_suffix(w, table)
    if best and _measure(w[:-len(best[0])]) > 0:
        return w[:-len(best[0])] + best[1]
    return w


class PorterStemmer(object):
    """Porter stemmer. ``mode`` is ``"lingora"`` (default, with the LINGORA
    extensions) or ``"original"`` (Porter's 1980 algorithm)."""

    MODES = ("lingora", "original")

    def __init__(self, mode="lingora"):
        if mode not in self.MODES:
            raise ValueError("unsupported Porter mode %r" % (mode,))
        self._lingora = mode == "lingora"

    def stem(self, word, to_lowercase=False):
        _check_word(word)
        result = _porter_stem(word.lower(), self._lingora)
        if to_lowercase:
            return result
        return _restore_case(word, result)


# --- Lancaster (Paice/Husk) ----------------------------------------------------

_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>",
    "deec2ss.", "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>",
    "gai3y.", "ga2>", "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>",
    "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.", "jn1d.",
    "j1s.", "lbaifi6.", "lbai4y.", "lba3.", "lbi3.", "lib2l>", "lc1.", "lufi4y.",
    "lu2.", "lai3y>", "lau3.", "la2.", "ll1.", "mui3.", "mu*2.", "msi3.", "mm1.",
    "nois4j>", "noix4ct.", "noi3>", "nai3>", "na2>", "nee0.", "ne2>", "nn1.",
    "pihs4>", "pp1.", "re2>", "rae0.", "ra2.", "ro2q>", "ru2>", "rr1.", "rt1>",
    "rei3y>", "sei3y>", "sis2.", "si2>", "ssen4>", "ss0.", "suo3>", "su*2.",
    "s*1>", "s0>", "tacilp4y.", "ta2>", "tnem4>", "tne3>", "tna3>", "tpir2b.",
    "tpro2b.", "tcud1.", "tpmus2.", "tpec2iv.", "tulo2v.", "tsis0.", "tsi3>",
    "tt1.", "uqi3.", "ugo1.", "vis3j>", "vi2>", "ylb1>", "yli3y>", "ylp0.",
    "yl2>", "ygo1.", "yhp1.", "ymo1.", "ypo1.", "yti3>", "yte3>", "ytl2.",
    "yrtsi5.", "yra3>", "yro3>", "yfi3.", "ycn2t.", "yca3>", "zi2>", "zy1s.",
]


def _parse_lancaster_rule(rule):
    match = re.match(r"^([a-z]+)(\*?)(\d)([a-z]*)([.>])$", rule)
    if not match:
        raise ValueError("bad Lancaster rule %r" % (rule,))
    reversed_suffix, star, remove, append, flag = match.groups()
    return {
        "suffix": reversed_suffix[::-1],
        "intact_only": star == "*",
        "remove": int(remove),
        "append": append,
        "continue": flag == ">",
    }


_LANCASTER_PARSED = [_parse_lancaster_rule(r) for r in _LANCASTER_RULES]


class LancasterStemmer(object):
    """Paice/Husk Lancaster stemmer. The word is lowercased; no prefix is stripped."""

    def stem(self, word):
        _check_word(word)
        w = word.lower()
        intact = True
        for _ in range(1000):
            for rule in _LANCASTER_PARSED:
                if rule["intact_only"] and not intact:
                    continue
                if not w.endswith(rule["suffix"]):
                    continue
                stem = w[:len(w) - rule["remove"]] if rule["remove"] else w
                if len(stem) < 2:
                    continue
                w = stem + rule["append"]
                if not rule["continue"]:
                    return w
                intact = False
                break
            else:
                return w
        return w


# --- Regular-expression stemmer -----------------------------------------------

class RegexpStemmer(object):
    """Removes every match of ``regexp`` from the word; nothing else changes."""

    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be str")
        self._regexp = re.compile(regexp)

    def stem(self, word):
        _check_word(word)
        return self._regexp.sub("", word)


# --- Snowball -------------------------------------------------------------------

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)

_P2_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
    "only": "onli", "singly": "singl",
}
_P2_INVARIANT = {"sky", "news", "howe", "atlas", "cosmos", "bias", "andes"}
_P2_EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed",
            "exceed", "succeed"}
_P2_VOWELS = "aeiouy"


def _p2_r_start(w, start=0):
    for i in range(max(start, 1), len(w)):
        if w[i] not in _P2_VOWELS and w[i - 1] in _P2_VOWELS:
            return i + 1
    return len(w)


def _p2_short_syllable_end(w):
    n = len(w)
    if n == 2:
        return w[0] in _P2_VOWELS and w[1] not in _P2_VOWELS
    if n >= 3:
        return (w[-3] not in _P2_VOWELS and w[-2] in _P2_VOWELS
                and w[-1] not in _P2_VOWELS and w[-1] not in "wxY")
    return False


def _p2_longest(w, suffixes, r_start):
    best = None
    for suffix in suffixes:
        if w.endswith(suffix) and (best is None or len(suffix) > len(best)):
            best = suffix
    if best is None or len(w) - len(best) < r_start:
        return None
    return best


_P2_STEP2 = {
    "ization": "ize", "ational": "ate", "fulness": "ful", "ousness": "ous",
    "iveness": "ive", "tional": "tion", "biliti": "ble", "lessli": "less",
    "fulli": "ful", "ousli": "ous", "alism": "al", "aliti": "al", "iviti": "ive",
    "ation": "ate", "entli": "ent", "enci": "ence", "anci": "ance", "abli": "able",
    "izer": "ize", "ator": "ate", "alli": "al", "bli": "ble", "ogi": "og", "li": "",
}
_P2_STEP3 = {
    "tional": "tion", "ational": "ate", "alize": "al", "icate": "ic",
    "iciti": "ic", "ical": "ic", "ful": "", "ness": "", "ative": "",
}
_P2_STEP4 = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
             "ment", "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion"]


def _porter2(word):
    if len(word) <= 2:
        return word
    if word in _P2_EXC1:
        return _P2_EXC1[word]
    if word in _P2_INVARIANT:
        return word
    w = word
    if w.startswith("'"):
        w = w[1:]
    chars = list(w)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _P2_VOWELS:
            chars[i] = "Y"
    w = "".join(chars)

    prefix = next((p for p in ("gener", "commun", "arsen") if w.startswith(p)), None)
    if prefix is not None:
        r1 = len(prefix)
    else:
        r1 = _p2_r_start(w)
    r2 = _p2_r_start(w, r1)

    # Step 0
    for suffix in ("'s'", "'s", "'"):
        if w.endswith(suffix):
            w = w[:-len(suffix)]
            break

    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith(("ied", "ies")):
        prefix = w[:-3]
        w = prefix + ("i" if len(prefix) > 1 else "ie")
    elif w.endswith(("us", "ss")):
        pass
    elif w.endswith("s") and _has_p2_vowel(w[:-2]):
        w = w[:-1]

    if w in _P2_EXC2:
        return w.replace("Y", "y")

    # Step 1b
    if w.endswith(("eed", "eedly")):
        suffix = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suffix) >= r1:
            w = w[:-len(suffix)] + "ee"
    else:
        for suffix in ("ingly", "edly", "ing", "ed"):
            if w.endswith(suffix) and _has_p2_vowel(w[:-len(suffix)]):
                w = w[:-len(suffix)]
                if w.endswith(("at", "bl", "iz")):
                    w += "e"
                elif _ends_p2_double(w):
                    w = w[:-1]
                elif r1 >= len(w) and _p2_short_syllable_end(w):
                    w += "e"
                break

    # Step 1c
    if len(w) > 2 and w[-1] in "yY" and w[-2] not in _P2_VOWELS:
        w = w[:-1] + "i"

    # Step 2
    suffix = _p2_longest(w, _P2_STEP2.keys(), r1)
    if suffix is not None:
        if suffix == "li":
            if len(w) >= 3 and w[-3] in "cdeghkmnrt":
                w = w[:-2]
        elif suffix == "ogi":
            if len(w) >= 4 and w[-4] == "l":
                w = w[:-3] + "og"
        else:
            w = w[:-len(suffix)] + _P2_STEP2[suffix]

    # Step 3
    suffix = _p2_longest(w, _P2_STEP3.keys(), r1)
    if suffix is not None:
        if suffix == "ative" and len(w) - len(suffix) < r2:
            pass
        else:
            w = w[:-len(suffix)] + _P2_STEP3[suffix]

    # Step 4
    suffix = _p2_longest(w, _P2_STEP4, r2)
    if suffix is not None:
        if suffix != "ion" or (len(w) >= 4 and w[-4] in "st"):
            w = w[:-len(suffix)]

    # Step 5
    if w.endswith("e"):
        stem = w[:-1]
        if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not _p2_short_syllable_end(stem)):
            w = stem
    elif w.endswith("l") and len(w) - 1 >= r2 and w[-2:-1] == "l":
        w = w[:-1]

    return w.replace("Y", "y")


def _has_p2_vowel(stem):
    return any(ch in _P2_VOWELS and ch != "Y" for ch in stem)


def _ends_p2_double(w):
    return len(w) >= 2 and w[-2:] in ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")


class SnowballStemmer(object):
    """Snowball stemmer. Implemented languages: ``english`` (Porter2) and
    ``porter`` (the original Porter algorithm). The other Snowball language
    names are accepted by the constructor check but raise NotImplementedError."""

    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in SNOWBALL_LANGUAGES:
            raise ValueError(
                "unsupported Snowball language %r; supported: %s"
                % (language, ", ".join(SNOWBALL_LANGUAGES))
            )
        self.language = language
        self._stopwords = None
        if ignore_stopwords:
            self._stopwords = _load_stopwords(language)
        if language not in ("english", "porter"):
            raise NotImplementedError(
                "Snowball stemmer for %r is not implemented in this build" % language
            )
        self._ignore_stopwords = bool(ignore_stopwords)

    def stem(self, word):
        _check_word(word)
        lowered = word.lower()
        if self._stopwords is not None and lowered in self._stopwords:
            return lowered
        if self.language == "english":
            return _porter2(lowered)
        return _porter_stem(lowered, lingora=False)


def _load_stopwords(language):
    resource = "corpora/stopwords/" + language
    try:
        location = data.find(resource)
    except LookupError:
        raise LookupError(
            "stopwords list for %r is not installed (looked for %s)" % (language, resource)
        )
    if os.path.isdir(location):
        raise LookupError("stopwords resource %r is not a file" % resource)
    return set(line.strip().lower() for line in data.read_lines(location) if line.strip())


# --- Arabic stemmers (outside this build's stemming results) ---------------------

class ARLSTem(object):
    """ARLSTem Arabic stemmer. Constructible, but its stemming is not implemented."""

    def stem(self, word):
        _check_word(word)
        raise NotImplementedError("ARLSTem stemming is not implemented in this build")


class ARLSTem2(object):
    """ARLSTem2 Arabic stemmer. Constructible, but its stemming is not implemented."""

    def stem(self, word):
        _check_word(word)
        raise NotImplementedError("ARLSTem2 stemming is not implemented in this build")


# --- WordNet lemmatizer ----------------------------------------------------------

_MORPH_RULES = {
    "n": [("s", ""), ("ses", "s"), ("ves", "f"), ("xes", "x"), ("zes", "z"),
          ("ches", "ch"), ("shes", "sh"), ("men", "man"), ("ies", "y")],
    "v": [("s", ""), ("ies", "y"), ("es", "e"), ("es", ""), ("ed", "e"), ("ed", ""),
          ("ing", "e"), ("ing", "")],
    "a": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
    "r": [],
    "s": [("er", ""), ("est", ""), ("er", "e"), ("est", "e")],
}
_POS_FILES = {"n": "noun", "v": "verb", "a": "adj", "s": "adj", "r": "adv"}


class WordNetLemmatizer(object):
    """Lemmatizer over the packaged WordNet resource (``corpora/wordnet``).
    Raises LookupError at construction when WordNet is not visible."""

    def __init__(self):
        self._dir = data.find("corpora/wordnet")
        self._lemmas = {}
        self._exceptions = {}

    def _load(self, pos):
        if pos in self._lemmas:
            return
        name = _POS_FILES[pos]
        lemmas = set()
        index = os.path.join(self._dir, "index." + name)
        exceptions = {}
        exc_file = os.path.join(self._dir, name + ".exc")
        try:
            for line in data.read_lines(index):
                if line and not line.startswith(" "):
                    lemmas.add(line.split(" ", 1)[0])
        except OSError:
            raise LookupError("WordNet index file %r missing" % index)
        if os.path.exists(exc_file):
            for line in data.read_lines(exc_file):
                parts = line.split()
                if len(parts) >= 2:
                    exceptions.setdefault(parts[0], parts[1])
        self._lemmas[pos] = lemmas
        self._exceptions[pos] = exceptions

    def lemmatize(self, word, pos="n"):
        _check_word(word)
        if pos not in _POS_FILES:
            raise ValueError("unknown WordNet part of speech %r" % (pos,))
        self._load(pos)
        lemmas = self._lemmas[pos]
        if word in self._exceptions[pos]:
            return self._exceptions[pos][word]
        if word in lemmas:
            return word
        for suffix, replacement in _MORPH_RULES.get(pos, []):
            if word.endswith(suffix) and len(word) > len(suffix):
                candidate = word[:-len(suffix)] + replacement
                if candidate in lemmas:
                    return candidate
        return word
