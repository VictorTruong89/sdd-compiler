"""Classifiers: Naive Bayes (with a probability distribution over labels) and a
decision tree, both trained on labeled featuresets, plus the accuracy helper."""

import math
from collections import Counter

__all__ = ["DecisionTreeClassifier", "NaiveBayesClassifier", "ProbDist", "accuracy"]

_MISSING = object()


class ProbDist(object):
    """A probability distribution over labels."""

    def __init__(self, probabilities):
        self._probs = dict(probabilities)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs, key=lambda label: self._probs[label])

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


def _check_training(labeled_featuresets):
    examples = []
    for featureset, label in labeled_featuresets:
        if not isinstance(featureset, dict):
            raise TypeError("a featureset must be a dict")
        examples.append((featureset, label))
    if not examples:
        raise ValueError("training needs at least one labeled featureset")
    return examples


class NaiveBayesClassifier(object):
    """Naive Bayes with add-one (Laplace) smoothing over feature values."""

    def __init__(self, label_counts, feature_values, feature_counts, labels):
        self._label_counts = label_counts
        self._total = sum(label_counts.values())
        self._feature_values = feature_values
        self._feature_counts = feature_counts
        self._labels = list(labels)

    @classmethod
    def train(cls, labeled_featuresets):
        examples = _check_training(labeled_featuresets)
        labels = []
        label_counts = Counter()
        feature_values = {}
        feature_counts = {}
        for featureset, label in examples:
            if label not in label_counts:
                labels.append(label)
            label_counts[label] += 1
            for name, value in featureset.items():
                feature_values.setdefault(name, set()).add(value)
                key = (label, name, value)
                feature_counts[key] = feature_counts.get(key, 0) + 1
        return cls(label_counts, feature_values, feature_counts, labels)

    def labels(self):
        return list(self._labels)

    def _log_scores(self, featureset):
        scores = {}
        for label in self._labels:
            log_score = math.log(self._label_counts[label] / float(self._total))
            label_total = self._label_counts[label]
            for name, value in featureset.items():
                if name not in self._feature_values:
                    continue
                count = self._feature_counts.get((label, name, value), 0)
                vocabulary = len(self._feature_values[name])
                probability = (count + 1.0) / (label_total + vocabulary)
                log_score += math.log(probability)
            scores[label] = log_score
        return scores

    def prob_classify(self, featureset):
        scores = self._log_scores(featureset)
        top = max(scores.values())
        weights = {label: math.exp(score - top) for label, score in scores.items()}
        norm = sum(weights.values())
        return ProbDist({label: weight / norm for label, weight in weights.items()})

    def classify(self, featureset):
        scores = self._log_scores(featureset)
        best = self._labels[0]
        for label in self._labels:
            if scores[label] > scores[best]:
                best = label
        return best


def _entropy(counts, total):
    result = 0.0
    for count in counts.values():
        if count:
            p = count / float(total)
            result -= p * math.log(p, 2)
    return result


class DecisionTreeClassifier(object):
    """Decision tree: at each node the feature with the highest information gain
    is tested; a leaf returns the majority label of the training examples
    reaching it."""

    def __init__(self, node):
        self._node = node

    @classmethod
    def train(cls, labeled_featuresets):
        examples = _check_training(labeled_featuresets)
        names = []
        seen = set()
        for featureset, _ in examples:
            for name in featureset:
                if name not in seen:
                    seen.add(name)
                    names.append(name)
        return cls(_build(examples, names))

    def labels(self):
        out = []
        _collect_labels(self._node, out)
        return out

    def classify(self, featureset):
        node = self._node
        while "children" in node:
            value = featureset.get(node["feature"], _MISSING)
            child = node["children"].get(value)
            if child is None:
                return node["default"]
            node = child
        return node["label"]


def _collect_labels(node, out):
    if "label" in node:
        if node["label"] not in out:
            out.append(node["label"])
        return
    for child in node["children"].values():
        _collect_labels(child, out)
    if node["default"] not in out:
        out.append(node["default"])


def _majority(examples):
    counts = Counter(label for _, label in examples)
    best = None
    for _, label in examples:
        if best is None or counts[label] > counts[best]:
            best = label
    return best


def _build(examples, names):
    labels = Counter(label for _, label in examples)
    majority = _majority(examples)
    if len(labels) == 1 or not names:
        return {"label": majority}
    total = len(examples)
    parent_entropy = _entropy(labels, total)
    best_name = None
    best_gain = None
    for name in names:
        groups = {}
        for featureset, label in examples:
            value = featureset.get(name, _MISSING)
            groups.setdefault(value, Counter())[label] += 1
        if len(groups) < 2:
            continue
        remainder = 0.0
        for counts in groups.values():
            size = sum(counts.values())
            remainder += (size / float(total)) * _entropy(counts, size)
        gain = parent_entropy - remainder
        if best_gain is None or gain > best_gain:
            best_name, best_gain = name, gain
    if best_name is None:
        return {"label": majority}
    partitions = {}
    for featureset, label in examples:
        value = featureset.get(best_name, _MISSING)
        partitions.setdefault(value, []).append((featureset, label))
    remaining = [name for name in names if name != best_name]
    children = {value: _build(subset, remaining) for value, subset in partitions.items()}
    return {"feature": best_name, "children": children, "default": majority}


def accuracy(classifier, gold):
    """Fraction of gold ``(featureset, label)`` pairs whose label the classifier
    returns."""
    gold = list(gold)
    if not gold:
        raise ValueError("accuracy needs at least one gold example")
    correct = sum(1 for featureset, label in gold if classifier.classify(featureset) == label)
    return correct / float(len(gold))
