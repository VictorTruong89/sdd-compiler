"""Context-free grammars read from text: one production per line, ``LHS -> RHS``,
with ``|`` separating alternatives and quoted text giving terminals."""

import re

__all__ = ["CFG", "Nonterminal", "Production"]

_IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_\-]*")


class Nonterminal(object):
    """A nonterminal symbol; ``str()`` is its name."""

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def symbol(self):
        return self._name

    def __str__(self):
        return self._name

    def __repr__(self):
        return "Nonterminal(%r)" % (self._name,)

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._name == self._name

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(("Nonterminal", self._name))


class Production(object):
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __eq__(self, other):
        return (isinstance(other, Production) and self._lhs == other._lhs
                and self._rhs == other._rhs)

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = []
        for sym in self._rhs:
            if isinstance(sym, str):
                parts.append('"%s"' % sym)
            else:
                parts.append(str(sym))
        return "%s -> %s" % (self._lhs, " ".join(parts))

    def __repr__(self):
        return "Production(%s)" % (self,)


def _parse_alternatives(text):
    """Split the right-hand side at top-level ``|`` into lists of symbols."""
    alternatives = [[]]
    i = 0
    while i < len(text):
        ch = text[i]
        if ch.isspace():
            i += 1
        elif ch == "|":
            alternatives.append([])
            i += 1
        elif ch in ("'", '"'):
            end = text.find(ch, i + 1)
            if end < 0:
                raise ValueError("unterminated quoted terminal in %r" % (text,))
            alternatives[-1].append(text[i + 1:end])
            i = end + 1
        else:
            match = _IDENT.match(text, i)
            if not match:
                raise ValueError("unexpected %r in production %r" % (ch, text))
            alternatives[-1].append(Nonterminal(match.group(0)))
            i = match.end()
    return alternatives


class CFG(object):
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("grammar text must be str")
        productions = []
        start = None
        for raw in input.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("production must have the form 'LHS -> RHS': %r" % (line,))
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not _IDENT.fullmatch(lhs_text):
                raise ValueError("bad left-hand side %r" % (lhs_text,))
            lhs = Nonterminal(lhs_text)
            if start is None:
                start = lhs
            for alternative in _parse_alternatives(rhs_text):
                productions.append(Production(lhs, alternative))
        return cls(start, productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        name = lhs.symbol() if isinstance(lhs, Nonterminal) else str(lhs)
        return [p for p in self._productions if p.lhs().symbol() == name]

    def terminals(self):
        out = set()
        for prod in self._productions:
            for sym in prod.rhs():
                if isinstance(sym, str) and sym != "":
                    out.add(sym)
        return out

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)
