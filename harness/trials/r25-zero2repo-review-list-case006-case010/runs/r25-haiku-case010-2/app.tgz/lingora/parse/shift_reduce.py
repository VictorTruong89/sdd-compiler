"""Shift-reduce parser: one left-to-right pass without backtracking."""

from ..tree import Tree
from ._common import check_grammar, check_tokens

_TOKEN = object()
_MAX_STEPS = 100000


class ShiftReduceParser(object):
    def __init__(self, grammar):
        self._grammar = check_grammar(grammar)

    def parse(self, tokens):
        tokens = check_tokens(tokens, self._grammar)
        start = self._grammar.start()
        if start is None:
            return iter([])
        productions = [p for p in self._grammar.productions()
                       if p.rhs() and not (len(p.rhs()) == 1 and p.rhs()[0] == p.lhs())]
        stack = []  # entries are (symbol name or _TOKEN, node)
        position = 0
        seen = set()
        for _ in range(_MAX_STEPS):
            reduced = False
            for prod in productions:
                rhs = prod.rhs()
                k = len(rhs)
                if k > len(stack):
                    continue
                if all(_matches(rhs[x], stack[len(stack) - k + x]) for x in range(k)):
                    children = [node for _, node in stack[len(stack) - k:]]
                    del stack[len(stack) - k:]
                    name = prod.lhs().symbol()
                    stack.append((name, Tree(name, children)))
                    reduced = True
                    break
            if reduced:
                key = (tuple(name for name, _ in stack), position)
                if key in seen:
                    return iter([])
                seen.add(key)
                continue
            if position < len(tokens):
                stack.append((_TOKEN, tokens[position]))
                position += 1
                continue
            break
        if position == len(tokens) and len(stack) == 1 and stack[0][0] == start.symbol():
            return iter([stack[0][1]])
        return iter([])


def _matches(sym, entry):
    name, node = entry
    if isinstance(sym, str):
        return name is _TOKEN and node == sym
    return name is not _TOKEN and name == sym.symbol()
