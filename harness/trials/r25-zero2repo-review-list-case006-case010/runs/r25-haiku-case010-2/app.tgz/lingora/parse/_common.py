from ..grammar import CFG


def check_grammar(grammar):
    if not isinstance(grammar, CFG):
        raise TypeError("grammar must be a CFG, not %s" % type(grammar).__name__)
    return grammar


def check_tokens(tokens, grammar):
    """Refuse non-token input; raise when a token no production produces is present."""
    if isinstance(tokens, (str, bytes)):
        raise TypeError("tokens must be a list of str, not a string")
    tokens = list(tokens)
    for token in tokens:
        if not isinstance(token, str):
            raise TypeError("every token must be str, not %s" % type(token).__name__)
    terminals = grammar.terminals()
    for token in tokens:
        if token not in terminals:
            raise ValueError("token %r is not produced by any production of the grammar" % (token,))
    return tokens
