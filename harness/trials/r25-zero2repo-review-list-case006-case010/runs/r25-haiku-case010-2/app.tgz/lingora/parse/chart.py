"""Exhaustive chart parser: every parse tree the grammar assigns to a token list."""

from ..tree import Tree
from ._common import check_grammar, check_tokens


def _derivable(grammar, tokens):
    """All (symbol, i, j) spans from which the symbol derives tokens[i:j]."""
    n = len(tokens)
    spans = set()
    productions = grammar.productions()
    changed = True
    while changed:
        changed = False
        for prod in productions:
            lhs = prod.lhs().symbol()
            for i in range(n + 1):
                for j in _ends(prod.rhs(), i, tokens, spans):
                    key = (lhs, i, j)
                    if key not in spans:
                        spans.add(key)
                        changed = True
    return spans


def _ends(rhs, i, tokens, spans):
    current = {i}
    for sym in rhs:
        following = set()
        for p in current:
            if isinstance(sym, str):
                if sym == "":
                    following.add(p)
                elif p < len(tokens) and tokens[p] == sym:
                    following.add(p + 1)
            else:
                for q in range(p, len(tokens) + 1):
                    if (sym.symbol(), p, q) in spans:
                        following.add(q)
        current = following
        if not current:
            break
    return current


class _Enumerator(object):
    def __init__(self, grammar, tokens):
        self.grammar = grammar
        self.tokens = tokens
        self.spans = _derivable(grammar, tokens)
        self.by_lhs = {}
        for prod in grammar.productions():
            self.by_lhs.setdefault(prod.lhs().symbol(), []).append(prod)

    def trees(self, name, i, j, path):
        key = (name, i, j)
        if key not in self.spans or key in path:
            return []
        out = []
        for prod in self.by_lhs.get(name, []):
            for children in self.sequences(prod.rhs(), i, j, path | {key}):
                out.append(Tree(name, children))
        return out

    def sequences(self, rhs, i, j, path):
        if not rhs:
            return [[]] if i == j else []
        first, rest = rhs[0], rhs[1:]
        results = []
        if isinstance(first, str):
            if first == "":
                return self.sequences(rest, i, j, path)
            if i < j and self.tokens[i] == first:
                for tail in self.sequences(rest, i + 1, j, path):
                    results.append([first] + tail)
            return results
        name = first.symbol()
        for k in range(i, j + 1):
            if (name, i, k) not in self.spans:
                continue
            for sub in self.trees(name, i, k, path):
                for tail in self.sequences(rest, k, j, path):
                    results.append([sub] + tail)
        return results


class ChartParser(object):
    def __init__(self, grammar):
        self._grammar = check_grammar(grammar)

    def parse(self, tokens):
        tokens = check_tokens(tokens, self._grammar)
        start = self._grammar.start()
        if start is None:
            return iter([])
        enumerator = _Enumerator(self._grammar, tokens)
        return iter(enumerator.trees(start.symbol(), 0, len(tokens), frozenset()))
