"""Generation: enumerate the sentences a grammar derives from a start symbol."""

import itertools

from ..grammar import CFG, Nonterminal

__all__ = ["generate"]


def _symbol(grammar, sym):
    """Yield the token lists derivable from ``sym`` with ``depth`` expansions left."""


def _expand_symbol(grammar, name, depth):
    if depth <= 0:
        return
    for prod in grammar.productions(lhs=name):
        for sentence in _expand_sequence(grammar, prod.rhs(), depth - 1):
            yield sentence


def _expand_sequence(grammar, rhs, depth):
    if not rhs:
        yield []
        return
    first, rest = rhs[0], rhs[1:]
    if isinstance(first, str):
        prefix = [first] if first != "" else []
        for tail in _expand_sequence(grammar, rest, depth):
            yield prefix + tail
        return
    for head in _expand_symbol(grammar, first.symbol(), depth):
        for tail in _expand_sequence(grammar, rest, depth):
            yield head + tail


def generate(grammar, start=None, depth=None, n=None):
    """Yield token lists derivable from ``start`` (default: the grammar's start
    symbol). ``depth`` bounds the derivation depth and ``n`` the number of
    sentences; both default to no bound."""
    if not isinstance(grammar, CFG):
        raise TypeError("grammar must be a CFG")
    if start is None:
        start = grammar.start()
    if start is None:
        return iter([])
    if isinstance(start, Nonterminal):
        name = start.symbol()
    else:
        name = str(start)
    bound = float("inf") if depth is None else depth
    sentences = _expand_symbol(grammar, name, bound)
    if n is None:
        return sentences
    return itertools.islice(sentences, n)
