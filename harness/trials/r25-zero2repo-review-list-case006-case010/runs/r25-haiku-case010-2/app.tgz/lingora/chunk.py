"""Chunking: a regular-expression chunk parser over a chunk grammar (FP-04), and
the named-entity chunker entry, which needs its packaged model."""

import re

from . import data
from .tree import Tree

__all__ = ["ChunkStage", "RegexpParser", "ne_chunk"]

ROOT_LABEL = "S"
_CLAUSE_LABEL = re.compile(r"^[A-Za-z_][\w.\-]*$")


class ChunkStage(object):
    """One clause of a chunk grammar: a chunk label and its rules, each rule a
    ``("chunk" | "chink", compiled_regexp)`` pair."""

    def __init__(self, label, rules):
        self.label = label
        self.rules = list(rules)


def _element_regex(content):
    """Turn the content of one ``<...>`` element into a regular expression over
    a single tag: ``.`` matches any character of the tag, never a bracket."""
    out = []
    k = 0
    while k < len(content):
        ch = content[k]
        if ch == "\\" and k + 1 < len(content):
            out.append(content[k:k + 2])
            k += 2
            continue
        out.append("[^<>]" if ch == "." else ch)
        k += 1
    return "".join(out)


_QUANTIFIER_BRACES = re.compile(r"\{\d*,?\d*\}")


def _parse_rules(text):
    """Parse the pattern part of a clause into ``(kind, regexp_text)`` pairs."""
    compact = re.sub(r"\s+", "", text)
    rules = []
    i = 0
    while i < len(compact):
        opener = compact[i]
        if opener == "{":
            kind, close = "chunk", "}"
        elif opener == "}":
            kind, close = "chink", "{"
        else:
            raise ValueError("expected '{' or '}' in chunk pattern %r" % (text,))
        i += 1
        elements = []
        while True:
            if i >= len(compact):
                raise ValueError("unterminated chunk rule in %r" % (text,))
            ch = compact[i]
            if ch == close:
                i += 1
                break
            if ch != "<":
                raise ValueError("expected '<tag>' in chunk pattern %r" % (text,))
            end = compact.find(">", i)
            if end < 0:
                raise ValueError("unterminated '<' in chunk pattern %r" % (text,))
            content = compact[i + 1:end]
            i = end + 1
            quantifier = ""
            if i < len(compact) and compact[i] in "?*+":
                quantifier = compact[i]
                i += 1
            else:
                match = _QUANTIFIER_BRACES.match(compact, i)
                if match and any(c.isdigit() for c in match.group(0)):
                    quantifier = match.group(0)
                    i = match.end()
            elements.append("(?:<(?:%s)>)%s" % (_element_regex(content), quantifier))
        rules.append((kind, "".join(elements)))
    return rules


def _parse_grammar(text):
    stages = []
    current = None
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        indented = raw[:1] in (" ", "\t")
        body = raw.strip()
        colon = body.find(":")
        label_text = body[:colon].strip() if colon >= 0 else ""
        if not indented and colon >= 0 and _CLAUSE_LABEL.match(label_text):
            current = ChunkStage(label_text, [])
            stages.append(current)
            body = body[colon + 1:]
        if current is None:
            raise ValueError("chunk grammar must start with a '<LABEL>:' clause line")
        for kind, regexp_text in _parse_rules(body):
            try:
                compiled = re.compile(regexp_text)
            except re.error as exc:
                raise ValueError("bad tag pattern in chunk grammar: %s" % exc)
            current.rules.append((kind, compiled))
    return stages


def _tag_of(item):
    if isinstance(item, Tree):
        return item.label()
    tag = item[1] if isinstance(item, tuple) and len(item) == 2 else None
    return "" if tag is None else str(tag)


def _spans(items, regexp):
    """Non-overlapping, non-empty matches of ``regexp`` over the tag sequence of
    ``items``, as ``(start, end)`` item indices. Touching matches are merged."""
    tags = "".join("<%s>" % _tag_of(item) for item in items)
    positions = {0: 0}
    offset = 0
    for index, item in enumerate(items):
        offset += len(_tag_of(item)) + 2
        positions[offset] = index + 1
    spans = []
    for match in regexp.finditer(tags):
        if match.end() == match.start():
            continue
        start = positions.get(match.start())
        end = positions.get(match.end())
        if start is None or end is None:
            continue
        if spans and spans[-1][1] == start:
            spans[-1] = (spans[-1][0], end)
        else:
            spans.append((start, end))
    return spans


class RegexpParser(object):
    """Chunk parser for a chunk grammar (a string, or a list of ChunkStage objects)."""

    def __init__(self, grammar, root_label=ROOT_LABEL):
        if isinstance(grammar, str):
            self._stages = _parse_grammar(grammar)
        elif isinstance(grammar, list) and all(isinstance(s, ChunkStage) for s in grammar):
            self._stages = list(grammar)
        else:
            raise TypeError("chunk grammar must be a str or a list of chunk stages")
        self._root = root_label

    @property
    def stages(self):
        return list(self._stages)

    def parse(self, tagged):
        if isinstance(tagged, (str, bytes)):
            raise TypeError("tagged tokens must be a list of (token, tag) pairs")
        items = []
        for pair in tagged:
            if not (isinstance(pair, tuple) and len(pair) == 2):
                raise TypeError("each item must be a (token, tag) pair")
            items.append(pair)
        for stage_index, stage in enumerate(self._stages):
            for kind, regexp in stage.rules:
                if kind == "chunk":
                    items = self._apply_chunk(items, stage, stage_index, regexp)
                else:
                    items = self._apply_chink(items, stage, stage_index, regexp)
        return Tree(self._root, items)

    @staticmethod
    def _matchable(item, stage_index):
        return not (isinstance(item, Tree) and getattr(item, "_stage", None) == stage_index)

    def _apply_chunk(self, items, stage, stage_index, regexp):
        result = []
        i = 0
        n = len(items)
        while i < n:
            if not self._matchable(items[i], stage_index):
                result.append(items[i])
                i += 1
                continue
            j = i
            while j < n and self._matchable(items[j], stage_index):
                j += 1
            run = items[i:j]
            pos = 0
            for start, end in _spans(run, regexp):
                result.extend(run[pos:start])
                result.append(self._make_chunk(stage, stage_index, run[start:end]))
                pos = end
            result.extend(run[pos:])
            i = j
        return result

    def _apply_chink(self, items, stage, stage_index, regexp):
        result = []
        for item in items:
            if not (isinstance(item, Tree) and getattr(item, "_stage", None) == stage_index):
                result.append(item)
                continue
            children = list(item)
            pos = 0
            removed_any = False
            for start, end in _spans(children, regexp):
                removed_any = True
                if start > pos:
                    result.append(self._make_chunk(stage, stage_index, children[pos:start]))
                result.extend(children[start:end])
                pos = end
            if not removed_any:
                result.append(item)
                continue
            if pos < len(children):
                result.append(self._make_chunk(stage, stage_index, children[pos:]))
        return result

    @staticmethod
    def _make_chunk(stage, stage_index, children):
        node = Tree(stage.label, list(children))
        node._stage = stage_index
        return node


def ne_chunk(tagged_tokens):
    """Named-entity chunker entry. It needs the packaged named-entity model and
    the English wordlist; it raises LookupError when either is not visible.
    Running the packaged model is not implemented in this build."""
    if isinstance(tagged_tokens, (str, bytes)):
        raise TypeError("tagged tokens must be a list of (token, tag) pairs")
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    raise NotImplementedError("the named-entity model is not supported in this build")
