"""Punkt sentence-boundary detection (Kiss and Strunk, 2006), driven by the
packaged parameters: abbreviation types, collocations, sentence starters and
orthographic context.

The boundary decision for a sentence-final candidate (a whitespace-delimited
token that ends in ``.``, ``?`` or ``!`` before optional closing quotes or
brackets) follows Punkt's rules:

* ``?`` and ``!`` always end a sentence when another token follows.
* A pair (type before the period, type of the next token) listed as a
  collocation never ends a sentence.
* A period after an abbreviation (a listed abbreviation type or a single
  letter) ends a sentence only when the next token is capitalised and is
  either a known sentence starter or has upper-case-at-sentence-start evidence
  in the orthographic context.
* Any other period ends a sentence unless the next token starts with a
  lower-case letter.
"""

import re

from . import data

_SENT_CLOSERS = "\"')]}>"
_NUMBER_TYPE = re.compile(r"^-?[.,]?\d[\d,.-]*\.?$")
_CANDIDATE = re.compile(r"\S+")

ORTHO_UPPER_SENT_START = 2
ORTHO_UPPER_INSIDE = 4


class PunktParameters(object):
    def __init__(self, abbrev_types, collocations, sent_starters, ortho_context):
        self.abbrev_types = abbrev_types
        self.collocations = collocations
        self.sent_starters = sent_starters
        self.ortho_context = ortho_context


_cache = {}


def load_parameters(language):
    """Load the Punkt parameters for ``language`` (a directory name such as
    ``english``) from the first data-path directory that holds them."""
    directory = data.find("tokenizers/punkt_tab/" + language)
    if directory in _cache:
        return _cache[directory]

    def lines(name):
        try:
            return data.read_lines(_join(directory, name))
        except OSError as exc:
            raise LookupError(
                "Punkt model file %r missing for language %r: %s" % (name, language, exc)
            )

    abbrev = set(line.strip().lower() for line in lines("abbrev_types.txt") if line.strip())
    starters = set(line.strip().lower() for line in lines("sent_starters.txt") if line.strip())
    collocations = set()
    for line in lines("collocations.tab"):
        parts = line.split("\t")
        if len(parts) == 2:
            collocations.add((parts[0], parts[1]))
    ortho = {}
    for line in lines("ortho_context.tab"):
        parts = line.split("\t")
        if len(parts) == 2 and parts[1].strip().lstrip("-").isdigit():
            ortho[parts[0]] = int(parts[1])
    params = PunktParameters(abbrev, collocations, starters, ortho)
    _cache[directory] = params
    return params


def _join(directory, name):
    import os

    return os.path.join(directory, name)


def _type_of(word):
    """Punkt type of a token: lower-cased, or ``##number##`` for numbers."""
    if _NUMBER_TYPE.match(word):
        return "##number##"
    return word.lower()


def _core(word):
    """The token without leading and trailing non-word characters."""
    return re.sub(r"^\W+", "", re.sub(r"\W+$", "", word))


def split_sentences(text, language="english"):
    params = load_parameters(language)
    tokens = [(m.group(0), m.start(), m.end()) for m in _CANDIDATE.finditer(text)]
    sentences = []
    if not tokens:
        return sentences
    start = 0
    for i, (word, _, _) in enumerate(tokens):
        if i == len(tokens) - 1:
            break
        if _ends_sentence(params, tokens, i):
            sentences.append(text[tokens[start][1]:tokens[i][2]])
            start = i + 1
    sentences.append(text[tokens[start][1]:tokens[-1][2]])
    return sentences


def _ends_sentence(params, tokens, i):
    word = tokens[i][0]
    core = word.rstrip("".join(_SENT_CLOSERS))
    if not core or core[-1] not in ".?!":
        return False
    if core[-1] in "?!":
        return True

    base = core[:-1]
    next_word = tokens[i + 1][0]
    next_core = _core(next_word)
    next_type = _type_of(next_core[:-1] if next_core.endswith(".") else next_core)
    base_core = _core(base)
    if not base_core:
        # A bare period or an ellipsis-like run: ordinary handling.
        return not next_core[:1].islower()

    word_type = _type_of(base_core)
    if (word_type, next_type) in params.collocations:
        return False

    is_ellipsis = base.endswith(".")
    is_abbrev = (not is_ellipsis) and (
        word_type in params.abbrev_types or (len(word_type) == 1 and word_type.isalpha())
    )
    if is_abbrev:
        if not next_core[:1].isupper():
            return False
        if next_type in params.sent_starters:
            return True
        ortho = params.ortho_context.get(next_type, 0)
        return bool(ortho & ORTHO_UPPER_SENT_START)

    return not next_core[:1].islower()
