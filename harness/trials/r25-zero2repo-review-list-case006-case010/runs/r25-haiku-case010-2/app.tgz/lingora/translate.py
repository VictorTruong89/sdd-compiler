"""BLEU (Papineni et al., 2002) over token lists."""

import math
from collections import Counter

__all__ = ["bleu"]

DEFAULT_WEIGHTS = (0.5, 0.5)


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def bleu(references, hypothesis, weights=None, smoothing_function=None):
    """Sentence-level BLEU of ``hypothesis`` against one or more ``references``.

    ``weights`` gives one weight per n-gram order from unigrams; when omitted,
    unigrams and bigrams are weighted equally. ``smoothing_function``, when
    given, is called as ``smoothing_function(numerators, denominators)`` with the
    clipped match counts and candidate n-gram totals per order, and must return
    the list of precisions to use."""
    if weights is None:
        weights = DEFAULT_WEIGHTS
    weights = [float(w) for w in weights]
    if not weights:
        raise ValueError("bleu needs at least one weight")
    references = [list(r) for r in references]
    if not references:
        raise ValueError("bleu needs at least one reference")
    hypothesis = list(hypothesis)

    numerators = []
    denominators = []
    for n in range(1, len(weights) + 1):
        hyp_counts = _ngrams(hypothesis, n)
        max_ref = Counter()
        for ref in references:
            for gram, count in _ngrams(ref, n).items():
                if count > max_ref[gram]:
                    max_ref[gram] = count
        numerators.append(sum(min(count, max_ref[gram]) for gram, count in hyp_counts.items()))
        denominators.append(max(len(hypothesis) - n + 1, 0))

    if smoothing_function is not None:
        precisions = list(smoothing_function(numerators, denominators))
    else:
        precisions = [(num / float(den)) if den > 0 else 0.0
                      for num, den in zip(numerators, denominators)]

    if not hypothesis:
        return 0.0
    for p, w in zip(precisions, weights):
        if w > 0 and p <= 0:
            return 0.0

    hyp_len = len(hypothesis)
    ref_len = min((len(r) for r in references),
                  key=lambda r: (abs(r - hyp_len), r))
    if hyp_len > ref_len:
        brevity = 1.0
    else:
        brevity = math.exp(1 - ref_len / float(hyp_len))

    log_sum = sum(w * math.log(p) for p, w in zip(precisions, weights) if w > 0)
    return float(brevity * math.exp(log_sum))
