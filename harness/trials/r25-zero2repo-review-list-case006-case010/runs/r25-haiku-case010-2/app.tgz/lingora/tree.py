"""Constituent trees: a label plus an ordered list of children, where a child is a
leaf (a token) or another tree."""

import re

__all__ = ["Tree"]

_BRACKET_TOKEN = re.compile(r"\(|\)|[^\s()]+")


class Tree(object):
    def __init__(self, label, children):
        if isinstance(children, (str, bytes)):
            raise TypeError("children must be a list of children, not a string")
        if not isinstance(children, (list, tuple)):
            raise TypeError("children must be a list, not %s" % type(children).__name__)
        self._label = label
        self._children = list(children)

    # --- structure -------------------------------------------------------
    def label(self):
        return self._label

    def __len__(self):
        return len(self._children)

    def __iter__(self):
        return iter(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def __str__(self):
        return self.pformat(margin=10 ** 9)

    # --- text forms ------------------------------------------------------
    def pformat(self, margin=70):
        """Pretty-printed form. Nodes are shown in pre-order, left to right; a
        node is broken over lines when its one-line form exceeds ``margin``."""
        return _pformat(self, 0, margin)

    @classmethod
    def fromstring(cls, s):
        if not isinstance(s, str):
            raise TypeError("bracketed tree text must be str")
        tokens = _BRACKET_TOKEN.findall(s)
        if not tokens:
            raise ValueError("empty bracketed tree text")
        tree, position = _parse_node(tokens, 0)
        if position != len(tokens):
            raise ValueError("trailing text after the tree in %r" % (s,))
        return tree


def _parse_node(tokens, position):
    if position >= len(tokens) or tokens[position] != "(":
        raise ValueError("expected '(' in bracketed tree text")
    position += 1
    label = ""
    if position < len(tokens) and tokens[position] not in ("(", ")"):
        label = tokens[position]
        position += 1
    children = []
    while True:
        if position >= len(tokens):
            raise ValueError("unbalanced parentheses in bracketed tree text")
        token = tokens[position]
        if token == ")":
            return Tree(label, children), position + 1
        if token == "(":
            child, position = _parse_node(tokens, position)
            children.append(child)
        else:
            children.append(token)
            position += 1


def _leaf_text(child):
    if isinstance(child, tuple) and len(child) == 2:
        return "%s/%s" % (child[0], child[1])
    return str(child)


def _pformat(node, indent, margin):
    if not isinstance(node, Tree):
        return _leaf_text(node)
    flat = _flat(node)
    if indent + len(flat) <= margin:
        return flat
    return _multiline(node, indent, margin)


def _multiline(node, indent, margin):
    lines = ["(" + str(node.label())]
    body = []
    for child in node:
        body.append(_pformat(child, indent + 2, margin))
    text = lines[0]
    for chunk in body:
        text += "\n" + " " * (indent + 2) + chunk
    return text + ")"


def _flat(node):
    parts = []
    for child in node:
        if isinstance(child, Tree):
            parts.append(_flat(child))
        else:
            parts.append(_leaf_text(child))
    inner = " ".join(parts)
    return "(%s %s)" % (node.label(), inner) if parts else "(%s)" % node.label()
