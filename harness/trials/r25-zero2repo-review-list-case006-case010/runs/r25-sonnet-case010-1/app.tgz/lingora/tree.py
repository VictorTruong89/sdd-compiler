"""Constituent trees."""


class Tree(list):
    def __init__(self, label, children):
        if isinstance(children, (str, bytes)) or children is None or not isinstance(children, (list, tuple)):
            if not isinstance(children, (list, tuple)):
                raise TypeError("children should be a list, not %s" % type(children).__name__)
        list.__init__(self, children)
        self._label = label

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def leaves(self):
        out = []
        for c in self:
            if isinstance(c, Tree):
                out.extend(c.leaves())
            else:
                out.append(c)
        return out

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return False
        return self._label == other._label and list.__eq__(self, other)

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def copy(self):
        return Tree(self._label, [c.copy() if isinstance(c, Tree) else c for c in self])

    def __repr__(self):
        return "Tree(%r, %s)" % (self._label, list.__repr__(self))

    def __str__(self):
        return self.pformat()

    def _flat(self):
        parts = []
        for c in self:
            if isinstance(c, Tree):
                parts.append(c._flat())
            elif isinstance(c, tuple):
                parts.append("/".join(str(x) for x in c))
            else:
                parts.append(str(c))
        return "(%s %s)" % (self._label, " ".join(parts)) if parts else "(%s )" % (self._label,)

    def pformat(self, margin=70, indent=0):
        s = self._flat()
        if len(s) + indent < margin:
            return s
        out = "(%s" % (self._label,)
        for c in self:
            if isinstance(c, Tree):
                out += "\n" + " " * (indent + 2) + c.pformat(margin, indent + 2)
            elif isinstance(c, tuple):
                out += "\n" + " " * (indent + 2) + "/".join(str(x) for x in c)
            else:
                out += "\n" + " " * (indent + 2) + str(c)
        return out + ")"

    def pretty_print(self, *a, **k):
        print(self.pformat())

    @classmethod
    def fromstring(cls, s, open_paren="(", close_paren=")"):
        import re
        toks = re.findall(r"\(|\)|[^\s()]+", s)
        if not toks:
            raise ValueError("empty tree string")
        pos = [0]

        def parse_node():
            if toks[pos[0]] != "(":
                raise ValueError("Tree.fromstring: expected '(' at token %d" % pos[0])
            pos[0] += 1
            if pos[0] >= len(toks):
                raise ValueError("Tree.fromstring: unexpected end")
            if toks[pos[0]] in "()":
                label = ""
            else:
                label = toks[pos[0]]
                pos[0] += 1
            children = []
            while True:
                if pos[0] >= len(toks):
                    raise ValueError("Tree.fromstring: missing ')'")
                t = toks[pos[0]]
                if t == ")":
                    pos[0] += 1
                    return cls(label, children)
                if t == "(":
                    children.append(parse_node())
                else:
                    children.append(t)
                    pos[0] += 1

        tree = parse_node()
        if pos[0] != len(toks):
            raise ValueError("Tree.fromstring: extra text after tree")
        if tree.label() == "" and len(tree) == 1 and isinstance(tree[0], Tree):
            return tree[0]
        return tree
