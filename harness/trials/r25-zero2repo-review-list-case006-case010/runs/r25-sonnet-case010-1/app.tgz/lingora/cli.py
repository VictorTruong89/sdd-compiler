"""Command line: ``lingora tokenize``."""
import sys

from .tokenize import word_tokenize


class _Group:
    def __init__(self, name):
        self.name = name

    def main(self, args=None, standalone_mode=True, **kwargs):
        args = list(sys.argv[1:] if args is None else args)
        try:
            code = self._run(args)
        except SystemExit as e:
            code = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
        except Exception as e:  # failure: no token line for failed input
            sys.stderr.write("Error: %s\n" % (e,))
            code = 1
        if standalone_mode:
            sys.exit(code)
        return code

    def _run(self, args):
        if not args or args[0] in ("-h", "--help"):
            sys.stdout.write("Usage: lingora [OPTIONS] COMMAND [ARGS]...\n\nCommands:\n  tokenize\n")
            return 0 if args else 2
        cmd, rest = args[0], args[1:]
        if cmd != "tokenize":
            sys.stderr.write("Error: No such command %r.\n" % cmd)
            return 2
        language, delimiter, encoding = "english", " ", "utf-8"
        i = 0
        while i < len(rest):
            a = rest[i]
            if a in ("-l", "--language", "-d", "--delimiter", "-e", "--encoding") and i + 1 < len(rest):
                v = rest[i + 1]
                if a in ("-l", "--language"):
                    language = v
                elif a in ("-d", "--delimiter"):
                    delimiter = v
                else:
                    encoding = v
                i += 2
            elif a.startswith("--language="):
                language = a.split("=", 1)[1]; i += 1
            elif a.startswith("--delimiter="):
                delimiter = a.split("=", 1)[1]; i += 1
            elif a.startswith("--encoding="):
                encoding = a.split("=", 1)[1]; i += 1
            else:
                sys.stderr.write("Error: unexpected argument %r\n" % a)
                return 2
        stdin = sys.stdin
        text = stdin.buffer.read().decode(encoding) if hasattr(stdin, "buffer") else stdin.read()
        out = []
        for line in text.splitlines():
            toks = word_tokenize(line, language=language)
            out.append(delimiter.join(toks) + "\n")
            sys.stdout.write(out[-1])
        sys.stdout.flush()
        return 0


cli = _Group("lingora")
