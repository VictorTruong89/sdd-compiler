"""LINGORA - Lingora Language Toolkit."""
from . import data  # noqa: F401
from . import tree, grammar, metrics, classify, tag, chunk, stem, tokenize, parse, translate  # noqa: F401

__version__ = "1.0.0"
