"""Stemmers."""
import re

from .porter import PorterStemmer
from .lancaster import LancasterStemmer
from .snowball import SnowballStemmer


class RegexpStemmer:
    def __init__(self, regexp, min=0):
        if not hasattr(regexp, "pattern"):
            regexp = re.compile(regexp)
        self._regexp = regexp
        self._min = min

    def stem(self, word):
        if len(word) < self._min:
            return word
        return self._regexp.sub("", word)


class WordNetLemmatizer:
    def __init__(self):
        from .. import data
        data.find("corpora/wordnet")

    def lemmatize(self, word, pos="n"):
        from .. import data
        data.find("corpora/wordnet")
        raise NotImplementedError("WordNet lemmatization is outside the specified surface")


class _ArabicUnavailable:
    def __init__(self, *a, **k):
        pass

    def stem(self, word):
        return word


class ARLSTem(_ArabicUnavailable):
    pass


class ARLSTem2(_ArabicUnavailable):
    pass


__all__ = ["ARLSTem", "ARLSTem2", "LancasterStemmer", "PorterStemmer", "RegexpStemmer",
           "SnowballStemmer", "WordNetLemmatizer"]
