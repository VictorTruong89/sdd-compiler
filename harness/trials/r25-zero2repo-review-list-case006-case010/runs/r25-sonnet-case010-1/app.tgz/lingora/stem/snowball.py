"""Snowball stemmers. English (Porter2) and Porter are implemented in full."""
import os

from .. import data
from .porter import PorterStemmer

LANGUAGES = ("arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian",
             "italian", "norwegian", "porter", "portuguese", "romanian", "russian", "spanish",
             "swedish")

_SPECIAL = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
}
_POST_1A = ("inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed")
_VOWELS = "aeiouy"
_DOUBLES = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
_LI = "cdeghkmnrt"
_STEP2 = (
    ("ization", "ize"), ("ational", "ate"), ("fulness", "ful"), ("ousness", "ous"),
    ("iveness", "ive"), ("tional", "tion"), ("biliti", "ble"), ("lessli", "less"),
    ("entli", "ent"), ("ation", "ate"), ("alism", "al"), ("aliti", "al"), ("ousli", "ous"),
    ("iviti", "ive"), ("fulli", "ful"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"),
    ("izer", "ize"), ("ator", "ate"), ("alli", "al"), ("bli", "ble"), ("ogi", "og"),
    ("li", ""),
)
_STEP3 = (
    ("ational", "ate"), ("tional", "tion"), ("alize", "al"), ("icate", "ic"), ("iciti", "ic"),
    ("ative", ""), ("ical", "ic"), ("ness", ""), ("ful", ""),
)
_STEP4 = ("ement", "ance", "ence", "able", "ible", "ment", "ant", "ent", "ism", "ate", "iti",
          "ous", "ive", "ize", "ion", "al", "er", "ic")


def _is_vowel(w, i):
    return w[i] in _VOWELS


def _regions(word):
    r1 = len(word)
    for pre in ("gener", "commun", "arsen"):
        if word.startswith(pre):
            r1 = len(pre)
            break
    else:
        for i in range(1, len(word)):
            if word[i] not in _VOWELS and word[i - 1] in _VOWELS:
                r1 = i + 1
                break
    r2 = len(word)
    for i in range(r1 + 1, len(word)):
        if word[i] not in _VOWELS and word[i - 1] in _VOWELS:
            r2 = i + 1
            break
    return r1, r2


def _ends_short_syllable(w):
    n = len(w)
    if n == 2:
        return w[0] in _VOWELS and w[1] not in _VOWELS
    if n >= 3:
        return (w[-3] not in _VOWELS and w[-2] in _VOWELS and w[-1] not in _VOWELS
                and w[-1] not in "wxY")
    return False


def _english_stem(word):
    if len(word) <= 2:
        return word
    if word in _SPECIAL:
        return _SPECIAL[word]
    if word.startswith("'"):
        word = word[1:]
    if len(word) <= 2:
        return word
    if word[0] == "y":
        word = "Y" + word[1:]
    chars = list(word)
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _VOWELS:
            chars[i] = "Y"
    word = "".join(chars)
    r1, r2 = _regions(word)

    def in_r1(suf):
        return len(word) - len(suf) >= r1

    def in_r2(suf):
        return len(word) - len(suf) >= r2

    # step 0
    for suf in ("'s'", "'s", "'"):
        if word.endswith(suf):
            word = word[:-len(suf)]
            break
    # step 1a
    if word.endswith("sses"):
        word = word[:-2]
    elif word.endswith("ied") or word.endswith("ies"):
        word = word[:-3] + ("i" if len(word) > 4 else "ie")
    elif word.endswith("us") or word.endswith("ss"):
        pass
    elif word.endswith("s"):
        if any(c in _VOWELS for c in word[:-2]):
            word = word[:-1]
    if word in _POST_1A:
        return word
    # step 1b
    for suf in ("eedly", "ingly", "edly", "eed", "ing", "ed"):
        if word.endswith(suf):
            if suf in ("eed", "eedly"):
                if in_r1(suf):
                    word = word[:-len(suf)] + "ee"
            else:
                pre = word[:-len(suf)]
                if any(c in _VOWELS for c in pre):
                    word = pre
                    if word.endswith(("at", "bl", "iz")):
                        word += "e"
                    elif word.endswith(_DOUBLES):
                        word = word[:-1]
                    elif r1 >= len(word) and _ends_short_syllable(word):
                        word += "e"
            break
    # step 1c
    if len(word) > 2 and word[-1] in "yY" and word[-2] not in _VOWELS:
        word = word[:-1] + "i"
    # step 2
    for suf, rep in _STEP2:
        if word.endswith(suf):
            if in_r1(suf):
                if suf == "ogi":
                    if word[:-3].endswith("l"):
                        word = word[:-3] + "og"
                elif suf == "li":
                    if len(word) > 2 and word[-3] in _LI:
                        word = word[:-2]
                else:
                    word = word[:-len(suf)] + rep
            break
    # step 3
    for suf, rep in _STEP3:
        if word.endswith(suf):
            if in_r1(suf):
                if suf == "ative":
                    if in_r2(suf):
                        word = word[:-5]
                else:
                    word = word[:-len(suf)] + rep
            break
    # step 4
    for suf in _STEP4:
        if word.endswith(suf):
            if in_r2(suf):
                if suf == "ion":
                    if word[:-3].endswith(("s", "t")):
                        word = word[:-3]
                else:
                    word = word[:-len(suf)]
            break
    # step 5
    if word.endswith("e"):
        if in_r2("e") or (in_r1("e") and not _ends_short_syllable(word[:-1])):
            word = word[:-1]
    elif word.endswith("l"):
        if in_r2("l") and word[:-1].endswith("l"):
            word = word[:-1]
    return word.replace("Y", "y")


class SnowballStemmer:
    languages = LANGUAGES

    def __init__(self, language, ignore_stopwords=False):
        if language not in LANGUAGES:
            raise ValueError("The language '%s' is not supported." % (language,))
        self.language = language
        self.stopwords = set()
        if ignore_stopwords:
            fp = data.find("corpora/stopwords/%s" % language)
            with open(fp, encoding="utf-8") as f:
                self.stopwords = {w.strip() for w in f.read().splitlines() if w.strip()}
        self._porter = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM) if language == "porter" else None

    def stem(self, word):
        word = word.lower()
        if word in self.stopwords:
            return word
        if self.language == "english":
            return _english_stem(word)
        if self.language == "porter":
            if len(word) <= 2:
                return word
            return self._porter.stem(word, to_lowercase=False)
        raise NotImplementedError(
            "Snowball stemming for %r is not implemented in this build" % self.language)
