"""Punkt sentence boundary detection (Kiss & Strunk 2006)."""
import os
import re

from . import data

_ORTHO_BEG_UC, _ORTHO_MID_UC, _ORTHO_UNK_UC = 2, 4, 8
_ORTHO_BEG_LC, _ORTHO_MID_LC, _ORTHO_UNK_LC = 16, 32, 64
_ORTHO_UC = _ORTHO_BEG_UC | _ORTHO_MID_UC | _ORTHO_UNK_UC
_ORTHO_LC = _ORTHO_BEG_LC | _ORTHO_MID_LC | _ORTHO_UNK_LC

_NONWORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_MULTI = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORDSTART = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_WORD_RE = re.compile(
    r"(%(M)s|(?=%(W)s)\S+?(?=\s|$|%(N)s|%(M)s|,(?=$|\s|%(N)s|%(M)s))|\S)" % {"M": _MULTI, "W": _WORDSTART, "N": _NONWORD},
    re.UNICODE | re.VERBOSE)
_PERIOD_CONTEXT = re.compile(
    r"\S*[.?!](?=(?P<after_tok>%s|\s+(?P<next_tok>\S+)))" % _NONWORD, re.UNICODE)
_REALIGN = re.compile(r"[\"')\]}]+?(?:\s+|(?=--)|$)", re.MULTILINE)
_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_ELLIPSIS = re.compile(r"\.\.+$")
_INITIAL = re.compile(r"[^\W\d]\.$")
_ALPHA = re.compile(r"[^\W\d]+$")
_NON_PUNCT = re.compile(r"[^\W\d]")
_PUNCT = tuple(";:,.!?")


class _Tok:
    __slots__ = ("tok", "type", "period_final", "sentbreak", "abbr", "ellipsis", "parastart", "linestart")

    def __init__(self, tok, parastart=False, linestart=False):
        self.tok = tok
        self.type = _NUMERIC.sub("##number##", tok.lower())
        self.period_final = tok.endswith(".")
        self.sentbreak = self.abbr = self.ellipsis = False
        self.parastart = parastart
        self.linestart = linestart

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        return self.type_no_period if self.sentbreak else self.type

    @property
    def first_upper(self):
        return self.tok[0].isupper()

    @property
    def first_lower(self):
        return self.tok[0].islower()

    @property
    def is_ellipsis(self):
        return bool(_ELLIPSIS.match(self.tok))

    @property
    def is_initial(self):
        return bool(_INITIAL.match(self.tok))


class PunktParameters:
    def __init__(self):
        self.abbrev_types = set()
        self.collocations = set()
        self.sent_starters = set()
        self.ortho_context = {}


def load_parameters(language):
    d = data.find("tokenizers/punkt_tab/%s" % language)
    p = PunktParameters()

    def lines(name):
        fp = os.path.join(d, name)
        if not os.path.exists(fp):
            return []
        with open(fp, encoding="utf-8") as f:
            return f.read().splitlines()

    p.abbrev_types = {l for l in lines("abbrev_types.txt") if l}
    p.sent_starters = {l for l in lines("sent_starters.txt") if l}
    for l in lines("collocations.tab"):
        parts = l.split("\t")
        if len(parts) >= 2:
            p.collocations.add((parts[0], parts[1]))
    for l in lines("ortho_context.tab"):
        parts = l.split("\t")
        if len(parts) >= 2:
            try:
                p.ortho_context[parts[0]] = int(parts[1])
            except ValueError:
                pass
    return p


class PunktSentenceTokenizer:
    def __init__(self, params):
        self._p = params

    @classmethod
    def for_language(cls, language="english"):
        return cls(load_parameters(language))

    # -- word-level -----------------------------------------------------
    @staticmethod
    def _tokenize_words(text):
        parastart = False
        for line in text.split("\n"):
            if line.strip():
                toks = iter(_WORD_RE.findall(line))
                try:
                    first = next(toks)
                except StopIteration:
                    continue
                yield _Tok(first, parastart=parastart, linestart=True)
                parastart = False
                for t in toks:
                    yield _Tok(t)
            else:
                parastart = True

    def _first_pass(self, toks):
        for t in toks:
            tok = t.tok
            if tok in (".", "?", "!"):
                t.sentbreak = True
            elif t.is_ellipsis:
                t.ellipsis = True
            elif t.period_final and not tok.endswith(".."):
                if tok[:-1].lower() in self._p.abbrev_types or \
                        tok[:-1].lower().split("-")[-1] in self._p.abbrev_types:
                    t.abbr = True
                else:
                    t.sentbreak = True
            yield t

    def _ortho_heuristic(self, t):
        if t.tok in _PUNCT:
            return False
        oc = self._p.ortho_context.get(t.type_no_sentperiod, 0)
        if t.first_upper and (oc & _ORTHO_LC) and not (oc & _ORTHO_MID_UC):
            return True
        if t.first_lower and ((oc & _ORTHO_UC) or not (oc & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, toks):
        toks = list(toks)
        for i, t1 in enumerate(toks):
            t2 = toks[i + 1] if i + 1 < len(toks) else None
            self._second(t1, t2)
        return toks

    def _second(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        initial = t1.is_initial
        if (typ, next_typ) in self._p.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not initial:
            if self._ortho_heuristic(t2) is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self._p.sent_starters:
                t1.sentbreak = True
                return
        if initial or typ == "##number##":
            h = self._ortho_heuristic(t2)
            if h is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if (h == "unknown" and initial and t2.first_upper
                    and not (self._p.ortho_context.get(next_typ, 0) & _ORTHO_LC)):
                t1.sentbreak = False
                t1.abbr = True

    def _contains_sentbreak(self, text):
        toks = self._second_pass(self._first_pass(self._tokenize_words(text)))
        found = False
        for t in toks:
            if found:
                return True
            if t.sentbreak:
                found = True
        return False

    # -- sentence-level -------------------------------------------------
    @staticmethod
    def _last_ws_index(s):
        for i in range(len(s) - 1, -1, -1):
            if s[i].isspace():
                return i
        return None

    def _potential_ends(self, text):
        prev_slice = (0, 0)
        prev_match = None
        for match in _PERIOD_CONTEXT.finditer(text):
            before = text[prev_slice[1]:match.start()]
            idx = self._last_ws_index(before)
            if idx:
                idx += prev_slice[1] + 1
            else:
                idx = prev_slice[0]
            cur_slice = (idx, match.start())
            if prev_match is not None and prev_slice[1] <= cur_slice[0]:
                yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")
            prev_match = match
            prev_slice = cur_slice
        if prev_match is not None:
            yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")

    def _slices(self, text):
        last = 0
        for match, context in self._potential_ends(text):
            if self._contains_sentbreak(context):
                yield (last, match.end())
                if match.group("next_tok"):
                    last = match.start("next_tok")
                else:
                    last = match.end()
        yield (last, len(text.rstrip()))

    def span_tokenize(self, text, realign_boundaries=True):
        slices = list(self._slices(text))
        if realign_boundaries:
            slices = self._realign(text, slices)
        return slices

    def _realign(self, text, slices):
        out = []
        realign = 0
        for i, s1 in enumerate(slices):
            s2 = slices[i + 1] if i + 1 < len(slices) else None
            s1 = (s1[0] + realign, s1[1])
            if s2 is None:
                if text[s1[0]:s1[1]]:
                    out.append(s1)
                continue
            m = _REALIGN.match(text[s2[0]:s2[1]])
            if m:
                out.append((s1[0], s2[0] + len(m.group(0).rstrip())))
                realign = m.end()
            else:
                realign = 0
                if text[s1[0]:s1[1]]:
                    out.append(s1)
        return out

    def tokenize(self, text, realign_boundaries=True):
        return [text[a:b] for a, b in self.span_tokenize(text, realign_boundaries)]
