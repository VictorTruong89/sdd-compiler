"""Context-free grammars."""
import re


class Nonterminal:
    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and self._symbol == other._symbol

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(("NT", self._symbol))

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "%s" % (self._symbol,)


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def is_lexical(self):
        return all(not isinstance(s, Nonterminal) for s in self._rhs)

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = []
        for s in self._rhs:
            parts.append(str(s) if isinstance(s, Nonterminal) else repr(s))
        return "%s -> %s" % (self._lhs, " ".join(parts))

    __repr__ = __str__


_TOKEN_RE = re.compile(r"""'[^']*'|"[^"]*"|\||[^\s|'"]+""")


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None):
        ps = self._productions
        if lhs is not None:
            ps = [p for p in ps if p.lhs() == lhs]
        if rhs is not None:
            ps = [p for p in ps if p.rhs() and p.rhs()[0] == rhs]
        return list(ps)

    def terminals(self):
        out = set()
        for p in self._productions:
            for s in p.rhs():
                if not isinstance(s, Nonterminal):
                    out.add(s)
        return out

    def check_coverage(self, tokens):
        terms = self.terminals()
        missing = [t for t in tokens if t not in terms]
        if missing:
            raise ValueError("Grammar does not cover some of the input words: %r." % (
                ", ".join(repr(m) for m in missing),))

    @classmethod
    def fromstring(cls, input):
        if isinstance(input, (list, tuple)):
            lines = list(input)
        else:
            lines = str(input).splitlines()
        productions = []
        last_lhs = None
        for raw in lines:
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("|"):
                if last_lhs is None:
                    raise ValueError("Unable parse line %r: continuation without production" % raw)
                lhs = last_lhs
                rhs_text = line
            else:
                m = re.match(r"^(\S+?)\s*(?:->|→)\s*(.*)$", line)
                if not m:
                    raise ValueError("Unable to parse line %r: expected '->'" % raw)
                lhs = Nonterminal(m.group(1))
                last_lhs = lhs
                rhs_text = m.group(2)
            alts = [[]]
            for tok in _TOKEN_RE.findall(rhs_text):
                if tok == "|":
                    alts.append([])
                elif tok[0] in "'\"":
                    if len(tok) < 2 or tok[-1] != tok[0]:
                        raise ValueError("Unbalanced quote in %r" % raw)
                    alts[-1].append(tok[1:-1])
                else:
                    alts[-1].append(Nonterminal(tok))
            if line.startswith("|") and alts and alts[0] == [] and len(alts) > 1:
                alts = alts[1:]
            for a in alts:
                productions.append(Production(lhs, a))
        if not productions:
            raise ValueError("No productions found")
        return cls(productions[0].lhs(), productions)

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n" % (len(self._productions), self._start) + \
            "\n".join("    %s" % p for p in self._productions)

    __repr__ = __str__
