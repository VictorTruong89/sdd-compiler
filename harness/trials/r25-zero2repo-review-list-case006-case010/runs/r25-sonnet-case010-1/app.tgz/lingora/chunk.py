"""Regular-expression chunking."""
import re

from .tree import Tree

ROOT = "S"


def _tag_pattern_to_regex(pattern):
    p = re.sub(r"\s", "", pattern)
    p = p.replace("<", "(<(").replace(">", ")>)")
    p = re.sub(r"([^\\])\.", r"\1[^\{\}<>]", p)
    p = re.sub(r"^\.", r"[^\{\}<>]", p)
    return p


class _Rule:
    def __init__(self, kind, pattern):
        self.kind = kind
        self.pattern = pattern
        rx = _tag_pattern_to_regex(pattern)
        try:
            if kind == "chunk":
                self.regex = re.compile(r"(?P<x>%s)(?=[^\}]*(\{|$))" % rx)
                self.repl = r"{\g<x>}"
            else:
                self.regex = re.compile(r"(?P<x>%s)(?=[^\{]*\})" % rx)
                self.repl = r"}\g<x>{"
        except re.error as e:
            raise ValueError("bad tag pattern %r: %s" % (pattern, e))

    def apply(self, s):
        s = self.regex.sub(self.repl, s)
        return s.replace("{}", "")


class RegexpChunkParser:
    """One stage: a clause label with its rules."""

    def __init__(self, rules, chunk_label="NP", root_label=ROOT):
        self._rules = list(rules)
        self._label = chunk_label
        self._root = root_label

    def parse(self, tagged):
        items = list(tagged)
        return Tree(self._root, self._chunk(items))

    def _chunk(self, items):
        if not items:
            return []
        tags = []
        for it in items:
            tag = it.label() if isinstance(it, Tree) else it[1]
            if re.search(r"[<>{}]", str(tag)):
                raise ValueError("Bad tag %r: must not contain <, >, { or }" % (tag,))
            tags.append(str(tag))
        s = "".join("<%s>" % t for t in tags)
        for rule in self._rules:
            s = rule.apply(s)
        out = []
        stack = [out]
        idx = 0
        for m in re.finditer(r"\{|\}|<[^<>{}]*>", s):
            t = m.group()
            if t == "{":
                new = []
                stack.append(new)
            elif t == "}":
                done = stack.pop()
                if done:
                    stack[-1].append(Tree(self._label, done))
            else:
                stack[-1].append(items[idx])
                idx += 1
        return out


def _strip_comment(line):
    depth = 0
    for i, ch in enumerate(line):
        if ch == "<":
            depth += 1
        elif ch == ">":
            depth = max(0, depth - 1)
        elif ch == "#" and depth == 0 and (i == 0 or line[i - 1].isspace()):
            return line[:i]
    return line


def _parse_grammar(text):
    stages = []
    cur = None
    for raw in text.split("\n"):
        line = _strip_comment(raw).strip()
        if not line:
            continue
        m = re.match(r"^([^\s:<>{}]+)\s*:\s*(.*)$", line)
        if m and not raw[:1].isspace():
            cur = (m.group(1), [])
            stages.append(cur)
            rule = m.group(2).strip()
        elif m and cur is None:
            cur = (m.group(1), [])
            stages.append(cur)
            rule = m.group(2).strip()
        else:
            if cur is None:
                raise ValueError("Illegal chunk grammar line: %r" % raw)
            rule = line
        if not rule:
            continue
        if rule.startswith("{") and rule.endswith("}") and len(rule) >= 2:
            cur[1].append(_Rule("chunk", rule[1:-1]))
        elif rule.startswith("}") and rule.endswith("{") and len(rule) >= 2:
            cur[1].append(_Rule("chink", rule[1:-1]))
        else:
            raise ValueError("Illegal chunk pattern: %r" % rule)
    return stages


class RegexpParser:
    def __init__(self, grammar, root_label=ROOT):
        self._root = root_label
        if isinstance(grammar, str):
            self._stages = [RegexpChunkParser(rules, label, root_label)
                            for label, rules in _parse_grammar(grammar)]
        elif isinstance(grammar, (list, tuple)):
            for st in grammar:
                if not isinstance(st, RegexpChunkParser):
                    raise TypeError("grammar must be a string or a list of chunk-parser stages")
            self._stages = list(grammar)
        else:
            raise TypeError("grammar must be a string or a list of chunk-parser stages, not %s"
                            % type(grammar).__name__)

    def parse(self, tagged):
        items = list(tagged)
        for st in self._stages:
            items = st._chunk(items)
        return Tree(self._root, items)


def ne_chunk(tagged_tokens, binary=False):
    from . import data
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    raise NotImplementedError("the named-entity chunker model cannot be evaluated by this implementation")
