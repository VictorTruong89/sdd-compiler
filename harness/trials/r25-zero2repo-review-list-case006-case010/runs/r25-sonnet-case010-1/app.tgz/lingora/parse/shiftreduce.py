from ..grammar import Nonterminal
from ..tree import Tree


class ShiftReduceParser:
    def __init__(self, grammar):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        tokens = list(tokens)
        self._grammar.check_coverage(tokens)
        return iter(self._parse(tokens))

    def _parse(self, tokens):
        stack = []
        remaining = list(tokens)
        while remaining:
            stack.append(remaining.pop(0))
            while self._reduce(stack):
                pass
        if len(stack) != 1:
            return []
        top = stack[0]
        if not isinstance(top, Tree) or top.label() != str(self._grammar.start()):
            return []
        return [top]

    def _reduce(self, stack):
        for prod in self._grammar.productions():
            rhs = prod.rhs()
            n = len(rhs)
            if n == 0 or n > len(stack):
                continue
            top = stack[-n:]
            ok = True
            for elt, item in zip(rhs, top):
                if isinstance(elt, Nonterminal):
                    if not (isinstance(item, Tree) and item.label() == str(elt)):
                        ok = False
                        break
                elif isinstance(item, Tree) or item != elt:
                    ok = False
                    break
            if ok:
                stack[-n:] = [Tree(str(prod.lhs()), top)]
                return prod
        return None
