from ..grammar import Nonterminal
from ..tree import Tree


class ChartParser:
    """Exhaustive parser: returns every parse tree of the token list."""

    def __init__(self, grammar):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        tokens = list(tokens)
        self._grammar.check_coverage(tokens)
        return iter(self._parse(tokens))

    def _parse(self, tokens):
        g = self._grammar
        n = len(tokens)
        prods = g.productions()
        by_lhs = {}
        for p in prods:
            by_lhs.setdefault(p.lhs(), []).append(p)
        can = set()  # (nonterminal, i, j)

        def seq_can(rhs, k, i, j):
            if k == len(rhs):
                return i == j
            s = rhs[k]
            if isinstance(s, Nonterminal):
                for m in range(i, j + 1):
                    if (s, i, m) in can and seq_can(rhs, k + 1, m, j):
                        return True
                return False
            if s == "":
                return seq_can(rhs, k + 1, i, j)
            return i < j and tokens[i] == s and seq_can(rhs, k + 1, i + 1, j)

        changed = True
        while changed:
            changed = False
            for p in prods:
                for i in range(n + 1):
                    for j in range(i, n + 1):
                        key = (p.lhs(), i, j)
                        if key not in can and seq_can(p.rhs(), 0, i, j):
                            can.add(key)
                            changed = True

        def trees(sym, i, j, active):
            key = (sym, i, j)
            if key not in can or key in active:
                return
            act = active | {key}
            for p in by_lhs.get(sym, []):
                for kids in seq(p.rhs(), 0, i, j, act):
                    yield Tree(str(sym), kids)

        def seq(rhs, k, i, j, active):
            if k == len(rhs):
                if i == j:
                    yield []
                return
            s = rhs[k]
            if isinstance(s, Nonterminal):
                for m in range(i, j + 1):
                    if (s, i, m) in can:
                        for t in trees(s, i, m, active):
                            for rest in seq(rhs, k + 1, m, j, active):
                                yield [t] + rest
            elif s == "":
                yield from seq(rhs, k + 1, i, j, active)
            elif i < j and tokens[i] == s:
                for rest in seq(rhs, k + 1, i + 1, j, active):
                    yield [s] + rest

        yield from trees(g.start(), 0, n, frozenset())
