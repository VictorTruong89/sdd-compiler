"""Locate packaged resources through ``data.path``."""
import os

path = [
    os.path.join(os.path.expanduser("~"), "lingora_data"),
    "/usr/share/lingora_data",
    "/usr/local/share/lingora_data",
    "/app/lingora_data",
]


def find(resource):
    """Return the filesystem path of ``resource`` found in a directory of ``path``.

    Raises LookupError when it is not visible."""
    for d in list(path):
        p = os.path.join(str(d), *resource.rstrip("/").split("/"))
        if os.path.exists(p):
            return p
    raise LookupError("Resource %r not found in data.path %r" % (resource, list(path)))


def read_lines(filepath):
    with open(filepath, encoding="utf-8") as f:
        text = f.read()
    return text.splitlines()
