"""Tokenizers."""
import html
import re

from .punkt import PunktSentenceTokenizer


class TokenizerI:
    def tokenize(self, text):
        raise NotImplementedError

    def span_tokenize(self, text):
        raise NotImplementedError


class RegexpTokenizer(TokenizerI):
    def __init__(self, pattern, gaps=False, discard_empty=True, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._regexp = re.compile(pattern, flags)

    def tokenize(self, text):
        if self._gaps:
            toks = self._regexp.split(text)
            return [t for t in toks if t] if self._discard_empty else toks
        return self._regexp.findall(text)

    def span_tokenize(self, text):
        if self._gaps:
            pos = 0
            for m in self._regexp.finditer(text):
                if m.start() != pos or not self._discard_empty:
                    if not (self._discard_empty and m.start() == pos):
                        yield (pos, m.start())
                pos = m.end()
            if pos != len(text) or not self._discard_empty:
                if not (self._discard_empty and pos == len(text)):
                    yield (pos, len(text))
        else:
            for m in self._regexp.finditer(text):
                yield m.span()


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


_wp = WordPunctTokenizer()
_bl = RegexpTokenizer(r"\s*\n\s*\n\s*", gaps=True)


def wordpunct_tokenize(text):
    return _wp.tokenize(text)


def blankline_tokenize(text):
    return _bl.tokenize(text)


class BlanklineTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True)


# ---------------------------------------------------------------- Treebank

class TreebankWordTokenizer(TokenizerI):
    STARTING_QUOTES = [
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile(r'"'), " '' "),
        (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(p) for p in (
        r"(?i)\b(can)(?#X)(not)\b", r"(?i)\b(d)(?#X)('ye)\b", r"(?i)\b(gim)(?#X)(me)\b",
        r"(?i)\b(gon)(?#X)(na)\b", r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = [re.compile(p) for p in (r"(?i) ('t)(?#X)(is)\b", r"(?i) ('t)(?#X)(was)\b")]

    def tokenize(self, text):
        for rx, sub in self.STARTING_QUOTES:
            text = rx.sub(sub, text)
        for rx, sub in self.PUNCTUATION:
            text = rx.sub(sub, text)
        rx, sub = self.PARENS_BRACKETS
        text = rx.sub(sub, text)
        rx, sub = self.DOUBLE_DASHES
        text = rx.sub(sub, text)
        text = " " + text + " "
        for rx, sub in self.ENDING_QUOTES:
            text = rx.sub(sub, text)
        for rx in self.CONTRACTIONS2:
            text = rx.sub(r" \1 \2 ", text)
        for rx in self.CONTRACTIONS3:
            text = rx.sub(r" \1 \2 ", text)
        return text.split()


class _ImprovedWordTokenizer(TokenizerI):
    STARTING_QUOTES = [
        (re.compile("([«“‘„]|[`]+)", re.U), r" \1 "),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
        (re.compile(r"(?i)(\')(?!re|ve|ll|m|t|s|d|n)(\w)\b", re.U), r"\1 \2"),
    ]
    PUNCTUATION = [
        (re.compile(r'([^\.])(\.)([\]\)}>"\'' "»”’ " r"]*)\s*$", re.U), r"\1 \2 \3 "),
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}", re.U), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*]", re.U), r" \g<0> "),
        (re.compile("[‒–—―]"), r" \g<0> "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile("([»”’])", re.U), r" \1 "),
        (re.compile(r"''"), " '' "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(p) for p in (
        r"(?i)\b(d)(?#X)('ye)\b", r"(?i)\b(gim)(?#X)(me)\b",
        r"(?i)\b(gon)(?#X)(na)\b", r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
        r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)")]
    CONTRACTIONS3 = TreebankWordTokenizer.CONTRACTIONS3

    def tokenize(self, text):
        for rx, sub in self.STARTING_QUOTES:
            text = rx.sub(sub, text)
        for rx, sub in self.PUNCTUATION:
            text = rx.sub(sub, text)
        rx, sub = self.PARENS_BRACKETS
        text = rx.sub(sub, text)
        rx, sub = self.DOUBLE_DASHES
        text = rx.sub(sub, text)
        text = " " + text + " "
        for rx, sub in self.ENDING_QUOTES:
            text = rx.sub(sub, text)
        for rx in self.CONTRACTIONS2:
            text = rx.sub(r" \1 \2 ", text)
        for rx in self.CONTRACTIONS3:
            text = rx.sub(r" \1 \2 ", text)
        return text.split()


_improved = _ImprovedWordTokenizer()


def sent_tokenize(text, language="english"):
    return PunktSentenceTokenizer.for_language(language).tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    return [tok for sent in sentences for tok in _improved.tokenize(sent)]


# ------------------------------------------------------------------ Tweets

_EMOTICONS = r"""(?:[<>]?[:;=8][\-o\*\']?[\)\]\(\[dDpP/\:\}\{@\|\\]|[\)\]\(\[dDpP/\:\}\{@\|\\][\-o\*\']?[:;=8][<>]?|<3)"""
_URLS = r"""(?:https?://[^\s<>"]+|www\.[^\s<>"]+)"""
_PHONE = r"""(?:(?:\+?[01][\-\s.]*)?(?:[\(]?\d{3}[\-\s.\)]*)?\d{3}[\-\s.]*\d{4})"""
_WORD_PATTERNS = [
    _EMOTICONS,
    _URLS,
    _PHONE,
    r"""(?:<[^>\s]+>)""",
    r"""(?:[\-]+>|<[\-]+)""",
    r"""(?:@[\w_]+)""",
    r"""(?:\#+[\w_]+[\w\'_\-]*[\w_]+)""",
    r"""[\w.+-]+@[\w-]+\.(?:[\w-]\.?)+[\w-]""",
    r"""(?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])""",
    r"""(?:[+\-]?\d+[,/.:-]\d+[+\-]?)""",
    r"""(?:[\w_]+)""",
    r"""(?:\.(?:\s*\.){1,})""",
    r"""(?:\S)""",
]
_TWEET_RE = re.compile("(%s)" % "|".join(_WORD_PATTERNS), re.I | re.UNICODE)
_EMOTICON_RE = re.compile(_EMOTICONS, re.I | re.UNICODE)
_HANDLE_RE = re.compile(r"(?<![A-Za-z0-9_])@[A-Za-z0-9_]{1,15}")
_LEN_RE = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer(TokenizerI):
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        text = html.unescape(text)
        if self.strip_handles:
            text = _HANDLE_RE.sub(" ", text)
        if self.reduce_len:
            text = _LEN_RE.sub(r"\1\1\1", text)
        words = [m.group(0) for m in _TWEET_RE.finditer(text)]
        if not self.preserve_case:
            words = [w if _EMOTICON_RE.fullmatch(w) else w.lower() for w in words]
        return words
