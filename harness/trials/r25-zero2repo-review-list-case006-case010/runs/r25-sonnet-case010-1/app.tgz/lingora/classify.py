"""Naive Bayes and decision tree classifiers."""
import math
from collections import Counter, defaultdict


class DictionaryProbDist:
    def __init__(self, prob_dict, normalize=False, log=False):
        self._prob = {}
        items = list(prob_dict.items())
        if log:
            if normalize and items:
                m = max(v for _, v in items)
                if m == -math.inf:
                    probs = [1.0 / len(items)] * len(items)
                else:
                    exps = [math.exp(v - m) for _, v in items]
                    tot = sum(exps)
                    probs = [e / tot for e in exps]
            else:
                probs = [math.exp(v) for _, v in items]
        else:
            probs = [v for _, v in items]
            if normalize and items:
                tot = sum(probs)
                probs = [p / tot for p in probs] if tot else [1.0 / len(items)] * len(items)
        for (k, _), p in zip(items, probs):
            self._prob[k] = float(p)

    def prob(self, sample):
        return float(self._prob.get(sample, 0.0))

    def logprob(self, sample):
        p = self.prob(sample)
        return math.log2(p) if p > 0 else -math.inf

    def samples(self):
        return list(self._prob.keys())

    def max(self):
        return max(self._prob, key=lambda k: self._prob[k])

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._prob)


class ClassifierI:
    def classify_many(self, featuresets):
        return [self.classify(fs) for fs in featuresets]


class NaiveBayesClassifier(ClassifierI):
    def __init__(self, label_probdist, feature_probdist):
        self._label_probdist = label_probdist
        self._feature_probdist = feature_probdist
        self._labels = list(label_probdist.keys())

    def labels(self):
        return list(self._labels)

    @classmethod
    def train(cls, labeled_featuresets):
        labeled_featuresets = list(labeled_featuresets)
        if not labeled_featuresets:
            raise ValueError("cannot train on an empty list")
        label_freq = Counter()
        feature_freq = defaultdict(Counter)
        feature_values = defaultdict(set)
        fnames = {}
        num_samples = len(labeled_featuresets)
        for featureset, label in labeled_featuresets:
            label_freq[label] += 1
            for fname, fval in featureset.items():
                feature_freq[label, fname][fval] += 1
                feature_values[fname].add(fval)
                fnames[fname] = True
        for label in list(label_freq):
            for fname in fnames:
                count = sum(feature_freq[label, fname].values())
                if num_samples - count > 0:
                    feature_freq[label, fname][None] += num_samples - count
                    feature_values[fname].add(None)
        # ELE estimates
        n_labels = sum(label_freq.values())
        b = len(label_freq)
        label_prob = {l: (c + 0.5) / (n_labels + 0.5 * b) for l, c in label_freq.items()}
        feature_prob = {}
        for (label, fname), freq in feature_freq.items():
            bins = len(feature_values[fname])
            feature_prob[label, fname] = (dict(freq), sum(freq.values()), bins)
        return cls(label_prob, feature_prob)

    def _fprob(self, label, fname, fval):
        freq, n, bins = self._feature_probdist[label, fname]
        return (freq.get(fval, 0) + 0.5) / (n + 0.5 * bins)

    def prob_classify(self, featureset):
        featureset = dict(featureset)
        for fname in list(featureset):
            if not any((label, fname) in self._feature_probdist for label in self._labels):
                del featureset[fname]
        logprob = {}
        for label in self._labels:
            logprob[label] = math.log(self._label_probdist[label])
            for fname, fval in featureset.items():
                if (label, fname) in self._feature_probdist:
                    logprob[label] += math.log(self._fprob(label, fname, fval))
                else:
                    logprob[label] += -math.inf
        return DictionaryProbDist(logprob, normalize=True, log=True)

    def classify(self, featureset):
        pd = self.prob_classify(featureset)
        return max(pd.samples(), key=lambda l: pd.prob(l))


def _entropy(labels):
    c = Counter(labels)
    n = sum(c.values())
    return -sum((v / n) * math.log2(v / n) for v in c.values()) if n else 0.0


def _majority(labels):
    return Counter(labels).most_common(1)[0][0]


class DecisionTreeClassifier(ClassifierI):
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions or {}
        self._default = default

    def labels(self):
        labels = [self._label]
        for d in self._decisions.values():
            labels.extend(d.labels())
        return list(dict.fromkeys(labels))

    def classify(self, featureset):
        fval = featureset.get(self._fname)
        if self._fname is not None and fval in self._decisions:
            return self._decisions[fval].classify(featureset)
        if self._fname is not None and self._default is not None:
            return self._default.classify(featureset)
        return self._label

    def error(self, labeled_featuresets):
        errors = sum(1 for fs, l in labeled_featuresets if self.classify(fs) != l)
        return errors / len(labeled_featuresets)

    @staticmethod
    def leaf(lfs):
        return DecisionTreeClassifier(_majority([l for _, l in lfs]))

    @staticmethod
    def stump(fname, lfs):
        label = _majority([l for _, l in lfs])
        groups = {}
        for fs, l in lfs:
            groups.setdefault(fs.get(fname), []).append(l)
        decisions = {v: DecisionTreeClassifier(_majority(ls)) for v, ls in groups.items()}
        return DecisionTreeClassifier(label, fname, decisions)

    @staticmethod
    def best_stump(feature_names, lfs):
        best = DecisionTreeClassifier.leaf(lfs)
        best_err = best.error(lfs)
        for fname in feature_names:
            st = DecisionTreeClassifier.stump(fname, lfs)
            err = st.error(lfs)
            if err < best_err:
                best, best_err = st, err
        return best

    def refine(self, lfs, entropy_cutoff, depth_cutoff, support_cutoff):
        if len(lfs) <= support_cutoff or self._fname is None or depth_cutoff <= 0:
            return
        for fval in list(self._decisions):
            sub = [(fs, l) for fs, l in lfs if fs.get(self._fname) == fval]
            if _entropy([l for _, l in sub]) > entropy_cutoff:
                self._decisions[fval] = DecisionTreeClassifier.train(
                    sub, entropy_cutoff, depth_cutoff, support_cutoff)

    @classmethod
    def train(cls, labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100, support_cutoff=10):
        labeled_featuresets = list(labeled_featuresets)
        if not labeled_featuresets:
            raise ValueError("cannot train on an empty list")
        names = {}
        for fs, _ in labeled_featuresets:
            for n in fs:
                names[n] = True
        tree = cls.best_stump(list(names), labeled_featuresets)
        tree.refine(labeled_featuresets, entropy_cutoff, depth_cutoff - 1, support_cutoff)
        return tree


def accuracy(classifier, gold):
    gold = list(gold)
    if not gold:
        return 0
    results = classifier.classify_many([fs for fs, _ in gold])
    return sum(1 for r, (_, l) in zip(results, gold) if r == l) / len(gold)
