import math
import sys
from collections import Counter


class Fraction:
    def __init__(self, numerator, denominator, _normalize=False):
        self.numerator = numerator
        self.denominator = denominator

    def __float__(self):
        return self.numerator / self.denominator

    def __repr__(self):
        return 'Fraction(%r, %r)' % (self.numerator, self.denominator)


def _ngrams(seq, n):
    return [tuple(seq[i:i + n]) for i in range(len(seq) - n + 1)]


def modified_precision(references, hypothesis, n):
    counts = Counter(_ngrams(hypothesis, n))
    max_counts = {}
    for ref in references:
        rc = Counter(_ngrams(ref, n))
        for ng in counts:
            max_counts[ng] = max(max_counts.get(ng, 0), rc[ng])
    clipped = {ng: min(c, max_counts.get(ng, 0)) for ng, c in counts.items()}
    return Fraction(sum(clipped.values()), max(1, sum(counts.values())))


def closest_ref_length(references, hyp_len):
    return min((len(r) for r in references), key=lambda l: (abs(l - hyp_len), l))


def brevity_penalty(closest, hyp_len):
    if hyp_len > closest:
        return 1
    if hyp_len == 0:
        return 0
    return math.exp(1 - closest / hyp_len)


class SmoothingFunction:
    def __init__(self, epsilon=0.1, alpha=5, k=5):
        self.epsilon = epsilon
        self.alpha = alpha
        self.k = k

    def method0(self, p_n, *a, **k):
        return [p if p.numerator != 0 else sys.float_info.min for p in p_n]

    def method1(self, p_n, *a, **k):
        return [(p.numerator + self.epsilon) / p.denominator if p.numerator == 0 else p for p in p_n]

    def method2(self, p_n, *a, **k):
        return [Fraction(p.numerator + 1, p.denominator + 1, _normalize=False) if i != 0 else p
                for i, p in enumerate(p_n)]


def sentence_bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    if isinstance(hypothesis, str) or any(isinstance(r, str) for r in references):
        raise TypeError("references and hypothesis must be token lists")
    weights = list(weights)
    nums, dens = [], []
    for i in range(1, len(weights) + 1):
        a, b = _frac(modified_precision(references, hypothesis, i))
        nums.append(a)
        dens.append(b)
    hyp_len = len(hypothesis)
    ref_len = closest_ref_length(references, hyp_len)
    bp = brevity_penalty(ref_len, hyp_len)
    if not nums or nums[0] == 0:
        return 0
    p_n = [Fraction(a, b, _normalize=False) for a, b in zip(nums, dens)]
    if smoothing_function is None:
        smoothing_function = SmoothingFunction().method0
    p_n = list(smoothing_function(p_n, references=references, hypothesis=hypothesis, hyp_len=hyp_len))
    s = math.fsum(w * math.log(float(p)) for w, p in zip(weights, p_n))
    return bp * math.exp(s)


def _frac(x):
    if isinstance(x, tuple):
        return x
    return x.numerator, x.denominator


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    return sentence_bleu(references, hypothesis, weights, smoothing_function)
