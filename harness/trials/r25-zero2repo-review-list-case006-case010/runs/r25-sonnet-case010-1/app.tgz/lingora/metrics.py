"""Evaluation metrics."""


def accuracy(reference, test):
    if not isinstance(reference, (list, tuple)) or not isinstance(test, (list, tuple)):
        reference, test = list(reference), list(test)
    if len(reference) != len(test):
        raise ValueError("Lists must have the same length.")
    if not reference:
        return 0.0
    return sum(1 for x, y in zip(reference, test) if x == y) / len(test)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    len1, len2 = len(s1), len(s2)
    if not transpositions:
        prev = list(range(len2 + 1))
        for i in range(1, len1 + 1):
            cur = [i] + [0] * len2
            for j in range(1, len2 + 1):
                sub = 0 if s1[i - 1] == s2[j - 1] else substitution_cost
                cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + sub)
            prev = cur
        return prev[len2]
    # unrestricted Damerau-Levenshtein (Lowrance & Wagner 1975)
    maxd = (len1 + len2) * max(1, substitution_cost) + 1
    d = [[maxd] * (len2 + 2) for _ in range(len1 + 2)]
    for i in range(len1 + 1):
        d[i + 1][1] = i
    for j in range(len2 + 1):
        d[1][j + 1] = j
    da = {}
    for i in range(1, len1 + 1):
        db = 0
        for j in range(1, len2 + 1):
            k = da.get(s2[j - 1], 0)
            l = db
            if s1[i - 1] == s2[j - 1]:
                cost = 0
                db = j
            else:
                cost = substitution_cost
            d[i + 1][j + 1] = min(d[i][j] + cost, d[i + 1][j] + 1, d[i][j + 1] + 1,
                                  d[k][l] + (i - k - 1) + 1 + (j - l - 1))
        da[s1[i - 1]] = i
    return d[len1 + 1][len2 + 1]


def jaccard_distance(label1, label2):
    union = len(label1 | label2)
    if union == 0:
        return 0.0
    return (union - len(label1 & label2)) / union


def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("reference and test must be sets")


def precision(reference, test):
    _check_sets(reference, test)
    if len(test) == 0:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    _check_sets(reference, test)
    if len(reference) == 0:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return 0
    return 1.0 / (alpha / p + (1 - alpha) / r)
