"""Part-of-speech taggers."""
import json
import os
import re
from collections import Counter, defaultdict

from . import data


class SequentialBackoffTagger:
    def __init__(self, backoff=None):
        self._backoff = backoff

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tag() expects a list of tokens, not a string")
        tags = []
        for i in range(len(tokens)):
            tags.append(self.tag_one(tokens, i, tags))
        return list(zip(tokens, tags))

    def tag_one(self, tokens, index, history):
        tag = None
        for tagger in self._taggers():
            tag = tagger.choose_tag(tokens, index, history)
            if tag is not None:
                break
        return tag

    def _taggers(self):
        t = self
        while t is not None:
            yield t
            t = t._backoff

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError


class DefaultTagger(SequentialBackoffTagger):
    def __init__(self, tag):
        SequentialBackoffTagger.__init__(self, None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class RegexpTagger(SequentialBackoffTagger):
    def __init__(self, regexps, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._regexps = [(re.compile(r), t) for r, t in regexps]

    def choose_tag(self, tokens, index, history):
        for rx, tag in self._regexps:
            if rx.match(tokens[index]):
                return tag
        return None


class ContextTagger(SequentialBackoffTagger):
    def __init__(self, train=None, model=None, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._context_to_tag = {} if model is None else dict(model)
        if train:
            self._train(train)

    def context(self, tokens, index, history):
        raise NotImplementedError

    def _train(self, tagged_corpus):
        counts = defaultdict(Counter)
        for sentence in tagged_corpus:
            tokens = [w for w, _ in sentence]
            history = []
            for i, (w, t) in enumerate(sentence):
                ctx = self.context(tokens, i, history)
                if ctx is not None:
                    counts[ctx][t] += 1
                history.append(t)
        for ctx, c in counts.items():
            self._context_to_tag[ctx] = c.most_common(1)[0][0]

    def choose_tag(self, tokens, index, history):
        ctx = self.context(tokens, index, history)
        if ctx is None:
            return None
        return self._context_to_tag.get(ctx)


class UnigramTagger(ContextTagger):
    def context(self, tokens, index, history):
        return tokens[index]


class NgramTagger(ContextTagger):
    _n = 2

    def context(self, tokens, index, history):
        n = self._n
        prev = tuple(history[max(0, index - n + 1):index])
        return (prev, tokens[index])


class BigramTagger(NgramTagger):
    _n = 2


class TrigramTagger(NgramTagger):
    _n = 3


class AffixTagger(ContextTagger):
    def __init__(self, train=None, model=None, affix_length=-3, min_stem_length=2, backoff=None):
        self._affix_length = affix_length
        self._min_word_length = min_stem_length + abs(affix_length)
        ContextTagger.__init__(self, train, model, backoff)

    def context(self, tokens, index, history):
        token = tokens[index]
        if len(token) < self._min_word_length:
            return None
        return token[self._affix_length:] if self._affix_length < 0 else token[:self._affix_length]


# ---- averaged perceptron tagger -------------------------------------------------

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


class PerceptronTagger:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = list(classes)

    @classmethod
    def load(cls, lang):
        d = data.find("taggers/averaged_perceptron_tagger_%s" % lang)
        base = os.path.join(d, "averaged_perceptron_tagger_%s" % lang)
        try:
            with open(base + ".weights.json", encoding="utf-8") as f:
                weights = json.load(f)
            with open(base + ".tagdict.json", encoding="utf-8") as f:
                tagdict = json.load(f)
            with open(base + ".classes.json", encoding="utf-8") as f:
                classes = json.load(f)
        except OSError as e:
            raise LookupError("averaged perceptron tagger resource for %r is incomplete: %s" % (lang, e))
        return cls(weights, tagdict, classes)

    def tag(self, tokens):
        prev, prev2 = _START
        output = []
        context = _START + [_normalize(w) for w in tokens] + _END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                feats = self._features(i, word, context, prev, prev2)
                tag = self.predict(feats)
            output.append((word, tag))
            prev2 = prev
            prev = tag
        return output

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    @staticmethod
    def _features(i, word, context, prev, prev2):
        features = defaultdict(int)

        def add(name, *args):
            features[" ".join((name,) + tuple(args))] += 1

        i += len(_START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return features


_RNC_TO_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ADV": "ADV", "NUM": "NUM", "PR": "ADP",
    "CONJ": "CONJ", "PART": "PRT", "INTJ": "X", "COM": "X", "NONLEX": ".",
    "SPRO": "PRON", "APRO": "DET", "ADVPRO": "ADV", "ANUM": "ADJ", "A-PRO": "DET",
    "S-PRO": "PRON", "ADV-PRO": "ADV", "A-NUM": "ADJ",
}


def pos_tag(tokens, tagset=None, lang="eng"):
    if isinstance(tokens, (str, bytes)) or not isinstance(tokens, (list, tuple)):
        raise TypeError("pos_tag expects a list of tokens, not %s" % type(tokens).__name__)
    if lang not in ("eng", "rus"):
        raise ValueError("Currently, NLTK pos_tag only supports English and Russian (i.e. lang='eng' or lang='rus')")
    tagger = PerceptronTagger.load(lang)
    tagged = tagger.tag(list(tokens))
    if tagset is None:
        return tagged
    if tagset != "universal":
        raise ValueError("unsupported tagset %r" % (tagset,))
    if lang == "rus":
        return [(w, _RNC_TO_UNIVERSAL.get(t.split("=")[0], "X")) for w, t in tagged]
    d = data.find("taggers/universal_tagset")
    mp = {}
    with open(os.path.join(d, "en-ptb.map"), encoding="utf-8") as f:
        for line in f.read().splitlines():
            parts = line.split("\t")
            if len(parts) >= 2:
                mp[parts[0]] = parts[1]
    return [(w, mp.get(t, "X")) for w, t in tagged]
