"""Parameters, invocation contexts, commands, and groups."""

import enum
import inspect
import os
import shutil
import sys
from collections.abc import Mapping
from contextlib import ExitStack, contextmanager
from functools import update_wrapper

from . import termui
from ._globals import get_current_context, pop_context, push_context
from .exceptions import (
    Abort,
    BadOptionUsage,
    BadParameter,
    Exit,
    FileError,
    MissingParameter,
    NoArgsIsHelp,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import HelpFormatter, make_default_short_help
from .paramtypes import BOOL, FLOAT, INT, STRING, Choice, ParamType, Path, File, Tuple, _convert_type  # noqa: F401
from .utils import format_filename  # noqa: F401


class ParameterSource(enum.Enum):
    """Where a parameter's value came from."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


class _Unset:
    def __repr__(self):
        return "UNSET"


class _NoValue:
    def __repr__(self):
        return "NO_VALUE"


_UNSET = _Unset()
_NO_VALUE = _NoValue()
CHAIN_MARK = object()  # value of ``invoked_subcommand`` on a chaining group


def _warn(message, ctx=None):
    termui.echo(f"DeprecationWarning: {message}", err=True)


def _note_text(deprecated, base):
    if isinstance(deprecated, str):
        return f"{base} {deprecated}"
    return base


# ---------------------------------------------------------------------------
# Context
# ---------------------------------------------------------------------------


class Context:
    """Per-invocation state: parsed values, parent link, author object, cleanup."""

    def __init__(
        self,
        command,
        parent=None,
        info_name=None,
        obj=None,
        default_map=None,
        auto_envvar_prefix=None,
        terminal_width=None,
        max_content_width=None,
        help_option_names=None,
        token_normalize_func=None,
        color=None,
        show_default=None,
        allow_extra_args=None,
        ignore_unknown_options=None,
        allow_interspersed_args=None,
        resilient_parsing=False,
    ):
        self.command = command
        self.parent = parent
        self.info_name = info_name
        settings = dict(getattr(command, "context_settings", None) or {})

        def pick(key, explicit, inherited, fallback):
            if explicit is not None:
                return explicit
            if key in settings and settings[key] is not None:
                return settings[key]
            if parent is not None and inherited:
                return getattr(parent, key)
            return fallback

        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.terminal_width = pick("terminal_width", terminal_width, True, None)
        self.max_content_width = pick("max_content_width", max_content_width, True, 80)
        self.help_option_names = list(pick("help_option_names", help_option_names, True, ["--help"]))
        self.token_normalize_func = pick("token_normalize_func", token_normalize_func, True, None)
        self.color = pick("color", color, True, None)
        self.show_default = bool(pick("show_default", show_default, True, False))
        self.allow_extra_args = bool(pick("allow_extra_args", allow_extra_args, False, command.allow_extra_args))
        self.ignore_unknown_options = bool(
            pick("ignore_unknown_options", ignore_unknown_options, False, False)
        )
        self.allow_interspersed_args = bool(
            pick("allow_interspersed_args", allow_interspersed_args, False, command.allow_interspersed_args)
        )
        self.resilient_parsing = resilient_parsing

        # Default map: explicit setting wins, otherwise the parent's nested entry.
        dm = settings.get("default_map") if default_map is None else default_map
        if dm is None and parent is not None and isinstance(parent.default_map, Mapping) and info_name is not None:
            dm = parent.default_map.get(info_name)
        self.default_map = dict(dm) if isinstance(dm, Mapping) else None

        # Automatic environment prefix.
        if auto_envvar_prefix is None:
            auto_envvar_prefix = settings.get("auto_envvar_prefix")
        if auto_envvar_prefix is None and parent is not None and parent.auto_envvar_prefix is not None:
            part = (info_name or "").upper().replace("-", "_")
            auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{part}"
        self.auto_envvar_prefix = auto_envvar_prefix

        self.params = {}
        self.args = []
        self.protected_args = []
        self.invoked_subcommand = None
        self._sources = {}
        self._declared = set()
        self._parsed = None
        self._help_option = None
        self._exit_stack = ExitStack()
        self._depth = 0

    # -- identity -----------------------------------------------------------
    @property
    def command_path(self):
        rpath = self.info_name or ""
        if self.parent is not None:
            rpath = f"{self.parent.command_path} {rpath}"
        return rpath.strip()

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    # -- entering the context --------------------------------------------------
    def __enter__(self):
        self._depth += 1
        push_context(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        self._depth -= 1
        pop_context()
        if self._depth == 0:
            self.close()
        return False

    @contextmanager
    def scope(self, cleanup=True):
        self._depth += 1
        push_context(self)
        try:
            yield self
        finally:
            self._depth -= 1
            pop_context()
            if cleanup and self._depth == 0:
                self.close()

    def close(self):
        stack = self._exit_stack
        self._exit_stack = ExitStack()
        stack.close()

    def call_on_close(self, func):
        self._exit_stack.callback(func)

    def with_resource(self, cm):
        return self._exit_stack.enter_context(cm)

    # -- values ---------------------------------------------------------------
    def lookup_default(self, name):
        if self.default_map is None or name not in self.default_map:
            return _UNSET
        value = self.default_map[name]
        if value is None:
            return _UNSET
        return value

    def get_parameter_source(self, name):
        if name not in self._declared:
            return None
        return self._sources.get(name)

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    # -- control --------------------------------------------------------------
    def fail(self, message):
        raise UsageError(message, self)

    def abort(self):
        raise Abort()

    def exit(self, code=0):
        raise Exit(code)

    def get_usage(self):
        formatter = HelpFormatter(width=self.get_help_width())
        self.command.format_usage(self, formatter)
        return formatter.getvalue().rstrip("\n")

    def get_help_hint(self):
        if not self.command.add_help_option or not self.help_option_names:
            return ""
        return f"Try '{self.command_path} {self.help_option_names[0]}' for help."

    def get_help_width(self):
        if self.terminal_width is not None:
            return self.terminal_width
        cols = shutil.get_terminal_size((80, 24)).columns
        return max(min(cols, self.max_content_width), 10)

    def get_help(self):
        formatter = HelpFormatter(width=self.get_help_width())
        self.command.format_help(self, formatter)
        return formatter.getvalue().rstrip("\n") + "\n"

    def invoke(self, callback, *args, **kwargs):
        """Call ``callback`` (a function or a Command) inside this context."""
        if isinstance(callback, Command):
            other = callback
            sub = Context(other, info_name=other.name, parent=self, default_map=None)
            for p in other.params:
                if p.expose_value and p.name not in kwargs:
                    kwargs[p.name] = p.get_default(sub)
            sub.params.update({k: v for k, v in kwargs.items()})
            if other.callback is None:
                return None
            with sub:
                return other.callback(*args, **kwargs)
        with self:
            return callback(*args, **kwargs)

    def forward(self, cmd, *args, **kwargs):
        values = dict(self.params)
        values.update(kwargs)
        return self.invoke(cmd, *args, **values)


# ---------------------------------------------------------------------------
# Parameters
# ---------------------------------------------------------------------------


def _split_decls(decls, is_option):
    """Return (dest_name, flag_names, secondary_flag_names) from declarations."""
    name = None
    opts = []
    secondary = []
    for decl in decls:
        if not decl:
            continue
        if not is_option or decl[0].isalnum() or decl[0] == "_":
            if name is not None:
                raise TypeError(f"Name '{name}' defined twice.")
            name = decl
            continue
        idx = decl.find("/", 1)
        if idx > 0:
            opts.append(decl[:idx])
            secondary.append(decl[idx + 1 :])
        else:
            opts.append(decl)
    return name, opts, secondary


def _infer_dest(opts):
    longs = [o for o in opts if len(o) > 2 and o[1] in "-/+" and o[0] in "-/+"]
    chosen = (longs or opts)[0]
    return chosen.lstrip("-/+").replace("-", "_")


class Parameter:
    """Base class for options and arguments."""

    param_type_name = "parameter"

    def __init__(
        self,
        name,
        type=None,
        required=False,
        default=None,
        callback=None,
        nargs=1,
        multiple=False,
        metavar=None,
        expose_value=True,
        is_eager=False,
        envvar=None,
        shell_complete=None,
        deprecated=False,
        help=None,
        hidden=False,
        show_default=None,
        show_envvar=False,
        allow_from_autoenv=True,
    ):
        self.name = name
        self.default = default
        self.callback = callback
        self.multiple = bool(multiple)
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.envvar = envvar
        self.shell_complete_func = shell_complete
        self.deprecated = deprecated
        self.help = help
        self.hidden = hidden
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.allow_from_autoenv = allow_from_autoenv
        self.required = bool(required)
        self.type = _convert_type(type, default)
        if isinstance(self.type, Tuple):
            nargs = len(self.type.types)
        self.nargs = nargs

    # -- helpers --------------------------------------------------------------
    def _env_names(self):
        if self.envvar is None:
            names = []
        elif isinstance(self.envvar, str):
            names = [self.envvar]
        else:
            names = list(self.envvar)
        return names

    def _auto_env_name(self, ctx):
        if not self.allow_from_autoenv or ctx.auto_envvar_prefix is None:
            return None
        return f"{ctx.auto_envvar_prefix}_{self.name}".upper().replace("-", "_")

    def _split_text(self, text):
        if isinstance(self.type, (File, Path)):
            return [t for t in text.split(os.pathsep) if t != ""]
        return text.split()

    def _shape_tokens(self, tokens):
        """Shape split tokens into the per-parameter raw form."""
        arity = self._token_arity()
        if self.multiple:
            if arity == 1:
                return list(tokens)
            return [tuple(tokens[i : i + arity]) for i in range(0, len(tokens), arity)]
        if self.nargs == 1 and not isinstance(self.type, Tuple):
            return tokens[0] if tokens else _UNSET
        return tuple(tokens)

    def _token_arity(self):
        return self.nargs if self.nargs and self.nargs > 0 else 1

    def _is_seq_shape(self):
        return self.multiple or self.nargs != 1 or isinstance(self.type, Tuple)

    def get_default(self, ctx):
        d = self.default
        if callable(d) and not isinstance(d, type):
            d = d()
        return d

    def get_error_hint(self, ctx=None):
        return ""

    def get_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return self.type.get_metavar(self)

    def _empty_value(self):
        if self.multiple or self.nargs == -1:
            return ()
        return None

    def _convert_one(self, ctx, raw):
        try:
            if isinstance(self.type, Tuple):
                return self.type.convert(tuple(raw) if not isinstance(raw, str) else raw, self, ctx)
            if self.nargs != 1:
                if isinstance(raw, str):
                    raise BadParameter("expected a sequence of values.", ctx, self)
                return tuple(self.type.convert(x, self, ctx) for x in raw)
            return self.type.convert(raw, self, ctx)
        except BadParameter as e:
            if e.param is None:
                e.param = self
            if e.ctx is None:
                e.ctx = ctx
            raise

    def _convert_value(self, ctx, raw):
        if self._skip_conversion():
            return raw
        if self.multiple:
            if isinstance(raw, str) or not isinstance(raw, (list, tuple)):
                raise BadOptionUsage(
                    f"The default for {self.get_error_hint(ctx)} needs an iterable (sequence) default, "
                    f"not a single value.",
                    ctx,
                )
            return tuple(self._convert_one(ctx, r) for r in raw)
        return self._convert_one(ctx, raw)

    def _skip_conversion(self):
        return False

    def _store(self, ctx, value, source):
        if self.expose_value:
            ctx.params[self.name] = value
        ctx._sources[self.name] = source

    def _finish(self, ctx, value, source):
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        self._store(ctx, value, source)
        return value

    # -- value sources --------------------------------------------------------
    def _default_map_value(self, ctx):
        raw = ctx.lookup_default(self.name)
        if raw is _UNSET:
            return _UNSET
        if isinstance(raw, str):
            if self.multiple and self._token_arity() == 1:
                raise BadOptionUsage(
                    f"The default for {self.get_error_hint(ctx)} needs an iterable (sequence), not a string.",
                    ctx,
                )
            if self._token_arity() != 1 or self.nargs == -1:
                return self._shape_tokens(self._split_text(raw))
        return raw

    def _env_value(self, ctx):
        names = self._env_names()
        auto = self._auto_env_name(ctx)
        if auto is not None:
            names = names + [auto]
        for name in names:
            text = os.environ.get(name)
            if not text:
                continue
            return self._parse_env_text(ctx, text)
        return _UNSET

    def _parse_env_text(self, ctx, text):
        if self._token_arity() == 1 and not self.multiple and self.nargs != -1 and not isinstance(self.type, Tuple):
            return text
        tokens = self._split_text(text)
        if not tokens:
            return _UNSET
        return self._shape_tokens(tokens)

    def _prompt_applies(self, given):
        return False

    def consume_value(self, ctx, given):  # pragma: no cover - overridden
        raise NotImplementedError


class Option(Parameter):
    """A named parameter introduced by a prefix such as ``-`` or ``--``."""

    param_type_name = "option"

    def __init__(
        self,
        param_decls=(),
        *,
        is_flag=None,
        flag_value=None,
        count=False,
        prompt=False,
        prompt_required=True,
        hide_input=False,
        confirmation_prompt=False,
        allow_from_autoenv=True,
        type=None,
        default=None,
        required=False,
        deprecated=False,
        **attrs,
    ):
        name, opts, secondary = _split_decls(list(param_decls), True)
        if name is None:
            name = _infer_dest(opts or secondary)
        if not opts and not secondary:
            raise TypeError("An option needs at least one flag name.")
        self.opts = opts
        self.secondary_opts = secondary
        self.count = bool(count)
        if is_flag is None:
            is_flag = bool(secondary) or (
                type is None and isinstance(default, bool)
            ) or type is BOOL
        self.is_flag = bool(is_flag) and not self.count
        if self.count:
            if type is None:
                type = INT
            if default is None:
                default = 0
        if self.is_flag:
            if type is None:
                type = BOOL
            if flag_value is None:
                flag_value = True
            if default is None:
                default = False
        self.flag_value = flag_value
        self.optional_value = (not self.is_flag and not self.count and flag_value is not None)
        # Flags and counters consume no tokens; valued options consume ``nargs``.
        nargs = 1 if (self.is_flag or self.count) else attrs.pop("nargs", 1)
        if deprecated and (required or prompt):
            raise ValueError("A deprecated option cannot be required or prompt.")
        self.prompt_enabled = bool(prompt)
        self.prompt_text = prompt if isinstance(prompt, str) else None
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        super().__init__(
            name,
            type=type,
            required=required,
            default=default,
            nargs=nargs,
            deprecated=deprecated,
            allow_from_autoenv=allow_from_autoenv,
            **attrs,
        )
        if self.prompt_enabled and self.prompt_text is None:
            self.prompt_text = self.name.replace("_", " ").capitalize()

    # -- declaration helpers --------------------------------------------------
    def _all_names(self):
        return self.opts + self.secondary_opts

    def get_error_hint(self, ctx=None):
        return "'" + " / ".join(self._all_names()) + "'"

    def _skip_conversion(self):
        return self.is_flag or self.count

    def _prompt_applies(self, given):
        if not self.prompt_enabled:
            return False
        if given is _NO_VALUE:
            return True
        if given is _UNSET:
            return bool(self.prompt_required or self.required)
        return False

    def _env_value(self, ctx):
        names = self._env_names()
        auto = self._auto_env_name(ctx)
        if auto is not None:
            names = names + [auto]
        for name in names:
            text = os.environ.get(name)
            if not text:
                continue
            if self.is_flag or self.count:
                value = self._flag_from_env(ctx, text, name)
                if value is _UNSET:
                    return _UNSET
                return value
            return self._parse_env_text(ctx, text)
        return _UNSET

    def _flag_from_env(self, ctx, text, varname):
        if self.count:
            try:
                return int(text.strip())
            except ValueError:
                return _UNSET
        stripped = text.strip()
        low = stripped.lower()
        non_bool_flag = self.flag_value is not None and not isinstance(self.flag_value, bool)
        if non_bool_flag and stripped == str(self.flag_value):
            return self.flag_value
        if low in ("true", "1", "yes", "on", "t", "y"):
            return True
        if low in ("false", "0", "no", "off", "f", "n", ""):
            return False if not non_bool_flag else _UNSET
        if non_bool_flag:
            return _UNSET
        raise BadOptionUsage(
            f"Invalid value {text!r} for environment variable {varname} of {self.get_error_hint(ctx)}.",
            ctx,
        )

    def _flag_raw(self, secondary):
        if self.count:
            return 1
        if secondary:
            return False
        return self.flag_value

    def _prompt(self, ctx, given):
        default = self._prompt_default(ctx)
        if self.is_flag:
            return termui.confirm(self.prompt_text, default=bool(default))
        converted = termui.prompt(
            self.prompt_text,
            default=default if default is None or not self.multiple else None,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            value_proc=lambda raw: self._convert_one(ctx, raw),
        )
        if self.multiple:
            return (converted,)
        return converted

    def _prompt_default(self, ctx):
        dm = self._default_map_value(ctx)
        if dm is not _UNSET:
            return dm
        return self.get_default(ctx)

    def consume_value(self, ctx, given):
        """Resolve this option's value from all sources. Returns the value."""
        raw = _UNSET
        source = None
        if given is not _UNSET and given is not _NO_VALUE:
            raw, source = given, ParameterSource.COMMANDLINE
        if raw is _UNSET:
            env = self._env_value(ctx)
            if env is not _UNSET:
                raw, source = env, ParameterSource.ENVIRONMENT
        if raw is _UNSET and self._prompt_applies(given):
            value = self._prompt(ctx, given)
            return self._finish(ctx, value, ParameterSource.PROMPT)
        if raw is _UNSET and given is _NO_VALUE:
            raw, source = self.flag_value, ParameterSource.COMMANDLINE
        if raw is _UNSET:
            dm = self._default_map_value(ctx)
            if dm is not _UNSET:
                raw, source = dm, ParameterSource.DEFAULT_MAP
        if raw is _UNSET:
            d = self.get_default(ctx)
            if d is not None:
                raw, source = d, ParameterSource.DEFAULT
        if raw is _UNSET:
            if self.required:
                raise MissingParameter(ctx=ctx, param=self, param_type="option")
            value = self._empty_value()
            if self.is_flag:
                value = False
            elif self.count:
                value = 0
            if self.callback is not None:
                value = self.callback(ctx, self, value)
            self._store(ctx, value, ParameterSource.DEFAULT)
            return value
        if source is ParameterSource.COMMANDLINE and self.deprecated:
            _warn(_note_text(self.deprecated, f"The option '{self._all_names()[0]}' is deprecated."), ctx)
        value = self._convert_value(ctx, raw)
        return self._finish(ctx, value, source)

    def get_help_record(self, ctx):
        """Return ``(first_column, help_text)`` for the options section, or None when hidden."""
        if self.hidden:
            return None
        if self.secondary_opts:
            names = " / ".join(self._all_names())
        else:
            names = ", ".join(self.opts)
        if not (self.is_flag or self.count):
            names = f"{names} {self.get_metavar()}"
        parts = []
        if self.help:
            parts.append(self.help)
        show_default = self.show_default if self.show_default is not None else ctx.show_default
        if show_default and not (self.is_flag and self.default is False):
            if isinstance(show_default, str):
                parts.append(f"[default: {show_default}]")
            elif callable(self.default):
                parts.append("[default: (dynamic)]")
            elif self.default is not None:
                parts.append(f"[default: {self.default}]")
        if self.show_envvar and self._env_names():
            parts.append(f"[env var: {', '.join(self._env_names())}]")
        if self.required:
            parts.append("[required]")
        if self.deprecated:
            parts.append("(DEPRECATED)")
        return names, " ".join(parts)


class Argument(Parameter):
    """A positional parameter."""

    param_type_name = "argument"

    def __init__(
        self,
        param_decls,
        *,
        required=None,
        default=None,
        nargs=None,
        type=None,
        envvar=None,
        deprecated=False,
        help=None,
        metavar=None,
        **attrs,
    ):
        decls = list(param_decls)
        if len(decls) != 1:
            raise TypeError("An argument takes exactly one destination name.")
        name = decls[0]
        if nargs is None:
            nargs = 1
        if nargs == 0 or nargs < -1:
            raise ValueError("nargs must be a positive integer or -1.")
        variadic = nargs == -1
        if required is None:
            required = (default is None) and not variadic
        if deprecated and required:
            raise ValueError("A deprecated argument cannot be required.")
        super().__init__(
            name,
            type=type,
            required=required,
            default=default,
            nargs=nargs,
            envvar=envvar,
            deprecated=deprecated,
            help=help,
            metavar=metavar,
            **attrs,
        )

    def get_error_hint(self, ctx=None):
        return f"'{self.name.upper()}'"

    def _skip_conversion(self):
        return False

    def _prompt_applies(self, given):
        return False

    def _env_value(self, ctx):
        for name in self._env_names():
            text = os.environ.get(name)
            if not text:
                continue
            return self._parse_env_text(ctx, text)
        return _UNSET

    def get_usage_pieces(self):
        placeholder = self.metavar or self.name.upper()
        if self.nargs == -1:
            body = f"{placeholder}..."
            return body if self.required else f"[{body}]"
        if self.nargs > 1:
            body = " ".join([placeholder] * self.nargs)
        else:
            body = placeholder
        return body if self.required else f"[{body}]"

    def consume_value(self, ctx, given):
        raw = _UNSET
        source = None
        if given is not _UNSET:
            raw, source = given, ParameterSource.COMMANDLINE
        if raw is _UNSET:
            env = self._env_value(ctx)
            if env is not _UNSET:
                raw, source = env, ParameterSource.ENVIRONMENT
        if raw is _UNSET:
            dm = self._default_map_value(ctx)
            if dm is not _UNSET:
                raw, source = dm, ParameterSource.DEFAULT_MAP
        if raw is _UNSET:
            d = self.get_default(ctx)
            if d is not None:
                raw, source = d, ParameterSource.DEFAULT
        if raw is _UNSET:
            if self.required:
                raise MissingParameter(ctx=ctx, param=self, param_type="argument")
            value = self._empty_value()
            if self.callback is not None:
                value = self.callback(ctx, self, value)
            self._store(ctx, value, ParameterSource.DEFAULT)
            return value
        if source is ParameterSource.COMMANDLINE and self.deprecated:
            _warn(_note_text(self.deprecated, f"The argument '{self.name}' is deprecated."), ctx)
        value = self._convert_value(ctx, raw)
        return self._finish(ctx, value, source)


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------


class _ParseResult:
    def __init__(self):
        self.events = []  # list of (option, raw)
        self.arg_values = {}  # id(argument) -> raw or _UNSET
        self.leftover = []  # list of (token, literal)


class _Parser:
    def __init__(self, command, ctx, params):
        self.ctx = ctx
        self.is_group = isinstance(command, Group)
        self.opt_params = [p for p in params if isinstance(p, Option)]
        self.arg_params = [p for p in params if isinstance(p, Argument)]
        self.norm = ctx.token_normalize_func
        self.lookup = {}
        self.prefixes = {"-"}
        for p in self.opt_params:
            for n in p.opts:
                self.prefixes.add(n[0])
                self.lookup.setdefault(self._key(n), (p, False))
            for n in p.secondary_opts:
                self.prefixes.add(n[0])
                self.lookup.setdefault(self._key(n), (p, True))
        self.interspersed = ctx.allow_interspersed_args
        self.ignore_unknown = ctx.ignore_unknown_options
        fixed = 0
        self.group_fixed = None
        if self.is_group:
            variadic = any(a.nargs == -1 for a in self.arg_params)
            if not variadic:
                fixed = sum(a.nargs for a in self.arg_params)
                self.group_fixed = fixed

    def _key(self, name):
        return self.norm(name) if self.norm else name

    def _option_like(self, tok):
        return len(tok) > 1 and tok[0] in self.prefixes

    def _is_long(self, tok):
        return len(tok) > 2 and tok[0] in self.prefixes and tok[1] in self.prefixes

    def parse(self, args):
        result = _ParseResult()
        events = result.events
        pos = []
        opts_done = False
        literal = False
        sub_started = False
        i = 0
        n = len(args)
        while i < n:
            tok = args[i]
            i += 1
            if opts_done:
                pos.append((tok, literal))
                continue
            if tok == "--":
                opts_done = True
                literal = True
                continue
            if self._option_like(tok):
                lenient = self.ignore_unknown or (sub_started and self.is_group)
                i = self._option(tok, args, i, events, lenient, pos)
                continue
            # positional token
            if not self.interspersed:
                pos.append((tok, False))
                opts_done = True
                literal = False
                continue
            if self.is_group and self.group_fixed is not None and len(pos) >= self.group_fixed:
                sub_started = True
            pos.append((tok, False))
        result.leftover = self._assign_args(pos, result)
        return result

    def _option(self, tok, args, i, events, lenient, pos):
        name, eq, attached = tok.partition("=")
        key = self._key(name)
        exact_ok = self._is_long(tok) or len(name) == 2
        if exact_ok and key in self.lookup:
            p, secondary = self.lookup[key]
            return self._take(p, secondary, name, attached if eq else None, args, i, events)
        if self._is_long(tok):
            if lenient:
                pos.append((tok, False))
                return i
            raise NoSuchOption(name)
        prefix = tok[0]
        s = tok[1:]
        j = 0
        while j < len(s):
            flag = prefix + s[j]
            k = self._key(flag)
            if k not in self.lookup:
                if lenient:
                    pos.append((prefix + s[j:], False))
                    return i
                raise NoSuchOption(flag)
            p, secondary = self.lookup[k]
            if not (p.is_flag or p.count):
                attached_text = s[j + 1 :]
                return self._take(p, secondary, flag, attached_text or None, args, i, events)
            events.append((p, p._flag_raw(secondary)))
            j += 1
        return i

    def _take(self, p, secondary, name, attached, args, i, events):
        if p.is_flag or p.count:
            if attached is not None:
                raise BadOptionUsage(f"Option '{name}' does not take a value.", self.ctx)
            events.append((p, p._flag_raw(secondary)))
            return i
        if p.optional_value:
            if attached is not None:
                val = attached
            elif i < len(args) and not self._option_like(args[i]):
                val = args[i]
                i += 1
            else:
                val = _NO_VALUE
            events.append((p, val))
            return i
        arity = p.nargs
        tokens = []
        if attached is not None:
            tokens.append(attached)
        while len(tokens) < arity:
            if i >= len(args):
                raise BadOptionUsage(f"Option '{name}' requires an argument.", self.ctx)
            tokens.append(args[i])
            i += 1
        if p.nargs == 1 and not isinstance(p.type, Tuple):
            raw = tokens[0]
        else:
            raw = tuple(tokens)
        events.append((p, raw))
        return i

    def _assign_args(self, pos, result):
        idx = 0
        args = self.arg_params
        for k, arg in enumerate(args):
            remaining = len(pos) - idx
            if arg.nargs == -1:
                later = sum(a.nargs for a in args[k + 1 :] if a.nargs > 0)
                take = max(0, remaining - later)
                chunk = pos[idx : idx + take]
                idx += take
                result.arg_values[id(arg)] = tuple(t for t, _ in chunk) if chunk else _UNSET
                continue
            need = arg.nargs
            if remaining >= need:
                chunk = pos[idx : idx + need]
                idx += need
                if need == 1 and not isinstance(arg.type, Tuple):
                    result.arg_values[id(arg)] = chunk[0][0]
                else:
                    result.arg_values[id(arg)] = tuple(t for t, _ in chunk)
            else:
                result.arg_values[id(arg)] = _UNSET
        return pos[idx:]


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------


def _show_help(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    termui.echo(ctx.get_help(), color=ctx.color)
    ctx.exit(0)


class Command:
    """A callable unit that parses its slice of the command line and runs a callback."""

    allow_extra_args = False
    allow_interspersed_args = True
    is_group = False

    def __init__(
        self,
        name,
        context_settings=None,
        callback=None,
        params=None,
        help=None,
        epilog=None,
        short_help=None,
        options_metavar="[OPTIONS]",
        add_help_option=True,
        no_args_is_help=False,
        hidden=False,
        deprecated=False,
    ):
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        if help:
            help = inspect.cleandoc(help)
            if "\f" in help:
                help = help.split("\f", 1)[0]
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # -- parameters ------------------------------------------------------------
    def get_help_option(self, ctx):
        if ctx._help_option is not None:
            return ctx._help_option
        if not self.add_help_option:
            return None
        declared = set()
        for p in self.params:
            if isinstance(p, Option):
                declared.update(p._all_names())
        names = [n for n in ctx.help_option_names if n not in declared]
        if not names:
            return None
        opt = Option(
            ["_optlyn_help", *names],
            is_flag=True,
            is_eager=True,
            expose_value=False,
            callback=_show_help,
            help="Show this message and exit.",
        )
        ctx._help_option = opt
        return opt

    def get_params(self, ctx):
        rv = list(self.params)
        help_opt = self.get_help_option(ctx)
        if help_opt is not None:
            rv.append(help_opt)
        return rv

    def _accepts_leftover(self):
        return False

    # -- parsing ---------------------------------------------------------------
    def make_context(self, info_name, args, parent=None, **extra):
        ctx = Context(self, info_name=info_name, parent=parent, **extra)
        with ctx.scope(cleanup=False):
            self.parse_args(ctx, args)
        return ctx

    def parse_args(self, ctx, args):
        args = list(args)
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelp("", ctx)
        params = self.get_params(ctx)
        ctx._declared = {p.name for p in params}
        parser = _Parser(self, ctx, params)
        result = parser.parse(args)
        ctx._parsed = result
        self._process_params(ctx, params, result)
        leftover = result.leftover
        if leftover and not self._accepts_leftover():
            tokens = [t for t, _ in leftover]
            if not ctx.allow_extra_args:
                ctx.fail(
                    "Got unexpected extra argument{} ({})".format(
                        "s" if len(tokens) > 1 else "", " ".join(tokens)
                    )
                )
            bad = [t for t, literal in leftover if not literal and len(t) > 1 and t[0] == "-"]
            if bad and not ctx.ignore_unknown_options:
                ctx.fail(f"No such option: {bad[0]}")
        leftover_tokens = [t for t, _ in leftover]
        ctx.args = leftover_tokens
        return leftover_tokens

    def _process_params(self, ctx, params, result):
        occ = {}
        for seq, (p, raw) in enumerate(result.events):
            occ.setdefault(id(p), []).append((seq, raw))
        groups = []
        index = {}
        for p in params:
            if isinstance(p, Option) and p.expose_value and not p.is_eager:
                key = ("opt", p.name)
            else:
                key = ("p", id(p))
            if key in index:
                groups[index[key]].append(p)
            else:
                index[key] = len(groups)
                groups.append([p])

        def eager_sort_key(item):
            pos, members = item
            firsts = [occ[id(m)][0][0] for m in members if id(m) in occ]
            if firsts:
                return (0, min(firsts), pos)
            return (1, 0, pos)

        indexed = list(enumerate(groups))
        eager = [(pos, g) for pos, g in indexed if any(m.is_eager for m in g)]
        eager.sort(key=eager_sort_key)
        rest = [(pos, g) for pos, g in indexed if not any(m.is_eager for m in g)]
        for _, members in eager + rest:
            self._process_group(ctx, members, occ, result)

    def _collect(self, p, occ, result):
        if isinstance(p, Argument):
            return result.arg_values.get(id(p), _UNSET)
        lst = occ.get(id(p), [])
        if not lst:
            return _UNSET
        if p.count:
            return sum(raw for _, raw in lst)
        if p.multiple:
            return [raw for _, raw in lst]
        return lst[-1][1]

    def _process_group(self, ctx, members, occ, result):
        if len(members) == 1:
            p = members[0]
            given = self._collect(p, occ, result)
            p.consume_value(ctx, given)
            return
        # Feature-switch group: several options share one destination.
        winner = None
        best = None
        for p in members:
            lst = occ.get(id(p), [])
            if lst:
                key = (2, lst[-1][0])
                if best is None or key > best:
                    best, winner = key, p
        if winner is None:
            explicit = [p for p in members if p.default is not None]
            winner = (explicit or members)[-1]
            given = _UNSET
        else:
            given = self._collect(winner, occ, result)
        winner.consume_value(ctx, given)

    # -- invocation ------------------------------------------------------------
    def invoke(self, ctx):
        if self.deprecated:
            _warn(_note_text(self.deprecated, f"The command '{ctx.command_path}' is deprecated."), ctx)
        if self.callback is None:
            return None
        return ctx.invoke(self.callback, **ctx.params)

    def main(
        self,
        args=None,
        prog_name=None,
        complete_var=None,
        standalone_mode=True,
        windows_expand_args=True,
        **extra,
    ):
        if args is None:
            args = sys.argv[1:]
        else:
            args = list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0] or "") or "root"
        from .shell_completion import maybe_complete

        maybe_complete(self, prog_name, complete_var, args)
        try:
            with self.make_context(prog_name, args, **extra) as ctx:
                rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                ctx.exit()
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)
        except Abort:
            if not standalone_mode:
                raise
            termui.echo("Aborted!", file=sys.stderr)
            sys.exit(1)
        except (EOFError, KeyboardInterrupt):
            if not standalone_mode:
                raise
            termui.echo(file=sys.stderr)
            termui.echo("Aborted!", file=sys.stderr)
            sys.exit(1)

    # -- help ------------------------------------------------------------------
    def get_short_help_str(self, limit=45):
        if self.short_help:
            return self.short_help
        return make_default_short_help(self.help or "", limit)

    def collect_usage_pieces(self, ctx):
        pieces = []
        if self.options_metavar:
            pieces.append(self.options_metavar)
        for p in self.params:
            if isinstance(p, Argument):
                pieces.append(p.get_usage_pieces())
        return pieces

    def format_usage(self, ctx, formatter):
        pieces = self.collect_usage_pieces(ctx)
        formatter.write_usage(ctx.command_path, " ".join(pieces))

    def format_help_text(self, ctx, formatter):
        if self.deprecated:
            note = self.deprecated if isinstance(self.deprecated, str) else ""
            formatter.write_text(("(Deprecated) " + note).strip())
            formatter.write_paragraph()
        if self.help:
            formatter.write_text(self.help)
            formatter.write_paragraph()

    def format_arguments(self, ctx, formatter):
        rows = []
        for p in self.params:
            if isinstance(p, Argument) and p.help and not p.hidden:
                rows.append((p.metavar or p.name.upper(), p.help))
        if rows:
            formatter.write_heading("Positional arguments")
            with formatter.indentation():
                formatter.write_dl(rows)

    def format_options(self, ctx, formatter):
        rows = []
        for p in self.get_params(ctx):
            if isinstance(p, Option):
                rec = p.get_help_record(ctx)
                if rec:
                    rows.append(rec)
        if rows:
            formatter.write_heading("Options")
            with formatter.indentation():
                formatter.write_dl(rows)

    def format_epilog(self, ctx, formatter):
        if self.epilog:
            formatter.write_paragraph()
            formatter.write_text(self.epilog)

    def format_help(self, ctx, formatter):
        self.format_usage(ctx, formatter)
        formatter.write_paragraph()
        self.format_help_text(ctx, formatter)
        self.format_arguments(ctx, formatter)
        self.format_options(ctx, formatter)
        self.format_epilog(ctx, formatter)


class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_interspersed_args = False
    is_group = True

    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        **kwargs,
    ):
        super().__init__(name, no_args_is_help=(not invoke_without_command) if no_args_is_help is None else no_args_is_help, **kwargs)
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback
        self.commands = {}
        if commands:
            if isinstance(commands, Mapping):
                for cname, cmd in commands.items():
                    self.add_command(cmd, cname)
            else:
                for cmd in commands:
                    self.add_command(cmd)

    def _accepts_leftover(self):
        return True

    def add_command(self, cmd, name=None):
        name = name or cmd.name
        if self.chain and isinstance(cmd, Group):
            raise RuntimeError("Cannot attach a group to a chained group.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        def decorator(f):
            cmd = command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        def decorator(f):
            cmd = group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self, replace=False):
        """Return a decorator that registers the result callback of this group."""

        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def _lookup(self, ctx, name):
        cmd = self.get_command(ctx, name)
        if cmd is not None:
            return cmd
        norm = ctx.token_normalize_func
        if norm is None:
            return None
        target = norm(name)
        for other in self.list_commands(ctx):
            if norm(other) == target:
                return self.get_command(ctx, other)
        return None

    def resolve_command(self, ctx, args):
        cmd_name = args[0]
        cmd = self._lookup(ctx, cmd_name)
        if cmd is None:
            ctx.fail(f"No such command '{cmd_name}'.")
        return cmd_name, cmd, args[1:]

    def format_usage(self, ctx, formatter):
        pieces = self.collect_usage_pieces(ctx)
        if self.subcommand_metavar:
            sub = self.subcommand_metavar
        elif self.chain:
            sub = "COMMAND1 [ARGS]... [COMMAND2 [ARGS]...]..."
        elif self.invoke_without_command:
            sub = "[COMMAND] [ARGS]..."
        else:
            sub = "COMMAND [ARGS]..."
        pieces.append(sub)
        formatter.write_usage(ctx.command_path, " ".join(pieces))

    def format_commands(self, ctx, formatter):
        rows = []
        names = self.list_commands(ctx)
        cmds = []
        for name in names:
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            cmds.append((name, cmd))
        if not cmds:
            return
        col_w = min(max(len(n) for n, _ in cmds), 30)
        limit = max(formatter.width - col_w - 8, 20)
        for name, cmd in cmds:
            rows.append((name, cmd.get_short_help_str(limit)))
        formatter.write_heading("Commands")
        with formatter.indentation():
            formatter.write_dl(rows)

    def format_help(self, ctx, formatter):
        self.format_usage(ctx, formatter)
        formatter.write_paragraph()
        self.format_help_text(ctx, formatter)
        self.format_arguments(ctx, formatter)
        self.format_options(ctx, formatter)
        self.format_commands(ctx, formatter)
        self.format_epilog(ctx, formatter)

    # -- parsing ---------------------------------------------------------------
    def parse_args(self, ctx, args):
        rest = super().parse_args(ctx, args)
        if self.chain:
            ctx.protected_args = []
            ctx.args = list(rest)
        else:
            ctx.protected_args = list(rest[:1])
            ctx.args = list(rest[1:])
        return rest

    # -- invocation ------------------------------------------------------------
    def invoke(self, ctx):
        def _process_result(value):
            if self._result_callback is not None:
                return ctx.invoke(self._result_callback, value, **ctx.params)
            return value

        if self.chain:
            if not ctx.args:
                if not self.invoke_without_command:
                    ctx.fail("Missing command.")
                ctx.invoked_subcommand = None
                with ctx:
                    Command.invoke(self, ctx)
                if self._result_callback is not None:
                    ctx.invoke(self._result_callback, [], **ctx.params)
                return []
            # Validate the first chained name before the group callback runs.
            self.resolve_command(ctx, list(ctx.args))
            ctx.invoked_subcommand = CHAIN_MARK
            with ctx:
                Command.invoke(self, ctx)
            rvs = []
            args = list(ctx.args)
            while args:
                cmd_name, cmd, rest = self.resolve_command(ctx, args)
                sub = cmd.make_context(cmd_name, rest, parent=ctx, allow_extra_args=True, allow_interspersed_args=False)
                with sub:
                    rvs.append(cmd.invoke(sub))
                args = list(sub.args)
            if self._result_callback is not None:
                ctx.invoke(self._result_callback, rvs, **ctx.params)
            return rvs

        if not ctx.protected_args:
            if self.invoke_without_command:
                ctx.invoked_subcommand = None
                with ctx:
                    rv = Command.invoke(self, ctx)
                return _process_result(rv)
            ctx.fail("Missing command.")

        cmd_name, cmd, rest = self.resolve_command(ctx, ctx.protected_args + ctx.args)
        ctx.invoked_subcommand = cmd_name
        with ctx:
            rv = Command.invoke(self, ctx)
        sub = cmd.make_context(cmd_name, rest, parent=ctx)
        with sub:
            sub_rv = cmd.invoke(sub)
        return _process_result(sub_rv)


class CommandCollection(Group):
    """A group whose subcommands are the union of several source groups."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for src in self.sources:
            names.update(src.list_commands(ctx))
        names.update(self.commands)
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for src in self.sources:
            cmd = src.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


# ---------------------------------------------------------------------------
# Decorators
# ---------------------------------------------------------------------------


def _attach_param(f, param):
    if isinstance(f, Command):
        f.params.append(param)
        return f
    f.__dict__.setdefault("__optlyn_params__", []).append(param)
    return f


def _function_name(name):
    lowered = name.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if lowered.endswith(suffix) and len(lowered) > len(suffix):
            lowered = lowered[: -len(suffix)]
            break
    return lowered.replace("_", "-")


def _build(f, name, cls, attrs, default_cls):
    cls = cls or default_cls
    params = f.__dict__.pop("__optlyn_params__", [])
    params.reverse()
    if name is None:
        name = _function_name(f.__name__)
    help_text = attrs.pop("help", None) or f.__doc__
    return cls(name=name, callback=f, params=params, help=help_text, **attrs)


def command(name=None, cls=None, **attrs):
    """Turn a function into a Command. Usable as ``@command`` or ``@command(...)``."""
    if callable(name) and not isinstance(name, str):
        return command(None, cls, **attrs)(name)

    def decorator(f):
        return _build(f, name, cls, attrs, Command)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a Group. Usable as ``@group`` or ``@group(...)``."""
    if callable(name) and not isinstance(name, str):
        return group(None, cls, **attrs)(name)

    def decorator(f):
        return _build(f, name, cls or Group, attrs, Group)

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to a command function."""

    def decorator(f):
        klass = cls or Option
        return _attach_param(f, klass(param_decls, **attrs))

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to a command function."""

    def decorator(f):
        klass = cls or Argument
        return _attach_param(f, klass(param_decls, **attrs))

    return decorator


def help_option(*param_decls, **kwargs):
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("callback", _show_help)
    if not any(d[0].isalnum() or d[0] == "_" for d in decls):
        decls = ["_optlyn_help", *decls]

    def decorator(f):
        return _attach_param(f, Option(decls, **kwargs))

    return decorator


def _version_text(package_name, prog_name):
    import importlib.metadata as md

    if package_name:
        try:
            return md.version(package_name)
        except md.PackageNotFoundError:
            pass
        try:
            mapping = md.packages_distributions()
            dists = mapping.get(package_name, [])
            if dists:
                return md.version(dists[0])
        except Exception:
            pass
    return "unknown"


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    decls = list(param_decls) or ["--version"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    if not any(d[0].isalnum() or d[0] == "_" for d in decls):
        decls = ["_optlyn_version", *decls]

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        ver = version if version is not None else _version_text(package_name, prog_name)
        prog = prog_name or ctx.find_root().info_name or ""
        text = (message or "%(prog)s, version %(version)s") % {"prog": prog, "version": ver}
        termui.echo(text, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("callback", callback)

    def decorator(f):
        return _attach_param(f, Option(decls, **kwargs))

    return decorator


def custom_version_option(callback, *param_decls, **kwargs):
    decls = list(param_decls) or ["--version"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    if not any(d[0].isalnum() or d[0] == "_" for d in decls):
        decls = ["_optlyn_version", *decls]

    def _cb(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        termui.echo(callback(ctx), color=ctx.color)
        ctx.exit()

    kwargs["callback"] = _cb

    def decorator(f):
        return _attach_param(f, Option(decls, **kwargs))

    return decorator


def password_option(*param_decls, **kwargs):
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("help", "Password.")

    def decorator(f):
        return _attach_param(f, Option(decls, **kwargs))

    return decorator


def _abort_if_false(ctx, param, value):
    if not value:
        ctx.abort()


def confirmation_option(*param_decls, **kwargs):
    decls = list(param_decls) or ["--yes"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs.setdefault("callback", _abort_if_false)
    if not any(d[0].isalnum() or d[0] == "_" for d in decls):
        decls = ["_optlyn_yes", *decls]

    def decorator(f):
        return _attach_param(f, Option(decls, **kwargs))

    return decorator


def pass_context(f):
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return update_wrapper(new_func, f)


def pass_obj(f):
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            return f(obj, *args, **kwargs)

        return update_wrapper(new_func, f)

    return decorator

