"""Terminal helpers: echo, styling, prompts, progress bars, pager, and friends."""

import getpass
import os
import re
import subprocess
import shlex
import sys
import time
from contextlib import contextmanager

from ._globals import get_current_context
from .exceptions import Abort, BadParameter
from .utils import (
    _NonClosing,
    edit_text,
    format_filename,  # noqa: F401  (re-exported)
    get_app_dir,  # noqa: F401  (re-exported)
    is_interactive,
    launch as _launch,
    stream_is_tty,
)

_ANSI_RE = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]")

_NAMED_FG = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93, "bright_blue": 94,
    "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}
_SWITCHES = {
    "bold": 1, "dim": 2, "italic": 3, "underline": 4, "blink": 5, "reverse": 7, "strikethrough": 9, "overline": 53,
}


def _color_codes(color, background):
    """Return the SGR parameter list for a color, or raise ValueError."""
    if background:
        base_named, base_ext, reset_code = 40, 48, 49
    else:
        base_named, base_ext, reset_code = 30, 38, 39
    if isinstance(color, bool):
        raise ValueError(f"invalid color {color!r}")
    if isinstance(color, str):
        if color == "reset":
            return [str(reset_code)]
        if color in _NAMED_FG:
            code = _NAMED_FG[color]
            return [str(code + (10 if background else 0))]
        raise ValueError(f"invalid color {color!r}")
    if isinstance(color, int):
        if 0 <= color <= 255:
            return [str(base_ext), "5", str(color)]
        raise ValueError(f"invalid color {color!r}")
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return [str(base_ext), "2"] + [str(c) for c in color]
    raise ValueError(f"invalid color {color!r}")


def unstyle(text):
    """Remove ANSI escape sequences from ``text``."""
    return _ANSI_RE.sub("", text)


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
):
    """Wrap ``text`` in ANSI SGR sequences."""
    codes = []
    if fg is not None:
        codes += _color_codes(fg, False)
    if bg is not None:
        codes += _color_codes(bg, True)
    flags = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline, "italic": italic,
        "blink": blink, "reverse": reverse, "strikethrough": strikethrough,
    }
    for name, value in flags.items():
        if value:
            codes.append(str(_SWITCHES[name]))
    if not codes:
        return str(text)
    prefix = "\x1b[" + ";".join(codes) + "m"
    return prefix + str(text) + ("\x1b[0m" if reset else "")


def _write_text(stream, text):
    try:
        stream.write(text)
    except UnicodeEncodeError:
        buf = getattr(stream, "buffer", None)
        if buf is not None:
            stream.flush()
            buf.write(text.encode("utf-8", "replace"))
            buf.flush()
        else:
            stream.write(text.encode("ascii", "replace").decode("ascii"))
    try:
        stream.flush()
    except Exception:
        pass


def _resolve_keep_color(color, file):
    if color is None:
        ctx = get_current_context(silent=True)
        color = ctx.color if ctx is not None else None
    if color is None:
        return stream_is_tty(file)
    return bool(color)


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes to stdout (or stderr), stripping styles when not on a terminal."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        buf = getattr(file, "buffer", None)
        data = message + (b"\n" if nl else b"")
        if buf is not None:
            file.flush()
            buf.write(data)
            buf.flush()
        else:
            _write_text(file, data.decode("utf-8", "replace"))
        return
    message = str(message)
    if not _resolve_keep_color(color, file):
        message = unstyle(message)
    _write_text(file, message + ("\n" if nl else ""))


_echo_fn = echo


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None:
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def _read_line(hidden=False):
    """Read one line of input for a prompt. End of file aborts."""
    stdin = sys.stdin
    if getattr(stdin, "_optlyn_runner", False):
        line = stdin.readline()
        if line == "":
            raise EOFError()
        line = line.rstrip("\r\n")
        if hidden:
            sys.stdout.write("\n")
        else:
            sys.stdout.write(line + "\n")
        return line
    if hidden and stream_is_tty(stdin):
        try:
            return getpass.getpass("")
        except EOFError:
            raise
    line = stdin.readline()
    if line == "":
        raise EOFError()
    return line.rstrip("\r\n")


def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    value_proc=None,
    prompt_suffix=": ",
    show_default=True,
    err=False,
    show_choices=True,
):
    """Ask for a value; re-ask on conversion failure. Returns the converted value."""
    from .paramtypes import _convert_type

    ptype = _convert_type(type, default)
    ctx = get_current_context(silent=True)

    def convert(raw):
        if value_proc is not None:
            return value_proc(raw)
        return ptype.convert(raw, None, ctx)

    while True:
        shown = text
        if default is not None and show_default:
            shown_default = "" if hide_input else str(default)
            if shown_default != "":
                shown = f"{shown} [{shown_default}]"
        echo(shown + prompt_suffix, nl=False, err=err)
        value = _read_line(hide_input)
        if value == "" and default is not None:
            try:
                return convert(default)
            except BadParameter as e:
                echo(f"Error: {e.format_message()}", err=True)
                continue
        if confirmation_prompt:
            echo(f"Repeat for confirmation{prompt_suffix}", nl=False, err=err)
            second = _read_line(hide_input)
            if second != value:
                echo("Error: The two entered values do not match.", err=True)
                continue
        try:
            return convert(value)
        except BadParameter as e:
            echo(f"Error: {e.format_message()}", err=True)
            continue


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question and return a boolean."""
    if show_default:
        choices = "[Y/n]" if default else "[y/N]"
        shown = f"{text} {choices}"
    else:
        shown = text
    while True:
        echo(shown + prompt_suffix, nl=False, err=err)
        value = _read_line().strip().lower()
        if value == "":
            result = bool(default)
            break
        if value in ("y", "yes"):
            result = True
            break
        if value in ("n", "no"):
            result = False
            break
        echo("Error: invalid input", err=True)
    if abort and not result:
        raise Abort()
    return result


def getchar(echo=False):
    """Read one character from the terminal (or stdin when no terminal)."""
    stdin = sys.stdin
    if getattr(stdin, "_optlyn_runner", False):
        ch = stdin.read(1)
    else:
        ch = None
        if os.name == "posix":
            try:
                import termios
                import tty

                fd = os.open("/dev/tty", os.O_RDONLY)
            except (OSError, ImportError):
                fd = None
            if fd is not None:
                try:
                    if os.isatty(fd):
                        old = termios.tcgetattr(fd)
                        try:
                            tty.setraw(fd)
                            ch = os.read(fd, 1).decode("utf-8", "replace")
                        finally:
                            termios.tcsetattr(fd, termios.TCSADRAIN, old)
                    else:
                        ch = os.read(fd, 1).decode("utf-8", "replace")
                finally:
                    os.close(fd)
        else:
            import msvcrt

            ch = msvcrt.getwch()
            if ch in ("\x00", "\xe0"):
                msvcrt.getwch()
                ch = ""
        if ch is None:
            ch = stdin.read(1)
    if ch == "":
        raise EOFError()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    if echo:
        _echo_fn(ch, nl=False)
    return ch


def pause(info=None, err=False):
    """Print a message and wait for a key press when interactive."""
    if info is None:
        info = "Press any key to continue..."
    echo(info, nl=False, err=err)
    if not is_interactive():
        echo("", err=err)
        return
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo("", err=err)


def clear():
    """Clear the terminal screen; does nothing when stdout is not a terminal."""
    if stream_is_tty(sys.stdout):
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    return edit_text(text, editor, env, require_save, extension, filename)


def launch(url, wait=False, locate=False):
    return _launch(url, wait=wait, locate=locate)


def _chunks(text_or_generator):
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        return [text_or_generator]
    return text_or_generator


def echo_via_pager(text_or_generator, color=None):
    """Write text through the pager when interactive; otherwise write it to stdout."""
    chunks = _chunks(text_or_generator)
    pager = os.environ.get("PAGER")
    if not is_interactive() or not pager:
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    keep = bool(color) if color is not None else False
    proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE, text=False)
    try:
        for chunk in chunks:
            text = str(chunk)
            if not keep:
                text = unstyle(text)
            proc.stdin.write(text.encode("utf-8", "replace"))
            proc.stdin.flush()
    finally:
        try:
            proc.stdin.close()
        except OSError:
            pass
        proc.wait()


@contextmanager
def get_pager_file(color=None):
    """Context manager yielding a writable text stream that goes through the pager."""
    pager = os.environ.get("PAGER")
    if not is_interactive() or not pager:
        yield _NonClosing(sys.stdout)
        return
    proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE)
    import io

    stream = io.TextIOWrapper(proc.stdin, encoding="utf-8", errors="replace", write_through=True)
    try:
        yield stream
    finally:
        try:
            stream.close()
        except OSError:
            pass
        proc.wait()


class ProgressBar:
    """Progress over an iterable or a known length. Visits every item in order."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, file=None, **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.file = file or sys.stdout
        self.pos = 0
        self.start = time.time()
        self.options = options
        self.tty = (not hidden) and stream_is_tty(self.file)
        self._label_done = False
        if not hidden and not self.tty and self.label:
            echo(self.label, file=self.file)
            self._label_done = True

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps, current_item=None):
        self.pos += n_steps
        if self.tty:
            self._render()

    def _render(self):
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            filled = int(frac * 30)
            bar = "#" * filled + "-" * (30 - filled)
            eta = ""
            if self.pos and self.options.get("show_eta", True):
                elapsed = time.time() - self.start
                remaining = elapsed / self.pos * (self.length - self.pos)
                eta = f"  eta {int(remaining)}s"
            line = f"\r{self.label}  [{bar}]  {self.pos}/{self.length}{eta}"
        else:
            line = f"\r{self.label}  {self.pos}"
        _write_text(self.file, line)

    def finish(self):
        if self.tty:
            _write_text(self.file, "\n")


@contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    bar = ProgressBar(iterable, length, label, hidden, **options)
    try:
        yield bar
    finally:
        bar.finish()


__all__ = [
    "echo",
    "secho",
    "style",
    "unstyle",
    "prompt",
    "confirm",
    "getchar",
    "pause",
    "clear",
    "edit",
    "launch",
    "echo_via_pager",
    "get_pager_file",
    "progressbar",
    "get_app_dir",
    "format_filename",
]
