"""Parameter types: conversion of command-line text into Python values."""

import datetime as _dt
import enum
import os
import pathlib
import uuid as _uuid

from ._globals import get_current_context
from .exceptions import BadParameter
from .utils import LazyFile, open_file

_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}

DEFAULT_DATETIME_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]


def _ctx_normalize(ctx):
    if ctx is None:
        return None
    return getattr(ctx, "token_normalize_func", None)


def _apply_norm(func, value):
    if func is None:
        return value
    return func(value)


class ParamType:
    """Base class for parameter types. Subclasses implement ``convert``."""

    name = "text"
    is_composite = False
    arity = 1

    def convert(self, value, param=None, ctx=None):
        return value

    def get_metavar(self, param=None):
        return self.name.upper()

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def shell_complete(self, ctx, param, incomplete):
        return []

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class FuncParamType(ParamType):
    """Wraps a conversion function that raises ``ValueError`` to refuse input."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "custom").lower()

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as e:
            raise BadParameter(str(e) or f"{value!r} is not valid.", ctx=ctx, param=param)


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, str):
            return value
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip())
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return float(value)
        try:
            return float(str(value).strip())
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except (ValueError, TypeError, AttributeError):
            self.fail(f"{value!r} is not a valid UUID value.", param, ctx)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._enum = True
        else:
            self.choices = list(choices)
            self._enum = False
        self.case_sensitive = case_sensitive

    def _token(self, choice):
        if isinstance(choice, enum.Enum):
            return choice.name
        return str(choice)

    def get_metavar(self, param=None):
        return "[" + "|".join(self._token(c) for c in self.choices) + "]"

    def convert(self, value, param=None, ctx=None):
        for choice in self.choices:
            if value is choice or (not isinstance(value, str) and value == choice):
                return choice
        if not isinstance(value, str):
            value = str(value)
        norm = _ctx_normalize(ctx)
        token = _apply_norm(norm, value)
        for choice in self.choices:
            cand = _apply_norm(norm, self._token(choice))
            if self.case_sensitive:
                if token == cand:
                    return choice
            elif token.casefold() == cand.casefold():
                return choice
        options = ", ".join(repr(self._token(c)) for c in self.choices)
        self.fail(f"{value!r} is not one of {options}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        items = []
        for choice in self.choices:
            tok = self._token(choice)
            if tok.startswith(incomplete) or (not self.case_sensitive and tok.casefold().startswith(incomplete.casefold())):
                items.append(CompletionItem(tok))
        return items


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(DEFAULT_DATETIME_FORMATS)

    def get_metavar(self, param=None):
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip() if not isinstance(value, str) else value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        self.fail(f"{value!r} does not match the formats {', '.join(repr(f) for f in self.formats)}.", param, ctx)


class IntRange(IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp
        if min is not None and max is not None and min > max:
            raise ValueError("'min' must not be greater than 'max'.")

    def _range_text(self):
        lo = "" if self.min is None else str(self.min)
        hi = "" if self.max is None else str(self.max)
        lb = "(" if self.min_open else "["
        rb = ")" if self.max_open else "]"
        return f"{lb}{lo}, {hi}{rb}"

    def convert(self, value, param=None, ctx=None):
        rv = IntParamType.convert(self, value, param, ctx)
        below = self.min is not None and (rv <= self.min if self.min_open else rv < self.min)
        above = self.max is not None and (rv >= self.max if self.max_open else rv > self.max)
        if not below and not above:
            return rv
        if self.clamp:
            if below:
                return self.min + 1 if self.min_open else self.min
            return self.max - 1 if self.max_open else self.max
        self.fail(f"{rv} is not in the valid range of {self._range_text()}.", param, ctx)


class FloatRange(FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp
        if min is not None and max is not None and min > max:
            raise ValueError("'min' must not be greater than 'max'.")
        if clamp and (min_open or max_open):
            raise ValueError("Clamping is not supported when a bound is open.")

    def _range_text(self):
        lo = "" if self.min is None else str(self.min)
        hi = "" if self.max is None else str(self.max)
        lb = "(" if self.min_open else "["
        rb = ")" if self.max_open else "]"
        return f"{lb}{lo}, {hi}{rb}"

    def convert(self, value, param=None, ctx=None):
        rv = FloatParamType.convert(self, value, param, ctx)
        below = self.min is not None and (rv <= self.min if self.min_open else rv < self.min)
        above = self.max is not None and (rv >= self.max if self.max_open else rv > self.max)
        if not below and not above:
            return rv
        if self.clamp:
            return float(self.min) if below else float(self.max)
        self.fail(f"{rv} is not in the valid range of {self._range_text()}.", param, ctx)


class Tuple(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [_convert_type(t) for t in types]
        self.arity = len(self.types)

    def get_metavar(self, param=None):
        return " ".join(t.get_metavar(param) for t in self.types)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, str) or not hasattr(value, "__len__") or len(value) != len(self.types):
            self.fail(f"{value!r} must be a sequence of {len(self.types)} values.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


class File(ParamType):
    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        if not isinstance(value, (str, bytes, os.PathLike)):
            value = str(value)
        if isinstance(value, os.PathLike):
            value = os.fspath(value)
        if isinstance(value, bytes):
            value = os.fsdecode(value)
        writing = "w" in self.mode
        if value == "-":
            return open_file("-", self.mode, self.encoding, self.errors)
        lazy = self.lazy if self.lazy is not None else writing
        if writing and lazy:
            f = LazyFile(value, self.mode, self.encoding, self.errors, self.atomic)
        else:
            try:
                f = open_file(value, self.mode, self.encoding, self.errors, atomic=self.atomic)
            except Exception as e:
                from .exceptions import FileError

                if isinstance(e, FileError):
                    self.fail(f"'{value}': {e.hint}", param, ctx)
                raise
        cur = ctx or get_current_context(silent=True)
        if cur is not None:
            cur.call_on_close(f.close)
        return f


class Path(ParamType):
    name = "path"

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            rv = os.fsdecode(value)
        elif isinstance(value, os.PathLike):
            rv = os.fspath(value)
        else:
            rv = str(value)
        if self.allow_dash and rv == "-":
            return self._finish(rv)
        if self.resolve_path:
            rv = os.path.realpath(os.path.abspath(rv))
        try:
            st = os.stat(rv)
            exists = True
        except OSError:
            st = None
            exists = False
        if not exists:
            if self.exists:
                self.fail(f"{value!r} does not exist.", param, ctx)
            return self._finish(rv)
        if not self.file_okay and os.path.isfile(rv):
            self.fail(f"{value!r} is a file.", param, ctx)
        if not self.dir_okay and os.path.isdir(rv):
            self.fail(f"{value!r} is a directory.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{value!r} is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{value!r} is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{value!r} is not executable.", param, ctx)
        return self._finish(rv)

    def _finish(self, rv):
        if self.path_type is None or self.path_type is str:
            return rv
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return self.path_type(rv)

    def shell_complete(self, ctx, param, incomplete):
        from .shell_completion import CompletionItem

        kind = "dir" if (self.dir_okay and not self.file_okay) else "file"
        return [CompletionItem(incomplete, type=kind)]


INT = IntParamType()
STRING = StringParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()

_PY_TYPES = {int: INT, float: FLOAT, bool: BOOL, str: STRING, _uuid.UUID: UUID}


def _convert_type(ty, default=None):
    """Turn an author-supplied type spec (instance, class, function, or None) into a ParamType."""
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, tuple):
        return Tuple(ty)
    if ty is None:
        if default is None:
            return STRING
        if isinstance(default, bool):
            return BOOL
        if isinstance(default, (list, tuple)):
            if not default:
                return STRING
            return _convert_type(None, default[0])
        for py, pt in _PY_TYPES.items():
            if isinstance(default, py):
                return pt
        return STRING
    if ty in _PY_TYPES:
        return _PY_TYPES[ty]
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type: {ty!r}")
