"""In-process runner: invoke a command with tokens and capture output and status."""

import io
import os
import shlex
import shutil
import sys
import tempfile
from contextlib import contextmanager


class _BufferProxy:
    def __init__(self, owner):
        self._owner = owner

    def write(self, data):
        return self._owner._write_bytes(data)

    def flush(self):
        pass

    def writable(self):
        return True

    def isatty(self):
        return False


class _OutputStream:
    """A text stream that records writes both to its own buffer and to a combined buffer."""

    def __init__(self, combined, charset):
        self._own = io.BytesIO()
        self._combined = combined
        self.encoding = charset
        self.errors = "replace"
        self.buffer = _BufferProxy(self)

    def _write_bytes(self, data):
        self._own.write(data)
        self._combined.write(data)
        return len(data)

    def write(self, text):
        if isinstance(text, bytes):
            self._write_bytes(text)
            return len(text)
        data = text.encode(self.encoding, "replace")
        self._write_bytes(data)
        return len(text)

    def flush(self):
        pass

    def isatty(self):
        return False

    def writable(self):
        return True

    def getvalue(self):
        return self._own.getvalue()


class _InputBuffer:
    """Binary view of the runner's stdin: reads return bytes."""

    def __init__(self, buf):
        self._buf = buf

    def read(self, size=-1):
        return self._buf.read() if size is None or size < 0 else self._buf.read(size)

    def readline(self, *args):
        return self._buf.readline()

    def readable(self):
        return True

    def isatty(self):
        return False


class _InputStream:
    """Stdin replacement. Marked so prompts know they run under the runner."""

    _optlyn_runner = True

    def __init__(self, data, charset, echo_stdin, out):
        if data is None:
            data = b""
        if isinstance(data, str):
            data = data.encode(charset)
        self._buf = io.BytesIO(data)
        self.encoding = charset
        self._echo = echo_stdin
        self._out = out
        self.buffer = _InputBuffer(self._buf)

    def _decode(self, raw):
        return raw.decode(self.encoding, "replace")

    def readline(self, *args):
        raw = self._buf.readline()
        text = self._decode(raw)
        if self._echo and text:
            self._out.write(text if text.endswith("\n") else text + "\n")
        return text

    def read(self, size=-1):
        raw = self._buf.read() if size is None or size < 0 else self._buf.read(size)
        return self._decode(raw)

    def isatty(self):
        return False

    def readable(self):
        return True

    def __iter__(self):
        return iter(self.readline, "")


class Result:
    """Outcome of ``CliRunner.invoke``."""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info
        charset = runner.charset
        self.stdout = stdout_bytes.decode(charset, "replace")
        self.stderr = stderr_bytes.decode(charset, "replace")
        self.output = output_bytes.decode(charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invoke a Command in-process with argument tokens and captured streams."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextmanager
    def isolation(self, input=None, env=None, color=False):
        combined = io.BytesIO()
        out = _OutputStream(combined, self.charset)
        err = _OutputStream(combined, self.charset)
        stdin = _InputStream(input, self.charset, self.echo_stdin, out)
        merged = dict(self.env)
        merged.update(env or {})
        saved_env = {}
        for key, value in merged.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        saved = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, out, err
        try:
            yield (out, err, combined)
        finally:
            sys.stdin, sys.stdout, sys.stderr = saved
            for key, old in saved_env.items():
                if old is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = old

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            args = shlex.split(args)
        else:
            args = list(args)
        prog_name = extra.pop("prog_name", None) or cli.name or "root"
        standalone = extra.pop("standalone_mode", True)
        extra.setdefault("color", color)

        exit_code = 0
        exception = None
        exc_info = None
        with self.isolation(input=input, env=env, color=color) as (out, err, combined):
            fd_files = None
            if self.capture == "fd":
                fd_files = self._start_fd_capture(out, err)
            try:
                cli.main(args=args, prog_name=prog_name, standalone_mode=standalone, **extra)
            except SystemExit as e:
                if e.code is None:
                    exit_code = 0
                elif isinstance(e.code, int):
                    exit_code = e.code
                else:
                    sys.stderr.write(str(e.code) + "\n")
                    exit_code = 1
            except Exception as e:
                if not catch_exceptions:
                    if fd_files is not None:
                        self._stop_fd_capture(fd_files, out, err)
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                if fd_files is not None:
                    self._stop_fd_capture(fd_files, out, err)
            stdout_bytes = out.getvalue() if fd_files is None else fd_files["stdout"]
            stderr_bytes = err.getvalue() if fd_files is None else fd_files["stderr"]
            output_bytes = combined.getvalue() if fd_files is None else stdout_bytes + stderr_bytes
        return Result(self, stdout_bytes, stderr_bytes, output_bytes, exit_code, exception, exc_info)

    # -- fd capture ------------------------------------------------------------
    def _start_fd_capture(self, out, err):
        f1 = tempfile.TemporaryFile()
        f2 = tempfile.TemporaryFile()
        sys.stdout.flush()
        sys.stderr.flush()
        saved1 = os.dup(1)
        saved2 = os.dup(2)
        os.dup2(f1.fileno(), 1)
        os.dup2(f2.fileno(), 2)
        real_out = io.TextIOWrapper(io.FileIO(os.dup(1), "w"), encoding=self.charset, errors="replace", write_through=True)
        real_err = io.TextIOWrapper(io.FileIO(os.dup(2), "w"), encoding=self.charset, errors="replace", write_through=True)
        sys.stdout = real_out
        sys.stderr = real_err
        return {"f1": f1, "f2": f2, "saved1": saved1, "saved2": saved2, "out": real_out, "err": real_err}

    def _stop_fd_capture(self, st, out, err):
        if st.get("done"):
            return
        st["done"] = True
        sys.stdout.flush()
        sys.stderr.flush()
        os.dup2(st["saved1"], 1)
        os.dup2(st["saved2"], 2)
        os.close(st["saved1"])
        os.close(st["saved2"])
        st["out"].close()
        st["err"].close()
        st["f1"].seek(0)
        st["f2"].seek(0)
        st["stdout"] = st["f1"].read()
        st["stderr"] = st["f2"].read()
        st["f1"].close()
        st["f2"].close()
        sys.stdout = out
        sys.stderr = err

    @contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        if temp_dir is None:
            dt = tempfile.mkdtemp()
            remove = True
        else:
            dt = tempfile.mkdtemp(dir=temp_dir)
            remove = False
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if remove:
                shutil.rmtree(dt, ignore_errors=True)
