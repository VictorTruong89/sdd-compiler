"""Help-page layout and text wrapping."""

import re
import shutil
import textwrap
from contextlib import contextmanager

DEFAULT_WRAP_WIDTH = 100  # maximum content width for wrapped text unless the caller sets another


def _detected_width(max_width):
    try:
        cols = shutil.get_terminal_size((80, 24)).columns
    except OSError:
        cols = 80
    return min(cols, max_width)


def wrap_text(text, width=None, initial_indent="", subsequent_indent="", preserve_paragraphs=False):
    """Rewrap ``text`` to ``width`` columns.

    Single newlines inside a paragraph are joined. Blank lines separate paragraphs.
    A paragraph whose first line is only a backspace is not rewrapped: its line breaks
    are kept and the backspace line is removed.
    """
    if width is None:
        width = _detected_width(DEFAULT_WRAP_WIDTH) - 2
    width = max(width, 1)
    text = (text or "").replace("\r\n", "\n")
    paragraphs = re.split(r"\n[ \t]*\n", text.strip("\n"))
    out = []
    for para in paragraphs:
        lines = para.split("\n")
        if lines and lines[0].strip() == "\b":
            kept = [ln for ln in lines[1:]]
            for ln in kept:
                out.append(textwrap.fill(ln, width, initial_indent=initial_indent, subsequent_indent=subsequent_indent) if ln.strip() else "")
            out.append("")
            continue
        joined = " ".join(ln.strip() for ln in lines if ln.strip())
        if not joined:
            continue
        out.append(
            textwrap.fill(
                joined,
                width,
                initial_indent=initial_indent,
                subsequent_indent=subsequent_indent,
                break_long_words=False,
                break_on_hyphens=False,
            )
        )
    # Collapse trailing blank markers.
    while out and out[-1] == "":
        out.pop()
    return "\n\n".join(out) if preserve_paragraphs else "\n".join(out)


def make_default_short_help(text, max_length):
    """First sentence of the first paragraph, ellipsized to ``max_length``."""
    if not text:
        return ""
    text = text.replace("\b", "")
    first_para = re.split(r"\n[ \t]*\n", text.strip("\n"))[0]
    flat = " ".join(ln.strip() for ln in first_para.split("\n") if ln.strip())
    m = re.match(r"(.*?[.!?])(\s|$)", flat)
    sentence = m.group(1) if m else flat
    if len(sentence) > max_length:
        if max_length <= 3:
            return sentence[:max_length]
        sentence = sentence[: max_length - 3].rstrip() + "..."
    return sentence


class HelpFormatter:
    """Accumulates a help page. Layout is Optlyn's; wording comes from the author."""

    def __init__(self, width=80, indent_increment=2, col_max=30, col_spacing=2):
        self.width = max(width, 10)
        self.indent_increment = indent_increment
        self.col_max = col_max
        self.col_spacing = col_spacing
        self.current_indent = 0
        self.buffer = []

    @contextmanager
    def indentation(self):
        self.current_indent += self.indent_increment
        try:
            yield
        finally:
            self.current_indent -= self.indent_increment

    def write(self, text):
        self.buffer.append(text)

    def write_line(self, text=""):
        self.buffer.append(text + "\n")

    def write_paragraph(self):
        text = "".join(self.buffer)
        if text and not text.endswith("\n\n"):
            self.buffer.append("\n")

    def write_usage(self, prog, args="", prefix="Usage: "):
        usage_prefix = f"{prefix}{prog} "
        text = f"{usage_prefix}{args}".rstrip()
        wrapped = textwrap.fill(
            text,
            self.width,
            initial_indent="",
            subsequent_indent=" " * len(usage_prefix),
            break_long_words=False,
            break_on_hyphens=False,
        )
        self.write(wrapped + "\n")

    def write_heading(self, heading):
        self.write_paragraph()
        self.write(f"{' ' * self.current_indent}{heading}:\n")

    def write_text(self, text):
        indent = " " * self.current_indent
        wrapped = wrap_text(text, max(self.width - self.current_indent, 10), indent, indent)
        if wrapped:
            self.write(wrapped + "\n")

    def write_dl(self, rows):
        rows = [(first, second) for first, second in rows]
        if not rows:
            return
        indent = " " * self.current_indent
        col_w = min(max(len(first) for first, _ in rows), self.col_max)
        help_width = max(self.width - self.current_indent - col_w - self.col_spacing, 10)
        cont = " " * (self.current_indent + col_w + self.col_spacing)
        for first, second in rows:
            if not second:
                self.write(f"{indent}{first}\n")
                continue
            lines = [ln for ln in wrap_text(second, help_width).split("\n")]
            if len(first) <= col_w:
                head = f"{indent}{first.ljust(col_w + self.col_spacing)}"
                first_line = lines[0] if lines else ""
                self.write(f"{head}{first_line}".rstrip() + "\n")
                rest = lines[1:]
            else:
                self.write(f"{indent}{first}\n")
                rest = lines
            for ln in rest:
                self.write(f"{cont}{ln}".rstrip() + "\n")

    def getvalue(self):
        return "".join(self.buffer)
