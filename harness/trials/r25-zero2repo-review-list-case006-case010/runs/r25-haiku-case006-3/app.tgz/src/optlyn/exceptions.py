"""Exception classes used by Optlyn.

Every usage/abort/file error carries an ``exit_code`` that standalone mode uses
when the process is ended. ``show`` writes the human-readable report.
"""

import sys


def _write_err(text, file=None):
    if file is None:
        file = sys.stderr
    try:
        file.write(text)
    except UnicodeEncodeError:
        buf = getattr(file, "buffer", None)
        if buf is not None:
            buf.write(text.encode("utf-8", "replace"))
        else:
            file.write(text.encode("ascii", "replace").decode("ascii"))
    try:
        file.flush()
    except Exception:
        pass


class OptlynError(Exception):
    """Base class for errors Optlyn reports to the user."""

    exit_code = 1

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def format_message(self):
        return self.message

    def __str__(self):
        return self.message

    def show(self, file=None):
        _write_err(f"Error: {self.format_message()}\n", file)


class UsageError(OptlynError):
    """Incorrect command-line usage. Exit status 2."""

    exit_code = 2

    def show(self, file=None):
        ctx = self.ctx
        if ctx is not None:
            usage = ctx.get_usage()
            if usage:
                _write_err(usage + "\n", file)
            hint = ctx.get_help_hint()
            if hint:
                _write_err(hint + "\n", file)
            _write_err("\n", file)
        _write_err(f"Error: {self.format_message()}\n", file)


class BadOptionUsage(UsageError):
    """A usage error about an option whose details are in the message."""


class BadArgumentUsage(UsageError):
    """A usage error about an argument whose details are in the message."""


class NoSuchOption(UsageError):
    def __init__(self, option_name, message=None, ctx=None):
        if message is None:
            message = f"No such option: {option_name}"
        super().__init__(message, ctx)
        self.option_name = option_name


class BadParameter(UsageError):
    """A value that cannot be accepted for a parameter."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"


class MissingParameter(BadParameter):
    def __init__(self, message=None, ctx=None, param=None, param_hint=None, param_type=None):
        super().__init__(message or "", ctx, param, param_hint)
        self.param_type = param_type

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if self.param_type:
            label = self.param_type
        elif self.param is not None and self.param.param_type_name == "argument":
            label = "argument"
        else:
            label = "option"
        if hint:
            return f"Missing {label} {hint}."
        return f"Missing {label}."


class NoArgsIsHelp(UsageError):
    """Raised when a command shows its help page because no arguments were given.

    It is a usage failure (exit 2) and the help page goes to standard error.
    """

    def show(self, file=None):
        if self.ctx is not None:
            _write_err(self.ctx.get_help(), file)


class FileError(OptlynError):
    """A file could not be opened at first I/O. General error (exit 1)."""

    exit_code = 1

    def __init__(self, filename, hint=None, ctx=None):
        self.ui_filename = filename
        self.hint = hint
        super().__init__(f"Could not open file '{filename}': {hint}", ctx)

    def show(self, file=None):
        _write_err(f"Error: {self.message}\n", file)


class Abort(RuntimeError):
    """The user or author aborted the program (exit 1)."""

    exit_code = 1


class Exit(RuntimeError):
    """An author clean stop with an exit status."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
