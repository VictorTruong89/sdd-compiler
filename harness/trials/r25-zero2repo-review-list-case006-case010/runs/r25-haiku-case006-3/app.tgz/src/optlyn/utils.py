"""File, path, and platform helpers shared by the parameter types and terminal helpers."""

import io
import os
import subprocess
import sys
import tempfile
import shlex
from contextlib import contextmanager

from ._globals import get_current_context
from .exceptions import FileError


class _NonClosing:
    """Proxy over a standard stream that ignores ``close``."""

    def __init__(self, stream):
        object.__setattr__(self, "_stream", stream)

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __setattr__(self, name, value):
        setattr(self._stream, name, value)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def __iter__(self):
        return iter(self._stream)


def _std_stream(name, writing, binary):
    stream = sys.stdout if writing else sys.stdin
    if binary:
        stream = getattr(stream, "buffer", stream)
    return _NonClosing(stream)


class _AtomicFile:
    """Writes to a sibling temp file and replaces the target on close."""

    def __init__(self, filename, fobj, tmp_path):
        self._filename = filename
        self._fobj = fobj
        self._tmp_path = tmp_path
        self._closed = False

    def __getattr__(self, name):
        return getattr(self._fobj, name)

    def __iter__(self):
        return iter(self._fobj)

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._fobj.close()
        os.replace(self._tmp_path, self._filename)

    @property
    def closed(self):
        return self._closed

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


def _open_real(filename, mode, encoding, errors, atomic):
    if atomic and ("w" in mode or "a" in mode):
        directory = os.path.dirname(os.path.abspath(filename))
        fd, tmp_path = tempfile.mkstemp(dir=directory, prefix=".__atomic-write")
        os.close(fd)
        if "b" in mode:
            f = open(tmp_path, mode, errors=None)
        else:
            f = open(tmp_path, mode, encoding=encoding, errors=errors)
        return _AtomicFile(filename, f, tmp_path)
    if "b" in mode:
        return open(filename, mode)
    return open(filename, mode, encoding=encoding, errors=errors)


class LazyFile:
    """A file that is opened on first I/O (write modes by default)."""

    def __init__(self, filename, mode, encoding=None, errors="strict", atomic=False):
        self.name = filename
        self.mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._f = None
        self._closed_before_open = False

    def _open(self):
        if self._f is None:
            try:
                self._f = _open_real(self.name, self.mode, self._encoding, self._errors, self._atomic)
            except OSError as e:
                raise FileError(self.name, e.strerror or str(e))
        return self._f

    def __getattr__(self, name):
        if name.startswith("__"):
            raise AttributeError(name)
        return getattr(self._open(), name)

    def __iter__(self):
        return iter(self._open())

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def close(self):
        if self._f is not None:
            self._f.close()

    @property
    def closed(self):
        return self._f is not None and self._f.closed


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or a standard stream when ``filename`` is ``-``."""
    if isinstance(filename, os.PathLike):
        filename = os.fspath(filename)
    binary = "b" in mode
    writing = "w" in mode or "a" in mode or "x" in mode
    if filename == "-":
        return _std_stream("-", writing, binary)
    if lazy and writing:
        return LazyFile(filename, mode, encoding, errors, atomic)
    try:
        return _open_real(filename, mode, encoding, errors, atomic)
    except OSError as e:
        raise FileError(filename, e.strerror or str(e))


def format_filename(filename, shorten=False):
    """Return printable text for a filename that may not be valid Unicode."""
    if isinstance(filename, os.PathLike):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = str(filename)
    if shorten:
        text = os.path.basename(text.rstrip("/\\")) or text
    out = []
    for ch in text:
        code = ord(ch)
        if 0xDC80 <= code <= 0xDCFF:
            # Undecodable byte: keep it visible and distinct from other names.
            out.append("\\x%02x" % (code - 0xDC00))
        else:
            out.append(ch)
    result = "".join(out)
    result.encode("utf-8")  # must be strictly encodable
    return result


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user configuration directory for ``app_name``."""
    home = os.path.expanduser("~")
    if sys.platform == "darwin" and not force_posix:
        return os.path.join(home, "Library", "Application Support", app_name)
    if sys.platform.startswith("win") and not force_posix:
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming" if roaming else "Local")
        return os.path.join(base, app_name)
    folder = "-".join(app_name.lower().split())
    if force_posix:
        return os.path.join(home, "." + folder)
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(base, folder)


def launch(url, wait=False, locate=False):
    """Open ``url`` (URL or path) with the default application. Returns a status."""
    if sys.platform == "darwin":
        args = ["open"]
        if wait:
            args.append("-W")
        if locate:
            args.append("-R")
    elif sys.platform.startswith("win"):
        if locate:
            url = "/select," + url
        try:
            os.startfile(url)  # type: ignore[attr-defined]
        except OSError:
            return 1
        return 0
    else:
        args = ["xdg-open"]
        if locate:
            url = os.path.dirname(url) or url
    args.append(url)
    try:
        proc = subprocess.Popen(args)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def edit_text(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Implementation of the ``edit`` helper."""
    if editor is None:
        editor = (env or {}).get("EDITOR") or os.environ.get("EDITOR")
    if not editor:
        editor = "notepad" if sys.platform.startswith("win") else "vi"
    cmd = shlex.split(editor) if not sys.platform.startswith("win") else [editor]
    if filename is not None:
        subprocess.call(cmd + [os.fspath(filename)], env=_merged_env(env))
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        data = (text or "").replace("\r\n", "\n").encode("utf-8")
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        subprocess.call(cmd + [path], env=_merged_env(env))
        with open(path, "rb") as f:
            result = f.read().decode("utf-8", "replace")
        if require_save and result == (text or "").replace("\r\n", "\n"):
            return None
        return result
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def _merged_env(env):
    if not env:
        return None
    merged = dict(os.environ)
    merged.update(env)
    return merged


@contextmanager
def isolated_cwd(path):
    old = os.getcwd()
    os.chdir(path)
    try:
        yield path
    finally:
        os.chdir(old)


def current_color_flag():
    ctx = get_current_context(silent=True)
    return ctx.color if ctx is not None else None


def stream_is_tty(stream):
    try:
        return bool(stream is not None and stream.isatty())
    except Exception:
        return False


def is_interactive():
    """A session is interactive when stdin or stdout is a terminal."""
    return stream_is_tty(sys.stdin) or stream_is_tty(sys.stdout)


__all__ = [
    "open_file",
    "LazyFile",
    "format_filename",
    "get_app_dir",
    "launch",
    "edit_text",
    "is_interactive",
    "stream_is_tty",
    "io",
]
