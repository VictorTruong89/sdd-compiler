"""Shell completion: registration scripts and suggestion output.

Completion mode is selected by the environment variable ``_<PROG>_COMPLETE``.
Its value is ``<shell>_source`` (print the registration script) or
``<shell>_complete`` (print suggestions for ``COMP_WORDS``/``COMP_CWORD``).

Suggestion stream format: one entry per line, ``type<TAB>value<TAB>help``.
``type`` is ``plain`` for a value, or ``file`` / ``dir`` for a path request
(the value is the incomplete token).
"""

import os
import sys

SHELLS = ("bash", "zsh", "fish", "powershell")


class CompletionItem:
    """One suggestion. ``type`` is ``plain`` for values, ``file``/``dir`` for paths."""

    def __init__(self, value, help=None, type="plain"):
        self.value = value
        self.help = help
        self.type = type

    def __repr__(self):
        return f"CompletionItem({self.value!r}, help={self.help!r}, type={self.type!r})"


def _env_var_name(prog):
    return "_" + os.path.basename(prog).upper().replace("-", "_").replace(".", "_") + "_COMPLETE"


def _source_script(prog, shell):
    name = os.path.basename(prog)
    func = "_" + name.replace("-", "_").replace(".", "_") + "_completion"
    var = _env_var_name(prog)
    if shell == "bash":
        return f"""{func}() {{
    local IFS=$'\\n'
    local response
    response=$(env COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD {var}=bash_complete $1)
    COMPREPLY=()
    for line in $response; do
        local kind="${{line%%$'\\t'*}}"
        local rest="${{line#*$'\\t'}}"
        local value="${{rest%%$'\\t'*}}"
        case "$kind" in
            plain) COMPREPLY+=("$value") ;;
            file) COMPREPLY+=($(compgen -f -- "$value")) ;;
            dir) COMPREPLY+=($(compgen -d -- "$value")) ;;
        esac
    done
    return 0
}}

complete -o default -F {func} {name}
"""
    if shell == "zsh":
        return f"""#compdef {name}
{func}() {{
    local -a completions
    local line kind rest value
    local response
    response=$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {name})
    for line in ${{(f)response}}; do
        kind="${{line%%$'\\t'*}}"
        rest="${{line#*$'\\t'}}"
        value="${{rest%%$'\\t'*}}"
        case "$kind" in
            plain) completions+=("$value") ;;
            file) _files -- "$value" ;;
            dir) _files -/ -- "$value" ;;
        esac
    done
    if (( ${{#completions}} )); then
        compadd -- $completions
    fi
}}

compdef {func} {name}
"""
    if shell == "fish":
        return f"""function {func}
    set -l response (env {var}=fish_complete COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) {name})
    for line in $response
        set -l parts (string split \\t -- $line)
        switch $parts[1]
            case plain
                printf '%s\\t%s\\n' $parts[2] $parts[3]
            case file
                __fish_complete_path $parts[2]
            case dir
                __fish_complete_directories $parts[2]
        end
    end
end

complete -c {name} -f -a "({func})"
"""
    if shell == "powershell":
        return f"""Register-ArgumentCompleter -Native -CommandName {name} -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $words = $commandAst.ToString()
    $index = $commandAst.CommandElements.Count
    if ($wordToComplete -eq '') {{ $index = $index }} else {{ $index = $index - 1 }}
    $env:COMP_WORDS = $words
    $env:COMP_CWORD = $index
    $env:{var} = 'powershell_complete'
    $response = & {name}
    Remove-Item Env:\\{var}
    foreach ($line in $response) {{
        $parts = $line -split "`t"
        if ($parts[0] -eq 'plain') {{
            [System.Management.Automation.CompletionResult]::new($parts[1], $parts[1], 'ParameterValue', $parts[1])
        }}
    }}
}}
"""
    raise ValueError(shell)


def _visible_options(ctx, cmd):
    from .core import Option

    out = []
    for p in cmd.get_params(ctx):
        if isinstance(p, Option) and not p.hidden:
            out.append(p)
    return out


def _descend(root, root_ctx, tokens):
    """Walk ``tokens`` through the group tree. Returns (command, ctx, trailing_tokens)."""
    from .core import Argument, Group, Context, Option

    cmd = root
    ctx = root_ctx
    i = 0
    cur_tokens = tokens
    while i < len(cur_tokens):
        tok = cur_tokens[i]
        if tok.startswith("-") and len(tok) > 1:
            # Skip an option's value when the option takes one.
            flag = tok.split("=", 1)[0]
            opt = None
            for p in cmd.get_params(ctx):
                if isinstance(p, Option) and flag in p._all_names():
                    opt = p
                    break
            if opt is not None and not (opt.is_flag or opt.count) and "=" not in tok:
                i += 2
            else:
                i += 1
            continue
        if isinstance(cmd, Group):
            child = cmd.get_command(ctx, tok)
            if child is not None:
                ctx = Context(child, info_name=tok, parent=ctx)
                cmd = child
                cur_tokens = cur_tokens[i + 1 :]
                i = 0
                continue
        i += 1
    return cmd, ctx, cur_tokens


def _complete_items(root, prog, words, cword, shell):
    if shell == "fish":
        incomplete = cword
        args = words[1:]
        if args and args[-1] == incomplete:
            args = args[:-1]
    else:
        try:
            idx = int(cword)
        except ValueError:
            idx = len(words)
        args = words[1:idx]
        incomplete = words[idx] if 0 <= idx < len(words) else ""

    from .core import Argument, Group, Context, Option

    root_ctx = Context(root, info_name=prog)
    cmd, ctx, trailing = _descend(root, root_ctx, args)
    items = []

    # A pending option value: the token before the incomplete word takes a value.
    pending = None
    if trailing:
        last = trailing[-1]
        if last.startswith("-") and len(last) > 1 and "=" not in last:
            for p in _visible_options(ctx, cmd):
                if last in p._all_names() and not (p.is_flag or p.count):
                    pending = p
                    break
    if pending is not None:
        return _value_items(ctx, pending, incomplete)

    if incomplete.startswith("-"):
        for p in _visible_options(ctx, cmd):
            for name in p._all_names():
                if name.startswith(incomplete):
                    items.append(CompletionItem(name, help=p.help))
        return items

    if isinstance(cmd, Group):
        for name in cmd.list_commands(ctx):
            child = cmd.get_command(ctx, name)
            if child is None or child.hidden:
                continue
            if name.startswith(incomplete):
                items.append(CompletionItem(name, help=child.get_short_help_str(45)))

    positional = [p for p in cmd.params if isinstance(p, Argument)]
    used = len([t for t in trailing if not t.startswith("-")])
    if not isinstance(cmd, Group) and used < len(positional):
        arg = positional[used]
        items.extend(_value_items(ctx, arg, incomplete))
    return items


def _value_items(ctx, param, incomplete):
    if param.shell_complete_func is not None:
        raw = param.shell_complete_func(ctx, param, incomplete)
    else:
        raw = param.type.shell_complete(ctx, param, incomplete)
    out = []
    for item in raw or []:
        if isinstance(item, CompletionItem):
            out.append(item)
        elif isinstance(item, str):
            if item.startswith(incomplete):
                out.append(CompletionItem(item))
        else:
            value = getattr(item, "value", None)
            if value is None or not str(value).startswith(incomplete):
                continue
            out.append(CompletionItem(value, help=getattr(item, "help", None), type=getattr(item, "type", "plain") or "plain"))
    return out


def _write_items(items):
    from .termui import echo

    for item in items:
        value = item.value
        help_text = (item.help or "").replace("\t", " ").replace("\n", " ")
        echo(f"{item.type}\t{value}\t{help_text}", color=False)


def maybe_complete(command, prog_name, complete_var, args):
    """If completion is requested via the environment, handle it and exit."""
    var = complete_var or _env_var_name(prog_name)
    value = os.environ.get(var)
    if not value:
        return
    from .termui import echo

    if "_" not in value:
        echo(f"Unknown completion instruction: {value}", err=True)
        sys.exit(1)
    shell, _, instruction = value.rpartition("_")
    if shell not in SHELLS or instruction not in ("source", "complete"):
        echo(f"Unknown completion instruction: {value}", err=True)
        sys.exit(1)
    if instruction == "source":
        echo(_source_script(prog_name, shell), color=False, nl=False)
        sys.exit(0)
    cword = os.environ.get("COMP_CWORD", "0")
    words = os.environ.get("COMP_WORDS", "").split(" ")
    items = _complete_items(command, prog_name, words, cword, shell)
    _write_items(items)
    sys.exit(0)

