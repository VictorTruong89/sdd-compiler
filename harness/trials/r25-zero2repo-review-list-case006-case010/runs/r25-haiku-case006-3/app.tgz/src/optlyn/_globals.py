"""Thread-local stack of the invocation contexts that are current on a thread."""

import threading

_local = threading.local()


def _stack():
    st = getattr(_local, "stack", None)
    if st is None:
        st = []
        _local.stack = st
    return st


def push_context(ctx):
    _stack().append(ctx)


def pop_context():
    st = _stack()
    if st:
        st.pop()


def get_current_context(silent=False):
    st = _stack()
    if st:
        return st[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")
