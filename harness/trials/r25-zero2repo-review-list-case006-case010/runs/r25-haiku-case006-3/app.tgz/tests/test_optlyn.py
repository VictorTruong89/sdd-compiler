"""Regression tests for Optlyn behaviour described in spec/Full_PRD.md."""

import os
import pathlib

import pytest

from optlyn import (
    Abort,
    BadParameter,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    Path,
    argument,
    command,
    confirmation_option,
    custom_version_option,
    echo,
    get_app_dir,
    group,
    make_pass_decorator,
    option,
    pass_context,
    format_filename,
)
from optlyn.formatting import wrap_text
from optlyn.testing import CliRunner


@pytest.fixture
def runner():
    return CliRunner()


# -- FP-01 / FP-02 --------------------------------------------------------------


def test_command_name_derivation():
    @command()
    def my_tool_cmd():
        pass

    @command()
    def do_thing_grp():
        pass

    assert my_tool_cmd.name == "my-tool"
    assert do_thing_grp.name == "do-thing"


def test_explicit_name_replaces_derived_name(runner):
    @command("renamed")
    def fn():
        echo("ran")

    assert runner.invoke(fn, []).output == "ran\n"
    assert fn.name == "renamed"


def test_help_does_not_run_callback(runner):
    ran = []

    @command()
    def cmd():
        """Does things."""
        ran.append(1)

    result = runner.invoke(cmd, ["--help"])
    assert result.exit_code == 0
    assert "Does things." in result.output
    assert ran == []


def test_form_feed_truncates_help(runner):
    @command()
    def cmd():
        """Visible.\fHidden text."""

    out = runner.invoke(cmd, ["--help"]).output
    assert "Visible." in out
    assert "Hidden" not in out
    assert "\f" not in out


def test_no_args_is_help_is_usage_failure(runner):
    @group()
    def cli():
        pass

    @cli.command()
    def sub():
        pass

    result = runner.invoke(cli, [])
    assert result.exit_code == 2
    assert "Commands:" in result.stderr


def test_options_only_group_is_missing_command(runner):
    @group()
    @option("--x")
    def cli(x):
        pass

    @cli.command()
    def sub():
        pass

    result = runner.invoke(cli, ["--x", "1"])
    assert result.exit_code == 2
    assert "Missing command." in result.output


def test_epilog_at_end_of_help(runner):
    @command(epilog="THE END")
    @option("--flag")
    def cmd(flag):
        pass

    out = runner.invoke(cmd, ["--help"]).output
    assert out.rstrip().endswith("THE END")


def test_deprecated_command_runs_and_warns(runner):
    @command(deprecated=True)
    def cmd():
        echo("ran")

    result = runner.invoke(cmd, [])
    assert result.exit_code == 0
    assert "ran" in result.stdout
    assert "deprecated" in result.stderr.lower()


# -- FP-03 options --------------------------------------------------------------


def test_flags_counts_and_repeatables(runner):
    @command()
    @option("--shout/--no-shout", default=False)
    @option("-v", "--verbose", count=True)
    @option("-n", "--num", type=int, multiple=True)
    @argument("rest", nargs=-1)
    def cmd(shout, verbose, num, rest):
        echo(repr((shout, verbose, num, rest)))

    result = runner.invoke(cmd, ["--shout", "-vv", "-n", "1", "-n2", "a", "b"])
    assert result.output == "(True, 2, (1, 2), ('a', 'b'))\n"
    assert runner.invoke(cmd, []).output == "(False, 0, (), ())\n"


def test_double_dash_ends_options(runner):
    @command()
    @option("--shout", is_flag=True)
    @argument("rest", nargs=-1)
    def cmd(shout, rest):
        echo(repr((shout, rest)))

    assert runner.invoke(cmd, ["--", "--shout"]).output == "(False, ('--shout',))\n"


def test_envvar_first_set_wins_and_empty_is_unset(runner):
    @command()
    @option("--q", envvar=["NOPE_A", "NOPE_B"])
    def cmd(q):
        echo(q)

    result = runner.invoke(cmd, [], env={"NOPE_A": "", "NOPE_B": "bee"})
    assert result.output == "bee\n"


def test_command_line_beats_environment(runner):
    @command()
    @option("--env", envvar="MY_ENV_OPT", default="d")
    def cmd(env):
        echo(env)

    assert runner.invoke(cmd, [], env={"MY_ENV_OPT": "fromenv"}).output == "fromenv\n"
    assert runner.invoke(cmd, ["--env", "cli"], env={"MY_ENV_OPT": "fromenv"}).output == "cli\n"


def test_env_boolean_unrecognised_is_usage_error(runner):
    @command()
    @option("--x", envvar="FLAGX", is_flag=True)
    def cmd(x):
        echo(str(x))

    assert runner.invoke(cmd, [], env={"FLAGX": "Yes"}).output == "True\n"
    assert runner.invoke(cmd, [], env={"FLAGX": "maybe"}).exit_code == 2


def test_required_option_and_error_names_it(runner):
    @command()
    @option("--n", type=int, required=True)
    def cmd(n):
        pass

    result = runner.invoke(cmd, [])
    assert result.exit_code == 2
    assert "--n" in result.stderr


def test_bad_value_names_parameter(runner):
    @command()
    @option("--count", type=int)
    def cmd(count):
        pass

    result = runner.invoke(cmd, ["--count", "x"])
    assert result.exit_code == 2
    assert "--count" in result.stderr


def test_parameter_callback_can_refuse(runner):
    def refuse(ctx, param, value):
        if value == "bad":
            raise BadParameter("nope", ctx=ctx, param=param)
        return value.upper()

    @command()
    @option("--v", callback=refuse)
    def cmd(v):
        echo(v)

    assert runner.invoke(cmd, ["--v", "abc"]).output == "ABC\n"
    assert runner.invoke(cmd, ["--v", "bad"]).exit_code == 2


def test_multiple_default_string_is_usage_error(runner):
    @command()
    @option("--tags", multiple=True, default="x")
    def cmd(tags):
        pass

    result = runner.invoke(cmd, [])
    assert result.exit_code == 2
    assert "iterable" in result.stderr


def test_feature_switch_group(runner):
    @command()
    @option("--upper", "mode", flag_value="upper", default=False)
    @option("--lower", "mode", flag_value="lower")
    def cmd(mode):
        echo(repr(mode))

    assert runner.invoke(cmd, []).output == "False\n"
    assert runner.invoke(cmd, ["--lower"]).output == "'lower'\n"


def test_custom_version_option_prints_exact_string(runner):
    @command()
    @custom_version_option(lambda ctx: "custom 9")
    def cmd():
        pass

    assert runner.invoke(cmd, ["--version"]).output == "custom 9\n"


# -- FP-04 arguments --------------------------------------------------------------


def test_argument_arity_and_missing(runner):
    @command()
    @argument("pair", nargs=2)
    @argument("opt", required=False, default="dflt")
    def cmd(pair, opt):
        echo(repr((pair, opt)))

    assert runner.invoke(cmd, ["a", "b"]).output == "(('a', 'b'), 'dflt')\n"
    result = runner.invoke(cmd, ["a"])
    assert result.exit_code == 2
    assert "PAIR" in result.stderr


# -- FP-05 types -----------------------------------------------------------------


def test_choice_returns_original_member(runner):
    @command()
    @option("--mode", type=Choice(["Fast", "Slow"], case_sensitive=False))
    def cmd(mode):
        echo(mode)

    assert runner.invoke(cmd, ["--mode", "fast"]).output == "Fast\n"
    assert runner.invoke(cmd, ["--mode", "medium"]).exit_code == 2


def test_int_range_clamp_and_refuse(runner):
    @command()
    @option("--n", type=IntRange(0, 10, clamp=True))
    @option("--f", type=FloatRange(0.0, 1.0))
    def cmd(n, f):
        echo(f"{n} {f}")

    assert runner.invoke(cmd, ["--n", "99", "--f", "0.5"]).output == "10 0.5\n"
    assert runner.invoke(cmd, ["--f", "2"]).exit_code == 2


def test_float_range_clamp_with_open_bound_refused():
    with pytest.raises(ValueError):
        FloatRange(0.0, 1.0, min_open=True, clamp=True)


def test_datetime_default_formats(runner):
    @command()
    @option("--when", type=DateTime())
    def cmd(when):
        echo(str(when))

    assert runner.invoke(cmd, ["--when", "2026-11-09 10:20:30"]).output == "2026-11-09 10:20:30\n"
    assert runner.invoke(cmd, ["--when", "yesterday"]).exit_code == 2


def test_tuple_type(runner):
    @command()
    @option("--tup", type=(str, int))
    def cmd(tup):
        echo(repr(tup))

    assert runner.invoke(cmd, ["--tup", "a", "5"]).output == "('a', 5)\n"


# -- FP-06 groups -----------------------------------------------------------------


def test_nested_groups_run_outside_in(runner):
    @group()
    def outer():
        echo("outer")

    @outer.group()
    def mid():
        echo("mid")

    @mid.command()
    def inner():
        echo("inner")

    assert runner.invoke(outer, ["mid", "inner"]).output == "outer\nmid\ninner\n"


def test_skipping_a_middle_name_is_unknown_command(runner):
    @group()
    def outer():
        pass

    @outer.group()
    def mid():
        pass

    @mid.command()
    def inner():
        pass

    result = runner.invoke(outer, ["inner"])
    assert result.exit_code == 2
    assert "No such command" in result.stderr


def test_chaining_returns_list(runner):
    @group(chain=True)
    def pipeline():
        pass

    @pipeline.command()
    @argument("x", type=int)
    def a(x):
        return x * 2

    @pipeline.command()
    def b():
        return "b"

    @pipeline.result_callback()
    def done(results):
        echo(repr(results))

    assert runner.invoke(pipeline, ["a", "3", "b"]).output == "[6, 'b']\n"


def test_hidden_command_is_still_invocable(runner):
    @group()
    def hg():
        pass

    @hg.command(hidden=True)
    def secret():
        echo("secret ran")

    assert "secret" not in runner.invoke(hg, ["--help"]).output
    assert runner.invoke(hg, ["secret"]).output == "secret ran\n"


def test_token_normalization(runner):
    @group(context_settings={"token_normalize_func": lambda s: s.lower()})
    def norm():
        pass

    @norm.command()
    @option("--verbose")
    def go(verbose):
        echo(f"verbose={verbose}")

    assert runner.invoke(norm, ["GO", "--VERBOSE", "x"]).output == "verbose=x\n"


# -- FP-07 context ---------------------------------------------------------------


class Conf:
    def __init__(self):
        self.x = 1


def test_ensure_object_and_default_map(runner):
    @group()
    def root():
        pass

    @root.command()
    @make_pass_decorator(Conf, ensure=True)
    def child(conf):
        echo(f"x={conf.x}")

    assert runner.invoke(root, ["child"]).output == "x=1\n"

    @group()
    def dm():
        pass

    @dm.command()
    @option("--color", default="red")
    def paint(color):
        echo(color)

    result = runner.invoke(dm, ["paint"], default_map={"paint": {"color": "blue"}})
    assert result.output == "blue\n"


def test_auto_envvar_prefix(runner):
    @command(context_settings={"auto_envvar_prefix": "APP"})
    @option("--db-url")
    def cmd(db_url):
        echo(db_url)

    assert runner.invoke(cmd, [], env={"APP_DB_URL": "sqlite"}).output == "sqlite\n"


def test_resources_closed_after_usage_abort(runner):
    closed = []

    class Res:
        def __enter__(self):
            return self

        def __exit__(self, *exc):
            closed.append("res")

    @group()
    @pass_context
    def owner(ctx):
        ctx.with_resource(Res())

    @owner.command()
    def kid():
        raise Abort()

    result = runner.invoke(owner, ["kid"])
    assert result.exit_code == 1
    assert closed == ["res"]


def test_standalone_off_returns_value():
    @command()
    def ret():
        return 42

    assert ret.main([], standalone_mode=False) == 42


# -- FP-08 prompts -----------------------------------------------------------------


def test_prompt_and_confirmation_pair(runner):
    @command()
    @option("--pw", prompt=True, hide_input=True, confirmation_prompt=True)
    def cmd(pw):
        echo(f"pw={pw}")

    result = runner.invoke(cmd, [], input="secret\nother\nsecret\nsecret\n")
    assert result.exit_code == 0
    assert result.stdout.endswith("pw=secret\n")
    assert "do not match" in result.stderr or "do not match" in result.output


def test_confirmation_option_declined_aborts(runner):
    @command()
    @confirmation_option(prompt="Really?")
    def cmd():
        echo("ran")

    result = runner.invoke(cmd, [], input="n\n")
    assert result.exit_code == 1
    assert "ran" not in result.output
    assert runner.invoke(cmd, ["--yes"], input="").output == "ran\n"


def test_eof_during_prompt_aborts(runner):
    @command()
    @option("--name", prompt=True)
    def cmd(name):
        pass

    assert runner.invoke(cmd, [], input="").exit_code == 1


# -- FP-09 files and paths ------------------------------------------------------


def test_file_round_trip_and_dash(runner):
    @command()
    @argument("src", type=File("r"))
    @argument("dst", type=File("w"))
    def cp(src, dst):
        dst.write(src.read().upper())

    with runner.isolated_filesystem():
        pathlib.Path("in.txt").write_text("hello")
        assert runner.invoke(cp, ["in.txt", "out.txt"]).exit_code == 0
        assert pathlib.Path("out.txt").read_text() == "HELLO"
        result = runner.invoke(cp, ["-", "-"], input="dash in")
        assert result.stdout == "DASH IN"


def test_missing_read_file_is_usage_error(runner):
    @command()
    @argument("src", type=File("r"))
    def cmd(src):
        pass

    with runner.isolated_filesystem():
        result = runner.invoke(cmd, ["nope.txt"])
        assert result.exit_code == 2
        assert "nope.txt" in result.stderr


def test_lazy_write_is_not_truncated_when_unused(runner):
    @command()
    @option("--out", type=File("w", lazy=True))
    def cmd(out):
        pass

    with runner.isolated_filesystem():
        pathlib.Path("keep.txt").write_text("orig")
        assert runner.invoke(cmd, ["--out", "keep.txt"]).exit_code == 0
        assert pathlib.Path("keep.txt").read_text() == "orig"


def test_path_must_exist(runner):
    @command()
    @option("--p", type=Path(exists=True, dir_okay=False))
    def cmd(p):
        pass

    result = runner.invoke(cmd, ["--p", "/nonexistent/x"])
    assert result.exit_code == 2
    assert "/nonexistent/x" in result.stderr


# -- FP-11 helpers --------------------------------------------------------------


def test_echo_strips_styles_off_terminal(runner):
    from optlyn import secho

    @command()
    def cmd():
        secho("hi", fg="red", bold=True)

    assert runner.invoke(cmd, []).output == "hi\n"
    assert "\x1b[" in runner.invoke(cmd, [], color=True).output


def test_style_invalid_color_raises():
    from optlyn import style

    with pytest.raises(ValueError):
        style("x", fg="purple")


def test_get_app_dir_posix_forced():
    path = get_app_dir("My App", force_posix=True)
    assert path.endswith(os.sep + ".my-app")


def test_wrap_text_backspace_paragraph_keeps_breaks():
    text = "\b\nline one\n  line two"
    out = wrap_text(text, width=40)
    assert out.split("\n") == ["line one", "  line two"]


def test_format_filename_is_strict_utf8():
    name = format_filename(b"caf\xc3\xa9\xff")
    name.encode("utf-8")


# -- FP-12 completion -------------------------------------------------------------


def test_completion_source_and_suggestions(runner, monkeypatch):
    @command()
    @option("--shell", type=Choice(["bash", "zsh"]))
    def comp(shell):
        pass

    src = runner.invoke(comp, [], env={"_COMP_COMPLETE": "bash_source"}, prog_name="comp")
    assert "complete -" in src.stdout

    env = {"_COMP_COMPLETE": "bash_complete", "COMP_WORDS": "comp --sh", "COMP_CWORD": "1"}
    out = runner.invoke(comp, [], env=env, prog_name="comp").stdout
    assert "--shell" in out

    env = {"_COMP_COMPLETE": "bash_complete", "COMP_WORDS": "comp --shell ", "COMP_CWORD": "2"}
    out = runner.invoke(comp, [], env=env, prog_name="comp").stdout
    assert "plain\tbash" in out and "plain\tzsh" in out


def test_unknown_completion_instruction(runner):
    @command()
    def comp():
        echo("ran")

    result = runner.invoke(comp, [], env={"_COMP_COMPLETE": "tcsh_source"}, prog_name="comp")
    assert result.exit_code != 0
    assert "ran" not in result.output
