"""Machine-translation evaluation."""
from lingora.translate.bleu_score import SmoothingFunction, bleu, sentence_bleu

__all__ = ["bleu", "sentence_bleu", "SmoothingFunction"]
