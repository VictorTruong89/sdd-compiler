"""Sentence-level BLEU (Papineni et al., 2002)."""
import math
import sys
from collections import Counter


def _ngrams(seq, n):
    return Counter(tuple(seq[i:i + n]) for i in range(len(seq) - n + 1))


def _modified_precision(references, hypothesis, n):
    counts = _ngrams(hypothesis, n)
    max_counts = {}
    for ref in references:
        rc = _ngrams(ref, n)
        for ng in counts:
            max_counts[ng] = max(max_counts.get(ng, 0), rc[ng])
    clipped = {ng: min(c, max_counts.get(ng, 0)) for ng, c in counts.items()}
    num = sum(clipped.values())
    den = max(1, sum(counts.values()))
    return num, den


def _closest_ref_len(references, hyp_len):
    lens = (len(r) for r in references)
    return min(lens, key=lambda rl: (abs(rl - hyp_len), rl))


def _brevity_penalty(closest, hyp_len):
    if hyp_len > closest:
        return 1
    if hyp_len == 0:
        return 0
    return math.exp(1 - closest / hyp_len)


class SmoothingFunction:
    def __init__(self, epsilon=0.1, alpha=5, k=5):
        self.epsilon = epsilon
        self.alpha = alpha
        self.k = k

    def method0(self, p_n, references, hypothesis, hyp_len=None, *a, **k):
        out = []
        for num, den in p_n:
            out.append((num, den) if num != 0 else (sys.float_info.min, 1))
        return out

    def method1(self, p_n, references, hypothesis, hyp_len=None, *a, **k):
        return [(num + self.epsilon, den) if num == 0 else (num, den) for num, den in p_n]

    def method2(self, p_n, references, hypothesis, hyp_len=None, *a, **k):
        return [(num + 1, den + 1) if i != 0 else (num, den) for i, (num, den) in enumerate(p_n)]

    def method3(self, p_n, references, hypothesis, hyp_len=None, *a, **k):
        incvnt = 1
        out = []
        for num, den in p_n:
            if num == 0:
                incvnt *= 2
                out.append((1 / (incvnt * den), 1))
            else:
                out.append((num, den))
        return out


def sentence_bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25),
                  smoothing_function=None):
    if isinstance(hypothesis, str) or any(isinstance(r, str) for r in references):
        raise TypeError("references and hypothesis must be token lists, not strings")
    references = [list(r) for r in references]
    hypothesis = list(hypothesis)
    weights = list(weights)
    p_n = [_modified_precision(references, hypothesis, i) for i in range(1, len(weights) + 1)]
    if p_n and p_n[0][0] == 0:
        return 0
    hyp_len = len(hypothesis)
    bp = _brevity_penalty(_closest_ref_len(references, hyp_len), hyp_len)
    smoothing = smoothing_function or SmoothingFunction().method0
    p_n = smoothing(p_n, references, hypothesis, hyp_len)
    s = (w * math.log(num / den) for w, (num, den) in zip(weights, p_n))
    return bp * math.exp(math.fsum(s))


bleu = sentence_bleu
