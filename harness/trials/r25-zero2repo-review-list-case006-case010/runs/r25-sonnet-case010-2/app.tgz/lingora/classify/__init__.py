"""Classifiers."""
import math
from collections import Counter

from lingora import metrics

__all__ = ["NaiveBayesClassifier", "DecisionTreeClassifier", "accuracy", "DictionaryProbDist"]


class DictionaryProbDist:
    def __init__(self, prob_dict, log=False, normalize=False):
        self._prob_dict = dict(prob_dict)
        self._log = log
        if normalize:
            if log:
                m = max(self._prob_dict.values())
                for k in self._prob_dict:
                    self._prob_dict[k] = math.exp(self._prob_dict[k] - m)
                self._log = False
            total = sum(self._prob_dict.values())
            for k in self._prob_dict:
                self._prob_dict[k] /= total

    def prob(self, sample):
        p = self._prob_dict.get(sample, 0.0)
        return float(math.exp(p)) if self._log else float(p)

    def samples(self):
        return list(self._prob_dict.keys())

    def max(self):
        return max(self.samples(), key=self.prob)


class NaiveBayesClassifier:
    def __init__(self, label_probdist, feature_probdist):
        self._label_probdist = label_probdist  # label -> prob
        self._feature_probdist = feature_probdist  # (label, fname) -> (value -> prob, default)
        self._labels = list(label_probdist)

    def labels(self):
        return list(self._labels)

    def prob_classify(self, featureset):
        featureset = dict(featureset)
        for fname in list(featureset):
            if not any((label, fname) in self._feature_probdist for label in self._labels):
                del featureset[fname]
        logprob = {label: math.log(self._label_probdist[label]) for label in self._labels}
        for label in self._labels:
            for fname, fval in featureset.items():
                if (label, fname) in self._feature_probdist:
                    probs, unseen = self._feature_probdist[(label, fname)]
                    try:
                        p = probs.get(fval, unseen)
                    except TypeError:
                        p = unseen
                    logprob[label] += math.log(p)
                else:
                    logprob[label] += -math.inf
        return DictionaryProbDist(logprob, log=True, normalize=True)

    def classify(self, featureset):
        return self.prob_classify(featureset).max()

    @classmethod
    def train(cls, labeled_featuresets):
        label_freq = Counter()
        feature_freq = {}
        feature_values = {}
        fnames = []
        fname_set = set()
        for featureset, label in labeled_featuresets:
            label_freq[label] += 1
            for fname, fval in featureset.items():
                feature_freq.setdefault((label, fname), Counter())[fval] += 1
                feature_values.setdefault(fname, set()).add(fval)
                if fname not in fname_set:
                    fname_set.add(fname)
                    fnames.append(fname)
        if not label_freq:
            raise ValueError("cannot train on an empty training set")
        for label in label_freq:
            n = label_freq[label]
            for fname in fnames:
                count = sum(feature_freq.get((label, fname), Counter()).values())
                if n - count > 0:
                    feature_freq.setdefault((label, fname), Counter())[None] += n - count
                    feature_values[fname].add(None)
        total = sum(label_freq.values())
        b = len(label_freq)
        label_probdist = {l: (c + 0.5) / (total + b * 0.5) for l, c in label_freq.items()}
        feature_probdist = {}
        for (label, fname), fd in feature_freq.items():
            n = sum(fd.values())
            bins = len(feature_values[fname])
            denom = n + bins * 0.5
            feature_probdist[(label, fname)] = (
                {v: (c + 0.5) / denom for v, c in fd.items()}, 0.5 / denom)
        return cls(label_probdist, feature_probdist)


def _entropy(counter):
    total = sum(counter.values())
    return -sum((c / total) * math.log2(c / total) for c in counter.values() if c)


def _majority(items):
    c = Counter()
    for _, label in items:
        c[label] += 1
    return c.most_common(1)[0][0]


class DecisionTreeClassifier:
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    def labels(self):
        labels = {self._label}
        if self._decisions:
            for d in self._decisions.values():
                labels.update(d.labels())
        if self._default is not None:
            labels.update(self._default.labels())
        return list(labels)

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        try:
            if fval in self._decisions:
                return self._decisions[fval].classify(featureset)
        except TypeError:
            pass
        if self._default is not None:
            return self._default.classify(featureset)
        return self._label

    def error(self, labeled_featuresets):
        errors = sum(1 for fs, label in labeled_featuresets if self.classify(fs) != label)
        return errors / len(labeled_featuresets)

    @staticmethod
    def leaf(labeled_featuresets):
        return DecisionTreeClassifier(_majority(labeled_featuresets))

    @staticmethod
    def stump(feature_name, labeled_featuresets):
        label = _majority(labeled_featuresets)
        freqs = {}
        for fs, lab in labeled_featuresets:
            freqs.setdefault(fs.get(feature_name), Counter())[lab] += 1
        decisions = {v: DecisionTreeClassifier(c.most_common(1)[0][0]) for v, c in freqs.items()}
        return DecisionTreeClassifier(label, feature_name, decisions)

    @staticmethod
    def best_stump(feature_names, labeled_featuresets):
        best = DecisionTreeClassifier.leaf(labeled_featuresets)
        best_error = best.error(labeled_featuresets)
        for fname in feature_names:
            stump = DecisionTreeClassifier.stump(fname, labeled_featuresets)
            err = stump.error(labeled_featuresets)
            if err < best_error:
                best_error = err
                best = stump
        return best

    def refine(self, labeled_featuresets, entropy_cutoff, depth_cutoff, support_cutoff):
        if len(labeled_featuresets) <= support_cutoff:
            return
        if self._fname is None:
            return
        if depth_cutoff <= 0:
            return
        for fval in list(self._decisions):
            subset = [(fs, l) for fs, l in labeled_featuresets if fs.get(self._fname) == fval]
            if _entropy(Counter(l for _, l in subset)) > entropy_cutoff:
                self._decisions[fval] = DecisionTreeClassifier.train(
                    subset, entropy_cutoff, depth_cutoff, support_cutoff)

    @staticmethod
    def train(labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100, support_cutoff=10):
        labeled_featuresets = list(labeled_featuresets)
        if not labeled_featuresets:
            raise ValueError("cannot train on an empty training set")
        names = []
        seen = set()
        for fs, _ in labeled_featuresets:
            for fname in fs:
                if fname not in seen:
                    seen.add(fname)
                    names.append(fname)
        tree = DecisionTreeClassifier.best_stump(names, labeled_featuresets)
        tree.refine(labeled_featuresets, entropy_cutoff, depth_cutoff - 1, support_cutoff)
        return tree


def accuracy(classifier, gold):
    gold = list(gold)
    results = [classifier.classify(fs) for fs, _ in gold]
    return metrics.accuracy([l for _, l in gold], results)
