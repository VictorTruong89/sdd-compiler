"""Regular-expression chunking."""
import re

from lingora import data
from lingora.tree import Tree

__all__ = ["RegexpParser", "ne_chunk"]

_SENT = "S"


def _tag_pattern_to_re(pattern):
    pattern = re.sub(r"\s", "", pattern)
    pattern = pattern.replace("<", "(?:<(?:").replace(">", ")>)")
    pattern = re.sub(r"(?<!\\)\.", r"[^\\{\\}<>]", pattern)
    return pattern


class _ChunkString:
    def __init__(self, tokens):
        self._tags = [t for t in tokens]
        self._str = "".join("<%s>" % t for t in self._tags)

    def xform(self, regexp, repl):
        self._str = re.sub(regexp, repl, self._str)
        self._str = re.sub(r"\{\}", "", self._str)

    def to_tree(self, leaves):
        out = []
        chunk = None
        pos = 0
        i = 0
        s = self._str
        # walk through the string, mapping each <tag> to the next leaf
        for m in re.finditer(r"\{|\}|<[^<>{}]*>", s):
            t = m.group(0)
            if t == "{":
                chunk = []
            elif t == "}":
                out.append(chunk)
                chunk = None
            else:
                leaf = leaves[i]
                i += 1
                if chunk is not None:
                    chunk.append(leaf)
                else:
                    out.append(leaf)
        return out


class _Rule:
    def __init__(self, kind, pattern):
        self.kind = kind
        self.pattern = pattern
        body = _tag_pattern_to_re(pattern)
        if kind == "chunk":
            self.regexp = "(?P<chunk>%s)(?=[^\\{\\}]*(\\{|$))" % body
            self.repl = r"{\g<chunk>}"
        else:
            self.regexp = "(?P<chink>%s)(?=[^\\{\\}]*(\\}|$))" % body
            self.repl = r"}\g<chink>{"
        re.compile(self.regexp)

    def apply(self, cs):
        cs.xform(self.regexp, self.repl)


class _Stage:
    def __init__(self, label, rules, root_label):
        self.label = label
        self.rules = rules
        self.root_label = root_label

    def parse(self, tree_children):
        tags = []
        for ch in tree_children:
            if isinstance(ch, Tree):
                tags.append(ch.label())
            else:
                tags.append(ch[1])
        # tags must not contain angle braces / braces
        cs = _ChunkString(tags)
        for r in self.rules:
            r.apply(cs)
        pieces = cs.to_tree(tree_children)
        children = []
        for p in pieces:
            if type(p) is list:
                children.append(Tree(self.label, p))
            else:
                children.append(p)
        return children


class RegexpParser:
    def __init__(self, grammar, root_label=_SENT, loop=1):
        self._root_label = root_label
        self._loop = loop
        if isinstance(grammar, str):
            self._stages = self._parse_grammar(grammar, root_label)
        elif isinstance(grammar, (list, tuple)) and all(isinstance(g, _Stage) for g in grammar):
            self._stages = list(grammar)
        else:
            raise TypeError("grammar must be a string or a list of chunk-parser stages")
        self._grammar = grammar

    @staticmethod
    def _parse_grammar(text, root_label):
        stages = []
        cur = None
        for raw in text.split("\n"):
            line = re.sub(r"(^|\s)#\s.*$", "", raw).strip()
            if not line or line.startswith("#"):
                continue
            m = re.match(r"^([^\s:{}<>]+)\s*:\s*(.*)$", line)
            if m:
                cur = [m.group(1), []]
                stages.append(cur)
                if m.group(2).strip():
                    cur[1].append(m.group(2).strip())
            else:
                if cur is None:
                    raise ValueError("Illegal chunk pattern: %s" % line)
                cur[1].append(line)
        out = []
        for label, pats in stages:
            rules = []
            for p in pats:
                p = p.strip()
                if p.startswith("{") and p.endswith("}") and not p.startswith("{}"):
                    rules.append(_Rule("chunk", p[1:-1]))
                elif p.startswith("}") and p.endswith("{"):
                    rules.append(_Rule("chink", p[1:-1]))
                else:
                    raise ValueError("Illegal chunk pattern: %s" % p)
            out.append(_Stage(label, rules, root_label))
        return out

    def parse(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tagged tokens must be a list of (token, tag) pairs")
        children = [tuple(t) for t in tokens]
        for _ in range(self._loop):
            for stage in self._stages:
                children = stage.parse(children)
        return Tree(self._root_label, children)


def ne_chunk(tagged_tokens, binary=False):
    data.find_dir("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    raise NotImplementedError("named-entity chunking results are outside this specification")
