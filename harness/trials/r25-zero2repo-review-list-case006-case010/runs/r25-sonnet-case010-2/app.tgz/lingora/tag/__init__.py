"""Part-of-speech taggers."""
import json
import re
from collections import Counter

from lingora import data

__all__ = ["DefaultTagger", "UnigramTagger", "BigramTagger", "TrigramTagger", "AffixTagger",
           "RegexpTagger", "PerceptronTagger", "pos_tag"]


class TaggerI:
    def tag(self, tokens):
        raise NotImplementedError

    def tag_sents(self, sents):
        return [self.tag(s) for s in sents]


class SequentialBackoffTagger(TaggerI):
    def __init__(self, backoff=None):
        if backoff is not None and not isinstance(backoff, TaggerI):
            raise TypeError("backoff must be a tagger or None")
        self._taggers = [self] + (backoff._taggers if backoff else [])
        self.backoff = backoff

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of strings")
        tags = []
        for i in range(len(tokens)):
            tags.append(self.tag_one(tokens, i, tags))
        return list(zip(tokens, tags))

    def tag_one(self, tokens, index, history):
        tag = None
        for tagger in self._taggers:
            tag = tagger.choose_tag(tokens, index, history)
            if tag is not None:
                break
        return tag

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError


class DefaultTagger(SequentialBackoffTagger):
    def __init__(self, tag):
        SequentialBackoffTagger.__init__(self)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


class RegexpTagger(SequentialBackoffTagger):
    def __init__(self, regexps, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._regexps = [(re.compile(rx), tag) for rx, tag in regexps]

    def choose_tag(self, tokens, index, history):
        for rx, tag in self._regexps:
            if rx.match(tokens[index]):
                return tag
        return None


class ContextTagger(SequentialBackoffTagger):
    def __init__(self, context_to_tag=None, backoff=None):
        SequentialBackoffTagger.__init__(self, backoff)
        self._context_to_tag = dict(context_to_tag) if context_to_tag else {}

    def context(self, tokens, index, history):
        raise NotImplementedError

    def choose_tag(self, tokens, index, history):
        ctx = self.context(tokens, index, history)
        if ctx is None:
            return None
        return self._context_to_tag.get(ctx)

    def _train(self, tagged_corpus, cutoff=0):
        fd = {}
        useful = []
        useful_set = set()
        for sentence in tagged_corpus:
            if not sentence:
                continue
            tokens = [t for t, _ in sentence]
            tags = [g for _, g in sentence]
            for index, (token, tag) in enumerate(sentence):
                ctx = self.context(tokens, index, tags[:index])
                if ctx is None:
                    continue
                fd.setdefault(ctx, Counter())[tag] += 1
                if self.backoff is None or tag != self.backoff.tag_one(tokens, index, tags[:index]):
                    if ctx not in useful_set:
                        useful_set.add(ctx)
                        useful.append(ctx)
        for ctx in useful:
            best, hits = fd[ctx].most_common(1)[0]
            if hits > cutoff:
                self._context_to_tag[ctx] = best


class UnigramTagger(ContextTagger):
    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        ContextTagger.__init__(self, model, backoff)
        if train:
            self._train(train, cutoff)

    def context(self, tokens, index, history):
        return tokens[index]


class NgramTagger(ContextTagger):
    _n = 2

    def __init__(self, train=None, model=None, backoff=None, cutoff=0):
        ContextTagger.__init__(self, model, backoff)
        if train:
            self._train(train, cutoff)

    def context(self, tokens, index, history):
        hist = tuple(history[max(0, index - self._n + 1):index])
        return hist, tokens[index]


class BigramTagger(NgramTagger):
    _n = 2


class TrigramTagger(NgramTagger):
    _n = 3


class AffixTagger(ContextTagger):
    def __init__(self, train=None, model=None, affix_length=-3, min_stem_length=2,
                 backoff=None, cutoff=0):
        ContextTagger.__init__(self, model, backoff)
        self._affix_length = affix_length
        self._min_word_length = min_stem_length + abs(affix_length)
        if train:
            self._train(train, cutoff)

    def context(self, tokens, index, history):
        token = tokens[index]
        if len(token) < self._min_word_length:
            return None
        if self._affix_length > 0:
            return token[:self._affix_length]
        return token[self._affix_length:]


# ---------------------------------------------------------------- perceptron
class PerceptronTagger(TaggerI):
    START = ["-START-", "-START2-"]
    END = ["-END-", "-END2-"]

    def __init__(self, lang="eng"):
        if lang not in ("eng", "rus"):
            raise ValueError("Unsupported language %r: only 'eng' and 'rus'" % (lang,))
        d = data.find_dir("taggers/averaged_perceptron_tagger_%s" % lang)
        base = "%s/averaged_perceptron_tagger_%s" % (d, lang)
        with open(base + ".weights.json", encoding="utf-8") as f:
            self.weights = json.load(f)
        with open(base + ".tagdict.json", encoding="utf-8") as f:
            self.tagdict = json.load(f)
        with open(base + ".classes.json", encoding="utf-8") as f:
            self.classes = set(json.load(f))
        self.lang = lang

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def _features(self, i, word, context, prev, prev2):
        i += len(self.START)
        feats = {}

        def add(name, *args):
            k = " ".join((name,) + tuple(args))
            feats[k] = feats.get(k, 0) + 1

        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[0] if word else "")
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def _predict(self, feats):
        scores = {}
        for feat, value in feats.items():
            if feat not in self.weights or value == 0:
                continue
            for label, w in self.weights[feat].items():
                scores[label] = scores.get(label, 0.0) + value * w
        return max(self.classes, key=lambda label: (scores.get(label, 0.0), label))

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of strings, not a string")
        prev, prev2 = self.START
        out = []
        context = self.START + [self.normalize(w) for w in tokens] + self.END
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self._predict(self._features(i, word, context, prev, prev2))
            out.append((word, tag))
            prev2 = prev
            prev = tag
        return out


_RUS_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ADV": "ADV", "PR": "ADP", "CONJ": "CONJ",
    "NUM": "NUM", "ANUM": "ADJ", "SPRO": "PRON", "APRO": "DET", "ADVPRO": "ADV",
    "PART": "PRT", "INTJ": "X", "COM": "X", "NONLEX": ".", "P": ".",
}


def _map_ru(tag):
    if tag is None:
        return None
    part = tag.split("=")[0]
    return _RUS_UNIVERSAL.get(part, "X")


def _load_en_map():
    d = data.find_dir("taggers/universal_tagset")
    table = {}
    with open("%s/en-ptb.map" % d, encoding="utf-8") as f:
        for line in f.read().split("\n"):
            parts = line.split("\t")
            if len(parts) >= 2:
                table[parts[0]] = parts[1]
    return table


def pos_tag(tokens, tagset=None, lang="eng"):
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of strings, not a string")
    if lang not in ("eng", "rus"):
        raise ValueError("Unsupported language %r: only 'eng' and 'rus' are supported" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("Unsupported tagset %r" % (tagset,))
    tagger = PerceptronTagger(lang)
    tagged = tagger.tag(list(tokens))
    if tagset == "universal":
        if lang == "eng":
            table = _load_en_map()
            return [(w, table.get(t, "X")) for w, t in tagged]
        return [(w, _map_ru(t)) for w, t in tagged]
    return tagged
