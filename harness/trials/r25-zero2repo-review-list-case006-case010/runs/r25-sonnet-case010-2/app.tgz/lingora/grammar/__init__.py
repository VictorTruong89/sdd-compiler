"""Context-free grammars."""
import re


class Nonterminal:
    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and self._symbol == other._symbol

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(("nt", self._symbol))

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "Nonterminal(%r)" % (self._symbol,)


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def is_empty(self):
        return len(self._rhs) == 0

    def is_lexical(self):
        return any(isinstance(s, str) for s in self._rhs)

    def __eq__(self, other):
        return (isinstance(other, Production) and self._lhs == other._lhs
                and self._rhs == other._rhs)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = [repr(s) if isinstance(s, str) else str(s) for s in self._rhs]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    __repr__ = __str__


_RHS_TOKEN = re.compile(r"""\s*(?:('[^']*'|"[^"]*")|(\|)|([^\s|'"]+))""")


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None):
        prods = self._productions
        if lhs is not None:
            prods = [p for p in prods if p.lhs() == lhs]
        if rhs is not None:
            prods = [p for p in prods if p.rhs() and p.rhs()[0] == rhs]
        return list(prods)

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n" % (
            len(self._productions), self._start) + "\n".join(
            "    %s" % p for p in self._productions)

    __repr__ = __str__

    @classmethod
    def fromstring(cls, input):
        if isinstance(input, (list, tuple)):
            lines = list(input)
        else:
            lines = str(input).split("\n")
        prods = []
        cur_lhs = None
        for line in lines:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("|"):
                if cur_lhs is None:
                    raise ValueError("alternative without left-hand side: %r" % line)
                rest = line
            else:
                m = re.match(r"^(\S+?)\s*(?:->|=>)(.*)$", line)
                if not m:
                    raise ValueError("Unable to parse production: %r" % line)
                cur_lhs = Nonterminal(m.group(1))
                rest = m.group(2)
            alts = [[]]
            pos = 0
            rest = rest.rstrip()
            while pos < len(rest):
                m = _RHS_TOKEN.match(rest, pos)
                if not m:
                    break
                pos = m.end()
                if m.group(1) is not None:
                    alts[-1].append(m.group(1)[1:-1])
                elif m.group(2) is not None:
                    alts.append([])
                else:
                    alts[-1].append(Nonterminal(m.group(3)))
            for alt in alts:
                prods.append(Production(cur_lhs, alt))
        if not prods:
            raise ValueError("No productions found")
        return cls(prods[0].lhs(), prods)
