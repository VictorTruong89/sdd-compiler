"""Parsers for context-free grammars."""
from lingora.grammar import Nonterminal
from lingora.tree import Tree


def _check_coverage(grammar, tokens):
    terms = set()
    for p in grammar.productions():
        for s in p.rhs():
            if isinstance(s, str):
                terms.add(s)
    missing = [t for t in tokens if t not in terms]
    if missing:
        raise ValueError("Grammar does not cover some of the input words: %s"
                         % ", ".join(repr(t) for t in missing))


def _check_tokens(tokens):
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of strings, not a string")
    return list(tokens)


class ChartParser:
    """Exhaustive parser: returns every parse tree."""

    def __init__(self, grammar, **kwargs):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        tokens = _check_tokens(tokens)
        _check_coverage(self._grammar, tokens)
        return iter(self._parses(tokens))

    def _parses(self, tokens):
        g = self._grammar
        n = len(tokens)
        prods = [p for p in g.productions()]
        # recognition table: set of (nonterminal, i, j)
        derives = set()

        def span_ok(rhs, k, i, j):
            """Can rhs[k:] derive tokens[i:j]?"""
            if k == len(rhs):
                return i == j
            sym = rhs[k]
            if isinstance(sym, str):
                if sym == "":
                    return span_ok(rhs, k + 1, i, j)
                return i < j and tokens[i] == sym and span_ok(rhs, k + 1, i + 1, j)
            for m in range(i, j + 1):
                if (sym, i, m) in derives and span_ok(rhs, k + 1, m, j):
                    return True
            return False

        changed = True
        while changed:
            changed = False
            for i in range(n + 1):
                for j in range(i, n + 1):
                    for p in prods:
                        key = (p.lhs(), i, j)
                        if key in derives:
                            continue
                        if span_ok(p.rhs(), 0, i, j):
                            derives.add(key)
                            changed = True

        def trees(sym, i, j, stack):
            key = (sym, i, j)
            if key not in derives or key in stack:
                return
            stack = stack | {key}
            for p in g.productions(sym):
                for kids in seqs(p.rhs(), 0, i, j, stack):
                    yield Tree(str(sym), kids)

        def seqs(rhs, k, i, j, stack):
            if k == len(rhs):
                if i == j:
                    yield []
                return
            sym = rhs[k]
            if isinstance(sym, str):
                if sym == "":
                    yield from seqs(rhs, k + 1, i, j, stack)
                elif i < j and tokens[i] == sym:
                    for rest in seqs(rhs, k + 1, i + 1, j, stack):
                        yield [sym] + rest
                return
            for m in range(i, j + 1):
                if (sym, i, m) not in derives:
                    continue
                for t in trees(sym, i, m, stack):
                    for rest in seqs(rhs, k + 1, m, j, stack):
                        yield [t] + rest

        return list(trees(g.start(), 0, n, frozenset()))


class ShiftReduceParser:
    """Single-pass shift-reduce parser without backtracking."""

    def __init__(self, grammar, trace=0):
        self._grammar = grammar

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        tokens = _check_tokens(tokens)
        _check_coverage(self._grammar, tokens)
        res = self._parse(tokens)
        return iter([res] if res is not None else [])

    def _match(self, rhs, stack):
        n = len(rhs)
        if n > len(stack):
            return False
        for sym, item in zip(rhs, stack[len(stack) - n:]):
            if isinstance(sym, str):
                if not (isinstance(item, str) and item == sym):
                    return False
            else:
                if not (isinstance(item, Tree) and item.label() == str(sym)):
                    return False
        return True

    def _reduce(self, stack):
        for p in self._grammar.productions():
            rhs = p.rhs()
            if not rhs:
                continue
            if self._match(rhs, stack):
                n = len(rhs)
                node = Tree(str(p.lhs()), stack[len(stack) - n:])
                del stack[len(stack) - n:]
                stack.append(node)
                return True
        return False

    def _parse(self, tokens):
        stack = []
        remaining = list(tokens)
        while remaining:
            stack.append(remaining.pop(0))
            while self._reduce(stack):
                pass
        if (len(stack) == 1 and isinstance(stack[0], Tree)
                and stack[0].label() == str(self._grammar.start())):
            return stack[0]
        return None


class RecursiveDescentParser(ChartParser):
    """Exhaustive top-down parser (implemented on top of the chart parser)."""
