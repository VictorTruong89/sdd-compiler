"""Constituent trees."""
import re


class Tree(list):
    def __init__(self, label, children=None):
        if children is None or isinstance(children, str):
            raise TypeError("children should be a list of children, not %r" % type(children).__name__)
        list.__init__(self, children)
        self._label = label

    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def leaves(self):
        out = []
        for child in self:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __eq__(self, other):
        return (isinstance(other, Tree) and self._label == other._label
                and list(self) == list(other))

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    def __repr__(self):
        return "Tree(%r, %s)" % (self._label, list.__repr__(self))

    def __str__(self):
        return self.pformat()

    def _flat(self):
        parts = []
        for child in self:
            if isinstance(child, Tree):
                parts.append(child._flat())
            elif isinstance(child, tuple):
                parts.append("/".join(str(c) for c in child))
            else:
                parts.append(str(child))
        return "(%s %s)" % (self._label, " ".join(parts))

    def pformat(self, margin=70, indent=0):
        s = self._flat()
        if len(s) + indent < margin:
            return s
        s = "(%s" % (self._label,)
        for child in self:
            if isinstance(child, Tree):
                s += "\n" + " " * (indent + 2) + child.pformat(margin, indent + 2)
            elif isinstance(child, tuple):
                s += "\n" + " " * (indent + 2) + "/".join(str(c) for c in child)
            else:
                s += "\n" + " " * (indent + 2) + str(child)
        return s + ")"

    def pprint(self, **kw):
        print(self.pformat(**kw))

    @classmethod
    def fromstring(cls, s):
        toks = re.findall(r"\(|\)|[^\s()]+", s)
        pos = 0

        def parse_node():
            nonlocal pos
            if pos >= len(toks) or toks[pos] != "(":
                raise ValueError("expected '(' in tree text")
            pos += 1
            if pos < len(toks) and toks[pos] not in "()":
                label = toks[pos]
                pos += 1
            else:
                label = ""
            children = []
            while True:
                if pos >= len(toks):
                    raise ValueError("unbalanced brackets in tree text")
                t = toks[pos]
                if t == ")":
                    pos += 1
                    return cls(label, children)
                if t == "(":
                    children.append(parse_node())
                else:
                    children.append(t)
                    pos += 1

        if not toks:
            raise ValueError("empty tree text")
        tree = parse_node()
        if pos != len(toks):
            raise ValueError("unexpected text after end of tree")
        return tree
