from lingora.cli import cli

cli.main()
