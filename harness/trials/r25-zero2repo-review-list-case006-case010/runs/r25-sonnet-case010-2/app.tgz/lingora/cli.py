"""Command line interface."""
import sys


class _Exit(Exception):
    def __init__(self, code):
        self.code = code


class Group:
    def __init__(self):
        self.commands = {}

    def command(self, name):
        def deco(fn):
            self.commands[name] = fn
            return fn
        return deco

    def main(self, args=None, standalone_mode=True, **kwargs):
        args = list(sys.argv[1:] if args is None else args)
        code = 0
        try:
            if not args or args[0] not in self.commands:
                sys.stderr.write("Usage: lingora tokenize [OPTIONS]\n")
                raise _Exit(2)
            self.commands[args[0]](args[1:])
        except _Exit as e:
            code = e.code
        except Exception as e:  # noqa: BLE001
            if not standalone_mode:
                raise
            sys.stderr.write("Error: %s\n" % e)
            code = 1
        if standalone_mode:
            sys.exit(code)
        return code

    __call__ = main


cli = Group()


@cli.command("tokenize")
def _tokenize(args):
    from lingora.tokenize import word_tokenize
    language = "english"
    delimiter = " "
    encoding = "utf-8"
    i = 0
    while i < len(args):
        a = args[i]
        if a in ("-l", "--language") and i + 1 < len(args):
            language = args[i + 1]
            i += 2
        elif a in ("-d", "--delimiter") and i + 1 < len(args):
            delimiter = args[i + 1]
            i += 2
        elif a in ("-e", "--encoding") and i + 1 < len(args):
            encoding = args[i + 1]
            i += 2
        else:
            sys.stderr.write("Unknown option %s\n" % a)
            raise _Exit(2)
    stdin = sys.stdin
    raw = getattr(stdin, "buffer", None)
    text = raw.read().decode(encoding) if raw is not None else stdin.read()
    out = []
    for line in text.splitlines():
        out.append(delimiter.join(word_tokenize(line.rstrip("\r\n"), language=language)))
    # only write once every line has succeeded
    if out:
        sys.stdout.write("\n".join(out) + "\n")
        sys.stdout.flush()


if __name__ == "__main__":
    cli.main()
