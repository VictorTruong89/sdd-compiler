"""Locating packaged resources."""
import os

path = [
    os.path.expanduser("~/lingora_data"),
    "/usr/share/lingora_data",
    "/usr/local/share/lingora_data",
    "/app/lingora_data",
]


def find(resource):
    """Return the first existing location of *resource* in ``path``."""
    for d in list(path):
        p = os.path.join(os.path.expanduser(str(d)), *resource.split("/"))
        if os.path.exists(p):
            return p
    raise LookupError("Resource %r not found in data.path" % resource)


def find_dir(resource):
    p = find(resource)
    if not os.path.isdir(p):
        raise LookupError("Resource %r is not a directory" % resource)
    return p


def read_lines(filepath):
    with open(filepath, encoding="utf-8") as f:
        return f.read().split("\n")
