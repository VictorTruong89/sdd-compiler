"""Tweet tokenizer."""
import html
import re

EMOTICONS = r"""
    (?:
      [<>]?
      [:;=8]
      [\-o\*\']?
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      |
      [\)\]\(\[dDpP/\:\}\{@\|\\]
      [\-o\*\']?
      [:;=8]
      [<>]?
      |
      </?3
    )"""

URLS = r"""
  (?:
  https?:
    (?:
      /{1,3}
      |
      [a-z0-9%]
    )
    |
    [a-z0-9.\-]+[.]
    (?:[a-z]{2,13})
    /
  )
  (?:
    [^\s()<>{}\[\]]+
    |
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
  )+
  (?:
    \([^\s()]*?\([^\s()]+\)[^\s()]*?\)
    |
    \([^\s]+?\)
    |
    [^\s`!()\[\]{};:'".,<>?«»“”‘’]
  )
  |
  (?:
    (?<!@)
    [a-z0-9]+
    (?:[.\-][a-z0-9]+)*
    [.]
    (?:[a-z]{2,13})
    \b
    /?
    (?!@)
  )
"""

PHONE = r"""
    (?:
      (?:
        \+?[01]
        [ *\-.\)]*
      )?
      (?:
        [\(]?
        \d{3}
        [ *\-.\)]*
      )?
      \d{3}
      [ *\-.\)]*
      \d{4}
    )"""

REGEXPS = (
    URLS,
    PHONE,
    EMOTICONS,
    r"""<[^>\s]+>""",
    r"""[\-]+>|<[\-]+""",
    r"""(?:@[\w_]+)""",
    r"""(?:\#+[\w_]+[\w\'_\-]*[\w_]+)""",
    r"""[\w.+-]+@[\w-]+\.(?:[\w-]\.?)+[\w-]""",
    r"""(?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])""",
    r"""(?:[+\-]?\d+[,/.:-]\d+[+\-]?)""",
    r"""(?:[\w_]+)""",
    r"""(?:\.(?:\s*\.){1,})""",
    r"""(?:\S)""",
)

WORD_RE = re.compile(r"(%s)" % "|".join(REGEXPS), re.VERBOSE | re.I | re.UNICODE)
EMOTICON_RE = re.compile(EMOTICONS, re.VERBOSE | re.I | re.UNICODE)
HANG_RE = re.compile(r"([^a-zA-Z0-9])\1{3,}")
HANDLES_RE = re.compile(
    r"(?<![A-Za-z0-9_!@#\$%&*])@"
    r"(([A-Za-z0-9_]){15}(?!@)|([A-Za-z0-9_]){1,14}(?![A-Za-z0-9_]*@))")
LENGTH_RE = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False,
                 match_phone_numbers=True):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        text = html.unescape(text)
        if self.strip_handles:
            text = HANDLES_RE.sub(" ", text)
        if self.reduce_len:
            text = LENGTH_RE.sub(r"\1\1\1", text)
        safe = HANG_RE.sub(r"\1\1\1", text)
        words = [m.group(0) for m in WORD_RE.finditer(safe)]
        if not self.preserve_case:
            words = [w if EMOTICON_RE.search(w) else w.lower() for w in words]
        return words
