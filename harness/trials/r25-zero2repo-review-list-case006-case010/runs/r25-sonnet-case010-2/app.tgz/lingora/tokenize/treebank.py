"""Penn Treebank word tokenizers."""
import re

_C2 = [r"(?i)\b(can)(?#X)(not)\b", r"(?i)\b(d)(?#X)('ye)\b", r"(?i)\b(gim)(?#X)(me)\b",
       r"(?i)\b(gon)(?#X)(na)\b", r"(?i)\b(got)(?#X)(ta)\b", r"(?i)\b(lem)(?#X)(me)\b",
       r"(?i)\b(more)(?#X)('n)\b", r"(?i)\b(wan)(?#X)(na)(?=\s)",
       r"(?i)(?<!\w)('t)(?#X)(is)\b", r"(?i)(?<!\w)('t)(?#X)(was)\b"]


class TreebankWordTokenizer:
    STARTING_QUOTES = [
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2 \3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = None
    ENDING_QUOTES = [
        (re.compile(r'"'), " '' "),
        (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [re.compile(p) for p in _C2]
    CONTRACTIONS3 = [re.compile(r"(?i)\b(whad)(dd)(ya)\b"), re.compile(r"(?i)\b(wha)(t)(cha)\b")]

    def tokenize(self, text, convert_parentheses=False, return_str=False):
        for r, s in self.STARTING_QUOTES:
            text = r.sub(s, text)
        for r, s in self.PUNCTUATION:
            text = r.sub(s, text)
        r, s = self.PARENS_BRACKETS
        text = r.sub(s, text)
        if self.DOUBLE_DASHES:
            r, s = self.DOUBLE_DASHES
            text = r.sub(s, text)
        text = " " + text + " "
        for r, s in self.ENDING_QUOTES:
            text = r.sub(s, text)
        for r in self.CONTRACTIONS2:
            text = r.sub(r" \1 \2 ", text)
        for r in self.CONTRACTIONS3:
            text = r.sub(r" \1 \2 \3 ", text)
        toks = text.split()
        return " ".join(toks) if return_str else toks

    def span_tokenize(self, text):
        toks = self.tokenize(text)
        pos = 0
        out = []
        for t in toks:
            cands = [t]
            if t in ("``", "''"):
                cands = [t, '"']
            for c in cands:
                i = text.find(c, pos)
                if i >= 0:
                    out.append((i, i + len(c)))
                    pos = i + len(c)
                    break
            else:
                raise ValueError("Could not align token %r" % t)
        return out


class NLTKWordTokenizer(TreebankWordTokenizer):
    """Improved Penn Treebank tokenizer (the recommended word tokenizer)."""
    STARTING_QUOTES = [
        (re.compile("([«“‘„]|[`]+)", re.U), r" \1 "),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
        (re.compile(r"(?i)(\')(?!re|ve|ll|m|t|s|d|n)(\w)\b", re.U), r"\1 \2"),
    ]
    ENDING_QUOTES = [
        (re.compile("([»”’])", re.U), r" \1 "),
        (re.compile(r"''"), " '' "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    PUNCTUATION = [
        (re.compile(r'([^\.])(\.)([\]\)}>"\'' "»”’ " r"]*)\s*$", re.U), r"\1 \2 \3 "),
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}", re.U), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*\u2012-\u2015]", re.U), r" \g<0> "),
    ]
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    CONTRACTIONS2 = [re.compile(p) for p in _C2[1:]]
