"""Punkt sentence boundary detection (Kiss & Strunk 2006), using packaged parameters."""
import re

from lingora import data

_ORTHO_BEG_UC = 1 << 1
_ORTHO_MID_UC = 1 << 2
_ORTHO_UNK_UC = 1 << 3
_ORTHO_BEG_LC = 1 << 4
_ORTHO_MID_LC = 1 << 5
_ORTHO_UNK_LC = 1 << 6
_ORTHO_UC = _ORTHO_BEG_UC | _ORTHO_MID_UC | _ORTHO_UNK_UC
_ORTHO_LC = _ORTHO_BEG_LC | _ORTHO_MID_LC | _ORTHO_UNK_LC

_RE_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_INITIAL = re.compile(r"[^\W\d]\.$")
_RE_ALPHA = re.compile(r"[^\W\d]+$")
_RE_ELLIPSIS = re.compile(r"\.\.+$")

_NONWORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_MULTI = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORDSTART = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"

PERIOD_CONTEXT_RE = re.compile(
    r"""
    [.?!]
    (?=(?P<after_tok>
        %s
        |
        \s+(?P<next_tok>\S+)
    ))""" % _NONWORD, re.VERBOSE | re.UNICODE)

WORD_TOKENIZER_RE = re.compile(
    r"""(
    %(MultiChar)s
    |
    (?=%(WordStart)s)\S+?
    (?=
        \s|
        $|
        %(NonWord)s|%(MultiChar)s|
        ,(?=$|\s|%(NonWord)s|%(MultiChar)s)
    )
    |
    \S
    )""" % {"MultiChar": _MULTI, "WordStart": _WORDSTART, "NonWord": _NONWORD},
    re.UNICODE | re.VERBOSE)

RE_BOUNDARY_REALIGNMENT = re.compile(r"[\"\')\]}]+?(?:\s+|(?=--)|$)", re.MULTILINE)


class _Token:
    def __init__(self, tok, parastart=False, linestart=False):
        self.tok = tok
        self.parastart = parastart
        self.linestart = linestart
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False
        t = tok.lower()
        self.type = _RE_NUMERIC.sub("##number##", t) if _RE_NUMERIC.match(t) else t
        self.period_final = tok.endswith(".")
        self.first_case = ("upper" if tok[0].isupper() else
                           "lower" if tok[0].islower() else "none")

    @property
    def first_upper(self):
        return self.first_case == "upper"

    @property
    def first_lower(self):
        return self.first_case == "lower"

    @property
    def is_ellipsis(self):
        return bool(_RE_ELLIPSIS.match(self.tok))

    @property
    def is_number(self):
        return self.type.startswith("##number##")

    @property
    def is_initial(self):
        return bool(_RE_INITIAL.match(self.tok))

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        if self.sentbreak:
            return self.type_no_period
        return self.type


class PunktSentenceTokenizer:
    def __init__(self, abbrev_types, collocations, sent_starters, ortho_context):
        self.abbrev_types = abbrev_types
        self.collocations = collocations
        self.sent_starters = sent_starters
        self.ortho_context = ortho_context

    @classmethod
    def load(cls, language="english"):
        d = data.find_dir("tokenizers/punkt_tab/%s" % language)

        def lines(name):
            with open("%s/%s" % (d, name), encoding="utf-8") as f:
                return [l for l in f.read().split("\n") if l != ""]

        abbrev = set(lines("abbrev_types.txt"))
        starters = set(lines("sent_starters.txt"))
        colloc = set()
        for l in lines("collocations.tab"):
            parts = l.split("\t")
            if len(parts) >= 2:
                colloc.add((parts[0], parts[1]))
        ortho = {}
        for l in lines("ortho_context.tab"):
            parts = l.split("\t")
            if len(parts) >= 2:
                ortho[parts[0]] = int(parts[1])
        return cls(abbrev, colloc, starters, ortho)

    # --- tokenization ---------------------------------------------------
    def _tokenize_words(self, text):
        parastart = False
        for line in text.split("\n"):
            if line.strip():
                toks = WORD_TOKENIZER_RE.findall(line)
                if not toks:
                    continue
                yield _Token(toks[0], parastart=parastart, linestart=True)
                parastart = False
                for t in toks[1:]:
                    yield _Token(t)
            else:
                parastart = True

    def _first_pass(self, tok):
        t = tok.tok
        if t in (".", "?", "!"):
            tok.sentbreak = True
        elif tok.is_ellipsis:
            tok.ellipsis = True
        elif tok.period_final and not t.endswith(".."):
            if (t[:-1].lower() in self.abbrev_types
                    or t[:-1].lower().split("-")[-1] in self.abbrev_types):
                tok.abbr = True
            else:
                tok.sentbreak = True

    def _ortho(self, tok):
        ortho = self.ortho_context.get(tok.type_no_sentperiod, 0)
        if tok.first_upper and (ortho & _ORTHO_LC) and not (ortho & _ORTHO_MID_UC):
            return True
        if tok.first_lower and ((ortho & _ORTHO_UC) or not (ortho & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _second_pass(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        initial = t1.is_initial
        if (typ, next_typ) in self.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not initial:
            if self._ortho(t2) is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self.sent_starters:
                t1.sentbreak = True
                return
        if initial or typ == "##number##":
            ss = self._ortho(t2)
            if ss is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            elif (ss == "unknown" and initial and t2.first_upper
                  and not (self.ortho_context.get(next_typ, 0) & _ORTHO_LC)):
                t1.sentbreak = False
                t1.abbr = True
                return

    def _annotate(self, tokens):
        toks = list(tokens)
        for t in toks:
            self._first_pass(t)
        for i, t in enumerate(toks):
            self._second_pass(t, toks[i + 1] if i + 1 < len(toks) else None)
        return toks

    def _contains_sentbreak(self, text):
        found = False
        for tok in self._annotate(self._tokenize_words(text)):
            if found:
                return True
            if tok.sentbreak:
                found = True
        return False

    @staticmethod
    def _last_ws(text):
        for i in range(len(text) - 1, -1, -1):
            if text[i].isspace():
                return i
        return 0

    def _potential_ends(self, text):
        prev_slice = (0, 0)
        prev_match = None
        for match in PERIOD_CONTEXT_RE.finditer(text):
            before = text[prev_slice[1]:match.start()]
            idx = self._last_ws(before)
            if idx:
                idx += prev_slice[1] + 1
            else:
                idx = prev_slice[0]
            cur = (idx, match.start())
            if prev_match is not None and prev_slice[1] <= cur[0]:
                yield prev_match, (text[prev_slice[0]:prev_slice[1]]
                                   + prev_match.group() + prev_match.group("after_tok"))
            prev_match = match
            prev_slice = cur
        if prev_match is not None:
            yield prev_match, (text[prev_slice[0]:prev_slice[1]]
                               + prev_match.group() + prev_match.group("after_tok"))

    def _slices(self, text):
        last = 0
        out = []
        for match, context in self._potential_ends(text):
            if self._contains_sentbreak(context):
                out.append((last, match.end()))
                if match.group("next_tok"):
                    last = match.start("next_tok")
                else:
                    last = match.end()
        out.append((last, len(text.rstrip())))
        return out

    def _realign(self, text, slices):
        realign = 0
        for i, s1 in enumerate(slices):
            s1 = (s1[0] + realign, s1[1])
            s2 = slices[i + 1] if i + 1 < len(slices) else None
            if s2 is None:
                if text[s1[0]:s1[1]]:
                    yield s1
                continue
            m = RE_BOUNDARY_REALIGNMENT.match(text[s2[0]:s2[1]])
            if m:
                yield (s1[0], s2[0] + len(m.group(0).rstrip()))
                realign = m.end()
            else:
                realign = 0
                if text[s1[0]:s1[1]]:
                    yield s1

    def span_tokenize(self, text):
        return list(self._realign(text, self._slices(text)))

    def tokenize(self, text):
        return [text[a:b] for a, b in self.span_tokenize(text)]


_cache = {}


def load_tokenizer(language="english"):
    key = language
    # Do not cache: data.path may change between calls.
    return PunktSentenceTokenizer.load(key)
