"""Tokenizers."""
import re

from lingora.tokenize.casual import TweetTokenizer
from lingora.tokenize.punkt import PunktSentenceTokenizer, load_tokenizer
from lingora.tokenize.treebank import NLTKWordTokenizer, TreebankWordTokenizer

__all__ = [
    "RegexpTokenizer", "TreebankWordTokenizer", "TweetTokenizer", "WhitespaceTokenizer",
    "WordPunctTokenizer", "BlanklineTokenizer", "blankline_tokenize", "sent_tokenize",
    "word_tokenize", "wordpunct_tokenize", "whitespace_tokenize", "NLTKWordTokenizer",
    "PunktSentenceTokenizer",
]


class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=True,
                 flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._flags = flags
        self._regexp = re.compile(pattern, flags)

    def span_tokenize(self, text):
        if self._gaps:
            pos = 0
            spans = []
            for m in self._regexp.finditer(text):
                spans.append((pos, m.start()))
                pos = m.end()
            spans.append((pos, len(text)))
            if self._discard_empty:
                spans = [(a, b) for a, b in spans if b > a]
            return iter(spans)
        spans = [m.span() for m in self._regexp.finditer(text)]
        if self._discard_empty:
            spans = [(a, b) for a, b in spans if b > a]
        return iter(spans)

    def tokenize(self, text):
        return [text[a:b] for a, b in self.span_tokenize(text)]

    def __repr__(self):
        return "%s(pattern=%r, gaps=%r, discard_empty=%r, flags=%r)" % (
            type(self).__name__, self._pattern, self._gaps, self._discard_empty, self._flags)


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s+", gaps=True)


class BlanklineTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\s*\n\s*\n\s*", gaps=True)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        RegexpTokenizer.__init__(self, r"\w+|[^\w\s]+")


_wordpunct = WordPunctTokenizer()
_whitespace = WhitespaceTokenizer()
_blankline = BlanklineTokenizer()
_word = NLTKWordTokenizer()


def wordpunct_tokenize(text):
    return _wordpunct.tokenize(text)


def whitespace_tokenize(text):
    return _whitespace.tokenize(text)


def blankline_tokenize(text):
    return _blankline.tokenize(text)


def sent_tokenize(text, language="english"):
    return load_tokenizer(language).tokenize(text)


class _RecommendedWord(NLTKWordTokenizer):
    pass


def word_tokenize(text, language="english", preserve_line=False):
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    return [tok for sent in sentences for tok in _word.tokenize(sent)]
