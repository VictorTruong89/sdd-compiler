"""Stemmers."""
import re

from lingora import data
from lingora.stem.lancaster import LancasterStemmer
from lingora.stem.porter import PorterStemmer
from lingora.stem.snowball import SnowballStemmer

__all__ = ["PorterStemmer", "LancasterStemmer", "SnowballStemmer", "RegexpStemmer",
           "WordNetLemmatizer", "ARLSTem", "ARLSTem2"]


class RegexpStemmer:
    def __init__(self, regexp, min=0):
        if not hasattr(regexp, "pattern"):
            regexp = re.compile(regexp)
        self._regexp = regexp
        self._min = min

    def stem(self, word):
        if len(word) < self._min:
            return word
        return self._regexp.sub("", word)


class WordNetLemmatizer:
    def __init__(self):
        data.find("corpora/wordnet")

    def lemmatize(self, word, pos="n"):
        data.find("corpora/wordnet")
        raise NotImplementedError("WordNet lookup is outside this specification")


class _ArabicLight:
    _prefixes = ("وال", "بال", "كال", "فال", "ال", "لل", "و", "ف", "ب", "ك", "ل")
    _suffixes = ("ات", "ون", "ين", "ان", "ها", "ية", "ة", "ه", "ي")

    def stem(self, word):
        for p in self._prefixes:
            if word.startswith(p) and len(word) - len(p) >= 3:
                word = word[len(p):]
                break
        for s in self._suffixes:
            if word.endswith(s) and len(word) - len(s) >= 3:
                word = word[:-len(s)]
                break
        return word


class ARLSTem(_ArabicLight):
    pass


class ARLSTem2(_ArabicLight):
    pass
