"""Lancaster (Paice/Husk) stemmer."""
import re

_RULES = """
ai*2. a*1. bb1. city3s. ci2> cn1j< dd1. dei3y> deec2ss. dee1. de2> dooh4> e1> feil1v. fi2> gni3>
gai3y. ga2> gg1. ht*2. hsiug5ct. hsi3> i*1. i1y> ji1d. juf1s. ju1d. jo1d. jeh1r. jrev1t. jsim2t.
jn1d. j1s. lbaifi6. lbai4y. lba3> lbi3. lib2l> lc1. lufi4y. luf3> lu2. lai3> lau3> la2> ll1.
mui3. mu*2. msi3> mm1. nois4j> noix4ct. noi3> nai3> na2> nee0. ne2> nn1. pihs4> pp1. re2> rae0.
ra2. ro2> ru2> rr1. rt1> rei3y> sei3y> sis2. si2> ssen4> ss0. suo3> su*2. s*1> s0. tacilp4y.
ta2> tnem4> tne3> tna3> tpir2b. tpro2b. tcud1. tpmus2. tpec2iv. tulo2v. tsis0. tsi3> tt1.
uqi3. ugo1. vis3j> vie0. vi2> ylb1> yli3y> ylp0. yl2> ygo1. yhp1. ymo1. ypo1. yti3> yte3>
ytl2. yrtsi5. yra3> yro3> yfi3. ycn2t> yca3> zi2> zy1s.
""".split()


class LancasterStemmer:
    def __init__(self, rule_tuple=None, strip_prefix_flag=False):
        self.rule_dictionary = {}
        self._strip_prefix = strip_prefix_flag
        rules = rule_tuple if rule_tuple else self._default_rules()
        for rule in rules:
            self.rule_dictionary.setdefault(rule[0], []).append(rule)

    @staticmethod
    def _default_rules():
        out = []
        for r in _RULES:
            out.append(r)
        return out

    def stem(self, word):
        word = word.lower()
        if self._strip_prefix:
            for prefix in ("kilo", "micro", "milli", "intra", "ultra", "mega", "nano", "pico",
                           "pseudo"):
                if word.startswith(prefix):
                    word = word[len(prefix):]
                    break
        return self._do_stemming(word, word)

    @staticmethod
    def _last_letter(word):
        last = -1
        for i, ch in enumerate(word):
            if ch.isalpha():
                last = i
            else:
                break
        return last

    @staticmethod
    def _acceptable(word, remove_total):
        if word[0] in "aeiouy":
            return len(word) - remove_total >= 2
        if len(word) - remove_total >= 3:
            return word[1] in "aeiouy" or word[2] in "aeiouy"
        return False

    def _do_stemming(self, word, intact_word):
        valid = re.compile(r"^([a-z]+)(\*?)(\d)([a-z]*)([>\.]?)$")
        proceed = True
        while proceed:
            last = self._last_letter(word)
            if last < 0 or word[last] not in self.rule_dictionary:
                proceed = False
            else:
                applied = False
                for rule in self.rule_dictionary[word[last]]:
                    m = valid.match(rule)
                    if not m:
                        continue
                    ending, intact_flag, remove_total, append, cont = m.groups()
                    remove_total = int(remove_total)
                    if word.endswith(ending[::-1]):
                        if (not intact_flag or word == intact_word) and self._acceptable(
                                word, remove_total):
                            word = word[: len(word) - remove_total] + append
                            applied = True
                            if cont == ".":
                                proceed = False
                            break
                if not applied:
                    proceed = False
        return word
