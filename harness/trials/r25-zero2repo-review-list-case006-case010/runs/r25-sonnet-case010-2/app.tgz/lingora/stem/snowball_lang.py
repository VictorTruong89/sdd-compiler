"""Snowball stemmers for several languages (Germanic/Scandinavian family)."""
from lingora.stem.snowball_en import regions


def _longest(word, sufs):
    best = None
    for s in sufs:
        if word.endswith(s) and (best is None or len(s) > len(best)):
            best = s
    return best


def _r(word, vowels):
    r1, r2 = regions(word, vowels)
    r1 = max(r1, 3) if len(word) >= 3 else r1
    if r1 > len(word):
        r1 = len(word)
    # R2 recomputed relative to adjusted R1
    r2 = len(word)
    for i in range(r1 + 1, len(word)):
        if word[i] not in vowels and word[i - 1] in vowels:
            r2 = i + 1
            break
    return r1, r2


# ------------------------------------------------------------------ German
def stem_german(word):
    word = word.lower().replace("ß", "ss")
    vow = "aeiouyäöü"
    w = list(word)
    for i in range(1, len(w) - 1):
        if w[i - 1] in vow and w[i + 1] in vow:
            if w[i] == "u":
                w[i] = "U"
            elif w[i] == "y":
                w[i] = "Y"
    word = "".join(w)
    r1, r2 = _r(word, vow)
    # step 1
    suf = _longest(word, ["em", "ern", "er", "e", "en", "es", "s"])
    if suf and len(word) - len(suf) >= r1:
        base = word[:-len(suf)]
        if suf in ("em", "ern", "er"):
            word = base
        elif suf in ("e", "en", "es"):
            word = base
            if word.endswith("niss"):
                word = word[:-1]
        elif suf == "s" and base and base[-1] in "bdfghklmnrt":
            word = base
    # step 2
    suf = _longest(word, ["en", "er", "est", "st"])
    if suf and len(word) - len(suf) >= r1:
        base = word[:-len(suf)]
        if suf in ("en", "er", "est"):
            word = base
        elif base and base[-1] in "bdfghklmnt" and len(base) >= 4:
            word = base
    # step 3
    suf = _longest(word, ["end", "ung", "ig", "ik", "isch", "lich", "heit", "keit"])
    if suf and len(word) - len(suf) >= r2:
        base = word[:-len(suf)]
        if suf in ("end", "ung"):
            word = base
            if word.endswith("ig") and not word.endswith("eig") and len(word) - 2 >= r2:
                word = word[:-2]
        elif suf in ("ig", "ik", "isch"):
            if not base.endswith("e"):
                word = base
        elif suf in ("lich", "heit"):
            word = base
            for s2 in ("er", "en"):
                if word.endswith(s2) and len(word) - 2 >= r1:
                    word = word[:-2]
                    break
        elif suf == "keit":
            word = base
            for s2 in ("lich", "ig"):
                if word.endswith(s2) and len(word) - len(s2) >= r2:
                    word = word[:-len(s2)]
                    break
    word = word.replace("U", "u").replace("Y", "y")
    return word.translate(str.maketrans("äöü", "aou"))


# ------------------------------------------------------------------- Dutch
def _undouble(word):
    if word.endswith(("kk", "dd", "tt")):
        return word[:-1]
    return word


def stem_dutch(word):
    word = word.lower()
    word = word.translate(str.maketrans("äëïöüáéíóú", "aeiouaeiou"))
    vow = "aeiouyè"
    w = list(word)
    if w and w[0] == "y":
        w[0] = "Y"
    for i in range(1, len(w)):
        if w[i] == "y" and w[i - 1] in vow:
            w[i] = "Y"
    for i in range(1, len(w) - 1):
        if w[i] == "i" and w[i - 1] in vow and w[i + 1] in vow:
            w[i] = "I"
    word = "".join(w)
    vow2 = vow
    r1, r2 = _r(word, vow2)

    def valid_en(base):
        return bool(base) and base[-1] not in vow2 and not base.endswith("gem")

    # step 1
    suf = _longest(word, ["heden", "en", "ene", "s", "se"])
    if suf and len(word) - len(suf) >= r1:
        base = word[:-len(suf)]
        if suf == "heden":
            word = base + "heid"
        elif suf in ("en", "ene"):
            if valid_en(base):
                word = _undouble(base)
        elif base and base[-1] not in vow2 and base[-1] != "j":
            word = base
    # step 2
    e_deleted = False
    if word.endswith("e") and len(word) - 1 >= r1 and len(word) > 1 and word[-2] not in vow2:
        word = _undouble(word[:-1])
        e_deleted = True
    # step 3a
    if word.endswith("heid") and len(word) - 4 >= r2 and not word.endswith("cheid"):
        word = word[:-4]
        if word.endswith("en") and len(word) - 2 >= r1 and valid_en(word[:-2]):
            word = _undouble(word[:-2])
    # step 3b
    suf = _longest(word, ["end", "ing", "ig", "lijk", "baar", "bar"])
    if suf:
        base = word[:-len(suf)]
        if suf in ("end", "ing") and len(word) - len(suf) >= r2:
            word = base
            if word.endswith("ig") and len(word) - 2 >= r2 and not word.endswith("eig"):
                word = word[:-2]
            else:
                word = _undouble(word)
        elif suf == "ig" and len(word) - 2 >= r2 and not base.endswith("e"):
            word = base
        elif suf == "lijk" and len(word) - 4 >= r2:
            word = base
            if word.endswith("e") and len(word) - 1 >= r1 and len(word) > 1 \
                    and word[-2] not in vow2:
                word = _undouble(word[:-1])
        elif suf == "baar" and len(word) - 4 >= r2:
            word = base
        elif suf == "bar" and len(word) - 3 >= r2 and e_deleted:
            word = base
    # step 4
    if len(word) >= 4 and word[-1] not in vow2 and word[-1] != "I" and \
            word[-2] == word[-3] and word[-2] in "aeou" and word[-4] not in vow2:
        word = word[:-2] + word[-1]
    return word.replace("Y", "y").replace("I", "i")


# --------------------------------------------------------------- Swedish
def stem_swedish(word):
    word = word.lower()
    vow = "aeiouyäåö"
    r1, _ = _r(word, vow)
    sufs = ["a", "arna", "erna", "heterna", "orna", "ad", "e", "ade", "ande", "arne", "are",
            "aste", "en", "anden", "aren", "heten", "ern", "ar", "er", "heter", "or", "as",
            "arnas", "ernas", "ornas", "es", "ades", "andes", "ens", "arens", "hetens", "erns",
            "at", "andet", "het", "ast", "s"]
    suf = _longest(word, sufs)
    if suf and len(word) - len(suf) >= r1:
        base = word[:-len(suf)]
        if suf == "s":
            if base and base[-1] in "bcdfghjklmnoprtvy":
                word = base
        else:
            word = base
    if len(word) - 1 >= r1 and word.endswith(("dd", "gd", "nn", "dt", "gt", "kt", "tt")) \
            and len(word) - 2 >= r1 - 0:
        word = word[:-1]
    suf = _longest(word, ["lig", "ig", "els", "lös", "fullt"])
    if suf and len(word) - len(suf) >= r1:
        if suf in ("lig", "ig", "els"):
            word = word[:-len(suf)]
        elif suf == "lös":
            word = word[:-1]
        else:
            word = word[:-1]
    return word


# -------------------------------------------------------------- Norwegian
def stem_norwegian(word):
    word = word.lower()
    vow = "aeiouyæåø"
    r1, _ = _r(word, vow)
    sufs = ["a", "e", "ede", "ande", "ende", "ane", "ene", "hetene", "en", "heten", "ar", "er",
            "heter", "as", "ena", "enes", "erte", "ert", "ede", "s"]
    suf = _longest(word, sufs)
    if suf and len(word) - len(suf) >= r1:
        base = word[:-len(suf)]
        if suf == "s":
            if base and (base[-1] in "bcdfghjlmnoprtvyz"
                         or (base[-1] == "k" and len(base) > 1 and base[-2] not in vow)):
                word = base
        elif suf in ("erte", "ert"):
            word = base + "er"
        else:
            word = base
    if len(word) - 1 >= r1 and word.endswith(("dt", "vt")):
        word = word[:-1]
    suf = _longest(word, ["leg", "eleg", "ig", "eig", "lig", "elig", "els", "lov", "elov",
                          "slov", "hetslov"])
    if suf and len(word) - len(suf) >= r1:
        word = word[:-len(suf)]
    return word


# ----------------------------------------------------------------- Danish
def stem_danish(word):
    word = word.lower()
    vow = "aeiouyæåø"
    r1, _ = _r(word, vow)
    sufs = ["hed", "ethed", "ered", "e", "erede", "ende", "erende", "ene", "erne", "ere", "en",
            "heden", "eren", "er", "heder", "erer", "heds", "es", "endes", "erendes", "enes",
            "ernes", "eres", "ens", "hedens", "erens", "ers", "ets", "erets", "et", "eret", "s"]
    suf = _longest(word, sufs)
    if suf and len(word) - len(suf) >= r1:
        base = word[:-len(suf)]
        if suf == "s":
            if base and base[-1] in "abcdfghjklmnoprtvyzå":
                word = base
        else:
            word = base
    if len(word) - 1 >= r1 and word.endswith(("gd", "dt", "gt", "kt")):
        word = word[:-1]
    if word.endswith("igst") and len(word) - 4 >= r1:
        word = word[:-2]
    suf = _longest(word, ["ig", "lig", "elig", "els", "løst"])
    if suf and len(word) - len(suf) >= r1:
        if suf == "løst":
            word = word[:-1]
        else:
            word = word[:-len(suf)]
            if len(word) - 1 >= r1 and word[-2:] in ("gd", "dt", "gt", "kt"):
                word = word[:-1]
            if len(word) >= 2 and word[-1] == word[-2] and word[-1] not in vow \
                    and len(word) - 1 >= r1:
                word = word[:-1]
    elif len(word) >= 2 and word[-1] == word[-2] and word[-1] not in vow and len(word) - 1 >= r1:
        word = word[:-1]
    return word
