"""Approximate stemmers for the remaining Snowball languages."""
import re

_SUFFIXES = {
    "french": ["issements", "issement", "atrices", "atrice", "ations", "ation", "ements",
               "ement", "ances", "ance", "ences", "ence", "ités", "ité", "eaux", "euses",
               "euse", "eux", "ives", "ive", "ifs", "if", "ables", "able", "ments", "ment",
               "ions", "ion", "ent", "ant", "er", "es", "e", "s"],
    "spanish": ["amientos", "amiento", "imientos", "imiento", "aciones", "ación", "uciones",
                "ución", "adoras", "adores", "adora", "ador", "ancias", "ancia", "idades",
                "idad", "mente", "ables", "able", "ibles", "ible", "istas", "ista", "osos",
                "osas", "oso", "osa", "ando", "iendo", "ar", "er", "ir", "os", "as", "es",
                "o", "a", "e", "s"],
    "italian": ["amente", "azione", "azioni", "atore", "atori", "mente", "abile", "ibile",
                "osi", "ose", "oso", "osa", "ando", "endo", "are", "ere", "ire", "i", "e",
                "o", "a"],
    "portuguese": ["amentos", "amento", "imentos", "imento", "adoras", "adores", "ações",
                   "ação", "idades", "idade", "mente", "ável", "ível", "istas", "ista",
                   "osos", "osas", "oso", "osa", "ando", "endo", "ar", "er", "ir", "os",
                   "as", "es", "o", "a", "e", "s"],
    "russian": ["ившись", "ывшись", "ившийся", "ейший", "ующий", "ающий", "ости", "ость",
                "ения", "ение", "ыми", "ими", "ого", "его", "ому", "ему", "ать", "ять",
                "ить", "ыть", "ами", "ями", "ах", "ях", "ов", "ев", "ей", "ом", "ем", "ой",
                "ый", "ий", "ая", "яя", "ое", "ее", "ые", "ие", "ы", "и", "а", "я", "о", "е",
                "у", "ю", "ь"],
    "finnish": ["ssa", "ssä", "sta", "stä", "lla", "llä", "lta", "ltä", "lle", "ksi", "tta",
                "ttä", "ine", "nsa", "nsä", "n", "a", "ä", "t", "i"],
    "hungarian": ["ban", "ben", "nak", "nek", "val", "vel", "ból", "ből", "ról", "ről",
                  "tól", "től", "hoz", "hez", "höz", "ok", "ek", "ök", "ak", "k", "t"],
    "romanian": ["ului", "ilor", "elor", "ările", "area", "ește", "iile", "ile", "ele",
                 "ul", "ii", "ea", "le", "a", "e", "i"],
    "arabic": ["ها", "ان", "ات", "ون", "ين", "ية", "ه", "ة", "ي"],
}


def get(language):
    suffixes = sorted(_SUFFIXES[language], key=len, reverse=True)

    def stem(word):
        word = word.lower()
        for s in suffixes:
            if word.endswith(s) and len(word) - len(s) >= 3:
                return word[:-len(s)]
        return word
    return stem
