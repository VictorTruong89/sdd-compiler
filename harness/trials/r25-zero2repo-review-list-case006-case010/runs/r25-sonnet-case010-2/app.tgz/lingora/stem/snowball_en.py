"""Snowball English (Porter2) stemmer."""

VOWELS = "aeiouy"
DOUBLES = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
LI_END = "cdeghkmnrt"
SPECIAL = {"skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
           "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
           "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
           "cosmos": "cosmos", "bias": "bias", "andes": "andes"}
STEP2 = [("ization", "ize"), ("ational", "ate"), ("fulness", "ful"), ("ousness", "ous"),
         ("iveness", "ive"), ("tional", "tion"), ("biliti", "ble"), ("lessli", "less"),
         ("entli", "ent"), ("ation", "ate"), ("alism", "al"), ("aliti", "al"), ("ousli", "ous"),
         ("iviti", "ive"), ("fulli", "ful"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"),
         ("izer", "ize"), ("ator", "ate"), ("alli", "al"), ("bli", "ble"), ("ogi", "og"),
         ("li", "")]
STEP3 = [("ational", "ate"), ("tional", "tion"), ("alize", "al"), ("icate", "ic"),
         ("iciti", "ic"), ("ative", ""), ("ical", "ic"), ("ness", ""), ("ful", "")]
STEP4 = ["ement", "ance", "ence", "able", "ible", "ment", "ant", "ent", "ism", "ate", "iti",
         "ous", "ive", "ize", "ion", "al", "er", "ic"]


def regions(word, vowels, r1_exceptions=()):
    r1 = len(word)
    for ex, pos in r1_exceptions:
        if word.startswith(ex):
            r1 = pos
            break
    else:
        for i in range(1, len(word)):
            if word[i] not in vowels and word[i - 1] in vowels:
                r1 = i + 1
                break
    r2 = len(word)
    for i in range(r1 + 1, len(word)):
        if word[i] not in vowels and word[i - 1] in vowels:
            r2 = i + 1
            break
    return r1, r2


def _short_syllable_end(w):
    if len(w) == 2:
        return w[0] in VOWELS and w[1] not in VOWELS
    if len(w) >= 3:
        return (w[-1] not in VOWELS and w[-1] not in "wxY"
                and w[-2] in VOWELS and w[-3] not in VOWELS)
    return False


def stem_english(word):
    word = word.lower()
    if len(word) <= 2:
        return word
    if word in SPECIAL:
        return SPECIAL[word]
    word = word.replace("’", "'").replace("‘", "'").replace("‛", "'")
    if word.startswith("'"):
        word = word[1:]
    if word.startswith("y"):
        word = "Y" + word[1:]
    for i in range(1, len(word)):
        if word[i - 1] in VOWELS and word[i] == "y":
            word = word[:i] + "Y" + word[i + 1:]
    r1, r2 = regions(word, VOWELS, (("gener", 5), ("commun", 6), ("arsen", 5)))

    # Step 0
    for suf in ("'s'", "'s", "'"):
        if word.endswith(suf):
            word = word[:-len(suf)]
            break
    # Step 1a
    for suf in ("sses", "ied", "ies", "us", "ss", "s"):
        if word.endswith(suf):
            if suf == "sses":
                word = word[:-2]
            elif suf in ("ied", "ies"):
                word = word[:-2] if len(word) - len(suf) > 1 else word[:-1]
            elif suf == "s":
                if any(c in VOWELS for c in word[:-2]):
                    word = word[:-1]
            break
    if word in ("inning", "outing", "canning", "herring", "earring", "proceed", "exceed",
                "succeed") or word in ("inning",):
        pass
    if word in ("innings", "inning", "outing", "outings", "canning", "cannings", "herring",
                "herrings", "earring", "earrings", "proceed", "proceeds", "proceeded",
                "proceeding", "exceed", "exceeds", "exceeded", "exceeding", "succeed",
                "succeeds", "succeeded", "succeeding"):
        return word
    # Step 1b
    for suf in ("eedly", "ingly", "edly", "eed", "ing", "ed"):
        if word.endswith(suf):
            if suf in ("eed", "eedly"):
                if len(word) - len(suf) >= r1:
                    word = word[:-len(suf)] + "ee"
            else:
                base = word[:-len(suf)]
                if any(c in VOWELS for c in base):
                    word = base
                    if word.endswith(("at", "bl", "iz")):
                        word += "e"
                    elif word.endswith(DOUBLES):
                        word = word[:-1]
                    elif r1 >= len(word) and _short_syllable_end(word):
                        word += "e"
            break
    # Step 1c
    if len(word) > 2 and word[-1] in "yY" and word[-2] not in VOWELS:
        word = word[:-1] + "i"
    # Step 2
    for suf, rep in STEP2:
        if word.endswith(suf):
            if len(word) - len(suf) >= r1:
                if suf == "ogi":
                    if word[-4:-3] == "l":
                        word = word[:-3] + rep
                elif suf == "li":
                    if len(word) >= 3 and word[-3] in LI_END:
                        word = word[:-2]
                else:
                    word = word[:-len(suf)] + rep
            break
    # Step 3
    for suf, rep in STEP3:
        if word.endswith(suf):
            if len(word) - len(suf) >= r1:
                if suf == "ative":
                    if len(word) - len(suf) >= r2:
                        word = word[:-len(suf)]
                else:
                    word = word[:-len(suf)] + rep
            break
    # Step 4
    for suf in STEP4:
        if word.endswith(suf):
            if len(word) - len(suf) >= r2:
                if suf == "ion":
                    if word[-4:-3] in ("s", "t"):
                        word = word[:-3]
                else:
                    word = word[:-len(suf)]
            break
    # Step 5
    if word.endswith("e"):
        if len(word) - 1 >= r2 or (len(word) - 1 >= r1 and not _short_syllable_end(word[:-1])):
            word = word[:-1]
    elif word.endswith("l"):
        if len(word) - 1 >= r2 and word[-2:-1] == "l":
            word = word[:-1]
    return word.replace("Y", "y")
