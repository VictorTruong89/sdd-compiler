"""Snowball stemmer front-end."""
import os
import re

from lingora import data
from lingora.stem import snowball_lang as L
from lingora.stem.porter import PorterStemmer
from lingora.stem.snowball_en import stem_english

LANGUAGES = ("arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian",
             "italian", "norwegian", "porter", "portuguese", "romanian", "russian", "spanish",
             "swedish")


def _fallback(suffixes, vowels):
    suffixes = sorted(suffixes, key=len, reverse=True)

    def stem(word):
        word = word.lower()
        for s in suffixes:
            if word.endswith(s) and len(word) - len(s) >= 3:
                return word[:-len(s)]
        return word
    return stem


_porter = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)

_FUNCS = {
    "english": stem_english,
    "porter": lambda w: _porter.stem(w, to_lowercase=True),
    "german": L.stem_german,
    "dutch": L.stem_dutch,
    "swedish": L.stem_swedish,
    "norwegian": L.stem_norwegian,
    "danish": L.stem_danish,
}


def _load_other(language):
    from lingora.stem import snowball_other
    return snowball_other.get(language)


class SnowballStemmer:
    languages = LANGUAGES

    def __init__(self, language, ignore_stopwords=False):
        if language not in LANGUAGES:
            raise ValueError("The language '%s' is not supported." % language)
        self.language = language
        self.stopwords = set()
        if ignore_stopwords:
            path = data.find("corpora/stopwords/%s" % language)
            with open(path, encoding="utf-8") as f:
                self.stopwords = set(l.strip() for l in f.read().split("\n") if l.strip())
        self._func = _FUNCS.get(language) or _load_other(language)

    def stem(self, word):
        w = word.lower()
        if self.stopwords and w in self.stopwords:
            return w
        return self._func(word)
