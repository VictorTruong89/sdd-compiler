"""LINGORA: a Python natural-language processing library.

Importing the package downloads nothing. Packaged resources (Punkt models,
taggers, stopwords) are looked up through ``lingora.data.path``.
"""

from lingora import data

__version__ = "0.1.0"

__all__ = ["data", "__version__"]
