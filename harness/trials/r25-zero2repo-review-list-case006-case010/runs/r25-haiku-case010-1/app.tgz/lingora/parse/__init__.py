"""Grammar-based parsers: ChartParser (exhaustive) and ShiftReduceParser (one pass)."""

from lingora.grammar import Nonterminal
from lingora.tree import Tree

__all__ = ["ChartParser", "ShiftReduceParser"]


def _check_tokens(grammar, tokens):
    if isinstance(tokens, (str, bytes)) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    known = grammar.terminals()
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("every token must be a str")
        if tok not in known:
            raise ValueError("no production produces the token %r" % tok)


class ChartParser(object):
    """Returns every parse tree the grammar assigns to the token list."""

    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        _check_tokens(self._grammar, tokens)
        tokens = list(tokens)
        grammar = self._grammar
        by_lhs = {}
        for prod in grammar.productions():
            by_lhs.setdefault(str(prod.lhs()), []).append(prod)
        memo = {}
        active = set()

        def sequences(rhs, k, i, j):
            """Child lists for rhs[k:] covering tokens[i:j]."""
            if k == len(rhs):
                if i == j:
                    yield []
                return
            item = rhs[k]
            if isinstance(item, str):
                if item == "":
                    for rest in sequences(rhs, k + 1, i, j):
                        yield rest
                elif i < j and tokens[i] == item:
                    for rest in sequences(rhs, k + 1, i + 1, j):
                        yield [item] + rest
                return
            for m in range(i, j + 1):
                for sub in trees(str(item), i, m):
                    for rest in sequences(rhs, k + 1, m, j):
                        yield [sub] + rest

        def trees(symbol, i, j):
            key = (symbol, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                return []  # cut cyclic derivations over the same span
            active.add(key)
            result = []
            for prod in by_lhs.get(symbol, []):
                for kids in sequences(prod.rhs(), 0, i, j):
                    result.append(Tree(symbol, kids))
            active.discard(key)
            memo[key] = result
            return result

        return iter(trees(str(grammar.start()), 0, len(tokens)))


class ShiftReduceParser(object):
    """A single left-to-right shift-reduce pass without backtracking.

    Reduces whenever the top of the stack matches a production's right-hand
    side (first such production in written order); otherwise shifts. Empty
    productions are never used for reduction, since they would match forever.
    """

    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        _check_tokens(self._grammar, tokens)
        tokens = list(tokens)
        grammar = self._grammar
        productions = [p for p in grammar.productions() if len(p.rhs()) > 0]
        start = str(grammar.start())

        def matches(items, rhs):
            for item, sym in zip(items, rhs):
                if isinstance(sym, str):
                    if not (isinstance(item, str) and item == sym):
                        return False
                else:
                    if not (isinstance(item, Tree) and item.label() == str(sym)):
                        return False
            return True

        stack = []
        pos = 0
        while True:
            reduced = False
            for prod in productions:
                k = len(prod.rhs())
                if k <= len(stack) and matches(stack[-k:], prod.rhs()):
                    children = stack[-k:]
                    del stack[-k:]
                    stack.append(Tree(str(prod.lhs()), list(children)))
                    reduced = True
                    break
            if reduced:
                continue
            if pos < len(tokens):
                stack.append(tokens[pos])
                pos += 1
                continue
            break
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == start:
            return iter([stack[0]])
        return iter([])
