"""Enumerate the sentences a grammar derives (FP-05, Generator)."""

import itertools

from lingora.grammar import Nonterminal

__all__ = ["generate"]


def generate(grammar, start=None, depth=None, n=None):
    """Yield sentences (lists of terminal strings) derived from ``start``.

    Productions are expanded in written order. ``depth`` bounds the derivation
    depth (each nonterminal expansion uses one level); ``None`` is unbounded.
    ``n`` bounds the number of sentences; ``None`` is unbounded. A quoted empty
    string contributes an empty-string token; an empty production contributes none.
    """
    if start is None:
        start = grammar.start()
    elif isinstance(start, str):
        start = Nonterminal(start)
    if depth is not None and not isinstance(depth, int):
        raise TypeError("depth must be an int or None")
    if n is not None and not isinstance(n, int):
        raise TypeError("n must be an int or None")

    def expand_seq(symbols, level):
        if not symbols:
            yield []
            return
        first, rest = symbols[0], symbols[1:]
        if isinstance(first, str):
            for tail in expand_seq(rest, level):
                yield [first] + tail
            return
        if level is not None and level <= 0:
            return
        child_level = None if level is None else level - 1
        for prod in grammar.productions(first):
            for head in expand_seq(list(prod.rhs()), child_level):
                for tail in expand_seq(rest, level):
                    yield head + tail

    sentences = expand_seq([start], depth)
    if n is not None:
        sentences = itertools.islice(sentences, n)
    return sentences
