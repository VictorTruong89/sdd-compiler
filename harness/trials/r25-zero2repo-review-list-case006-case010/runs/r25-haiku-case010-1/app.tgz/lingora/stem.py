"""Stemmers (FP-02).

Built-in families: PorterStemmer (three modes; LINGORA extensions by default),
LancasterStemmer (Paice/Husk), SnowballStemmer, RegexpStemmer, and the
Arabic/WordNet stemmers, which exist as names but are not implemented here.
"""

import re

from lingora import data

__all__ = [
    "ARLSTem",
    "ARLSTem2",
    "LancasterStemmer",
    "PorterStemmer",
    "RegexpStemmer",
    "SnowballStemmer",
    "WordNetLemmatizer",
]

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)


def _check_word(word):
    if not isinstance(word, str):
        raise TypeError("word must be a str, got %s" % type(word).__name__)


# ------------------------------------------------------------------ Porter

ORIGINAL = "original"
MARTIN = "martin"
LINGORA = "lingora"

_IRREGULAR = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie",
    "tying": "tie", "idly": "idl", "gently": "gentl", "ugly": "ugli",
    "early": "earli", "only": "onli", "singly": "singl", "sky": "sky",
    "news": "news", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos",
    "bias": "bias", "andes": "andes",
}


def _is_cons(word, i):
    ch = word[i]
    if ch in "aeiou":
        return False
    if ch == "y":
        return i == 0 or not _is_cons(word, i - 1)
    return True


def _measure(stem):
    n = len(stem)
    m = 0
    i = 0
    while i < n and _is_cons(stem, i):
        i += 1
    while i < n:
        while i < n and not _is_cons(stem, i):
            i += 1
        if i >= n:
            break
        m += 1
        while i < n and _is_cons(stem, i):
            i += 1
    return m


def _has_vowel(stem):
    return any(not _is_cons(stem, i) for i in range(len(stem)))


def _double_cons(word):
    return len(word) >= 2 and word[-1] == word[-2] and _is_cons(word, len(word) - 1)


def _cvc(word, lingora_ext):
    n = len(word)
    if lingora_ext and n == 2:
        return (not _is_cons(word, 0)) and _is_cons(word, 1)
    if n < 3:
        return False
    return (_is_cons(word, n - 3) and not _is_cons(word, n - 2)
            and _is_cons(word, n - 1) and word[-1] not in "wxy")


def _replace_first(word, rules, stem_test):
    """Apply the first rule whose suffix matches (Porter's table semantics)."""
    for suffix, repl in rules:
        if word.endswith(suffix):
            stem = word[: len(word) - len(suffix)]
            if stem_test(stem):
                return stem + repl
            return word
    return word


_STEP2_ORIGINAL = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"),
    ("eli", "e"), ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"),
    ("ator", "ate"), ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"),
    ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_STEP2_LINGORA = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("bli", "ble"), ("entli", "ent"),
    ("eli", "e"), ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"),
    ("ator", "ate"), ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"),
    ("ousness", "ous"), ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_STEP3 = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""),
]
_STEP4 = [
    ("al", ""), ("ance", ""), ("ence", ""), ("er", ""), ("ic", ""),
    ("able", ""), ("ible", ""), ("ant", ""), ("ement", ""), ("ment", ""),
    ("ent", ""), ("ion", ""), ("ou", ""), ("ism", ""), ("ate", ""),
    ("iti", ""), ("ous", ""), ("ive", ""), ("ize", ""),
]


class PorterStemmer(object):
    """Porter's suffix-stripping stemmer.

    ``mode`` selects the algorithm: ``LINGORA`` (default, the LINGORA
    extensions), ``MARTIN`` (Porter's extensions) or ``ORIGINAL``.
    """

    def __init__(self, mode=LINGORA):
        if mode not in (ORIGINAL, MARTIN, LINGORA):
            raise ValueError("unknown Porter mode %r" % (mode,))
        self.mode = mode

    def stem(self, word, to_lowercase=True):
        _check_word(word)
        if to_lowercase:
            word = word.lower()
        if self.mode == LINGORA and word in _IRREGULAR:
            return _IRREGULAR[word]
        return _porter(word, self.mode)


def _porter(word, mode):
    ext = mode == LINGORA
    if len(word) <= 2:
        return word
    # Step 1a
    if word.endswith("sses"):
        word = word[:-2]
    elif word.endswith("ies"):
        if ext and len(word) == 4:
            word = word[:-1]          # four letters: ties -> tie
        else:
            word = word[:-2]          # ponies -> poni
    elif word.endswith("ss"):
        pass
    elif word.endswith("s"):
        if _has_vowel(word[:-1]):
            word = word[:-1]
    # Step 1b
    if ext and word.endswith("ied"):
        word = word[:-3] + ("ie" if len(word) == 4 else "i")
    elif word.endswith("eed"):
        if _measure(word[:-3]) > 0:
            word = word[:-1]
    else:
        suffix = None
        if word.endswith("ed") and _has_vowel(word[:-2]):
            suffix = "ed"
        elif word.endswith("ing") and _has_vowel(word[:-3]):
            suffix = "ing"
        if suffix:
            word = word[: -len(suffix)]
            if word.endswith(("at", "bl", "iz")):
                word += "e"
            elif _double_cons(word) and word[-1] not in "lsz":
                word = word[:-1]
            elif _measure(word) == 1 and _cvc(word, ext):
                word += "e"
    # Step 1c
    if word.endswith("y"):
        stem = word[:-1]
        if ext:
            if len(stem) >= 2 and _is_cons(stem, len(stem) - 1):
                word = stem + "i"
        elif _has_vowel(stem):
            word = stem + "i"
    # Step 2
    if ext and word.endswith("alli") and _measure(word[:-4]) > 0:
        return _porter(word[:-2], mode)
    rules2 = _STEP2_LINGORA if ext else _STEP2_ORIGINAL
    word = _replace_first(word, rules2, lambda s: _measure(s) > 0)
    if ext:
        if word.endswith("fulli") and _measure(word[:-5]) > 0:
            word = word[:-5] + "ful"
        elif word.endswith("logi") and _measure(word[:-3]) > 0:
            word = word[:-4] + "log"
    # Step 3
    word = _replace_first(word, _STEP3, lambda s: _measure(s) > 0)
    # Step 4
    for suffix, repl in _STEP4:
        if word.endswith(suffix):
            stem = word[: -len(suffix)]
            if suffix == "ion":
                if stem and stem[-1] in "st" and _measure(stem) > 1:
                    word = stem
            elif _measure(stem) > 1:
                word = stem + repl
            break
    # Step 5a
    if word.endswith("e"):
        stem = word[:-1]
        m = _measure(stem)
        if m > 1 or (m == 1 and not _cvc(stem, ext)):
            word = stem
    # Step 5b
    if _measure(word) > 1 and _double_cons(word) and word.endswith("l"):
        word = word[:-1]
    return word


# ------------------------------------------------------------------ Lancaster

# Paice/Husk rule table. A rule is written with its pattern reversed (as in
# the published table): "<pattern><digit>[<append>][.|>]" where the digit is
# the number of letters removed, "*" makes the rule apply only to an intact
# word, "." ends the stemming and ">" continues with the next pass.
_LANCASTER_RULES = (
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>",
    "deec2ss.", "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>",
    "gai3y.", "ga2>", "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>",
    "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.",
    "jn1d.", "j1s.", "lbaifi6.", "lbai4y.", "lba3y.", "lbi3.", "lib2l>",
    "lc1.", "lufi4y.", "luf3y.", "lu2.", "lai3>", "lau3>", "la2>", "ll1.",
    "mui3.", "mu*2.", "msi3>", "mm1.", "nois4j>", "noix4ct.", "noi3>",
    "nai3>", "na2>", "nee0.", "ne2>", "nn1.", "pihs4>", "pp1.", "re2>",
    "rae0.", "ra2.", "ro2>", "ru2>", "rr1.", "rt1>", "rei3y>", "sei3y>",
    "sis2.", "si2>", "ssen4>", "ss0.", "suo3>", "su*2.", "s*1>", "s0.",
    "tacilp4y.", "ytic5s.", "tec2>", "tu5.", "tri5>", "tr1.", "tt1.", "ua2.",
    "ue2.", "ui2.", "um1.", "un2.", "ur2>", "us2.", "uu1.", "ve5.", "vi3>",
    "vo2.", "vt1.", "vu2.", "wa1>", "wi3.", "wr1.", "wh3.", "xo2.", "xt1>",
    "yb1.", "yj1.", "zi2>", "zi3.", "zz1.",
)


def _parse_lancaster_rule(text):
    m = re.match(r"^([a-z]+)(\*?)(\d)([a-z]*)([.>])$", text)
    if not m:
        raise ValueError("bad Lancaster rule %r" % text)
    return m.group(1), m.group(2) == "*", int(m.group(3)), m.group(4), m.group(5) == ">"


_PARSED_RULES = [_parse_lancaster_rule(r) for r in _LANCASTER_RULES]


def _lancaster_acceptable(word):
    if not word:
        return False
    if word[0] in "aeiou":
        return len(word) >= 2
    return len(word) >= 3 and any(c in "aeiouy" for c in word[1:])


class LancasterStemmer(object):
    """Paice/Husk stemmer."""

    def stem(self, word):
        _check_word(word)
        word = word.lower()
        intact = True
        while True:
            applied = False
            for pattern, needs_intact, remove, append, cont in _PARSED_RULES:
                if needs_intact and not intact:
                    continue
                rev = word[::-1]
                if not rev.startswith(pattern):
                    continue
                if len(rev) < remove:
                    continue
                new_word = (append + rev[remove:])[::-1]
                if not _lancaster_acceptable(new_word):
                    continue
                word = new_word
                intact = False
                if not cont:
                    return word
                applied = True
                break
            if not applied:
                return word


# ------------------------------------------------------------------ Snowball

_EN_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli",
    "only": "onli", "singly": "singl", "sky": "sky", "news": "news",
    "howe": "howe", "atlas": "atlas", "cosmos": "cosmos", "bias": "bias",
    "andes": "andes",
}
_EN_EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed",
            "exceed", "succeed"}
_EN_VOWELS = "aeiouy"


def _en_is_vowel(ch):
    return ch in _EN_VOWELS


def _en_region(word, start):
    for i in range(max(start, 1), len(word)):
        if not _en_is_vowel(word[i]) and _en_is_vowel(word[i - 1]):
            return i + 1
    return len(word)


def _en_short_syllable(w):
    n = len(w)
    if n == 2:
        return _en_is_vowel(w[0]) and not _en_is_vowel(w[1])
    if n >= 3:
        return (not _en_is_vowel(w[-3]) and _en_is_vowel(w[-2])
                and not _en_is_vowel(w[-1]) and w[-1] not in "wxY")
    return False


_EN_STEP2 = [
    ("ational", "ate", "R1"), ("tional", "tion", "R1"), ("enci", "ence", "R1"),
    ("anci", "ance", "R1"), ("abli", "able", "R1"), ("entli", "ent", "R1"),
    ("izer", "ize", "R1"), ("ization", "ize", "R1"), ("ation", "ate", "R1"),
    ("ator", "ate", "R1"), ("alism", "al", "R1"), ("aliti", "al", "R1"),
    ("alli", "al", "R1"), ("fulness", "ful", "R1"), ("ousli", "ous", "R1"),
    ("ousness", "ous", "R1"), ("iveness", "ive", "R1"), ("iviti", "ive", "R1"),
    ("biliti", "ble", "R1"), ("bli", "ble", "R1"), ("fulli", "ful", "R1"),
    ("lessli", "less", "R1"), ("ogi", "og", "R1"), ("li", "", "R1"),
]
_EN_STEP3 = [
    ("tional", "tion", "R1"), ("ational", "ate", "R1"), ("alize", "al", "R1"),
    ("icate", "ic", "R1"), ("iciti", "ic", "R1"), ("ical", "ic", "R1"),
    ("ful", "", "R1"), ("ness", "", "R1"), ("ative", "", "R2"),
]
_EN_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
    "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion",
]


def _porter2(word):
    """Snowball English (Porter2) stemmer."""
    if len(word) <= 2:
        return word
    if word in _EN_EXC1:
        return _EN_EXC1[word]
    if word.startswith("'"):
        word = word[1:]
    chars = list(word)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and _en_is_vowel(chars[i - 1]):
            chars[i] = "Y"
    word = "".join(chars)
    if word.startswith(("gener", "arsen")):
        r1 = 5
    elif word.startswith("commun"):
        r1 = 6
    else:
        r1 = _en_region(word, 0)
    r2 = _en_region(word, r1)

    # Step 0
    for suffix in ("'s'", "'s", "'"):
        if word.endswith(suffix):
            word = word[: -len(suffix)]
            break
    # Step 1a
    if word.endswith("sses"):
        word = word[:-2]
    elif word.endswith(("ied", "ies")):
        prefix = word[:-3]
        word = prefix + ("i" if len(prefix) > 1 else "ie")
    elif word.endswith(("us", "ss")):
        pass
    elif word.endswith("s"):
        if any(_en_is_vowel(c) for c in word[:-2]):
            word = word[:-1]
    if word in _EN_EXC2:
        return word.replace("Y", "y")
    # Step 1b
    if word.endswith(("eedly", "eed")):
        suffix = "eedly" if word.endswith("eedly") else "eed"
        if len(word) - len(suffix) >= r1:
            word = word[: -len(suffix)] + "ee"
    else:
        for suffix in ("ingly", "edly", "ing", "ed"):
            if word.endswith(suffix):
                stem = word[: -len(suffix)]
                if any(_en_is_vowel(c) for c in stem):
                    word = stem
                    if word.endswith(("at", "bl", "iz")):
                        word += "e"
                    elif word[-2:] in ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt"):
                        word = word[:-1]
                    elif r1 >= len(word) and _en_short_syllable(word):
                        word += "e"
                break
    # Step 1c
    if word[-1:] in ("y", "Y") and len(word) > 2 and not _en_is_vowel(word[-2]):
        word = word[:-1] + "i"
    # Step 2
    best = None
    for suffix, repl, region in _EN_STEP2:
        if word.endswith(suffix) and (best is None or len(suffix) > len(best[0])):
            best = (suffix, repl, region)
    if best:
        suffix, repl, region = best
        start = len(word) - len(suffix)
        if start >= r1:
            if suffix == "ogi":
                if start >= 1 and word[start - 1] == "l":
                    word = word[:start] + repl
            elif suffix == "li":
                if start >= 1 and word[start - 1] in "cdeghkmnrt":
                    word = word[:start]
            else:
                word = word[:start] + repl
    # Step 3
    best = None
    for suffix, repl, region in _EN_STEP3:
        if word.endswith(suffix) and (best is None or len(suffix) > len(best[0])):
            best = (suffix, repl, region)
    if best:
        suffix, repl, region = best
        start = len(word) - len(suffix)
        limit = r1 if region == "R1" else r2
        if start >= limit:
            word = word[:start] + repl
    # Step 4
    best = None
    for suffix in _EN_STEP4:
        if word.endswith(suffix) and (best is None or len(suffix) > len(best)):
            best = suffix
    if best:
        start = len(word) - len(best)
        if start >= r2:
            if best == "ion":
                if start >= 1 and word[start - 1] in "st":
                    word = word[:start]
            else:
                word = word[:start]
    # Step 5
    if word.endswith("e"):
        start = len(word) - 1
        if start >= r2 or (start >= r1 and not _en_short_syllable(word[:-1])):
            word = word[:-1]
    elif word.endswith("l"):
        if len(word) - 1 >= r2 and word[-2:-1] == "l":
            word = word[:-1]
    return word.replace("Y", "y")


class SnowballStemmer(object):
    """Snowball stemmer for the languages in ``SNOWBALL_LANGUAGES``.

    Implemented in this build: ``english`` (Porter2) and ``porter`` (the original
    Porter algorithm). The other listed languages are accepted names, but their
    algorithms are not implemented here, so constructing them raises
    ``NotImplementedError``.
    """

    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in SNOWBALL_LANGUAGES:
            raise ValueError("unsupported Snowball language: %r" % (language,))
        self.language = language
        self.ignore_stopwords = bool(ignore_stopwords)
        self._stopwords = frozenset()
        if self.ignore_stopwords:
            file_path = data.find("corpora/stopwords/%s" % language, isdir=False)
            with open(file_path, encoding="utf-8") as handle:
                self._stopwords = frozenset(
                    line.strip() for line in handle if line.strip()
                )
        if language not in ("english", "porter"):
            raise NotImplementedError(
                "Snowball stemmer for %r is not implemented in this build" % language
            )

    def stem(self, word):
        _check_word(word)
        word = word.lower()
        if self.ignore_stopwords and word in self._stopwords:
            return word
        if self.language == "english":
            return _porter2(word)
        return _porter(word, ORIGINAL)


# ------------------------------------------------------------------ regexp


class RegexpStemmer(object):
    """Removes every match of ``regexp`` from the word."""

    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._regexp = re.compile(regexp)

    def stem(self, word):
        _check_word(word)
        return self._regexp.sub("", word)


# ------------------------------------------------------------------ not implemented


class ARLSTem(object):
    def __init__(self, *args, **kwargs):
        raise NotImplementedError("ARLSTem is not implemented in this build")


class ARLSTem2(object):
    def __init__(self, *args, **kwargs):
        raise NotImplementedError("ARLSTem2 is not implemented in this build")


class WordNetLemmatizer(object):
    """Requires the WordNet resource; the lemmatization itself is not implemented."""

    def __init__(self):
        data.find("corpora/wordnet", isdir=True)  # raises when WordNet is not visible
        raise NotImplementedError("WordNetLemmatizer is not implemented in this build")

    def lemmatize(self, word):  # pragma: no cover
        raise NotImplementedError("WordNetLemmatizer is not implemented in this build")
