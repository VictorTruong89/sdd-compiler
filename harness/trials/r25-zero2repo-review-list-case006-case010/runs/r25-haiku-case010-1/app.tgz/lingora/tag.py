"""Part-of-speech taggers (FP-03).

Sequential taggers that need no downloaded model: DefaultTagger, UnigramTagger,
BigramTagger, TrigramTagger, AffixTagger, RegexpTagger (all with optional
backoff). The recommended English/Russian tagger is ``pos_tag``, which reads a
packaged averaged perceptron model.
"""

import json
import os
import re
from collections import Counter, defaultdict

from lingora import data

__all__ = [
    "AffixTagger",
    "BigramTagger",
    "DefaultTagger",
    "RegexpTagger",
    "TrigramTagger",
    "UnigramTagger",
    "pos_tag",
]


def _check_tokens(tokens):
    if isinstance(tokens, (str, bytes)) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str, got %s" % type(tokens).__name__)
    for tok in tokens:
        if not isinstance(tok, str):
            raise TypeError("every token must be a str")


class SequentialTagger(object):
    """Base class: a tagger assigns a tag to each token from its context or
    passes to its backoff tagger when it assigns none."""

    def __init__(self, backoff=None):
        if backoff is not None and not isinstance(backoff, SequentialTagger):
            raise TypeError("backoff must be a tagger or None")
        self._backoff = backoff

    def choose_tag(self, tokens, index, history):
        raise NotImplementedError

    def _choose_with_backoff(self, tokens, index, history):
        tag = self.choose_tag(tokens, index, history)
        if tag is None and self._backoff is not None:
            tag = self._backoff._choose_with_backoff(tokens, index, history)
        return tag

    def tag(self, tokens):
        _check_tokens(tokens)
        history = []
        out = []
        for i, token in enumerate(tokens):
            tag = self._choose_with_backoff(tokens, i, history)
            history.append(tag)
            out.append((token, tag))
        return out


class DefaultTagger(SequentialTagger):
    """Assigns one tag to every token."""

    def __init__(self, tag):
        super(DefaultTagger, self).__init__(None)
        self._tag = tag

    def choose_tag(self, tokens, index, history):
        return self._tag


def _train_pairs(train):
    if train is None:
        return []
    return list(train)


class UnigramTagger(SequentialTagger):
    """Tags each word with the tag it had most often in training."""

    def __init__(self, train=None, model=None, backoff=None):
        super(UnigramTagger, self).__init__(backoff)
        self._model = dict(model) if model else {}
        if train is not None:
            counts = defaultdict(Counter)
            for sentence in _train_pairs(train):
                for token, tag in sentence:
                    counts[token][tag] += 1
            for token, counter in counts.items():
                best = sorted(counter.items(), key=lambda kv: (-kv[1], str(kv[0])))[0][0]
                self._model[token] = best

    def choose_tag(self, tokens, index, history):
        return self._model.get(tokens[index])


class NgramTagger(SequentialTagger):
    """Tags each word from its word and the n-1 previous tags."""

    n = 2

    def __init__(self, train=None, model=None, backoff=None):
        super(NgramTagger, self).__init__(backoff)
        self._model = dict(model) if model else {}
        if train is not None:
            counts = defaultdict(Counter)
            for sentence in _train_pairs(train):
                history = []
                for token, tag in sentence:
                    key = (self._context(history), token)
                    counts[key][tag] += 1
                    history.append(tag)
            for key, counter in counts.items():
                best = sorted(counter.items(), key=lambda kv: (-kv[1], str(kv[0])))[0][0]
                self._model[key] = best

    def _context(self, history):
        """The n-1 previous tags, padded with None at the start of a sentence."""
        if self.n <= 1:
            return ()
        padded = [None] * (self.n - 1) + list(history)
        return tuple(padded[-(self.n - 1):])

    def choose_tag(self, tokens, index, history):
        return self._model.get((self._context(history), tokens[index]))


class BigramTagger(NgramTagger):
    n = 2


class TrigramTagger(NgramTagger):
    n = 3


class AffixTagger(SequentialTagger):
    """Tags each word from its prefix or suffix of a fixed length."""

    def __init__(self, train=None, affix_length=-3, min_stem_length=2, backoff=None):
        super(AffixTagger, self).__init__(backoff)
        self._affix_length = affix_length
        self._min_stem_length = min_stem_length
        self._model = {}
        if train is not None:
            counts = defaultdict(Counter)
            for sentence in _train_pairs(train):
                for token, tag in sentence:
                    affix = self._affix(token)
                    if affix is not None:
                        counts[affix][tag] += 1
            for affix, counter in counts.items():
                self._model[affix] = sorted(counter.items(), key=lambda kv: (-kv[1], str(kv[0])))[0][0]

    def _affix(self, token):
        if len(token) < self._min_stem_length + abs(self._affix_length):
            return None
        if self._affix_length > 0:
            return token[: self._affix_length]
        return token[self._affix_length:]

    def choose_tag(self, tokens, index, history):
        affix = self._affix(tokens[index])
        return self._model.get(affix) if affix is not None else None


class RegexpTagger(SequentialTagger):
    """Tags a token with the tag of the first rule whose pattern matches its start."""

    def __init__(self, regexps, backoff=None):
        super(RegexpTagger, self).__init__(backoff)
        self._rules = []
        for pattern, tag in regexps:
            if not isinstance(pattern, str) or not isinstance(tag, str):
                raise TypeError("regexps must be (pattern, tag) string pairs")
            self._rules.append((re.compile(pattern), tag))

    def choose_tag(self, tokens, index, history):
        token = tokens[index]
        for regexp, tag in self._rules:
            if regexp.match(token):
                return tag
        return None


# ------------------------------------------------------------------ recommended


_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]
_LANGS = {"eng", "rus"}
_perceptron_cache = {}
_universal_cache = {}


def _normalize(word):
    if "-" in word and word[:1] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word[:1].isdigit():
        return "!DIGITS"
    return word.lower()


class _AveragedPerceptron(object):
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = set(classes)

    def _predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    @staticmethod
    def _features(i, word, context, prev, prev2):
        features = defaultdict(int)

        def add(name, *args):
            features[" ".join((name,) + tuple(args))] += 1

        i += len(_START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[:1])
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return features

    def tag(self, tokens):
        prev, prev2 = _START
        context = _START + [_normalize(w) for w in tokens] + _END
        out = []
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                features = self._features(i, word, context, prev, prev2)
                tag = self._predict(features)
            out.append((word, tag))
            prev2 = prev
            prev = tag
        return out


def _load_perceptron(lang):
    name = "averaged_perceptron_tagger_%s" % lang
    model_dir = data.find("taggers/%s" % name, isdir=True)
    if model_dir in _perceptron_cache:
        return _perceptron_cache[model_dir]
    with open(os.path.join(model_dir, name + ".weights.json"), encoding="utf-8") as handle:
        weights = json.load(handle)
    with open(os.path.join(model_dir, name + ".tagdict.json"), encoding="utf-8") as handle:
        tagdict = json.load(handle)
    with open(os.path.join(model_dir, name + ".classes.json"), encoding="utf-8") as handle:
        classes = json.load(handle)
    model = _AveragedPerceptron(weights, tagdict, classes)
    _perceptron_cache[model_dir] = model
    return model


def _load_universal_map():
    table_dir = data.find("taggers/universal_tagset", isdir=True)
    map_file = os.path.join(table_dir, "en-ptb.map")
    if not os.path.isfile(map_file):
        raise data.ResourceNotFoundError("universal tagset table en-ptb.map not found")
    if map_file in _universal_cache:
        return _universal_cache[map_file]
    mapping = {}
    with open(map_file, encoding="utf-8") as handle:
        for line in handle:
            parts = line.rstrip("\r\n").split("\t")
            if len(parts) == 2:
                mapping[parts[0]] = parts[1]
    _universal_cache[map_file] = mapping
    return mapping


# Russian National Corpus part-of-speech categories -> universal tagset.
_RUS_TO_UNIVERSAL = {
    "S": "NOUN", "A": "ADJ", "ANUM": "ADJ", "V": "VERB", "ADV": "ADV",
    "ADVPRO": "ADV", "PR": "ADP", "CONJ": "CONJ", "PART": "PRT", "NUM": "NUM",
    "APRO": "DET", "SPRO": "PRON", "INTJ": "INTJ", "PRED": "ADV", "COM": "ADJ",
}


def pos_tag(tokens, tagset=None, lang="eng"):
    """Recommended tagger: averaged perceptron, English (``eng``) or Russian (``rus``).

    ``tagset`` is ``None`` for the model's native tags or ``'universal'``.
    Raises when the model for ``lang`` is not visible.
    """
    _check_tokens(tokens)
    if lang not in _LANGS:
        raise ValueError("pos_tag supports only 'eng' and 'rus', not %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal'")
    model = _load_perceptron(lang)
    if tagset == "universal" and lang == "eng":
        mapping = _load_universal_map()
    else:
        mapping = None
    if not tokens:
        return []
    tagged = model.tag(list(tokens))
    out = []
    for token, tag in tagged:
        if tagset == "universal":
            if lang == "eng":
                tag = mapping.get(tag, tag)
            else:
                tag = _RUS_TO_UNIVERSAL.get(tag.split("=", 1)[0], tag)
        out.append((token, tag))
    return out
