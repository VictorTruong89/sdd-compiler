"""Punkt sentence-boundary detection (Kiss and Strunk, 2006).

Parameters come from the packaged Punkt model directory
``tokenizers/punkt_tab/<language>/`` (see the Interface Contract for the file
formats). The decision rules follow the Punkt paper: period-final tokens are
candidate boundaries; abbreviations, initials, numbers and ellipses are
resolved by collocations, sentence starters and orthographic context.
"""

import os
import re

from lingora import data

ORTHO_BEGIN_UC = 2
ORTHO_MID_UC = 4
ORTHO_UNK_UC = 8
ORTHO_BEGIN_LC = 16
ORTHO_MID_LC = 32
ORTHO_UNK_LC = 64
_UC_MASK = ORTHO_BEGIN_UC | ORTHO_MID_UC | ORTHO_UNK_UC
_LC_MASK = ORTHO_BEGIN_LC | ORTHO_MID_LC | ORTHO_UNK_LC

_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_TRAILING = re.compile(r"^(.*?)([.?!]+)([)\]}\"'»”’]*)$", re.DOTALL)
_LEADING_OPEN = "\"'`([{«“‘"


class PunktParameters(object):
    """The packaged parameters of one Punkt model."""

    def __init__(self, abbrev_types, sent_starters, collocations, ortho_context):
        self.abbrev_types = frozenset(abbrev_types)
        self.sent_starters = frozenset(sent_starters)
        self.collocations = frozenset(collocations)
        self.ortho_context = dict(ortho_context)


def _read_lines(file_path):
    if not os.path.isfile(file_path):
        return []
    out = []
    with open(file_path, encoding="utf-8") as handle:
        for line in handle:
            line = line.rstrip("\r\n")
            if line:
                out.append(line)
    return out


_cache = {}


def load_parameters(language):
    """Load the Punkt parameters for ``language``.

    Raises ``ResourceNotFoundError`` when the model directory is not visible.
    """
    model_dir = data.find("tokenizers/punkt_tab/%s" % language, isdir=True)
    if model_dir in _cache:
        return _cache[model_dir]
    abbrev = _read_lines(os.path.join(model_dir, "abbrev_types.txt"))
    starters = _read_lines(os.path.join(model_dir, "sent_starters.txt"))
    colloc = []
    for line in _read_lines(os.path.join(model_dir, "collocations.tab")):
        parts = line.split("\t")
        if len(parts) == 2:
            colloc.append((parts[0], parts[1]))
    ortho = {}
    for line in _read_lines(os.path.join(model_dir, "ortho_context.tab")):
        parts = line.split("\t")
        if len(parts) == 2:
            ortho[parts[0]] = int(parts[1])
    params = PunktParameters(abbrev, starters, colloc, ortho)
    _cache[model_dir] = params
    return params


class _Token(object):
    __slots__ = ("start", "end", "body", "punct", "typ", "first_char")

    def __init__(self, start, end, raw):
        self.start = start
        self.end = end
        match = _TRAILING.match(raw)
        if match:
            self.body, self.punct = match.group(1), match.group(2)
        else:
            self.body, self.punct = raw, ""
        stripped = self.body.lstrip(_LEADING_OPEN)
        self.first_char = stripped[:1]
        self.typ = self.body.lower()
        if _NUMERIC.match(self.body):
            self.typ = "##number##"

    @property
    def candidate(self):
        """Ends with a period, an ellipsis, or a ? / ! sentence character."""
        return bool(self.punct) and "." in self.punct or "?" in self.punct or "!" in self.punct


class PunktSentenceTokenizer(object):
    """Sentence splitter driven by a ``PunktParameters`` set."""

    def __init__(self, params):
        self.params = params

    def _ortho_says_break(self, next_tok):
        """Orthographic heuristic for a token after an abbreviation."""
        ctx = self.params.ortho_context.get(next_tok.typ, 0)
        if next_tok.first_char.isupper():
            if (ctx & _LC_MASK) and not (ctx & _UC_MASK):
                return False
            if (ctx & ORTHO_MID_UC) and not (ctx & (ORTHO_BEGIN_UC | ORTHO_UNK_UC)):
                return False  # usually a capitalised word inside a sentence (a name)
            return True
        return False

    def _is_break(self, tokens, i):
        tok = tokens[i]
        if i + 1 >= len(tokens):
            return True
        nxt = tokens[i + 1]
        if not tok.candidate:
            return False
        if "?" in tok.punct or "!" in tok.punct:
            return True
        if (tok.typ, nxt.typ) in self.params.collocations:
            return False
        is_initial = len(tok.body) == 1 and tok.body.isalpha()
        abbrev = is_initial or tok.typ in self.params.abbrev_types
        ellipsis = tok.punct.startswith("..") and tok.punct.count(".") >= 2
        if not (abbrev or ellipsis):
            return True
        if nxt.typ in self.params.sent_starters:
            return True
        if is_initial:
            return False
        if not nxt.first_char:
            return False
        if nxt.first_char.islower() or nxt.first_char.isdigit():
            return False
        return self._ortho_says_break(nxt)

    def sentences(self, text):
        """Return the sentences of ``text`` in order, without separating whitespace."""
        tokens = [
            _Token(m.start(), m.end(), m.group(0))
            for m in re.finditer(r"\S+", text)
        ]
        out = []
        if not tokens:
            return out
        first = 0
        for i in range(len(tokens)):
            if self._is_break(tokens, i):
                out.append(text[tokens[first].start:tokens[i].end])
                first = i + 1
        return out
