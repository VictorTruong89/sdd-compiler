"""BLEU (Papineni et al., 2002) over token lists (FP-07)."""

import math
from collections import Counter

__all__ = ["bleu", "method1"]

_DEFAULT_WEIGHTS = (0.25, 0.25, 0.25, 0.25)


def method1(matches_and_totals):
    """Smoothing: add 0.1 to each zero match count (a usable ``smoothing_function``)."""
    return [(m if m > 0 else 0.1, t) for m, t in matches_and_totals]


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def bleu(references, hypothesis, weights=None, smoothing_function=None):
    """Sentence-level BLEU of ``hypothesis`` (a token list) against ``references``.

    ``weights`` gives one weight per n-gram order from unigrams; the default is
    equal weights on unigrams through 4-grams. A ``smoothing_function`` takes and
    returns a list of (matches, total) pairs, one per order.
    """
    if not isinstance(references, (list, tuple)) or not isinstance(hypothesis, (list, tuple)):
        raise TypeError("bleu takes a list of reference token lists and a token list")
    if weights is None:
        weights = _DEFAULT_WEIGHTS
    weights = [float(w) for w in weights]
    if not weights:
        raise ValueError("bleu needs at least one weight")
    hyp_len = len(hypothesis)
    if hyp_len == 0:
        return 0.0
    ref_lens = [len(r) for r in references]

    pairs = []
    for n in range(1, len(weights) + 1):
        hyp_counts = _ngrams(hypothesis, n)
        total = sum(hyp_counts.values())
        max_ref = Counter()
        for ref in references:
            for gram, count in _ngrams(ref, n).items():
                if count > max_ref[gram]:
                    max_ref[gram] = count
        matches = sum(min(count, max_ref[gram]) for gram, count in hyp_counts.items())
        pairs.append((matches, total))

    if smoothing_function is not None:
        pairs = list(smoothing_function(pairs))

    log_sum = 0.0
    for weight, (matches, total) in zip(weights, pairs):
        if total == 0 or matches == 0:
            return 0.0
        log_sum += weight * math.log(matches / float(total))

    closest = min(ref_lens, key=lambda r: (abs(r - hyp_len), r))
    if hyp_len > closest:
        brevity = 1.0
    else:
        brevity = math.exp(1 - closest / float(hyp_len))
    return brevity * math.exp(log_sum)
