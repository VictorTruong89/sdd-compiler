"""Evaluation metrics (FP-07). Pure functions of their arguments."""

__all__ = [
    "accuracy",
    "edit_distance",
    "f_measure",
    "jaccard_distance",
    "precision",
    "recall",
]


def accuracy(reference, test):
    """Fraction of positions at which two equal-length lists hold equal values."""
    if not isinstance(reference, (list, tuple)) or not isinstance(test, (list, tuple)):
        raise TypeError("accuracy takes two lists")
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length")
    if not reference:
        raise ValueError("accuracy is undefined for empty lists")
    same = sum(1 for a, b in zip(reference, test) if a == b)
    return same / float(len(reference))


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance. With ``transpositions`` it is the unrestricted
    Damerau-Levenshtein distance (Lowrance and Wagner, 1975)."""
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance takes two str")
    if transpositions:
        return _damerau(s1, s2, substitution_cost)
    len1, len2 = len(s1), len(s2)
    prev = [j for j in range(len2 + 1)]
    for i in range(1, len1 + 1):
        cur = [i] + [0] * len2
        for j in range(1, len2 + 1):
            if s1[i - 1] == s2[j - 1]:
                sub = prev[j - 1]
            else:
                sub = prev[j - 1] + substitution_cost
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, sub)
        prev = cur
    return prev[len2]


def _damerau(s1, s2, sub_cost):
    len1, len2 = len(s1), len(s2)
    maxdist = len1 + len2
    da = {}
    d = [[0] * (len2 + 2) for _ in range(len1 + 2)]
    d[0][0] = maxdist
    for i in range(0, len1 + 1):
        d[i + 1][0] = maxdist
        d[i + 1][1] = i
    for j in range(0, len2 + 1):
        d[0][j + 1] = maxdist
        d[1][j + 1] = j
    for i in range(1, len1 + 1):
        db = 0
        for j in range(1, len2 + 1):
            k = da.get(s2[j - 1], 0)
            l = db
            if s1[i - 1] == s2[j - 1]:
                cost = 0
                db = j
            else:
                cost = sub_cost
            d[i + 1][j + 1] = min(
                d[i][j] + cost,
                d[i + 1][j] + 1,
                d[i][j + 1] + 1,
                d[k][l] + (i - k - 1) + 1 + (j - l - 1),
            )
        da[s1[i - 1]] = i
    result = d[len1 + 1][len2 + 1]
    if isinstance(sub_cost, int):
        return int(result)
    return result


def jaccard_distance(label1, label2):
    """|symmetric difference| / |union| of two sets (0 when both are empty)."""
    set1, set2 = set(label1), set(label2)
    union = set1 | set2
    if not union:
        return 0.0
    return len(set1 ^ set2) / float(len(union))


def _check_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("precision, recall and f_measure take sets")


def precision(reference, test):
    """|reference & test| / |test|; None when ``test`` is empty."""
    _check_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / float(len(test))


def recall(reference, test):
    """|reference & test| / |reference|; None when ``reference`` is empty."""
    _check_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / float(len(reference))


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean of precision and recall; None when no number results."""
    _check_sets(reference, test)
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None or not (reference & test):
        return None
    if p == 0 or r == 0:
        return 0.0
    return 1.0 / (alpha / p + (1.0 - alpha) / r)
