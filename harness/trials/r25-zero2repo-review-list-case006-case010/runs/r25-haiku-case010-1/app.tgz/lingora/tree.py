"""Constituent trees (FP-05)."""

import re

__all__ = ["Tree"]

_BRACKET_TOKEN = re.compile(r"\(|\)|[^\s()]+")


def _leaf_text(leaf):
    if isinstance(leaf, tuple) and len(leaf) == 2:
        return "%s/%s" % (leaf[0], leaf[1])
    return str(leaf)


class Tree(object):
    """A labelled node with an ordered list of children.

    A child is a leaf (a token string, or a (token, tag) pair in chunk trees)
    or another ``Tree``. ``children`` must be a list; a string, or a missing
    argument, is refused with ``TypeError``.
    """

    def __init__(self, label, children):
        if isinstance(children, (str, bytes)) or not isinstance(children, (list, tuple)):
            raise TypeError("children must be a list of children, got %s"
                            % type(children).__name__)
        self._label = label
        self._children = list(children)

    @classmethod
    def fromstring(cls, s):
        """Build a tree from bracketed tree text, e.g. ``(S (NP the dog) (VP barks))``."""
        if not isinstance(s, str):
            raise TypeError("bracketed tree text must be a str")
        tokens = _BRACKET_TOKEN.findall(s)
        pos = [0]

        def node():
            if pos[0] >= len(tokens) or tokens[pos[0]] != "(":
                raise ValueError("expected '(' in bracketed tree text")
            pos[0] += 1
            if pos[0] >= len(tokens) or tokens[pos[0]] in ("(", ")"):
                raise ValueError("node without a label in bracketed tree text")
            label = tokens[pos[0]]
            pos[0] += 1
            children = []
            while True:
                if pos[0] >= len(tokens):
                    raise ValueError("unbalanced parentheses in bracketed tree text")
                tok = tokens[pos[0]]
                if tok == ")":
                    pos[0] += 1
                    break
                if tok == "(":
                    children.append(node())
                else:
                    children.append(tok)
                    pos[0] += 1
            return Tree(label, children)

        if not tokens:
            raise ValueError("empty bracketed tree text")
        result = node()
        if pos[0] != len(tokens):
            raise ValueError("trailing text after bracketed tree")
        return result

    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __iter__(self):
        return iter(self._children)

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    def _flat(self):
        parts = []
        for child in self._children:
            parts.append(child._flat() if isinstance(child, Tree) else _leaf_text(child))
        return "(%s%s)" % (self._label, "".join(" " + p for p in parts))

    def _pretty(self, indent, margin):
        flat = self._flat()
        if indent + len(flat) <= margin or all(not isinstance(c, Tree) for c in self._children):
            return " " * indent + flat
        lines = [" " * indent + "(" + str(self._label)]
        for child in self._children:
            if isinstance(child, Tree):
                lines.append(child._pretty(indent + 2, margin))
            else:
                lines.append(" " * (indent + 2) + _leaf_text(child))
        lines[-1] += ")"
        return "\n".join(lines)

    def pformat(self, margin=70):
        """Pretty-printed bracketed text; every label and leaf appears in pre-order."""
        return self._pretty(0, margin)

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    def __str__(self):
        return self.pformat()
