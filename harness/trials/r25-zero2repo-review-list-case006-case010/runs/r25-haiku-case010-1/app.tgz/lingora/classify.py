"""Text classifiers (FP-06): Naive Bayes and decision tree, plus accuracy."""

import math
from collections import Counter, defaultdict

__all__ = ["DecisionTreeClassifier", "NaiveBayesClassifier", "ProbDist", "accuracy"]

_GAMMA = 0.5  # Expected-likelihood smoothing constant.


class ProbDist(object):
    """A probability distribution over labels."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs.keys())

    def max(self):
        return max(self._probs, key=lambda label: self._probs[label])

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._probs)


def _check_training(labeled_featuresets):
    if not isinstance(labeled_featuresets, (list, tuple)):
        raise TypeError("labeled_featuresets must be a list of (featureset, label) pairs")
    for item in labeled_featuresets:
        if not (isinstance(item, tuple) and len(item) == 2 and isinstance(item[0], dict)):
            raise TypeError("each training item must be a (featureset dict, label) pair")


class NaiveBayesClassifier(object):
    """Naive Bayes over featuresets, with expected-likelihood smoothing."""

    def __init__(self, label_counts, total, feature_counts, feature_values, label_feature_totals):
        self._label_counts = label_counts          # label -> number of examples
        self._total = total
        self._feature_counts = feature_counts      # (label, name, value) -> count
        self._feature_values = feature_values      # name -> set of values seen in training
        self._label_feature_totals = label_feature_totals  # (label, name) -> examples having name

    @classmethod
    def train(cls, labeled_featuresets):
        _check_training(labeled_featuresets)
        label_counts = Counter()
        feature_counts = Counter()
        feature_values = defaultdict(set)
        label_feature_totals = Counter()
        for featureset, label in labeled_featuresets:
            label_counts[label] += 1
            for name, value in featureset.items():
                feature_counts[(label, name, value)] += 1
                feature_values[name].add(value)
                label_feature_totals[(label, name)] += 1
        return cls(dict(label_counts), len(labeled_featuresets), dict(feature_counts),
                   {k: set(v) for k, v in feature_values.items()}, dict(label_feature_totals))

    def labels(self):
        return list(self._label_counts.keys())

    def _log_scores(self, featureset):
        scores = {}
        for label, count in self._label_counts.items():
            score = math.log(count / float(self._total))
            for name, value in featureset.items():
                if name not in self._feature_values:
                    continue  # never seen in training
                bins = len(self._feature_values[name]) + 1
                numer = self._feature_counts.get((label, name, value), 0) + _GAMMA
                denom = self._label_feature_totals.get((label, name), 0) + _GAMMA * bins
                score += math.log(numer / denom)
            scores[label] = score
        return scores

    def prob_classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("featureset must be a dict")
        scores = self._log_scores(featureset)
        top = max(scores.values())
        weights = {label: math.exp(s - top) for label, s in scores.items()}
        norm = sum(weights.values())
        return ProbDist({label: w / norm for label, w in weights.items()})

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("featureset must be a dict")
        scores = self._log_scores(featureset)
        order = self.labels()
        best = order[0]
        for label in order[1:]:
            if scores[label] > scores[best]:
                best = label
        return best


def _entropy(labels):
    total = len(labels)
    counts = Counter(labels)
    return -sum((c / total) * math.log(c / total, 2) for c in counts.values())


class _Leaf(object):
    __slots__ = ("label",)

    def __init__(self, label):
        self.label = label


class _Node(object):
    __slots__ = ("feature", "children", "default")

    def __init__(self, feature, children, default):
        self.feature = feature
        self.children = children
        self.default = default


def _majority(labels):
    counts = Counter(labels)
    best = None
    for label in labels:  # first-seen wins ties
        if best is None or counts[label] > counts[best]:
            best = label
    return best


def _build_tree(examples, features):
    labels = [label for _, label in examples]
    majority = _majority(labels)
    if len(set(labels)) == 1:
        return _Leaf(majority)
    base = _entropy(labels)
    best_feature, best_gain, best_groups = None, 0.0, None
    for name in features:
        groups = defaultdict(list)
        for featureset, label in examples:
            groups[featureset.get(name)].append((featureset, label))
        remainder = 0.0
        for group in groups.values():
            remainder += len(group) / float(len(examples)) * _entropy([l for _, l in group])
        gain = base - remainder
        if gain > best_gain + 1e-12:
            best_feature, best_gain, best_groups = name, gain, groups
    if best_feature is None:
        return _Leaf(majority)
    children = {value: _build_tree(group, features) for value, group in best_groups.items()}
    return _Node(best_feature, children, majority)


class DecisionTreeClassifier(object):
    """Decision tree learned by information gain over featureset tests."""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        _check_training(labeled_featuresets)
        examples = list(labeled_featuresets)
        if not examples:
            raise ValueError("cannot train a decision tree on no examples")
        names = sorted({name for fs, _ in examples for name in fs}, key=repr)
        return cls(_build_tree(examples, names))

    def classify(self, featureset):
        if not isinstance(featureset, dict):
            raise TypeError("featureset must be a dict")
        node = self._root
        while isinstance(node, _Node):
            value = featureset.get(node.feature)
            child = node.children.get(value)
            if child is None:
                return node.default
            node = child
        return node.label


def accuracy(classifier, gold):
    """Fraction of gold (featureset, label) pairs the classifier labels correctly."""
    if len(gold) == 0:
        raise ValueError("accuracy is undefined for an empty gold list")
    correct = sum(1 for featureset, label in gold if classifier.classify(featureset) == label)
    return correct / float(len(gold))
