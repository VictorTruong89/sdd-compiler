"""Command line: ``lingora tokenize`` applies the recommended word tokenizer to each stdin line."""

import sys

from lingora import data
from lingora.tokenize import word_tokenize

__all__ = ["cli"]

EXIT_OK = 0
EXIT_FAILURE = 1
EXIT_USAGE = 2


class _Group(object):
    """A minimal command group with a ``main`` entry."""

    def __init__(self, commands):
        self._commands = commands

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        status = self._run(list(args))
        if standalone_mode:
            sys.exit(status)
        return status

    def _run(self, args):
        if not args or args[0] in ("-h", "--help"):
            sys.stderr.write("usage: lingora COMMAND [OPTIONS]\n\ncommands: %s\n"
                             % ", ".join(sorted(self._commands)))
            return EXIT_OK if args else EXIT_USAGE
        command = args[0]
        if command not in self._commands:
            sys.stderr.write("lingora: no such command %r\n" % command)
            return EXIT_USAGE
        return self._commands[command](args[1:])


def _parse_options(args, allowed):
    options = dict(allowed)
    i = 0
    while i < len(args):
        arg = args[i]
        if arg.startswith("--") and arg[2:] in allowed:
            if i + 1 >= len(args):
                raise ValueError("option %s needs a value" % arg)
            options[arg[2:]] = args[i + 1]
            i += 2
        else:
            raise ValueError("unexpected argument %r" % arg)
    return options


def _tokenize_command(args):
    try:
        options = _parse_options(args, {"language": "english", "delimiter": " ",
                                        "encoding": "utf-8"})
    except ValueError as exc:
        sys.stderr.write("lingora tokenize: %s\n" % exc)
        return EXIT_USAGE
    language = options["language"]
    delimiter = options["delimiter"]
    # The recommended word tokenizer splits sentences first, so the Punkt model
    # must be visible before any token line is written.
    try:
        data.find("tokenizers/punkt_tab/%s" % language, isdir=True)
    except data.ResourceNotFoundError as exc:
        sys.stderr.write("lingora tokenize: %s\n" % exc)
        return EXIT_FAILURE
    for raw in sys.stdin:
        line = raw.rstrip("\r\n")
        try:
            tokens = word_tokenize(line, language=language, preserve_line=False)
        except Exception as exc:  # report and stop; no token line for this input
            sys.stderr.write("lingora tokenize: %s\n" % exc)
            return EXIT_FAILURE
        sys.stdout.write(delimiter.join(tokens) + "\n")
    sys.stdout.flush()
    return EXIT_OK


cli = _Group({"tokenize": _tokenize_command})
