"""Packaged-resource lookup for LINGORA.

``path`` is the list of directories searched for packaged resources
(Punkt models, averaged perceptron taggers, stopword lists, ...). A caller
may replace its contents in place. An empty list means no packaged resource
is visible.
"""

import os


class ResourceNotFoundError(LookupError):
    """A packaged resource that a path needs is not visible on ``data.path``."""


def _initial_path():
    entries = []
    env = os.environ.get("LINGORA_DATA", "")
    entries.extend(p for p in env.split(os.pathsep) if p)
    entries.append(os.path.join(os.path.expanduser("~"), "lingora_data"))
    return entries


path = _initial_path()


def find(resource, isdir=True):
    """Return the first existing location of ``resource`` on ``path``.

    ``resource`` is a name relative to a directory on ``path``. Raises
    ``ResourceNotFoundError`` when no listed directory holds it.
    """
    for base in list(path):
        candidate = os.path.join(base, resource)
        if (os.path.isdir(candidate) if isdir else os.path.isfile(candidate)):
            return candidate
    raise ResourceNotFoundError(
        "packaged resource %r not found in data.path %r" % (resource, list(path))
    )


def is_available(resource, isdir=True):
    """True when ``resource`` can be found on ``path``."""
    try:
        find(resource, isdir=isdir)
    except ResourceNotFoundError:
        return False
    return True
