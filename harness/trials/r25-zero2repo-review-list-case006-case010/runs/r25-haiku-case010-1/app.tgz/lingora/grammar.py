"""Context-free grammars (FP-05).

Grammar text has one production per line: ``LHS -> RHS``. Nonterminals are
bare identifiers; terminals are single- or double-quoted; ``|`` separates
alternatives; nothing after ``->`` is an empty production.
"""

import re

__all__ = ["CFG", "Nonterminal", "Production"]


class Nonterminal(object):
    """A nonterminal symbol. It is not a ``str``; ``str()`` gives its name."""

    __slots__ = ("_symbol",)

    def __init__(self, symbol):
        self._symbol = str(symbol)

    def symbol(self):
        return self._symbol

    def __str__(self):
        return self._symbol

    def __repr__(self):
        return "Nonterminal(%r)" % self._symbol

    def __eq__(self, other):
        return isinstance(other, Nonterminal) and other._symbol == self._symbol

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash(("Nonterminal", self._symbol))


class Production(object):
    """``lhs -> rhs``; rhs items are terminals (``str``) or ``Nonterminal``."""

    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return (isinstance(other, Production) and other._lhs == self._lhs
                and other._rhs == self._rhs)

    def __ne__(self, other):
        return not self.__eq__(other)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = [str(x) if isinstance(x, Nonterminal) else '"%s"' % x for x in self._rhs]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    def __repr__(self):
        return "Production(%s)" % self


_IDENT = re.compile(r"[A-Za-z_][A-Za-z0-9_\-']*")
_ITEM = re.compile(r"""\s*(?:"([^"]*)"|'([^']*)'|(\|)|([^\s|"']+))""")


def _parse_rhs(text):
    """Split an RHS into alternatives; each alternative is a list of items."""
    alternatives = [[]]
    pos = 0
    text = text.rstrip()
    while pos < len(text):
        if text[pos].isspace():
            pos += 1
            continue
        m = _ITEM.match(text, pos)
        if not m or m.end() == pos:
            raise ValueError("bad grammar text near %r" % text[pos:])
        if m.group(3):
            alternatives.append([])
        elif m.group(1) is not None:
            alternatives[-1].append(m.group(1))
        elif m.group(2) is not None:
            alternatives[-1].append(m.group(2))
        else:
            name = m.group(4)
            if not _IDENT.fullmatch(name):
                raise ValueError("bad nonterminal %r" % name)
            alternatives[-1].append(Nonterminal(name))
        pos = m.end()
    return alternatives


class CFG(object):
    """A context-free grammar. The start symbol is the first production's left side."""

    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        productions = []
        for raw in input.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("production without '->': %r" % line)
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not _IDENT.fullmatch(lhs_text):
                raise ValueError("bad left-hand side %r" % lhs_text)
            lhs = Nonterminal(lhs_text)
            for alt in _parse_rhs(rhs_text):
                productions.append(Production(lhs, alt))
        if not productions:
            raise ValueError("grammar has no productions")
        return cls(productions[0].lhs(), productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        return [p for p in self._productions if p.lhs() == lhs]

    def terminals(self):
        out = set()
        for prod in self._productions:
            for item in prod.rhs():
                if isinstance(item, str) and item != "":
                    out.add(item)
        return out

    def __repr__(self):
        return "<CFG with %d productions>" % len(self._productions)
