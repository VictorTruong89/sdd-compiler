"""Chunk parsing with chunk grammars (FP-04).

``RegexpParser(grammar)`` reads clauses of the form::

    NP: {<DT>?<JJ>*<NN>}
        }<VB.*>{

A ``{...}`` pattern chunks matching tag sequences; a ``}...{`` pattern chinks.
Clauses and their rules apply in written order. A later clause may match an
earlier clause's chunk as one unit whose tag is that chunk's label; when it
does, the chunk's tokens are carried into the new chunk as its (token, tag)
children.
"""

import re

from lingora.tree import Tree

__all__ = ["ChunkRule", "RegexpParser", "ne_chunk"]

DEFAULT_ROOT_LABEL = "S"

_QUANT = r"(?:[?*+]|\{\d*,?\d*\})?"


def _parse_quantifier(text):
    if text in ("", None):
        return 1, 1
    if text == "?":
        return 0, 1
    if text == "*":
        return 0, None
    if text == "+":
        return 1, None
    inner = text[1:-1]
    if "," not in inner:
        return int(inner), int(inner)
    lo, hi = inner.split(",", 1)
    return (int(lo) if lo else 0), (int(hi) if hi else None)


class _Element(object):
    __slots__ = ("regexp", "lo", "hi")

    def __init__(self, content, quant):
        self.regexp = re.compile(content)
        self.lo, self.hi = _parse_quantifier(quant)


def _compile_tag_pattern(text):
    """Compile a tag pattern (a sequence of ``<regex>`` elements with quantifiers)."""
    elements = []
    pos = 0
    text = text.strip()
    while pos < len(text):
        m = re.compile(r"\s*<([^<>]*)>\s*(" + _QUANT + r")").match(text, pos)
        if not m:
            raise ValueError("bad tag pattern near %r" % text[pos:])
        try:
            elements.append(_Element(m.group(1), m.group(2)))
        except re.error as exc:
            raise ValueError("bad tag regular expression %r: %s" % (m.group(1), exc))
        pos = m.end()
    return elements


def _ends(elements, k, tags, pos, memo):
    """All positions where elements[k:] can end when matching from ``pos``."""
    if k == len(elements):
        return {pos}
    key = (k, pos)
    if key in memo:
        return memo[key]
    el = elements[k]
    result = set()
    if el.lo == 0:
        result |= _ends(elements, k + 1, tags, pos, memo)
    cur = pos
    reps = 0
    limit = len(tags) if el.hi is None else min(el.hi, len(tags))
    while reps < limit and cur < len(tags) and el.regexp.fullmatch(tags[cur]):
        cur += 1
        reps += 1
        if reps >= el.lo:
            result |= _ends(elements, k + 1, tags, cur, memo)
    memo[key] = result
    return result


def _find_matches(elements, tags):
    """Leftmost-longest, non-overlapping, non-empty matches as (start, end) pairs."""
    matches = []
    n = len(tags)
    start = 0
    while start < n:
        memo = {}
        ends = _ends(elements, 0, tags, start, memo)
        longest = max((e for e in ends if e > start), default=None)
        if longest is None:
            start += 1
        else:
            matches.append((start, longest))
            start = longest
    return matches


class ChunkRule(object):
    """One rule of a clause: a chunk rule (``{...}``) or a chink rule (``}...{``)."""

    def __init__(self, label, pattern, chink=False, clause=None):
        self.label = label
        self.chink = bool(chink)
        self.clause = clause
        self.elements = _compile_tag_pattern(pattern)


_CLAUSE_HEADER = re.compile(r"^([^\s:{}<>]+)\s*:\s*(.*)$")
_CHUNK_BODY = re.compile(r"\{(" + r"(?:\s*<[^<>]*>\s*" + _QUANT + r"\s*)*" + r")\}")
_CHINK_BODY = re.compile(r"\}(" + r"(?:\s*<[^<>]*>\s*" + _QUANT + r"\s*)*" + r")\{")


def _parse_grammar(text):
    rules = []
    label = None
    clause = -1
    for raw in text.splitlines():
        line = raw.rstrip()
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        if not line[:1].isspace():
            m = _CLAUSE_HEADER.match(line.strip())
            if not m:
                raise ValueError("bad chunk grammar clause: %r" % line)
            label = m.group(1)
            clause += 1
            body = m.group(2)
        else:
            if label is None:
                raise ValueError("chunk grammar pattern before any clause: %r" % line)
            body = line.strip()
        pos = 0
        body = body.strip()
        while pos < len(body):
            if body[pos].isspace():
                pos += 1
                continue
            m = _CHUNK_BODY.match(body, pos)
            chink = False
            if not m:
                m = _CHINK_BODY.match(body, pos)
                chink = True
            if not m:
                raise ValueError("bad chunk grammar pattern: %r" % body[pos:])
            rules.append(ChunkRule(label, m.group(1), chink=chink, clause=clause))
            pos = m.end()
    return rules


def _is_pair(item):
    return isinstance(item, (tuple, list)) and len(item) == 2


class RegexpParser(object):
    """Chunk parser for a chunk grammar given as text or as a list of ChunkRule objects."""

    def __init__(self, grammar, root_label=DEFAULT_ROOT_LABEL):
        if isinstance(grammar, str):
            self._rules = _parse_grammar(grammar)
        elif isinstance(grammar, list) and all(isinstance(r, ChunkRule) for r in grammar):
            self._rules = list(grammar)
        else:
            raise TypeError("grammar must be a str or a list of ChunkRule stages")
        self._root = root_label

    def parse(self, tagged):
        if isinstance(tagged, (str, bytes)) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        for item in tagged:
            if not _is_pair(item):
                raise TypeError("each tagged item must be a (token, tag) pair")
        # Entries: ("tok", pair) or ("chunk", label, owner_clause, pairs)
        entries = [("tok", tuple(item)) for item in tagged]
        owner_of = self._rule_owners()
        for index, rule in enumerate(self._rules):
            owner = owner_of[index]
            if rule.chink:
                entries = self._apply_chink(entries, owner, rule)
            else:
                entries = self._apply_chunk(entries, owner, rule)
        children = []
        for entry in entries:
            if entry[0] == "tok":
                children.append(entry[1])
            else:
                children.append(Tree(entry[1], list(entry[3])))
        return Tree(self._root, children)

    def _rule_owners(self):
        # Clause index for each rule: a new clause starts whenever the label changes
        # in the rule list, except that consecutive rules of one clause share an index.
        owners = []
        clause = -1
        prev_label = object()
        prev_clause = object()
        for rule in self._rules:
            if rule.clause is not None:
                if rule.clause != prev_clause:
                    clause += 1
                    prev_clause = rule.clause
            elif rule.label != prev_label:
                clause += 1
                prev_label = rule.label
            owners.append(clause)
        return owners

    @staticmethod
    def _entry_tag(entry):
        return entry[1][1] if entry[0] == "tok" else entry[1]

    @staticmethod
    def _flatten(entries):
        pairs = []
        for entry in entries:
            if entry[0] == "tok":
                pairs.append(entry[1])
            else:
                pairs.extend(entry[3])
        return pairs

    def _apply_chunk(self, entries, owner, rule):
        out = []
        segment = []

        def flush():
            tags = [self._entry_tag(e) for e in segment]
            cursor = 0
            for start, end in _find_matches(rule.elements, tags):
                out.extend(segment[cursor:start])
                out.append(("chunk", rule.label, owner,
                            self._flatten(segment[start:end])))
                cursor = end
            out.extend(segment[cursor:])
            del segment[:]

        for entry in entries:
            if entry[0] == "chunk" and entry[2] == owner:
                flush()
                out.append(entry)
            else:
                segment.append(entry)
        flush()

        # Chunks of this clause that touch are joined into one chunk.
        merged = []
        for entry in out:
            if (merged and entry[0] == "chunk" and merged[-1][0] == "chunk"
                    and entry[2] == owner and merged[-1][2] == owner
                    and entry[1] == merged[-1][1]):
                merged[-1] = ("chunk", entry[1], owner, merged[-1][3] + entry[3])
            else:
                merged.append(entry)
        return merged

    def _apply_chink(self, entries, owner, rule):
        out = []
        for entry in entries:
            if entry[0] != "chunk" or entry[2] != owner:
                out.append(entry)
                continue
            pairs = entry[3]
            tags = [p[1] for p in pairs]
            matches = _find_matches(rule.elements, tags)
            if not matches:
                out.append(entry)
                continue
            cursor = 0
            for start, end in matches:
                if start > cursor:
                    out.append(("chunk", entry[1], owner, pairs[cursor:start]))
                for pair in pairs[start:end]:
                    out.append(("tok", pair))
                cursor = end
            if cursor < len(pairs):
                out.append(("chunk", entry[1], owner, pairs[cursor:]))
        return out


def ne_chunk(tagged_tokens):
    """Named-entity chunker. Requires the packaged NE model and the English wordlist."""
    from lingora import data

    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass", isdir=True)
    data.find("corpora/words", isdir=False)
    raise NotImplementedError("the named-entity chunker is not implemented in this build")
