"""Tokenizers (FP-01).

Entries: wordpunct_tokenize, WordPunctTokenizer, TreebankWordTokenizer,
word_tokenize (recommended word tokenizer), sent_tokenize (recommended
sentence tokenizer), WhitespaceTokenizer, blankline_tokenize,
RegexpTokenizer, TweetTokenizer.
"""

import re

from lingora import _punkt

__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]


def _check_text(text):
    if not isinstance(text, str):
        raise TypeError("expected str, got %s" % type(text).__name__)


# ---------------------------------------------------------------- word/punct

_WORDPUNCT = re.compile(r"\w+|[^\w\s]+")


class WordPunctTokenizer(object):
    """Splits into maximal runs of word characters and of other non-space characters."""

    def tokenize(self, text):
        _check_text(text)
        return _WORDPUNCT.findall(text)

    def span_tokenize(self, text):
        _check_text(text)
        return [m.span() for m in _WORDPUNCT.finditer(text)]


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


# ------------------------------------------------------------------ whitespace


class WhitespaceTokenizer(object):
    def tokenize(self, text):
        _check_text(text)
        return text.split()

    def span_tokenize(self, text):
        _check_text(text)
        return [m.span() for m in re.finditer(r"\S+", text)]


# ------------------------------------------------------------------ blank line

_BLANKLINE_SEP = re.compile(r"\s*\n\s*\n\s*")


def blankline_tokenize(text):
    _check_text(text)
    return [piece for piece in _BLANKLINE_SEP.split(text) if piece]


# ------------------------------------------------------------------ regexp


class RegexpTokenizer(object):
    """Tokens are the matches of ``pattern`` (or the gaps between them when ``gaps``)."""

    def __init__(self, pattern, gaps=False, discard_empty=True, flags=0):
        self._regexp = re.compile(pattern, flags) if isinstance(pattern, str) else pattern
        self._gaps = bool(gaps)
        self._discard_empty = bool(discard_empty)

    def _spans(self, text):
        spans = []
        if self._gaps:
            pos = 0
            for m in self._regexp.finditer(text):
                spans.append((pos, m.start()))
                pos = m.end()
            spans.append((pos, len(text)))
        else:
            spans = [m.span() for m in self._regexp.finditer(text)]
        if self._discard_empty:
            spans = [(s, e) for (s, e) in spans if e > s]
        return spans

    def tokenize(self, text):
        _check_text(text)
        return [text[s:e] for (s, e) in self._spans(text)]

    def span_tokenize(self, text):
        _check_text(text)
        return self._spans(text)


# ------------------------------------------------------------------ Treebank

_START_QUOTE_RULES = [
    (re.compile(r"([ \(\[{<])(\"|'{2})"), r"\1 `` "),
    (re.compile(r"(``)"), r" \1 "),
]
_PUNCT_RULES = [
    (re.compile(r"([:,])([^\d])"), r" \1 \2"),
    (re.compile(r"([:,])$"), r" \1 "),
    (re.compile(r"\.\.\."), r" ... "),
    (re.compile(r"[;@#$%&]"), r" \g<0> "),
    (re.compile(r"([^\.])(\.)([\]\)}>\"']*)\s*$"), r"\1 \2\3 "),
    (re.compile(r"[?!]"), r" \g<0> "),
    (re.compile(r"([^'])' "), r"\1 ' "),
]
_BRACKET_RULE = (re.compile(r"[\]\[\(\)\{\}<>]"), r" \g<0> ")
_DASH_RULE = (re.compile(r" -- "), r" -- ")
_END_QUOTE_RULES = [
    (re.compile(r"(\S)('')"), r"\1 \2 "),
    (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
]
_CONTRACTIONS2 = [
    re.compile(r"(?i)\b(can)(not)\b"),
    re.compile(r"(?i)\b(d)('ye)\b"),
    re.compile(r"(?i)\b(gim)(me)\b"),
    re.compile(r"(?i)\b(gon)(na)\b"),
    re.compile(r"(?i)\b(got)(ta)\b"),
    re.compile(r"(?i)\b(lem)(me)\b"),
    re.compile(r"(?i)\b(more)('n)\b"),
    re.compile(r"(?i)\b(wan)(na)(?=\s)"),
]
_CONTRACTIONS3 = [
    re.compile(r"(?i) ('t)(is)\b"),
    re.compile(r"(?i) ('t)(was)\b"),
]
_TYPOGRAPHIC_QUOTES = re.compile(r"([“”„‟«»‘’‚‛])")
_DASHES_AND_STARS = re.compile(r"([\u2012-\u2015*])")
_RUN_OF_POINTS = re.compile(r"\.{2,}")
_DOUBLE_HYPHEN = re.compile(r"--")
_SENTINEL = "\x00"


def _treebank(text, improved, at_text_start):
    """Shared implementation of the Penn Treebank conventions (and the improved variant)."""
    if not text.strip():
        return []
    text = " " + text + " "
    if improved and at_text_start and text[1:2] == '"':
        # Straight quote at the very start of the text is a closing-quote token.
        text = " " + _SENTINEL + text[2:]
    if improved:
        text = _TYPOGRAPHIC_QUOTES.sub(r" \1 ", text)
        text = _DASHES_AND_STARS.sub(r" \1 ", text)
    for rx, rep in _START_QUOTE_RULES:
        text = rx.sub(rep, text)
    text = text.replace('"', " '' ")
    if improved:
        text = _RUN_OF_POINTS.sub(lambda m: " %s " % m.group(0), text)
    for rx, rep in _PUNCT_RULES:
        text = rx.sub(rep, text)
    text = _BRACKET_RULE[0].sub(_BRACKET_RULE[1], text)
    text = _DASH_RULE[0].sub(_DASH_RULE[1], text)
    if improved:
        text = _DOUBLE_HYPHEN.sub(" -- ", text)
    for rx, rep in _END_QUOTE_RULES:
        text = rx.sub(rep, text)
    for rx in _CONTRACTIONS2:
        if improved and rx.pattern.startswith(r"(?i)\b(can)"):
            continue  # the improved tokenizer keeps "cannot" as one token
        text = rx.sub(r" \1 \2 ", text)
    for rx in _CONTRACTIONS3:
        text = rx.sub(r" \1 \2 ", text)
    text = text.replace(_SENTINEL, " '' ")
    return text.split()


class TreebankWordTokenizer(object):
    """Penn Treebank word tokenizer."""

    def tokenize(self, text):
        _check_text(text)
        return _treebank(text, improved=False, at_text_start=True)


# ------------------------------------------------------------------ recommended


def _check_language(language):
    if not isinstance(language, str):
        raise TypeError("language must be a str")


def sent_tokenize(text, language="english"):
    """Split ``text`` into sentences with the Punkt model for ``language``."""
    _check_text(text)
    _check_language(language)
    params = _punkt.load_parameters(language)  # raises when the model is missing
    return _punkt.PunktSentenceTokenizer(params).sentences(text)


def word_tokenize(text, language="english", preserve_line=False):
    """Recommended word tokenizer: improved Penn Treebank conventions.

    Unless ``preserve_line`` is true, the text is first split into sentences with
    the Punkt model for ``language`` (required in that case).
    """
    _check_text(text)
    _check_language(language)
    if preserve_line:
        return _treebank(text, improved=True, at_text_start=True)
    sentences = sent_tokenize(text, language=language)
    tokens = []
    for index, sentence in enumerate(sentences):
        tokens.extend(_treebank(sentence, improved=True, at_text_start=index == 0))
    return tokens


# ------------------------------------------------------------------ tweet

_HANDLE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")
_EMOTICON = (
    r"(?::|;|=)(?:-|o|O|\^)?[)(\]\[DdPpOo/\\|3]"
    r"|<3"
    r"|\^_\^"
    r"|[xX]D"
)
_TWEET_TOKEN = re.compile(
    "(?:"
    + r"<[^<>\s]+>"                               # HTML tags
    + r"|(?:https?|ftp)://\S+|www\.\S+"           # URLs
    + r"|" + _EMOTICON                            # emoticons
    + r"|[#]\w+"                                  # hashtags
    + r"|@\w+"                                    # @-handles
    + r"|\w+(?:['’]\w+)+"                         # words with internal apostrophe
    + r"|[+-]?\d+(?:[.,:]\d+)*"                   # numbers
    + r"|\w+(?:[-.]\w+)*"                         # words, hyphenated words
    + r"|\.{2,}"                                  # ellipsis / runs of points
    + r"|[^\w\s]"                                 # other punctuation
    + ")",
    re.UNICODE,
)
_TWEET_EMOTICON = re.compile("(?:" + _EMOTICON + ")$")


class TweetTokenizer(object):
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = bool(preserve_case)
        self.reduce_len = bool(reduce_len)
        self.strip_handles = bool(strip_handles)

    def tokenize(self, text):
        _check_text(text)
        if self.strip_handles:
            text = _HANDLE.sub(" ", text)
        if self.reduce_len:
            text = re.sub(r"(.)\1{2,}", r"\1\1\1", text, flags=re.DOTALL)
        tokens = _TWEET_TOKEN.findall(text)
        if not self.preserve_case:
            tokens = [t if _TWEET_EMOTICON.match(t) else t.lower() for t in tokens]
        return tokens
