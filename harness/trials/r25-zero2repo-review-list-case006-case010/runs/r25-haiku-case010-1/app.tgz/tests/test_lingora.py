"""Behavioural tests for LINGORA. Packaged data is built in a temporary directory."""

import json
import os
import subprocess
import sys

import pytest

from lingora import data
from lingora.classify import DecisionTreeClassifier, NaiveBayesClassifier, accuracy
from lingora.chunk import RegexpParser
from lingora.grammar import CFG
from lingora.metrics import edit_distance, f_measure, precision, recall
from lingora.metrics import accuracy as list_accuracy
from lingora.parse import ChartParser, ShiftReduceParser
from lingora.parse.generate import generate
from lingora.stem import LancasterStemmer, PorterStemmer, SnowballStemmer
from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger, pos_tag
from lingora.tokenize import (
    RegexpTokenizer, TreebankWordTokenizer, TweetTokenizer, WhitespaceTokenizer,
    WordPunctTokenizer, blankline_tokenize, sent_tokenize, word_tokenize,
    wordpunct_tokenize,
)
from lingora.translate import bleu
from lingora.tree import Tree


@pytest.fixture
def resources(tmp_path, monkeypatch):
    """A data directory with Punkt, perceptron, universal-map and stopword resources."""
    root = tmp_path / "lingora_data"
    punkt = root / "tokenizers" / "punkt_tab" / "english"
    punkt.mkdir(parents=True)
    (punkt / "abbrev_types.txt").write_text("dr\nmr\ne.g\n##number##\n", encoding="utf-8")
    (punkt / "sent_starters.txt").write_text("he\nshe\nthe\n", encoding="utf-8")
    (punkt / "collocations.tab").write_text("mr\tjones\n", encoding="utf-8")
    (punkt / "ortho_context.tab").write_text("smith\t4\njones\t4\n", encoding="utf-8")
    tagger = root / "taggers" / "averaged_perceptron_tagger_eng"
    tagger.mkdir(parents=True)
    (tagger / "averaged_perceptron_tagger_eng.weights.json").write_text(
        json.dumps({"bias": {"NN": 0.1}, "i word dog": {"NN": 3.0}}), encoding="utf-8")
    (tagger / "averaged_perceptron_tagger_eng.tagdict.json").write_text(
        json.dumps({"the": "DT"}), encoding="utf-8")
    (tagger / "averaged_perceptron_tagger_eng.classes.json").write_text(
        json.dumps(["DT", "NN"]), encoding="utf-8")
    universal = root / "taggers" / "universal_tagset"
    universal.mkdir(parents=True)
    (universal / "en-ptb.map").write_text("DT\tDET\nNN\tNOUN\n", encoding="utf-8")
    stop = root / "corpora" / "stopwords"
    stop.mkdir(parents=True)
    (stop / "english").write_text("the\na\nof\n", encoding="utf-8")
    monkeypatch.setattr(data, "path", [str(root)])
    return root


# ---------------------------------------------------------------- tokenizers


def test_wordpunct_and_spans():
    assert wordpunct_tokenize("Hello, world! 3.5") == ["Hello", ",", "world", "!", "3", ".", "5"]
    assert WordPunctTokenizer().span_tokenize("ab, c") == [(0, 2), (2, 3), (4, 5)]
    assert wordpunct_tokenize("   ") == []


def test_treebank_conventions():
    tokens = TreebankWordTokenizer().tokenize("They can't go, cannot. Gonna...")
    assert tokens == ["They", "ca", "n't", "go", ",", "can", "not", ".", "Gon", "na", "..."]


def test_whitespace_blankline_regexp():
    assert WhitespaceTokenizer().tokenize(" a \t b\n") == ["a", "b"]
    assert blankline_tokenize("a\nb\n\n\n c \n\n d") == ["a\nb", "c", "d"]
    assert RegexpTokenizer(r"\w+").tokenize("x y,z") == ["x", "y", "z"]
    assert RegexpTokenizer(r",", gaps=True).tokenize("a,,b") == ["a", "b"]
    assert RegexpTokenizer(r",", gaps=True, discard_empty=False).tokenize("a,,b") == ["a", "", "b"]


def test_tweet_tokenizer_defaults_and_options():
    assert TweetTokenizer().tokenize("Don't stop :) ÉCOLE!!!") == [
        "Don't", "stop", ":)", "ÉCOLE", "!", "!", "!"]
    assert TweetTokenizer(preserve_case=False, strip_handles=True).tokenize("@bob HELLO") == [
        "hello"]
    assert TweetTokenizer(reduce_len=True).tokenize("wooooow") == ["wooow"]


def test_sentence_tokenizer_needs_model(resources):
    text = "Dr. Smith went home. He was tired. Mr. Jones arrived today!"
    assert sent_tokenize(text) == [
        "Dr. Smith went home.", "He was tired.", "Mr. Jones arrived today!"]
    assert word_tokenize("Dr. Smith went home.", preserve_line=True) == [
        "Dr.", "Smith", "went", "home", "."]


def test_sentence_tokenizer_fails_without_model(tmp_path, monkeypatch):
    monkeypatch.setattr(data, "path", [str(tmp_path)])
    with pytest.raises(LookupError):
        sent_tokenize("A sentence.")
    with pytest.raises(LookupError):
        word_tokenize("A sentence.")
    # The model-free path still works.
    assert word_tokenize("A sentence.", preserve_line=True) == ["A", "sentence", "."]


def test_cli_tokenize(resources):
    env = dict(os.environ, LINGORA_DATA=str(resources))
    proc = subprocess.run(
        [sys.executable, "-m", "lingora", "tokenize"],
        input="Dr. Smith went home. He was tired.\n", capture_output=True,
        text=True, env=env, cwd=os.path.dirname(os.path.dirname(__file__)))
    assert proc.returncode == 0
    assert proc.stdout == "Dr. Smith went home . He was tired .\n"


def test_cli_fails_without_model(tmp_path):
    env = dict(os.environ, LINGORA_DATA=str(tmp_path), HOME=str(tmp_path))
    proc = subprocess.run(
        [sys.executable, "-m", "lingora", "tokenize"], input="x\n", capture_output=True,
        text=True, env=env, cwd=os.path.dirname(os.path.dirname(__file__)))
    assert proc.returncode != 0
    assert proc.stdout == ""


# ---------------------------------------------------------------- stemmers


@pytest.mark.parametrize("word,expected", [
    ("caresses", "caress"), ("ponies", "poni"), ("ties", "tie"), ("cats", "cat"),
    ("agreed", "agre"), ("motoring", "motor"), ("hopping", "hop"),
    ("relational", "relat"), ("hopefulness", "hope"), ("died", "die"),
])
def test_porter_lingora_mode(word, expected):
    assert PorterStemmer().stem(word) == expected


def test_porter_lowercases_by_default_and_handles_short_words():
    assert PorterStemmer().stem("Running") == "run"
    assert PorterStemmer().stem("Running", to_lowercase=False) == "Run"
    assert PorterStemmer().stem("is") == "is"


def test_snowball_english_and_stopwords(resources):
    stemmer = SnowballStemmer("english")
    assert stemmer.stem("generously") == "generous"
    assert stemmer.stem("cats") == "cat"
    skipping = SnowballStemmer("english", ignore_stopwords=True)
    assert skipping.stem("The") == "the"


def test_snowball_rejects_unknown_language():
    with pytest.raises(ValueError, match="klingon"):
        SnowballStemmer("klingon")


def test_lancaster_basics():
    assert LancasterStemmer().stem("maximum") == "maxim"
    assert LancasterStemmer().stem("running") == "run"


# ---------------------------------------------------------------- tagging


def test_sequential_taggers():
    train = [[("the", "DT"), ("dog", "NN")], [("the", "DT"), ("cat", "NN")]]
    tagger = UnigramTagger(train=train, backoff=DefaultTagger("XX"))
    assert tagger.tag(["the", "zebra"]) == [("the", "DT"), ("zebra", "XX")]
    assert UnigramTagger(train=train).tag(["zebra"]) == [("zebra", None)]
    assert RegexpTagger([(r".*ing$", "VBG")]).tag(["running", "x"]) == [
        ("running", "VBG"), ("x", None)]
    assert DefaultTagger("NN").tag([]) == []


def test_pos_tag_perceptron(resources):
    assert pos_tag(["the", "dog"]) == [("the", "DT"), ("dog", "NN")]
    assert pos_tag(["the", "dog"], tagset="universal") == [("the", "DET"), ("dog", "NOUN")]
    with pytest.raises(TypeError):
        pos_tag("the dog")
    with pytest.raises(ValueError):
        pos_tag(["x"], lang="deu")


def test_pos_tag_fails_without_resource(tmp_path, monkeypatch):
    monkeypatch.setattr(data, "path", [str(tmp_path)])
    with pytest.raises(LookupError):
        pos_tag(["the"])


# ---------------------------------------------------------------- chunking


def test_chunk_rule_and_chink():
    tagged = [("the", "DT"), ("big", "JJ"), ("dog", "NN"), ("barked", "VBD"), ("the", "DT"), ("cat", "NN")]
    tree = RegexpParser("NP: {<DT>?<JJ>*<NN>}").parse(tagged)
    assert tree.label() == "S"
    assert [c.label() for c in tree if isinstance(c, Tree)] == ["NP", "NP"]
    assert tree.leaves() == tagged
    chinked = RegexpParser("NP: {<DT><JJ>*<NN>}\n    }<VBD>{").parse(tagged)
    assert chinked.leaves() == tagged
    assert RegexpParser("S: {<A>}").parse([]) == Tree("S", [])


def test_chunk_grammar_refused():
    with pytest.raises(TypeError):
        RegexpParser(42)


# ---------------------------------------------------------------- grammars


GRAMMAR = """
S -> NP VP
NP -> 'I' | Det N | NP PP
VP -> V NP | VP PP
PP -> P NP
Det -> 'the' | 'a'
N -> 'man' | 'telescope'
V -> 'saw'
P -> 'with'
"""


def test_chart_parser_ambiguity_and_errors():
    grammar = CFG.fromstring(GRAMMAR)
    trees = list(ChartParser(grammar).parse("I saw the man with a telescope".split()))
    assert len(trees) == 2
    assert all(t.label() == "S" and t.leaves() == "I saw the man with a telescope".split()
               for t in trees)
    assert list(ChartParser(grammar).parse("I saw".split())) == []
    with pytest.raises(ValueError):
        list(ChartParser(grammar).parse(["unknown"]))


def test_shift_reduce_matches_chart_on_unambiguous():
    grammar = CFG.fromstring("S -> NP VP\nNP -> 'I'\nVP -> 'ran'")
    chart = list(ChartParser(grammar).parse(["I", "ran"]))
    shift = list(ShiftReduceParser(grammar).parse(["I", "ran"]))
    assert shift == chart and len(shift) == 1


def test_generator_and_trees():
    grammar = CFG.fromstring("S -> 'a' S | 'b'")
    assert list(generate(grammar, depth=4)) == [["a", "a", "a", "b"], ["a", "a", "b"], ["a", "b"], ["b"]]
    tree = Tree.fromstring("(S (NP the dog) (VP barks))")
    assert tree == Tree("S", [Tree("NP", ["the", "dog"]), Tree("VP", ["barks"])])
    assert tree.leaves() == ["the", "dog", "barks"] and len(tree) == 2
    with pytest.raises(TypeError):
        Tree("S", "x")
    with pytest.raises(TypeError):
        Tree("S")
    assert len(Tree("X", [])) == 0


# ---------------------------------------------------------------- classify


def test_naive_bayes_and_tree():
    nb = NaiveBayesClassifier.train([({"w": "a"}, "pos"), ({"w": "b"}, "neg"), ({"w": "a", "x": 1}, "pos")])
    assert nb.classify({"w": "a"}) == "pos"
    assert nb.classify({"unseen": 1}) in nb.labels()
    dist = nb.prob_classify({"w": "b"})
    assert abs(sum(dist.prob(l) for l in nb.labels()) - 1.0) < 1e-9
    dt = DecisionTreeClassifier.train([({"f": 1}, "x"), ({"f": 0}, "y")])
    assert dt.classify({"f": 1}) == "x" and dt.classify({"f": 0}) == "y"
    assert accuracy(dt, [({"f": 1}, "x"), ({"f": 0}, "x")]) == 0.5


# ---------------------------------------------------------------- metrics


def test_metrics():
    assert list_accuracy([1, 2, 3], [1, 2, 4]) == pytest.approx(2 / 3)
    with pytest.raises(ValueError):
        list_accuracy([1], [1, 2])
    assert edit_distance("kitten", "sitting") == 3
    assert edit_distance("ca", "abc") == 3
    assert edit_distance("ca", "abc", transpositions=True) == 2
    assert edit_distance("ab", "ba", transpositions=True) == 1
    assert edit_distance("", "") == 0
    assert precision({1, 2}, {2, 3}) == 0.5
    assert recall({1, 2}, {2, 3}) == 0.5
    assert precision({1}, set()) is None
    assert f_measure({1}, {2}) is None
    with pytest.raises(TypeError):
        precision([1], [1])


def test_bleu():
    ref = "the cat sat on the mat".split()
    assert bleu([ref], ref) == pytest.approx(1.0)
    assert bleu([ref], "a b c d".split()) == 0.0
