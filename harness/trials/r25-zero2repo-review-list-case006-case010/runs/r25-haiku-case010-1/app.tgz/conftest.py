# Keeps the project root on sys.path so `import lingora` works from the source tree.
