"""Declaration decorators."""
from __future__ import annotations

import inspect
from functools import update_wrapper

from .core import Argument, Command, Group, Option
from .globals import get_current_context
from .utils import echo


def pass_context(f):
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return update_wrapper(new_func, f)


def pass_obj(f):
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(
                    f"Managed to invoke callback without a context object of type {object_type.__name__!r} existing.")
            return ctx.invoke(f, obj, *args, **kwargs)

        return update_wrapper(new_func, f)

    return decorator


def _param_memo(f, param):
    if isinstance(f, Command):
        f.params.append(param)
    else:
        if not hasattr(f, "__optlyn_params__"):
            f.__optlyn_params__ = []
        f.__optlyn_params__.append(param)


def _make_command(f, name, attrs, cls):
    if isinstance(f, Command):
        raise TypeError("Attempted to convert a callback into a command twice.")
    params = list(reversed(f.__dict__.get("__optlyn_params__", []))) if hasattr(f, "__dict__") else []
    if hasattr(f, "__optlyn_params__"):
        del f.__optlyn_params__
    attrs = dict(attrs)
    if attrs.get("help") is None:
        attrs["help"] = inspect.getdoc(f)
    else:
        attrs["help"] = inspect.cleandoc(attrs["help"])
    if name is None:
        cmd_name = f.__name__.lower().replace("_", "-")
        left, sep, suffix = cmd_name.rpartition("-")
        if sep and suffix in {"command", "cmd", "group", "grp"}:
            cmd_name = left
        name = cmd_name
    cmd = cls(name=name, callback=f, params=params, **attrs)
    cmd.__doc__ = f.__doc__
    return cmd


def command(name=None, cls=None, **attrs):
    if callable(name) and not isinstance(name, str):
        f, name = name, None
        return _make_command(f, None, attrs, cls or Command)
    if cls is None:
        cls = Command

    def decorator(f):
        return _make_command(f, name, attrs, cls)

    return decorator


def group(name=None, cls=None, **attrs):
    if callable(name) and not isinstance(name, str):
        f = name
        return _make_command(f, None, attrs, cls or Group)
    if cls is None:
        cls = Group

    def decorator(f):
        return _make_command(f, name, attrs, cls)

    return decorator


def argument(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Argument

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def option(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Option

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f

    return decorator


def confirmation_option(*param_decls, **kwargs):
    def callback(ctx, param, value):
        if not value:
            ctx.abort()

    kwargs.setdefault("is_flag", True)
    kwargs["callback"] = callback
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*(param_decls or ("--yes",)), **kwargs)


def password_option(*param_decls, **kwargs):
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("hide_input", True)
    return option(*(param_decls or ("--password",)), **kwargs)


def _detect_package_name():
    frame = inspect.currentframe()
    f_back = frame.f_back.f_back.f_back if frame and frame.f_back and frame.f_back.f_back else None
    f_globals = f_back.f_globals if f_back is not None else None
    del frame
    if f_globals is not None:
        package_name = f_globals.get("__name__")
        if package_name == "__main__":
            package_name = f_globals.get("__package__")
        if package_name:
            return package_name.partition(".")[0]
    return None


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    if message is None:
        message = "%(prog)s, version %(version)s"
    if version is None and package_name is None:
        package_name = _detect_package_name()

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        ver = version
        pkg = package_name
        if ver is None:
            if pkg is None:
                raise RuntimeError("Could not determine the version: no version or package name.")
            import importlib.metadata as md

            try:
                ver = md.version(pkg)
            except md.PackageNotFoundError:
                dist_names = md.packages_distributions().get(pkg.partition(".")[0])
                if not dist_names:
                    raise RuntimeError(f"{pkg!r} is not installed. Try passing 'package_name' instead.") from None
                try:
                    ver = md.version(dist_names[0])
                except md.PackageNotFoundError:
                    raise RuntimeError(f"{pkg!r} is not installed.") from None
            if ver is None:
                raise RuntimeError(f"Could not determine the version for {pkg!r} automatically.")
        prog = prog_name
        if prog is None:
            prog = ctx.find_root().info_name
        echo(message % {"prog": prog, "package": pkg, "version": ver}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*(param_decls or ("--version",)), **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    def cb(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = cb
    return option(*(param_decls or ("--version",)), **kwargs)


def help_option(*param_decls, **kwargs):
    def show_help(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(ctx.get_help(), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", show_help)
    return option(*param_decls, **kwargs)
