"""In-process runner."""
from __future__ import annotations

import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile
import threading

from . import formatting, termui, utils


class _Tee(io.BytesIO):
    def __init__(self, shared):
        super().__init__()
        self._shared = shared

    def write(self, b):
        self._shared.write(bytes(b))
        return super().write(b)


class _Wrapper(io.TextIOWrapper):
    def __init__(self, buffer, name, mode, **kw):
        super().__init__(buffer, **kw)
        self._n = name
        self._m = mode

    @property
    def name(self):
        return self._n

    @property
    def mode(self):
        return self._m


class _EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def read1(self, n=-1):
        return self._echo(self._input.read1(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code,
                 exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _dec(self, b):
        return b.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def output(self):
        return self._dec(self.output_bytes)

    @property
    def stdout(self):
        return self._dec(self.stdout_bytes)

    @property
    def stderr(self):
        return self._dec(self.stderr_bytes)

    def __repr__(self):
        exc = repr(self.exception) if self.exception else "okay"
        return f"<Result {exc}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = bytes(input)
        old = (sys.stdin, sys.stdout, sys.stderr, termui.visible_prompt_func, termui.hidden_prompt_func,
               termui._getchar, utils.should_strip_ansi, formatting.FORCED_WIDTH)
        formatting.FORCED_WIDTH = 80
        env = self.make_env(env)
        shared = io.BytesIO()
        fd_state = None
        if self.capture == "fd":
            fd_state = self._fd_begin()
            out_stream, err_stream = fd_state["out"], fd_state["err"]
            out_buf = err_buf = None
        else:
            out_buf = _Tee(shared)
            err_buf = _Tee(shared)
            out_stream = _Wrapper(out_buf, "<stdout>", "w", encoding=self.charset, write_through=True)
            err_stream = _Wrapper(err_buf, "<stderr>", "w", encoding=self.charset, errors="backslashreplace",
                                  write_through=True)
        in_bytes = io.BytesIO(data)
        echo_input = None
        if self.echo_stdin:
            in_bytes = echo_input = _EchoingStdin(in_bytes, out_stream.buffer)
        text_input = _Wrapper(in_bytes, "<stdin>", "r", encoding=self.charset)
        sys.stdin = text_input
        sys.stdout = out_stream
        sys.stderr = err_stream

        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            if echo_input is not None:
                echo_input._paused = True
            try:
                line = text_input.readline()
            finally:
                if echo_input is not None:
                    echo_input._paused = False
            if not line:
                raise EOFError()
            val = line.rstrip("\r\n")
            sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            line = text_input.readline()
            if not line:
                raise EOFError()
            return line.rstrip("\r\n")

        def _getchar(echo):
            ch = sys.stdin.read(1)
            if echo:
                sys.stdout.write(ch)
            return ch

        default_color = color

        def should_strip_ansi(stream=None, color=None):
            if color is None:
                return not default_color
            return not color

        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        utils.should_strip_ansi = should_strip_ansi

        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            holder = {}
            yield (out_buf, err_buf, shared, fd_state, holder)
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            if fd_state is not None:
                self._fd_end(fd_state)
            (sys.stdin, sys.stdout, sys.stderr, termui.visible_prompt_func, termui.hidden_prompt_func,
             termui._getchar, utils.should_strip_ansi, formatting.FORCED_WIDTH) = old

    def _fd_begin(self):
        try:
            sys.__stdout__.flush()
        except Exception:
            pass
        chunks = []
        r1, w1 = os.pipe()
        r2, w2 = os.pipe()
        saved1, saved2 = os.dup(1), os.dup(2)
        os.dup2(w1, 1)
        os.dup2(w2, 2)
        os.close(w1)
        os.close(w2)

        def reader(fd, which):
            while True:
                try:
                    d = os.read(fd, 65536)
                except OSError:
                    break
                if not d:
                    break
                chunks.append((which, d))
            os.close(fd)

        threads = [threading.Thread(target=reader, args=(r1, 1), daemon=True),
                   threading.Thread(target=reader, args=(r2, 2), daemon=True)]
        for t in threads:
            t.start()

        def mk(fd, name, errors):
            raw = io.FileIO(fd, "wb", closefd=False)
            buf = io.BufferedWriter(raw)
            return _Wrapper(buf, name, "w", encoding=self.charset, errors=errors, line_buffering=True)

        return {"chunks": chunks, "threads": threads, "saved": (saved1, saved2),
                "out": mk(1, "<stdout>", "strict"), "err": mk(2, "<stderr>", "backslashreplace"),
                "ended": False}

    def _fd_flush(self, st):
        for s in (st["out"], st["err"]):
            try:
                s.flush()
            except Exception:
                pass

    def _fd_collect(self, st):
        self._fd_flush(st)
        # wait for pipes to drain
        import time

        time.sleep(0.02)
        chunks = list(st["chunks"])
        out = b"".join(d for w, d in chunks if w == 1)
        err = b"".join(d for w, d in chunks if w == 2)
        both = b"".join(d for w, d in chunks)
        return out, err, both

    def _fd_end(self, st):
        if st["ended"]:
            return
        st["ended"] = True
        self._fd_flush(st)
        os.dup2(st["saved"][0], 1)
        os.dup2(st["saved"][1], 2)
        os.close(st["saved"][0])
        os.close(st["saved"][1])
        for t in st["threads"]:
            t.join(timeout=2)

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as (out_buf, err_buf, shared, fd_state, _):
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name", None) or self.get_default_prog_name(cli)
                return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                code = e.code
                if code is None:
                    code = 0
                if code != 0:
                    exception = e
                if not isinstance(code, int):
                    sys.stdout.write(str(code))
                    sys.stdout.write("\n")
                    code = 1
                exit_code = code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
                if fd_state is not None:
                    stdout, stderr, output = self._fd_collect(fd_state)
                else:
                    stdout = out_buf.getvalue()
                    stderr = err_buf.getvalue()
                    output = shared.getvalue()
        return Result(self, stdout, stderr, output, return_value, exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass
