"""Shell completion."""
from __future__ import annotations

import os
import re
import sys

from .core import Argument, Context, Group, Option, ParameterSource
from .types import CompletionItem
from .utils import split_arg_string

_BASH = """\
%(func)s() {
    local IFS=$'\\n'
    local response
    response=$(env COMP_WORDS="${COMP_WORDS[*]}" COMP_CWORD=$COMP_CWORD %(var)s=bash_complete $1)
    for completion in $response; do
        IFS=',' read type value <<< "$completion"
        if [[ $type == 'dir' ]]; then
            COMPREPLY=()
            compopt -o dirnames
        elif [[ $type == 'file' ]]; then
            COMPREPLY=()
            compopt -o default
        elif [[ $type == 'plain' ]]; then
            COMPREPLY+=($value)
        fi
    done
    return 0
}

%(func)s_setup() {
    complete -o nosort -F %(func)s %(prog)s
}

%(func)s_setup;
"""

_ZSH = """\
#compdef %(prog)s

%(func)s() {
    local -a completions
    local -a completions_with_descriptions
    local -a response
    (( ! $+commands[%(prog)s] )) && return 1

    response=("${(@f)$(env COMP_WORDS="${words[*]}" COMP_CWORD=$((CURRENT-1)) %(var)s=zsh_complete %(prog)s)}")

    for type key descr in ${response}; do
        if [[ "$type" == "plain" ]]; then
            if [[ "$descr" == "_" ]]; then
                completions+=("$key")
            else
                completions_with_descriptions+=("$key":"$descr")
            fi
        elif [[ "$type" == "dir" ]]; then
            _path_files -/
        elif [[ "$type" == "file" ]]; then
            _path_files -f
        fi
    done

    if [ -n "$completions_with_descriptions" ]; then
        _describe -V unsorted completions_with_descriptions -U
    fi

    if [ -n "$completions" ]; then
        compadd -U -V unsorted -a completions
    fi
}

if [[ $zsh_eval_context[-1] == loadautofunc ]]; then
    %(func)s "$@"
else
    compdef %(func)s %(prog)s
fi
"""

_FISH = """\
function %(func)s;
    set -l response (env %(var)s=fish_complete COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -t) %(prog)s);

    for completion in $response;
        set -l metadata (string split "," $completion);

        if test $metadata[1] = "dir";
            __fish_complete_directories $metadata[2];
        else if test $metadata[1] = "file";
            __fish_complete_path $metadata[2];
        else if test $metadata[1] = "plain";
            echo $metadata[2];
        end;
    end;
end;

complete --no-files --command %(prog)s --arguments "(%(func)s)";
"""

_POWERSHELL = """\
Register-ArgumentCompleter -Native -CommandName %(prog)s -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)

    $env:COMP_WORDS = $commandAst.ToString()
    $words = $commandAst.CommandElements.Count
    if ($wordToComplete -eq "") { $env:COMP_CWORD = $words } else { $env:COMP_CWORD = $words - 1 }
    $env:%(var)s = "powershell_complete"

    %(prog)s | ForEach-Object {
        $type, $value, $help = $_.Split(":", 3)
        if ($type -eq "plain") {
            [System.Management.Automation.CompletionResult]::new($value, $value, "ParameterValue", $value)
        } elseif ($type -eq "file" -or $type -eq "dir") {
            [System.Management.Automation.CompletionResult]::new($value, $value, "ProviderItem", $value)
        }
    }
    Remove-Item Env:%(var)s
}
"""

_SCRIPTS = {"bash": _BASH, "zsh": _ZSH, "fish": _FISH, "powershell": _POWERSHELL}


def _source(shell, prog_name, complete_var):
    func = "_{}_completion".format(re.sub(r"\W*", "", prog_name.replace("-", "_"))).lower()
    return _SCRIPTS[shell] % {"func": func, "prog": prog_name, "var": complete_var}


def _format(shell, item):
    if shell == "bash":
        return f"{item.type},{item.value}"
    if shell == "zsh":
        return f"{item.type}\n{item.value}\n{item.help if item.help else '_'}"
    if shell == "fish":
        h = (item.help or "").replace("\n", " ")
        if item.help:
            return f"{item.type},{item.value}\t{h}"
        return f"{item.type},{item.value}"
    return f"{item.type}:{item.value}:{(item.help or ' ').replace(chr(10), ' ')}"


def _get_args(shell):
    cwords = split_arg_string(os.environ.get("COMP_WORDS", ""))
    cword_env = os.environ.get("COMP_CWORD", "")
    if shell == "fish":
        incomplete = cword_env
        args = cwords[1:]
        if incomplete and args and args[-1] == incomplete:
            args.pop()
        return args, incomplete
    try:
        cword = int(cword_env)
    except ValueError:
        cword = len(cwords)
    args = cwords[1:cword]
    try:
        incomplete = cwords[cword]
    except IndexError:
        incomplete = ""
    return args, incomplete


def _resolve_context(cli, ctx_args, prog_name, args):
    ctx_args = dict(ctx_args)
    ctx_args["resilient_parsing"] = True
    ctx = cli.make_context(prog_name, list(args), **ctx_args)
    args = ctx.protected_args + ctx.args
    while args:
        command = ctx.command
        if isinstance(command, Group):
            if not command.chain:
                name, cmd, args = command.resolve_command(ctx, args)
                if cmd is None:
                    return ctx
                ctx = cmd.make_context(name, args, parent=ctx, resilient_parsing=True)
                args = ctx.protected_args + ctx.args
            else:
                sub_ctx = ctx
                while args:
                    name, cmd, args = command.resolve_command(ctx, args)
                    if cmd is None:
                        return ctx
                    sub_ctx = cmd.make_context(name, args, parent=ctx, allow_extra_args=True,
                                               allow_interspersed_args=False, resilient_parsing=True)
                    args = sub_ctx.args
                ctx = sub_ctx
                args = [*sub_ctx.protected_args, *sub_ctx.args]
        else:
            break
    return ctx


def _start_of_option(ctx, value):
    if not value:
        return False
    return not value[0].isalnum() and value[0] in (ctx._opt_prefixes | {"-"})


def _resolve_incomplete(ctx, args, incomplete):
    if "--" in args:
        return _argument_param(ctx, incomplete)
    if _start_of_option(ctx, incomplete) and "=" in incomplete and False:
        pass
    # value of an option?
    for param in ctx.command.get_params(ctx):
        if not isinstance(param, Option) or param.is_flag or param.count:
            continue
        last = None
        for index, arg in enumerate(reversed(args)):
            if index + 1 > param.nargs:
                break
            if _start_of_option(ctx, arg):
                last = arg
        if last is not None and last in (list(param.opts) + list(param.secondary_opts)):
            return param, incomplete
    if not _start_of_option(ctx, incomplete):
        return _argument_param(ctx, incomplete)
    return ctx.command, incomplete


def _argument_param(ctx, incomplete):
    for param in ctx.command.get_params(ctx):
        if not isinstance(param, Argument):
            continue
        value = ctx.params.get(param.name)
        if (param.nargs == -1 or ctx.get_parameter_source(param.name) is not ParameterSource.COMMANDLINE
                or (param.nargs > 1 and isinstance(value, (tuple, list)) and len(value) < param.nargs)):
            return param, incomplete
    return ctx.command, incomplete


def get_completions(cli, ctx_args, prog_name, args, incomplete):
    ctx = _resolve_context(cli, ctx_args, prog_name, args)
    obj, incomplete = _resolve_incomplete(ctx, args, incomplete)
    items = obj.shell_complete(ctx, incomplete)
    out = []
    for i in items:
        out.append(CompletionItem(i) if isinstance(i, str) else i)
    return out


def shell_complete(cli, ctx_args, prog_name, complete_var, instruction):
    shell, _, instr = instruction.partition("_")
    if shell not in _SCRIPTS or instr not in ("source", "complete"):
        return 1
    if instr == "source":
        out = _source(shell, prog_name, complete_var)
    else:
        args, incomplete = _get_args(shell)
        items = get_completions(cli, ctx_args, prog_name, args, incomplete)
        out = "\n".join(_format(shell, i) for i in items)
    sys.stdout.write(out)
    sys.stdout.flush()
    return 0
