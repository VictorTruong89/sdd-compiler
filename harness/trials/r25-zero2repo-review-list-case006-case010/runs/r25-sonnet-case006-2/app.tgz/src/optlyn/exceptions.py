"""Exception types."""
from __future__ import annotations

import typing as t


def _echo(*a, **k):
    from .utils import echo

    return echo(*a, **k)


class OptlynException(Exception):
    exit_code = 1

    def __init__(self, message: str = "") -> None:
        super().__init__(message)
        self.message = message

    def format_message(self) -> str:
        return self.message

    def __str__(self) -> str:
        return self.message

    def show(self, file=None) -> None:
        import sys

        if file is None:
            file = sys.stderr
        _echo(f"Error: {self.format_message()}", file=file)


class UsageError(OptlynException):
    exit_code = 2

    def __init__(self, message: str, ctx=None) -> None:
        super().__init__(message)
        self.ctx = ctx
        self.cmd = self.ctx.command if self.ctx else None

    def show(self, file=None) -> None:
        import sys

        if file is None:
            file = sys.stderr
        color = None
        hint = ""
        if self.ctx is not None:
            color = self.ctx.color
            try:
                if self.ctx.command.get_help_option(self.ctx) is not None:
                    hint = (
                        f"Try '{self.ctx.command_path} "
                        f"{self.ctx.help_option_names[0]}' for help.\n"
                    )
            except Exception:
                pass
            _echo(f"{self.ctx.get_usage()}\n{hint}", file=file, color=color)
        _echo(f"Error: {self.format_message()}", file=file, color=color)


class NoArgsIsHelpError(UsageError):
    def __init__(self, ctx) -> None:
        super().__init__("Missing arguments.", ctx)

    def show(self, file=None) -> None:
        import sys

        if file is None:
            file = sys.stderr
        _echo(self.ctx.get_help(), file=file, color=self.ctx.color)


def _join_hints(hints) -> str:
    return " / ".join(repr(x) if not isinstance(x, str) else f"'{x}'" for x in hints)


class BadParameter(UsageError):
    def __init__(self, message: str, ctx=None, param=None, param_hint=None) -> None:
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self) -> str:
        if self.param_hint is not None:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            return f"Invalid value: {self.message}"
        if isinstance(hint, str):
            hint = f"'{hint}'" if not hint.startswith("'") else hint
        else:
            hint = _join_hints(hint)
        return f"Invalid value for {hint}: {self.message}"


class MissingParameter(BadParameter):
    def __init__(self, message=None, ctx=None, param=None, param_hint=None, param_type=None) -> None:
        super().__init__(message or "", ctx, param, param_hint)
        self.param_type = param_type

    def format_message(self) -> str:
        if self.param_hint is not None:
            hint = self.param_hint
        elif self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        else:
            hint = None
        if hint is not None and not isinstance(hint, str):
            hint = _join_hints(hint)
        elif isinstance(hint, str) and not hint.startswith("'"):
            hint = f"'{hint}'"
        ptype = self.param_type
        if ptype is None and self.param is not None:
            ptype = self.param.param_type_name
        msg = self.message
        if self.param is not None:
            extra = self.param.get_missing_message(self.ctx)
            if extra:
                msg = f"{msg}. {extra}" if msg else extra
        out = f"Missing {ptype}" if ptype else "Missing parameter"
        if hint:
            out += f" {hint}"
        if msg:
            out += f". {msg}" if not msg.endswith(".") else f". {msg}"
        else:
            out += "."
        return out


class NoSuchOption(UsageError):
    def __init__(self, option_name, message=None, possibilities=None, ctx=None) -> None:
        if message is None:
            message = f"No such option: {option_name}"
        super().__init__(message, ctx)
        self.option_name = option_name
        self.possibilities = possibilities

    def format_message(self) -> str:
        if not self.possibilities:
            return self.message
        poss = sorted(self.possibilities)
        if len(poss) == 1:
            return f"{self.message} Did you mean {poss[0]}?"
        return f"{self.message} (Possible options: {', '.join(poss)})"


class BadOptionUsage(UsageError):
    def __init__(self, option_name, message, ctx=None) -> None:
        super().__init__(message, ctx)
        self.option_name = option_name


class BadArgumentUsage(UsageError):
    pass


class FileError(OptlynException):
    def __init__(self, filename, hint=None) -> None:
        from .utils import format_filename

        if hint is None:
            hint = "unknown error"
        super().__init__(hint)
        self.ui_filename = format_filename(filename)
        self.filename = filename

    def format_message(self) -> str:
        return f"Could not open file '{self.ui_filename}': {self.message}"


class Abort(RuntimeError):
    pass


class Exit(RuntimeError):
    __slots__ = ("exit_code",)

    def __init__(self, code: int = 0) -> None:
        super().__init__(code)
        self.exit_code = code
