"""Terminal UI helpers."""
from __future__ import annotations

import contextlib
import getpass
import math
import os
import shutil
import subprocess
import sys
import tempfile
import time

from .exceptions import Abort, OptlynException, UsageError
from .globals import resolve_color_default
from .types import Choice, convert_type
from .utils import _is_interactive, echo, isatty, strip_ansi, should_strip_ansi

visible_prompt_func = input
hidden_prompt_func = getpass.getpass


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += " ({})".format(", ".join(map(str, [getattr(c, "name", c) for c in type.choices])))
    if default is not None and show_default:
        prompt = f"{prompt} [{_format_default(default)}]"
    return f"{prompt}{suffix}"


def _format_default(default):
    if hasattr(default, "name"):
        return default.name
    return default


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None, value_proc=None,
           prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    def prompt_func(text):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    p = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(p)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    p = _build_prompt(text, prompt_suffix, show_default, "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(p.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


def _getchar(echo_):
    import termios
    import tty

    f = None
    if isatty(sys.stdin):
        f = sys.stdin
        fd = sys.stdin.fileno()
    else:
        fd = os.open("/dev/tty", os.O_RDONLY)
        f = os.fdopen(fd)
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32)
            ch = ch.decode(getattr(sys.stdin, "encoding", None) or "utf-8", "replace")
            if echo_ and isatty(sys.stdout):
                sys.stdout.write(ch)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
    finally:
        if f is not None and f is not sys.stdin:
            f.close()
    return ch


def getchar(echo=False):
    ch = _getchar(echo)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    return ch


def pause(info=None, err=False):
    if info is None:
        info = "Press any key to continue..."
    if not _is_interactive():
        echo(info, err=err)
        return
    try:
        echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    finally:
        echo(err=err)


def clear():
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


class _Pager:
    def __init__(self, proc, color):
        self.proc = proc
        self.color = color
        self.encoding = "utf-8"

    def write(self, text):
        if not isinstance(text, str):
            text = text.decode("utf-8", "replace")
        if not self.color:
            text = strip_ansi(text)
        try:
            self.proc.stdin.write(text.encode("utf-8"))
            self.proc.stdin.flush()
        except (BrokenPipeError, OSError):
            pass
        return len(text)

    def flush(self):
        try:
            self.proc.stdin.flush()
        except Exception:
            pass

    def writable(self):
        return True

    def isatty(self):
        return False


class _PlainOut:
    def __init__(self, stream, color):
        self.stream = stream
        self.color = color

    def write(self, text):
        echo(text, file=self.stream, nl=False, color=self.color)
        return len(text)

    def flush(self):
        self.stream.flush()

    def writable(self):
        return True

    def isatty(self):
        return isatty(self.stream)


@contextlib.contextmanager
def get_pager_file(color=None):
    color = resolve_color_default(color)
    stdout = sys.stdout
    if not _is_interactive():
        yield _PlainOut(stdout, color)
        return
    cmd = os.environ.get("PAGER", "").strip()
    if not cmd:
        for cand in ("less", "more"):
            if shutil.which(cand):
                cmd = cand
                break
    if not cmd:
        yield _PlainOut(stdout, color)
        return
    env = dict(os.environ)
    if color and "LESS" not in env:
        env["LESS"] = "-R"
    stdout.flush()
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, env=env)
    pager = _Pager(proc, bool(color))
    try:
        yield pager
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        while True:
            try:
                proc.wait()
                break
            except KeyboardInterrupt:
                pass


def echo_via_pager(text_or_generator, color=None):
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    elif isinstance(text_or_generator, (bytes, bytearray)):
        chunks = [bytes(text_or_generator).decode("utf-8", "replace")]
    else:
        try:
            chunks = iter(text_or_generator)
        except TypeError:
            chunks = [str(text_or_generator)]
    with get_pager_file(color=color) as f:
        for chunk in chunks:
            f.write(chunk if isinstance(chunk, str) else str(chunk))
            f.flush()
        # trailing newline like a printed text
        if not (isinstance(text_or_generator, str) and text_or_generator.endswith("\n")):
            pass


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    ed = _Editor(editor=editor, env=env, require_save=require_save, extension=extension)
    if filename is None:
        return ed.edit(text)
    ed.edit_files(filename if isinstance(filename, (list, tuple)) else (filename,))
    return None


class _Editor:
    def __init__(self, editor=None, env=None, require_save=True, extension=".txt"):
        self.editor = editor
        self.env = env
        self.require_save = require_save
        self.extension = extension

    def get_editor(self):
        if self.editor is not None:
            return self.editor
        for key in ("VISUAL", "EDITOR"):
            rv = os.environ.get(key)
            if rv:
                return rv
        for e in ("sensible-editor", "vim", "nano"):
            if shutil.which(e) is not None:
                return e
        return "vi"

    def edit_files(self, filenames):
        import shlex

        editor = self.get_editor()
        environ = os.environ.copy()
        if self.env:
            environ.update({k: v for k, v in self.env.items() if v is not None})
        quoted = " ".join(shlex.quote(os.fspath(f)) for f in filenames)
        try:
            c = subprocess.Popen(f"{editor} {quoted}", env=environ, shell=True)
            code = c.wait()
        except OSError as e:
            raise OptlynException(f"{editor}: Editing failed: {e}") from e
        if code != 0:
            raise OptlynException(f"{editor}: Editing failed")

    def edit(self, text):
        if not text:
            data = b""
        elif isinstance(text, (bytes, bytearray)):
            data = bytes(text)
        else:
            if text and not text.endswith("\n"):
                text += "\n"
            data = text.encode("utf-8")
        fd, name = tempfile.mkstemp(prefix="editor-", suffix=self.extension)
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(data)
            before = os.stat(name)
            # make the timestamp clearly older so a quick save is still detected
            os.utime(name, ns=(before.st_atime_ns, before.st_mtime_ns - 2_000_000_000))
            ts = os.stat(name).st_mtime_ns
            self.edit_files((name,))
            if self.require_save and os.stat(name).st_mtime_ns == ts:
                return None
            with open(name, "rb") as f:
                rv = f.read()
            return rv.decode("utf-8-sig").replace("\r\n", "\n")
        finally:
            try:
                os.unlink(name)
            except OSError:
                pass


def launch(url, wait=False, locate=False):
    url = os.fspath(url) if not isinstance(url, str) else url
    if locate:
        url = os.path.dirname(url) or "."
    opener = shutil.which("xdg-open") or "xdg-open"
    try:
        p = subprocess.Popen([opener, url], stdout=subprocess.DEVNULL if False else None)
        return p.wait()
    except OSError:
        return 127


class ProgressBar:
    def __init__(self, iterable=None, length=None, fill_char="#", empty_char="-",
                 bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ", show_eta=True,
                 show_percent=None, show_pos=False, item_show_func=None, label=None, file=None,
                 color=None, update_min_steps=1, width=36, hidden=False):
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        self.iter = iter(iterable)
        if length is None:
            try:
                length = len(iterable)
            except (TypeError, AttributeError):
                length = None
        self.length = length
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.show_eta = show_eta
        self.show_percent = show_percent
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.label = label or ""
        self.file = file
        self.color = color
        self.update_min_steps = update_min_steps
        self.width = width
        self.hidden = hidden
        self.pos = 0
        self.finished = False
        self.entered = False
        self.current_item = None
        self.start = self.last_eta = time.time()
        self._last_line = None
        self._rendered_any = False
        if self.show_percent is None:
            self.show_percent = not show_pos and length is not None

    def _stream(self):
        return self.file if self.file is not None else sys.stdout

    @property
    def is_hidden(self):
        return self.hidden or not isatty(self._stream())

    def __enter__(self):
        self.entered = True
        self.render_progress()
        return self

    def __exit__(self, *a):
        self.render_finish()

    def __iter__(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        self.render_progress()
        return self.generator()

    def __next__(self):
        return next(iter(self))

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def percent(self):
        return self.pct

    @property
    def time_per_iteration(self):
        if self.pos <= 0:
            return 0.0
        return (time.time() - self.start) / self.pos

    @property
    def eta(self):
        if self.length is not None and not self.finished:
            return self.time_per_iteration * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.length is not None and not self.finished:
            t = int(self.eta)
            seconds = t % 60
            t //= 60
            minutes = t % 60
            t //= 60
            hours = t % 24
            t //= 24
            if t > 0:
                return f"{t}d {hours:02}:{minutes:02}:{seconds:02}"
            return f"{hours:02}:{minutes:02}:{seconds:02}"
        return ""

    def format_pos(self):
        pos = str(self.pos)
        if self.length is not None:
            pos += f"/{self.length}"
        return pos

    def format_pct(self):
        return f"{int(self.pct * 100): 4}%"[1:]

    def format_bar(self):
        if self.length is not None:
            bar_length = int(self.pct * self.width)
            bar = self.fill_char * bar_length
            bar += self.empty_char * (self.width - bar_length)
        elif self.finished:
            bar = self.fill_char * self.width
        else:
            chars = list(self.empty_char * (self.width or 1))
            if self.time_per_iteration != 0:
                chars[int((math.cos(self.pos * self.time_per_iteration) / 2.0 + 0.5) * self.width)] = self.fill_char
            bar = "".join(chars)
        return bar

    def format_progress_line(self):
        parts = []
        if self.show_percent:
            parts.append(self.format_pct())
        if self.show_pos:
            parts.append(self.format_pos())
        if self.show_eta and self.length is not None and not self.finished:
            eta = self.format_eta()
            if eta:
                parts.append(eta)
        if self.item_show_func is not None:
            item = self.item_show_func(self.current_item)
            if item is not None:
                parts.append(item)
        info = self.info_sep.join(p for p in parts if p)
        return (self.bar_template % {"label": self.label, "bar": self.format_bar(), "info": info}).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        stream = self._stream()
        if not isatty(stream):
            if self.label and self._last_line != self.label:
                self._last_line = self.label
                echo(self.label, file=stream, color=self.color)
            return
        line = self.format_progress_line()
        if line == self._last_line:
            return
        self._last_line = line
        stream.write("\r" + line)
        stream.flush()
        self._rendered_any = True

    def render_finish(self):
        if self.is_hidden:
            return
        stream = self._stream()
        stream.write("\n")
        stream.flush()

    def update(self, n_steps=1, current_item=None):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        if current_item is not None:
            self.current_item = current_item
        self.render_progress()

    def finish(self):
        self.finished = True

    def generator(self):
        for rv in self.iter:
            self.current_item = rv
            yield rv
            self.update(1)
        self.finish()
        self.render_progress()


def progressbar(iterable=None, length=None, label=None, hidden=False, show_eta=True, show_percent=None,
                show_pos=False, item_show_func=None, fill_char="#", empty_char="-",
                bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ", width=36, file=None,
                color=None, update_min_steps=1):
    return ProgressBar(
        iterable=iterable, length=length, show_eta=show_eta, show_percent=show_percent, show_pos=show_pos,
        item_show_func=item_show_func, fill_char=fill_char, empty_char=empty_char, bar_template=bar_template,
        info_sep=info_sep, file=file, label=label, width=width, color=color,
        update_min_steps=update_min_steps, hidden=hidden)
