"""Utilities: echo, style, file helpers."""
from __future__ import annotations

import codecs
import io
import os
import re
import sys

from .exceptions import FileError
from .globals import resolve_color_default

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")


def safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass

    return wrapper


def make_str(value):
    if isinstance(value, bytes):
        try:
            return value.decode(sys.getfilesystemencoding())
        except UnicodeError:
            return value.decode("utf-8", "replace")
    return str(value)


def isatty(stream) -> bool:
    try:
        return stream.isatty()
    except Exception:
        return False


def _is_interactive() -> bool:
    return isatty(sys.stdin) and isatty(sys.stdout)


def strip_ansi(value: str) -> str:
    return _ansi_re.sub("", value)


def should_strip_ansi(stream=None, color=None) -> bool:
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def unstyle(text: str) -> str:
    return strip_ansi(text)


_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34,
    "magenta": 35, "cyan": 36, "white": 37, "reset": 39,
    "bright_black": 90, "bright_red": 91, "bright_green": 92,
    "bright_yellow": 93, "bright_blue": 94, "bright_magenta": 95,
    "bright_cyan": 96, "bright_white": 97,
}


class InvalidColor(TypeError, ValueError):
    pass


def _interpret_color(color, offset=0) -> str:
    if isinstance(color, bool):
        raise InvalidColor(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise InvalidColor(f"Unknown color {color!r}")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or not all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color):
            raise InvalidColor(f"Unknown color {color!r}")
        r, g, b = color
        return f"{38 + offset};2;{r:d};{g:d};{b:d}"
    try:
        return str(_ansi_colors[color] + offset)
    except (KeyError, TypeError):
        raise InvalidColor(f"Unknown color {color!r}") from None


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True) -> str:
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    if bold is not None:
        bits.append(f"\033[{1 if bold else 22}m")
    if dim is not None:
        bits.append(f"\033[{2 if dim else 22}m")
    if underline is not None:
        bits.append(f"\033[{4 if underline else 24}m")
    if overline is not None:
        bits.append(f"\033[{53 if overline else 55}m")
    if italic is not None:
        bits.append(f"\033[{3 if italic else 23}m")
    if blink is not None:
        bits.append(f"\033[{5 if blink else 25}m")
    if reverse is not None:
        bits.append(f"\033[{7 if reverse else 27}m")
    if strikethrough is not None:
        bits.append(f"\033[{9 if strikethrough else 29}m")
    bits.append(text)
    if reset:
        bits.append("\033[0m")
    return "".join(bits)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def _find_binary_writer(stream):
    buf = getattr(stream, "buffer", None)
    if buf is not None and hasattr(buf, "write"):
        return buf
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    return None


def _is_ascii_encoding(enc) -> bool:
    if not enc:
        return False
    try:
        return codecs.lookup(enc).name == "ascii"
    except LookupError:
        return False


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
    if file is None:
        return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        if isinstance(out, str):
            out += "\n"
        else:
            out += b"\n"
    if not out:
        try:
            file.flush()
        except Exception:
            pass
        return
    if isinstance(out, (bytes, bytearray)):
        binary = _find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(bytes(out))
            binary.flush()
            return
        out = bytes(out).decode("utf-8", "replace")
    color = resolve_color_default(color)
    if should_strip_ansi(file, color):
        out = strip_ansi(out)
    enc = getattr(file, "encoding", None)
    if _is_ascii_encoding(enc):
        binary = _find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(out.encode("utf-8"))
            binary.flush()
            return
    file.write(out)
    file.flush()


def format_filename(filename, shorten=False) -> str:
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        return filename.decode(sys.getfilesystemencoding() or "utf-8", "backslashreplace")
    return filename.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")


def _posixify(name: str) -> str:
    return "-".join(name.split()).lower()


def get_app_dir(app_name, roaming=True, force_posix=False) -> str:
    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser("~"), f".{_posixify(app_name)}")
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return os.path.join(base, _posixify(app_name))


class _NoCloseBuffer:
    """Proxy for a binary stream that ignores close()."""

    def __init__(self, stream):
        self._s = stream

    def __getattr__(self, name):
        return getattr(self._s, name)

    def close(self):
        try:
            self._s.flush()
        except Exception:
            pass

    @property
    def closed(self):
        return False

    def readable(self):
        return self._s.readable()

    def writable(self):
        return self._s.writable()

    def seekable(self):
        return False


class _NonClosingTextIOWrapper(io.TextIOWrapper):
    def __del__(self):
        try:
            self.flush()
        except Exception:
            pass


class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass

    def close(self):
        try:
            self._file.flush()
        except Exception:
            pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


def _binary_of(stream):
    buf = getattr(stream, "buffer", None)
    return buf if buf is not None else stream


def _text_stream(stream, encoding, errors):
    if encoding is None and errors is None:
        return KeepOpenFile(stream)
    cur_enc = getattr(stream, "encoding", None)
    cur_err = getattr(stream, "errors", None)
    if (encoding is None or codecs.lookup(encoding).name == codecs.lookup(cur_enc or "utf-8").name) and (
        errors is None or errors == cur_err or errors == "strict"
    ) and not _is_ascii_encoding(cur_enc):
        return KeepOpenFile(stream)
    try:
        stream.flush()
    except Exception:
        pass
    buf = _binary_of(stream)
    return _NonClosingTextIOWrapper(
        _NoCloseBuffer(buf), encoding=encoding or "utf-8", errors=errors or "strict", line_buffering=True
    )


def get_text_stdout(encoding=None, errors=None):
    if encoding is None and _is_ascii_encoding(getattr(sys.stdout, "encoding", None)):
        encoding = "utf-8"
    return _text_stream(sys.stdout, encoding, errors)


def get_text_stderr(encoding=None, errors=None):
    if encoding is None and _is_ascii_encoding(getattr(sys.stderr, "encoding", None)):
        encoding = "utf-8"
    return _text_stream(sys.stderr, encoding, errors)


def get_text_stdin(encoding=None, errors=None):
    if encoding is None and _is_ascii_encoding(getattr(sys.stdin, "encoding", None)):
        encoding = "utf-8"
    return _text_stream(sys.stdin, encoding, errors)


def get_binary_stdout():
    return KeepOpenFile(_binary_of(sys.stdout))


def get_binary_stderr():
    return KeepOpenFile(_binary_of(sys.stderr))


def get_binary_stdin():
    return KeepOpenFile(_binary_of(sys.stdin))


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        if delete:
            try:
                os.unlink(self._tmp_filename)
            except OSError:
                pass
        else:
            os.replace(self._tmp_filename, self._real_filename)
        self.closed = True

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, *a):
        self.close(delete=exc_type is not None)

    def __iter__(self):
        return iter(self._f)

    def __repr__(self):
        return repr(self._f)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if filename == "-":
        if any(m in mode for m in ("w", "a", "x")):
            if binary:
                return get_binary_stdout(), False
            return get_text_stdout(encoding=encoding, errors=None if errors == "strict" else errors), False
        if binary:
            return get_binary_stdin(), False
        return get_text_stdin(encoding=encoding, errors=None if errors == "strict" else errors), False
    kw = {} if binary else {"encoding": encoding, "errors": errors}
    if not atomic or "r" in mode and "+" not in mode:
        return open(filename, mode, **kw), True
    if "x" in mode:
        raise ValueError("Use the `overwrite`-parameter instead.")
    import errno
    import random

    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL
    perm = 0o666
    try:
        perm = os.stat(filename).st_mode
    except OSError:
        pass
    while True:
        tmp = os.path.join(os.path.dirname(filename) or ".", f".__atomic-write{random.randrange(1 << 32):08x}")
        try:
            fd = os.open(tmp, flags, perm)
            break
        except OSError as e:
            if e.errno == errno.EEXIST:
                continue
            raise
    f = open(fd, mode.replace("a", "w") if "a" in mode else mode, **kw) if False else os.fdopen(fd, "wb" if binary else "w", **kw)
    return _AtomicFile(f, tmp, os.path.realpath(filename)), True


class LazyFile:
    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
        elif "r" in mode:
            open(filename, mode).close()

    def __getattr__(self, name):
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{format_filename(self.name)}' {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(self.name, self.mode, self.encoding, self.errors, atomic=self.atomic)
        except OSError as e:
            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f


def split_arg_string(string):
    import shlex

    lex = shlex.shlex(string, posix=True)
    lex.whitespace_split = True
    lex.commenters = ""
    out = []
    try:
        for token in lex:
            out.append(token)
    except ValueError:
        out.append(lex.token)
    return out
