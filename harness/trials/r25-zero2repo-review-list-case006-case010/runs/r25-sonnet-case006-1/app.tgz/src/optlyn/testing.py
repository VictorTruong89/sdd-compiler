from __future__ import annotations

import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile
import threading

from . import formatting, termui, utils
from .utils import should_strip_ansi


class _Mixed(io.RawIOBase):
    """Raw byte sink that records into its own buffer and a shared one."""

    def __init__(self, own, shared, fileno=None):
        self.own = own
        self.shared = shared
        self._fileno = fileno

    def writable(self):
        return True

    def write(self, b):
        b = bytes(b)
        self.own.write(b)
        self.shared.write(b)
        return len(b)

    def flush(self):
        pass

    def fileno(self):
        if self._fileno is None:
            return super().fileno()
        return self._fileno


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


class _EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code,
                 exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _dec(self, b):
        return b.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def output(self):
        return self._dec(self.output_bytes)

    @property
    def stdout(self):
        return self._dec(self.stdout_bytes)

    @property
    def stderr(self):
        return self._dec(self.stderr_bytes)

    def __repr__(self):
        return f"<Result {repr(self.exception) if self.exception else 'okay'}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        elif isinstance(input, (bytes, bytearray)):
            data = bytes(input)
        else:
            d = input.read()
            data = d.encode(self.charset) if isinstance(d, str) else d
        env = self.make_env(env)

        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_forced = formatting.FORCED_WIDTH
        old_vis, old_hid = termui.visible_prompt_func, termui.hidden_prompt_func
        old_getchar = termui._getchar
        old_strip = utils.should_strip_ansi

        bytes_in = io.BytesIO(data)
        shared = io.BytesIO()
        out_b = io.BytesIO()
        err_b = io.BytesIO()
        fd_state = None

        if self.capture == "fd":
            fd_state = _FdCapture()
            out_sink, err_sink = fd_state.start(shared_lock=threading.Lock())
            stdout = _NamedTextIOWrapper(io.FileIO(1, "w", closefd=False), name="<stdout>", mode="w",
                                         encoding=self.charset, write_through=True)
            stderr = _NamedTextIOWrapper(io.FileIO(2, "w", closefd=False), name="<stderr>", mode="w",
                                         encoding=self.charset, errors="backslashreplace",
                                         write_through=True)
        else:
            stdout = _NamedTextIOWrapper(_Mixed(out_b, shared), name="<stdout>", mode="w",
                                         encoding=self.charset, write_through=True)
            stderr = _NamedTextIOWrapper(_Mixed(err_b, shared), name="<stderr>", mode="w",
                                         encoding=self.charset, errors="backslashreplace",
                                         write_through=True)

        text_input_raw = _NamedTextIOWrapper(bytes_in, name="<stdin>", mode="r", encoding=self.charset)
        if self.echo_stdin:
            stdin = _EchoingStdin(text_input_raw, stdout)
        else:
            stdin = text_input_raw

        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            was = None
            if isinstance(stdin, _EchoingStdin):
                stdin._paused = True
            try:
                line = text_input_raw.readline()
            finally:
                if isinstance(stdin, _EchoingStdin):
                    stdin._paused = False
            if line == "":
                raise EOFError()
            val = line.rstrip("\r\n")
            sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            line = text_input_raw.readline()
            if line == "":
                raise EOFError()
            return line.rstrip("\r\n")

        def _getchar(echo_):
            ch = text_input_raw.read(1)
            if ch == "":
                raise EOFError()
            if echo_:
                sys.stdout.write(ch)
                sys.stdout.flush()
            return ch

        def should_strip(stream=None, color_=None):
            if color_ is None:
                return not color
            return not color_

        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        termui._getchar = _getchar
        utils.should_strip_ansi = should_strip
        formatting.FORCED_WIDTH = 80

        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            if fd_state is not None:
                yield (None, None, fd_state)
            else:
                yield (out_b, err_b, shared)
        finally:
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            try:
                stdout.flush()
                stderr.flush()
            except Exception:
                pass
            if fd_state is not None:
                fd_state.stop()
            sys.stdin, sys.stdout, sys.stderr = old_stdin, old_stdout, old_stderr
            termui.visible_prompt_func = old_vis
            termui.hidden_prompt_func = old_hid
            termui._getchar = old_getchar
            utils.should_strip_ansi = old_strip
            formatting.FORCED_WIDTH = old_forced

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as streams:
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name")
            except KeyError:
                prog_name = self.get_default_prog_name(cli)
            try:
                return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
            except SystemExit as e:
                exc_info = sys.exc_info()
                code = e.code
                if code is None:
                    code = 0
                if code != 0:
                    exception = e
                if not isinstance(code, int):
                    sys.stdout.write(str(code))
                    sys.stdout.write("\n")
                    code = 1
                exit_code = code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                try:
                    sys.stdout.flush()
                    sys.stderr.flush()
                except Exception:
                    pass
                if streams[2] is not None and self.capture == "fd":
                    out_bytes, err_bytes, mixed = streams[2].collect()
                else:
                    out_bytes = streams[0].getvalue()
                    err_bytes = streams[1].getvalue()
                    mixed = streams[2].getvalue()
        return Result(self, out_bytes, err_bytes, mixed, return_value, exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass


class _FdCapture:
    def __init__(self):
        self.chunks = []

    def start(self, shared_lock):
        self.lock = shared_lock
        self.saved = (os.dup(1), os.dup(2))
        try:
            sys.__stdout__.flush()
        except Exception:
            pass
        self.pipes = []
        self.tags = {}
        for fd, tag in ((1, "out"), (2, "err")):
            r, w = os.pipe()
            os.dup2(w, fd)
            os.close(w)
            self.pipes.append(r)
            self.tags[r] = tag
        t = threading.Thread(target=self._reader, daemon=True)
        t.start()
        self.threads = [t]
        return None, None

    def _reader(self):
        import select
        open_ = list(self.pipes)
        while open_:
            ready, _, _ = select.select(open_, [], [])
            for r in ready:
                try:
                    data = os.read(r, 65536)
                except OSError:
                    data = b""
                if not data:
                    open_.remove(r)
                    continue
                with self.lock:
                    self.chunks.append((self.tags[r], data))

    def stop(self):
        if getattr(self, "saved", None) is None:
            return
        os.dup2(self.saved[0], 1)
        os.dup2(self.saved[1], 2)
        os.close(self.saved[0])
        os.close(self.saved[1])
        self.saved = None
        for t in self.threads:
            t.join(timeout=5)
        for r in self.pipes:
            try:
                os.close(r)
            except OSError:
                pass

    def collect(self):
        # make sure everything written is drained: restore fds, which closes the pipe write ends
        self.stop()
        out = b"".join(d for t, d in self.chunks if t == "out")
        err = b"".join(d for t, d in self.chunks if t == "err")
        mixed = b"".join(d for t, d in self.chunks)
        return out, err, mixed
