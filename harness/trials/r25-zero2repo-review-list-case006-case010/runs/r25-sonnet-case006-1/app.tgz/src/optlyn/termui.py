from __future__ import annotations

import inspect
import io
import os
import shlex
import subprocess
import sys
import tempfile
import time
import math

from .exceptions import Abort, UsageError, OptlynException
from .formatting import strip_ansi, term_len
from .utils import echo, isatty, _interactive
from .types import convert_type

visible_prompt_func = input


def hidden_prompt_func(prompt):
    import getpass
    return getpass.getpass(prompt)


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and hasattr(type, "choices") and not isinstance(type, str):
        try:
            names = type._names()
            prompt += f" ({', '.join(names)})"
        except Exception:
            pass
    if default is not None and show_default:
        prompt = f"{prompt} [{default if not isinstance(default, (list, tuple)) else ' '.join(map(str, default))}]"
    return f"{prompt}{suffix}"


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    def prompt_func(t):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(t.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    p = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(p)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    p = _build_prompt(text, prompt_suffix, show_default,
                      "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(p.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


def _getchar_impl(echo_):
    try:
        import termios
        import tty
    except ImportError:
        return sys.stdin.read(1)
    try:
        f = open("/dev/tty")
        fd = f.fileno()
    except OSError:
        f = None
        fd = sys.stdin.fileno()
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            data = os.read(fd, 32)
            ch = data.decode("utf-8", "replace")
            if echo_ and isatty(sys.stdout):
                sys.stdout.write(ch)
                sys.stdout.flush()
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
    finally:
        if f is not None:
            f.close()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04" or ch == "":
        raise EOFError()
    return ch


_getchar = None


def getchar(echo=False):
    f = _getchar or _getchar_impl
    return f(echo)


def pause(info=None, err=False):
    if info is None:
        info = "Press any key to continue..."
    interactive = isatty(sys.stdin) and isatty(sys.stdout)
    try:
        if info:
            echo(info, nl=False, err=err)
        if interactive:
            try:
                getchar()
            except (KeyboardInterrupt, EOFError):
                pass
    finally:
        if info:
            echo(err=err)


def clear():
    if not isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    if editor is None:
        editor = os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    environ = None
    if env:
        environ = os.environ.copy()
        environ.update(env)

    def run(path):
        try:
            c = subprocess.Popen(f"{editor} {shlex.quote(path)}", env=environ, shell=True)
            exit_code = c.wait()
        except OSError as e:
            raise OptlynException(f"{editor}: Editing failed: {e}")
        if exit_code != 0:
            raise OptlynException(f"{editor}: Editing failed")

    if filename is not None:
        if isinstance(filename, (list, tuple)):
            filename = " ".join(shlex.quote(str(f)) for f in filename)
            c = subprocess.Popen(f"{editor} {filename}", env=environ, shell=True)
            if c.wait() != 0:
                raise OptlynException(f"{editor}: Editing failed")
        else:
            run(os.fspath(filename))
        return None
    if text is None:
        text = ""
    data = text if isinstance(text, (bytes, bytearray)) else text.replace("\r\n", "\n").encode("utf-8")
    fd, name = tempfile.mkstemp(prefix="editor-", suffix=extension)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        before = os.path.getmtime(name)
        run(name)
        after = os.path.getmtime(name)
        if require_save and before == after:
            return None
        with open(name, "rb") as f:
            rv = f.read()
        if isinstance(text, (bytes, bytearray)):
            return rv
        return rv.decode("utf-8-sig").replace("\r\n", "\n")
    finally:
        try:
            os.unlink(name)
        except OSError:
            pass


def launch(url, wait=False, locate=False):
    args = ["xdg-open", os.path.dirname(os.fspath(url)) or "." if locate else url]
    try:
        if wait:
            return subprocess.Popen(args).wait()
        c = subprocess.Popen(args)
        return 0
    except OSError:
        return 127


# ---------------------------------------------------------------- progress bar

class ProgressBar:
    def __init__(self, iterable=None, length=None, fill_char="#", empty_char="-",
                 bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ", show_eta=True,
                 show_percent=None, show_pos=False, item_show_func=None, label=None, file=None,
                 color=None, update_min_steps=1, width=36, hidden=False):
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.show_eta = show_eta
        self.show_percent = show_percent
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.label = label or ""
        if file is None:
            file = sys.stdout
        self.file = file
        self.color = color
        self.update_min_steps = update_min_steps
        self._completed_intervals = 0
        self.width = width
        self.autowidth = width == 0
        self.hidden = hidden
        if length is None:
            try:
                length = len(iterable)
            except (TypeError, AttributeError):
                length = None
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        self.iter = iter(iterable)
        self.length = length
        self.pos = 0
        self.avg = []
        self.last_eta = 0.0
        self.start = self.last_eta = time.time()
        self.eta_known = False
        self.finished = False
        self.max_width = None
        self.entered = False
        self.current_item = None
        self._is_atty = isatty(self.file)
        self._last_line = None
        self._label_printed = False

    def __enter__(self):
        self.entered = True
        self.render_progress()
        return self

    def __exit__(self, *a):
        self.render_finish()

    def __iter__(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        self.render_progress()
        return self.generator()

    def __next__(self):
        return next(iter(self))

    @property
    def pct(self):
        if self.finished:
            return 1.0
        if not self.length:
            return 0.0
        return min(self.pos / self.length, 1.0)

    @property
    def time_per_iteration(self):
        if not self.avg:
            return 0.0
        return sum(self.avg) / float(len(self.avg))

    @property
    def eta(self):
        if self.length is not None and not self.finished:
            return self.time_per_iteration * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.eta_known:
            t = int(self.eta)
            seconds = t % 60
            t //= 60
            minutes = t % 60
            t //= 60
            hours = t % 24
            t //= 24
            if t > 0:
                return f"{t}d {hours:02}:{minutes:02}:{seconds:02}"
            return f"{hours:02}:{minutes:02}:{seconds:02}"
        return ""

    def format_pos(self):
        pos = str(self.pos)
        if self.length is not None:
            pos += f"/{self.length}"
        return pos

    def format_pct(self):
        return f"{int(self.pct * 100): 4}%"[1:]

    def format_bar(self):
        if self.length is not None:
            bar_length = int(self.pct * self.width)
            bar = self.fill_char * bar_length
            bar += self.empty_char * (self.width - bar_length)
        elif self.finished:
            bar = self.fill_char * self.width
        else:
            chars = list(self.empty_char * (self.width or 1))
            if self.time_per_iteration != 0:
                chars[int((math.cos(self.pos * self.time_per_iteration) / 2.0 + 0.5) * (self.width - 1))] = self.fill_char
            bar = "".join(chars)
        return bar

    def format_progress_line(self):
        show_percent = self.show_percent
        info_bits = []
        if self.length is not None and show_percent is None:
            show_percent = not self.show_pos
        if self.show_pos:
            info_bits.append(self.format_pos())
        if show_percent:
            info_bits.append(self.format_pct())
        if self.show_eta and self.eta_known and not self.finished:
            info_bits.append(self.format_eta())
        if self.item_show_func is not None:
            item_info = self.item_show_func(self.current_item)
            if item_info is not None:
                info_bits.append(item_info)
        return (self.bar_template % {
            "label": self.label, "bar": self.format_bar(),
            "info": self.info_sep.join(info_bits)}).rstrip()

    def render_progress(self):
        if self.hidden:
            return
        if not self._is_atty:
            if not self._label_printed:
                self._label_printed = True
                if self.label:
                    echo(self.label, file=self.file, color=self.color)
            return
        line = self.format_progress_line()
        if line == self._last_line:
            return
        self._last_line = line
        echo("\r" + line, file=self.file, nl=False, color=self.color)

    def make_step(self, n_steps):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        now = time.time()
        if (now - self.last_eta) < 1.0:
            return
        self.last_eta = now
        if self.pos:
            step = (now - self.start) / self.pos
        else:
            step = 0
        self.avg = self.avg[-6:] + [step]
        self.eta_known = self.length is not None

    def update(self, n_steps, current_item=None):
        self._completed_intervals += n_steps
        if current_item is not None:
            self.current_item = current_item
        if self._completed_intervals >= self.update_min_steps:
            self.make_step(self._completed_intervals)
            self.render_progress()
            self._completed_intervals = 0

    def finish(self):
        self.eta_known = False
        self.current_item = None
        self.finished = True

    def generator(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        for rv in self.iter:
            self.current_item = rv
            yield rv
            self.update(1)
        self.finish()
        self.render_progress()

    def render_finish(self):
        if self.hidden or not self._is_atty:
            return
        echo("", file=self.file, color=self.color)


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)
