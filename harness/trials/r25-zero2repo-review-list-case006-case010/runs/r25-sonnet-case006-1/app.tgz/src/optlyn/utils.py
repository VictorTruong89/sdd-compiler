from __future__ import annotations

import os
import re
import sys
import io
import contextlib
import inspect
import subprocess
import tempfile
import time
import shlex

from .exceptions import FileError
from .formatting import strip_ansi
from .globals import get_current_context

_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35,
    "cyan": 36, "white": 37, "reset": 39,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


def isatty(stream):
    try:
        return stream.isatty()
    except Exception:
        return False


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise TypeError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ValueError(f"Color out of range: {color!r}")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, (tuple, list)):
        if len(color) != 3:
            raise ValueError(f"RGB color needs 3 values: {color!r}")
        for c in color:
            if isinstance(c, bool) or not isinstance(c, int):
                raise TypeError(f"Bad RGB component {c!r}")
            if not 0 <= c <= 255:
                raise ValueError(f"Color out of range: {color!r}")
        r, g, b = color
        return f"{38 + offset};2;{r:d};{g:d};{b:d}"
    raise TypeError(f"Unknown color {color!r}")


def _color_code(color, offset):
    if isinstance(color, str):
        if color not in _ansi_colors:
            raise TypeError(f"Unknown color {color!r}")
        return str(_ansi_colors[color] + offset)
    return _interpret_color(color, offset)


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_color_code(fg, 0)}m")
    if bg is not None:
        bits.append(f"\033[{_color_code(bg, 10)}m")
    for val, on, off in ((bold, 1, 22), (dim, 2, 22), (underline, 4, 24), (overline, 53, 55),
                         (italic, 3, 23), (blink, 5, 25), (reverse, 7, 27), (strikethrough, 9, 29)):
        if val is not None:
            bits.append(f"\033[{on if val else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def unstyle(text):
    return strip_ansi(text)


def _find_binary_writer(stream):
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is not None and hasattr(buf, "write"):
        return buf
    return None


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
    if file is None:
        return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        out = out + (b"\n" if isinstance(out, (bytes, bytearray)) else "\n")
    if not out:
        try:
            file.flush()
        except Exception:
            pass
        return
    if isinstance(out, (bytes, bytearray)):
        binary = _find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(out)
            binary.flush()
            return
        out = bytes(out).decode("utf-8", "replace")
    if color is None:
        ctx = get_current_context(silent=True)
        if ctx is not None:
            color = ctx.color
    if should_strip_ansi(file, color):
        out = strip_ansi(out)
    enc = (getattr(file, "encoding", None) or "").lower().replace("_", "-")
    if enc in ("ascii", "us-ascii", "ansi-x3.4-1968", "646"):
        binary = _find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(out.encode("utf-8"))
            binary.flush()
            return
    file.write(out)
    file.flush()


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        return filename.decode(sys.getfilesystemencoding() or "utf-8", "backslashreplace")
    return filename.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")


def get_app_dir(app_name, roaming=True, force_posix=False):
    def posixify(name):
        return "-".join(name.split()).lower()

    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser("~"), "." + posixify(app_name))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return os.path.join(base, posixify(app_name))


# ---------------------------------------------------------------- files

class _AtomicFile:
    def __init__(self, f, tmp, real):
        self._f = f
        self._tmp = tmp
        self._real = real
        self._done = False

    @property
    def name(self):
        return self._real

    def close(self, delete=False):
        if self._done:
            return
        self._done = True
        self._f.close()
        if delete:
            try:
                os.unlink(self._tmp)
            except OSError:
                pass
        else:
            os.replace(self._tmp, self._real)

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, *a):
        self.close(delete=exc_type is not None)

    def __iter__(self):
        return iter(self._f)


class _NonClosingTextIOWrapper(io.TextIOWrapper):
    def close(self):
        try:
            self.flush()
        except Exception:
            pass

    def __del__(self):
        pass


class _KeepOpenFile:
    def __init__(self, f):
        self._f = f

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass

    def close(self):
        pass

    def __iter__(self):
        return iter(self._f)

    def __repr__(self):
        return repr(self._f)


def _std_stream(name, binary, encoding, errors):
    stream = getattr(sys, name)
    if binary:
        b = getattr(stream, "buffer", None)
        return b if b is not None else stream
    if encoding is None and errors == "strict":
        return stream
    b = getattr(stream, "buffer", None)
    if b is None:
        return stream
    if encoding is None:
        encoding = getattr(stream, "encoding", None) or "utf-8"
    try:
        stream.flush()
    except Exception:
        pass
    return _NonClosingTextIOWrapper(b, encoding=encoding, errors=errors, write_through=True) \
        if name != "stdin" else _NonClosingTextIOWrapper(b, encoding=encoding, errors=errors)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if filename == "-" or filename == b"-":
        if any(m in mode for m in ("w", "a", "x")):
            return _std_stream("stdout", binary, encoding, errors), False
        return _std_stream("stdin", binary, encoding, errors), False
    if not atomic:
        return open(filename, mode, encoding=None if binary else encoding,
                    errors=None if binary else errors), True
    if "r" in mode or "x" in mode or "a" in mode:
        return open(filename, mode, encoding=None if binary else encoding,
                    errors=None if binary else errors), True
    d = os.path.dirname(os.path.abspath(filename))
    fd, tmp = tempfile.mkstemp(dir=d, prefix=".__atomic-write")
    os.close(fd)
    try:
        f = open(tmp, mode, encoding=None if binary else encoding, errors=None if binary else errors)
    except BaseException:
        os.unlink(tmp)
        raise
    return _AtomicFile(f, tmp, filename), True


class LazyFile:
    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True

    def open(self):
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(self.name, self.mode, self.encoding, self.errors, self.atomic)
        except OSError as e:
            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)

    def __getattr__(self, name):
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{format_filename(self.name)}' {self.mode}>"


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = _KeepOpenFile(f)
    return f


def get_text_stream(name, encoding=None, errors="strict"):
    return _std_stream(name, False, encoding, errors)


def get_binary_stream(name):
    return _std_stream(name, True, None, "strict")


# ---------------------------------------------------------------- pager

def _interactive():
    return isatty(sys.stdin) and isatty(sys.stdout)


class _PagerStream:
    def __init__(self, write, flush, close=None):
        self._w = write
        self._flush = flush
        self._close = close

    def write(self, text):
        if isinstance(text, bytes):
            text = text.decode("utf-8", "replace")
        self._w(text)
        return len(text)

    def writelines(self, lines):
        for l in lines:
            self.write(l)

    def flush(self):
        self._flush()

    def isatty(self):
        return False


@contextlib.contextmanager
def get_pager_file(color=None):
    pager = os.environ.get("PAGER", "").strip()
    if not _interactive() or not pager:
        yield _PagerStream(lambda t: echo(t, nl=False, color=color),
                           lambda: sys.stdout.flush() if sys.stdout else None)
        return
    proc = subprocess.Popen(pager, shell=True, stdin=subprocess.PIPE, text=True,
                            encoding="utf-8", errors="replace")

    def w(t):
        if color is False or (color is None and False):
            t = strip_ansi(t)
        elif color is None:
            ctx = get_current_context(silent=True)
            if ctx is not None and ctx.color is False:
                t = strip_ansi(t)
        try:
            proc.stdin.write(t)
            proc.stdin.flush()
        except (BrokenPipeError, OSError):
            pass

    try:
        yield _PagerStream(w, lambda: None)
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        while True:
            try:
                proc.wait()
                break
            except KeyboardInterrupt:
                pass


def echo_via_pager(text_or_generator, color=None):
    it = text_or_generator
    if callable(it):
        it = it()
    if isinstance(it, str):
        it = [it if it.endswith("\n") else it + "\n"]
    elif isinstance(it, (bytes, bytearray)):
        it = [bytes(it).decode("utf-8", "replace")]
    with get_pager_file(color) as f:
        for chunk in it:
            if not isinstance(chunk, str):
                chunk = str(chunk)
            f.write(chunk)
            f.flush()
        # a trailing newline mirrors echo semantics
