"""Terminal interaction helpers."""
import getpass
import inspect
import io
import math
import os
import shutil
import subprocess
import sys
import tempfile
import time
from contextlib import contextmanager

from . import _compat
from .exceptions import Abort, ColorError, OptlynException, UsageError
from .globals import resolve_color_default
from .types import Choice, convert_type
from .utils import echo, get_app_dir, format_filename  # noqa: F401

visible_prompt_func = input
hidden_prompt_func = getpass.getpass

_ansi_colors = {
    "black": 30, "red": 31, "green": 32, "yellow": 33, "blue": 34, "magenta": 35,
    "cyan": 36, "white": 37, "reset": 39, "bright_black": 90, "bright_red": 91,
    "bright_green": 92, "bright_yellow": 93, "bright_blue": 94, "bright_magenta": 95,
    "bright_cyan": 96, "bright_white": 97,
}
_ansi_reset_all = "\033[0m"


def _interpret_color(color, offset=0):
    if isinstance(color, bool):
        raise ColorError(f"Unknown color {color!r}")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise ColorError(f"Unknown color {color!r}")
        return f"{38 + offset};5;{color:d}"
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or any(isinstance(c, bool) or not isinstance(c, int)
                                  or not 0 <= c <= 255 for c in color):
            raise ColorError(f"Unknown color {color!r}")
        r, g, b = color
        return f"{38 + offset};2;{r:d};{g:d};{b:d}"
    if isinstance(color, str) and color in _ansi_colors:
        return str(_ansi_colors[color] + offset)
    raise ColorError(f"Unknown color {color!r}")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    if not isinstance(text, str):
        text = str(text)
    bits = []
    if fg is not None:
        bits.append(f"\033[{_interpret_color(fg)}m")
    if bg is not None:
        bits.append(f"\033[{_interpret_color(bg, 10)}m")
    for val, on, off in ((bold, 1, 22), (dim, 2, 22), (underline, 4, 24), (overline, 53, 55),
                         (italic, 3, 23), (blink, 5, 25), (reverse, 7, 27),
                         (strikethrough, 9, 29)):
        if val is not None:
            bits.append(f"\033[{on if val else off}m")
    bits.append(text)
    if reset:
        bits.append(_ansi_reset_all)
    return "".join(bits)


def unstyle(text):
    return _compat.strip_ansi(text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None and not isinstance(message, (bytes, bytearray)):
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def _build_prompt(text, suffix, show_default=False, default=None, show_choices=True, type=None):
    prompt = text
    if type is not None and show_choices and isinstance(type, Choice):
        prompt += " ({})".format(", ".join(map(str, [getattr(c, "name", c) for c in type.choices])))
    if default is not None and show_default:
        prompt = f"{prompt} [{_format_default(default)}]"
    return f"{prompt}{suffix}"


def _format_default(default):
    if hasattr(default, "name") and hasattr(default, "mode"):
        return default.name
    return default


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    def prompt_func(text):
        f = hidden_prompt_func if hide_input else visible_prompt_func
        try:
            echo(text.rstrip(" "), nl=False, err=err)
            return f(" ")
        except (KeyboardInterrupt, EOFError):
            if hide_input:
                echo(None, err=err)
            raise Abort() from None

    if value_proc is None:
        value_proc = convert_type(type, default)
    prompt_text = _build_prompt(text, prompt_suffix, show_default, default, show_choices, type)
    if confirmation_prompt:
        if confirmation_prompt is True:
            confirmation_prompt = "Repeat for confirmation"
        confirmation_prompt = _build_prompt(confirmation_prompt, prompt_suffix)
    while True:
        while True:
            value = prompt_func(prompt_text)
            if value:
                break
            elif default is not None:
                value = default
                break
        try:
            result = value_proc(value)
        except UsageError as e:
            if hide_input:
                echo("Error: The value you entered was invalid.", err=err)
            else:
                echo(f"Error: {e.message}", err=err)
            continue
        if not confirmation_prompt:
            return result
        while True:
            value2 = prompt_func(confirmation_prompt)
            is_empty = not value and not value2
            if value2 or is_empty:
                break
        if value == value2:
            return result
        echo("Error: The two entered values do not match.", err=err)


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    prompt_text = _build_prompt(text, prompt_suffix, show_default,
                                "y/n" if default is None else ("Y/n" if default else "y/N"))
    while True:
        try:
            echo(prompt_text.rstrip(" "), nl=False, err=err)
            value = visible_prompt_func(" ").lower().strip()
        except (KeyboardInterrupt, EOFError):
            raise Abort() from None
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif default is not None and value == "":
            rv = default
        else:
            echo("Error: invalid input", err=err)
            continue
        break
    if abort and not rv:
        raise Abort()
    return rv


def getchar(echo=False):
    import termios
    import tty
    f = None
    if not _compat.isatty(sys.stdin):
        f = open("/dev/tty")
        fd = f.fileno()
    else:
        fd = sys.stdin.fileno()
    ch = ""
    try:
        old = termios.tcgetattr(fd)
        try:
            tty.setraw(fd)
            ch = os.read(fd, 32).decode(getattr(sys.stdin, "encoding", None) or "utf-8", "replace")
            if echo and _compat.isatty(sys.stdout):
                sys.stdout.write(ch)
        finally:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
            sys.stdout.flush()
    finally:
        if f is not None:
            f.close()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    return ch


def pause(info=None, err=False):
    if info is None:
        info = "Press any key to continue..."
    if not _compat.interactive():
        echo(info, nl=False, err=err)
        echo(None, err=err)
        return
    try:
        if info:
            echo(info, nl=False, err=err)
        try:
            getchar()
        except (KeyboardInterrupt, EOFError):
            pass
    finally:
        if info:
            echo(err=err)


def clear():
    if not _compat.isatty(sys.stdout):
        return
    echo("\033[2J\033[1;1H", nl=False)


def launch(url, wait=False, locate=False):
    opener = shutil.which("xdg-open")
    if opener is None:
        return 127
    if url.startswith("file://"):
        from urllib.parse import unquote
        url = unquote(url[7:])
    if locate:
        url = os.path.dirname(url) or "."
    try:
        return subprocess.call([opener, url])
    except OSError:
        return 127


class Editor:
    def __init__(self, editor=None, env=None, require_save=True, extension=".txt"):
        self.editor = editor
        self.env = env
        self.require_save = require_save
        self.extension = extension

    def get_editor(self):
        if self.editor is not None:
            return self.editor
        for key in "VISUAL", "EDITOR":
            rv = os.environ.get(key)
            if rv:
                return rv
        return "vi"

    def edit_file(self, filename):
        editor = self.get_editor()
        environ = None
        if self.env:
            environ = os.environ.copy()
            environ.update(self.env)
        try:
            c = subprocess.Popen(f'{editor} "{filename}"', env=environ, shell=True)
            exit_code = c.wait()
            if exit_code != 0:
                raise OptlynException(f"{editor}: Editing failed")
        except OSError as e:
            raise OptlynException(f"{editor}: Editing failed: {e}") from e

    def edit(self, text):
        text = text or ""
        binary = isinstance(text, bytes)
        if not binary and text and not text.endswith("\n"):
            text += "\n"
        fd, name = tempfile.mkstemp(prefix="editor-", suffix=self.extension)
        try:
            with os.fdopen(fd, "wb") as f:
                f.write(text if binary else text.encode("utf-8"))
            st = os.stat(name)
            before = (st.st_mtime_ns, st.st_size)
            self.edit_file(name)
            st = os.stat(name)
            if self.require_save and (st.st_mtime_ns, st.st_size) == before:
                return None
            with open(name, "rb") as f:
                rv = f.read()
            if binary:
                return rv
            return rv.decode("utf-8-sig").replace("\r\n", "\n")
        finally:
            os.unlink(name)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    ed = Editor(editor=editor, env=env, require_save=require_save, extension=extension)
    if filename is None:
        return ed.edit(text)
    ed.edit_file(filename)
    return None


# --- pager -----------------------------------------------------------------

class _PagerStream:
    def __init__(self, target, strip):
        self._t = target
        self._strip = strip

    def write(self, text):
        if isinstance(text, bytes):
            text = text.decode("utf-8", "replace")
        if self._strip:
            text = _compat.strip_ansi(text)
        self._t.write(text)
        return len(text)

    def flush(self):
        try:
            self._t.flush()
        except Exception:
            pass

    def writable(self):
        return True

    def isatty(self):
        return False


@contextmanager
def get_pager_file(color=None):
    stdout = sys.stdout
    color = resolve_color_default(color)
    if not _compat.interactive():
        yield _PagerStream(stdout, _compat.should_strip_ansi(stdout, color))
        return
    cmd = (os.environ.get("PAGER") or "").strip()
    if not cmd:
        for cand in ("less", "more"):
            if shutil.which(cand):
                cmd = cand
                break
    if not cmd:
        yield _PagerStream(stdout, _compat.should_strip_ansi(stdout, color))
        return
    env = dict(os.environ)
    if "LESS" not in env and color:
        env["LESS"] = "-R"
    proc = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, env=env, text=True,
                            errors="replace")
    stream = _PagerStream(proc.stdin, not color)
    try:
        yield stream
    finally:
        try:
            proc.stdin.close()
        except (OSError, BrokenPipeError):
            pass
        while True:
            try:
                proc.wait()
            except KeyboardInterrupt:
                continue
            break


def echo_via_pager(text_or_generator, color=None):
    if inspect.isgeneratorfunction(text_or_generator) or callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    with get_pager_file(color=color) as f:
        for chunk in chunks:
            f.write(chunk if isinstance(chunk, str) else str(chunk))
            f.flush()
        f.write("\n")
        f.flush()


# --- progress bar ------------------------------------------------------------

def _length_hint(it):
    try:
        return len(it)
    except (AttributeError, TypeError):
        try:
            return int(it.__length_hint__())
        except Exception:
            return None


class ProgressBar:
    def __init__(self, iterable=None, length=None, fill_char="#", empty_char="-",
                 bar_template="%(label)s  [%(bar)s]  %(info)s", info_sep="  ", show_eta=True,
                 show_percent=None, show_pos=False, item_show_func=None, label=None, file=None,
                 color=None, update_min_steps=1, width=36, hidden=False):
        if iterable is None:
            if length is None:
                raise TypeError("iterable or length is required")
            iterable = range(length)
        if length is None:
            length = _length_hint(iterable)
        self.iter = iter(iterable)
        self.length = length
        self.pos = 0
        self.label = label or ""
        self.file = file if file is not None else sys.stdout
        self.color = color
        self.fill_char = fill_char
        self.empty_char = empty_char
        self.bar_template = bar_template
        self.info_sep = info_sep
        self.show_eta = show_eta
        self.show_percent = show_percent if show_percent is not None else length is not None
        self.show_pos = show_pos
        self.item_show_func = item_show_func
        self.width = width
        self.hidden = hidden
        self.current_item = None
        self.start = self.last_eta = time.time()
        self.finished = False
        self.entered = False
        self._last_line = None
        self._printed_label = False

    def __enter__(self):
        self.entered = True
        self.render_progress()
        return self

    def __exit__(self, *a):
        self.render_finish()

    @property
    def is_tty(self):
        return _compat.isatty(self.file)

    @property
    def eta(self):
        if self.length is not None and not self.finished and self.pos > 0:
            elapsed = time.time() - self.start
            return elapsed / self.pos * (self.length - self.pos)
        return 0.0

    def format_eta(self):
        if self.length is not None and not self.finished:
            t = int(self.eta)
            s = t % 60
            t //= 60
            m = t % 60
            t //= 60
            h = t % 24
            t //= 24
            if t > 0:
                return f"{t}d {h:02}:{m:02}:{s:02}"
            return f"{h:02}:{m:02}:{s:02}"
        return ""

    def format_pct(self):
        if not self.length:
            return "100%"
        return f"{int(self.pos * 100 / self.length): 4}%"[1:]

    def format_pos(self):
        pos = str(self.pos)
        if self.length is not None:
            pos += f"/{self.length}"
        return pos

    def format_bar(self):
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            n = int(frac * self.width)
            return self.fill_char * n + self.empty_char * (self.width - n)
        return self.empty_char * self.width

    def render_progress(self):
        if self.hidden:
            return
        if not self.is_tty:
            if self.label and not self._printed_label:
                self._printed_label = True
                echo(self.label, file=self.file, color=self.color)
            return
        info = []
        if self.show_pos:
            info.append(self.format_pos())
        if self.show_percent:
            info.append(self.format_pct())
        if self.show_eta and self.length is not None and not self.finished:
            eta = self.format_eta()
            if eta:
                info.append(eta)
        if self.item_show_func is not None:
            item = self.item_show_func(self.current_item)
            if item:
                info.append(item)
        line = self.bar_template % {"label": self.label, "bar": self.format_bar(),
                                    "info": self.info_sep.join(info)}
        line = line.rstrip()
        if line != self._last_line:
            self._last_line = line
            self.file.write("\r" + line)
            self.file.flush()

    def render_finish(self):
        if self.hidden or not self.is_tty:
            return
        self.file.write("\n")
        self.file.flush()

    def update(self, n_steps=1, current_item=None):
        self.pos += n_steps
        if self.length is not None and self.pos >= self.length:
            self.finished = True
        if current_item is not None:
            self.current_item = current_item
        self.render_progress()

    def finish(self):
        self.finished = True
        self.render_progress()

    def __iter__(self):
        if not self.entered:
            raise RuntimeError("You need to use progress bars in a with block.")
        return self._generator()

    def _generator(self):
        for rv in self.iter:
            self.current_item = rv
            yield rv
            self.update(1)
        self.finish()


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)
