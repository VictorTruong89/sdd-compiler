"""In-process runner."""
import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile

from . import _compat, formatting, termui, utils


class _Tee(io.BytesIO):
    def __init__(self, combined, fd=None):
        super().__init__()
        self._combined = combined
        self._fd = fd

    def write(self, b):
        self._combined.write(b)
        return super().write(b)

    def fileno(self):
        if self._fd is None:
            return super().fileno()
        return self._fd


class _NamedTextIOWrapper(io.TextIOWrapper):
    def __init__(self, buffer, name=None, mode=None, **kwargs):
        super().__init__(buffer, **kwargs)
        self._name = name
        self._mode = mode

    @property
    def name(self):
        return self._name

    @property
    def mode(self):
        return self._mode


class _EchoingStdin:
    def __init__(self, input, output):
        self._input = input
        self._output = output
        self._paused = False

    def __getattr__(self, x):
        return getattr(self._input, x)

    def _echo(self, rv):
        if not self._paused:
            self._output.write(rv)
        return rv

    def read(self, n=-1):
        return self._echo(self._input.read(n))

    def read1(self, n=-1):
        return self._echo(self._input.read1(n))

    def readline(self, n=-1):
        return self._echo(self._input.readline(n))

    def readlines(self):
        return [self._echo(x) for x in self._input.readlines()]

    def __iter__(self):
        return iter(self._echo(x) for x in self._input)


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code,
                 exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    def _dec(self, b):
        return b.decode(self.runner.charset, "replace").replace("\r\n", "\n")

    @property
    def output(self):
        return self._dec(self.output_bytes)

    @property
    def stdout(self):
        return self._dec(self.stdout_bytes)

    @property
    def stderr(self):
        return self._dec(self.stderr_bytes)

    def __repr__(self):
        name = type(self.exception).__name__ if self.exception else "okay"
        return f"<Result {name}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        self.charset = charset
        self.env = env or {}
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    def get_default_prog_name(self, cli):
        return cli.name or "root"

    def make_env(self, overrides=None):
        rv = dict(self.env)
        if overrides:
            rv.update(overrides)
        return rv

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        if hasattr(input, "read"):
            bytes_input = _compat.find_binary_reader(input)
            if bytes_input is None:
                raise TypeError("Could not find binary reader for input stream.")
        else:
            if input is None:
                input = b""
            elif isinstance(input, str):
                input = input.encode(self.charset)
            bytes_input = io.BytesIO(input)
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        old_visible, old_hidden = termui.visible_prompt_func, termui.hidden_prompt_func
        old_strip = _compat.should_strip_ansi
        old_width = formatting.FORCED_WIDTH
        formatting.FORCED_WIDTH = 80
        env = self.make_env(env)
        combined = io.BytesIO()
        fd_mode = self.capture == "fd"
        out_buf = _Tee(combined, 1 if fd_mode else None)
        err_buf = _Tee(combined, 2 if fd_mode else None)
        if self.echo_stdin:
            bytes_input = _EchoingStdin(bytes_input, combined)
        text_input = _NamedTextIOWrapper(bytes_input, name="<stdin>", mode="r",
                                         encoding=self.charset)
        if self.echo_stdin:
            text_input._CHUNK_SIZE = 1
        sys.stdin = text_input
        sys.stdout = _NamedTextIOWrapper(out_buf, name="<stdout>", mode="w", encoding=self.charset,
                                         write_through=True)
        sys.stderr = _NamedTextIOWrapper(err_buf, name="<stderr>", mode="w", encoding=self.charset,
                                         errors="backslashreplace", write_through=True)
        saved_fds = None
        tmp_out = tmp_err = None
        if fd_mode:
            sys.stdout.flush()
            tmp_out = tempfile.TemporaryFile()
            tmp_err = tempfile.TemporaryFile()
            saved_fds = (os.dup(1), os.dup(2))
            os.dup2(tmp_out.fileno(), 1)
            os.dup2(tmp_err.fileno(), 2)

        def visible_input(prompt=None):
            sys.stdout.write(prompt or "")
            line = text_input.readline()
            if not line:
                raise EOFError()
            val = line.rstrip("\r\n")
            if not self.echo_stdin:
                sys.stdout.write(f"{val}\n")
            sys.stdout.flush()
            return val

        def hidden_input(prompt=None):
            sys.stdout.write(f"{prompt or ''}\n")
            sys.stdout.flush()
            line = text_input.readline()
            if not line:
                raise EOFError()
            return line.rstrip("\r\n")

        def should_strip_ansi(stream=None, color_=None):
            if color_ is None:
                return not color
            return not color_

        termui.visible_prompt_func = visible_input
        termui.hidden_prompt_func = hidden_input
        _compat.should_strip_ansi = should_strip_ansi
        old_env = {}
        try:
            for key, value in env.items():
                old_env[key] = os.environ.get(key)
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            streams = [out_buf, err_buf, combined]
            self._fd_state = [saved_fds, tmp_out, tmp_err]
            yield streams
        finally:
            if fd_mode and self._fd_state[0] is not None:
                _finish_fd(self._fd_state[0], tmp_out, tmp_err, out_buf, err_buf, combined)
            for key, value in old_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            sys.stdin, sys.stdout, sys.stderr = old_stdin, old_stdout, old_stderr
            termui.visible_prompt_func, termui.hidden_prompt_func = old_visible, old_hidden
            _compat.should_strip_ansi = old_strip
            formatting.FORCED_WIDTH = old_width

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        exc_info = None
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        with self.isolation(input=input, env=env, color=color) as outstreams:
            return_value = None
            exception = None
            exit_code = 0
            if isinstance(args, str):
                args = shlex.split(args)
            try:
                prog_name = extra.pop("prog_name", None)
                if prog_name is None:
                    prog_name = self.get_default_prog_name(cli)
                try:
                    return_value = cli.main(args=args or (), prog_name=prog_name, **extra)
                except SystemExit as e:
                    exc_info = sys.exc_info()
                    e_code = e.code
                    if e_code is None:
                        e_code = 0
                    if e_code != 0:
                        exception = e
                    if not isinstance(e_code, int):
                        sys.stdout.write(str(e_code))
                        sys.stdout.write("\n")
                        e_code = 1
                    exit_code = e_code
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                sys.stdout.flush()
                sys.stderr.flush()
                if self.capture == "fd":
                    _finish_fd(self._fd_state[0], self._fd_state[1], self._fd_state[2],
                               outstreams[0], outstreams[1], outstreams[2])
                    self._fd_state[0] = None
                stdout = outstreams[0].getvalue()
                stderr = outstreams[1].getvalue()
                output = outstreams[2].getvalue()
        return Result(self, stdout, stderr, output, return_value, exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        dt = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(dt)
        try:
            yield dt
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                try:
                    shutil.rmtree(dt)
                except OSError:
                    pass


def _finish_fd(saved_fds, tmp_out, tmp_err, out_buf, err_buf, combined):
    try:
        sys.stdout.flush()
        sys.stderr.flush()
    except Exception:
        pass
    os.dup2(saved_fds[0], 1)
    os.dup2(saved_fds[1], 2)
    os.close(saved_fds[0])
    os.close(saved_fds[1])
    for tmp, buf in ((tmp_out, out_buf), (tmp_err, err_buf)):
        tmp.seek(0)
        data = tmp.read()
        tmp.close()
        if data:
            io.BytesIO.write(buf, data)
            combined.write(data)
