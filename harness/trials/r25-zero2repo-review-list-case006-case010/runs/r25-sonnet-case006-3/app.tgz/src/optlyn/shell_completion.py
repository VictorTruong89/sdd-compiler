"""Shell completion."""
import os
import re
import shlex

from .core import Argument, Group, Option, ParameterSource
from .utils import echo


class CompletionItem:
    __slots__ = ("value", "type", "help", "_info")

    def __init__(self, value, type="plain", help=None, **kwargs):
        self.value = value
        self.type = type
        self.help = help
        self._info = kwargs

    def __repr__(self):
        return f"CompletionItem({self.value!r}, {self.type!r})"


def split_arg_string(string):
    lex = shlex.shlex(string, posix=True)
    lex.whitespace_split = True
    lex.commenters = ""
    out = []
    try:
        for token in lex:
            out.append(token)
    except ValueError:
        out.extend(lex.token and [lex.token] or [])
    return out


_SOURCES = {
    "bash": """%(func)s() {
    local IFS=$'\\n'
    local response
    response=$(env COMP_WORDS="${COMP_WORDS[*]}" COMP_CWORD=$COMP_CWORD %(var)s=bash_complete $1)
    for completion in $response; do
        IFS=',' read type value <<< "$completion"
        if [[ $type == 'dir' ]]; then
            COMPREPLY=()
            compopt -o dirnames
        elif [[ $type == 'file' ]]; then
            COMPREPLY=()
            compopt -o default
        elif [[ $type == 'plain' ]]; then
            COMPREPLY+=($value)
        fi
    done
    return 0
}

%(func)s_setup() {
    complete -o nosort -F %(func)s %(prog)s
}

%(func)s_setup;
""",
    "zsh": """#compdef %(prog)s

%(func)s() {
    local -a completions
    local -a completions_with_descriptions
    local -a response
    (( ! $+commands[%(prog)s] )) && return 1

    response=("${(@f)$(env COMP_WORDS="${words[*]}" COMP_CWORD=$((CURRENT-1)) %(var)s=zsh_complete %(prog)s)}")

    for type key descr in ${response}; do
        if [[ "$type" == "plain" ]]; then
            if [[ "$descr" == "_" ]]; then
                completions+=("$key")
            else
                completions_with_descriptions+=("$key":"$descr")
            fi
        elif [[ "$type" == "dir" ]]; then
            _path_files -/
        elif [[ "$type" == "file" ]]; then
            _path_files -f
        fi
    done

    if [ -n "$completions_with_descriptions" ]; then
        _describe -V unsorted completions_with_descriptions -U
    fi
    if [ -n "$completions" ]; then
        compadd -U -V unsorted -a completions
    fi
}

if [[ $zsh_eval_context[-1] == loadautofunc ]]; then
    %(func)s "$@"
else
    compdef %(func)s %(prog)s
fi
""",
    "fish": """function %(func)s;
    set -l response (env %(var)s=fish_complete COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -t) %(prog)s);

    for completion in $response;
        set -l metadata (string split "," -- $completion);

        if test $metadata[1] = "dir";
            __fish_complete_directories $metadata[2];
        else if test $metadata[1] = "file";
            __fish_complete_path $metadata[2];
        else if test $metadata[1] = "plain";
            echo $metadata[2];
        end;
    end;
end;

complete --no-files --command %(prog)s --arguments "(%(func)s)";
""",
    "powershell": """Register-ArgumentCompleter -Native -CommandName %(prog)s -ScriptBlock {
    param($wordToComplete, $commandAst, $cursorPosition)
    $env:COMP_WORDS = $commandAst
    $env:COMP_CWORD = $commandAst.CommandElements.Count - 1
    $env:%(var)s = "powershell_complete"
    %(prog)s | ForEach-Object {
        $type, $value, $help = $_.Split(":", 3)
        if ($type -eq "plain") {
            [System.Management.Automation.CompletionResult]::new($value, $value, "ParameterValue", $value)
        } elseif ($type -eq "file" -or $type -eq "dir") {
            [System.Management.Automation.CompletionResult]::new($value, $value, "ProviderItem", $value)
        }
    }
    Remove-Item Env:%(var)s
}
""",
}


class ShellComplete:
    name = ""

    def __init__(self, cli, ctx_args, prog_name, complete_var):
        self.cli = cli
        self.ctx_args = ctx_args
        self.prog_name = prog_name
        self.complete_var = complete_var

    @property
    def func_name(self):
        safe = re.sub(r"\W*", "", self.prog_name.replace("-", "_"), flags=re.ASCII)
        return f"_{safe}_completion"

    def source(self):
        return _SOURCES[self.name] % {"func": self.func_name, "var": self.complete_var,
                                      "prog": self.prog_name}

    def get_completion_args(self):
        cwords = split_arg_string(os.environ.get("COMP_WORDS", ""))
        cword = int(os.environ.get("COMP_CWORD", len(cwords)))
        args = cwords[1:cword]
        try:
            incomplete = cwords[cword]
        except IndexError:
            incomplete = ""
        return args, incomplete

    def get_completions(self, args, incomplete):
        ctx = _resolve_context(self.cli, self.ctx_args, self.prog_name, args)
        obj, incomplete = _resolve_incomplete(ctx, args, incomplete)
        return obj.shell_complete(ctx, incomplete)

    def format_completion(self, item):
        return f"{item.type},{item.value}"

    def complete(self):
        args, incomplete = self.get_completion_args()
        completions = self.get_completions(args, incomplete)
        return "\n".join(self.format_completion(item) for item in completions)


class BashComplete(ShellComplete):
    name = "bash"


class ZshComplete(ShellComplete):
    name = "zsh"

    def format_completion(self, item):
        return f"{item.type}\n{item.value}\n{item.help if item.help else '_'}"


class FishComplete(ShellComplete):
    name = "fish"

    def get_completion_args(self):
        cwords = split_arg_string(os.environ.get("COMP_WORDS", ""))
        incomplete = os.environ.get("COMP_CWORD", "")
        args = cwords[1:]
        if incomplete and args and args[-1] == incomplete:
            args.pop()
        return args, incomplete

    def format_completion(self, item):
        if item.help:
            return f"{item.type},{item.value}\t{item.help}"
        return f"{item.type},{item.value}"


class PowerShellComplete(ShellComplete):
    name = "powershell"

    def format_completion(self, item):
        return f"{item.type}:{item.value}:{item.help or ' '}"


_registry = {"bash": BashComplete, "zsh": ZshComplete, "fish": FishComplete,
             "powershell": PowerShellComplete}


def get_completion_class(shell):
    return _registry.get(shell)


def shell_complete(cli, ctx_args, prog_name, complete_var, instruction):
    shell, _, instruction = instruction.partition("_")
    comp_cls = get_completion_class(shell)
    if comp_cls is None:
        return 1
    comp = comp_cls(cli, ctx_args, prog_name, complete_var)
    if instruction == "source":
        echo(comp.source())
        return 0
    if instruction == "complete":
        echo(comp.complete())
        return 0
    return 1


def _start_of_option(ctx, value):
    if not value:
        return False
    c = value[0]
    return not c.isalnum() and (c in ctx._opt_prefixes or c in "-+/")


def _is_incomplete_option(ctx, args, incomplete):
    for param in ctx.command.get_params(ctx):
        if not isinstance(param, Option) or param.is_flag or param.count:
            continue
        last_option = None
        for index, arg in enumerate(reversed(args)):
            if index + 1 > param.nargs:
                break
            if _start_of_option(ctx, arg):
                last_option = arg
        if last_option is not None and last_option in param.opts:
            return param
    return None


def _is_incomplete_argument(ctx, param):
    if not isinstance(param, Argument):
        return False
    value = ctx.params.get(param.name)
    return (param.nargs == -1
            or ctx.get_parameter_source(param.name) is not ParameterSource.COMMANDLINE
            or (param.nargs > 1 and isinstance(value, (tuple, list)) and len(value) < param.nargs))


def _resolve_context(cli, ctx_args, prog_name, args):
    ctx_args = dict(ctx_args)
    ctx_args["resilient_parsing"] = True
    ctx = cli.make_context(prog_name, list(args), **ctx_args)
    args = ctx.protected_args + ctx.args
    while args:
        command = ctx.command
        if isinstance(command, Group):
            if not command.chain:
                name, cmd, args = command.resolve_command(ctx, args)
                if cmd is None:
                    return ctx
                ctx = cmd.make_context(name, args, parent=ctx, resilient_parsing=True)
                args = ctx.protected_args + ctx.args
            else:
                sub_ctx = ctx
                while args:
                    name, cmd, args = command.resolve_command(ctx, args)
                    if cmd is None:
                        return ctx
                    sub_ctx = cmd.make_context(name, args, parent=ctx, allow_extra_args=True,
                                               allow_interspersed_args=False,
                                               resilient_parsing=True)
                    args = sub_ctx.args
                ctx = sub_ctx
                args = [*sub_ctx.protected_args, *sub_ctx.args]
        else:
            break
    return ctx


def _resolve_incomplete(ctx, args, incomplete):
    if incomplete and "=" in incomplete and _start_of_option(ctx, incomplete):
        name, _, val = incomplete.partition("=")
        for param in ctx.command.get_params(ctx):
            if isinstance(param, Option) and name in param.opts and not param.is_flag:
                return param, val
    param = _is_incomplete_option(ctx, args, incomplete)
    if param is not None:
        return param, incomplete
    if _start_of_option(ctx, incomplete):
        return ctx.command, incomplete
    for param in ctx.command.get_params(ctx):
        if _is_incomplete_argument(ctx, param):
            return param, incomplete
    return ctx.command, incomplete
