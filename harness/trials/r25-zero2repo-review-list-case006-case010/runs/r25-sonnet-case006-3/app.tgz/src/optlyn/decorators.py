"""Declaration decorators."""
import inspect
import sys
from functools import update_wrapper

from .core import Argument, Command, Group, Option, _show_help
from .globals import get_current_context
from .utils import echo

_ATTR = "__optlyn_params__"


def pass_context(f):
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)
    return update_wrapper(new_func, f)


def pass_obj(f):
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)
    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            obj = ctx.ensure_object(object_type) if ensure else ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError("Managed to invoke callback without a context object of type "
                                   f"{object_type.__name__!r} existing.")
            return ctx.invoke(f, obj, *args, **kwargs)
        return update_wrapper(new_func, f)
    return decorator


def _param_memo(f, param):
    if isinstance(f, Command):
        f.params.append(param)
    else:
        if not hasattr(f, _ATTR):
            setattr(f, _ATTR, [])
        getattr(f, _ATTR).append(param)


def command(name=None, cls=None, **attrs):
    if cls is None:
        cls = Command
    func = None
    if callable(name):
        func = name
        name = None

    def decorator(f):
        if isinstance(f, Command):
            raise TypeError("Attempted to convert a callback into a command twice.")
        a = dict(attrs)
        params = a.pop("params", None)
        params = list(params) if params is not None else []
        if hasattr(f, _ATTR):
            decorator_params = getattr(f, _ATTR)
            delattr(f, _ATTR)
            params.extend(reversed(decorator_params))
        if a.get("help") is None:
            a["help"] = f.__doc__
        cmd_name = name
        if cmd_name is None:
            cmd_name = f.__name__.lower().replace("_", "-")
            left, sep, suffix = cmd_name.rpartition("-")
            if sep and suffix in {"command", "cmd", "group", "grp"} and left:
                cmd_name = left
        cmd = cls(name=cmd_name, callback=f, params=params, **a)
        cmd.__doc__ = f.__doc__
        return cmd

    if func is not None:
        return decorator(func)
    return decorator


def group(name=None, cls=None, **attrs):
    if cls is None:
        cls = Group
    if callable(name):
        return command(cls=cls, **attrs)(name)
    return command(name, cls, **attrs)


def argument(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Argument

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f
    return decorator


def option(*param_decls, cls=None, **attrs):
    if cls is None:
        cls = Option

    def decorator(f):
        _param_memo(f, cls(param_decls, **attrs))
        return f
    return decorator


def help_option(*param_decls, **kwargs):
    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help)
    return option(*param_decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    def callback(ctx, param, value):
        if not value:
            ctx.abort()

    if not param_decls:
        param_decls = ("--yes",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("callback", callback)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("prompt", "Do you want to continue?")
    kwargs.setdefault("help", "Confirm the action without prompting.")
    return option(*param_decls, **kwargs)


def password_option(*param_decls, **kwargs):
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("hide_input", True)
    return option(*param_decls, **kwargs)


def version_option(version=None, *param_decls, package_name=None, prog_name=None,
                   message=None, **kwargs):
    if message is None:
        message = "%(prog)s, version %(version)s"
    if version is None and package_name is None:
        frame = inspect.currentframe()
        f_back = frame.f_back if frame else None
        f_globals = f_back.f_globals if f_back else None
        del frame
        if f_globals is not None:
            package_name = f_globals.get("__name__")
            if package_name == "__main__":
                package_name = f_globals.get("__package__")
            if package_name:
                package_name = package_name.partition(".")[0]

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        nonlocal prog_name
        nonlocal version
        if prog_name is None:
            prog_name = ctx.find_root().info_name
        if version is None and package_name is not None:
            import importlib.metadata as md
            try:
                version = md.version(package_name)
            except md.PackageNotFoundError:
                try:
                    dists = md.packages_distributions().get(package_name)
                    if not dists:
                        raise md.PackageNotFoundError(package_name)
                    version = md.version(dists[0])
                except md.PackageNotFoundError:
                    raise RuntimeError(
                        f"{package_name!r} is not installed. Try passing 'package_name' "
                        "instead.") from None
        if version is None:
            raise RuntimeError("Could not determine the version for "
                               f"{package_name!r} automatically.")
        echo(message % {"prog": prog_name, "package": package_name, "version": version},
             color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    def cb(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=ctx.color)
        ctx.exit()

    if not param_decls:
        param_decls = ("--version",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = cb
    return option(*param_decls, **kwargs)
