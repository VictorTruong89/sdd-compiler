"""echo, file helpers, application dir."""
import io
import os
import sys

from . import _compat
from .exceptions import FileError
from .globals import resolve_color_default


def make_str(value):
    if isinstance(value, bytes):
        try:
            return value.decode(sys.getfilesystemencoding())
        except UnicodeError:
            return value.decode("utf-8", "replace")
    return str(value)


def safecall(func):
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception:
            pass
    return wrapper


def _ascii_only(file):
    enc = (getattr(file, "encoding", None) or "").lower().replace("_", "-")
    return enc in ("ascii", "us-ascii", "ansi-x3.4-1968", "646")


def echo(message=None, file=None, nl=True, err=False, color=None):
    if file is None:
        file = sys.stderr if err else sys.stdout
        if file is None:
            return
    if message is not None and not isinstance(message, (str, bytes, bytearray)):
        out = str(message)
    else:
        out = message
    if nl:
        out = out or ""
        if isinstance(out, str):
            out += "\n"
        else:
            out += b"\n"
    if not out:
        try:
            file.flush()
        except Exception:
            pass
        return
    if isinstance(out, (bytes, bytearray)):
        binary = _compat.find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(out)
            binary.flush()
            return
        out = out.decode("utf-8", "replace")
    color = resolve_color_default(color)
    if _compat.should_strip_ansi(file, color):
        out = _compat.strip_ansi(out)
    if _ascii_only(file):
        binary = _compat.find_binary_writer(file)
        if binary is not None:
            file.flush()
            binary.write(out.encode("utf-8"))
            binary.flush()
            return
    try:
        file.write(out)
    except UnicodeEncodeError:
        binary = _compat.find_binary_writer(file)
        if binary is None:
            raise
        file.flush()
        binary.write(out.encode("utf-8"))
        binary.flush()
        return
    file.flush()


def format_filename(filename, shorten=False):
    if shorten:
        filename = os.path.basename(filename)
    else:
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = filename.decode(sys.getfilesystemencoding(), "replace")
    else:
        filename = filename.encode("utf-8", "surrogateescape").decode("utf-8", "replace")
    return filename


def get_app_dir(app_name, roaming=True, force_posix=False):
    def posixify(name):
        return "-".join(name.split()).lower()

    if sys.platform.startswith("win"):
        key = "APPDATA" if roaming else "LOCALAPPDATA"
        folder = os.environ.get(key) or os.path.expanduser("~")
        return os.path.join(folder, app_name)
    if force_posix:
        return os.path.join(os.path.expanduser("~/.{}".format(posixify(app_name))))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return os.path.join(base, posixify(app_name))


class _AtomicFile:
    def __init__(self, f, tmp_filename, real_filename):
        self._f = f
        self._tmp_filename = tmp_filename
        self._real_filename = real_filename
        self.closed = False

    @property
    def name(self):
        return self._real_filename

    def close(self, delete=False):
        if self.closed:
            return
        self._f.close()
        if delete:
            try:
                os.unlink(self._tmp_filename)
            except OSError:
                pass
        else:
            os.replace(self._tmp_filename, self._real_filename)
        self.closed = True

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, *_):
        self.close(delete=exc_type is not None)

    def __iter__(self):
        return iter(self._f)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False):
    binary = "b" in mode
    filename = os.fspath(filename)
    if filename == "-" or filename == b"-":
        if any(m in mode for m in "wax"):
            if binary:
                return _compat.get_binary_stdout(), False
            return _compat.get_text_stdout(encoding=encoding, errors=errors), False
        if binary:
            return _compat.get_binary_stdin(), False
        return _compat.get_text_stdin(encoding=encoding, errors=errors), False
    if binary:
        encoding = errors = None
    if not atomic:
        return io.open(filename, mode, encoding=encoding, errors=errors), True
    if "r" in mode or "+" in mode:
        raise ValueError("Cannot open file in atomic read mode")
    import random
    flags = os.O_RDWR | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0)
    real = filename
    if os.path.exists(real):
        perm = os.stat(real).st_mode
        flags = os.O_RDWR | os.O_CREAT | os.O_EXCL | getattr(os, "O_BINARY", 0)
    else:
        perm = 0o666
    while True:
        tmp = os.path.join(os.path.dirname(real), ".__atomic-write{:08x}".format(random.randrange(1 << 32)))
        try:
            fd = os.open(tmp, flags, perm)
            break
        except FileExistsError:
            continue
    af = _AtomicFile(io.open(fd, mode, encoding=encoding, errors=errors), tmp, real)
    return af, True


class LazyFile:
    def __init__(self, filename, mode="r", encoding=None, errors="strict", atomic=False):
        self.name = os.fspath(filename)
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self.should_close = True
        if self.name == "-":
            self._f, self.should_close = open_stream(filename, mode, encoding, errors)
        elif "r" in mode:
            open(filename, mode).close()

    def __getattr__(self, name):
        return getattr(self.open(), name)

    def __repr__(self):
        if self._f is not None:
            return repr(self._f)
        return f"<unopened file '{format_filename(self.name)}' {self.mode}>"

    def open(self):
        if self._f is not None:
            return self._f
        try:
            rv, self.should_close = open_stream(self.name, self.mode, self.encoding,
                                                self.errors, atomic=self.atomic)
        except OSError as e:
            raise FileError(self.name, hint=e.strerror) from e
        self._f = rv
        return rv

    def close(self):
        if self._f is not None:
            self._f.close()

    def close_intelligently(self):
        if self.should_close:
            self.close()

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close_intelligently()

    def __iter__(self):
        self.open()
        return iter(self._f)


class KeepOpenFile:
    def __init__(self, file):
        self._file = file

    def __getattr__(self, name):
        return getattr(self._file, name)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        pass

    def __repr__(self):
        return repr(self._file)

    def __iter__(self):
        return iter(self._file)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic=atomic)
    f, should_close = open_stream(filename, mode, encoding, errors, atomic=atomic)
    if not should_close:
        f = KeepOpenFile(f)
    return f


def get_text_stream(name, encoding=None, errors="strict"):
    if name == "stdin":
        return _compat.get_text_stdin(encoding, errors)
    if name == "stdout":
        return _compat.get_text_stdout(encoding, errors)
    if name == "stderr":
        return sys.stderr
    raise TypeError(name)


def get_binary_stream(name):
    if name == "stdin":
        return _compat.get_binary_stdin()
    if name == "stdout":
        return _compat.get_binary_stdout()
    if name == "stderr":
        return _compat.find_binary_writer(sys.stderr)
    raise TypeError(name)
