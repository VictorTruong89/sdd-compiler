"""Stream helpers shared by the terminal helpers."""
import io
import re
import sys

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")


def strip_ansi(value):
    return _ansi_re.sub("", value)


def isatty(stream):
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def should_strip_ansi(stream=None, color=None):
    if color is None:
        if stream is None:
            stream = sys.stdin
        return not isatty(stream)
    return not color


def interactive():
    """A session is interactive when stdin or stdout is a terminal."""
    return isatty(sys.stdin) or isatty(sys.stdout)


def find_binary_writer(stream):
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is not None:
        return buf
    return None


def find_binary_reader(stream):
    if isinstance(stream, (io.RawIOBase, io.BufferedIOBase)):
        return stream
    buf = getattr(stream, "buffer", None)
    if buf is not None:
        return buf
    return None


def is_file_like(value):
    return hasattr(value, "read") or hasattr(value, "write")


class NonClosingTextIOWrapper(io.TextIOWrapper):
    """Text wrapper over a stream it does not own: never closes it."""

    def __del__(self):
        try:
            self.detach()
        except Exception:
            pass

    def close(self):
        try:
            self.flush()
        except Exception:
            pass


def wrap_text_stream(buffer, encoding, errors):
    return NonClosingTextIOWrapper(buffer, encoding=encoding, errors=errors or "strict",
                                   write_through=True)


def get_text_stdout(encoding=None, errors=None):
    s = sys.stdout
    if encoding is None:
        return s
    buf = getattr(s, "buffer", None)
    if buf is None:
        return s
    s.flush()
    return wrap_text_stream(buf, encoding, errors)


def get_text_stdin(encoding=None, errors=None):
    s = sys.stdin
    if encoding is None:
        return s
    buf = getattr(s, "buffer", None)
    if buf is None:
        return s
    return wrap_text_stream(buf, encoding, errors)


def get_binary_stdout():
    w = find_binary_writer(sys.stdout)
    if w is None:
        raise RuntimeError("Was not able to determine binary stream for sys.stdout.")
    return w


def get_binary_stdin():
    r = find_binary_reader(sys.stdin)
    if r is None:
        raise RuntimeError("Was not able to determine binary stream for sys.stdin.")
    return r
