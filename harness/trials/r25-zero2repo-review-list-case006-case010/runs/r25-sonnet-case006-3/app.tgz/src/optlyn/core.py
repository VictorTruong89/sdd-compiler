"""Core: Context, Command, Group, Parameter, Option, Argument."""
import enum
import errno
import inspect
import os
import sys
from collections import abc
from contextlib import ExitStack, contextmanager
from functools import update_wrapper
from itertools import repeat

from . import types as _types
from .exceptions import (Abort, BadParameter, DeclarationError, Exit, MissingParameter,
                         NoArgsIsHelpError, OptlynException, UsageError)
from .formatting import HelpFormatter, join_options, make_default_short_help, split_opt
from .globals import get_current_context, pop_context, push_context
from .parser import FLAG_NEEDS_VALUE, OptionParser
from .utils import echo, make_str


class ParameterSource(enum.Enum):
    COMMANDLINE = enum.auto()
    ENVIRONMENT = enum.auto()
    DEFAULT = enum.auto()
    DEFAULT_MAP = enum.auto()
    PROMPT = enum.auto()


_RANK = {ParameterSource.PROMPT: 0, ParameterSource.COMMANDLINE: 1,
         ParameterSource.ENVIRONMENT: 2, ParameterSource.DEFAULT_MAP: 3,
         ParameterSource.DEFAULT: 4}


@contextmanager
def augment_usage_errors(ctx, param=None):
    try:
        yield
    except BadParameter as e:
        if e.ctx is None:
            e.ctx = ctx
        if param is not None and e.param is None:
            e.param = param
        raise
    except UsageError as e:
        if e.ctx is None:
            e.ctx = ctx
        raise


def iter_params_for_processing(invocation_order, declaration_order):
    def sort_key(item):
        try:
            idx = invocation_order.index(item)
        except ValueError:
            idx = float("inf")
        return not item.is_eager, idx
    return sorted(declaration_order, key=sort_key)


def _check_multicommand(base_command, cmd_name, cmd, register=False):
    if not base_command.chain or not isinstance(cmd, Group):
        return
    raise RuntimeError(f"{cmd_name!r} is a group and cannot be attached to chaining group "
                       f"{base_command.name!r}.")


def _detect_program_name():
    path = sys.argv[0] if sys.argv and sys.argv[0] else "python"
    name = os.path.basename(path)
    if name == "__main__.py":
        main = sys.modules.get("__main__")
        pkg = getattr(getattr(main, "__spec__", None), "parent", None)
        if pkg:
            return pkg
        return os.path.basename(os.path.dirname(path)) or name
    return name


class Context:
    formatter_class = HelpFormatter

    def __init__(self, command, parent=None, info_name=None, obj=None, auto_envvar_prefix=None,
                 default_map=None, terminal_width=None, max_content_width=None,
                 resilient_parsing=False, allow_extra_args=None, allow_interspersed_args=None,
                 ignore_unknown_options=None, help_option_names=None, token_normalize_func=None,
                 color=None, show_default=None):
        self.parent = parent
        self.command = command
        self.info_name = info_name
        self.params = {}
        self.args = []
        self.protected_args = []
        self._opt_prefixes = set(parent._opt_prefixes) if parent else set()
        if obj is None and parent is not None:
            obj = parent.obj
        self.obj = obj
        self._meta = getattr(parent, "meta", {})
        if default_map is None and info_name is not None and parent is not None \
                and parent.default_map is not None:
            default_map = parent.default_map.get(info_name)
        self.default_map = default_map
        self.invoked_subcommand = None
        if terminal_width is None and parent is not None:
            terminal_width = parent.terminal_width
        self.terminal_width = terminal_width
        if max_content_width is None and parent is not None:
            max_content_width = parent.max_content_width
        self.max_content_width = max_content_width
        if allow_extra_args is None:
            allow_extra_args = command.allow_extra_args
        self.allow_extra_args = allow_extra_args
        if allow_interspersed_args is None:
            allow_interspersed_args = command.allow_interspersed_args
        self.allow_interspersed_args = allow_interspersed_args
        if ignore_unknown_options is None:
            ignore_unknown_options = command.ignore_unknown_options
        self.ignore_unknown_options = ignore_unknown_options
        if help_option_names is None:
            if parent is not None:
                help_option_names = parent.help_option_names
            else:
                help_option_names = ["--help"]
        self.help_option_names = help_option_names
        if token_normalize_func is None and parent is not None:
            token_normalize_func = parent.token_normalize_func
        self.token_normalize_func = token_normalize_func
        self.resilient_parsing = resilient_parsing
        if auto_envvar_prefix is None:
            if parent is not None and parent.auto_envvar_prefix is not None \
                    and self.info_name is not None:
                auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{self.info_name.upper()}"
        else:
            auto_envvar_prefix = auto_envvar_prefix.upper()
        if auto_envvar_prefix is not None:
            auto_envvar_prefix = auto_envvar_prefix.replace("-", "_")
        self.auto_envvar_prefix = auto_envvar_prefix
        if color is None and parent is not None:
            color = parent.color
        self.color = color
        if show_default is None and parent is not None:
            show_default = parent.show_default
        self.show_default = show_default
        self._close_callbacks = []
        self._depth = 0
        self._parameter_source = {}
        self._ranks = {}
        self._exit_stack = ExitStack()

    @property
    def meta(self):
        return self._meta

    def __enter__(self):
        self._depth += 1
        push_context(self)
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self._depth -= 1
        if self._depth == 0:
            self.close()
        pop_context()

    @contextmanager
    def scope(self, cleanup=True):
        if not cleanup:
            self._depth += 1
        try:
            with self as rv:
                yield rv
        finally:
            if not cleanup:
                self._depth -= 1

    def with_resource(self, context_manager):
        return self._exit_stack.enter_context(context_manager)

    def call_on_close(self, f):
        return self._exit_stack.callback(f)

    def close(self):
        self._exit_stack.close()
        self._exit_stack = ExitStack()

    @property
    def command_path(self):
        rv = ""
        if self.info_name is not None:
            rv = self.info_name
        if self.parent is not None:
            parent_command_path = [self.parent.command_path]
            if isinstance(self.parent.command, Command):
                for param in self.parent.command.get_params(self):
                    parent_command_path.extend(param.get_usage_pieces(self))
            rv = f"{' '.join(parent_command_path)} {rv}"
        return rv.lstrip()

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        rv = self.find_object(object_type)
        if rv is None:
            self.obj = rv = object_type()
        return rv

    def lookup_default(self, name, call=True):
        if self.default_map is not None:
            value = self.default_map.get(name)
            if call and callable(value):
                return value()
            return value
        return None

    def fail(self, message):
        raise UsageError(message, self)

    def abort(self):
        raise Abort()

    def exit(self, code=0):
        raise Exit(code)

    def make_formatter(self):
        return self.formatter_class(width=self.terminal_width, max_width=self.max_content_width)

    def get_usage(self):
        return self.command.get_usage(self)

    def get_help(self):
        return self.command.get_help(self)

    def _make_sub_context(self, command):
        return type(self)(command, info_name=command.name, parent=self)

    def invoke(__self, __callback, *args, **kwargs):
        if isinstance(__callback, Command):
            other_cmd = __callback
            if other_cmd.callback is None:
                raise TypeError("The given command does not have a callback that can be invoked.")
            __callback = other_cmd.callback
            ctx = __self._make_sub_context(other_cmd)
            for param in other_cmd.params:
                if param.name not in kwargs and param.expose_value:
                    kwargs[param.name] = param.type_cast_value(ctx, param.get_default(ctx))
            ctx.params.update(kwargs)
        else:
            ctx = __self
        with augment_usage_errors(__self):
            with ctx:
                return __callback(*args, **kwargs)

    def forward(__self, __cmd, **kwargs):
        if not isinstance(__cmd, Command):
            raise TypeError("Callback is not a command.")
        for param in __self.params:
            if param not in kwargs:
                kwargs[param] = __self.params[param]
        return __self.invoke(__cmd, **kwargs)

    def set_parameter_source(self, name, source):
        self._parameter_source[name] = source

    def get_parameter_source(self, name):
        return self._parameter_source.get(name)


class Command:
    context_class = Context
    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False

    def __init__(self, name=None, context_settings=None, callback=None, params=None, help=None,
                 epilog=None, short_help=None, options_metavar="[OPTIONS]", add_help_option=True,
                 no_args_is_help=False, hidden=False, deprecated=False):
        self.name = name
        if context_settings is None:
            context_settings = {}
        self.context_settings = context_settings
        self.callback = callback
        self.params = params or []
        self.help = help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.short_help = short_help
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated
        self._help_option = None

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"

    def get_usage(self, ctx):
        formatter = ctx.make_formatter()
        self.format_usage(ctx, formatter)
        return formatter.getvalue().rstrip("\n")

    def get_params(self, ctx):
        rv = self.params
        help_option = self.get_help_option(ctx)
        if help_option is not None:
            rv = [*rv, help_option]
        return rv

    def format_usage(self, ctx, formatter):
        pieces = self.collect_usage_pieces(ctx)
        formatter.write_usage(ctx.command_path, " ".join(pieces))

    def collect_usage_pieces(self, ctx):
        rv = [self.options_metavar] if self.options_metavar else []
        for param in self.get_params(ctx):
            rv.extend(param.get_usage_pieces(ctx))
        return rv

    def get_help_option_names(self, ctx):
        all_names = set(ctx.help_option_names)
        for param in self.params:
            all_names.difference_update(param.opts)
            all_names.difference_update(param.secondary_opts)
        return list(all_names)

    def get_help_option(self, ctx):
        help_options = self.get_help_option_names(ctx)
        if not help_options or not self.add_help_option:
            return None
        key = tuple(help_options)
        if self._help_option is None or self._help_option[0] != key:
            ordered = [n for n in ctx.help_option_names if n in help_options]
            opt = Option(ordered, is_flag=True, is_eager=True, expose_value=False,
                         callback=_show_help, help="Show this message and exit.")
            self._help_option = (key, opt)
        return self._help_option[1]

    def make_parser(self, ctx):
        parser = OptionParser(ctx)
        for param in self.get_params(ctx):
            param.add_to_parser(parser, ctx)
        return parser

    def get_help(self, ctx):
        formatter = ctx.make_formatter()
        self.format_help(ctx, formatter)
        return formatter.getvalue().rstrip("\n")

    def get_short_help_str(self, limit=45):
        if self.short_help:
            text = inspect.cleandoc(self.short_help)
        elif self.help:
            text = make_default_short_help(self.help, limit)
        else:
            text = ""
        if self.deprecated:
            text = f"(Deprecated) {text}"
        return text.strip()

    def format_help(self, ctx, formatter):
        self.format_usage(ctx, formatter)
        self.format_help_text(ctx, formatter)
        self.format_options(ctx, formatter)
        self.format_epilog(ctx, formatter)

    def format_help_text(self, ctx, formatter):
        text = inspect.cleandoc(self.help).partition("\f")[0] if self.help is not None else ""
        if self.deprecated:
            text = f"(Deprecated) {text}"
        if text:
            formatter.write_paragraph()
            with formatter.indentation():
                formatter.write_text(text)

    def format_options(self, ctx, formatter):
        args = []
        opts = []
        for param in self.get_params(ctx):
            rv = param.get_help_record(ctx)
            if rv is not None:
                (args if isinstance(param, Argument) else opts).append(rv)
        if args:
            with formatter.section("Positional arguments"):
                formatter.write_dl(args)
        if opts:
            with formatter.section("Options"):
                formatter.write_dl(opts)

    def format_epilog(self, ctx, formatter):
        if self.epilog:
            epilog = inspect.cleandoc(self.epilog)
            formatter.write_paragraph()
            with formatter.indentation():
                formatter.write_text(epilog)

    def make_context(self, info_name, args, parent=None, **extra):
        for key, value in self.context_settings.items():
            if key not in extra:
                extra[key] = value
        ctx = self.context_class(self, info_name=info_name, parent=parent, **extra)
        with ctx.scope(cleanup=False):
            self.parse_args(ctx, args)
        return ctx

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelpError(ctx)
        parser = self.make_parser(ctx)
        opts, args, param_order = parser.parse_args(args=args)
        for param in iter_params_for_processing(param_order, self.get_params(ctx)):
            value, args = param.handle_parse_result(ctx, opts, args)
        if args and not ctx.allow_extra_args and not ctx.resilient_parsing:
            ctx.fail(f"Got unexpected extra argument{'s' if len(args) != 1 else ''} "
                     f"({' '.join(map(make_str, args))})")
        ctx.args = args
        ctx._opt_prefixes.update(parser._opt_prefixes)
        return args

    def invoke(self, ctx):
        if self.deprecated:
            msg = f"DeprecationWarning: The command {self.name!r} is deprecated."
            if isinstance(self.deprecated, str):
                msg = f"{msg} {self.deprecated}"
            from .termui import style
            echo(style(msg, fg="red"), err=True)
        if self.callback is not None:
            return ctx.invoke(self.callback, **ctx.params)

    def shell_complete(self, ctx, incomplete):
        from .shell_completion import CompletionItem
        results = []
        if incomplete and not incomplete[0].isalnum():
            for param in self.get_params(ctx):
                if (not isinstance(param, Option) or param.hidden
                        or (not param.multiple and ctx.get_parameter_source(param.name)
                            is ParameterSource.COMMANDLINE)):
                    continue
                results.extend(CompletionItem(name, help=param.help)
                               for name in [*param.opts, *param.secondary_opts]
                               if name.startswith(incomplete))
        return results

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        if args is None:
            args = sys.argv[1:]
        else:
            args = list(args)
        if prog_name is None:
            prog_name = _detect_program_name()
        self._main_shell_completion(extra, prog_name, complete_var)
        try:
            try:
                with self.make_context(prog_name, args, **extra) as ctx:
                    rv = self.invoke(ctx)
                    if not standalone_mode:
                        return rv
                    ctx.exit()
            except (EOFError, KeyboardInterrupt) as e:
                echo(file=sys.stderr)
                raise Abort() from e
            except OptlynException as e:
                if not standalone_mode:
                    raise
                e.show()
                sys.exit(e.exit_code)
            except OSError as e:
                if e.errno == errno.EPIPE:
                    sys.stdout = open(os.devnull, "w")
                    sys.stderr = open(os.devnull, "w")
                    sys.exit(1)
                raise
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return e.exit_code
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", file=sys.stderr)
            sys.exit(1)

    def _main_shell_completion(self, ctx_args, prog_name, complete_var=None):
        if complete_var is None:
            complete_name = prog_name.replace("-", "_").replace(".", "_")
            complete_var = f"_{complete_name}_COMPLETE".upper()
        instruction = os.environ.get(complete_var)
        if not instruction:
            return
        from .shell_completion import shell_complete
        rv = shell_complete(self, ctx_args, prog_name, complete_var, instruction)
        sys.exit(rv)

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)


def _show_help(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


class Group(Command):
    allow_extra_args = True
    allow_interspersed_args = False

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, **attrs):
        Command.__init__(self, name, **attrs)
        if commands is None:
            commands = {}
        elif isinstance(commands, abc.Sequence):
            commands = {c.name: c for c in commands if c.name is not None}
        self.commands = commands
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.invoke_without_command = invoke_without_command
        if subcommand_metavar is None:
            if chain:
                subcommand_metavar = "COMMAND1 [ARGS]... [COMMAND2 [ARGS]...]..."
                if invoke_without_command:
                    subcommand_metavar = "[COMMAND1 [ARGS]...] [COMMAND2 [ARGS]...]..."
            else:
                subcommand_metavar = "COMMAND [ARGS]..."
                if invoke_without_command:
                    subcommand_metavar = "[COMMAND [ARGS]...]"
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback
        if self.chain:
            for name, cmd in self.commands.items():
                _check_multicommand(self, name, cmd, register=True)

    def add_command(self, cmd, name=None):
        name = name or cmd.name
        if name is None:
            raise TypeError("Command has no name.")
        _check_multicommand(self, name, cmd, register=True)
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as _command
        func = None
        if args and callable(args[0]):
            func = args[0]
            args = args[1:]

        def decorator(f):
            cmd = _command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        if func is not None:
            return decorator(func)
        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as _group
        func = None
        if args and callable(args[0]):
            func = args[0]
            args = args[1:]

        def decorator(f):
            cmd = _group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        if func is not None:
            return decorator(func)
        return decorator

    def result_callback(self, replace=False):
        def decorator(f):
            old_callback = self._result_callback
            if old_callback is None or replace:
                self._result_callback = f
                return f

            def function(__value, *args, **kwargs):
                inner = old_callback(__value, *args, **kwargs)
                return f(inner, *args, **kwargs)

            self._result_callback = rv = update_wrapper(function, f)
            return rv
        return decorator

    def collect_usage_pieces(self, ctx):
        rv = Command.collect_usage_pieces(self, ctx)
        rv.append(self.subcommand_metavar)
        return rv

    def format_options(self, ctx, formatter):
        Command.format_options(self, ctx, formatter)
        self.format_commands(ctx, formatter)

    def format_commands(self, ctx, formatter):
        commands = []
        for subcommand in self.list_commands(ctx):
            cmd = self.get_command(ctx, subcommand)
            if cmd is None or cmd.hidden:
                continue
            commands.append((subcommand, cmd))
        if commands:
            limit = formatter.width - 6 - max(len(cmd[0]) for cmd in commands)
            rows = []
            for subcommand, cmd in commands:
                rows.append((subcommand, cmd.get_short_help_str(limit)))
            if rows:
                with formatter.section("Commands"):
                    formatter.write_dl(rows)

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelpError(ctx)
        rest = Command.parse_args(self, ctx, args)
        if self.chain:
            ctx.protected_args = rest
            ctx.args = []
        elif rest:
            ctx.protected_args, ctx.args = rest[:1], rest[1:]
        return ctx.args

    def invoke(self, ctx):
        def _process_result(value):
            if self._result_callback is not None:
                value = ctx.invoke(self._result_callback, value, **ctx.params)
            return value

        if not ctx.protected_args:
            if self.invoke_without_command:
                with ctx:
                    rv = Command.invoke(self, ctx)
                    return _process_result([] if self.chain else rv)
            ctx.fail("Missing command.")
        args = [*ctx.protected_args, *ctx.args]
        ctx.args = []
        ctx.protected_args = []
        if not self.chain:
            with ctx:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                ctx.invoked_subcommand = cmd_name
                Command.invoke(self, ctx)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx)
                with sub_ctx:
                    return _process_result(sub_ctx.command.invoke(sub_ctx))
        with ctx:
            ctx.invoked_subcommand = "*" if args else None
            Command.invoke(self, ctx)
            contexts = []
            while args:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx, allow_extra_args=True,
                                           allow_interspersed_args=False)
                contexts.append(sub_ctx)
                args, sub_ctx.args = sub_ctx.args, []
            rv = []
            for sub_ctx in contexts:
                with sub_ctx:
                    rv.append(sub_ctx.command.invoke(sub_ctx))
            return _process_result(rv)

    def resolve_command(self, ctx, args):
        cmd_name = make_str(args[0])
        original_cmd_name = cmd_name
        cmd = self.get_command(ctx, cmd_name)
        if cmd is None and ctx.token_normalize_func is not None:
            cmd_name = ctx.token_normalize_func(cmd_name)
            cmd = self.get_command(ctx, cmd_name)
        if cmd is None and not ctx.resilient_parsing:
            if split_opt(cmd_name)[0]:
                self.parse_args(ctx, ctx.args)
            ctx.fail(f"No such command {original_cmd_name!r}.")
        return cmd_name if cmd else None, cmd, args[1:]

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def list_commands(self, ctx):
        return sorted(self.commands)

    def shell_complete(self, ctx, incomplete):
        from .shell_completion import CompletionItem
        results = []
        for name in self.list_commands(ctx):
            if name.startswith(incomplete):
                command = self.get_command(ctx, name)
                if command is not None and not command.hidden:
                    results.append(CompletionItem(name, help=command.get_short_help_str()))
        results.extend(Command.shell_complete(self, ctx, incomplete))
        return results


class CommandCollection(Group):
    def __init__(self, name=None, sources=None, **attrs):
        Group.__init__(self, name, **attrs)
        self.sources = sources or []

    def add_source(self, group):
        self.sources.append(group)

    def get_command(self, ctx, cmd_name):
        rv = Group.get_command(self, ctx, cmd_name)
        if rv is not None:
            return rv
        for source in self.sources:
            rv = source.get_command(ctx, cmd_name)
            if rv is not None:
                if self.chain:
                    _check_multicommand(self, cmd_name, rv)
                return rv
        return None

    def list_commands(self, ctx):
        rv = set(Group.list_commands(self, ctx))
        for source in self.sources:
            rv.update(source.list_commands(ctx))
        return sorted(rv)


def _check_iter(value):
    if isinstance(value, (str, bytes)):
        raise TypeError("not an iterable sequence")
    return iter(value)


def batch(iterable, batch_size):
    return list(zip(*repeat(iter(iterable), batch_size)))


class Parameter:
    param_type_name = "parameter"

    def __init__(self, param_decls=None, type=None, required=False, default=None, callback=None,
                 nargs=None, multiple=False, metavar=None, expose_value=True, is_eager=False,
                 envvar=None, shell_complete=None):
        self.name, self.opts, self.secondary_opts = self._parse_decls(param_decls or (), expose_value)
        self.type = _types.convert_type(type, default)
        if nargs is None:
            nargs = self.type.arity if self.type.is_composite else 1
        self.required = required
        self.callback = callback
        self.nargs = nargs
        self.multiple = multiple
        self.expose_value = expose_value
        self.default = default
        self.is_eager = is_eager
        self.metavar = metavar
        self.envvar = envvar
        self._custom_shell_complete = shell_complete
        if self.type.is_composite and nargs != self.type.arity:
            raise DeclarationError(
                f"'nargs' must be {self.type.arity} (or None) for type {self.type!r}, but it was {nargs}.")

    @property
    def human_readable_name(self):
        return self.name

    def _parse_decls(self, decls, expose_value):
        raise NotImplementedError

    def make_metavar(self):
        if self.metavar is not None:
            return self.metavar
        metavar = self.type.get_metavar(self)
        if metavar is None:
            metavar = self.type.name.upper()
        if self.nargs != 1:
            metavar += "..."
        return metavar

    def get_default(self, ctx, call=True):
        value = self.default
        if call and callable(value):
            value = value()
        return value

    def add_to_parser(self, parser, ctx):
        raise NotImplementedError

    def get_usage_pieces(self, ctx):
        return []

    def get_help_record(self, ctx):
        return None

    def get_error_hint(self, ctx):
        hint_list = self.opts or [self.human_readable_name]
        return " / ".join(f"'{x}'" for x in hint_list)

    def type_cast_value(self, ctx, value):
        if value is None:
            return () if self.multiple or self.nargs == -1 else None

        def check_iter(v):
            try:
                return _check_iter(v)
            except TypeError:
                raise BadParameter("Value must be an iterable sequence (list or tuple), "
                                   "not a plain string.", ctx=ctx, param=self) from None

        if self.nargs == 1 or self.type.is_composite:
            def convert(v):
                return self.type(v, param=self, ctx=ctx)
        elif self.nargs == -1:
            def convert(v):
                return tuple(self.type(x, self, ctx) for x in check_iter(v))
        else:
            def convert(v):
                v = tuple(check_iter(v))
                if len(v) != self.nargs:
                    raise BadParameter(f"Takes {self.nargs} values but {len(v)} given.",
                                       ctx=ctx, param=self)
                return tuple(self.type(x, self, ctx) for x in v)

        if self.multiple:
            return tuple(convert(x) for x in check_iter(value))
        return convert(value)

    def value_is_missing(self, value):
        if value is None:
            return True
        if (self.nargs != 1 or self.multiple) and value == ():
            return True
        return False

    def process_value(self, ctx, value):
        value = self.type_cast_value(ctx, value)
        if self.required and self.value_is_missing(value):
            raise MissingParameter(ctx=ctx, param=self)
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value

    def resolve_envvar_value(self, ctx):
        if not self.envvar:
            return None
        if isinstance(self.envvar, str):
            rv = os.environ.get(self.envvar)
            if rv:
                return rv
        else:
            for envvar in self.envvar:
                rv = os.environ.get(envvar)
                if rv:
                    return rv
        return None

    def value_from_envvar(self, ctx):
        rv = self.resolve_envvar_value(ctx)
        if rv is not None and self.nargs != 1:
            rv = self.type.split_envvar_value(rv)
        return rv

    def consume_value(self, ctx, opts):
        value = opts.get(self.name)
        source = ParameterSource.COMMANDLINE
        if value is None:
            value = self.value_from_envvar(ctx)
            source = ParameterSource.ENVIRONMENT
        if value is None:
            value = ctx.lookup_default(self.name)
            source = ParameterSource.DEFAULT_MAP
            if isinstance(value, str) and self.nargs != 1:
                value = self.type.split_envvar_value(value)
        if value is None:
            value = self.get_default(ctx)
            source = ParameterSource.DEFAULT
        return value, source

    def _rank(self, source):
        r = _RANK[source]
        if source is ParameterSource.DEFAULT:
            return (r, 0 if getattr(self, "_explicit_default", self.default is not None) else 1)
        return (r, 0)

    def handle_parse_result(self, ctx, opts, args):
        with augment_usage_errors(ctx, param=self):
            value, source = self.consume_value(ctx, opts)
            try:
                value = self.process_value_with_source(ctx, value, source)
            except Exception:
                if not ctx.resilient_parsing:
                    raise
                value = None
        if self.name is not None:
            rank = self._rank(self._last_source)
            prev = ctx._ranks.get(self.name)
            if prev is None or rank <= prev:
                ctx._ranks[self.name] = rank
                ctx.set_parameter_source(self.name, self._last_source)
                if self.expose_value:
                    ctx.params[self.name] = value
        return value, args

    def process_value_with_source(self, ctx, value, source):
        self._last_source = source
        return self.process_value(ctx, value)

    def shell_complete(self, ctx, incomplete):
        if self._custom_shell_complete is not None:
            from .shell_completion import CompletionItem
            results = self._custom_shell_complete(ctx, self, incomplete)
            if results and isinstance(results[0], str):
                results = [CompletionItem(c) for c in results]
            return results
        return self.type.shell_complete(ctx, self, incomplete)


class Option(Parameter):
    param_type_name = "option"

    def __init__(self, param_decls=None, show_default=None, prompt=False, confirmation_prompt=False,
                 prompt_required=True, hide_input=False, is_flag=None, flag_value=None,
                 multiple=False, count=False, allow_from_autoenv=True, type=None, help=None,
                 hidden=False, show_choices=True, show_envvar=False, deprecated=False, **attrs):
        if help:
            help = inspect.cleandoc(help)
        default_is_missing = "default" not in attrs
        self._explicit_default = attrs.get("default") is not None
        Parameter.__init__(self, param_decls, type=type, multiple=multiple, **attrs)
        if prompt is True:
            if self.name is None:
                raise TypeError("'name' is required with 'prompt=True'.")
            prompt_text = self.name.replace("_", " ").capitalize()
        elif prompt is False:
            prompt_text = None
        else:
            prompt_text = prompt
        self.prompt = prompt_text
        self.confirmation_prompt = confirmation_prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.hidden = hidden
        self.deprecated = deprecated
        self._flag_needs_value = self.prompt is not None and not self.prompt_required
        if is_flag is None:
            if flag_value is not None:
                is_flag = True
            elif self._flag_needs_value:
                is_flag = False
            else:
                is_flag = bool(self.secondary_opts)
        elif is_flag is False and not self._flag_needs_value:
            self._flag_needs_value = flag_value is not None
        if is_flag and default_is_missing and not self.required:
            if multiple:
                self.default = ()
            else:
                self.default = False
        if flag_value is None:
            flag_value = not self.default
        if is_flag and type is None:
            self.type = _types.convert_type(None, flag_value)
        self.is_flag = is_flag
        self.is_bool_flag = is_flag and isinstance(self.type, _types.BoolParamType)
        self.flag_value = flag_value
        self.count = count
        if count:
            if type is None:
                self.type = _types.IntRange(min=0)
            if default_is_missing:
                self.default = 0
        self.allow_from_autoenv = allow_from_autoenv
        self.help = help
        self.show_default = show_default
        self.show_choices = show_choices
        self.show_envvar = show_envvar
        if self.nargs < 1:
            raise DeclarationError("'nargs' must be a positive integer for options.")
        if self.prompt and self.is_flag and not self.is_bool_flag:
            raise DeclarationError("'prompt' is not valid for non-boolean flag.")
        if not self.is_bool_flag and self.secondary_opts:
            raise DeclarationError("Secondary flag is not valid for non-boolean flag.")
        if self.is_bool_flag and self.hide_input and self.prompt is not None:
            raise DeclarationError("'prompt' with 'hide_input' is not valid for boolean flag.")
        if self.count:
            if self.multiple:
                raise DeclarationError("'count' is not valid with 'multiple'.")
            if self.is_flag:
                raise DeclarationError("'count' is not valid with 'is_flag'.")
        if self.deprecated:
            if self.required:
                raise DeclarationError("A deprecated option cannot be required.")
            if self.prompt:
                raise DeclarationError("A deprecated option cannot use a prompt.")

    def _parse_decls(self, decls, expose_value):
        opts = []
        secondary_opts = []
        name = None
        possible_names = []
        for decl in decls:
            if decl.isidentifier():
                if name is not None:
                    raise TypeError(f"Name '{name}' defined twice")
                name = decl
            else:
                split_char = ";" if decl[:1] == "/" else "/"
                if split_char in decl:
                    first, second = decl.split(split_char, 1)
                    first = first.rstrip()
                    if first:
                        possible_names.append(split_opt(first))
                        opts.append(first)
                    second = second.lstrip()
                    if second:
                        secondary_opts.append(second.lstrip())
                    if first == second:
                        raise ValueError(
                            f"Boolean option {decl!r} cannot use the same flag for true/false.")
                else:
                    possible_names.append(split_opt(decl))
                    opts.append(decl)
        if name is None and possible_names:
            possible_names.sort(key=lambda x: -len(x[0]))
            name = possible_names[0][1].replace("-", "_").lower()
            if not name.isidentifier():
                name = None
        if name is None:
            if not expose_value:
                return None, opts, secondary_opts
            raise TypeError("Could not determine name for option")
        if not opts and not secondary_opts:
            raise TypeError(f"No options defined but a name was passed ({name}).")
        return name, opts, secondary_opts

    def add_to_parser(self, parser, ctx):
        if self.multiple:
            action = "append"
        elif self.count:
            action = "count"
        else:
            action = "store"
        if self.is_flag:
            action = f"{action}_const"
            if self.is_bool_flag and self.secondary_opts:
                parser.add_option(obj=self, opts=self.opts, dest=self.name, action=action, const=True)
                parser.add_option(obj=self, opts=self.secondary_opts, dest=self.name,
                                  action=action, const=False)
            else:
                parser.add_option(obj=self, opts=self.opts, dest=self.name, action=action,
                                  const=self.flag_value)
        else:
            parser.add_option(obj=self, opts=self.opts, dest=self.name, action=action,
                              nargs=self.nargs)

    def get_error_hint(self, ctx):
        names = [*self.opts, *self.secondary_opts]
        return " / ".join(f"'{x}'" for x in (names or [self.human_readable_name]))

    def get_help_record(self, ctx):
        if self.hidden:
            return None
        any_prefix_is_slash = False

        def write_opts(opts):
            nonlocal any_prefix_is_slash
            rv, any_slashes = join_options(opts)
            if any_slashes:
                any_prefix_is_slash = True
            if not self.is_flag and not self.count:
                rv += f" {self.make_metavar()}"
            return rv

        rv = [write_opts(self.opts)]
        if self.secondary_opts:
            rv.append(write_opts(self.secondary_opts))
        help = self.help or ""
        if self.deprecated:
            note = f": {self.deprecated}" if isinstance(self.deprecated, str) else ""
            help = f"(DEPRECATED{note}) {help}".rstrip()
        extra = []
        if self.show_envvar:
            envvar = self.envvar
            if envvar is None:
                if (self.allow_from_autoenv and ctx.auto_envvar_prefix is not None
                        and self.name is not None):
                    envvar = f"{ctx.auto_envvar_prefix}_{self.name.upper()}"
            if envvar is not None:
                var_str = envvar if isinstance(envvar, str) else ", ".join(str(d) for d in envvar)
                extra.append(f"env var: {var_str}")
        default_value = ctx.lookup_default(self.name, call=False)
        if default_value is None:
            default_value = self.get_default(ctx, call=False)
        show_default = False
        show_default_is_str = False
        if self.show_default is not None:
            if isinstance(self.show_default, str):
                show_default_is_str = show_default = True
            else:
                show_default = self.show_default
        elif ctx.show_default is not None:
            show_default = ctx.show_default
        if show_default_is_str or (show_default and default_value is not None):
            if show_default_is_str:
                default_string = f"({self.show_default})"
            elif isinstance(default_value, (list, tuple)):
                default_string = ", ".join(str(d) for d in default_value)
            elif inspect.isfunction(default_value):
                default_string = "(dynamic)"
            elif self.is_bool_flag and self.secondary_opts:
                default_string = split_opt((self.opts if default_value else self.secondary_opts)[0])[1]
            elif self.is_bool_flag and not self.secondary_opts and not default_value:
                default_string = ""
            else:
                default_string = str(default_value)
            if default_string:
                extra.append(f"default: {default_string}")
        if not self.count and isinstance(self.type, (_types.IntRange, _types.FloatRange)) and \
                (self.type.min is not None or self.type.max is not None):
            extra.append(self.type._describe())
        if self.required:
            extra.append("required")
        if extra:
            extra_str = "; ".join(extra)
            help = f"{help}  [{extra_str}]" if help else f"[{extra_str}]"
        return ("; " if any_prefix_is_slash else " / ").join(rv), help

    def get_default(self, ctx, call=True):
        if self.is_flag and not self.is_bool_flag:
            for param in ctx.command.params:
                if param.name == self.name and param.default:
                    return param.flag_value
            return None
        return Parameter.get_default(self, ctx, call=call)

    def prompt_for_value(self, ctx):
        from .termui import confirm, prompt
        default = ctx.lookup_default(self.name)
        if default is None:
            default = self.get_default(ctx)
        if self.is_bool_flag:
            return confirm(self.prompt, default)
        return prompt(self.prompt, default=default, type=self.type, hide_input=self.hide_input,
                      show_choices=self.show_choices, confirmation_prompt=self.confirmation_prompt,
                      value_proc=lambda x: self.process_value(ctx, x))

    def resolve_envvar_value(self, ctx):
        rv = Parameter.resolve_envvar_value(self, ctx)
        if rv is not None:
            return rv
        if self.allow_from_autoenv and ctx.auto_envvar_prefix is not None and self.name is not None:
            envvar = f"{ctx.auto_envvar_prefix}_{self.name.upper()}"
            rv = os.environ.get(envvar)
            if rv:
                return rv
        return None

    def value_from_envvar(self, ctx):
        rv = self.resolve_envvar_value(ctx)
        if rv is None:
            return None
        if self.is_flag and not self.count:
            if self.is_bool_flag:
                if rv.strip() == "":
                    return False
                return _types.BOOL.convert(rv, self, ctx)
            if rv == str(self.flag_value):
                return self.flag_value
            norm = rv.strip().lower()
            if norm in {"1", "true", "t", "yes", "y", "on"}:
                return self.flag_value
            return None
        value_depth = (self.nargs != 1) + bool(self.multiple)
        if value_depth > 0:
            rv = self.type.split_envvar_value(rv)
            if self.multiple and self.nargs != 1:
                rv = batch(rv, self.nargs)
        return rv

    def consume_value(self, ctx, opts):
        value, source = Parameter.consume_value(self, ctx, opts)
        if value is FLAG_NEEDS_VALUE:
            if self.prompt is not None and not ctx.resilient_parsing:
                value = self.prompt_for_value(ctx)
                source = ParameterSource.PROMPT
            else:
                value = self.flag_value
                source = ParameterSource.COMMANDLINE
        elif self.multiple and value is not None and not isinstance(value, str) \
                and any(v is FLAG_NEEDS_VALUE for v in value):
            value = [self.flag_value if v is FLAG_NEEDS_VALUE else v for v in value]
            source = ParameterSource.COMMANDLINE
        elif (source in {None, ParameterSource.DEFAULT, ParameterSource.DEFAULT_MAP}
              and self.prompt is not None and (self.required or self.prompt_required)
              and not ctx.resilient_parsing):
            value = self.prompt_for_value(ctx)
            source = ParameterSource.PROMPT
        return value, source

    def process_value_with_source(self, ctx, value, source):
        self._last_source = source
        if self.deprecated and value is not None and source not in (
                ParameterSource.DEFAULT, ParameterSource.DEFAULT_MAP):
            from .termui import style
            msg = f"DeprecationWarning: The option {self.get_error_hint(ctx)} is deprecated."
            if isinstance(self.deprecated, str):
                msg = f"{msg} {self.deprecated}"
            echo(style(msg, fg="red"), err=True)
        return self.process_value(ctx, value)


class Argument(Parameter):
    param_type_name = "argument"

    def __init__(self, param_decls=None, required=None, deprecated=False, help=None, **attrs):
        if required is None:
            if attrs.get("default") is not None:
                required = False
            else:
                required = attrs.get("nargs", 1) > 0
        Parameter.__init__(self, param_decls, required=required, **attrs)
        if self.default is not None and self.nargs == -1:
            raise DeclarationError("'default' is not supported for nargs=-1.")
        self.deprecated = deprecated
        self.help = inspect.cleandoc(help) if help else None
        if self.deprecated and self.required:
            raise DeclarationError("A deprecated argument cannot be required.")

    @property
    def human_readable_name(self):
        return self.name.upper()

    def make_metavar(self):
        if self.metavar is not None:
            return self.metavar
        var = self.type.get_metavar(self)
        if not var:
            var = self.name.upper()
        if not self.required:
            var = f"[{var}]"
        if self.nargs != 1:
            var += "..."
        return var

    def _parse_decls(self, decls, expose_value):
        if not decls:
            if not expose_value:
                return None, [], []
            raise TypeError("Could not determine name for argument")
        if len(decls) == 1:
            name = arg = decls[0]
            name = name.replace("-", "_").lower()
        else:
            raise TypeError(f"Arguments take exactly one parameter declaration, got {len(decls)}.")
        return name, [arg], []

    def get_usage_pieces(self, ctx):
        return [self.make_metavar()]

    def get_error_hint(self, ctx):
        return f"'{self.human_readable_name}'"

    def get_help_record(self, ctx):
        if not self.help:
            return None
        return self.make_metavar(), self.help

    def add_to_parser(self, parser, ctx):
        parser.add_argument(dest=self.name, nargs=self.nargs, obj=self)

    def process_value_with_source(self, ctx, value, source):
        self._last_source = source
        if self.deprecated and value not in (None, ()) and source not in (
                ParameterSource.DEFAULT, ParameterSource.DEFAULT_MAP):
            from .termui import style
            msg = f"DeprecationWarning: The argument {self.get_error_hint(ctx)} is deprecated."
            if isinstance(self.deprecated, str):
                msg = f"{msg} {self.deprecated}"
            echo(style(msg, fg="red"), err=True)
        return self.process_value(ctx, value)
