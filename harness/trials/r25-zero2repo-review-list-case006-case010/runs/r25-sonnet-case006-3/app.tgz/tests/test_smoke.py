import optlyn as o
from optlyn.testing import CliRunner


def test_hello():
    @o.command()
    @o.option("--n", type=int, default=2)
    def hello(n):
        o.echo(f"n={n}")

    res = CliRunner().invoke(hello, ["--n", "5"])
    assert res.exit_code == 0 and res.output == "n=5\n"
    assert CliRunner().invoke(hello, ["--n", "x"]).exit_code == 2
