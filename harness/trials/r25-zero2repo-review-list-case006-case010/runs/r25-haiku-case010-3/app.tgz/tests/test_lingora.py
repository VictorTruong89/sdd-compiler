"""Behavioural checks for LINGORA, one group per feature point."""

import io
import json
import os
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from lingora import data  # noqa: E402
from lingora.chunk import RegexpParser  # noqa: E402
from lingora.classify import DecisionTreeClassifier, NaiveBayesClassifier, accuracy  # noqa: E402
from lingora.cli import cli  # noqa: E402
from lingora.grammar import CFG  # noqa: E402
from lingora.metrics import (accuracy as metric_accuracy, edit_distance,  # noqa: E402
                             f_measure, jaccard_distance, precision, recall)
from lingora.parse import ChartParser, ShiftReduceParser  # noqa: E402
from lingora.parse.generate import generate  # noqa: E402
from lingora.stem import LancasterStemmer, PorterStemmer, RegexpStemmer, SnowballStemmer  # noqa: E402
from lingora.tag import DefaultTagger, RegexpTagger, UnigramTagger, pos_tag  # noqa: E402
from lingora.tokenize import (RegexpTokenizer, TreebankWordTokenizer,  # noqa: E402
                              TweetTokenizer, WhitespaceTokenizer, WordPunctTokenizer,
                              blankline_tokenize, sent_tokenize, word_tokenize)
from lingora.translate import bleu  # noqa: E402
from lingora.tree import Tree  # noqa: E402


@pytest.fixture
def punkt_root(tmp_path):
    base = tmp_path / "tokenizers" / "punkt_tab" / "english"
    base.mkdir(parents=True)
    (base / "abbrev_types.txt").write_text("dr\nmr\netc\n")
    (base / "sent_starters.txt").write_text("the\nit\n")
    (base / "collocations.tab").write_text("")
    (base / "ortho_context.tab").write_text("the\t2\nit\t2\nsmith\t32\n")
    saved = list(data.path)
    data.path[:] = [str(tmp_path)]
    yield tmp_path
    data.path[:] = saved


# FP-01 ---------------------------------------------------------------------

def test_wordpunct_and_spans():
    text = "Hi, there  you"
    assert WordPunctTokenizer().tokenize(text) == ["Hi", ",", "there", "you"]
    spans = WordPunctTokenizer().span_tokenize(text)
    assert [text[s:e] for s, e in spans] == ["Hi", ",", "there", "you"]
    assert WordPunctTokenizer().tokenize("") == []
    assert WordPunctTokenizer().tokenize("   ") == []


def test_treebank_conventions():
    tokens = TreebankWordTokenizer().tokenize('"Hi" he can\'t go; dogs\' bone')
    assert tokens[:2] == ["``", "Hi"]
    assert "''" in tokens and "n't" in tokens and "ca" in tokens
    assert TreebankWordTokenizer().tokenize("gonna") == ["gon", "na"]
    assert TreebankWordTokenizer().tokenize("1,000") == ["1,000"]


def test_whitespace_blankline_regexp():
    assert WhitespaceTokenizer().tokenize(" a\tb\n") == ["a", "b"]
    assert blankline_tokenize("a\nb\n\n  c\n") == ["a\nb", "c"]
    assert RegexpTokenizer(r"\w+").tokenize("a-b c") == ["a", "b", "c"]
    assert RegexpTokenizer(r",", gaps=True).tokenize("a,,b") == ["a", "b"]


def test_tweet_tokenizer_defaults_and_options():
    assert TweetTokenizer().tokenize("ABC :D") == ["ABC", ":D"]
    assert TweetTokenizer(preserve_case=False).tokenize("ABC :D") == ["abc", ":D"]
    assert TweetTokenizer(strip_handles=True).tokenize("@bob hi") == ["hi"]


def test_word_tokenize_needs_punkt_only_for_splitting(punkt_root):
    assert word_tokenize("Hi there.", preserve_line=True) == ["Hi", "there", "."]
    assert word_tokenize("cannot", preserve_line=True) == ["cannot"]


def test_sent_tokenize_with_model(punkt_root):
    got = sent_tokenize("Hello there. The cat sat. Dr. Smith went home. Yes.  ")
    assert got == ["Hello there.", "The cat sat.", "Dr. Smith went home.", "Yes."]


def test_sent_tokenize_without_model_fails():
    data.path[:] = []
    with pytest.raises(LookupError):
        sent_tokenize("Hello there.")
    with pytest.raises(LookupError):
        word_tokenize("Hello there.")


def test_cli_tokenize(punkt_root, monkeypatch, capsys):
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hello world. Bye.\n"))
    assert cli.main(args=["tokenize"], standalone_mode=False) == 0
    assert capsys.readouterr().out == "Hello world . Bye .\n"


def test_cli_tokenize_fails_without_model(monkeypatch, capsys):
    data.path[:] = []
    monkeypatch.setattr(sys, "stdin", io.StringIO("Hello.\n"))
    assert cli.main(args=["tokenize"], standalone_mode=False) != 0
    assert capsys.readouterr().out == ""


# FP-02 ---------------------------------------------------------------------

def test_porter_defaults_and_extensions():
    p = PorterStemmer()
    assert p.stem("Running") == "run"
    assert p.stem("ties") == "tie"
    assert PorterStemmer(mode="original").stem("ties") == "ti"
    assert p.stem("ab") == "ab"


def test_lancaster_and_regexp():
    assert LancasterStemmer().stem("maximum") == "maxim"
    assert RegexpStemmer("ing$").stem("runing") == "run"


def test_snowball_english_and_refusals(punkt_root):
    s = SnowballStemmer("english")
    assert s.stem("generously") == "generous"
    assert s.stem("communism") == "communism"
    with pytest.raises(ValueError, match="klingon"):
        SnowballStemmer("klingon")
    data.path[:] = []
    with pytest.raises(LookupError):
        SnowballStemmer("english", ignore_stopwords=True)


# FP-03 ---------------------------------------------------------------------

def test_sequential_taggers():
    train = [[("the", "DT"), ("dog", "NN")], [("the", "DT"), ("cat", "NN")]]
    tagger = UnigramTagger(train=train, backoff=DefaultTagger("X"))
    assert tagger.tag(["the", "dog", "zebra"]) == [("the", "DT"), ("dog", "NN"), ("zebra", "X")]
    assert RegexpTagger([(r"\d+$", "CD")]).tag(["3", "x"]) == [("3", "CD"), ("x", None)]
    assert DefaultTagger("N").tag([]) == []


def test_pos_tag_refusals():
    data.path[:] = []
    with pytest.raises(TypeError):
        pos_tag("a b")
    with pytest.raises(ValueError):
        pos_tag(["a"], lang="fr")
    with pytest.raises(LookupError):
        pos_tag(["a"])


# FP-04 ---------------------------------------------------------------------

TAGGED = [("the", "DT"), ("big", "JJ"), ("dog", "NN"), ("barks", "VBZ")]


def test_chunk_rule_and_empty():
    tree = RegexpParser("NP: {<DT>?<JJ>*<NN>}").parse(TAGGED)
    assert tree.label() == "S"
    assert tree[0].label() == "NP" and len(tree[0]) == 3
    assert tree[1] == ("barks", "VBZ")
    assert RegexpParser("NP: {<DT>}").parse([]) == Tree("S", [])


def test_chink_and_cascade():
    tree = RegexpParser("NP: {<.*>+}\n}<VBZ>{").parse(TAGGED)
    assert [c.label() for c in tree if isinstance(c, Tree)] == ["NP"]
    assert ("barks", "VBZ") in list(tree)
    # A cascading clause sees the earlier chunk as one unit.
    cascade = RegexpParser("NP: {<DT><JJ>?<NN>}\nVP: {<NP><VBZ>}").parse(TAGGED)
    assert [c.label() for c in cascade if isinstance(c, Tree)] == ["VP"]
    with pytest.raises(TypeError):
        RegexpParser(42)


# FP-05 ---------------------------------------------------------------------

GRAMMAR = """
S -> NP VP
NP -> Det N | NP PP | 'I'
VP -> V NP | VP PP
PP -> P NP
Det -> 'the' | 'a'
N -> 'man' | 'telescope' | 'park'
V -> 'saw' | 'ate'
P -> 'in' | 'with'
"""


def test_chart_and_shift_reduce():
    g = CFG.fromstring(GRAMMAR)
    assert g.start() == "S"
    trees = list(ChartParser(g).parse("I saw the man with the telescope".split()))
    assert len(trees) == 2
    assert all(t.label() == "S" and t.leaves() == "I saw the man with the telescope".split()
               for t in trees)
    assert list(ChartParser(g).parse("the man".split())) == []
    assert list(ShiftReduceParser(g).parse("the man saw the park".split()))
    with pytest.raises(ValueError):
        list(ChartParser(g).parse(["zebra"]))


def test_generator_bounds():
    g = CFG.fromstring(GRAMMAR)
    assert len(list(generate(g, n=3))) == 3
    assert list(generate(CFG.fromstring("S -> 'a' 'b'"))) == [["a", "b"]]


def test_tree_behaviour():
    t = Tree.fromstring("(S (NP the dog) (VP barks))")
    assert t == Tree("S", [Tree("NP", ["the", "dog"]), Tree("VP", ["barks"])])
    assert t.leaves() == ["the", "dog", "barks"]
    with pytest.raises(TypeError):
        Tree("S", "x")
    assert len(Tree("S", [])) == 0


# FP-06 / FP-07 -------------------------------------------------------------

DATA = [({"w": "good"}, "pos"), ({"w": "great"}, "pos"), ({"w": "bad"}, "neg"), ({"w": "awful"}, "neg")]


def test_classifiers():
    nb = NaiveBayesClassifier.train(DATA)
    assert accuracy(nb, DATA) == 1.0
    dist = nb.prob_classify({"w": "bad"})
    assert abs(sum(dist.prob(s) for s in dist.samples()) - 1.0) < 1e-9
    dt = DecisionTreeClassifier.train(DATA)
    assert [dt.classify(f) for f, _ in DATA] == [lab for _, lab in DATA]
    assert dt.classify({"q": 1}) in {"pos", "neg"}
    with pytest.raises(ValueError):
        accuracy(nb, [])


def test_metrics():
    assert edit_distance("kitten", "sitting") == 3
    assert edit_distance("ca", "abc", transpositions=True) == 2
    assert edit_distance("ca", "abc") == 3
    assert edit_distance("", "") == 0
    assert jaccard_distance({1, 2}, {2, 3}) == pytest.approx(2 / 3)
    assert precision({1, 2}, {2, 3}) == 0.5
    assert precision({1}, set()) is None
    assert recall(set(), {1}) is None
    assert f_measure({1}, {2}) is None
    with pytest.raises(TypeError):
        precision([1], {1})
    with pytest.raises(ValueError):
        metric_accuracy([1, 2], [1])


def test_bleu():
    ref = [["the", "cat", "sat", "on", "the", "mat"]]
    assert bleu(ref, ["the", "cat", "sat", "on", "the", "mat"]) == pytest.approx(1.0)
    assert bleu(ref, ["the", "cat", "is", "on", "the", "mat"]) == 0.0
    assert bleu(ref, ["the", "cat", "is", "on", "the", "mat"], weights=(0.5, 0.5)) > 0
