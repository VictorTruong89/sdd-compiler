"""Stemmers (FP-02): Porter (three modes), Lancaster (Paice/Husk), Snowball
(English Porter2 and the original Porter variant), regular-expression
stemmer, and placeholders for the other families that are outside the
specified behaviour."""

import os
import re

from lingora import data

__all__ = [
    "ARLSTem",
    "ARLSTem2",
    "LancasterStemmer",
    "PorterStemmer",
    "RegexpStemmer",
    "SnowballStemmer",
    "WordNetLemmatizer",
]

VOWELS = "aeiou"


# ---------------------------------------------------------------------------
# Porter stemmer
# ---------------------------------------------------------------------------

# A small table of irregular forms (their entries are not part of the
# specification; these are the usual English irregulars).
_PORTER_IRREGULAR = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie",
    "tying": "tie", "idly": "idl", "gently": "gentl", "ugly": "ugli",
    "early": "earli", "only": "onli", "singly": "singl", "sky": "sky",
    "news": "news", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos",
    "bias": "bias", "andes": "andes",
}

_STEP2_BASE = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("alli", "al"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_STEP3 = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""),
]
_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
    "ment", "ent", "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]


def _is_cons(w, i):
    c = w[i]
    if c in VOWELS:
        return False
    if c == "y":
        return True if i == 0 else not _is_cons(w, i - 1)
    return True


def _measure(stem):
    n = len(stem)
    i = 0
    while i < n and _is_cons(stem, i):
        i += 1
    m = 0
    while i < n:
        while i < n and not _is_cons(stem, i):
            i += 1
        if i >= n:
            break
        m += 1
        while i < n and _is_cons(stem, i):
            i += 1
    return m


def _has_vowel(stem):
    return any(not _is_cons(stem, i) for i in range(len(stem)))


def _double_cons(w):
    return len(w) >= 2 and w[-1] == w[-2] and _is_cons(w, len(w) - 1)


def _cvc(w, extended):
    """*o: stem ends consonant-vowel-consonant, final consonant not w, x, y.
    With ``extended``, a two-letter stem vowel-consonant also qualifies."""
    if len(w) == 2 and extended:
        return (not _is_cons(w, 0)) and _is_cons(w, 1) and w[1] not in "wxy"
    if len(w) < 3:
        return False
    return (_is_cons(w, len(w) - 3) and not _is_cons(w, len(w) - 2)
            and _is_cons(w, len(w) - 1) and w[-1] not in "wxy")


class PorterStemmer:
    """Porter's algorithm.  ``mode`` is ``'lingora'`` (default, the LINGORA
    extensions), ``'martin'`` (Martin Porter's bli/logi extensions) or
    ``'original'`` (the 1980 published algorithm)."""

    MODES = ("lingora", "martin", "original")

    def __init__(self, mode="lingora"):
        if mode not in self.MODES:
            raise ValueError("unknown Porter mode %r" % (mode,))
        self.mode = mode
        self._ext = mode == "lingora"

    def stem(self, word, to_lowercase=True):
        if not isinstance(word, str):
            raise TypeError("stem expects a str")
        w = word.lower() if to_lowercase else word
        if self._ext:
            if w in _PORTER_IRREGULAR:
                return _PORTER_IRREGULAR[w]
            if len(w) <= 2:
                return w
        elif len(w) <= 2:
            return w
        w = self._step1a(w)
        skip_1b = False
        if self._ext and w.endswith("ied"):
            w = w[:-3] + ("ie" if len(w) == 4 else "i")
            skip_1b = True
        if not skip_1b:
            w = self._step1b(w)
        w = self._step1c(w)
        w = self._step2(w)
        w = self._step3(w)
        w = self._step4(w)
        w = self._step5(w)
        return w

    def _step1a(self, w):
        if w.endswith("sses"):
            return w[:-2]
        if w.endswith("ies"):
            if self._ext and len(w) == 4:
                return w[:-1]
            return w[:-2]
        if w.endswith("ss"):
            return w
        if w.endswith("s"):
            return w[:-1]
        return w

    def _step1b(self, w):
        if w.endswith("eed"):
            if _measure(w[:-3]) > 0:
                return w[:-1]
            return w
        for suffix in ("ed", "ing"):
            if w.endswith(suffix) and _has_vowel(w[:-len(suffix)]):
                stem = w[:-len(suffix)]
                if stem.endswith(("at", "bl", "iz")):
                    return stem + "e"
                if _double_cons(stem) and stem[-1] not in "lsz":
                    return stem[:-1]
                if _measure(stem) == 1 and _cvc(stem, self._ext):
                    return stem + "e"
                return stem
        return w

    def _step1c(self, w):
        if w.endswith("y"):
            if self._ext:
                if len(w) >= 3 and _is_cons(w, len(w) - 2):
                    return w[:-1] + "i"
            elif _has_vowel(w[:-1]):
                return w[:-1] + "i"
        return w

    def _step2_table(self):
        table = list(_STEP2_BASE)
        if self.mode == "original":
            table.insert(5, ("abli", "able"))
        elif self.mode == "martin":
            table.insert(5, ("bli", "ble"))
            table.append(("logi", "log"))
        else:
            table.insert(5, ("bli", "ble"))
            table.append(("fulli", "ful"))
            table.append(("logi", "log"))
        return table

    def _step2(self, w):
        table = self._step2_table()
        if self.mode == "lingora" and w.endswith("alli"):
            if _measure(w[:-4]) > 0:
                return self._step2(w[:-4] + "al")
        for suffix, repl in table:
            if w.endswith(suffix):
                stem = w[:-len(suffix)]
                if suffix == "logi":
                    # The part before -ogi must have positive measure.
                    if _measure(w[:-3]) > 0:
                        return w[:-1]
                    return w
                if _measure(stem) > 0:
                    return stem + repl
                return w
        return w

    def _step3(self, w):
        for suffix, repl in _STEP3:
            if w.endswith(suffix):
                stem = w[:-len(suffix)]
                if _measure(stem) > 0:
                    return stem + repl
                return w
        return w

    def _step4(self, w):
        for suffix in _STEP4:
            if w.endswith(suffix):
                stem = w[:-len(suffix)]
                if _measure(stem) > 1 and (suffix != "ion" or stem[-1:] in ("s", "t")):
                    return stem
                return w
        return w

    def _step5(self, w):
        if w.endswith("e"):
            stem = w[:-1]
            m = _measure(stem)
            if m > 1 or (m == 1 and not _cvc(stem, self._ext)):
                w = stem
        if w.endswith("ll") and _measure(w) > 1:
            w = w[:-1]
        return w


# ---------------------------------------------------------------------------
# Lancaster stemmer (Paice/Husk)
# ---------------------------------------------------------------------------

_LANCASTER_RULES = [
    "ai*2.", "a*1.", "bb1.", "city3s.", "ci2>", "cn1t>", "dd1.", "dei3y>",
    "deec2ss.", "dee1.", "de2>", "dooh4>", "e1>", "feil1v.", "fi2>", "gni3>",
    "gai3y.", "ga2>", "gg1.", "ht*2.", "hsiug5ct.", "hsi3>", "i*1.", "i1y>",
    "ji1d.", "juf1s.", "ju1d.", "jo1d.", "jeh1r.", "jrev1t.", "jsim2t.",
    "jn1d.", "j1s.", "lbaifi6.", "lbai4y.", "lba3>", "lbi3.", "lib2l>",
    "lc1.", "lufi4y.", "lu2.", "lai3>", "lau3>", "la2>", "ll1.", "mui3.",
    "mu*2.", "msi3>", "mm1.", "nois4j>", "noix4ct.", "noi3>", "nai3>",
    "na2>", "nee0.", "ne2>", "nn1.", "pihs4>", "pp1.", "re2>", "rae0.",
    "ra2.", "ro2>", "ru2>", "rr1.", "rt1>", "rei3y>", "sei3y>", "sis2.",
    "si2>", "ssen4>", "ss0.", "suo3>", "su*2.", "s*1>", "s0.", "tacilp4y.",
    "ta2>", "tnem4>", "tne3>", "tna3>", "tpir2b.", "tpro2b.", "tcud1.",
    "tpmus2.", "tpec2iv.", "tulo2v.", "tsis0.", "tsi3>", "tt1.", "uqi3.",
    "ugo1.", "vis3j>", "vie0.", "vi2>", "ylb1>", "yli3y>", "ylp0.", "yl2>",
    "ygo1.", "yhp1.", "ymo1.", "ypo1.", "yti3>", "yte3>", "ytl2.", "yrtsi5.",
    "yka3>", "zi2>", "zy1s.",
]
_RULE_RE = re.compile(r"^([a-z]+)(\*?)(\d)([a-z]*)([.>])$")


def _parse_lancaster_rule(rule):
    m = _RULE_RE.match(rule)
    if not m:
        raise ValueError("bad Lancaster rule %r" % rule)
    letters, star, digit, append, cont = m.groups()
    # Rules are written with the ending reversed.
    return letters[::-1], bool(star), int(digit), append, cont == ">"


_LANCASTER_PARSED = [_parse_lancaster_rule(r) for r in _LANCASTER_RULES]


class LancasterStemmer:
    MIN_STEM = 2

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("stem expects a str")
        w = word.lower()
        intact = True
        while True:
            applied = False
            for ending, intact_only, remove, append, cont in _LANCASTER_PARSED:
                if not w.endswith(ending):
                    continue
                if intact_only and not intact:
                    continue
                remainder = w[:len(w) - remove] if remove else w
                if len(remainder) < self.MIN_STEM:
                    continue
                w = remainder + append
                applied = True
                if not cont:
                    return w
                intact = False
                break
            if not applied:
                return w


# ---------------------------------------------------------------------------
# Snowball stemmers
# ---------------------------------------------------------------------------

SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german",
    "hungarian", "italian", "norwegian", "porter", "portuguese", "romanian",
    "russian", "spanish", "swedish",
)
_SNOWBALL_IMPLEMENTED = ("english", "porter")

_PORTER2_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie",
    "tying": "tie", "idly": "idl", "gently": "gentl", "ugly": "ugli",
    "early": "earli", "only": "onli", "singly": "singl", "sky": "sky",
    "news": "news", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos",
    "bias": "bias", "andes": "andes",
}
_PORTER2_EXC2 = {
    "inning", "outing", "canning", "herring", "earring", "proceed",
    "exceed", "succeed",
}
_P2_VOWELS = "aeiouy"
_P2_STEP2 = [
    "ational", "tional", "enci", "anci", "abli", "entli", "izer", "ization",
    "ation", "ator", "alism", "aliti", "alli", "fulness", "ousli", "ousness",
    "iveness", "iviti", "biliti", "logi", "li",
]
_P2_STEP2_REPL = {
    "ational": "ate", "tional": "tion", "enci": "ence", "anci": "ance",
    "abli": "able", "entli": "ent", "izer": "ize", "ization": "ize",
    "ation": "ate", "ator": "ate", "alism": "al", "aliti": "al", "alli": "al",
    "fulness": "ful", "ousli": "ous", "ousness": "ous", "iveness": "ive",
    "iviti": "ive", "biliti": "ble", "logi": "log", "li": "",
}
_P2_STEP3 = {
    "ational": "ate", "tional": "tion", "alize": "al", "icate": "ic",
    "iciti": "ic", "ical": "ic", "ful": "", "ness": "", "ative": "",
}
_P2_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
    "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion",
]
_P2_LI_ENDINGS = "cdeghkmnrt"


def _p2_regions(w):
    def region(s):
        if len(s) == 0:
            return len(s)
        for i in range(1, len(s)):
            if s[i] not in _P2_VOWELS and s[i - 1] in _P2_VOWELS:
                return i + 1
        return len(s)

    if w[:5] == "gener" or w[:6] == "commun":
        r1 = 5 if w[:5] == "gener" else 6
    elif w[:5] == "arsen":
        r1 = 5
    else:
        r1 = region(w)
    return r1, region(w[r1:]) + r1


def _p2_short_syllable(w):
    if len(w) == 2:
        return w[0] in _P2_VOWELS and w[1] not in _P2_VOWELS
    if len(w) >= 3:
        return (w[-3] not in _P2_VOWELS and w[-2] in _P2_VOWELS
                and w[-1] not in _P2_VOWELS and w[-1] not in "wxY")
    return False


def _p2_longest(w, suffixes):
    best = None
    for s in suffixes:
        if w.endswith(s) and (best is None or len(s) > len(best)):
            best = s
    return best


def _porter2(word, stopwords=None):
    w = word.lower()
    if stopwords and w in stopwords:
        return w
    if len(w) <= 2:
        return w
    if w in _PORTER2_EXC1:
        return _PORTER2_EXC1[w]
    chars = list(w)
    if chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _P2_VOWELS:
            chars[i] = "Y"
    w = "".join(chars)
    r1, r2 = _p2_regions(w)

    # Step 0
    for suffix in ("'s'", "'s", "'"):
        if w.endswith(suffix):
            w = w[:-len(suffix)]
            break
    # Step 1a
    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith(("ied", "ies")):
        w = w[:-3] + ("i" if len(w[:-3]) > 1 else "ie")
    elif w.endswith("us") or w.endswith("ss"):
        pass
    elif w.endswith("s"):
        if any(c in _P2_VOWELS for c in w[:-2]):
            w = w[:-1]
    if w in _PORTER2_EXC2:
        return w.replace("Y", "y")
    # Step 1b
    if w.endswith(("eed", "eedly")):
        suffix = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suffix) >= r1:
            w = w[:-len(suffix)] + "ee"
    else:
        for suffix in ("ingly", "edly", "ing", "ed"):
            if w.endswith(suffix):
                stem = w[:-len(suffix)]
                if any(c in _P2_VOWELS for c in stem):
                    w = stem
                    if w.endswith(("at", "bl", "iz")):
                        w += "e"
                    elif w[-2:] in ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt"):
                        w = w[:-1]
                    elif r1 >= len(w) and _p2_short_syllable(w):
                        w += "e"
                break
    # Step 1c
    if len(w) > 2 and w[-1] in "yY" and w[-2] not in _P2_VOWELS:
        w = w[:-1] + "i"
    # Step 2
    suffix = _p2_longest(w, _P2_STEP2)
    if suffix and len(w) - len(suffix) >= r1:
        if suffix == "li":
            if len(w) > 2 and w[-3] in _P2_LI_ENDINGS:
                w = w[:-2]
        else:
            w = w[:-len(suffix)] + _P2_STEP2_REPL[suffix]
    # Step 3
    suffix = _p2_longest(w, _P2_STEP3)
    if suffix:
        region_start = r2 if suffix == "ative" else r1
        if len(w) - len(suffix) >= region_start:
            w = w[:-len(suffix)] + _P2_STEP3[suffix]
    # Step 4
    suffix = _p2_longest(w, _P2_STEP4)
    if suffix and len(w) - len(suffix) >= r2:
        if suffix != "ion" or w[-4:-3] in ("s", "t"):
            w = w[:-len(suffix)]
    # Step 5
    if w.endswith("e"):
        if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not _p2_short_syllable(w[:-1])):
            w = w[:-1]
    elif w.endswith("l") and len(w) - 1 >= r2 and w[-2:-1] == "l":
        w = w[:-1]
    return w.replace("Y", "y")


class SnowballStemmer:
    """Snowball stemmer for one of ``SNOWBALL_LANGUAGES``.

    English (Porter2) and ``'porter'`` (the original Porter algorithm) are
    implemented.  The other listed languages are refused at construction
    with ``NotImplementedError``."""

    def __init__(self, language, ignore_stopwords=False):
        if not isinstance(language, str) or language not in SNOWBALL_LANGUAGES:
            raise ValueError("unsupported Snowball language: %r" % (language,))
        self.language = language
        self.ignore_stopwords = bool(ignore_stopwords)
        self._stopwords = None
        if self.ignore_stopwords:
            self._stopwords = _load_stopwords(language)
        if language not in _SNOWBALL_IMPLEMENTED:
            raise NotImplementedError(
                "Snowball stemmer for language %r is not implemented" % language)
        self._porter = PorterStemmer(mode="original") if language == "porter" else None

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("stem expects a str")
        if self._porter is not None:
            w = word.lower()
            if self._stopwords and w in self._stopwords:
                return w
            return self._porter.stem(w, to_lowercase=False)
        return _porter2(word, self._stopwords)


def _load_stopwords(language):
    rel = os.path.join("corpora", "stopwords", language)
    path = data.find(rel, description="stopwords/" + language)
    if not os.path.isfile(path):
        raise LookupError("stopwords list for %r is not a file" % language)
    with open(path, encoding="utf-8") as fh:
        return {line.strip().lower() for line in fh if line.strip()}


# ---------------------------------------------------------------------------
# Regular-expression stemmer and resource-gated stemmers
# ---------------------------------------------------------------------------

class RegexpStemmer:
    """Removes every match of ``regexp`` from the word; nothing else."""

    def __init__(self, regexp):
        if not isinstance(regexp, str):
            raise TypeError("regexp must be a str")
        self._re = re.compile(regexp)

    def stem(self, word):
        if not isinstance(word, str):
            raise TypeError("stem expects a str")
        return self._re.sub("", word)


class WordNetLemmatizer:
    """Requires the WordNet resource.  Lemmatization itself is outside the
    specified behaviour, so with WordNet visible this raises
    ``NotImplementedError``."""

    def __init__(self):
        data.find(os.path.join("corpora", "wordnet"), description="wordnet")
        raise NotImplementedError("WordNet lemmatization is outside this specification")

    def lemmatize(self, word):
        raise NotImplementedError("WordNet lemmatization is outside this specification")


class ARLSTem:
    """Arabic light stemmer.  Its results are outside this specification and
    it is not implemented."""

    def stem(self, word):
        raise NotImplementedError("ARLSTem is outside this specification")


class ARLSTem2(ARLSTem):
    """Second Arabic light stemmer; not implemented (see ARLSTem)."""
