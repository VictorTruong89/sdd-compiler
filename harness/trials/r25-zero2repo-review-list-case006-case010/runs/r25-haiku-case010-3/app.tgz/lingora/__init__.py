"""LINGORA Language Toolkit: tokenizers, stemmers, taggers, chunk parsers,
context-free grammars and trees, classifiers, and evaluation metrics.

Importing the package downloads nothing.  Packaged models are located
through ``lingora.data.path``.
"""

from lingora import data  # noqa: F401
from lingora import tokenize  # noqa: F401
from lingora import stem  # noqa: F401
from lingora import tag  # noqa: F401
from lingora import tree  # noqa: F401
from lingora import grammar  # noqa: F401
from lingora import parse  # noqa: F401
from lingora import chunk  # noqa: F401
from lingora import classify  # noqa: F401
from lingora import metrics  # noqa: F401
from lingora import translate  # noqa: F401
from lingora import cli  # noqa: F401

__version__ = "0.1.0"
__all__ = ["data"]
