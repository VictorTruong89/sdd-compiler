"""Packaged-resource finder.

``path`` is a mutable list of directories that are searched for packaged
resources (Punkt models, perceptron taggers, stopword lists, ...).  The
initial contents come from the ``LINGORA_DATA`` environment variable
(``os.pathsep``-separated); it is empty when that variable is unset.
"""

import os

path = [p for p in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if p]


def find(relpath, description=None):
    """Return the absolute path of ``relpath`` inside the first listed
    directory that contains it.  Raise ``LookupError`` if none does."""
    for base in list(path):
        candidate = os.path.join(base, relpath)
        if os.path.exists(candidate):
            return candidate
    what = description or relpath
    raise LookupError(
        "packaged resource %r is not installed (searched: %s)"
        % (what, ", ".join(list(path)) or "<empty data.path>")
    )


def exists(relpath):
    """True when ``relpath`` is visible through ``path``."""
    try:
        find(relpath)
    except LookupError:
        return False
    return True
