"""Context-free grammars (FP-05).

Nonterminals are ``Nonterminal`` objects.  They are not ``str`` instances,
but they compare equal to, and hash like, their name, so ``start() == "S"``
holds.  Terminals are plain ``str`` values.
"""

import re

__all__ = ["CFG", "Nonterminal", "Production"]


class Nonterminal:
    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = str(name)

    def name(self):
        return self._name

    def __str__(self):
        return self._name

    def __repr__(self):
        return "Nonterminal(%r)" % self._name

    def __eq__(self, other):
        if isinstance(other, Nonterminal):
            return self._name == other._name
        if isinstance(other, str):
            return self._name == other
        return NotImplemented

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    def __hash__(self):
        return hash(self._name)


class Production:
    __slots__ = ("_lhs", "_rhs")

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def __eq__(self, other):
        return (isinstance(other, Production) and self._lhs == other._lhs
                and self._rhs == other._rhs)

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        return "%s -> %s" % (self._lhs, " ".join(
            repr(s) if isinstance(s, str) and not isinstance(s, Nonterminal)
            else str(s) for s in self._rhs))


_SYMBOL_RE = re.compile(r"""\s*(?:"([^"]*)"|'([^']*)'|([^\s"'|]+))""")


def _parse_rhs_alternatives(text, lineno):
    """Split a right-hand side on ``|`` (outside quotes) into alternatives,
    each a tuple of symbols."""
    alternatives = [[]]
    pos = 0
    text = text.rstrip()
    while True:
        m = re.compile(r"\s*").match(text, pos)
        pos = m.end()
        if pos >= len(text):
            break
        if text[pos] == "|":
            alternatives.append([])
            pos += 1
            continue
        sm = _SYMBOL_RE.match(text, pos)
        if not sm:
            raise ValueError("grammar line %d: cannot read %r" % (lineno, text[pos:]))
        if sm.group(1) is not None:
            alternatives[-1].append(sm.group(1))
        elif sm.group(2) is not None:
            alternatives[-1].append(sm.group(2))
        else:
            alternatives[-1].append(Nonterminal(sm.group(3)))
        pos = sm.end()
    return [tuple(a) for a in alternatives]


class CFG:
    def __init__(self, start, productions):
        self._start = start if isinstance(start, Nonterminal) else Nonterminal(start)
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("CFG.fromstring expects text")
        productions = []
        start = None
        for lineno, raw in enumerate(input.splitlines(), 1):
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if "->" not in line:
                raise ValueError("grammar line %d: expected 'LHS -> RHS'" % lineno)
            lhs_text, rhs_text = line.split("->", 1)
            lhs_text = lhs_text.strip()
            if not lhs_text or not re.fullmatch(r"[A-Za-z_][\w\-']*", lhs_text):
                raise ValueError("grammar line %d: bad left-hand side %r" % (lineno, lhs_text))
            lhs = Nonterminal(lhs_text)
            if start is None:
                start = lhs
            for alt in _parse_rhs_alternatives(rhs_text, lineno):
                productions.append(Production(lhs, alt))
        if start is None:
            raise ValueError("grammar has no productions")
        return cls(start, productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        return [p for p in self._productions if p.lhs() == lhs]

    def nonterminals(self):
        return {p.lhs() for p in self._productions}

    def terminals(self):
        out = set()
        for p in self._productions:
            for s in p.rhs():
                if isinstance(s, str) and not isinstance(s, Nonterminal):
                    out.add(s)
        return out

    def __repr__(self):
        return "<CFG with %d productions, start %s>" % (len(self._productions), self._start)
