"""Evaluation metrics (FP-07)."""

__all__ = [
    "accuracy",
    "edit_distance",
    "f_measure",
    "jaccard_distance",
    "precision",
    "recall",
]


def accuracy(reference, test):
    """Fraction of positions at which the two lists hold equal values.
    Lists of different lengths are refused."""
    if not isinstance(reference, list) or not isinstance(test, list):
        raise TypeError("accuracy expects two lists")
    if len(reference) != len(test):
        raise ValueError("accuracy needs lists of equal length")
    if not reference:
        raise ValueError("accuracy of two empty lists is undefined")
    return sum(1 for a, b in zip(reference, test) if a == b) / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    """Levenshtein distance; with ``transpositions`` the unrestricted
    Damerau-Levenshtein distance (Lowrance and Wagner, 1975)."""
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance expects two strings")
    if isinstance(substitution_cost, bool) or not isinstance(substitution_cost, (int, float)):
        raise TypeError("substitution_cost must be a number")
    n, m = len(s1), len(s2)
    if transpositions:
        return _damerau_levenshtein(s1, s2, substitution_cost)
    prev = [j for j in range(m + 1)]
    for i in range(1, n + 1):
        cur = [i] + [0] * m
        for j in range(1, m + 1):
            cost = 0 if s1[i - 1] == s2[j - 1] else substitution_cost
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
        prev = cur
    return prev[m]


def _damerau_levenshtein(a, b, subcost):
    """Unrestricted Damerau-Levenshtein distance (Lowrance and Wagner, 1975).
    ``d[i+1][j+1]`` holds the distance between a[:i+1] and b[:j+1]; row and
    column 0 are sentinels."""
    maxdist = len(a) + len(b)
    last_seen_row = {}
    d = [[0] * (len(b) + 2) for _ in range(len(a) + 2)]
    d[0][0] = maxdist
    for i in range(len(a) + 1):
        d[i + 1][0] = maxdist
        d[i + 1][1] = i
    for j in range(len(b) + 1):
        d[0][j + 1] = maxdist
        d[1][j + 1] = j
    for i in range(1, len(a) + 1):
        last_match_col = 0
        for j in range(1, len(b) + 1):
            k = last_seen_row.get(b[j - 1], 0)
            l = last_match_col
            if a[i - 1] == b[j - 1]:
                cost = 0
                last_match_col = j
            else:
                cost = subcost
            d[i + 1][j + 1] = min(
                d[i][j] + cost,
                d[i + 1][j] + 1,
                d[i][j + 1] + 1,
                d[k][l] + (i - k - 1) + 1 + (j - l - 1),
            )
        last_seen_row[a[i - 1]] = i
    return d[len(a) + 1][len(b) + 1]


def jaccard_distance(label1, label2):
    """|symmetric difference| / |union| of two sets (0 when both are empty)."""
    if not isinstance(label1, (set, frozenset)) or not isinstance(label2, (set, frozenset)):
        raise TypeError("jaccard_distance expects two sets")
    union = label1 | label2
    if not union:
        return 0.0
    return len(label1 ^ label2) / len(union)


def _require_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("precision, recall and f_measure expect sets")


def precision(reference, test):
    """|reference & test| / |test|; ``None`` when ``test`` is empty."""
    _require_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    """|reference & test| / |reference|; ``None`` when ``reference`` is empty."""
    _require_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    """Weighted harmonic mean of precision and recall.  ``None`` when either
    set is empty or the two sets share no element."""
    _require_sets(reference, test)
    if not reference or not test or not (reference & test):
        return None
    p = precision(reference, test)
    r = recall(reference, test)
    return 1.0 / (alpha / p + (1 - alpha) / r)
