"""BLEU score (FP-07), Papineni et al. 2002, sentence level."""

import math
from collections import Counter

__all__ = ["bleu", "method1"]

_DEFAULT_WEIGHTS = (0.25, 0.25, 0.25, 0.25)


def method1(matches, totals, epsilon=0.1):
    """A simple smoothing function: each zero modified-precision numerator is
    replaced by ``epsilon``.  Returns a list of precisions."""
    out = []
    for m, t in zip(matches, totals):
        if t == 0:
            out.append(0.0)
        elif m == 0:
            out.append(epsilon / t)
        else:
            out.append(m / t)
    return out


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def bleu(references, hypothesis, weights=None, smoothing_function=None):
    """Sentence BLEU of ``hypothesis`` (a token list) against ``references``
    (a list of token lists).  Without ``smoothing_function`` the score is 0
    when a weighted order has no match.  ``smoothing_function`` is called as
    ``f(matches, totals)`` with per-order clipped match counts and candidate
    n-gram totals, and returns the per-order precisions."""
    if not isinstance(references, (list, tuple)) or not isinstance(hypothesis, (list, tuple)):
        raise TypeError("bleu expects a list of reference token lists and a token list")
    if weights is None:
        weights = _DEFAULT_WEIGHTS
    weights = [float(w) for w in weights]
    if not weights:
        raise ValueError("bleu needs at least one weight")
    hyp = list(hypothesis)
    refs = [list(r) for r in references]
    if not hyp or not refs:
        return 0.0

    matches, totals = [], []
    for n in range(1, len(weights) + 1):
        hyp_counts = _ngrams(hyp, n)
        total = sum(hyp_counts.values())
        max_ref = Counter()
        for ref in refs:
            for gram, count in _ngrams(ref, n).items():
                if count > max_ref[gram]:
                    max_ref[gram] = count
        clipped = sum(min(count, max_ref[gram]) for gram, count in hyp_counts.items())
        matches.append(clipped)
        totals.append(total)

    if smoothing_function is None:
        precisions = [(m / t) if t > 0 else 0.0 for m, t in zip(matches, totals)]
        for w, p in zip(weights, precisions):
            if w > 0 and p == 0:
                return 0.0
    else:
        precisions = list(smoothing_function(matches, totals))

    # Brevity penalty against the reference length closest to the candidate.
    c = len(hyp)
    r = min((abs(len(ref) - c), len(ref)) for ref in refs)[1]
    if c == 0:
        return 0.0
    bp = 1.0 if c > r else math.exp(1 - r / c)

    log_sum = 0.0
    for w, p in zip(weights, precisions):
        if w == 0:
            continue
        if p <= 0:
            return 0.0
        log_sum += w * math.log(p)
    return float(bp * math.exp(log_sum))
