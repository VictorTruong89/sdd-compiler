"""Text classifiers (FP-06): Naive Bayes and decision tree, and accuracy."""

import math
from collections import Counter, defaultdict

__all__ = ["DecisionTreeClassifier", "NaiveBayesClassifier", "ProbDist", "accuracy"]


class ProbDist:
    """A probability distribution over labels."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs)

    def max(self):
        return max(self._probs, key=lambda k: (self._probs[k], str(k)))

    def __repr__(self):
        return "<ProbDist with %d labels>" % len(self._probs)


def _check_labeled(labeled):
    if not isinstance(labeled, (list, tuple)) or not labeled:
        raise ValueError("training needs a non-empty list of (featureset, label) pairs")
    for item in labeled:
        if not (isinstance(item, (list, tuple)) and len(item) == 2
                and isinstance(item[0], dict)):
            raise TypeError("each training item must be a (featureset dict, label) pair")
    return list(labeled)


class NaiveBayesClassifier:
    """Naive Bayes with add-one smoothing over feature values."""

    def __init__(self, label_counts, prior_labels, feature_value_counts, value_sets,
                 label_feature_totals):
        self._label_counts = label_counts          # label -> examples
        self._labels = prior_labels                # labels in first-seen order
        self._value_counts = feature_value_counts  # (label, fname, value) -> count
        self._value_sets = value_sets              # fname -> set of values
        self._label_feature_totals = label_feature_totals  # (label, fname) -> examples
        self._total = sum(label_counts.values())

    @classmethod
    def train(cls, labeled_featuresets):
        labeled = _check_labeled(labeled_featuresets)
        label_counts = Counter()
        labels = []
        value_counts = Counter()
        value_sets = defaultdict(set)
        totals = Counter()
        for fs, label in labeled:
            if label not in label_counts:
                labels.append(label)
            label_counts[label] += 1
            for fname, value in fs.items():
                value_counts[(label, fname, value)] += 1
                value_sets[fname].add(value)
                totals[(label, fname)] += 1
        return cls(dict(label_counts), labels, dict(value_counts), dict(value_sets),
                   dict(totals))

    def labels(self):
        return list(self._labels)

    def _log_scores(self, featureset):
        scores = {}
        for label in self._labels:
            log_p = math.log(self._label_counts[label] / self._total)
            for fname, value in featureset.items():
                if fname not in self._value_sets:
                    continue
                vocab = len(self._value_sets[fname])
                count = self._value_counts.get((label, fname, value), 0)
                denom = self._label_feature_totals.get((label, fname), 0) + vocab
                log_p += math.log((count + 1) / denom)
            scores[label] = log_p
        return scores

    def classify(self, featureset):
        scores = self._log_scores(featureset)
        index = {label: i for i, label in enumerate(self._labels)}
        return max(self._labels, key=lambda lab: (scores[lab], -index[lab]))

    def prob_classify(self, featureset):
        scores = self._log_scores(featureset)
        top = max(scores.values())
        exps = {label: math.exp(s - top) for label, s in scores.items()}
        norm = sum(exps.values())
        return ProbDist({label: v / norm for label, v in exps.items()})


_MISSING = object()


class _Node:
    __slots__ = ("feature", "children", "majority")

    def __init__(self, feature, children, majority):
        self.feature = feature
        self.children = children
        self.majority = majority


def _entropy(labels):
    counts = Counter(labels)
    n = len(labels)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


class DecisionTreeClassifier:
    """Decision tree that splits on the feature with the highest information
    gain.  A feature absent from a featureset counts as having no value."""

    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        labeled = _check_labeled(labeled_featuresets)
        return cls(cls._build(labeled, sorted_features=None))

    @staticmethod
    def _majority(labels):
        counts = Counter(labels)
        best = max(counts.values())
        for lab in labels:          # first-seen among the most common
            if counts[lab] == best:
                return lab

    @classmethod
    def _build(cls, examples, sorted_features):
        labels = [lab for _, lab in examples]
        majority = cls._majority(labels)
        if len(set(labels)) == 1:
            return _Node(None, None, majority)
        features = set()
        for fs, _ in examples:
            features.update(fs.keys())
        if not features:
            return _Node(None, None, majority)
        base = _entropy(labels)
        best_feature, best_gain = None, -1.0
        for fname in sorted(features, key=str):
            groups = defaultdict(list)
            for fs, lab in examples:
                groups[fs.get(fname, _MISSING)].append(lab)
            if len(groups) < 2:
                continue
            n = len(examples)
            remainder = sum(len(g) / n * _entropy(g) for g in groups.values())
            gain = base - remainder
            if gain > best_gain + 1e-12:
                best_feature, best_gain = fname, gain
        if best_feature is None or best_gain <= 1e-12:
            return _Node(None, None, majority)
        partition = defaultdict(list)
        for fs, lab in examples:
            partition[fs.get(best_feature, _MISSING)].append((fs, lab))
        children = {value: cls._build(group, None) for value, group in partition.items()}
        return _Node(best_feature, children, majority)

    def classify(self, featureset):
        node = self._root
        while node.feature is not None:
            value = featureset.get(node.feature, _MISSING)
            child = node.children.get(value)
            if child is None:
                return node.majority
            node = child
        return node.majority


def accuracy(classifier, gold):
    """Fraction of ``(featureset, label)`` pairs in ``gold`` that
    ``classifier`` labels correctly."""
    if not isinstance(gold, (list, tuple)) or not gold:
        raise ValueError("accuracy needs a non-empty list of (featureset, label) pairs")
    correct = sum(1 for fs, label in gold if classifier.classify(fs) == label)
    return correct / len(gold)
