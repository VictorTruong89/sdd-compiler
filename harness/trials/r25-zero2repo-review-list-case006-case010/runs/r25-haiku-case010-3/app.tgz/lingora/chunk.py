"""Chunk parsing with chunk grammars (FP-04).

Matching works on an encoded string.  Every matchable unit (a tagged token,
or a chunk built by an earlier clause) is written as ``\\x00 tag \\x01``, and
every unit that may not be matched is written as ``\\x02``.  A tag element of
a pattern is ``\\x00(?:tag-regex)\\x01``, so it matches exactly one unit, and
a match can never span an ineligible unit.
"""

import re

from lingora import data
from lingora.tree import Tree

__all__ = ["RegexpParser", "ne_chunk"]

ROOT_LABEL = "S"

_OPEN = "\x00"
_CLOSE = "\x01"
_BLOCK = "\x02"


def _element_regex(content):
    """Translate a tag regular expression so that ``.`` never crosses a
    unit delimiter."""
    out = []
    i = 0
    while i < len(content):
        c = content[i]
        if c == "\\" and i + 1 < len(content):
            out.append(content[i:i + 2])
            i += 2
            continue
        out.append("[^\x00\x01\x02]" if c == "." else c)
        i += 1
    return "".join(out)


def _compile_tag_pattern(text):
    """Compile a tag pattern (``<...>`` elements with optional quantifiers)
    into a regular expression over the encoded unit string."""
    out = []
    i = 0
    n = len(text)
    while i < n:
        c = text[i]
        if c.isspace():
            i += 1
            continue
        if c != "<":
            raise ValueError("tag pattern: expected '<' at %r" % text[i:])
        end = text.find(">", i + 1)
        if end < 0:
            raise ValueError("tag pattern: unclosed '<' in %r" % text)
        content = text[i + 1:end]
        i = end + 1
        try:
            re.compile(content)
        except re.error as exc:
            raise ValueError("tag pattern: bad element %r: %s" % (content, exc))
        elem = _OPEN + "(?:" + _element_regex(content) + ")" + _CLOSE
        k = i
        while k < n and text[k].isspace():
            k += 1
        quant = ""
        if k < n and text[k] in "?*+":
            quant = text[k]
            i = k + 1
        elif k < n and text[k] == "{":
            close = text.find("}", k)
            if close < 0:
                raise ValueError("tag pattern: unclosed '{' in %r" % text)
            m = re.fullmatch(r"\s*(\d*)\s*(,?)\s*(\d*)\s*", text[k + 1:close])
            if not m or (not m.group(1) and not m.group(3)):
                raise ValueError("tag pattern: bad count in %r" % text)
            lo, comma, hi = m.group(1), m.group(2), m.group(3)
            if comma:
                quant = "{%s,%s}" % (lo or "0", hi)
            else:
                quant = "{%s}" % lo
            i = close + 1
        out.append("(?:" + elem + ")" + quant if quant else elem)
    return re.compile("".join(out))


class _Rule:
    def __init__(self, kind, pattern):
        self.kind = kind          # "chunk" or "chink"
        self.pattern = pattern    # compiled regex over encoded units


def _parse_rule(text):
    text = text.strip()
    if len(text) >= 2 and text[0] == "{" and text[-1] == "}":
        return _Rule("chunk", _compile_tag_pattern(text[1:-1]))
    if len(text) >= 2 and text[0] == "}" and text[-1] == "{":
        return _Rule("chink", _compile_tag_pattern(text[1:-1]))
    raise ValueError("chunk grammar: rule %r is neither {...} nor }...{" % text)


def _parse_grammar(text):
    clauses = []
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        stripped = raw.strip()
        if stripped[:1] in ("{", "}") and clauses:
            # A brace-led line continues the current clause.
            clauses[-1][1].append(_parse_rule(stripped))
        elif raw[0] not in " \t":
            m = re.match(r"^\s*([^\s{}<>:]+)\s*:(.*)$", raw)
            if not m:
                raise ValueError("chunk grammar: expected '<LABEL>: <pattern>', got %r" % raw)
            clauses.append((m.group(1), []))
            rest = m.group(2).strip()
            if rest:
                clauses[-1][1].append(_parse_rule(rest))
        else:
            if not clauses:
                raise ValueError("chunk grammar: pattern before any clause label")
            clauses[-1][1].append(_parse_rule(raw.strip()))
    if not clauses:
        raise ValueError("chunk grammar has no clauses")
    for label, rules in clauses:
        if not rules:
            raise ValueError("chunk grammar: clause %r has no patterns" % label)
    return clauses


def _apply_chunk(nodes, rule, label):
    """Group every match of ``rule`` among eligible nodes into a chunk."""
    parts = []
    owner = {}
    pos = 0
    for idx, node in enumerate(nodes):
        if node[0] == "chunk":
            part = _BLOCK
        else:
            tag = node[1][1] if node[0] == "leaf" else node[1].label()
            part = _OPEN + tag + _CLOSE
            owner[pos] = idx
        parts.append(part)
        pos += len(part)
    encoded = "".join(parts)
    end_to_idx = {}
    p = 0
    for idx, part in enumerate(parts):
        p += len(part)
        end_to_idx[p] = idx
    matches = [m for m in rule.pattern.finditer(encoded) if m.end() > m.start()]
    matches = [m for m in matches if m.start() in owner and m.end() in end_to_idx]
    if not matches:
        return nodes
    out = []
    cursor = 0
    for m in matches:
        first = owner[m.start()]
        last = end_to_idx[m.end()]
        if first < cursor:
            continue
        out.extend(nodes[cursor:first])
        children = [node[1] for node in nodes[first:last + 1]]
        out.append(("chunk", label, children))
        cursor = last + 1
    out.extend(nodes[cursor:])
    return out


def _apply_chink(nodes, rule):
    """Remove every match of ``rule`` from the chunks of the current clause."""
    parts = []
    owner = {}
    pos = 0
    for idx, node in enumerate(nodes):
        if node[0] == "chunk":
            for ci, child in enumerate(node[2]):
                if isinstance(child, tuple):
                    part = _OPEN + child[1] + _CLOSE
                    owner[pos] = (idx, ci)
                else:
                    part = _BLOCK
                parts.append(part)
                pos += len(part)
        else:
            part = _BLOCK
            parts.append(part)
            pos += len(part)
    encoded = "".join(parts)
    removed = set()
    for m in rule.pattern.finditer(encoded):
        if m.end() <= m.start():
            continue
        for p in range(m.start(), m.end()):
            if p in owner:
                removed.add(owner[p])
    if not removed:
        return nodes
    out = []
    for idx, node in enumerate(nodes):
        if node[0] != "chunk":
            out.append(node)
            continue
        label, children = node[1], node[2]
        segment = []
        for ci, child in enumerate(children):
            if (idx, ci) in removed:
                if segment:
                    out.append(("chunk", label, segment))
                    segment = []
                out.append(("leaf", child))
            else:
                segment.append(child)
        if segment:
            out.append(("chunk", label, segment))
    return out


class RegexpParser:
    """Chunk parser for a chunk grammar (text, or a list of grammar texts)."""

    def __init__(self, grammar, root_label=ROOT_LABEL):
        if isinstance(grammar, str):
            text = grammar
        elif isinstance(grammar, (list, tuple)) and grammar and all(
                isinstance(g, str) for g in grammar):
            text = "\n".join(grammar)
        else:
            raise TypeError("chunk grammar must be text or a list of grammar stages")
        self._clauses = _parse_grammar(text)
        self._root = root_label

    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("parse expects a list of (token, tag) pairs")
        leaves = []
        for item in tagged:
            if not (isinstance(item, (list, tuple)) and len(item) == 2):
                raise TypeError("parse expects (token, tag) pairs")
            leaves.append((item[0], item[1]))
        nodes = [("leaf", leaf) for leaf in leaves]
        for label, rules in self._clauses:
            for rule in rules:
                if rule.kind == "chunk":
                    nodes = _apply_chunk(nodes, rule, label)
                else:
                    nodes = _apply_chink(nodes, rule)
            nodes = [("tree", Tree(node[1], node[2])) if node[0] == "chunk" else node
                     for node in nodes]
        children = []
        for node in nodes:
            if node[0] == "leaf":
                children.append(node[1])
            else:
                children.append(node[1])
        return Tree(self._root, children)


def ne_chunk(tagged_tokens):
    """Named-entity chunking.  Raises ``LookupError`` when the packaged
    named-entity model or the English wordlist is not installed.  The
    model's inference is outside this specification and is not implemented
    here, so a call with both resources present raises ``NotImplementedError``."""
    data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass",
              description="named-entity chunker model")
    data.find("corpora/words", description="English wordlist")
    if not isinstance(tagged_tokens, (list, tuple)):
        raise TypeError("ne_chunk expects a list of (token, tag) pairs")
    raise NotImplementedError("named-entity chunking is outside this specification")
