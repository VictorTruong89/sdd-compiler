"""Tokenizers: word/punctuation, Penn Treebank, LINGORA's recommended word
tokenizer, Punkt-based sentence tokenizer, whitespace, blank-line, regular
expression and tweet tokenizers (FP-01)."""

import os
import re

from lingora import data

__all__ = [
    "RegexpTokenizer",
    "TreebankWordTokenizer",
    "TweetTokenizer",
    "WhitespaceTokenizer",
    "WordPunctTokenizer",
    "blankline_tokenize",
    "sent_tokenize",
    "word_tokenize",
    "wordpunct_tokenize",
]


# ---------------------------------------------------------------------------
# Word / punctuation tokenizer
# ---------------------------------------------------------------------------

_WORD_PUNCT_RE = re.compile(r"\w+|[^\w\s]+")


class WordPunctTokenizer:
    """Maximal runs of word characters, and maximal runs of characters that
    are neither word characters nor whitespace."""

    def tokenize(self, text):
        return _WORD_PUNCT_RE.findall(text)

    def span_tokenize(self, text):
        return [(m.start(), m.end()) for m in _WORD_PUNCT_RE.finditer(text)]


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


# ---------------------------------------------------------------------------
# Whitespace, blank-line and regular-expression tokenizers
# ---------------------------------------------------------------------------

class WhitespaceTokenizer:
    _re = re.compile(r"\S+")

    def tokenize(self, text):
        return self._re.findall(text)

    def span_tokenize(self, text):
        return [(m.start(), m.end()) for m in self._re.finditer(text)]


_BLANKLINE_SEP = re.compile(r"\s*\n\s*\n\s*")


def blankline_tokenize(text):
    """Segments of ``text`` separated by blank lines (a newline, optional
    whitespace, another newline, and the whitespace around them)."""
    if not text.strip():
        return []
    pieces = _BLANKLINE_SEP.split(text)
    return [p.strip() for p in pieces if p.strip()]


class RegexpTokenizer:
    """Token mode (default): tokens are the matches of ``pattern``.
    Gap mode (``gaps=True``): tokens are the pieces between matches."""

    def __init__(self, pattern, gaps=False, discard_empty=True, flags=0):
        self._pattern = re.compile(pattern, flags)
        self.gaps = bool(gaps)
        self.discard_empty = bool(discard_empty)

    def _spans(self, text):
        if not text.strip():
            return []
        out = []
        if self.gaps:
            prev = 0
            for m in self._pattern.finditer(text):
                out.append((prev, m.start()))
                prev = m.end()
            out.append((prev, len(text)))
        else:
            out = [(m.start(), m.end()) for m in self._pattern.finditer(text)]
        if self.discard_empty:
            out = [(s, e) for (s, e) in out if e > s]
        return out

    def tokenize(self, text):
        return [text[s:e] for (s, e) in self._spans(text)]

    def span_tokenize(self, text):
        return self._spans(text)


# ---------------------------------------------------------------------------
# Penn Treebank word tokenizer and LINGORA's recommended word tokenizer
# ---------------------------------------------------------------------------

_TYPO_DOUBLE = re.compile("[“”„‟]")
_TYPO_SINGLE = re.compile("(?<!\\w)[‘‚‛]|[’‛](?!\\w)")
_DASHES_STAR = re.compile("[‒-―*]")
_FUSED = [
    (re.compile(r"(?i)\b(can)(not)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(d)('ye)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gim)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gon)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(got)(ta)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(lem)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(more)('n)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(wan)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)(^|\s)('t)(is|was)\b"), r"\1\2 \3"),
]
_CLITICS = [
    (re.compile(r"(?i)(\w)(n't)\b"), r"\1 \2"),
    (re.compile(r"(?i)(\w)('ll|'re|'ve|'s|'m|'d)\b"), r"\1 \2"),
]


def _treebank_split(text, improved):
    """Apply the Penn Treebank conventions to ``text``.  ``improved`` selects
    the recommended tokenizer's additions."""
    s = " " + text + " "
    if improved:
        s = _TYPO_DOUBLE.sub(lambda m: " %s " % m.group(0), s)
        s = _TYPO_SINGLE.sub(lambda m: " %s " % m.group(0), s)
        # A straight double quote at the very start of the text is a closer.
        s = re.sub(r"^( +)\"", r"\1'' ", s, count=1)
    # Opening quotes: start of text, or after space or an opening bracket.
    s = re.sub(r"(?<=[\s(\[{<])\"", " `` ", s)
    # Every other straight double quote is a closing quote.
    s = s.replace('"', " '' ")
    if improved:
        s = re.sub(r"\.{2,}", lambda m: " %s " % m.group(0), s)
        s = _DASHES_STAR.sub(lambda m: " %s " % m.group(0), s)
        s = s.replace("--", " -- ")
    else:
        s = s.replace("...", " ... ")
    s = re.sub(r"[;@#$%&?!]", lambda m: " %s " % m.group(0), s)
    s = re.sub(r"[\]\[(){}<>]", lambda m: " %s " % m.group(0), s)
    s = re.sub(r"([,:])(?!\d)", r" \1 ", s)
    # A point is split off only when it ends the text (optionally followed
    # by closing quotes or brackets).
    s = re.sub(r"(?<=[^\s.])\.(?=(?:''|[)\]}>\s])*$)", " . ", s)
    # Fused forms; the recommended tokenizer keeps "cannot" whole.
    fused = _FUSED if not improved else _FUSED[1:]
    for pat, rep in fused:
        s = pat.sub(rep, s)
    for pat, rep in _CLITICS:
        s = pat.sub(rep, s)
    s = re.sub(r"(\w)'(?=\s)", r"\1 '", s)
    return s.split()


class TreebankWordTokenizer:
    """Penn Treebank word tokenization conventions."""

    def tokenize(self, text):
        if not text.strip():
            return []
        return _treebank_split(text, improved=False)


# ---------------------------------------------------------------------------
# Punkt sentence model and sentence tokenizer
# ---------------------------------------------------------------------------

_PUNKT_CACHE = {}
_NUMBER_RE = re.compile(r"^[\-+]?[.,]?\d[\d.,:\-/]*$")
_OPENERS = "\"'([{<“‘«"
_CLOSERS = "\"')]}>”’»"


class _PunktParams:
    def __init__(self, abbrev_types, sent_starters, collocations, ortho):
        self.abbrev_types = abbrev_types
        self.sent_starters = sent_starters
        self.collocations = collocations
        self.ortho = ortho


def _read_lines(path):
    if not os.path.isfile(path):
        return []
    with open(path, encoding="utf-8") as fh:
        return [line.rstrip("\r\n") for line in fh]


def _load_punkt(language):
    """Load the Punkt parameters for ``language`` from the data finder.
    Raise ``LookupError`` when the model is not visible."""
    if not isinstance(language, str) or not language or (
        "/" in language or "\\" in language or language in (".", "..")
    ):
        raise LookupError("unknown Punkt language %r" % (language,))
    rel = os.path.join("tokenizers", "punkt_tab", language)
    directory = data.find(rel, description="punkt_tab/" + language)
    if not os.path.isdir(directory):
        raise LookupError("packaged resource %r is not a directory" % rel)
    if directory in _PUNKT_CACHE:
        return _PUNKT_CACHE[directory]
    abbrev = {line.strip().lower() for line in
              _read_lines(os.path.join(directory, "abbrev_types.txt")) if line.strip()}
    starters = {line.strip().lower() for line in
                _read_lines(os.path.join(directory, "sent_starters.txt")) if line.strip()}
    colloc = set()
    for line in _read_lines(os.path.join(directory, "collocations.tab")):
        parts = line.split("\t")
        if len(parts) == 2:
            colloc.add((parts[0], parts[1]))
    ortho = {}
    for line in _read_lines(os.path.join(directory, "ortho_context.tab")):
        parts = line.split("\t")
        if len(parts) == 2 and parts[1].strip().lstrip("-").isdigit():
            ortho[parts[0]] = ortho.get(parts[0], 0) | int(parts[1])
    params = _PunktParams(abbrev, starters, colloc, ortho)
    _PUNKT_CACHE[directory] = params
    return params


_ORTHO_UPPER_START = 2
_ORTHO_UPPER_UNKNOWN = 8
_ORTHO_LOWER_ANY = 16 | 32 | 64


def _punkt_sentences(text, params):
    toks = []
    for m in re.finditer(r"\S+", text):
        raw = m.group()
        core = raw.rstrip(_CLOSERS)
        final = ""
        word = core
        if core and core[-1] in ".?!":
            final = core[-1]
            word = core.rstrip(".?!")
        ellipsis = core.endswith("...") or core.endswith("..")
        lead = word.lstrip(_OPENERS)
        typ = lead.lower()
        if _NUMBER_RE.match(lead or "x"):
            typ = "##number##"
        toks.append({
            "start": m.start(), "end": m.end(), "final": final,
            "typ": typ, "ellipsis": ellipsis,
            "upper": lead[:1].isupper(), "lower": lead[:1].islower(),
        })
    if not toks:
        return []
    sentences = []
    start_idx = 0
    for i in range(len(toks) - 1):
        cur, nxt = toks[i], toks[i + 1]
        if not cur["final"]:
            continue
        if cur["final"] in "?!":
            brk = True
        elif (cur["typ"], nxt["typ"]) in params.collocations:
            brk = False
        else:
            abbrev_like = (
                cur["ellipsis"]
                or cur["typ"] in params.abbrev_types
                or (len(cur["typ"]) == 1 and cur["typ"].isalpha())
            )
            if not abbrev_like:
                brk = True
            else:
                ortho = params.ortho.get(nxt["typ"], 0)
                brk = (
                    nxt["typ"] in params.sent_starters
                    or (nxt["upper"]
                        and bool(ortho & (_ORTHO_UPPER_START | _ORTHO_UPPER_UNKNOWN))
                        and not (ortho & _ORTHO_LOWER_ANY))
                )
        if brk:
            sentences.append(text[toks[start_idx]["start"]:cur["end"]])
            start_idx = i + 1
    sentences.append(text[toks[start_idx]["start"]:toks[-1]["end"]])
    return sentences


def sent_tokenize(text, language="english"):
    """Split ``text`` into sentences with the Punkt model for ``language``.
    Raise ``LookupError`` when that model is not installed."""
    params = _load_punkt(language)
    return _punkt_sentences(text, params)


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer."""
    if preserve_line:
        if not text.strip():
            return []
        return _treebank_split(text, improved=True)
    tokens = []
    for sent in sent_tokenize(text, language=language):
        tokens.extend(_treebank_split(sent, improved=True))
    return tokens


# ---------------------------------------------------------------------------
# Tweet tokenizer
# ---------------------------------------------------------------------------

_EMOTICON = r"(?::|;|=|8)[\-o\*']?[\)\]\(\[dDpP/\\]|<3|\^_\^"
_TWEET_RE = re.compile(
    r"""
      (?P<url>(?:https?://|www\.)\S+)
    | (?P<emo>""" + _EMOTICON + r""")
    | (?P<hash>\#\w+)
    | (?P<handle>(?<!\w)@\w+)
    | (?P<num>\d+(?:[.,]\d+)*(?!\w))
    | (?P<word>\w+(?:['’]\w+)*)
    | (?P<dots>\.{2,})
    | (?P<punct>[^\w\s])
    """,
    re.VERBOSE,
)
_HANDLE_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")
_REDUCE_RE = re.compile(r"(.)\1{3,}", re.DOTALL)


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = bool(preserve_case)
        self.reduce_len = bool(reduce_len)
        self.strip_handles = bool(strip_handles)

    def tokenize(self, text):
        if self.strip_handles:
            text = _HANDLE_RE.sub(" ", text)
        if self.reduce_len:
            text = _REDUCE_RE.sub(lambda m: m.group(1) * 3, text)
        tokens = []
        for m in _TWEET_RE.finditer(text):
            kind = m.lastgroup
            tok = m.group()
            if not self.preserve_case and kind != "emo":
                tok = tok.lower()
            tokens.append(tok)
        return tokens


