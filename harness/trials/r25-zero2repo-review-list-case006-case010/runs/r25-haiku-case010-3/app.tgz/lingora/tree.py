"""Constituent trees (FP-05)."""

import re

__all__ = ["Tree"]

_TREE_TOKEN = re.compile(r"\(|\)|[^\s()]+")


class Tree:
    """A labelled node with an ordered list of children.  A child is a
    leaf (a token string) or another ``Tree``."""

    __slots__ = ("_label", "_children")

    def __init__(self, label, children):
        if isinstance(children, str):
            raise TypeError("Tree children must be a list, not a string")
        if children is None:
            raise TypeError("Tree children must be a list")
        self._label = label
        self._children = list(children)

    # -- basic access -------------------------------------------------------
    def label(self):
        return self._label

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __iter__(self):
        return iter(self._children)

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    # -- comparison ---------------------------------------------------------
    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __ne__(self, other):
        result = self.__eq__(other)
        if result is NotImplemented:
            return result
        return not result

    __hash__ = None

    def __repr__(self):
        return "Tree(%r, %r)" % (self._label, self._children)

    # -- text ---------------------------------------------------------------
    @classmethod
    def fromstring(cls, s):
        """Build a tree from bracketed tree text ``(label child ...)``."""
        tokens = _TREE_TOKEN.findall(s)
        pos = 0

        def parse_node():
            nonlocal pos
            if pos >= len(tokens) or tokens[pos] != "(":
                raise ValueError("bracketed tree text: expected '(' in %r" % s)
            pos += 1
            label = ""
            if pos < len(tokens) and tokens[pos] not in ("(", ")"):
                label = tokens[pos]
                pos += 1
            children = []
            while True:
                if pos >= len(tokens):
                    raise ValueError("bracketed tree text: unbalanced parentheses in %r" % s)
                tok = tokens[pos]
                if tok == ")":
                    pos += 1
                    return Tree(label, children)
                if tok == "(":
                    children.append(parse_node())
                else:
                    children.append(tok)
                    pos += 1

        tree = parse_node()
        if pos != len(tokens):
            raise ValueError("bracketed tree text: trailing material in %r" % s)
        return tree

    def pformat(self, indent=2):
        """Pretty-printed text; labels and leaves appear in pre-order."""
        return _pformat(self, 0, indent)

    def __str__(self):
        return self.pformat()


def _leaf_text(leaf):
    # Chunk leaves are (token, tag) pairs; they print as token/tag.
    if isinstance(leaf, tuple) and len(leaf) == 2:
        return "%s/%s" % (leaf[0], leaf[1])
    return str(leaf)


def _pformat(tree, depth, indent):
    pad = " " * (depth * indent)
    if all(not isinstance(c, Tree) for c in tree):
        inner = " ".join(_leaf_text(c) for c in tree)
        return "%s(%s%s)" % (pad, tree.label(), (" " + inner) if inner else "")
    lines = ["%s(%s" % (pad, tree.label())]
    for child in tree:
        if isinstance(child, Tree):
            lines.append(_pformat(child, depth + 1, indent))
        else:
            lines.append("%s%s" % (" " * ((depth + 1) * indent), _leaf_text(child)))
    lines[-1] = lines[-1] + ")"
    return "\n".join(lines)
