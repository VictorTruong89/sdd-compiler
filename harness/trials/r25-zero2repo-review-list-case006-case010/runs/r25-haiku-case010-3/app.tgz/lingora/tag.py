"""Part-of-speech taggers (FP-03).

Sequential taggers (default, unigram, regular-expression) are trained or
configured in memory.  ``pos_tag`` is the recommended tagger: a greedy
averaged perceptron tagger that reads packaged English or Russian resources.
"""

import json
import os
import re
from collections import Counter, defaultdict

from lingora import data

__all__ = ["DefaultTagger", "RegexpTagger", "UnigramTagger", "pos_tag"]


class SequentialTagger:
    """Assigns a tag to each token it can; tokens it leaves untagged go to
    the optional ``backoff`` tagger."""

    def __init__(self, backoff=None):
        self._backoff = backoff

    def _choose(self, tokens):
        raise NotImplementedError

    def tag(self, tokens):
        if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
            raise TypeError("tag expects a list of tokens")
        tags = list(self._choose(list(tokens)))
        if self._backoff is not None:
            missing = [i for i, t in enumerate(tags) if t is None]
            if missing:
                sub = self._backoff.tag([tokens[i] for i in missing])
                for i, (_, t) in zip(missing, sub):
                    tags[i] = t
        return [(tok, t) for tok, t in zip(tokens, tags)]


class DefaultTagger(SequentialTagger):
    def __init__(self, tag, backoff=None):
        super().__init__(backoff)
        self._tag = tag

    def _choose(self, tokens):
        return [self._tag] * len(tokens)


class UnigramTagger(SequentialTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(backoff)
        counts = defaultdict(Counter)
        for sentence in (train or []):
            for token, tag in sentence:
                counts[token][tag] += 1
        self._model = {}
        for token, tag_counts in counts.items():
            # Most frequent tag; ties broken by the tag's text.
            best = max(tag_counts.items(), key=lambda kv: (kv[1], str(kv[0])))
            self._model[token] = best[0]

    def _choose(self, tokens):
        return [self._model.get(tok) for tok in tokens]


class RegexpTagger(SequentialTagger):
    def __init__(self, regexps, backoff=None):
        super().__init__(backoff)
        self._rules = [(re.compile(pattern), tag) for pattern, tag in regexps]

    def _choose(self, tokens):
        out = []
        for tok in tokens:
            tag = None
            for pattern, candidate in self._rules:
                if pattern.match(tok):
                    tag = candidate
                    break
            out.append(tag)
        return out


# ---------------------------------------------------------------------------
# Averaged perceptron tagger (recommended tagger)
# ---------------------------------------------------------------------------

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]
_LANGS = ("eng", "rus")
_MODEL_CACHE = {}
_UNIVERSAL_CACHE = {}

# Russian National Corpus part-of-speech category -> universal tag.
_RNC_TO_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ANUM": "ADJ", "ADV": "ADV",
    "PR": "ADP", "CONJ": "CONJ", "NUM": "NUM", "PART": "PRT", "INTJ": "X",
    "SPRO": "PRON", "APRO": "DET", "PRO": "PRON",
}


def _normalise(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word[:1].isdigit():
        return "!DIGITS"
    return word.lower()


def _features(i, word, context, prev, prev2):
    feats = defaultdict(int)

    def add(name, *args):
        feats[" ".join((name,) + tuple(args))] += 1

    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[:1])
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return feats


class _PerceptronModel:
    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = classes

    def predict(self, feats):
        scores = defaultdict(float)
        for feat, value in feats.items():
            if value == 0 or feat not in self.weights:
                continue
            for label, weight in self.weights[feat].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        context = _START + [_normalise(w) for w in tokens] + _END
        prev, prev2 = _START[0], _START[1]
        out = []
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if tag is None:
                feats = _features(i + len(_START), word, context, prev, prev2)
                tag = self.predict(feats)
            out.append(tag)
            prev2, prev = prev, tag
        return out


def _load_model(lang):
    rel = os.path.join("taggers", "averaged_perceptron_tagger_" + lang)
    directory = data.find(rel, description="averaged_perceptron_tagger_" + lang)
    if not os.path.isdir(directory):
        raise LookupError("packaged resource %r is not a directory" % rel)
    if directory in _MODEL_CACHE:
        return _MODEL_CACHE[directory]
    base = os.path.join(directory, "averaged_perceptron_tagger_" + lang)

    def load(suffix):
        path = base + suffix
        if not os.path.isfile(path):
            raise LookupError("perceptron tagger file missing: %s" % path)
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)

    model = _PerceptronModel(load(".weights.json"), load(".tagdict.json"),
                             load(".classes.json"))
    _MODEL_CACHE[directory] = model
    return model


def _load_universal_map():
    rel = os.path.join("taggers", "universal_tagset")
    directory = data.find(rel, description="universal_tagset")
    if not os.path.isdir(directory):
        raise LookupError("packaged resource %r is not a directory" % rel)
    if directory in _UNIVERSAL_CACHE:
        return _UNIVERSAL_CACHE[directory]
    mapping = {}
    path = os.path.join(directory, "en-ptb.map")
    if not os.path.isfile(path):
        raise LookupError("universal tagset table en-ptb.map is missing")
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            parts = line.rstrip("\r\n").split("\t")
            if len(parts) >= 2 and parts[0]:
                mapping[parts[0]] = parts[1]
    _UNIVERSAL_CACHE[directory] = mapping
    return mapping


def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag a list of tokens with the recommended perceptron tagger.

    ``lang`` is ``'eng'`` or ``'rus'``.  ``tagset`` is ``None`` (native tags)
    or ``'universal'``.  Raises when the input is not a token list, when the
    language or tagset is unsupported, or when the packaged resource is
    missing."""
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("pos_tag expects a list of tokens, not a string")
    if not all(isinstance(t, str) for t in tokens):
        raise TypeError("pos_tag expects a list of str tokens")
    if lang not in _LANGS:
        raise ValueError("pos_tag supports only 'eng' and 'rus', not %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("tagset must be None or 'universal', not %r" % (tagset,))
    model = _load_model(lang)
    native = model.tag(list(tokens))
    if tagset == "universal":
        if lang == "eng":
            mapping = _load_universal_map()
            tags = [mapping.get(t, "X") for t in native]
        else:
            tags = [_RNC_TO_UNIVERSAL.get(t.split("=")[0], "X") for t in native]
    else:
        tags = native
    return list(zip(tokens, tags))
