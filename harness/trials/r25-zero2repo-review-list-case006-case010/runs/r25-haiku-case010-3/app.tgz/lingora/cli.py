"""Command line for LINGORA.

``lingora tokenize`` applies the recommended word tokenizer (with sentence
splitting) to each line of standard input and writes the tokens joined by
the delimiter, one output line per input line.  It needs the Punkt model
for the requested language; without it the command fails before writing any
token line.
"""

import sys

from lingora import tokenize as _tok

__all__ = ["cli"]

_USAGE = """usage: lingora tokenize [--language LANG] [--delimiter TEXT]

Reads UTF-8 text from standard input and writes, for each input line, its
recommended-word-tokenizer tokens joined by the delimiter (default: one space).
"""


class _Group:
    """Minimal command group with a ``main`` entry point."""

    def main(self, args=None, standalone_mode=True):
        argv = list(sys.argv[1:] if args is None else args)
        code = self._run(argv)
        if standalone_mode:
            sys.exit(code)
        return code

    def _run(self, argv):
        if not argv or argv[0] in ("-h", "--help"):
            sys.stdout.write(_USAGE)
            return 0
        if argv[0] == "tokenize":
            return _tokenize_command(argv[1:])
        sys.stderr.write("lingora: unknown command %r\n" % argv[0])
        return 2


def _parse_options(argv):
    language, delimiter = "english", " "
    i = 0
    while i < len(argv):
        opt = argv[i]
        if opt in ("--language", "-l") and i + 1 < len(argv):
            language = argv[i + 1]
            i += 2
        elif opt in ("--delimiter", "-d") and i + 1 < len(argv):
            delimiter = argv[i + 1]
            i += 2
        elif opt in ("-h", "--help"):
            sys.stdout.write(_USAGE)
            return None
        else:
            raise ValueError("unrecognised option %r" % opt)
    return language, delimiter


def _tokenize_command(argv):
    try:
        parsed = _parse_options(argv)
    except ValueError as exc:
        sys.stderr.write("lingora tokenize: %s\n" % exc)
        return 2
    if parsed is None:
        return 0
    language, delimiter = parsed
    try:
        # Check the sentence model before any input is read or written.
        _tok._load_punkt(language)
    except LookupError as exc:
        sys.stderr.write("lingora tokenize: %s\n" % exc)
        return 1
    out = sys.stdout
    for line in sys.stdin:
        line = line.rstrip("\r\n")
        tokens = _tok.word_tokenize(line, language=language, preserve_line=False)
        out.write(delimiter.join(tokens) + "\n")
    out.flush()
    return 0


cli = _Group()
