"""Enumerate the sentences a grammar derives (FP-05)."""

import itertools

from lingora.grammar import Nonterminal

__all__ = ["generate"]


def _gen_all(grammar, items, depth):
    if not items:
        yield []
        return
    first, rest = items[0], items[1:]
    for head in _gen_one(grammar, first, depth):
        for tail in _gen_all(grammar, rest, depth):
            yield head + tail


def _gen_one(grammar, sym, depth):
    if isinstance(sym, Nonterminal):
        if depth is None or depth > 0:
            child_depth = None if depth is None else depth - 1
            for prod in grammar.productions(sym):
                yield from _gen_all(grammar, list(prod.rhs()), child_depth)
    else:
        # A terminal, including the empty string, contributes one token.
        yield [sym]


def generate(grammar, start=None, depth=None, n=None):
    """Yield the sentences derived from ``start`` (default: the grammar's
    start symbol), each a list of terminal strings.  ``depth`` bounds the
    derivation depth and ``n`` the number of sentences."""
    if start is None:
        start = grammar.start()
    elif not isinstance(start, Nonterminal):
        start = Nonterminal(str(start))
    gen = _gen_one(grammar, start, depth)
    if n is None:
        return gen
    return itertools.islice(gen, int(n))
