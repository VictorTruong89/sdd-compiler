"""Grammar-based parsers (FP-05): a chart parser (exhaustive) and a
shift-reduce parser (single pass, no backtracking)."""

from lingora.grammar import Nonterminal
from lingora.tree import Tree

__all__ = ["ChartParser", "ShiftReduceParser"]


def _is_terminal(sym):
    return isinstance(sym, str) and not isinstance(sym, Nonterminal)


def _check_tokens(grammar, tokens):
    """Refuse token lists that are not lists of str, and tokens that no
    production of ``grammar`` produces."""
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("parse expects a list of tokens")
    if not all(isinstance(t, str) for t in tokens):
        raise TypeError("parse expects a list of str tokens")
    known = grammar.terminals()
    for t in tokens:
        if t not in known:
            raise ValueError("token %r is not produced by any production of the grammar" % t)
    return list(tokens)


class ChartParser:
    """Exhaustive parser: returns every tree the grammar assigns to the
    token list (an empty iterator when the grammar does not derive it)."""

    def __init__(self, grammar, trace=0):
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        return iter(self._all_parses(tokens))

    def _all_parses(self, tokens):
        grammar = self._grammar
        n = len(tokens)
        by_lhs = {}
        for prod in grammar.productions():
            by_lhs.setdefault(prod.lhs().name(), []).append(prod)
        memo = {}
        seq_memo = {}
        active = set()

        def derive(name, i, j):
            key = (name, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                return []
            active.add(key)
            results = []
            for prod in by_lhs.get(name, []):
                rhs = tuple(s for s in prod.rhs() if not (_is_terminal(s) and s == ""))
                for children in sequences(prod, rhs, 0, i, j):
                    results.append(Tree(name, children))
            active.discard(key)
            memo[key] = results
            return results

        def sequences(prod, rhs, k, start, end):
            key = (id(prod), k, start, end)
            if key in seq_memo:
                return seq_memo[key]
            if k == len(rhs):
                out = [[]] if start == end else []
            else:
                sym = rhs[k]
                out = []
                if _is_terminal(sym):
                    if start < end and tokens[start] == sym:
                        for rest in sequences(prod, rhs, k + 1, start + 1, end):
                            out.append([sym] + rest)
                else:
                    for mid in range(start, end + 1):
                        subs = derive(sym.name(), start, mid)
                        if not subs:
                            continue
                        rests = sequences(prod, rhs, k + 1, mid, end)
                        for rest in rests:
                            for sub in subs:
                                out.append([sub] + rest)
            seq_memo[key] = out
            return out

        if n == 0:
            start_name = grammar.start().name()
            return list(derive(start_name, 0, 0))
        return list(derive(grammar.start().name(), 0, n))


class ShiftReduceParser:
    """Single left-to-right shift-reduce pass without backtracking.  Returns
    the tree that the pass completes, or an empty iterator."""

    _MAX_REDUCE_WITHOUT_SHIFT = 1000

    def __init__(self, grammar, trace=0):
        self._grammar = grammar

    def parse(self, tokens):
        tokens = _check_tokens(self._grammar, tokens)
        return iter(self._run(tokens))

    def _run(self, tokens):
        grammar = self._grammar
        start_name = grammar.start().name()
        # Empty productions would reduce forever on an empty stack; they
        # are not used by this parser.
        prods = []
        for prod in grammar.productions():
            rhs = tuple(s for s in prod.rhs() if not (_is_terminal(s) and s == ""))
            if rhs:
                prods.append((prod.lhs().name(), rhs))
        stack = []
        pos = 0
        reduces = 0
        while True:
            reduced = False
            for lhs_name, rhs in prods:
                k = len(rhs)
                if len(stack) < k:
                    continue
                top = stack[len(stack) - k:]
                if all(_matches(item, sym) for item, sym in zip(top, rhs)):
                    if k == 1 and isinstance(top[0], Tree) and top[0].label() == lhs_name:
                        continue
                    del stack[len(stack) - k:]
                    stack.append(Tree(lhs_name, top))
                    reduced = True
                    break
            if reduced:
                reduces += 1
                if reduces > self._MAX_REDUCE_WITHOUT_SHIFT * (len(tokens) + 1):
                    return []
                continue
            if pos < len(tokens):
                stack.append(tokens[pos])
                pos += 1
                reduces = 0
                continue
            break
        if (pos == len(tokens) and len(stack) == 1 and isinstance(stack[0], Tree)
                and stack[0].label() == start_name):
            return [stack[0]]
        return []


def _matches(item, sym):
    if _is_terminal(sym):
        return isinstance(item, str) and item == sym
    return isinstance(item, Tree) and item.label() == sym.name()
