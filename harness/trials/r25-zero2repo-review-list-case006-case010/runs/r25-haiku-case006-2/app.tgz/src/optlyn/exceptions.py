"""Exceptions and their standalone exit classes (FP-13)."""

from __future__ import annotations


class OptlynError(Exception):
    """General library error. Standalone exit 1."""

    exit_code = 1

    def __init__(self, message=""):
        super().__init__(message)
        self.message = message

    def show(self, file=None):
        import sys

        from .termui import echo

        echo(f"Error: {self.message}", file=file or sys.stderr, err=True)


class UsageError(OptlynError):
    """Incorrect usage. Standalone exit 2. `ctx` is used to show the usage line."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self, file=None):
        import sys

        from .termui import echo

        lines = []
        if self.ctx is not None:
            lines.append(self.ctx.get_usage())
            lines.append(f"Try '{self.ctx.command_path} {self.ctx.help_option_names[0]}' for help.")
            lines.append("")
        lines.append(f"Error: {self.message}")
        echo("\n".join(lines), file=file or sys.stderr, err=True)


class MissingCommand(UsageError):
    """A group was invoked without a subcommand where one is needed."""


class Abort(OptlynError):
    """User or author abort. Standalone exit 1."""

    exit_code = 1

    def __init__(self, message="Aborted!"):
        super().__init__(message)

    def show(self, file=None):
        import sys

        from .termui import echo

        echo(self.message, file=file or sys.stderr, err=True)


class Exit(Exception):
    """Author clean stop or intentional help/version exit with a status."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code


class DeprecationNotice:
    """Marker used for deprecation warnings (not an exception)."""
