"""Parameters (options and arguments) and token parsing (FP-03, FP-04)."""

from __future__ import annotations

import enum
import re

from .exceptions import UsageError
from .types import BOOL, INT, STRING, BadParameter, _as_type, infer_type

PREFIX_CHARS = ("-", "/", "+")


class Source(enum.Enum):
    """Where a parameter's value came from (FP-07 get_parameter_source)."""

    PROMPT = "prompt"
    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"


def _auto_env_name(ctx, dest):
    """Automatic environment name: prefix, subcommands below root, destination (FP-07)."""
    parts = [ctx.auto_envvar_prefix] + list(ctx.path_names_below_root()) + [dest]
    return "_".join(p.replace("-", "_").upper() for p in parts if p)


class Parameter:
    is_argument = False

    def __init__(self, param_decls=None, *, type=None, default=None, required=False,
                 nargs=None, multiple=False, envvar=None, allow_from_autoenv=True,
                 callback=None, is_eager=False, expose_value=True, hidden=False,
                 deprecated=False, help=None, metavar=None, show_default=None,
                 show_envvar=False, shell_complete=None, count=False, **_ignored):
        self.type_arg = type
        self.default = default
        self.required = required
        self.multiple = multiple
        self.count = count
        self.nargs = nargs
        self.envvar = envvar
        self.allow_from_autoenv = allow_from_autoenv
        self.callback = callback
        self.is_eager = is_eager
        self.expose_value = expose_value
        self.hidden = hidden
        self.deprecated = deprecated
        self.help = help
        self.metavar = metavar
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.shell_complete_func = shell_complete
        self.name = None
        self.opts = []
        self.secondary_opts = []
        self.confirm_text = None
        self.prompt = False
        self.prompt_required = True

    def _finalize_type(self):
        t = self.type_arg
        if t is None:
            t = infer_type(self.default)
        if t is None:
            t = STRING
        self.type = _as_type(t)
        if self.type.is_composite:
            self.nargs = self.type.arity
        if self.nargs is None:
            self.nargs = 1

    @property
    def repeats_or_multi(self):
        """True when the value is a sequence (repeatable or multi-value or tuple)."""
        return self.multiple or self.nargs != 1

    def shell_complete(self, ctx, incomplete):
        if self.shell_complete_func is not None:
            return self.shell_complete_func(ctx, self, incomplete)
        return self.type.shell_complete(ctx, self, incomplete)

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"

    def label(self):
        return self.name

    def get_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return self.type.get_default_metavar()


class Option(Parameter):
    def __init__(self, param_decls=None, *, is_flag=False, flag_value=None, prompt=False,
                 prompt_required=True, hide_input=False, confirmation_prompt=False,
                 **kwargs):
        super().__init__(param_decls, **kwargs)
        self.is_flag = bool(is_flag)
        self.flag_value = flag_value
        self.prompt = prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self._parse_decls(list(param_decls or []))
        if self.deprecated and self.required:
            raise ValueError("A deprecated option cannot also be required.")
        if self.deprecated and self.prompt:
            raise ValueError("A deprecated option cannot use a prompt.")
        if self.count:
            self.type = INT
            self.nargs = 0
            return
        if self.is_flag:
            if self.flag_value is None:
                self.flag_value = True
            if self.type_arg is None:
                self.type = BOOL
            else:
                self.type = _as_type(self.type_arg)
            self.nargs = 0
            if self.default is None:
                self.default = False
            return
        self._finalize_type()

    def _parse_decls(self, decls):
        dest = None
        for decl in decls:
            if not decl:
                continue
            if decl[0] in PREFIX_CHARS:
                if decl[0] == "-" and "/" in decl[1:]:
                    on, off = decl.split("/", 1)
                    if off[:1] in PREFIX_CHARS:
                        self.opts.append(on)
                        self.secondary_opts.append(off)
                        self.is_flag = True
                        continue
                self.opts.append(decl)
            elif dest is None:
                dest = decl
        if not self.opts:
            raise ValueError("An option needs at least one flag name or a destination.")
        if dest is None:
            dest = self._infer_dest()
        self.name = re.sub(r"\W", "_", dest.replace("-", "_"))

    def _infer_dest(self):
        # first long name, otherwise first short name; prefix stripped, dashes -> underscores
        longs = [n for n in self.opts if n.startswith("--")]
        pick = longs[0] if longs else self.opts[0]
        return pick.lstrip("".join(PREFIX_CHARS)).replace("-", "_")

    @property
    def all_names(self):
        return self.opts + self.secondary_opts

    @property
    def takes_value(self):
        return not self.is_flag and not self.count

    def label(self):
        return " / ".join(self.all_names) or self.name

    def get_metavar(self):
        if self.is_flag or self.count:
            return None
        if self.metavar is not None:
            return self.metavar
        return self.type.get_default_metavar()


class Argument(Parameter):
    is_argument = True

    def __init__(self, param_decls=None, *, optional=False, **kwargs):
        decls = list(param_decls or [])
        if len(decls) != 1:
            raise ValueError("An argument takes exactly one name.")
        if kwargs.get("nargs") not in (None, -1) and kwargs["nargs"] < 1:
            raise ValueError("nargs must be positive or -1 (variadic).")
        required = kwargs.pop("required", None)
        super().__init__(decls, **kwargs)
        self.name = re.sub(r"\W", "_", decls[0].replace("-", "_"))
        if required is None:
            # a variadic argument is optional unless marked required (FP-04)
            required = (not optional) and self.default is None and self.nargs != -1
        self.required = required
        if self.deprecated and self.required:
            raise ValueError("A deprecated argument cannot be required.")
        self._finalize_type()
        if self.nargs == -1:
            self.multiple = True

    @property
    def variadic(self):
        return self.nargs == -1

    @property
    def slots(self):
        return 1 if self.variadic else self.nargs

    def get_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()

    def label(self):
        return self.name


def _finalize_arg_nargs(p):
    return p


# ----------------------------------------------------------------------
# Token parsing
# ----------------------------------------------------------------------

class ParseResult:
    def __init__(self):
        self.cli = {}            # dest -> list of (param, value), command-line order
        self.counts = {}         # dest -> occurrences of a counting option
        self.prompt_now = set()  # dests of prompting options given without a value
        self.eager = None        # eager parameter that fired (first one typed)
        self.positional = []     # list of (token_index, token)
        self.rest_index = None   # first token index not consumed (groups)
        self.deprecated_seen = []
        self.supplied = set()


def _is_option_like(tok):
    return len(tok) > 1 and tok[0] in PREFIX_CHARS


def _is_number(tok):
    try:
        float(tok)
        return True
    except ValueError:
        return False


def parse_tokens(ctx, params, tokens, *, interspersed=True, stop_after_slots=None,
                 ignore_unknown=False):
    """Parse option tokens and collect positional tokens.

    `stop_after_slots`: for groups, the number of argument tokens after which the
    next positional token is the subcommand name, and parsing stops there.
    `interspersed=False` on a leaf: after the first positional token, everything
    else is positional.
    """
    res = ParseResult()
    by_name = {}
    for p in params:
        if isinstance(p, Option):
            for n in p.all_names:
                by_name.setdefault(n, p)
    norm = ctx.token_normalize_func

    def lookup(name):
        if name in by_name:
            return by_name[name]
        if norm:
            for n, p in by_name.items():
                if norm(n) == norm(name):
                    return p
        return None

    n = len(tokens)
    i = 0
    after_dd = False
    no_opts = False
    while i < n:
        tok = tokens[i]
        if after_dd or no_opts:
            if stop_after_slots is not None and not after_dd and len(res.positional) >= stop_after_slots:
                break
            res.positional.append((i, tok))
            i += 1
            continue
        if tok == "--":
            after_dd = True
            i += 1
            continue
        if not _is_option_like(tok):
            if stop_after_slots is not None and len(res.positional) >= stop_after_slots:
                break
            res.positional.append((i, tok))
            if not interspersed and stop_after_slots is None:
                no_opts = True
            i += 1
            continue

        # option-like token
        if "=" in tok:
            name, eq_val = tok.split("=", 1)
            p = lookup(name)
            if p is not None:
                i = _consume_option(ctx, res, p, name, eq_val, tokens, i)
                if res.eager is not None:
                    return res
                continue
        p = lookup(tok)
        if p is not None:
            i = _consume_option(ctx, res, p, tok, None, tokens, i)
            if res.eager is not None:
                return res
            continue

        prefix = tok[0]
        if tok[1] == prefix:
            # unknown long option
            if ignore_unknown:
                res.positional.append((i, tok))
                i += 1
                continue
            raise UsageError(f"No such option: {tok.split('=', 1)[0]}", ctx)

        # single-prefix stack of single-character flags
        j = 1
        value_taken = False
        unknown = None
        while j < len(tok):
            short = prefix + tok[j]
            sp = lookup(short)
            if sp is None:
                unknown = tok[j:]
                break
            rest = tok[j + 1:]
            if sp.takes_value:
                i = _consume_option(ctx, res, sp, short, rest or None, tokens, i)
                value_taken = True
                break
            _consume_option(ctx, res, sp, short, None, tokens, i)
            if res.eager is not None:
                return res
            j += 1
        if res.eager is not None:
            return res
        if value_taken:
            continue
        if unknown is not None:
            # a known flag before it was consumed; the unknown rest stays leftover
            if ignore_unknown:
                res.positional.append((i, prefix + unknown))
                i += 1
                continue
            raise UsageError(f"No such option: {prefix}{unknown[0]}", ctx)
        i += 1
    res.rest_index = min(i, n)
    return res


def _consume_option(ctx, res, p, name, eq_val, tokens, i):
    """Consume one occurrence of option `p` whose token is tokens[i]; return next index."""
    if p.is_eager:
        res.eager = p
        return i + 1
    if p.deprecated:
        res.deprecated_seen.append(p)
    res.supplied.add(p.name)
    if p.count:
        res.counts[p.name] = res.counts.get(p.name, 0) + 1
        return i + 1
    if p.is_flag:
        if eq_val is not None:
            raise UsageError(f"Option {name} does not take a value.", ctx)
        value = False if name in p.secondary_opts else p.flag_value
        res.cli.setdefault(p.name, []).append((p, value))
        return i + 1
    # value-taking option
    need = p.nargs if p.nargs and p.nargs > 0 else 1
    vals = []
    j = i + 1
    if eq_val is not None:
        vals.append(eq_val)
    while len(vals) < need and j < len(tokens):
        nxt = tokens[j]
        if nxt == "--" or (_is_option_like(nxt) and not _is_number(nxt)):
            break
        vals.append(nxt)
        j += 1
    if len(vals) < need:
        if p.prompt:
            res.prompt_now.add(p.name)
            res.supplied.add(p.name)
            return j
        raise UsageError(
            f"Option {name} requires {need} argument{'s' if need != 1 else ''}.", ctx)
    value = vals[0] if need == 1 else tuple(vals)
    res.cli.setdefault(p.name, []).append((p, value))
    return j
