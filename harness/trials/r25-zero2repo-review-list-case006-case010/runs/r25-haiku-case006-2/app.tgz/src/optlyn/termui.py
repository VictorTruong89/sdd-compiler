"""Terminal helpers (FP-08, FP-11)."""

from __future__ import annotations

import contextlib
import io
import os
import re
import shlex
import subprocess
import sys
import tempfile
import time

from . import _stack

_ANSI_RE = re.compile(r"\033\[[0-9;]*[A-Za-z]")

_COLORS = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
    "reset": 39,
}

_BIT_CODES = {
    "bold": (1, 22), "dim": (2, 22), "italic": (3, 23), "underline": (4, 24),
    "blink": (5, 25), "reverse": (7, 27), "strikethrough": (9, 29), "overline": (53, 55),
}


def unstyle(text):
    return _ANSI_RE.sub("", text)


def _color_code(color, background=False):
    base = 40 if background else 30
    if isinstance(color, str):
        if color not in _COLORS:
            raise ValueError(f"Unknown color {color!r}.")
        code = _COLORS[color]
        if color == "reset":
            return "49" if background else "39"
        return str(code + (10 if background else 0))
    if isinstance(color, int) and not isinstance(color, bool):
        if not 0 <= color <= 255:
            raise ValueError(f"Color {color} out of range 0-255.")
        return f"{base + 8}8;5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return f"{base + 8}8;2;{color[0]};{color[1]};{color[2]}"
    raise ValueError(f"Invalid color {color!r}.")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True):
    codes = []
    if fg is not None:
        codes.append(_color_code(fg))
    if bg is not None:
        codes.append(_color_code(bg, background=True))
    flags = dict(bold=bold, dim=dim, underline=underline, overline=overline, italic=italic,
                 blink=blink, reverse=reverse, strikethrough=strikethrough)
    for k, v in flags.items():
        if v is not None:
            on, _off = _BIT_CODES[k]
            codes.append(str(on) if v else str(_BIT_CODES[k][1]))
    if not codes:
        return text
    prefix = "".join(f"\033[{c}m" for c in codes)
    return f"{prefix}{text}" + ("\033[0m" if reset else "")


def _resolve_color(color, stream):
    if color is not None:
        return bool(color)
    ctx = _stack.current_or_none()
    if ctx is not None and ctx.color is not None:
        return bool(ctx.color)
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def _stream_for(file, err):
    if file is not None:
        return file
    return sys.stderr if err else sys.stdout


def echo(message=None, file=None, nl=True, err=False, color=None):
    stream = _stream_for(file, err)
    if message is None:
        message = ""
    if isinstance(message, bytes):
        buf = getattr(stream, "buffer", None)
        if buf is not None:
            if nl:
                message = message + b"\n"
            stream.flush()
            buf.write(message)
            buf.flush()
        else:
            stream.write(message.decode("utf-8", "replace") + ("\n" if nl else ""))
        return
    text = str(message)
    if not _resolve_color(color, stream):
        text = unstyle(text)
    if nl:
        text += "\n"
    try:
        stream.write(text)
    except UnicodeEncodeError:
        data = text.encode("utf-8")
        buf = getattr(stream, "buffer", None)
        if buf is not None:
            stream.flush()
            buf.write(data)
            buf.flush()
        else:
            stream.write(data.decode("ascii", "replace"))
    try:
        stream.flush()
    except Exception:
        pass


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None:
        message = style(str(message), **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def is_interactive():
    try:
        stdin_tty = sys.stdin is not None and sys.stdin.isatty()
    except Exception:
        stdin_tty = False
    try:
        stdout_tty = sys.stdout is not None and sys.stdout.isatty()
    except Exception:
        stdout_tty = False
    return bool(stdin_tty or stdout_tty)


def _read_line(hide_input):
    stdin = sys.stdin
    if hide_input and stdin is not None and stdin.isatty():
        import getpass
        return getpass.getpass("")
    line = stdin.readline()
    if line == "":
        raise EOFError()
    line = line.rstrip("\r\n")
    if hide_input:
        return line
    return line


def prompt(text, default=None, hide_input=False, confirmation_prompt=False,
           type=None, value_proc=None, err=False, show_default=True, prompt_suffix=": "):
    from .types import STRING, infer_type, _as_type

    if type is None:
        inferred = infer_type(default) if default is not None else None
        ptype = inferred or STRING
    else:
        ptype = _as_type(type)

    suffix = ""
    if default is not None and show_default and not callable(default):
        suffix = f" [{default}]" if not hide_input else " [***]"
    while True:
        echo(f"{text}{suffix}{prompt_suffix}", nl=False, err=err)
        value = _read_line(hide_input)
        if not isinstance(value, str):
            value = str(value)
        if hide_input is False and not (sys.stdin is not None and sys.stdin.isatty()):
            echo(value, err=err)
        elif hide_input:
            echo("", err=err)
        if value == "" and default is not None:
            value = default() if callable(default) else default
            if isinstance(value, str) or not isinstance(value, (int, float, bool)):
                pass
        elif value == "" and default is None:
            value = ""
        try:
            converted = ptype.convert(value, None, _stack.current_or_none())
        except Exception as e:
            from .exceptions import UsageError
            from .types import BadParameter
            if isinstance(e, BadParameter):
                echo(f"Error: {e.message}", err=True)
                continue
            raise
        if confirmation_prompt:
            echo(f"Repeat for confirmation{prompt_suffix}", nl=False, err=err)
            again = _read_line(hide_input)
            if hide_input is False and not (sys.stdin is not None and sys.stdin.isatty()):
                echo(again, err=err)
            elif hide_input:
                echo("", err=err)
            if again != value:
                echo("Error: the two entered values do not match", err=True)
                continue
        if value_proc is not None:
            converted = value_proc(converted)
        return converted


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True,
            err=False):
    from .exceptions import Abort

    hint = " [Y/n]" if default else " [y/N]"
    if not show_default:
        hint = ""
    while True:
        echo(f"{text}{hint}{prompt_suffix}", nl=False, err=err)
        value = _read_line(False)
        if not (sys.stdin is not None and sys.stdin.isatty()):
            echo(value, err=err)
        v = value.strip().lower()
        if v == "":
            result = default
            break
        if v in ("y", "yes"):
            result = True
            break
        if v in ("n", "no"):
            result = False
            break
    if not result and abort:
        raise Abort()
    return result


def getchar(echo_char=False):
    tty = None
    try:
        tty = open("/dev/tty", "rb", buffering=0)
    except OSError:
        tty = None
    try:
        if tty is not None and os.name == "posix":
            import termios
            import tty as _tty

            fd = tty.fileno()
            old = termios.tcgetattr(fd)
            try:
                _tty.setraw(fd)
                ch = os.read(fd, 1)
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
            c = ch.decode("utf-8", "replace")
        else:
            c = sys.stdin.read(1)
            if c == "":
                raise EOFError()
    finally:
        if tty is not None:
            tty.close()
    if c == "\x03":
        raise KeyboardInterrupt()
    if c == "\x04" or c == "\x1a" and os.name == "nt":
        raise EOFError()
    if echo_char:
        echo(c, nl=False)
    return c


def pause(info=None, err=False):
    if not is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    echo(info, nl=False, err=err)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo("", err=err)


def clear():
    if sys.stdout is not None and sys.stdout.isatty():
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    if editor is None:
        editor = (env or {}).get("EDITOR") or os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if editor is None:
        editor = "notepad" if os.name == "nt" else "vi"
    cmd = shlex.split(editor) if isinstance(editor, str) else list(editor)
    if filename is not None:
        subprocess.run(cmd + [str(filename)], check=False, env=_env(env))
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        data = (text or "").encode("utf-8")
        os.write(fd, data)
        os.close(fd)
        mtime = os.path.getmtime(path)
        subprocess.run(cmd + [path], check=False, env=_env(env))
        with open(path, "rb") as f:
            result = f.read().decode("utf-8", "replace")
        changed = os.path.getmtime(path) != mtime or result != (text or "")
        if require_save and not changed:
            return None
        return result
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def _env(env):
    if not env:
        return None
    e = dict(os.environ)
    e.update(env)
    return e


def launch(url, wait=False, locate=False):
    if sys.platform.startswith("darwin"):
        cmd = ["open"]
    elif os.name == "nt":
        os.startfile(url)  # type: ignore[attr-defined]
        return 0
    else:
        cmd = ["xdg-open"]
    if locate and sys.platform.startswith("darwin"):
        cmd.append("-R")
    cmd.append(url)
    try:
        p = subprocess.Popen(cmd)
    except OSError:
        return 1
    if wait:
        return p.wait()
    return 0


def get_app_dir(app_name, roaming=True, force_posix=False):
    if force_posix:
        return os.path.join(os.path.expanduser("~"), "." + app_name.lower().replace(" ", "-"))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~/Library/Application Support"), app_name)
    if os.name == "nt":
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
        return os.path.join(base, app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = xdg if xdg else os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(base, folder)


def format_filename(filename, shorten=False):
    if isinstance(filename, (bytes, os.PathLike)):
        filename = os.fsdecode(filename)
    text = str(filename)
    text = text.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")
    if shorten:
        text = os.path.basename(text)
    return text


class ProgressBar:
    def __init__(self, iterable, length, label, hidden):
        self._iterable = iterable
        self.length = length if length is not None else (
            len(iterable) if iterable is not None and hasattr(iterable, "__len__") else None)
        self.label = label
        self.hidden = hidden
        self.pos = 0
        self.tty = (not hidden) and sys.stdout is not None and _isatty(sys.stdout)
        self._start = time.time()
        if label and not hidden and not self.tty:
            echo(label)

    def _render(self):
        if not self.tty:
            return
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            width = 30
            filled = int(width * frac)
            eta = ""
            if self.pos:
                elapsed = time.time() - self._start
                remaining = elapsed / self.pos * (self.length - self.pos)
                eta = f" eta {int(remaining)}s"
            sys.stdout.write(f"\r{self.label or ''} [{'#' * filled}{'-' * (width - filled)}] "
                             f"{self.pos}/{self.length}{eta}")
        else:
            sys.stdout.write(f"\r{self.label or ''} {self.pos}")
        sys.stdout.flush()

    def update(self, n_steps):
        self.pos += n_steps
        self._render()

    def __iter__(self):
        if self._iterable is None:
            return
        for item in self._iterable:
            yield item
            self.update(1)
        if self.tty:
            sys.stdout.write("\n")

    def finish(self):
        if self.tty:
            sys.stdout.write("\n")
            sys.stdout.flush()


def _isatty(stream):
    try:
        return stream.isatty()
    except Exception:
        return False


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    bar = ProgressBar(iterable, length, label, hidden)
    try:
        yield bar
    finally:
        bar.finish()


def echo_via_pager(text_or_generator, color=None):
    if callable(text_or_generator):
        chunks = text_or_generator()
    elif isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    if not is_interactive():
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    pager = os.environ.get("PAGER") or ("more" if os.name == "nt" else "less")
    proc = subprocess.Popen(pager, shell=True, stdin=subprocess.PIPE)
    try:
        for chunk in chunks:
            proc.stdin.write(str(chunk).encode("utf-8", "replace"))
            proc.stdin.flush()
    except BrokenPipeError:
        pass
    finally:
        try:
            proc.stdin.close()
        except Exception:
            pass
        proc.wait()


@contextlib.contextmanager
def get_pager_file(color=None):
    buf = io.StringIO()
    try:
        yield buf
    finally:
        echo_via_pager(buf.getvalue(), color=color)
