"""Parameter types and conversion (FP-05)."""

from __future__ import annotations

import datetime as _dt
import enum
import os
import pathlib
import sys
import uuid as _uuid


class BadParameter(Exception):
    """Refuses a value. Reported as a usage error (exit 2)."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message)
        self.message = message
        self.ctx = ctx
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        if self.param is not None:
            hint = self.param_hint or _param_hint(self.param)
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"


def _param_hint(param):
    decls = getattr(param, "opts", None)
    if decls:
        return " / ".join(decls)
    return param.name


class ParamType:
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value

    def get_metavar(self, param):
        return None

    def get_default_metavar(self):
        return self.name.upper()

    def shell_complete(self, ctx, param, incomplete):
        return []

    @property
    def is_composite(self):
        return False

    @property
    def split_on_env(self):
        """Whether an env string is split for repeatable/multi-value use."""
        return True

    def split_env(self, value):
        return value.split()

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            try:
                return value.decode("utf-8")
            except UnicodeError:
                return value.decode("utf-8", "replace")
        return str(value) if not isinstance(value, str) else value


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value

    @property
    def split_on_env(self):
        return True


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid float.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value))
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self.case_sensitive = case_sensitive
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self._enum = choices
            self.choices = list(choices)
            self._tokens = [m.name for m in choices]
        else:
            self._enum = None
            self.choices = list(choices)
            self._tokens = [str(c) for c in self.choices]

    def get_default_metavar(self):
        return "[" + "|".join(self._tokens) + "]"

    def get_metavar(self, param):
        return self.get_default_metavar()

    def _norm(self, s):
        return s if self.case_sensitive else s.casefold()

    def convert(self, value, param=None, ctx=None):
        if self._enum is not None and isinstance(value, self._enum):
            return value
        if not self._enum and value in self.choices:
            return value
        for tok, orig in zip(self._tokens, self.choices):
            if self._norm(tok) == self._norm(str(value)):
                return orig
        self.fail(
            f"{value!r} is not one of {', '.join(repr(t) for t in self._tokens)}.",
            param, ctx,
        )

    def shell_complete(self, ctx, param, incomplete):
        return [t for t in self._tokens if self._norm(t).startswith(self._norm(incomplete))]


_DEFAULT_DT_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DT_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value), fmt)
            except ValueError:
                continue
        self.fail(
            f"{value!r} does not match the formats {', '.join(self.formats)}.",
            param, ctx,
        )


class IntRange(IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        lo, hi = self.min, self.max
        if lo is not None:
            if v < lo or (self.min_open and v == lo):
                if self.clamp:
                    return lo + 1 if self.min_open else lo
                self.fail(self._range_msg(), param, ctx)
        if hi is not None:
            if v > hi or (self.max_open and v == hi):
                if self.clamp:
                    return hi - 1 if self.max_open else hi
                self.fail(self._range_msg(), param, ctx)
        return v

    def _range_msg(self):
        return f"{self._bounds_text()}."

    def _bounds_text(self):
        lo = "" if self.min is None else (
            f"{'>' if self.min_open else '>='} {self.min}")
        hi = "" if self.max is None else (
            f"{'<' if self.max_open else '<='} {self.max}")
        return "is not in the range " + " and ".join(x for x in (lo, hi) if x)


class FloatRange(FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        # FP-05 boundary rule: clamp with an open bound is a declaration error (NOTES C-17).
        if clamp and (min_open or max_open):
            raise ValueError("FloatRange clamp is not allowed with an open bound.")
        self.min, self.max = min, max
        self.min_open, self.max_open = min_open, max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        if self.min is not None and (v < self.min or (self.min_open and v == self.min)):
            if self.clamp:
                return float(self.min)
            self.fail(f"{v!r} is not in the range.", param, ctx)
        if self.max is not None and (v > self.max or (self.max_open and v == self.max)):
            if self.clamp:
                return float(self.max)
            self.fail(f"{v!r} is not in the range.", param, ctx)
        return v


class Tuple(ParamType):
    name = "tuple"

    def __init__(self, types):
        self.types = [_as_type(t) for t in types]

    @property
    def is_composite(self):
        return True

    @property
    def arity(self):
        return len(self.types)

    def get_default_metavar(self):
        return " ".join(t.get_default_metavar() for t in self.types)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, tuple) and len(value) == len(self.types):
            return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))
        if not isinstance(value, (list, tuple)) or len(value) != len(self.types):
            self.fail(f"{value!r} must be a tuple of {len(self.types)} values.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))

    def split_env(self, value):
        return value.split()


class File(ParamType):
    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"unsupported mode {mode!r}")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def get_default_metavar(self):
        return "FILENAME"

    def _is_lazy(self):
        if self.lazy is not None:
            return self.lazy
        return self.mode in ("w", "wb")

    def convert(self, value, param=None, ctx=None):
        from .fileio import open_file

        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        try:
            return open_file(
                str(value), self.mode, self.encoding, self.errors,
                lazy=self._is_lazy(), atomic=self.atomic,
            )
        except OSError as e:
            self.fail(f"Could not open file {value!s}: {e.strerror or e}.", param, ctx)

    def split_env(self, value):
        return value.split(os.pathsep)


class Path(ParamType):
    name = "path"

    def __init__(self, exists=False, file_okay=True, dir_okay=True, writable=False,
                 readable=True, resolve_path=False, allow_dash=False, path_type=None,
                 executable=False):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def get_default_metavar(self):
        return "PATH"

    def convert(self, value, param=None, ctx=None):
        raw = os.fspath(value) if not isinstance(value, str) else value
        if isinstance(raw, bytes):
            raw = os.fsdecode(raw)
        if self.allow_dash and raw == "-":
            return self._out("-")
        p = raw
        if self.resolve_path:
            p = os.path.realpath(os.path.expanduser(p))
        exists = os.path.exists(p)
        if not exists:
            if self.exists:
                self.fail(f"{raw} does not exist.", param, ctx)
        else:
            if os.path.isdir(p) and not self.dir_okay:
                self.fail(f"{raw} is a directory.", param, ctx)
            if not os.path.isdir(p) and not self.file_okay:
                self.fail(f"{raw} is a file.", param, ctx)
            if self.readable and not os.access(p, os.R_OK):
                self.fail(f"{raw} is not readable.", param, ctx)
            if self.writable and not os.access(p, os.W_OK):
                self.fail(f"{raw} is not writable.", param, ctx)
            if self.executable and not os.access(p, os.X_OK):
                self.fail(f"{raw} is not executable.", param, ctx)
        return self._out(p)

    def _out(self, p):
        if self.path_type is pathlib.Path:
            return pathlib.Path(p)
        return p

    def split_env(self, value):
        return value.split(os.pathsep)


def _as_type(t):
    if t is None:
        return STRING
    if isinstance(t, ParamType):
        return t
    if isinstance(t, type) and issubclass(t, ParamType):
        return t()
    if t is str:
        return STRING
    if t is int:
        return INT
    if t is float:
        return FLOAT
    if t is bool:
        return BOOL
    if t is _uuid.UUID:
        return UUID
    if callable(t):
        return FuncParamType(t)
    raise TypeError(f"unsupported type {t!r}")


class FuncParamType(ParamType):
    """A conversion function f(token) -> value that refuses by raising ValueError."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError as e:
            self.fail(str(e) or f"{value!r} is not valid.", param, ctx)


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()


def infer_type(default):
    """Infer a parameter type from a default value (FP-05)."""
    if default is None or callable(default):
        return None
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, (list, tuple)):
        return None
    return None
