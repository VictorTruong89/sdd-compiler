"""Core classes: Context, Command, Group, CommandCollection, and the standalone runner."""

from __future__ import annotations

import contextlib
import os
import sys

from . import _stack
from .exceptions import Abort, Exit, MissingCommand, OptlynError, UsageError
from .formatting import clean_help, format_help, format_usage
from .params import Argument, Option, Parameter, parse_tokens
from .resolve import check_extra, resolve_arguments, resolve_options
from .types import BadParameter

DEFAULT_HELP_NAMES = ["--help"]
_CHAIN = object()  # sentinel for invoked_subcommand on a chaining group


class Source:
    """Re-export helper; the enum lives in params."""


class NoArgsHelp(UsageError):
    """No arguments on a command where no-args-is-help applies: help goes to stderr, exit 2."""

    def show(self, file=None):
        from .termui import echo

        echo(format_help(self.ctx.command, self.ctx), file=file or sys.stderr, err=True, color=False)


_SETTING_KEYS = (
    "auto_envvar_prefix", "default_map", "terminal_width", "max_content_width",
    "help_option_names", "token_normalize_func", "color", "show_default",
    "allow_extra_args", "ignore_unknown_options", "allow_interspersed_args", "obj",
)


class Context:
    """Per-invocation state (FP-07; Contract section 6)."""

    def __init__(self, command, parent=None, info_name=None, **settings):
        self.command = command
        self.parent = parent
        self.info_name = info_name or (command.name if command is not None else None)
        unknown = set(settings) - set(_SETTING_KEYS)
        if unknown:
            raise TypeError(f"Unknown context settings: {', '.join(sorted(unknown))}")
        for key in _SETTING_KEYS:
            if key in settings and settings[key] is not None:
                value = settings[key]
            elif parent is not None:
                value = getattr(parent, key)
            else:
                value = None
            setattr(self, key, value)
        if self.help_option_names is None:
            self.help_option_names = list(DEFAULT_HELP_NAMES)
        if parent is None and self.default_map is not None and not isinstance(self.default_map, dict):
            self.default_map = dict(self.default_map)
        elif parent is not None:
            child_map = None
            if isinstance(parent.default_map, dict) and self.info_name in parent.default_map:
                child_map = parent.default_map[self.info_name]
            self.default_map = child_map if isinstance(child_map, dict) else None
        if self.obj is None and parent is not None:
            self.obj = parent.obj
        self.params = {}
        self.invoked_subcommand = None
        self._sources = {}
        self._kwargs = {}
        self._rest = []
        self._exit_stack = contextlib.ExitStack() if parent is None else None
        if parent is None:
            self._path = [self.info_name]
            self.command_path = self.info_name
        else:
            self._path = parent._path + [self.info_name]
            self.command_path = parent.command_path + " " + self.info_name
        self.path_names = list(self._path)

    # -- path helpers --------------------------------------------------
    def path_names_below_root(self):
        return self._path[1:]

    def _root(self):
        c = self
        while c.parent is not None:
            c = c.parent
        return c

    def get_usage(self):
        return format_usage(self.command, self)

    # -- context-manager protocol -----------------------------------------
    def __enter__(self):
        _stack.push(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        _stack.pop()
        return False

    # -- members -----------------------------------------------------------
    def get_parameter_source(self, name):
        from .params import Source as S

        if not any(p.name == name for p in self._all_declared()):
            return None
        src = self._sources.get(name)
        return src if src is not None else S.DEFAULT

    def _all_declared(self):
        return [p for p in self.command.params] if self.command is not None else []

    def with_resource(self, cm):
        return self._root()._exit_stack.enter_context(cm)

    def close(self):
        if self._exit_stack is not None:
            self._exit_stack.close()

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def invoke(self, cmd, **kwargs):
        child = Context(cmd, parent=self, info_name=cmd.name)
        child.params = dict(kwargs)
        with child:
            return cmd.invoke_with(child, dict(kwargs))

    def forward(self, cmd, **kwargs):
        names = {p.name for p in cmd.params if not p.is_argument or True}
        merged = {k: v for k, v in self.params.items() if k in names}
        merged.update(kwargs)
        return self.invoke(cmd, **merged)


def get_current_context(silent=False):
    return _stack.current(silent=silent)


# ----------------------------------------------------------------------
# Commands
# ----------------------------------------------------------------------

class Command:
    allow_interspersed_default = True

    def __init__(self, name=None, callback=None, params=None, *, help=None, short_help=None,
                 epilog=None, options_metavar=None, context_settings=None,
                 add_help_option=True, no_args_is_help=False, deprecated=False, hidden=False,
                 **_ignored):
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        self.help_text = clean_help(help if help is not None else (callback.__doc__ if callback else None))
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = add_help_option
        self.no_args_is_help = bool(no_args_is_help)
        self.deprecated = deprecated
        self.hidden = hidden
        self.usage_suffix = ""
        self._check_duplicates()

    def _check_duplicates(self):
        seen = {}
        for p in self.params:
            if p.name in seen and seen[p.name] is not p and not isinstance(p, Option):
                raise ValueError(f"Duplicate parameter name {p.name!r}.")
            seen[p.name] = p

    @property
    def arguments(self):
        return [p for p in self.params if p.is_argument]

    @property
    def options(self):
        return [p for p in self.params if not p.is_argument]

    # -- help --------------------------------------------------------------
    def get_help_option(self, ctx):
        """Build the implicit help option for this invocation (dynamic help names)."""
        if not self.add_help_option:
            return None
        names = list(ctx.help_option_names)
        if not names:
            return None
        declared = set()
        for p in self.params:
            if isinstance(p, Option):
                declared.update(p.all_names)
        if all(n in declared for n in names):
            return None
        return Option(names, is_flag=True, is_eager=True, expose_value=False,
                      help="Show this message and exit.", callback=_help_callback)

    def _params_for(self, ctx):
        params = list(self.params)
        auto = self.get_help_option(ctx)
        if auto is not None:
            params.append(auto)
        return params

    def visible_children(self, ctx):
        return []

    # -- context ------------------------------------------------------------
    def make_context(self, info_name, args, parent=None, **extra):
        ctx = Context(self, parent=parent, info_name=info_name, **self._settings(extra))
        with ctx:
            self.parse_args(ctx, list(args))
        return ctx

    def _settings(self, extra):
        merged = dict(self.context_settings)
        merged.update(extra)
        return merged

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help:
            raise NoArgsHelp("", ctx)
        params = self._params_for(ctx)
        interspersed = ctx.allow_interspersed_args
        if interspersed is None:
            interspersed = self.allow_interspersed_default
        res = parse_tokens(ctx, params, args, interspersed=interspersed,
                           ignore_unknown=bool(ctx.ignore_unknown_options))
        if res.eager is not None:
            eager = res.eager
            if eager.callback is not None:
                eager.callback(ctx, eager, True)
            raise Exit(0)
        kwargs = resolve_options(ctx, self.params, res)
        arg_kwargs, consumed = resolve_arguments(ctx, self.arguments, [t for _, t in res.positional], res)
        kwargs.update(arg_kwargs)
        leftover = [t for _, t in res.positional][consumed:]
        check_extra(ctx, leftover, bool(ctx.allow_extra_args), bool(ctx.ignore_unknown_options))
        ctx._kwargs = kwargs
        ctx._rest = []

    # -- invocation ----------------------------------------------------------
    def invoke(self, ctx):
        return self.invoke_with(ctx, ctx._kwargs)

    def invoke_with(self, ctx, kwargs):
        if self.deprecated:
            from .termui import echo

            msg = f"DeprecationWarning: The command '{self.name}' is deprecated."
            if isinstance(self.deprecated, str):
                msg += " " + self.deprecated
            echo(msg, err=True)
        if self.callback is None:
            return None
        with ctx:
            return self.callback(**kwargs)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        return _main(self, args, prog_name, complete_var, standalone_mode, extra)

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)


def _help_callback(ctx, param, value):
    from .termui import echo

    if not value:
        return None
    echo(format_help(ctx.command, ctx), nl=False, color=False)
    raise Exit(0)


class Group(Command):
    allow_interspersed_default = False

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, **kwargs):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name, no_args_is_help=no_args_is_help, **kwargs)
        self.commands = {}
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self.result_callback_func = result_callback
        if commands:
            for cmd in (commands.values() if isinstance(commands, dict) else commands):
                self.add_command(cmd)
        if self.subcommand_metavar is None:
            self.subcommand_metavar = "COMMAND [ARGS]..."
            if chain:
                self.subcommand_metavar = "COMMAND1 [ARGS]... [COMMAND2 [ARGS]...]..."

    # -- registration ------------------------------------------------------
    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise TypeError("A group cannot be nested under a chaining group.")
        key = name or cmd.name
        if not key:
            raise ValueError("A command needs a name.")
        self.commands[key] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as _command

        def decorator(f):
            cmd = _command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd
        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as _group

        def decorator(f):
            cmd = _group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd
        return decorator

    def result_callback(self):
        def decorator(f):
            self.result_callback_func = f
            return f
        return decorator

    # -- lookup (override points) -------------------------------------------
    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        norm = ctx.token_normalize_func if ctx is not None else None
        if norm:
            for n, c in self.commands.items():
                if norm(n) == norm(cmd_name):
                    return c
        return None

    def visible_children(self, ctx):
        out = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            out.append((name, cmd))
        return out

    # -- parsing -----------------------------------------------------------
    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help:
            raise NoArgsHelp("", ctx)
        params = self._params_for(ctx)
        slots = 0
        variadic = False
        for a in self.arguments:
            slots += a.slots
            variadic = variadic or a.variadic
        interspersed = ctx.allow_interspersed_args
        stop = None if interspersed else slots
        res = parse_tokens(ctx, params, args, interspersed=False, stop_after_slots=stop,
                           ignore_unknown=bool(ctx.ignore_unknown_options))
        if res.eager is not None:
            eager = res.eager
            if eager.callback is not None:
                eager.callback(ctx, eager, True)
            raise Exit(0)
        kwargs = resolve_options(ctx, self.params, res)
        arg_kwargs, consumed = resolve_arguments(ctx, self.arguments, [t for _, t in res.positional], res)
        kwargs.update(arg_kwargs)
        ctx._kwargs = kwargs
        if res.rest_index is not None and res.rest_index < len(args):
            ctx._rest = list(args[res.rest_index:])
        else:
            ctx._rest = []
        if not ctx._rest:
            # tokens consumed by arguments beyond the declared arity are an error
            leftover = [t for _, t in res.positional][consumed:]
            if leftover and not ctx.allow_extra_args:
                pass

    def invoke(self, ctx):
        rest = ctx._rest
        if self.chain:
            return self._invoke_chain(ctx, rest)
        if not rest:
            if self.invoke_without_command:
                ctx.invoked_subcommand = None
                rv = self._run_group_callback(ctx)
                return self._finish_result(ctx, rv)
            raise MissingCommand("Missing command.", ctx)
        name = rest[0]
        sub = self.get_command(ctx, name)
        if sub is None:
            raise UsageError(f"No such command '{name}'.", ctx)
        ctx.invoked_subcommand = name
        self._run_group_callback(ctx)
        sub_ctx = sub.make_context(name, rest[1:], parent=ctx)
        rv = sub.invoke(sub_ctx)
        return self._finish_result(ctx, rv)

    def _run_group_callback(self, ctx):
        if self.callback is None:
            return None
        return self.invoke_with(ctx, ctx._kwargs)

    def _finish_result(self, ctx, rv):
        if self.result_callback_func is not None:
            with ctx:
                return self.result_callback_func(rv, **ctx._kwargs)
        return rv

    def _invoke_chain(self, ctx, rest):
        ctx.invoked_subcommand = _CHAIN if rest else None
        self._run_group_callback(ctx)
        results = []
        if rest and self.get_command(ctx, rest[0]) is None:
            raise UsageError(f"No such command '{rest[0]}'.", ctx)
        i = 0
        while i < len(rest):
            name = rest[i]
            sub = self.get_command(ctx, name)
            if sub is None:
                raise UsageError(f"No such command '{name}'.", ctx)
            j = i + 1
            while j < len(rest) and self.get_command(ctx, rest[j]) is None:
                j += 1
            sub_ctx = sub.make_context(name, rest[i + 1:j], parent=ctx)
            results.append(sub.invoke(sub_ctx))
            i = j
        if self.result_callback_func is not None:
            with ctx:
                return self.result_callback_func(results, **ctx._kwargs)
        return results


class CommandCollection(Group):
    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = []
        for src in self.sources:
            for n in src.list_commands(ctx):
                if n not in names:
                    names.append(n)
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        for src in self.sources:
            c = src.get_command(ctx, cmd_name)
            if c is not None:
                return c
        return super().get_command(ctx, cmd_name)

    def add_command(self, cmd, name=None):
        raise TypeError("Use the sources list of a CommandCollection.")


# ----------------------------------------------------------------------
# Standalone runner
# ----------------------------------------------------------------------

def _prog_name_from_argv():
    prog = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "cli"
    if os.name == "nt" and prog.lower().endswith(".exe"):
        prog = prog[:-4]
    return prog


def _main(cmd, args, prog_name, complete_var, standalone, extra):
    if args is None:
        args = sys.argv[1:]
    prog = prog_name or _prog_name_from_argv()
    var = complete_var or "_" + prog.upper().replace("-", "_") + "_COMPLETE"
    value = os.environ.get(var)
    if value:
        from . import completion

        handled = completion.handle(cmd, prog, value, args)
        if standalone:
            sys.exit(0 if handled else 1)
        return None
    ctx = Context(cmd, info_name=prog, **cmd._settings(extra))
    try:
        with ctx:
            cmd.parse_args(ctx, list(args))
            rv = cmd.invoke(ctx)
            return rv
    except Exit as e:
        if standalone:
            sys.exit(e.exit_code)
        return None
    except OptlynError as e:
        if not standalone:
            raise
        e.show()
        sys.exit(e.exit_code)
    except (KeyboardInterrupt, EOFError):
        if not standalone:
            raise
        from .termui import echo

        echo("Aborted!", err=True)
        sys.exit(1)
    finally:
        ctx.close()
