"""File opening helpers with dash-as-stdin/stdout and lazy/atomic modes (FP-09)."""

from __future__ import annotations

import contextlib
import io
import os
import sys
import tempfile


class LazyFile:
    """A file object that opens on first I/O (used for lazy write mode)."""

    def __init__(self, filename, mode, encoding, errors, atomic):
        self.name = filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self._tmp = None
        self.closed = False

    def _open(self):
        if self._f is not None:
            return self._f
        kwargs = {}
        if "b" not in self.mode:
            kwargs = {"encoding": self.encoding, "errors": self.errors}
        if self.atomic:
            d = os.path.dirname(os.path.abspath(self.name))
            fd, self._tmp = tempfile.mkstemp(dir=d, prefix=".optlyn-")
            os.close(fd)
            self._f = open(self._tmp, self.mode, **kwargs)
        else:
            self._f = open(self.name, self.mode, **kwargs)
        return self._f

    def __getattr__(self, item):
        return getattr(self._open(), item)

    def write(self, data):
        return self._open().write(data)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self._f is not None:
            self._f.close()
            if self.atomic and self._tmp:
                os.replace(self._tmp, self.name)


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or a standard stream for '-'.

    Returns a context manager-capable file object. Standard streams are not
    closed when the caller's block ends.
    """
    filename = os.fspath(filename) if not isinstance(filename, str) else filename
    binary = "b" in mode
    writing = "w" in mode
    if filename == "-":
        if writing:
            stream = sys.stdout.buffer if binary else sys.stdout
        else:
            stream = sys.stdin.buffer if binary else sys.stdin
        return _StdStream(stream)
    if writing and lazy:
        return LazyFile(filename, mode, encoding, errors, atomic)
    kwargs = {} if binary else {"encoding": encoding, "errors": errors}
    if writing and atomic:
        d = os.path.dirname(os.path.abspath(filename))
        fd, tmp = tempfile.mkstemp(dir=d, prefix=".optlyn-")
        os.close(fd)
        return _AtomicFile(open(tmp, mode, **kwargs), tmp, filename)
    return open(filename, mode, **kwargs)


class _StdStream:
    """Wrapper that delegates to a std stream and does not close it."""

    def __init__(self, stream):
        self._s = stream

    def __getattr__(self, item):
        return getattr(self._s, item)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        try:
            self._s.flush()
        except Exception:
            pass
        return False

    def close(self):
        try:
            self._s.flush()
        except Exception:
            pass

    def __iter__(self):
        return iter(self._s)


class _AtomicFile:
    def __init__(self, f, tmp, target):
        self._f = f
        self._tmp = tmp
        self._target = target
        self.name = target

    def __getattr__(self, item):
        return getattr(self._f, item)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def close(self):
        if not self._f.closed:
            self._f.close()
            os.replace(self._tmp, self._target)
