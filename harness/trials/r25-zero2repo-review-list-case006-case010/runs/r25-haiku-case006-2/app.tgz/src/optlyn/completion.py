"""Shell completion (FP-12). Source and complete modes for bash, zsh, fish, powershell."""

from __future__ import annotations

import os
import sys

SHELLS = ("bash", "zsh", "fish", "powershell")


def _script(shell, prog, var):
    if shell == "bash":
        return (
            f"_{prog.replace('-', '_')}_completion() {{\n"
            f"    local IFS=$'\\n'\n"
            f"    COMPREPLY=( $(env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
            f"{var}=bash_complete {prog}) )\n"
            f"    return 0\n}}\n"
            f"complete -o default -F _{prog.replace('-', '_')}_completion {prog}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog}\n"
            f"_{prog.replace('-', '_')}_completion() {{\n"
            f"    local -a completions\n"
            f"    completions=(\"${{(@f)$(env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) "
            f"{var}=zsh_complete {prog})}}\")\n"
            f"    _describe '{prog}' completions\n}}\n"
            f"compdef _{prog.replace('-', '_')}_completion {prog}\n"
        )
    if shell == "fish":
        return (
            f"complete --no-files --command {prog} --arguments "
            f"\"(env {var}=fish_complete COMP_WORDS=(commandline -cp) "
            f"COMP_CWORD=(commandline -ct) {prog})\"\n"
        )
    return (
        f"Register-ArgumentCompleter -Native -CommandName {prog} -ScriptBlock {{\n"
        f"    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString()\n"
        f"    $env:COMP_CWORD = $wordToComplete\n"
        f"    $env:{var} = 'powershell_complete'\n"
        f"    & {prog} | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_) }}\n"
        f"    Remove-Item Env:{var}\n}}\n"
    )


def _walk(cmd, ctx, words):
    """Descend into groups for the words typed before the incomplete token."""
    from .core import Context, Group

    node = cmd
    current_ctx = ctx
    for w in words:
        if not isinstance(node, Group):
            break
        sub = node.get_command(current_ctx, w)
        if sub is None:
            continue
        node = sub
    return node


def suggestions(cmd, prog, words, cword, incomplete):
    from .core import Context, Group
    from .params import Option
    from .types import Choice

    ctx = Context(cmd, info_name=prog)
    before = words[1:cword] if cword > 1 else []
    target = _walk(cmd, ctx, before)
    out = []
    # previous word may be an option expecting a value: choice values
    if cword >= 2:
        prev = words[cword - 1]
        for p in getattr(target, "params", []):
            if isinstance(p, Option) and prev in p.all_names and p.takes_value:
                if p.shell_complete_func is not None or isinstance(p.type, Choice):
                    for s in p.shell_complete(ctx, incomplete):
                        v = s if isinstance(s, str) else getattr(s, "value", str(s))
                        if v.startswith(incomplete):
                            out.append(v)
                    return out
    if incomplete.startswith("-"):
        names = []
        for p in getattr(target, "params", []):
            if isinstance(p, Option) and not p.hidden:
                names.extend(p.all_names)
        help_opt = target.get_help_option(ctx) if hasattr(target, "get_help_option") else None
        if help_opt is not None:
            names.extend(help_opt.all_names)
        for n in names:
            if n.startswith(incomplete) and n not in out:
                out.append(n)
        return out
    if isinstance(target, Group):
        for name, sub in target.visible_children(ctx):
            if name.startswith(incomplete):
                out.append(name)
    return out


def handle(cmd, prog, value, args):
    """Handle the completion variable. Returns True when the value was recognised."""
    if "_" not in value:
        return False
    shell, _, mode = value.partition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        return False
    var = "_" + prog.upper().replace("-", "_") + "_COMPLETE"
    out = sys.stdout
    if mode == "source":
        out.write(_script(shell, prog, var))
        out.flush()
        return True
    raw = os.environ.get("COMP_WORDS", "")
    words = raw.split()
    if shell == "fish":
        incomplete = os.environ.get("COMP_CWORD", "")
        cword = len(words)
        if incomplete:
            words = words + [incomplete]
            cword = len(words) - 1
    else:
        try:
            cword = int(os.environ.get("COMP_CWORD", str(len(words))))
        except ValueError:
            cword = len(words)
        incomplete = words[cword] if 0 <= cword < len(words) else ""
    for s in suggestions(cmd, prog, words, cword, incomplete):
        out.write(s + "\n")
    out.flush()
    return True
