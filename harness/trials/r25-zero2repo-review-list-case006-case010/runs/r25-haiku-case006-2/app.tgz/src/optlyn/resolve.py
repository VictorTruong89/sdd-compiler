"""Value resolution: sources, conversion, callbacks, argument binding (FP-03, FP-04, FP-07, FP-08)."""

from __future__ import annotations

import os

from .exceptions import Abort, UsageError
from .params import Source, _auto_env_name
from .types import BadParameter

_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}
_MISSING = object()


def _convert(p, value, ctx):
    try:
        return p.type.convert(value, p, ctx)
    except BadParameter as e:
        raise UsageError(f"Invalid value for {p.label()}: {e.message}", ctx) from None


def _group(p, vals, ctx):
    """Convert one occurrence of a multi-value parameter (nargs > 1 or a tuple type)."""
    vals = list(vals)
    if p.type.is_composite:
        return _convert(p, tuple(vals), ctx)
    return tuple(_convert(p, v, ctx) for v in vals)


def _occurrence(p, v, ctx):
    """Convert one occurrence, which is a scalar or a group of nargs tokens."""
    if p.type.is_composite or p.nargs != 1:
        return _group(p, v, ctx)
    return _convert(p, v, ctx)


def _split_env(p, text):
    if p.type.is_composite or p.nargs != 1 or p.multiple:
        return list(p.type.split_env(text))
    return [text]


def _env_text(p, ctx):
    """Return the first non-empty environment value for `p`, or None (FP-03, FP-07)."""
    names = p.envvar
    if names is None:
        names = []
    elif isinstance(names, str):
        names = [names]
    else:
        names = list(names)
    if p.allow_from_autoenv and not p.is_argument and ctx.auto_envvar_prefix:
        auto = _auto_env_name(ctx, p.name)
        if auto not in names:
            names.append(auto)
    for n in names:
        v = os.environ.get(n)
        if v is not None and v != "":
            return v
    return None


def _env_flag(p, text, ctx):
    t = text.strip().lower()
    if t == "":
        return _MISSING
    fv = p.flag_value
    custom = not isinstance(fv, bool)
    if custom and t == str(fv).lower():
        return fv
    if t in _TRUE:
        return fv if fv is not None else True
    if t in _FALSE:
        return False
    if custom:
        return _MISSING
    raise UsageError(f"Invalid value for {p.label()}: {text!r} is not a valid boolean.", ctx)


def _default_value(p):
    d = p.default
    if callable(d):
        d = d()
    return d


def _from_default(p, d, ctx):
    """Convert a declared default for a value-taking parameter."""
    if p.multiple:
        if d is None:
            return ()
        if isinstance(d, (str, bytes)) or not hasattr(d, "__iter__"):
            raise UsageError(
                f"{p.label()}: the default needs an iterable (sequence) value.", ctx)
        return tuple(_occurrence(p, item, ctx) for item in d)
    if d is None:
        return None
    return _occurrence(p, d, ctx)


def _from_dm(p, raw, ctx):
    if p.is_flag:
        return raw
    if p.count:
        return _convert(p, raw, ctx)
    if isinstance(raw, (str, bytes)):
        text = raw if isinstance(raw, str) else raw.decode()
        if p.multiple and p.nargs == 1:
            raise UsageError(
                f"{p.label()}: the default map needs an iterable (sequence) value, not text.",
                ctx)
        if p.type.is_composite or p.nargs != 1:
            return _from_env(p, text, ctx)
        return _convert(p, text, ctx)
    return _from_default(p, raw, ctx)


def _from_env(p, text, ctx):
    parts = _split_env(p, text)
    if p.multiple:
        if p.nargs in (1, -1) and not p.type.is_composite:
            return tuple(_convert(p, x, ctx) for x in parts)
        width = p.nargs if not p.type.is_composite else len(p.type.types)
        chunks = [parts[k:k + width] for k in range(0, len(parts), width)]
        return tuple(_group(p, c, ctx) for c in chunks)
    if p.type.is_composite or p.nargs != 1:
        width = len(p.type.types) if p.type.is_composite else p.nargs
        return _group(p, parts[:width], ctx)
    return _convert(p, text, ctx)


def _from_cli(p, entries, ctx):
    if p.multiple:
        return tuple(_occurrence(p, v, ctx) for _, v in entries)
    return _occurrence(p, entries[-1][1], ctx)


def _prompt(p, ctx, dm_raw, has_dm):
    from . import termui

    text = p.prompt if isinstance(p.prompt, str) else p.name.replace("_", " ").capitalize()
    default = dm_raw if has_dm else p.default
    if callable(default):
        default = default()
    try:
        return termui.prompt(
            text, default=default, hide_input=p.hide_input,
            confirmation_prompt=p.confirmation_prompt, type=p.type,
        )
    except EOFError:
        raise Abort() from None


def _deprecation(p):
    from . import termui

    kind = "argument" if p.is_argument else "option"
    msg = f"DeprecationWarning: The {kind} '{p.label()}' is deprecated."
    if isinstance(p.deprecated, str):
        msg += " " + p.deprecated
    termui.echo(msg, err=True)


def resolve_options(ctx, params, res):
    """Resolve every option of a command into ctx.params; return kwargs for the callback."""
    kwargs = {}
    seen = []
    for p in params:
        if not p.is_argument and p.name not in seen:
            seen.append(p.name)
    for dest in seen:
        plist = [p for p in params if not p.is_argument and p.name == dest]
        value = _resolve_option(ctx, plist, dest, res)
        for p in plist:
            if p.deprecated and p in res.deprecated_seen:
                _deprecation(p)
        _run_callback_and_store(ctx, plist[0], value, kwargs)
    return kwargs


def _resolve_option(ctx, plist, dest, res):
    p = plist[0]
    entries = res.cli.get(dest, [])
    dm = ctx.default_map
    has_dm = isinstance(dm, dict) and dest in dm
    dm_raw = dm.get(dest) if has_dm else None
    winner = entries[-1][0] if entries else p   # most explicit feature-switch winner

    if p.count:
        if dest in res.counts:
            _set_source(ctx, dest, Source.COMMANDLINE)
            return res.counts[dest]
        _set_source(ctx, dest, Source.DEFAULT)
        return 0

    if p.is_flag:
        if entries:
            _set_source(ctx, dest, Source.COMMANDLINE)
            return entries[-1][1]
        env = _env_text(winner, ctx)
        if env is not None:
            v = _env_flag(winner, env, ctx)
            if v is not _MISSING:
                _set_source(ctx, dest, Source.ENVIRONMENT)
                return v
        if has_dm:
            _set_source(ctx, dest, Source.DEFAULT_MAP)
            return _from_dm(p, dm_raw, ctx)
        _set_source(ctx, dest, Source.DEFAULT)
        d = _default_value(p)
        return False if d is None else d

    if entries:
        _set_source(ctx, dest, Source.COMMANDLINE)
        return _from_cli(p, entries, ctx)
    if dest in res.prompt_now:
        _set_source(ctx, dest, Source.PROMPT)
        return _prompt(p, ctx, dm_raw, has_dm)
    env = _env_text(p, ctx)
    if env is not None:
        _set_source(ctx, dest, Source.ENVIRONMENT)
        return _from_env(p, env, ctx)
    if p.prompt and (p.prompt_required or p.required):
        _set_source(ctx, dest, Source.PROMPT)
        return _prompt(p, ctx, dm_raw, has_dm)
    if has_dm:
        _set_source(ctx, dest, Source.DEFAULT_MAP)
        return _from_dm(p, dm_raw, ctx)
    if p.default is not None:
        _set_source(ctx, dest, Source.DEFAULT)
        return _from_default(p, _default_value(p), ctx)
    _set_source(ctx, dest, None)
    return () if p.multiple else None


def _set_source(ctx, dest, src):
    ctx._sources[dest] = src


def _run_callback_and_store(ctx, p, value, kwargs):
    # confirmation option: a flag that asks when omitted; a decline aborts (FP-08)
    if getattr(p, "confirm_text", None) is not None and not value:
        from . import termui

        if termui.confirm(p.confirm_text, default=False, abort=False) is False:
            raise Abort()
        value = True
        _set_source(ctx, p.name, Source.PROMPT)
    if p.required and value is None and ctx._sources.get(p.name) is None:
        raise UsageError(f"Missing option '{p.label()}'.", ctx)
    if p.callback is not None:
        try:
            value = p.callback(ctx, p, value)
        except BadParameter as e:
            raise UsageError(f"Invalid value for {p.label()}: {e.message}", ctx) from None
    ctx.params[p.name] = value
    if p.expose_value:
        kwargs[p.name] = value


def resolve_arguments(ctx, arguments, positional, res):
    """Bind positional tokens to declared arguments; return (kwargs, consumed_count)."""
    kwargs = {}
    tokens = list(positional)
    idx = 0
    for a in arguments:
        dest = a.name
        dm = ctx.default_map
        has_dm = isinstance(dm, dict) and dest in dm
        dm_raw = dm.get(dest) if has_dm else None
        if a.variadic:
            taken = tokens[idx:]
        elif a.nargs == 1:
            taken = tokens[idx:idx + 1]
        else:
            taken = tokens[idx:idx + a.nargs]
            if taken and len(taken) < a.nargs:
                raise UsageError(
                    f"Argument '{a.name}' takes {a.nargs} values, got {len(taken)}.", ctx)
        idx += len(taken)

        value = _MISSING
        if taken:
            _set_source(ctx, dest, Source.COMMANDLINE)
            if a.variadic:
                value = tuple(_convert(a, t, ctx) for t in taken)
            elif a.multiple:
                value = tuple(_occurrence(a, t, ctx) for t in taken)
            else:
                value = _occurrence(a, taken[0] if a.nargs == 1 else taken, ctx)
        elif a.envvar is not None and _env_text(a, ctx) is not None:
            _set_source(ctx, dest, Source.ENVIRONMENT)
            value = _from_env(a, _env_text(a, ctx), ctx)
        elif has_dm:
            _set_source(ctx, dest, Source.DEFAULT_MAP)
            value = _from_dm(a, dm_raw, ctx)
        elif a.default is not None:
            _set_source(ctx, dest, Source.DEFAULT)
            value = _from_default(a, _default_value(a), ctx)
        else:
            _set_source(ctx, dest, None)

        if value is _MISSING:
            if a.required:
                raise UsageError(f"Missing argument '{a.name}'.", ctx)
            value = () if (a.variadic or a.multiple) else None
        if a.deprecated and taken:
            _deprecation(a)
        _run_callback_and_store(ctx, a, value, kwargs)
    return kwargs, idx


def check_extra(ctx, leftover, allow_extra, ignore_unknown):
    """Leftover tokens: an error unless extra args are allowed; option-shaped ones always error."""
    if not leftover:
        return
    if not allow_extra:
        raise UsageError(
            f"Got unexpected extra argument{'s' if len(leftover) > 1 else ''} "
            f"({' '.join(leftover)})", ctx)
    for t in leftover:
        if len(t) > 1 and t[0] in "-/+":
            raise UsageError(f"Got unexpected extra argument ({t})", ctx)
