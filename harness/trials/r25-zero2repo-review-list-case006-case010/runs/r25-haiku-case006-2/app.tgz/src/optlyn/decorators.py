"""Declaration decorators and ready-made options (FP-01, FP-02, FP-03, FP-08)."""

from __future__ import annotations

import functools
import os
import sys

from ._stack import current
from .core import Command, CommandCollection, Group
from .exceptions import Exit
from .params import Argument, Option


def _pending(f):
    if not hasattr(f, "__optlyn_params__"):
        f.__optlyn_params__ = []
    return f.__optlyn_params__


def _derive_name(f):
    name = f.__name__.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _take_params(f):
    pending = getattr(f, "__optlyn_params__", None)
    if pending is None:
        return []
    params = list(reversed(pending))
    try:
        del f.__optlyn_params__
    except AttributeError:
        pass
    return params


def _make(cls, default_cls, name, f_or_none, attrs):
    cls = cls or default_cls

    def decorator(f):
        params = _take_params(f)
        attrs2 = dict(attrs)
        if "help" not in attrs2 or attrs2["help"] is None:
            attrs2["help"] = f.__doc__
        cmd_name = name if name is not None else _derive_name(f)
        return cls(name=cmd_name, callback=f, params=params, **attrs2)

    if callable(f_or_none) and not isinstance(f_or_none, type):
        return decorator(f_or_none)
    return decorator


def command(name=None, cls=None, **attrs):
    """Declare a leaf command from a function. Used as `@command()` or `@command`."""
    if callable(name) and not isinstance(name, str):
        return _make(cls, Command, None, name, attrs)
    return _make(cls, Command, name, None, attrs)


def group(name=None, cls=None, **attrs):
    """Declare a group from a function. Used as `@group()` or `@group`."""
    if callable(name) and not isinstance(name, str):
        return _make(cls, Group, None, name, attrs)
    return _make(cls, Group, name, None, attrs)


def option(*param_decls, cls=None, **attrs):
    cls = cls or Option

    def decorator(f):
        p = cls(list(param_decls), **attrs)
        _pending(f).append(p)
        return f
    return decorator


def argument(*param_decls, cls=None, **attrs):
    cls = cls or Argument

    def decorator(f):
        p = cls(list(param_decls), **attrs)
        _pending(f).append(p)
        return f
    return decorator


def help_option(*param_decls, **kwargs):
    from .core import _help_callback

    names = list(param_decls) or ["--help"]
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("callback", _help_callback)

    def decorator(f):
        p = Option(names, is_flag=True, is_eager=True, **kwargs)
        _pending(f).append(p)
        return f
    return decorator


def _package_version(package_name):
    from importlib import metadata

    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    try:
        mapping = metadata.packages_distributions()
        dists = mapping.get(package_name) or []
        for dist in dists:
            try:
                return metadata.version(dist)
            except metadata.PackageNotFoundError:
                continue
    except Exception:
        pass
    return "unknown"


def version_option(version=None, *param_decls, package_name=None, prog_name=None,
                   message=None, **kwargs):
    names = list(param_decls) or ["--version"]
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs.setdefault("expose_value", False)

    def callback(ctx, param, value):
        if not value or ctx is None:
            return None
        ver = version
        if ver is None:
            ver = _package_version(package_name or (prog_name or ctx.info_name or "").split()[0])
        prog = prog_name or ctx.info_name
        text = message if message is not None else "%(prog)s, version %(version)s"
        from .termui import echo

        echo(text % {"prog": prog, "version": ver}, color=False)
        raise Exit(0)

    def decorator(f):
        p = Option(names, is_flag=True, is_eager=True, callback=callback, **kwargs)
        _pending(f).append(p)
        return f
    return decorator


def custom_version_option(callback_fn, *param_decls, **kwargs):
    names = list(param_decls) or ["--version"]
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs.setdefault("expose_value", False)

    def callback(ctx, param, value):
        if not value or ctx is None:
            return None
        from .termui import echo

        echo(str(callback_fn(ctx)) + "\n", nl=False, color=False)
        raise Exit(0)

    def decorator(f):
        p = Option(names, is_flag=True, is_eager=True, callback=callback, **kwargs)
        _pending(f).append(p)
        return f
    return decorator


def password_option(*param_decls, **kwargs):
    names = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("help", "The password to use.")

    def decorator(f):
        p = Option(names, **kwargs)
        _pending(f).append(p)
        return f
    return decorator


def confirmation_option(*param_decls, **kwargs):
    names = list(param_decls) or ["--yes"]
    text = kwargs.pop("prompt", None) or "Do you want to continue?"
    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_flag", True)

    def decorator(f):
        p = Option(names, **kwargs)
        p.confirm_text = text
        _pending(f).append(p)
        return f
    return decorator


# ----------------------------------------------------------------------
# Callback context passing
# ----------------------------------------------------------------------

def _current_or_raise():
    return current()


def pass_context(f):
    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(_current_or_raise(), *args, **kwargs)
    return new_func


def pass_obj(f):
    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(_current_or_raise().obj, *args, **kwargs)
    return new_func


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = _current_or_raise()
            node = ctx
            found = None
            while node is not None:
                if isinstance(node.obj, object_type):
                    found = node.obj
                    break
                node = node.parent
            if found is None:
                if ensure:
                    found = object_type()
                    ctx.obj = found
                else:
                    raise RuntimeError(f"Managed to find no object of type {object_type.__name__}.")
            return f(found, *args, **kwargs)
        return new_func
    return decorator
