"""Text wrapping and help-page rendering (FP-02, FP-11; Contract section 2)."""

from __future__ import annotations

import re
import shutil
import textwrap

from .params import Argument, Option
from .types import Choice

DEFAULT_MAX_CONTENT_WIDTH = 80
SHORT_HELP_LIMIT = 45


def wrap_text(text, width=100, initial_indent="", subsequent_indent="",
              preserve_paragraphs=False):
    """Rewrap text. Single newlines inside a paragraph are not kept as breaks.

    A paragraph whose first line is only a backspace is not rewrapped; its line
    breaks are kept and the backspace line is stripped.
    """
    if text is None:
        return ""
    text = str(text)
    out = []
    paragraphs = re.split(r"\n\s*\n", text.strip("\n"))
    for para in paragraphs:
        lines = para.split("\n")
        if lines and lines[0].strip() == "\b":
            kept = [ln for ln in lines[1:]]
            out.append("\n".join(subsequent_indent + ln for ln in kept))
            continue
        flat = " ".join(ln.strip() for ln in lines if ln.strip())
        if not flat:
            continue
        wrapped = textwrap.fill(
            flat, width=max(width, 10),
            initial_indent=initial_indent if not out else subsequent_indent,
            subsequent_indent=subsequent_indent,
            break_long_words=True, break_on_hyphens=False,
        )
        out.append(wrapped)
    return "\n\n".join(out)


def clean_help(text):
    """Remove everything after a form feed (PRD FP-02, see NOTES C-01)."""
    if text is None:
        return None
    return text.split("\f", 1)[0]


def first_sentence(text):
    text = " ".join((text or "").split())
    if not text:
        return ""
    m = re.match(r"(.+?[.!?])(\s|$)", text)
    return m.group(1) if m else text


def short_help_text(cmd, width=None):
    """Short help for a child on a group page (C-02: first sentence, cut at 45 chars)."""
    if getattr(cmd, "short_help", None):
        text = cmd.short_help
    else:
        text = first_sentence(clean_help(cmd.help_text) or "")
    if len(text) > SHORT_HELP_LIMIT:
        text = text[: SHORT_HELP_LIMIT - 3].rstrip() + "..."
    return text


def _content_width(ctx):
    if ctx.terminal_width:
        return int(ctx.terminal_width)
    auto = shutil.get_terminal_size((80, 24)).columns
    cap = ctx.max_content_width or DEFAULT_MAX_CONTENT_WIDTH
    return min(auto, cap)


def _visible_options(params):
    return [p for p in params if isinstance(p, Option) and not p.hidden and not p.is_argument]


def _option_names(p):
    if p.secondary_opts:
        return "/".join(p.opts + p.secondary_opts)
    return ", ".join(p.opts)


def _option_extras(p, ctx):
    extras = []
    if isinstance(p.type, Choice) and p.is_flag is False and not p.count:
        extras.append("choices: " + " | ".join(p.type._tokens))
    if p.envvar and p.show_envvar:
        names = p.envvar if isinstance(p.envvar, str) else ", ".join(p.envvar)
        extras.append(f"env var: {names}")
    show = p.show_default
    if show is None:
        show = ctx.show_default
    # a single-option flag whose default is off stays hidden even with show-default (NOTES C-06)
    hidden_flag_default = p.is_flag and p.default is False
    if show and p.default is not None and not hidden_flag_default:
        if isinstance(show, str):
            extras.append(f"default: {show}")
        else:
            d = p.default() if callable(p.default) else p.default
            extras.append(f"default: {d}")
    return extras


def show_flag_default(p):
    return False


def format_option_entry(p, ctx, width):
    names = _option_names(p)
    metavar = p.get_metavar()
    head = names + (f" {metavar}" if metavar else "")
    help_text = p.help or ""
    extras = _option_extras(p, ctx)
    if extras:
        help_text = (help_text + " " if help_text else "") + "[" + "; ".join(extras) + "]"
    if p.deprecated:
        help_text = (help_text + " " if help_text else "") + "(deprecated)"
    return _two_col(head, help_text, width)


def _two_col(head, text, width, indent=2, gap=2, head_max=30):
    if not text:
        return " " * indent + head
    col = min(max(len(head) + indent + gap, 0), head_max + indent)
    if len(head) + indent + gap > head_max + indent:
        lines = [" " * indent + head]
        body = wrap_text(text, width=width - (head_max + indent + gap), )
        for ln in body.split("\n"):
            lines.append(" " * (head_max + indent + gap) + ln)
        return "\n".join(lines)
    body = wrap_text(text, width=max(width - col, 20))
    body_lines = body.split("\n")
    lines = [" " * indent + head.ljust(col - indent - gap) + " " * gap + body_lines[0]]
    for ln in body_lines[1:]:
        lines.append(" " * col + ln)
    return "\n".join(lines)


def usage_pieces(cmd, ctx):
    """Return the usage line (without the 'Usage: ' label)."""
    prog = ctx.command_path
    pieces = [prog]
    if any(not p.hidden for p in _visible_options(cmd.params)) or cmd.options_metavar:
        pieces.append(cmd.options_metavar or "[OPTIONS]")
    for a in cmd.arguments:
        pieces.append(_arg_usage(a))
    if getattr(cmd, "subcommand_metavar", None):
        if getattr(cmd, "chain", False):
            pieces.append("COMMAND1 [ARGS]... [COMMAND2 [ARGS]...]...")
        elif getattr(cmd, "invoke_without_command", False):
            pieces.append("[COMMAND] [ARGS]...")
        else:
            pieces.append("COMMAND [ARGS]...")
    return pieces


def _arg_usage(a):
    name = a.get_metavar()
    if a.variadic:
        s = f"[{name}]..." if not a.required else f"{name}..."
        return s
    if a.nargs > 1:
        s = " ".join([name] * a.nargs)
        return s if a.required else f"[{s}]"
    return name if a.required else f"[{name}]"


def format_usage(cmd, ctx):
    return "Usage: " + " ".join(usage_pieces(cmd, ctx)) + (
        " " + cmd.usage_suffix if getattr(cmd, "usage_suffix", "") else "")


def format_help(cmd, ctx):
    width = _content_width(ctx)
    lines = [format_usage(cmd, ctx), ""]
    if getattr(cmd, "deprecated", False):
        note = "(Deprecated)"
        if isinstance(cmd.deprecated, str):
            note += " " + cmd.deprecated
        lines.append(note)
        lines.append("")
    if cmd.help_text:
        lines.append(wrap_text(cmd.help_text, width=width))
        lines.append("")
    args_with_help = [a for a in cmd.arguments if a.help and not a.hidden]
    if args_with_help:
        lines.append("Positional arguments:")
        for a in args_with_help:
            lines.append(_two_col(a.get_metavar(), a.help, width))
        lines.append("")
    opts = [p for p in cmd.params if isinstance(p, Option) and not p.hidden]
    if opts:
        lines.append("Options:")
        for p in opts:
            lines.append(format_option_entry(p, ctx, width))
        lines.append("")
    children = cmd.visible_children(ctx) if hasattr(cmd, "visible_children") else []
    if children:
        lines.append("Commands:")
        col = max(len(n) for n, _ in children)
        for name, sub in children:
            text = short_help_text(sub)
            lines.append("  " + name.ljust(col) + "  " + text)
        lines.append("")
    if cmd.epilog:
        lines.append(wrap_text(cmd.epilog, width=width))
        lines.append("")
    while lines and lines[-1] == "":
        lines.pop()
    return "\n".join(lines) + "\n"
