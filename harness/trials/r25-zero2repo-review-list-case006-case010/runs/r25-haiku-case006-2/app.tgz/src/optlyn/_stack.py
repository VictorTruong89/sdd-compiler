"""Thread-local stack of current invocation contexts (FP-07, FP-11)."""

from __future__ import annotations

import threading

_local = threading.local()


def _stack():
    s = getattr(_local, "stack", None)
    if s is None:
        s = []
        _local.stack = s
    return s


def push(ctx):
    _stack().append(ctx)


def pop():
    s = _stack()
    if s:
        s.pop()


def current(silent=False):
    s = _stack()
    if s:
        return s[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


def current_or_none():
    s = _stack()
    return s[-1] if s else None
