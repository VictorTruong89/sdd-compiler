"""In-process runner (FP-14; Contract section 9)."""

from __future__ import annotations

import contextlib
import io
import os
import shutil
import sys
import tempfile


class _Stream(io.TextIOBase):
    """A capture stream that records text in write order and keeps bytes."""

    def __init__(self, log, charset, name):
        super().__init__()
        self._log = log
        self._charset = charset
        self._name = name
        self.bio = io.BytesIO()
        self.buffer = self.bio

    @property
    def encoding(self):
        return self._charset

    def write(self, s):
        if not isinstance(s, str):
            s = s.decode(self._charset, "replace")
        self.bio.write(s.encode(self._charset, "replace"))
        self._log.append((self._name, s))
        return len(s)

    def flush(self):
        pass

    def isatty(self):
        return False

    def fileno(self):
        raise io.UnsupportedOperation("fileno")


class Result:
    def __init__(self, runner, stdout_bytes, stderr_bytes, log, exit_code, exception, exc_info):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info
        self._log = log
        self._cs = runner.charset

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self._cs, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self._cs, "replace")

    @property
    def output(self):
        return "".join(s for _, s in self._log)

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False,
                 catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None):
        log = []
        out = _Stream(log, self.charset, "stdout")
        err = _Stream(log, self.charset, "stderr")
        if input is None:
            data = b""
        elif isinstance(input, str):
            data = input.encode(self.charset)
        else:
            data = input
        stdin = io.TextIOWrapper(io.BytesIO(data), encoding=self.charset)
        saved = {k: os.environ.get(k) for k in set(self.env) | set(env or {})}
        merged = dict(self.env)
        merged.update(env or {})
        for k, v in merged.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = str(v)
        old_out, old_err, old_in = sys.stdout, sys.stderr, sys.stdin
        sys.stdout, sys.stderr, sys.stdin = out, err, stdin
        try:
            yield out, err, log
        finally:
            sys.stdout, sys.stderr, sys.stdin = old_out, old_err, old_in
            for k, v in saved.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False,
               **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if isinstance(args, str):
            import shlex
            args = shlex.split(args)
        args = list(args or [])
        prog_name = extra.pop("prog_name", "cli")
        standalone = extra.pop("standalone_mode", True)
        exit_code = 0
        exception = None
        exc_info = None
        with self.isolation(input=input, env=env) as (out, err, log):
            try:
                cli.main(args=args, prog_name=prog_name, standalone_mode=standalone,
                         color=color, **extra)
            except SystemExit as e:
                code = e.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    sys.stderr.write(str(code) + "\n")
                    exit_code = 1
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exc_info = sys.exc_info()
                exit_code = 1
        return Result(self, out.bio.getvalue(), err.bio.getvalue(), log, exit_code,
                      exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
            cleanup = True
        else:
            path = tempfile.mkdtemp(dir=str(temp_dir))
            cleanup = False
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if cleanup:
                shutil.rmtree(path, ignore_errors=True)
