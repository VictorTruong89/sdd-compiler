"""Terminal helpers (PRD FP-08, FP-11; Contract section 7)."""

from __future__ import annotations

import contextlib
import getpass
import io
import os
import pathlib
import shlex
import subprocess
import sys
import tempfile

from . import _state
from .exceptions import Abort, BadParameter
from .termui_style import style, unstyle
from .paramtypes import convert_type
from .fileio import open_stream


def _is_tty(stream) -> bool:
    try:
        return bool(stream is not None and stream.isatty())
    except (AttributeError, ValueError):
        return False


def is_interactive() -> bool:
    """C-21: interactive when stdin or stdout is a terminal."""
    return _is_tty(sys.stdin) or _is_tty(sys.stdout)


def _color_flag():
    ctx = _state.current(silent=True)
    return getattr(ctx, "color", None) if ctx is not None else None


def _resolve_color(color, stream):
    """Return True to keep styles, False to strip them."""
    if color is None:
        color = _color_flag()
    if color is not None:
        return bool(color)
    return _is_tty(stream)


def _write(stream, text: str):
    target = getattr(stream, "buffer", None)
    try:
        stream.write(text)
    except UnicodeEncodeError:
        if target is not None:
            stream.flush()
            target.write(text.encode("utf-8"))
        else:
            stream.write(text.encode("utf-8", "replace").decode("ascii", "replace"))
    stream.flush()


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes. Strips styles unless the stream is a terminal or color is forced."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        target = getattr(file, "buffer", None)
        if target is not None:
            file.flush()
            target.write(message + (b"\n" if nl else b""))
            target.flush()
        else:
            _write(file, message.decode("utf-8", "replace") + ("\n" if nl else ""))
        return
    text = str(message)
    if not _resolve_color(color, file):
        text = unstyle(text)
    if nl:
        text += "\n"
    _write(file, text)


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None:
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def unstyled_text(text):
    return unstyle(text)


def _read_line(hide: bool = False) -> str:
    """Read one line from stdin. EOF raises EOFError."""
    stdin = sys.stdin
    if hide and _is_tty(stdin):
        return getpass.getpass("")
    line = stdin.readline()
    if line == "" or line is None:
        raise EOFError
    line = line.rstrip("\n").rstrip("\r")
    return line


def prompt(text, default=None, hide_input=False, confirmation_prompt=False, type=None,
           value_proc=None, prompt_suffix=": ", show_default=True, err=False, show_choices=True):
    """Ask for a value until conversion succeeds. Returns the converted value."""
    ptype = convert_type(type, default)
    file = sys.stderr if err else sys.stdout
    default_value = default() if callable(default) else default
    while True:
        label = text
        if default_value is not None and show_default:
            label += f" [{default_value}]"
        _write(file, label + prompt_suffix)
        try:
            value = _read_line(hide_input)
        except EOFError as exc:
            raise Abort("Input ended while prompting.") from exc
        if not _is_tty(sys.stdin) and not hide_input:
            _write(file, value + "\n")
        elif hide_input or not _is_tty(sys.stdin):
            _write(file, "\n")
        if value == "" and default_value is not None:
            value = default_value
        if confirmation_prompt:
            _write(file, "Repeat for confirmation" + prompt_suffix)
            try:
                second = _read_line(hide_input)
            except EOFError as exc:
                raise Abort("Input ended during confirmation.") from exc
            if not _is_tty(sys.stdin) and not hide_input:
                _write(file, second + "\n")
            elif hide_input or not _is_tty(sys.stdin):
                _write(file, "\n")
            if second != value:
                _write(file, "Error: the two entered values do not match\n")
                continue
        try:
            if value_proc is not None:
                return value_proc(value)
            return ptype.convert(value)
        except BadParameter as exc:
            _write(file, f"Error: {exc.message}\n")
            continue


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True,
            err=False):
    """Ask a yes/no question. Returns a bool; aborts when asked and declined."""
    file = sys.stderr if err else sys.stdout
    suffix = " [Y/n]" if default else " [y/N]" if show_default else ""
    while True:
        _write(file, text + suffix + prompt_suffix)
        try:
            raw = _read_line()
        except EOFError as exc:
            raise Abort("Input ended while confirming.") from exc
        if not _is_tty(sys.stdin):
            _write(file, raw + "\n")
        value = raw.strip().lower()
        if value == "":
            result = default
            break
        if value in ("y", "yes"):
            result = True
            break
        if value in ("n", "no"):
            result = False
            break
        _write(file, "Error: invalid input\n")
    if not result and abort:
        raise Abort()
    return result


def getchar(echo=False):
    """Read one character from the terminal, even if stdin is a pipe."""
    try:
        import termios
        import tty

        fd = os.open("/dev/tty", os.O_RDONLY)
    except (ImportError, OSError):
        fd = None
    if fd is not None:
        try:
            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                ch = os.read(fd, 1)
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        finally:
            os.close(fd)
        if ch == b"\x03":
            raise KeyboardInterrupt
        if ch == b"\x04" or ch == b"":
            raise EOFError
        text = ch.decode("utf-8", "replace")
    else:
        text = sys.stdin.read(1)
        if text == "\x03":
            raise KeyboardInterrupt
        if text in ("\x04", ""):
            raise EOFError
    if echo:
        _write(sys.stdout, text)
    return text


def pause(info=None, err=False):
    file = sys.stderr if err else sys.stdout
    if not is_interactive():
        return
    _write(file, (info or "Press any key to continue...") + "\n")
    with contextlib.suppress(EOFError, KeyboardInterrupt):
        getchar()


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Launch an editor. Returns the saved text, or None when quit without saving or a filename was given."""
    editor = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    argv = shlex.split(editor)
    if filename is not None:
        path = str(filename)
        subprocess.call(argv + [path], env=env and {**os.environ, **env})
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as fh:
            fh.write(text or "")
        before = pathlib.Path(path).stat().st_mtime_ns
        subprocess.call(argv + [path], env=env and {**os.environ, **env})
        after = pathlib.Path(path).stat().st_mtime_ns
        if require_save and before == after:
            return None
        with open(path, encoding="utf-8", newline="") as fh:
            return fh.read()
    finally:
        with contextlib.suppress(OSError):
            os.remove(path)


def launch(url, wait=False, locate=False) -> int:
    """Open a URL or file with the default application (xdg-open on Linux)."""
    if sys.platform == "darwin":
        argv = ["open"]
    elif sys.platform == "win32":
        os.startfile(url)  # type: ignore[attr-defined]
        return 0
    else:
        argv = ["xdg-open"]
    if locate and sys.platform == "darwin":
        argv.append("-R")
    argv.append(str(url))
    try:
        proc = subprocess.Popen(argv)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def clear():
    if _is_tty(sys.stdout):
        _write(sys.stdout, "\033[2J\033[H")


def get_app_dir(app_name, roaming=True, force_posix=False) -> str:
    """Per-user config directory for an application (PRD FP-11, C-19)."""
    home = os.path.expanduser("~")
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
        return os.path.join(base, app_name)
    if force_posix:
        return os.path.join(home, "." + app_name.lower().replace(" ", "-"))
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    folder = "-".join(app_name.lower().split())
    xdg = os.environ.get("XDG_CONFIG_HOME")
    base = xdg if xdg else os.path.join(home, ".config")
    return os.path.join(base, folder)


def format_filename(filename, shorten=False) -> str:
    """Printable text for any filename; distinct names stay distinct."""
    if hasattr(filename, "__fspath__"):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        text = filename.decode("utf-8", "backslashreplace")
    else:
        if not isinstance(filename, str):
            filename = os.fsdecode(filename)
        text = filename.encode("utf-8", "surrogateescape").decode("utf-8", "backslashreplace")
    if shorten:
        text = os.path.basename(text) or text
    return text


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    return open_stream(str(filename), mode, encoding, errors, lazy=lazy, atomic=atomic)


def _pager_argv():
    cmd = os.environ.get("PAGER")
    return shlex.split(cmd) if cmd else ["less"]


def echo_via_pager(text_or_generator, color=None):
    """Write long text through a pager when interactive; otherwise plain output."""
    if callable(text_or_generator) and not isinstance(text_or_generator, str):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = text_or_generator
    keep = _resolve_color(color, sys.stdout) if is_interactive() else False
    if not is_interactive():
        for chunk in chunks:
            _write(sys.stdout, chunk if keep else unstyle(chunk))
        return
    proc = subprocess.Popen(_pager_argv(), stdin=subprocess.PIPE, text=True,
                            encoding="utf-8", errors="replace")
    try:
        for chunk in chunks:
            proc.stdin.write(chunk if keep else unstyle(chunk))
            proc.stdin.flush()
    except BrokenPipeError:
        pass
    finally:
        try:
            proc.stdin.close()
        except (BrokenPipeError, OSError):
            pass
        proc.wait()


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream whose contents go to the pager (or stdout)."""
    buf = io.StringIO()
    yield buf
    echo_via_pager(buf.getvalue(), color=color)


class ProgressBar:
    """Iterates a wrapped iterable and draws progress on a terminal."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label
        self.hidden = hidden
        self.pos = 0
        self.visible = (not hidden) and _is_tty(sys.stdout)
        self._printed_label = False
        if self.label and not self.visible and not hidden:
            _write(sys.stdout, f"{self.label}\n")
            self._printed_label = True

    def _draw(self):
        if not self.visible:
            return
        if self.length:
            frac = min(self.pos / self.length, 1.0)
            width = 30
            filled = int(width * frac)
            bar = "#" * filled + "-" * (width - filled)
            _write(sys.stdout, f"\r{self.label or ''} [{bar}] {self.pos}/{self.length}")
        else:
            _write(sys.stdout, f"\r{self.label or ''} {self.pos}")

    def update(self, n_steps=1):
        self.pos += n_steps
        self._draw()

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)
        if self.visible:
            _write(sys.stdout, "\n")

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        if self.visible and self.iterable is None:
            _write(sys.stdout, "\n")
        return False


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)
