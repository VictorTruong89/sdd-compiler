"""ANSI styling and unstyling (PRD FP-11)."""

from __future__ import annotations

import re

from .exceptions import OptlynError

_ANSI_RE = re.compile(r"\033\[[0-9;?]*[ -/]*[@-~]|\033[@-Z\\-_]")

_COLORS = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
    "reset": 0,
}

_SWITCHES = [
    ("bold", 1), ("dim", 2), ("italic", 3), ("underline", 4),
    ("blink", 5), ("reverse", 7), ("strikethrough", 9), ("overline", 53),
]


def _color_codes(color, base):
    """Return the SGR parameter string for a color in fg (base=38) or bg (base=48)."""
    if isinstance(color, str):
        if color not in _COLORS:
            raise OptlynError(f"Unknown color {color!r}.")
        code = _COLORS[color]
        if color == "reset":
            return "0"
        return str(code + (10 if base == 48 else 0))
    if isinstance(color, int) and not isinstance(color, bool):
        if not 0 <= color <= 255:
            raise OptlynError(f"Color index {color} is outside 0-255.")
        return f"{base};5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3 and all(
        isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color
    ):
        return f"{base};2;{color[0]};{color[1]};{color[2]}"
    raise OptlynError(f"Invalid color {color!r}.")


def style(text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
          italic=None, blink=None, reverse=None, strikethrough=None, reset=True) -> str:
    """Wrap text in ANSI SGR sequences. Invalid colors raise OptlynError."""
    bits = []
    if fg is not None:
        bits.append(_color_codes(fg, 38))
    if bg is not None:
        bits.append(_color_codes(bg, 48))
    flags = dict(bold=bold, dim=dim, underline=underline, overline=overline,
                 italic=italic, blink=blink, reverse=reverse, strikethrough=strikethrough)
    for name, code in _SWITCHES:
        if flags.get(name):
            bits.append(str(code))
    if not bits:
        return str(text)
    prefix = "\033[" + ";".join(bits) + "m"
    suffix = "\033[0m" if reset else ""
    return f"{prefix}{text}{suffix}"


def unstyle(text) -> str:
    """Remove ANSI escape sequences, leaving all other text."""
    if isinstance(text, bytes):
        text = text.decode("utf-8", "replace")
    return _ANSI_RE.sub("", str(text))


def has_styles(text) -> bool:
    return bool(_ANSI_RE.search(str(text)))
