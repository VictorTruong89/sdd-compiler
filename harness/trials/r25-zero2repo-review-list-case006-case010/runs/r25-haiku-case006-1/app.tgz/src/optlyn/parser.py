"""Token parsing and value resolution (PRD FP-03, FP-04, FP-07, FP-08)."""

from __future__ import annotations

import os

from . import termui
from .exceptions import (
    BadParameter, MissingParameter, NoSuchOption, UsageError,
)
from .params import UNSET, Argument, Option, ParameterSource
from .paramtypes import parse_bool_text


class ParsedArgs:
    """Result of tokenising one command's argument list."""

    def __init__(self):
        self.values = {}        # dest -> raw value(s) from the command line
        self.present = set()    # dests given on the command line (even without value)
        self.prompt_req = set() # dests whose prompting option was given without a value
        self.positional = []    # raw positional tokens (in order)
        self.rest = None        # group mode: tokens from the subcommand name on
        self.unknown = []       # option-like tokens left for a pass-through (interspersed)


def _normalize(ctx, text):
    func = getattr(ctx, "token_normalize_func", None)
    return func(text) if func else text


def _prefixes(params):
    chars = {"-"}
    for p in params:
        for name in list(getattr(p, "opts", [])) + list(getattr(p, "secondary_opts", [])):
            if name and not name[0].isalnum():
                chars.add(name[0])
    return chars


def _option_map(ctx, params):
    mapping = {}
    for p in params:
        if not isinstance(p, Option):
            continue
        for name in p.opts + p.secondary_opts:
            mapping.setdefault(_normalize(ctx, name), (p, name in p.secondary_opts))
    return mapping


def _is_option_like(tok, prefixes):
    return len(tok) > 1 and tok[0] in prefixes


def _take_values(tokens, i, count, ctx, option_name):
    """Take ``count`` tokens starting at index i. Returns (values, new_index)."""
    if i + count > len(tokens):
        raise UsageError(f"Option '{option_name}' requires {count} argument(s).", ctx)
    return tokens[i:i + count], i + count


def parse_tokens(cmd, ctx, args, params, group_mode=False, stop_at_name=False):
    """Walk the token list. In group mode, stops at the subcommand name."""
    result = ParsedArgs()
    prefixes = _prefixes(params)
    opt_map = _option_map(ctx, params)
    # Leaves mix options and arguments by default; groups do not (PRD FP-03).
    interspersed = ctx.allow_interspersed_args
    if interspersed is None:
        interspersed = not group_mode
    ignore_unknown = bool(ctx.ignore_unknown_options)
    eager_name_seen = False

    # For a group, number of positional tokens its own arguments consume.
    arg_params = [p for p in params if isinstance(p, Argument)]
    need = 0
    for a in arg_params:
        if a.is_variadic:
            need = None
            break
        need += a.arity

    dd = False
    i = 0
    n = len(args)
    while i < n:
        tok = args[i]
        if dd:
            result.positional.append(tok)
            i += 1
            continue
        if tok == "--":
            dd = True
            i += 1
            continue

        is_opt = _is_option_like(tok, prefixes)
        if not is_opt:
            if group_mode:
                if need is not None and len(result.positional) < need:
                    result.positional.append(tok)
                    i += 1
                    continue
                if not interspersed:
                    result.rest = args[i:]
                    return result
                # Interspersed group: the group takes its own options from the remainder.
                return _finish_group_mixing(cmd, ctx, args[i:], result, params, opt_map,
                                            prefixes)
            result.positional.append(tok)
            if not interspersed:
                # All remaining tokens are positional.
                result.positional.extend(args[i + 1:])
                break
            i += 1
            continue

        # Option-shaped token.
        consumed = _handle_option(tok, args, i, ctx, opt_map, prefixes, result,
                                  ignore_unknown)
        if consumed is None:
            # Unknown option kept as positional (ignore-unknown mode).
            result.positional.append(tok)
            i += 1
        else:
            i = consumed
    return result


def _finish_group_mixing(cmd, ctx, tokens, result, params, opt_map, prefixes):
    """Group with mixing enabled: pull group options out of tokens after the name."""
    name_tok = tokens[0]
    rest = []
    i = 1
    while i < len(tokens):
        tok = tokens[i]
        if tok == "--":
            rest.extend(tokens[i:])
            break
        if _is_option_like(tok, prefixes):
            norm = _normalize(ctx, tok.split("=", 1)[0])
            if norm in opt_map:
                i = _handle_option(tok, tokens, i, ctx, opt_map, prefixes, result, False)
                continue
        rest.append(tok)
        i += 1
    result.rest = [name_tok] + rest
    return result


def _handle_option(tok, args, i, ctx, opt_map, prefixes, result, ignore_unknown):
    """Process one option token. Returns the next index, or None if it is not an option."""
    # Exact whole-token match first (covers single-dash long names such as "-help").
    norm_tok = _normalize(ctx, tok)
    if "=" in tok and tok[0] in prefixes and _normalize(ctx, tok.split("=", 1)[0]) in opt_map:
        name, _, inline = tok.partition("=")
        return _apply_long(name, inline, args, i, ctx, opt_map, result, ignore_unknown,
                           tok)
    if norm_tok in opt_map:
        return _apply_long(tok, None, args, i, ctx, opt_map, result, ignore_unknown, tok)

    if tok[0] in prefixes and len(tok) > 1 and tok[1] in prefixes:
        # Long-style but unknown.
        if ignore_unknown:
            return None
        name = tok.split("=", 1)[0]
        raise NoSuchOption(f"No such option: {name}", ctx)

    # Short option stack.
    prefix = tok[0]
    chars = tok[1:]
    j = 0
    while j < len(chars):
        flag = prefix + chars[j]
        entry = opt_map.get(_normalize(ctx, flag))
        if entry is None:
            if ignore_unknown:
                if j == 0:
                    return None
                # Known flags before the unknown one were consumed; the rest is an argument.
                result.positional.append(prefix + chars[j:])
                return i + 1
            raise NoSuchOption(f"No such option: {flag}", ctx)
        opt, off = entry
        if opt.is_flag:
            _apply_flag(opt, off, result, ctx)
            j += 1
            continue
        inline = chars[j + 1:]
        if inline:
            return _apply_value(opt, flag, [inline], args, i, ctx, result, consumed_inline=True)
        return _apply_value(opt, flag, None, args, i, ctx, result)
    return i + 1


def _apply_long(name, inline, args, i, ctx, opt_map, result, ignore_unknown, tok):
    entry = opt_map[_normalize(ctx, name)]
    opt, off = entry
    if opt.is_flag:
        if inline is not None:
            raise UsageError(f"Option '{name}' does not take a value.", ctx)
        _apply_flag(opt, off, result, ctx)
        return i + 1
    if inline is not None:
        return _apply_value(opt, name, [inline], args, i, ctx, result, consumed_inline=True)
    return _apply_value(opt, name, None, args, i, ctx, result)


def _apply_flag(opt, off, result, ctx):
    result.present.add(opt.name)
    if opt.count:
        result.values[opt.name] = result.values.get(opt.name, 0) + 1
        return
    if off:
        value = False
    else:
        value = opt.flag_default()
    if opt.is_eager:
        result.values[opt.name] = value
        _run_eager(opt, value, ctx)
        return
    _store(opt, value, result)


def _apply_value(opt, name, inline_vals, args, i, ctx, result, consumed_inline=False):
    """Option that takes value(s). ``inline_vals`` is a list with the attached token."""
    width = opt.arity
    if inline_vals is not None:
        vals = list(inline_vals)
        nxt = i + 1
        if len(vals) < width:
            more, nxt = _take_values(args, i + 1, width - len(vals), ctx, name)
            vals.extend(more)
    else:
        nxt = i + 1
        if opt.is_optional_value and (nxt >= len(args) or _looks_like_flag(args[nxt])):
            result.present.add(opt.name)
            _store(opt, opt.flag_value, result)
            return nxt
        if opt.prompt and (nxt >= len(args) or _looks_like_flag(args[nxt]) or args[nxt] == "--"):
            # Flag present without a value on a prompting option: ask the user.
            result.present.add(opt.name)
            result.prompt_req.add(opt.name)
            return nxt
        if nxt < len(args) and args[nxt] == "--":
            raise UsageError(f"Option '{name}' requires an argument.", ctx)
        vals, nxt = _take_values(args, i + 1, width, ctx, name)
    result.present.add(opt.name)
    if opt.arity != 1 or opt.type.is_composite:
        value = tuple(vals)
    else:
        value = vals[0]
    if opt.is_eager:
        result.values[opt.name] = value
        _run_eager(opt, value, ctx)
        return nxt
    _store(opt, value, result)
    return nxt


def _looks_like_flag(tok):
    return len(tok) > 1 and tok[0] == "-" and tok != "-"


def _run_eager(opt, value, ctx):
    opt.process_value(value, ctx)


def _store(opt, value, result):
    if opt.multiple:
        result.values.setdefault(opt.name, []).append(value)
    else:
        result.values[opt.name] = value
        # Feature-switch: the last occurrence on the command line wins.


def resolve_params(cmd, ctx, parsed, params):
    """Assign values for every parameter from the sources in precedence order."""
    # Eager parameters first (help/version), in declaration order.
    ordered = [p for p in params if p.is_eager] + [p for p in params if not p.is_eager]
    for p in ordered:
        value, source = _resolve_one(cmd, ctx, parsed, p)
        if p.is_eager and source is ParameterSource.COMMANDLINE:
            continue  # already ran its callback during parsing
        if value is UNSET and p.required:
            raise MissingParameter(_missing_text(p), ctx=ctx, param=p)
        if p.deprecated and source is ParameterSource.COMMANDLINE:
            _warn_deprecated(p)
        if value is UNSET:
            # Omitted: the callback still runs (PRD FP-03), with the empty value.
            source = ParameterSource.DEFAULT
            value = _run_cb(p, _empty_value(p), ctx)
        else:
            value = _finalise(p, value, ctx, source)
        if p.expose_value:
            ctx.params[p.name] = value
        ctx.set_source(p.name, source)
    return ctx.params


def _missing_text(p):
    if isinstance(p, Argument):
        return f"Missing argument '{p.name.upper()}'."
    return f"Missing option '{p.describe()}'."


def _empty_value(p):
    if p.count:
        return 0
    if p.multiple or (isinstance(p, Argument) and p.is_variadic):
        return ()
    if p.is_flag:
        return False
    return None


def _finalise(p, value, ctx, source):
    """Convert (except flags, counts and prompt answers) and run the callback."""
    if source is ParameterSource.PROMPT or p.is_flag or p.count:
        converted = value
    elif p.multiple:
        if isinstance(value, (str, bytes)) or not hasattr(value, "__iter__"):
            raise BadParameter(f"needs an iterable (sequence) default for {p.describe()}.",
                               ctx=ctx, param=p)
        converted = tuple(p.convert_one(v, ctx) for v in value)
    else:
        converted = p.convert_value(value, ctx)
    return _run_cb(p, converted, ctx)


def _run_cb(p, value, ctx):
    if p.callback is not None:
        return p.callback(ctx, p, value)
    return value


def _warn_deprecated(p):
    kind = "option" if isinstance(p, Option) else "argument"
    label = p.opts[0] if isinstance(p, Option) and p.opts else p.name
    note = p.deprecated if isinstance(p.deprecated, str) else None
    msg = f"DeprecationWarning: The {kind} '{label}' is deprecated."
    if note:
        msg += " " + note
    termui.echo(msg, err=True)


def _resolve_one(cmd, ctx, parsed, p):
    """Return (raw_value_or_UNSET, source). Raw values are converted later."""
    name = p.name
    # 1. Command line.
    if name in parsed.values:
        raw = parsed.values[name]
        if isinstance(raw, list) and not p.multiple:
            raw = raw[-1]
        if isinstance(raw, tuple) and p.multiple:
            raw = list(raw)
        return raw, ParameterSource.COMMANDLINE
    # 2. Prompt requested by presence without value.
    if name in parsed.prompt_req:
        return _prompt(p, ctx), ParameterSource.PROMPT
    # 3. Environment.
    env = _env_value(p, ctx)
    if env is not UNSET:
        return env, ParameterSource.ENVIRONMENT
    # 4. Default map.
    dm = ctx.default_map if isinstance(ctx.default_map, dict) else {}
    if name in dm:
        value = dm[name]
        if isinstance(value, str):
            if p.arity != 1 or p.type.is_composite:
                value = p.type.split_envvar(value) if p.type is not None else value.split()
                value = tuple(value)
            elif p.multiple:
                raise BadParameter("needs an iterable (sequence) default.", ctx=ctx, param=p)
        return value, ParameterSource.DEFAULT_MAP
    # 5. Declared default.
    d = p.default
    if d is not None:
        value = d() if callable(d) else d
        if p.multiple:
            if isinstance(value, (str, bytes)) or not hasattr(value, "__iter__"):
                raise BadParameter(
                    f"needs an iterable (sequence) default for {p.describe()}.",
                    ctx=ctx, param=p,
                )
            value = tuple(value)
        return value, ParameterSource.DEFAULT
    # 6. Prompt on omission when required (or prompt_required is set).
    if isinstance(p, Option) and p.prompt and (p.required or p.prompt_required):
        return _prompt(p, ctx), ParameterSource.PROMPT
    return UNSET, ParameterSource.DEFAULT


def _prompt(p, ctx):
    text = p.prompt_text or p.name.replace("_", " ").capitalize()
    default = p.default
    return termui.prompt(
        text,
        default=default,
        hide_input=p.hide_input,
        confirmation_prompt=p.confirmation_prompt,
        value_proc=lambda v: p.convert_value(v, ctx),
    )


def _env_names(p, ctx):
    names = list(p.envvar_list)
    if isinstance(p, Option) and p.allow_from_autoenv and ctx is not None:
        prefix = _root_prefix(ctx)
        if prefix:
            parts = [prefix]
            parts.extend(_path_names(ctx))
            parts.append(p.name)
            auto = "_".join(x.replace("-", "_").upper() for x in parts if x)
            names.append(auto)
    return names


def _root_prefix(ctx):
    node = ctx
    while node.parent is not None:
        node = node.parent
    return getattr(node, "auto_envvar_prefix", None)


def _path_names(ctx):
    names = []
    node = ctx
    while node is not None and node.parent is not None:
        names.append(node.info_name)
        node = node.parent
    return list(reversed(names))


def _env_value(p, ctx):
    names = _env_names(p, ctx)
    for env_name in names:
        raw = os.environ.get(env_name)
        if raw is None or raw == "":
            continue
        if p.is_flag:
            return _env_flag(p, raw, ctx)
        if p.multiple or p.arity != 1 or p.type.is_composite:
            parts = p.type.split_envvar(raw) if raw.strip() else []
            if not parts:
                continue
            if p.multiple:
                return [tuple(parts[k:k + p.arity]) if p.arity != 1 else parts[k]
                        for k in range(0, len(parts), max(1, p.arity))]
            return tuple(parts)
        return raw
    return UNSET


def _env_flag(p, raw, ctx):
    text = raw.strip()
    if p.flag_value is not None and not isinstance(p.flag_value, bool):
        if text.lower() == str(p.flag_value).lower():
            return p.flag_value
        recognised = parse_bool_text(text)
        if recognised is None:
            return UNSET
        return recognised
    if text == "":
        return UNSET
    recognised = parse_bool_text(text)
    if recognised is None:
        raise BadParameter(
            f"{raw!r} is not a valid boolean for environment variable.",
            ctx=ctx, param=p,
        )
    return recognised


def bind_arguments(ctx, parsed, params, allow_extra):
    """Bind positional tokens to declared arguments in order.

    Returns the list of leftover tokens (not consumed by any argument).
    """
    args = [p for p in params if isinstance(p, Argument)]
    tokens = list(parsed.positional)
    idx = 0
    for k, arg in enumerate(args):
        if arg.is_variadic:
            fixed_after = sum(a.arity for a in args[k + 1:] if not a.is_variadic)
            take = max(0, len(tokens) - idx - fixed_after)
            vals = tokens[idx:idx + take]
            idx += take
            if not vals and arg.required:
                raise arg.missing_error(ctx)
            if vals:
                parsed.values[arg.name] = tuple(vals)
                parsed.present.add(arg.name)
            continue
        width = arg.arity
        avail = len(tokens) - idx
        if avail <= 0:
            continue  # omitted: resolved from other sources or missing
        if avail < width:
            raise UsageError(
                f"Argument '{arg.name}' takes {width} values but got {avail}.", ctx,
            )
        vals = tokens[idx:idx + width]
        idx += width
        if arg.is_scalar or (width == 1 and not arg.type.is_composite and not arg.multiple):
            parsed.values[arg.name] = vals[0]
        else:
            parsed.values[arg.name] = tuple(vals)
        parsed.present.add(arg.name)
    leftover = tokens[idx:]
    if leftover:
        option_like = [t for t in leftover if len(t) > 1 and t[0] == "-"]
        if option_like and not allow_extra:
            raise NoSuchOption(f"No such option: {option_like[0]}", ctx)
        if not allow_extra:
            raise UsageError(f"Got unexpected extra argument(s) ({' '.join(leftover)}).", ctx)
        if option_like:
            raise UsageError(
                f"Got unexpected option-like argument(s) ({' '.join(option_like)}).", ctx,
            )
    return leftover


__all__ = ["parse_tokens", "resolve_params", "bind_arguments", "ParsedArgs"]
