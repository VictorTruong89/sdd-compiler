"""Thread-local storage for the current invocation context."""

from __future__ import annotations

import threading

_local = threading.local()


def _stack():
    s = getattr(_local, "stack", None)
    if s is None:
        s = []
        _local.stack = s
    return s


def push(ctx):
    _stack().append(ctx)


def pop():
    s = _stack()
    if s:
        s.pop()


def current(silent=False):
    s = _stack()
    if s:
        return s[-1]
    if silent:
        return None
    from .exceptions import OptlynError

    raise OptlynError("There is no active Optlyn context on this thread.")
