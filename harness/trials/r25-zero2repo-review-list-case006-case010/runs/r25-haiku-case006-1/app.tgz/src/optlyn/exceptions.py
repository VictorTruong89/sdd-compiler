"""Exception classes and exit-status classes for Optlyn."""

from __future__ import annotations

import sys


class OptlynError(Exception):
    """Base class for all Optlyn-signalled errors (general error class, exit 1)."""

    exit_code = 1

    def __init__(self, message: str = "", ctx=None):
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def show(self, file=None) -> None:
        file = file or sys.stderr
        print(self.format_message(), file=file)

    def format_message(self) -> str:
        return self.message


class UsageError(OptlynError):
    """Usage failure (exit status 2)."""

    exit_code = 2

    def __init__(self, message: str, ctx=None, help_page: bool = False):
        super().__init__(message, ctx)
        self.help_page = help_page

    def show(self, file=None) -> None:
        file = file or sys.stderr
        print("Usage error: " + self.format_message(), file=file)


class BadParameter(UsageError):
    """A value was refused. Names the offending parameter when known."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self) -> str:
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.describe()
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return f"Invalid value: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter was not supplied."""

    def format_message(self) -> str:
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.describe()
        return f"Missing parameter: {hint or self.message}"


class NoSuchOption(UsageError):
    """An option name is not known."""


class UsageMissingCommand(UsageError):
    """A group was invoked without a subcommand where one is required."""


class NoSuchCommand(UsageError):
    """A subcommand name is not known."""

    def __init__(self, name: str, ctx=None):
        super().__init__(f"No such command '{name}'.", ctx)
        self.name = name


class Abort(OptlynError):
    """Abort (exit status 1), for user declines, EOF, interrupts and author aborts."""

    exit_code = 1

    def format_message(self) -> str:
        return self.message or "Aborted!"


class Exit(Exception):
    """Author clean stop. Carries the exit code."""

    def __init__(self, code: int = 0):
        super().__init__(code)
        self.exit_code = code


class DeclarationError(TypeError):
    """An invalid combination of declaration keywords."""
