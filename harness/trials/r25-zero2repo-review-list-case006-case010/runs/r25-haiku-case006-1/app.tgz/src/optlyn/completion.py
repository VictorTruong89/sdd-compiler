"""Shell completion (PRD FP-12; Contract section 8)."""

from __future__ import annotations

import os
import sys

from .params import Argument, Option
from .paramtypes import File, Path

SHELLS = ("bash", "zsh", "fish", "powershell")
PATH_FILE = "__optlyn_path_file__"
PATH_DIR = "__optlyn_path_dir__"


def _script(shell, prog_name, var):
    if shell == "bash":
        return (
            f"_{prog_name}_completion() {{\n"
            f"  local IFS=$'\\n'\n"
            f"  COMPREPLY=( $(env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD "
            f"{var}=bash_complete {prog_name}) )\n"
            f"  return 0\n"
            f"}}\n"
            f"complete -o default -F _{prog_name}_completion {prog_name}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {prog_name}\n"
            f"_{prog_name}_completion() {{\n"
            f"  local -a completions\n"
            f"  completions=(${{(f)\"$(env COMP_WORDS=\"${{words[*]}}\" "
            f"COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog_name})\"}})\n"
            f"  _describe 'values' completions\n"
            f"}}\n"
            f"compdef _{prog_name}_completion {prog_name}\n"
        )
    if shell == "fish":
        return (
            f"function _{prog_name}_completion\n"
            f"  set -l cmd (commandline -cp)\n"
            f"  env COMP_WORDS=\"$cmd\" COMP_CWORD=(commandline -ct) {var}=fish_complete "
            f"{prog_name}\n"
            f"end\n"
            f"complete -offline -c {prog_name} -f -a '(_{prog_name}_completion)'\n"
        )
    return (
        f"Register-ArgumentCompleter -Native -CommandName {prog_name} -ScriptBlock {{\n"
        f"  param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"  $env:COMP_WORDS = $commandAst.ToString()\n"
        f"  $env:COMP_CWORD = $wordToComplete\n"
        f"  $env:{var} = 'powershell_complete'\n"
        f"  & {prog_name} | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_) }}\n"
        f"}}\n"
    )


def _visible_children(cmd, ctx):
    from .core import Group

    if not isinstance(cmd, Group):
        return {}
    out = {}
    for name in cmd.list_commands(ctx):
        sub = cmd.get_command(ctx, name)
        if sub is not None and not sub.hidden:
            out[name] = sub
    return out


def _suggestions(root, words, incomplete, fish=False):
    from .context import Context

    ctx = Context(root, info_name=root.name)
    cmd = root
    prev_option = None
    tokens = words[:-1] if not fish else words[:-1]
    for tok in tokens:
        if prev_option is not None:
            prev_option = None
            continue
        if tok.startswith("-"):
            for p in cmd.params:
                if isinstance(p, Option) and tok in p.opts + p.secondary_opts and not p.is_flag:
                    prev_option = p
                    break
            continue
        children = _visible_children(cmd, ctx)
        if tok in children:
            cmd = children[tok]
            ctx = Context(cmd, parent=ctx, info_name=tok)
    out = []
    if prev_option is not None:
        return _value_suggestions(prev_option, ctx, incomplete)
    if incomplete.startswith("-"):
        for p in cmd.params:
            if isinstance(p, Option) and not p.hidden:
                for flag in p.opts + p.secondary_opts:
                    if flag.startswith(incomplete):
                        out.append((flag, p.help))
        for flag in ("--help",):
            if flag.startswith(incomplete) and getattr(cmd, "add_help_option", True):
                out.append((flag, "Show this message and exit."))
        return out
    for name, sub in _visible_children(cmd, ctx).items():
        if name.startswith(incomplete):
            out.append((name, sub.short_help_text(45) if sub.help else None))
    for p in cmd.params:
        if isinstance(p, Argument) and isinstance(p.type, (File, Path)):
            kind = PATH_DIR if isinstance(p.type, Path) and p.type.dir_okay \
                and not p.type.file_okay else PATH_FILE
            out.append((kind, incomplete))
            break
    return out


def _value_suggestions(opt, ctx, incomplete):
    if opt.shell_complete is not None:
        return [(getattr(i, "value", i), getattr(i, "help", None))
                for i in opt.shell_complete(ctx, opt, incomplete)]
    ptype = opt.type
    if isinstance(ptype, (File, Path)):
        kind = PATH_DIR if isinstance(ptype, Path) and ptype.dir_okay and not ptype.file_okay \
            else PATH_FILE
        return [(kind, incomplete)]
    return [(v, None) for v in ptype.shell_complete(ctx, opt, incomplete)]


def _emit(lines):
    out = sys.stdout
    for value, _help in lines:
        out.write(value + "\n")
    out.flush()


def run_completion(cmd, instruction, prog_name, args, standalone_mode=True, var=None):
    """Handle a completion instruction. Never runs the command callback."""
    shell, _, mode = instruction.partition("_")
    if shell not in SHELLS or mode not in ("source", "complete"):
        msg = f"Unsupported completion instruction: {instruction!r}"
        sys.stderr.write(msg + "\n")
        if standalone_mode:
            sys.exit(1)
        return None

    var = var or "_" + prog_name.replace("-", "_").upper() + "_COMPLETE"
    if mode == "source":
        sys.stdout.write(_script(shell, prog_name, var))
        sys.stdout.flush()
    else:
        raw = os.environ.get("COMP_WORDS", "")
        cword = os.environ.get("COMP_CWORD", "0")
        words = raw.split(" ") if raw else [prog_name]
        if shell == "fish":
            incomplete = cword
            consumed = words
        else:
            try:
                idx = int(cword)
            except ValueError:
                idx = len(words)
            incomplete = words[idx] if idx < len(words) else ""
            consumed = words[:idx] + [incomplete] if idx < len(words) else words + [""]
        body = consumed[1:]  # drop executable name
        lines = _suggestions(cmd, body if body else [""], incomplete, fish=(shell == "fish"))
        _emit(lines)
    if standalone_mode:
        sys.exit(0)
    return None


__all__ = ["run_completion", "PATH_FILE", "PATH_DIR"]
