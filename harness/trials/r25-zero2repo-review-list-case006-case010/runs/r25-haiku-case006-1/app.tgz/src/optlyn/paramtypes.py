"""Parameter types and conversion (PRD FP-05, FP-09; Contract section 5)."""

from __future__ import annotations

import datetime as _dt
import enum
import os
import pathlib
import uuid as _uuid

from .exceptions import BadParameter, DeclarationError

_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


def parse_bool_text(value: str):
    """Return True/False for recognised text, or None when unrecognised."""
    v = value.strip().lower()
    if v in _TRUE:
        return True
    if v in _FALSE:
        return False
    return None


class ParamType:
    """Base class for parameter types."""

    name = "text"
    # Placeholder shown in help when the type supplies its own (choice).
    is_composite = False
    arity = 1

    def convert(self, value, param=None, ctx=None):
        return value

    def get_metavar(self, param=None):
        return None

    def get_help_extra(self):
        return None

    def split_envvar(self, raw: str):
        return raw.split()

    def shell_complete(self, ctx, param, incomplete):
        return []

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self):
        return f"<{type(self).__name__}>"


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            try:
                value = value.decode("utf-8")
            except UnicodeDecodeError:
                value = value.decode("utf-8", "replace")
        return str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        if isinstance(value, int) and not isinstance(value, bool):
            return float(value)
        try:
            return float(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


class BoolParamType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        res = parse_bool_text(str(value))
        if res is None:
            self.fail(f"{value!r} is not a valid boolean.", param, ctx)
        return res


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self._enum = choices
            self.choices = list(choices)
            self._tokens = [m.name for m in choices]
        else:
            self._enum = None
            self.choices = list(choices)
            self._tokens = [str(c) for c in self.choices]
        self.case_sensitive = case_sensitive

    def _norm(self, s):
        return s if self.case_sensitive else s.casefold()

    def get_metavar(self, param=None):
        return "[" + "|".join(self._tokens) + "]"

    def get_help_extra(self):
        return "Choices: " + ", ".join(self._tokens)

    def convert(self, value, param=None, ctx=None):
        if self._enum is not None and isinstance(value, self._enum):
            return value
        if not self._enum and value in self.choices:
            return value
        token = str(value)
        for original, tok in zip(self.choices, self._tokens):
            if self._norm(tok) == self._norm(token):
                return original
        self.fail(
            f"{token!r} is not {' or '.join(repr(t) for t in self._tokens)}.",
            param,
            ctx,
        )

    def shell_complete(self, ctx, param, incomplete):
        return [t for t in self._tokens if t.startswith(incomplete)]


DEFAULT_DATETIME_FORMATS = (
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
)


class DateTime(ParamType):
    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(DEFAULT_DATETIME_FORMATS)

    def get_metavar(self, param=None):
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        text = str(value).strip()
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(text, fmt)
            except ValueError:
                continue
        self.fail(
            f"{value!r} does not match the formats {', '.join(self.formats)}.",
            param,
            ctx,
        )


class IntRange(IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        lo, hi = self.min, self.max
        below = lo is not None and (v < lo or (self.min_open and v == lo))
        above = hi is not None and (v > hi or (self.max_open and v == hi))
        if not below and not above:
            return v
        if self.clamp:
            if below:
                return (lo + 1) if self.min_open else lo
            return (hi - 1) if self.max_open else hi
        self.fail(self._range_message(), param, ctx)

    def _range_message(self):
        lo = "" if self.min is None else f"{'>' if self.min_open else '>='} {self.min}"
        hi = "" if self.max is None else f"{'<' if self.max_open else '<='} {self.max}"
        return "is not in the valid range: " + " and ".join(p for p in (lo, hi) if p) + "."


class FloatRange(FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and ((min is not None and min_open) or (max is not None and max_open)):
            raise DeclarationError("FloatRange clamp is not allowed with an open bound.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param=None, ctx=None):
        v = super().convert(value, param, ctx)
        lo, hi = self.min, self.max
        below = lo is not None and (v < lo or (self.min_open and v == lo))
        above = hi is not None and (v > hi or (self.max_open and v == hi))
        if not below and not above:
            return v
        if self.clamp:
            return float(lo) if below else float(hi)
        self.fail(f"{v} is not in the valid range.", param, ctx)


class Tuple(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(t) for t in types]
        self.arity = len(self.types)

    def get_metavar(self, param=None):
        return " ".join((t.get_metavar(param) or t.name.upper()) for t in self.types)

    def convert(self, value, param=None, ctx=None):
        value = tuple(value)
        if len(value) != len(self.types):
            self.fail(f"requires {len(self.types)} values.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


class FuncParamType(ParamType):
    """Wraps a conversion function f(token) -> value that refuses by raising."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except (ValueError, TypeError) as exc:
            self.fail(str(exc) or f"{value!r} is not valid.", param, ctx)


class File(ParamType):
    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise DeclarationError(f"Unsupported File mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def get_metavar(self, param=None):
        return "FILENAME"

    def _is_lazy(self):
        if self.lazy is not None:
            return self.lazy
        return self.mode.startswith("w")

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        from .fileio import open_stream

        try:
            return open_stream(
                str(value),
                self.mode,
                self.encoding,
                self.errors,
                lazy=self._is_lazy(),
                atomic=self.atomic,
            )
        except OSError as exc:
            self.fail(f"could not open file {value!r}: {exc.strerror or exc}", param, ctx)

    def split_envvar(self, raw):
        return raw.split(os.pathsep)


class Path(ParamType):
    name = "path"

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def get_metavar(self, param=None):
        return "PATH"

    def split_envvar(self, raw):
        return raw.split(os.pathsep)

    def shell_complete_kind(self):
        if self.dir_okay and not self.file_okay:
            return "dir"
        return "file"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, pathlib.PurePath):
            value = str(value)
        raw = str(value)
        if self.allow_dash and raw == "-":
            return self._out("-")

        if self.resolve_path:
            # C-18: a leading tilde is not expanded (PRD FP-09).
            p = os.path.realpath(raw)
        else:
            p = raw

        exists = os.path.exists(p)
        if self.exists and not exists:
            self.fail(f"{raw!r} does not exist.", param, ctx)
        if exists:
            is_dir = os.path.isdir(p)
            if is_dir and not self.dir_okay:
                self.fail(f"{raw!r} is a directory.", param, ctx)
            if not is_dir and not self.file_okay:
                self.fail(f"{raw!r} is a file.", param, ctx)
            if self.readable and not os.access(p, os.R_OK):
                self.fail(f"{raw!r} is not readable.", param, ctx)
            if self.writable and not os.access(p, os.W_OK):
                self.fail(f"{raw!r} is not writable.", param, ctx)
            if self.executable and not os.access(p, os.X_OK):
                self.fail(f"{raw!r} is not executable.", param, ctx)
        return self._out(p)

    def _out(self, p):
        if self.path_type is pathlib.Path:
            return pathlib.Path(p)
        return p


# Ready-made instances.
STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()

_PY_TYPE_MAP = {
    str: STRING,
    int: INT,
    float: FLOAT,
    bool: BOOL,
    _uuid.UUID: UUID,
}


def convert_type(ty, default=None) -> ParamType:
    """Turn a type spec (instance, class, python type, or function) into a ParamType."""
    if ty is None:
        if default is not None and not isinstance(default, (list, tuple, set)):
            # Infer from default (bool before int because bool subclasses int).
            if isinstance(default, bool):
                return BOOL
            if isinstance(default, int):
                return INT
            if isinstance(default, float):
                return FLOAT
        if isinstance(default, (tuple,)) and default:
            return Tuple([convert_type(None, d) for d in default])
        return STRING
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, type) and ty in _PY_TYPE_MAP:
        return _PY_TYPE_MAP[ty]
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if callable(ty):
        return FuncParamType(ty)
    raise DeclarationError(f"Unsupported parameter type: {ty!r}")


def is_iterable_default(value) -> bool:
    return isinstance(value, (list, tuple))


__all__ = [
    "ParamType",
    "STRING",
    "INT",
    "FLOAT",
    "BOOL",
    "UUID",
    "UNPROCESSED",
    "Choice",
    "DateTime",
    "IntRange",
    "FloatRange",
    "Tuple",
    "File",
    "Path",
    "convert_type",
    "parse_bool_text",
]
