"""Commands, groups, and dispatch (PRD FP-01, FP-02, FP-06, FP-10, FP-13)."""

from __future__ import annotations

import os
import sys

from . import formatting, termui
from .context import Context
from .exceptions import (
    Abort, DeclarationError, Exit, NoSuchCommand, OptlynError, UsageError,
    UsageMissingCommand,
)
from .params import UNSET, Argument, Option, ParameterSource, take_params
from .parser import bind_arguments, parse_tokens, resolve_params

_SUFFIXES = ("_command", "_cmd", "_group", "_grp")
_CHAIN = object()  # invoked_subcommand value when a chain runs several children


def _derive_name(func_name: str) -> str:
    name = func_name.lower()
    for suffix in _SUFFIXES:
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def completion_var_name(prog_name: str) -> str:
    """``_<PROG>_COMPLETE``: program name upper-cased, dashes turned into underscores."""
    return "_" + prog_name.replace("-", "_").upper() + "_COMPLETE"


def _command_path(ctx) -> str:
    names = []
    node = ctx
    while node is not None:
        if node.info_name:
            names.append(node.info_name)
        node = node.parent
    return " ".join(reversed(names))


class Command:
    """A leaf command: options and arguments, and a callback."""

    def __init__(self, name=None, callback=None, params=None, help=None, short_help=None,
                 epilog=None, options_metavar="[OPTIONS]", context_settings=None,
                 add_help_option=True, no_args_is_help=False, deprecated=False,
                 hidden=False, **extra):
        if name is None and callback is not None:
            name = _derive_name(callback.__name__)
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        self.help = self._clean_help(help if help is not None else getattr(callback, "__doc__", None))
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden
        self.extra = extra

    @staticmethod
    def _clean_help(text):
        if text is None:
            return None
        return formatting.truncate_at_formfeed(text)

    # -- parameters ---------------------------------------------------------
    def _author_flag_names(self):
        names = set()
        for p in self.params:
            if isinstance(p, Option):
                names.update(p.opts)
        return names

    def effective_params(self, ctx):
        """Declared parameters plus the automatic help option when it applies."""
        params = list(self.params)
        if self.add_help_option:
            author = self._author_flag_names()
            names = [n for n in (ctx.help_option_names or []) if n not in author]
            if names:
                params.append(_help_option(names))
        return params

    def declared_dests(self):
        return {p.name for p in self.params if p.expose_value}

    # -- context construction ----------------------------------------------
    def make_context(self, info_name, args, parent=None, **extra):
        settings = dict(self.context_settings)
        settings.update(extra)
        ctx = Context(self, parent=parent, info_name=info_name, **settings)
        if parent is not None:
            dm = parent.default_map
            ctx.default_map = dm.get(info_name) if isinstance(dm, dict) else None
        else:
            ctx.default_map = settings.get("default_map")
        ctx.protected_args = []
        self.parse_args(ctx, list(args))
        return ctx

    def parse_args(self, ctx, args):
        params = self.effective_params(ctx)
        if not args and self.no_args_is_help:
            termui.echo(self.get_help(ctx), err=True)
            raise UsageError("", ctx)
        parsed = parse_tokens(self, ctx, args, params)
        bind_arguments(ctx, parsed, params, bool(ctx.allow_extra_args))
        resolve_params(self, ctx, parsed, params)
        return ctx

    # -- invocation ---------------------------------------------------------
    def invoke(self, ctx):
        self._warn_deprecated()
        return self.invoke_with_values(ctx, ctx.params)

    def invoke_with_values(self, ctx, values, supplied=False):
        self._warn_deprecated_if(supplied)
        if self.callback is None:
            return None
        dests = {p.name for p in self.params if p.expose_value}
        kwargs = {k: v for k, v in values.items() if (k in dests or supplied)}
        with ctx:
            return self.callback(**kwargs)

    def _warn_deprecated(self):
        self._warn_deprecated_if(True)

    def _warn_deprecated_if(self, flag):
        if not self.deprecated or not flag:
            return
        msg = f"DeprecationWarning: The command '{self.name}' is deprecated."
        if isinstance(self.deprecated, str):
            msg += " " + self.deprecated
        termui.echo(msg, err=True)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True,
             **extra):
        if args is None:
            args = sys.argv[1:]
        else:
            args = list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "cli"
        var = complete_var or completion_var_name(prog_name)
        instruction = os.environ.get(var)
        if instruction:
            from .completion import run_completion

            return run_completion(self, instruction, prog_name, args, standalone_mode, var)

        ctx = None
        try:
            try:
                ctx = self.make_context(prog_name, args, **extra)
                with ctx:
                    rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
                sys.exit(0)
            finally:
                if ctx is not None:
                    ctx.close()
        except Exit as exc:
            if not standalone_mode:
                return exc.exit_code
            sys.exit(exc.exit_code)
        except (Abort, KeyboardInterrupt, EOFError) as exc:
            if not standalone_mode:
                if isinstance(exc, Abort):
                    raise
                raise Abort() from exc
            termui.echo("Aborted!", err=True)
            sys.exit(1)
        except UsageError as exc:
            if not standalone_mode:
                raise
            if exc.message or exc.__class__ is not UsageError:
                exc.show(file=sys.stderr)
                termui.echo(f"Try '{prog_name} --help' for help.", err=True)
            sys.exit(2)
        except OptlynError as exc:
            if not standalone_mode:
                raise
            exc.show(file=sys.stderr)
            sys.exit(exc.exit_code)

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # -- help ---------------------------------------------------------------
    def get_help(self, ctx) -> str:
        return format_help(self, ctx)

    def short_help_text(self, width):
        text = self.short_help or formatting.first_sentence(self.help or "")
        return formatting.ellipsize(text, width)


class Group(Command):
    """Dispatches to named subcommands. Groups may nest arbitrarily."""

    def __init__(self, name=None, commands=None, invoke_without_command=False,
                 no_args_is_help=None, subcommand_metavar=None, chain=False,
                 result_callback=None, **kwargs):
        super().__init__(name=name, no_args_is_help=False, **kwargs)
        self.commands = dict(commands or {})
        self.invoke_without_command = invoke_without_command
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        self.no_args_is_help = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self.result_callback_func = result_callback

    # -- children -----------------------------------------------------------
    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise DeclarationError("Groups cannot be nested under a chaining group.")
        key = name or cmd.name
        if key is None:
            raise DeclarationError("A subcommand needs a name.")
        self.commands[key] = cmd

    def command(self, *args, **kwargs):
        def decorator(f):
            cmd = command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        def decorator(f):
            grp = group(*args, **kwargs)(f)
            self.add_command(grp)
            return grp

        return decorator

    def result_callback(self):
        def decorator(f):
            self.result_callback_func = f
            return f

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def _lookup(self, ctx, name):
        candidates = [name]
        func = ctx.token_normalize_func
        if func:
            candidates = [name] + [n for n in self.list_commands(ctx) if func(n) == func(name)]
        for cand in candidates:
            cmd = self.get_command(ctx, cand)
            if cmd is not None:
                return cand, cmd
        return None, None

    # -- parsing ------------------------------------------------------------
    def parse_args(self, ctx, args):
        params = self.effective_params(ctx)
        if not args and self.no_args_is_help:
            termui.echo(self.get_help(ctx), err=True)
            raise UsageError("", ctx)
        parsed = parse_tokens(self, ctx, args, params, group_mode=True)
        bind_arguments(ctx, parsed, params, bool(ctx.allow_extra_args))
        resolve_params(self, ctx, parsed, params)
        rest = parsed.rest or []
        ctx.protected_args = list(rest)
        return ctx

    # -- invocation ---------------------------------------------------------
    def invoke(self, ctx):
        self._warn_deprecated()
        if self.chain:
            return self._invoke_chain(ctx)
        rest = ctx.protected_args
        if not rest:
            if not self.invoke_without_command:
                raise UsageMissingCommand("Missing command.", ctx)
            ctx.invoked_subcommand = None
            rv = self.invoke_with_values(ctx, ctx.params)
            if self.result_callback_func is not None:
                return self.result_callback_func(rv, **ctx.params)
            return rv

        name = rest[0]
        key, cmd = self._lookup(ctx, name)
        if cmd is None:
            raise NoSuchCommand(name, ctx)
        ctx.invoked_subcommand = key
        # The group callback runs before the child (PRD FP-06), even if the child then shows help.
        self.invoke_with_values(ctx, ctx.params)
        child = cmd.make_context(key, rest[1:], parent=ctx)
        try:
            with child:
                rv = cmd.invoke(child)
        finally:
            child.close()
        if self.result_callback_func is not None:
            return self.result_callback_func(rv, **ctx.params)
        return rv

    def _invoke_chain(self, ctx):
        rest = ctx.protected_args
        if not rest:
            if not self.invoke_without_command:
                raise UsageMissingCommand("Missing command.", ctx)
            ctx.invoked_subcommand = None
            self.invoke_with_values(ctx, ctx.params)
            rvs = []
            if self.result_callback_func is not None:
                return self.result_callback_func(rvs, **ctx.params)
            return rvs

        # Split the tokens into chunks; resolve and parse all children before running any.
        plan = []
        i = 0
        while i < len(rest):
            key, cmd = self._lookup(ctx, rest[i])
            if cmd is None:
                raise NoSuchCommand(rest[i], ctx)
            j = i + 1
            while j < len(rest) and self._lookup(ctx, rest[j])[1] is None:
                j += 1
            child = cmd.make_context(key, rest[i + 1:j], parent=ctx)
            plan.append((cmd, child))
            i = j

        ctx.invoked_subcommand = _CHAIN
        self.invoke_with_values(ctx, ctx.params)
        rvs = []
        for cmd, child in plan:
            try:
                with child:
                    rvs.append(cmd.invoke(child))
            finally:
                child.close()
        if self.result_callback_func is not None:
            return self.result_callback_func(rvs, **ctx.params)
        return rvs

    def get_help(self, ctx) -> str:
        return format_help(self, ctx)


class CommandCollection(Group):
    """Union of subcommands from several source groups."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name=name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for src in self.sources:
            names.update(src.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        for src in self.sources:
            cmd = src.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None

    def add_command(self, cmd, name=None):
        raise DeclarationError("Add subcommands to a source group, not to a CommandCollection.")


# -- help page -----------------------------------------------------------------

def _visible_options(params):
    return [p for p in params if isinstance(p, Option) and not p.hidden]


def _option_left(opt):
    flags = ", ".join(opt.opts) if opt.opts else ""
    if opt.secondary_opts:
        flags = "/".join(opt.opts + opt.secondary_opts) if not opt.opts else \
            ", ".join(opt.opts) + "/" + ", ".join(opt.secondary_opts)
    metavar = None
    if not opt.is_flag:
        metavar = opt.metavar or opt.type.get_metavar(opt) or opt.type.name.upper()
    return f"{flags} {metavar}" if metavar else flags


def _option_extras(opt, ctx):
    extras = []
    if isinstance(opt.type, object) and opt.type.get_help_extra():
        extras.append(opt.type.get_help_extra())
    show = ctx.show_default if opt.show_default is None else opt.show_default
    if opt.show_default is not None and not isinstance(opt.show_default, (bool, str)):
        show = bool(opt.show_default)
    if show:
        if isinstance(opt.show_default, str):
            extras.append(f"[default: {opt.show_default}]")
        elif opt.default is not None and not (opt.is_flag and opt.default is False):
            value = "(dynamic)" if callable(opt.default) else opt.default
            if isinstance(value, bool) and not opt.is_flag:
                value = str(value).lower()
            extras.append(f"[default: {value}]")
    if opt.show_envvar and opt.envvar_list:
        extras.append(f"[env var: {', '.join(opt.envvar_list)}]")
    if opt.required:
        extras.append("[required]")
    if opt.deprecated:
        extras.append("[deprecated]")
    return extras


def _usage_line(cmd, ctx, path):
    parts = [path, cmd.options_metavar if cmd.options_metavar else ""]
    for p in cmd.params:
        if isinstance(p, Argument) and not p.hidden:
            ph = p.placeholder()
            if p.is_variadic:
                ph = ph + "..."
            if not p.required:
                ph = f"[{ph}]"
            parts.append(ph)
    if isinstance(cmd, Group):
        meta = cmd.subcommand_metavar
        if cmd.chain:
            sub = meta or "COMMAND [ARGS]..."
            parts.append(sub + " [" + (meta or "COMMAND [ARGS]...") + "]...")
        else:
            sub = meta or "COMMAND [ARGS]..."
            if cmd.invoke_without_command:
                sub = "[" + sub.split(" ")[0] + "]" + sub[len(sub.split(" ")[0]):]
            parts.append(sub)
    return " ".join(p for p in parts if p)


def format_help(cmd, ctx) -> str:
    width = formatting.detect_width(ctx.terminal_width, ctx.max_content_width)
    path = _command_path(ctx)
    out = [f"Usage: {_usage_line(cmd, ctx, path)}", ""]
    if cmd.deprecated:
        note = cmd.deprecated if isinstance(cmd.deprecated, str) else ""
        out.append(formatting.wrap_text("DEPRECATED. " + note if note else "DEPRECATED.", width))
        out.append("")
    if cmd.help:
        out.append(formatting.wrap_text(cmd.help, width))
        out.append("")

    params = cmd.effective_params(ctx)
    args = [p for p in params if isinstance(p, Argument) and p.help and not p.hidden]
    if args:
        out.append("Positional arguments:")
        for a in args:
            out.extend(_entry(a.placeholder(), a.help, width))
        out.append("")

    opts = [o for o in _visible_options(params)]
    if opts:
        out.append("Options:")
        for o in opts:
            text = o.help or ""
            extras = _option_extras(o, ctx)
            if extras:
                text = (text + " " if text else "") + " ".join(extras)
            out.extend(_entry(_option_left(o), text, width))
        out.append("")

    if isinstance(cmd, Group):
        rows = []
        for name in cmd.list_commands(ctx):
            sub = cmd.get_command(ctx, name)
            if sub is None or sub.hidden:
                continue
            rows.append((name, sub.short_help_text(45)))
        if rows:
            out.append("Commands:")
            for name, text in rows:
                out.extend(_entry(name, text, width))
            out.append("")

    if cmd.epilog:
        out.append(formatting.wrap_text(cmd.epilog, width))
        out.append("")
    return "\n".join(out).rstrip("\n") + "\n"


def _entry(left, text, width):
    indent = "  "
    col = 28
    if not text:
        return [indent + left]
    wrapped = formatting.wrap_text(text, max(width - col, 20)).split("\n")
    if len(indent + left) < col - 1:
        lines = [(indent + left).ljust(col) + wrapped[0]]
    else:
        lines = [indent + left]
        lines.append(" " * col + wrapped[0])
    lines.extend(" " * col + ln for ln in wrapped[1:])
    return lines


# -- built-in eager options ------------------------------------------------------

def _help_callback(ctx, param, value):
    if not value or ctx is None:
        return value
    termui.echo(ctx.command.get_help(ctx), color=ctx.color)
    raise Exit(0)


def _help_option(names):
    return Option(["__optlyn_help"] + list(names), is_flag=True, is_eager=True,
                  expose_value=False, callback=_help_callback,
                  help="Show this message and exit.")


def help_option(*param_decls, **kwargs):
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("help", "Show this message and exit.")

    def decorator(f):
        params = f.__dict__.setdefault("__optlyn_params__", [])
        params.append(Option(decls, is_flag=True, is_eager=True, expose_value=False,
                             callback=_help_callback, **kwargs))
        return f

    return decorator


# -- decorators ---------------------------------------------------------------

def command(name=None, cls=None, **attrs):
    """Decorate a function as a leaf command (``@command()`` or ``@command``)."""
    if callable(name) and not isinstance(name, str):
        return command()(name)

    def decorator(f):
        klass = cls or Command
        if isinstance(f, Command):
            raise DeclarationError("command() cannot be applied to an existing command.")
        params = take_params(f)
        return klass(name=name, callback=f, params=params, **attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Decorate a function as a group (``@group()`` or ``@group``)."""
    if callable(name) and not isinstance(name, str):
        return group()(name)

    def decorator(f):
        klass = cls or Group
        params = take_params(f)
        return klass(name=name, callback=f, params=params, **attrs)

    return decorator


__all__ = [
    "Command", "Group", "CommandCollection", "command", "group", "format_help",
    "help_option", "UNSET", "ParameterSource",
]
