"""Parameter objects: options and arguments (PRD FP-03, FP-04; Contract section 4)."""

from __future__ import annotations

import enum
import re

from . import paramtypes as _types
from .exceptions import BadParameter, DeclarationError, MissingParameter

DEFAULT_PREFIXES = ("-",)


class ParameterSource(enum.Enum):
    """Where a parameter's value came from. Distinct per source."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


class _Unset:
    def __repr__(self):
        return "UNSET"


UNSET = _Unset()
_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _is_prefixed(name: str) -> bool:
    return bool(name) and not (name[0].isalnum() or name[0] == "_")


def _split_decls(decls):
    """Split declarations into (dest, flags, secondary_flags)."""
    dest = None
    flags, secondary = [], []
    for decl in decls:
        if not isinstance(decl, str) or not decl:
            raise DeclarationError(f"Invalid parameter declaration {decl!r}.")
        if _is_prefixed(decl):
            parts = decl.split("/")
            if len(parts) == 2 and parts[0] and parts[1] and _is_prefixed(parts[0]) \
                    and _is_prefixed(parts[1]):
                flags.append(parts[0])
                secondary.append(parts[1])
            else:
                flags.append(decl)
        else:
            if dest is not None:
                raise DeclarationError("Only one destination name may be given.")
            dest = decl
    return dest, flags, secondary


def _infer_dest(flags, secondary):
    """Destination from flag names: valid identifier, else first long, else first short."""
    if not flags:
        raise DeclarationError("An option needs a destination or at least one flag name.")
    for name in flags:
        if _IDENT.match(name):
            return name
    longs = [f for f in flags if f.startswith("--")] or flags
    base = longs[0].lstrip("-/+")
    return base.replace("-", "_")


class Parameter:
    """Base for options and arguments."""

    param_type_name = "parameter"
    is_flag = False
    count = False
    prompt = False

    def __init__(self, param_decls=(), type=None, default=None, required=False,
                 callback=None, nargs=None, multiple=False, metavar=None,
                 expose_value=True, is_eager=False, envvar=None, shell_complete=None,
                 deprecated=False, help=None, hidden=False, show_default=None,
                 show_envvar=False, **extra):
        self.dest_hint, self.opts, self.secondary_opts = _split_decls(param_decls)
        self.type = _types.convert_type(type, default)
        self.default = default
        self.required = bool(required)
        self.callback = callback
        self.nargs = nargs
        self.multiple = bool(multiple)
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = bool(is_eager)
        self.envvar = envvar
        self.shell_complete = shell_complete
        self.deprecated = deprecated
        self.help = help
        self.hidden = hidden
        self.show_default = show_default
        self.show_envvar = show_envvar
        self.extra = extra
        self.name = self.dest_hint

    # -- derived properties --------------------------------------------------
    @property
    def envvar_list(self):
        if self.envvar is None:
            return []
        if isinstance(self.envvar, str):
            return [self.envvar]
        return list(self.envvar)

    @property
    def arity(self):
        if self.type.is_composite:
            return self.type.arity
        return self.nargs if self.nargs not in (None, -1) else 1

    @property
    def is_variadic(self):
        return self.nargs == -1

    @property
    def is_scalar(self):
        return (not self.multiple) and self.arity == 1 and not self.type.is_composite

    def describe(self):
        return self.name or self.dest_hint or "parameter"

    def get_default(self, ctx):
        d = self.default
        if callable(d):
            return d()
        return d

    def has_default(self):
        return self.default is not None

    def convert_one(self, value, ctx):
        """Convert one occurrence (a scalar, or a tuple for multi-value/tuple types)."""
        if value is None or value is UNSET:
            return value
        if self.type.is_composite or self.arity != 1:
            if isinstance(value, (str, bytes)) or not hasattr(value, "__iter__"):
                value = (value,)
            if self.type.is_composite:
                return self.type.convert(tuple(value), self, ctx)
            return tuple(self.type.convert(v, self, ctx) for v in value)
        return self.type.convert(value, self, ctx)

    def convert_value(self, value, ctx):
        """Convert a whole value: a sequence of occurrences when repeatable."""
        if value is None or value is UNSET:
            return value
        if self.multiple:
            if isinstance(value, (str, bytes)) or not hasattr(value, "__iter__"):
                raise BadParameter(
                    f"needs an iterable (sequence) default for {self.describe()}.",
                    ctx=ctx, param=self,
                )
            return tuple(self.convert_one(v, ctx) for v in value)
        return self.convert_one(value, ctx)

    def process_value(self, value, ctx):
        """Convert then run the parameter callback (which may replace or refuse)."""
        if not self.is_flag and not self.count:
            value = self.convert_value(value, ctx)
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"


class Option(Parameter):
    param_type_name = "option"

    def __init__(self, param_decls=(), is_flag=None, flag_value=None, count=False,
                 prompt=False, prompt_required=False, hide_input=False,
                 confirmation_prompt=False, allow_from_autoenv=True, **kwargs):
        super().__init__(param_decls, **kwargs)
        if not self.opts and not self.secondary_opts:
            raise DeclarationError("An option needs at least one flag name.")
        if self.name is None:
            self.name = _infer_dest(self.opts, self.secondary_opts)
        if is_flag is None:
            # A boolean default with no value-shaping keywords implies a flag.
            is_flag = isinstance(self.default, bool) and self.type is _types.BOOL \
                and self.nargs is None and not self.multiple and not count
        self.is_flag = bool(is_flag or self.secondary_opts or count)
        self.count = bool(count)
        self.flag_value = flag_value
        if self.count:
            self.type = _types.INT
            self.multiple = False
        elif self.is_flag and self.type is not _types.BOOL and self.extra.get("type") is None \
                and kwargs.get("type") is None:
            self.type = _types.BOOL
        if self.is_flag and self.nargs not in (None, 1):
            raise DeclarationError("A flag cannot take a number of values.")
        if self.nargs is not None and self.nargs < 1:
            raise DeclarationError("nargs for an option must be a positive integer.")
        if self.multiple and self.nargs is not None and self.nargs < 1:
            raise DeclarationError("Invalid nargs.")
        self.prompt = prompt
        self.prompt_text = prompt if isinstance(prompt, str) else None
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        self.allow_from_autoenv = allow_from_autoenv
        if self.deprecated and self.required:
            raise DeclarationError("A deprecated option cannot be required.")
        if self.deprecated and self.prompt:
            raise DeclarationError("A deprecated option cannot use a prompt.")
        if self.is_flag and self.prompt:
            # Prompting flags are not meaningful; allow only value options.
            raise DeclarationError("A flag cannot prompt.")
        if self.is_flag and self.multiple:
            raise DeclarationError("A flag cannot be repeatable.")

    @staticmethod
    def flag_value_given(flag_value):
        return flag_value is not None

    @property
    def takes_value(self):
        return not self.is_flag

    @property
    def is_optional_value(self):
        # A value option whose flag may appear alone and yield flag_value.
        return (not self.is_flag) and self.flag_value is not None

    @property
    def all_flags(self):
        return self.opts + self.secondary_opts

    def describe(self):
        if self.opts:
            return f"'{self.opts[0]}'"
        if self.secondary_opts:
            return f"'{self.secondary_opts[0]}'"
        return self.name

    def flag_default(self):
        """Value produced by the flag alone (no explicit value)."""
        if self.count:
            return 1
        if self.flag_value is not None:
            return self.flag_value
        if self.is_flag:
            return True
        return UNSET

    def declared_default_for_flag(self):
        if self.default is None:
            return False
        return self.default


class Argument(Parameter):
    param_type_name = "argument"

    def __init__(self, param_decls=(), required=None, **kwargs):
        super().__init__(param_decls, required=False, **kwargs)
        if len(self.opts) or len(self.secondary_opts):
            raise DeclarationError("An argument takes a destination name, not flag names.")
        if self.name is None:
            raise DeclarationError("An argument needs a destination name.")
        if self.name is None or not self.name:
            raise DeclarationError("An argument needs a destination name.")
        if self.nargs is not None and self.nargs != -1 and self.nargs < 1:
            raise DeclarationError("nargs for an argument must be a positive integer or -1.")
        if required is None:
            # Argument with neither default nor optional marking counts as required.
            required = self.default is None and self.nargs != -1
        self.required = bool(required)
        if self.deprecated and self.required:
            raise DeclarationError("A deprecated argument cannot be required.")
        if self.nargs == -1 and self.multiple:
            raise DeclarationError("A variadic argument cannot be repeatable.")
        if self.nargs == -1 and self.required is False and self.default is None:
            pass

    def describe(self):
        return self.name

    def placeholder(self):
        if self.metavar:
            return self.metavar
        return self.name.upper()

    def missing_error(self, ctx):
        return MissingParameter(f"Argument '{self.name}' is required.", ctx=ctx, param=self)


def option(*param_decls, cls=None, **attrs):
    """Decorator attaching an option to a function (applied to the callback)."""
    klass = cls or Option

    def decorator(f):
        params = f.__dict__.setdefault("__optlyn_params__", [])
        params.append(klass(list(param_decls), **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Decorator attaching a positional argument to a function."""
    klass = cls or Argument

    def decorator(f):
        params = f.__dict__.setdefault("__optlyn_params__", [])
        params.append(klass(list(param_decls), **attrs))
        return f

    return decorator


def take_params(f):
    """Pop declarations off a function, in declaration order (top to bottom)."""
    params = f.__dict__.pop("__optlyn_params__", [])
    params.reverse()
    return params
