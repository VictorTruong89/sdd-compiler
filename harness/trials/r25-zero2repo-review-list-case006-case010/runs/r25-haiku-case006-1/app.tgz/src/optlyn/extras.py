"""Callback decorators and ready-made options (PRD FP-02, FP-07, FP-08; Contract sections 4, 6)."""

from __future__ import annotations

import functools
import importlib.metadata as _md

from . import termui
from ._state import current as _current
from .exceptions import Exit, DeclarationError
from .params import Option


def pass_context(f):
    """Pass the current Context as the first positional argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(_current(), *args, **kwargs)

    return new_func


def pass_obj(f):
    """Pass the current context's author object as the first positional argument."""

    @functools.wraps(f)
    def new_func(*args, **kwargs):
        return f(_current().obj, *args, **kwargs)

    return new_func


def make_pass_decorator(object_type, ensure=False):
    """Pass the nearest object of exactly ``object_type`` (created when ``ensure``)."""

    def decorator(f):
        @functools.wraps(f)
        def new_func(*args, **kwargs):
            ctx = _current()
            obj = ctx.ensure_object(object_type) if ensure else ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(f"Managed to invoke callback without a context object of "
                                   f"type {object_type.__name__!r} existing.")
            return f(obj, *args, **kwargs)

        return new_func

    return decorator


def _eager_flag(decls, callback, **kwargs):
    kwargs.setdefault("help", "Show the version and exit.")
    return Option(list(decls), is_flag=True, is_eager=True, expose_value=False,
                  callback=callback, **kwargs)


def _add(decls_default, attach):
    """Return a decorator that attaches an option built by ``attach(decls)``."""

    def decorator(f):
        params = f.__dict__.setdefault("__optlyn_params__", [])
        params.append(attach(decls_default))
        return f

    return decorator


def _detect_version(package_name, prog_name):
    if package_name:
        try:
            return _md.version(package_name)
        except _md.PackageNotFoundError:
            dists = _md.packages_distributions().get(package_name)
            if dists:
                return _md.version(dists[0])
            raise RuntimeError(f"{package_name!r} is not an installed package.")
    return prog_name or "unknown"


def version_option(version=None, *param_decls, package_name=None, prog_name=None,
                   message=None, **kwargs):
    """Eager flag printing the version identity and exiting."""
    decls = list(param_decls) or ["--version"]
    template = message or "%(prog)s, version %(version)s"

    def callback(ctx, param, value):
        if not value or ctx is None:
            return value
        resolved = version or _detect_version(package_name, prog_name or ctx.info_name)
        prog = prog_name or _root_name(ctx)
        termui.echo(template % {"prog": prog, "version": resolved}, color=ctx.color)
        raise Exit(0)

    kwargs.setdefault("help", "Show the version and exit.")
    return _add(decls, lambda d: _eager_flag(d, callback, **kwargs))


def custom_version_option(callback_fn, *param_decls, **kwargs):
    """Eager flag whose printed identity is exactly what ``callback_fn(ctx)`` returns."""
    decls = list(param_decls) or ["--version"]

    def callback(ctx, param, value):
        if not value or ctx is None:
            return value
        termui.echo(callback_fn(ctx), color=ctx.color)
        raise Exit(0)

    return _add(decls, lambda d: _eager_flag(d, callback, **kwargs))


def _root_name(ctx):
    node = ctx
    while node.parent is not None:
        node = node.parent
    return node.info_name or ""


def password_option(*param_decls, **kwargs):
    """Hidden, confirmed prompt option (``--password`` by default)."""
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return _add(decls, lambda d: Option(list(d), **kwargs))


def confirmation_option(*param_decls, **kwargs):
    """Yes-style flag that asks when omitted and aborts when declined (``--yes`` by default)."""
    decls = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", None) or "Do you want to continue?"
    if kwargs.get("is_flag") is False:
        raise DeclarationError("A confirmation option is always a flag.")

    def callback(ctx, param, value):
        if value:
            return value
        if ctx is None:
            return value
        if termui.confirm(question, default=False, abort=True):
            return True
        return False

    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs.setdefault("expose_value", False)
    kwargs["callback"] = callback
    kwargs["is_flag"] = True
    return _add(decls, lambda d: Option(list(d), **kwargs))


__all__ = [
    "pass_context", "pass_obj", "make_pass_decorator", "version_option",
    "custom_version_option", "password_option", "confirmation_option",
]
