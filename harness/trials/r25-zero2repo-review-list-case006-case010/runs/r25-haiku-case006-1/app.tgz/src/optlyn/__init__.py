"""Optlyn: a command line interface composition kit.

Importing this package performs no I/O, starts no processes, and opens no sockets.
"""

from .context import Context, get_current_context
from .core import Command, CommandCollection, Group, command, group, help_option
from .exceptions import Abort, BadParameter, DeclarationError, Exit, OptlynError, UsageError
from .extras import (
    confirmation_option, custom_version_option, make_pass_decorator, pass_context,
    pass_obj, password_option, version_option,
)
from .params import Option, Parameter, argument, option
from .termui import (
    clear, confirm, echo, echo_via_pager, edit, format_filename, get_app_dir,
    get_pager_file, getchar, launch, open_file, pause, progressbar, prompt,
)
from .termui_style import style, unstyle
from .termui import secho as _secho
from .paramtypes import (
    BOOL, FLOAT, INT, STRING, UNPROCESSED, UUID, Choice, DateTime, File, FloatRange,
    IntRange, ParamType, Path, Tuple,
)

secho = _secho

__version__ = "0.1.0"

__all__ = [
    # declaration
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option", "pass_context",
    "pass_obj", "make_pass_decorator",
    # classes
    "Command", "Group", "CommandCollection", "Context", "Option", "Parameter",
    "ParamType", "BadParameter", "Abort", "UsageError", "Exit", "OptlynError",
    "DeclarationError",
    # types
    "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED", "Choice", "DateTime",
    "IntRange", "FloatRange", "Tuple", "File", "Path",
    # terminal helpers
    "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file",
    "progressbar", "prompt", "confirm", "getchar", "pause", "edit", "launch", "clear",
    "get_app_dir", "get_current_context", "format_filename", "open_file",
]
