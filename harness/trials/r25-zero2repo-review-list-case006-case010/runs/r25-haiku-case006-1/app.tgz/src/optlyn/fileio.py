"""File opening helpers shared by File type and open_file (PRD FP-09)."""

from __future__ import annotations

import io
import os
import sys
import tempfile


class _NoCloseStream:
    """Proxy for a standard stream that is not closed when the caller's block ends."""

    def __init__(self, stream):
        object.__setattr__(self, "_stream", stream)

    def __getattr__(self, name):
        return getattr(object.__getattribute__(self, "_stream"), name)

    def __iter__(self):
        return iter(object.__getattribute__(self, "_stream"))

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.flush_safe()
        return False

    def flush_safe(self):
        try:
            object.__getattribute__(self, "_stream").flush()
        except (OSError, ValueError):
            pass


class _LazyFile:
    """Opens the real file on first I/O. Write-mode files are not truncated until used."""

    def __init__(self, filename, mode, encoding, errors, atomic):
        self._filename = filename
        self._mode = mode
        self._encoding = encoding
        self._errors = errors
        self._atomic = atomic
        self._fh = None
        self._tmp = None
        self.closed = False

    def _open(self):
        if self._fh is not None:
            return self._fh
        binary = "b" in self._mode
        kwargs = {} if binary else {"encoding": self._encoding, "errors": self._errors}
        if self._atomic and self._mode[0] == "w":
            directory = os.path.dirname(os.path.abspath(self._filename))
            fd, tmp = tempfile.mkstemp(dir=directory, prefix=".optlyn-", suffix=".tmp")
            os.close(fd)
            self._tmp = tmp
            self._fh = open(tmp, self._mode, **kwargs)
        else:
            self._fh = open(self._filename, self._mode, **kwargs)
        return self._fh

    def __getattr__(self, name):
        if name.startswith("_") and name not in ("_open",):
            raise AttributeError(name)
        return getattr(self._open(), name)

    def write(self, data):
        return self._open().write(data)

    def read(self, *args):
        return self._open().read(*args)

    def __iter__(self):
        return iter(self._open())

    def close(self):
        if self.closed:
            return
        self.closed = True
        if self._fh is not None:
            self._fh.close()
            if self._tmp is not None:
                os.replace(self._tmp, self._filename)
                self._tmp = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


def open_stream(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or the standard stream for the token ``-``.

    Reading opens immediately (so missing files fail up front). Writing opens lazily
    when ``lazy`` is true; otherwise it opens (and truncates) right away.
    """
    binary = "b" in mode
    writing = mode[0] in ("w", "a", "x")

    if filename == "-":
        if writing:
            raw = sys.stdout.buffer if binary else sys.stdout
        else:
            raw = sys.stdin.buffer if binary else sys.stdin
        return _NoCloseStream(raw)

    if not writing:
        kwargs = {} if binary else {"encoding": encoding, "errors": errors}
        return open(filename, mode, **kwargs)

    if lazy:
        return _LazyFile(filename, mode, encoding, errors, atomic)

    lf = _LazyFile(filename, mode, encoding, errors, atomic)
    lf._open()
    return lf


__all__ = ["open_stream", "io"]
