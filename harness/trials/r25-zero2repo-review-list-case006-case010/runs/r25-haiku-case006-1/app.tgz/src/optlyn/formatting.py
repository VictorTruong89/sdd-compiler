"""Text wrapping and help-page layout helpers (PRD FP-02, FP-11)."""

from __future__ import annotations

import re
import shutil
import textwrap

from .termui_style import unstyle

DEFAULT_HELP_WIDTH = 80  # FP-02 maximum content width for help pages
DEFAULT_WRAP_WIDTH = 100  # FP-11 default for wrapped text
SHORT_HELP_LIMIT = 45  # Contract section 2 item 5


def detect_width(explicit=None, max_width=DEFAULT_HELP_WIDTH) -> int:
    """Terminal width: an explicit width is used as-is; auto-detection is capped."""
    if explicit is not None:
        return int(explicit)
    try:
        cols = shutil.get_terminal_size((max_width, 24)).columns
    except OSError:
        cols = max_width
    return max(20, min(cols, max_width)) - 2


def _split_paragraphs(text: str):
    """Yield paragraphs. A paragraph whose first line is only a backspace is kept verbatim."""
    paragraphs = re.split(r"\n\s*\n", text.strip("\n"))
    for para in paragraphs:
        lines = para.split("\n")
        if lines and lines[0].strip("\b") == "" and "\b" in lines[0]:
            kept = [ln for ln in lines[1:]]
            yield ("verbatim", "\n".join(kept))
        else:
            yield ("wrap", " ".join(ln.strip() for ln in lines if ln.strip()))


def wrap_text(text, width=DEFAULT_WRAP_WIDTH, indent="", subsequent_indent=None,
              preserve_paragraphs=False):
    """Rewrap text to ``width``. Never fails on any string."""
    if text is None:
        return ""
    text = str(text)
    if subsequent_indent is None:
        subsequent_indent = indent
    out = []
    for kind, body in _split_paragraphs(text):
        if kind == "verbatim":
            out.append("\n".join(indent + ln for ln in body.split("\n")))
        elif not body:
            out.append("")
        else:
            out.append(
                textwrap.fill(
                    body,
                    width=max(width, 1),
                    initial_indent=indent,
                    subsequent_indent=subsequent_indent,
                    break_long_words=True,
                    break_on_hyphens=False,
                )
            )
    return "\n\n".join(out)


def first_sentence(text: str) -> str:
    text = unstyle(text or "").strip()
    m = re.search(r"(?<=[.!?])\s", text)
    return text[: m.start()] if m else text


def ellipsize(text: str, limit: int) -> str:
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 3)].rstrip() + "..."


def truncate_at_formfeed(text):
    if text is None:
        return None
    return text.split("\f", 1)[0]
