"""Invocation context (PRD FP-07; Contract section 6)."""

from __future__ import annotations

from . import _state
from .exceptions import Abort, Exit
from .params import ParameterSource


class Context:
    """Per-invocation state. Children see the parent chain through ``parent``."""

    def __init__(self, command, parent=None, info_name=None, obj=None, default_map=None,
                 terminal_width=None, max_content_width=None, help_option_names=None,
                 token_normalize_func=None, color=None, show_default=None,
                 allow_extra_args=None, ignore_unknown_options=None,
                 allow_interspersed_args=None, auto_envvar_prefix=None, **extra):
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self._obj = obj
        self.default_map = default_map
        self.terminal_width = terminal_width
        self.max_content_width = max_content_width if max_content_width is not None else 80
        self.help_option_names = list(help_option_names) if help_option_names is not None else None
        self.token_normalize_func = token_normalize_func
        self.color = color
        self.show_default = show_default
        self.allow_extra_args = allow_extra_args
        self.ignore_unknown_options = ignore_unknown_options
        self.allow_interspersed_args = allow_interspersed_args
        self.auto_envvar_prefix = auto_envvar_prefix
        self.extra = extra

        self.params = {}
        self._sources = {}
        self.protected_args = []
        self.invoked_subcommand = None
        self._exit_stack = []
        self._closed = False

        # Inherit settings from the parent where not given.
        if parent is not None:
            for key in ("terminal_width", "max_content_width", "help_option_names",
                        "token_normalize_func", "color", "show_default",
                        "allow_extra_args", "ignore_unknown_options",
                        "allow_interspersed_args", "auto_envvar_prefix"):
                if getattr(self, key) is None:
                    setattr(self, key, getattr(parent, key))
        if self.help_option_names is None:
            self.help_option_names = ["--help"]

    # -- author object --------------------------------------------------------
    @property
    def obj(self):
        if self._obj is not None:
            return self._obj
        if self.parent is not None:
            return self.parent.obj
        return None

    @obj.setter
    def obj(self, value):
        self._obj = value

    def find_object(self, object_type):
        node = self
        while node is not None:
            if node._obj is not None and type(node._obj) is object_type:
                return node._obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self._obj = found
        return found

    # -- value sources ------------------------------------------------------
    def set_source(self, name, source):
        self._sources[name] = source

    def get_parameter_source(self, name):
        """None for an undeclared name; otherwise a ParameterSource."""
        if self.command is None:
            return None
        if name not in {p.name for p in self.command.params}:
            return None
        return self._sources.get(name)

    # -- resources ----------------------------------------------------------
    def with_resource(self, cm):
        value = cm.__enter__()
        self._exit_stack.append(cm)
        return value

    def close(self):
        if self._closed:
            return
        self._closed = True
        while self._exit_stack:
            cm = self._exit_stack.pop()
            try:
                cm.__exit__(None, None, None)
            except Exception:  # pragma: no cover - best effort cleanup
                pass

    # -- control ------------------------------------------------------------
    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def invoke(self, cmd, **kwargs):
        """Run another command with exactly the given values."""
        child = Context(cmd, parent=self, info_name=cmd.name)
        child.params = dict(kwargs)
        with child:
            try:
                return cmd.invoke_with_values(child, dict(kwargs), supplied=True)
            finally:
                child.close()

    def forward(self, cmd, **kwargs):
        """Run another command filling in this command's current values."""
        values = dict(self.params)
        values.update(kwargs)
        child = Context(cmd, parent=self, info_name=cmd.name)
        child.params = dict(values)
        with child:
            try:
                return cmd.invoke_with_values(child, dict(values), supplied=True)
            finally:
                child.close()

    # -- thread-current -----------------------------------------------------
    def __enter__(self):
        _state.push(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        _state.pop()
        return False

    def __repr__(self):
        return f"<Context {self.info_name or ''}>"


def get_current_context(silent=False):
    return _state.current(silent=silent)


__all__ = ["Context", "get_current_context", "ParameterSource"]
