"""In-process runner for commands (PRD FP-14; Contract section 9)."""

from __future__ import annotations

import contextlib
import io
import os
import shutil
import sys
import tempfile


class _Sink:
    """Ordered record of (stream_name, bytes) writes."""

    def __init__(self):
        self.records = []

    def add(self, name, data: bytes):
        self.records.append((name, data))

    def of(self, name) -> bytes:
        return b"".join(d for n, d in self.records if n == name)

    def both(self) -> bytes:
        return b"".join(d for _, d in self.records)


class _RawWriter:
    def __init__(self, sink, name):
        self._sink = sink
        self._name = name

    def write(self, data):
        if isinstance(data, str):
            data = data.encode("utf-8", "surrogateescape")
        self._sink.add(self._name, bytes(data))
        return len(data)

    def flush(self):
        pass


class _CaptureStream:
    """Text stream over the sink; ``.buffer`` gives the bytes view."""

    def __init__(self, sink, name, charset):
        self._sink = sink
        self._name = name
        self.encoding = charset
        self.errors = "strict"
        self.buffer = _RawWriter(sink, name)

    def write(self, s):
        data = s.encode(self.encoding, "strict") if isinstance(s, str) else bytes(s)
        self._sink.add(self._name, data)
        return len(s)

    def isatty(self):
        return False

    def flush(self):
        pass

    def fileno(self):
        raise io.UnsupportedOperation("fileno")


class Result:
    def __init__(self, runner_sink, exit_code, exception, exc_info=None):
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info
        self.stdout_bytes = runner_sink.of("stdout")
        self.stderr_bytes = runner_sink.of("stderr")
        self.output_bytes = runner_sink.both()
        self.stdout = self.stdout_bytes.decode("utf-8", "replace")
        self.stderr = self.stderr_bytes.decode("utf-8", "replace")
        self.output = self.output_bytes.decode("utf-8", "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True,
                 capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        sink = _Sink()
        if isinstance(input, str):
            input_bytes = input.encode(self.charset)
        else:
            input_bytes = input or b""
        stdin = io.TextIOWrapper(io.BytesIO(input_bytes), encoding=self.charset)
        stdout = _CaptureStream(sink, "stdout", self.charset)
        stderr = _CaptureStream(sink, "stderr", self.charset)
        merged_env = dict(self.env)
        merged_env.update(env or {})
        saved_env = {}
        for key, value in merged_env.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        saved = (sys.stdin, sys.stdout, sys.stderr)
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield sink
        finally:
            sys.stdin, sys.stdout, sys.stderr = saved
            for key, old in saved_env.items():
                if old is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = old

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None,
               color=False, **extra):
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if args is None:
            args = []
        elif isinstance(args, str):
            args = args.split()
        extra.setdefault("standalone_mode", True)
        extra.setdefault("prog_name", "cli")
        extra["color"] = color
        standalone = extra.pop("standalone_mode")
        prog_name = extra.pop("prog_name")

        exit_code = 0
        exception = None
        exc_info = None
        with self.isolation(input=input, env=env, color=color) as sink:
            try:
                cli.main(args=list(args), prog_name=prog_name, standalone_mode=standalone,
                         **extra)
            except SystemExit as exc:
                code = exc.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    exit_code = 1
                    sys.stderr.write(str(code) + "\n")
                if exit_code != 0 and exception is None:
                    exception = None
            except Exception as exc:  # noqa: BLE001 - reported on the result
                if not catch_exceptions:
                    raise
                exception = exc
                exc_info = sys.exc_info()
                exit_code = 1
            return Result(sink, exit_code, exception, exc_info)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        cwd = os.getcwd()
        if temp_dir is None:
            path = tempfile.mkdtemp()
        else:
            path = tempfile.mkdtemp(dir=str(temp_dir))
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(path, ignore_errors=True)


__all__ = ["CliRunner", "Result"]
