"""Part-of-speech taggers."""
import json
import os
import re
from collections import Counter, defaultdict

from . import data

__all__ = ["DefaultTagger", "UnigramTagger", "RegexpTagger", "pos_tag", "PerceptronTagger"]


class TaggerI:
    def __init__(self, backoff=None):
        self._backoff = backoff

    def tag(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("tokens must be a list of strings, not a string")
        out = []
        for tok in tokens:
            tag = self.tag_one(tok)
            if tag is None and self._backoff is not None:
                tag = self._backoff.tag([tok])[0][1]
            out.append((tok, tag))
        return out

    def tag_one(self, tok):
        raise NotImplementedError


class DefaultTagger(TaggerI):
    def __init__(self, tag):
        super().__init__(None)
        self._tag = tag

    def tag_one(self, tok):
        return self._tag


class UnigramTagger(TaggerI):
    def __init__(self, train=None, backoff=None, model=None):
        super().__init__(backoff)
        self._model = dict(model) if model else {}
        if train:
            counts = defaultdict(Counter)
            for sent in train:
                for tok, tag in sent:
                    counts[tok][tag] += 1
            for tok, c in counts.items():
                self._model[tok] = c.most_common(1)[0][0]

    def tag_one(self, tok):
        return self._model.get(tok)


class RegexpTagger(TaggerI):
    def __init__(self, regexps, backoff=None):
        super().__init__(backoff)
        self._regexps = [(re.compile(p), t) for p, t in regexps]

    def tag_one(self, tok):
        for rx, t in self._regexps:
            if rx.match(tok):
                return t
        return None


# ------------------------------------------------------ averaged perceptron
class PerceptronTagger:
    START = ["-START-", "-START2-"]
    END = ["-END-", "-END2-"]

    def __init__(self, weights, tagdict, classes):
        self.weights = weights
        self.tagdict = tagdict
        self.classes = list(classes)

    @classmethod
    def load(cls, lang):
        d = data.find("taggers/averaged_perceptron_tagger_%s" % lang)
        base = os.path.join(d, "averaged_perceptron_tagger_%s" % lang)
        try:
            with open(base + ".weights.json", encoding="utf-8") as f:
                weights = json.load(f)
            with open(base + ".tagdict.json", encoding="utf-8") as f:
                tagdict = json.load(f)
            with open(base + ".classes.json", encoding="utf-8") as f:
                classes = json.load(f)
        except OSError as e:
            raise LookupError("tagger resource for %r incomplete: %s" % (lang, e))
        return cls(weights, tagdict, classes)

    @staticmethod
    def normalize(word):
        if "-" in word and word[0] != "-":
            return "!HYPHEN"
        if word.isdigit() and len(word) == 4:
            return "!YEAR"
        if word and word[0].isdigit():
            return "!DIGITS"
        return word.lower()

    def _features(self, i, word, context, prev, prev2):
        feats = defaultdict(int)

        def add(name, *args):
            feats[" ".join((name,) + tuple(args))] += 1

        i += len(self.START)
        add("bias")
        add("i suffix", word[-3:])
        add("i pref1", word[:1])
        add("i-1 tag", prev)
        add("i-2 tag", prev2)
        add("i tag+i-2 tag", prev, prev2)
        add("i word", context[i])
        add("i-1 tag+i word", prev, context[i])
        add("i-1 word", context[i - 1])
        add("i-1 suffix", context[i - 1][-3:])
        add("i-2 word", context[i - 2])
        add("i+1 word", context[i + 1])
        add("i+1 suffix", context[i + 1][-3:])
        add("i+2 word", context[i + 2])
        return feats

    def predict(self, features):
        scores = defaultdict(float)
        for feat, value in features.items():
            if feat not in self.weights or value == 0:
                continue
            for label, w in self.weights[feat].items():
                scores[label] += value * w
        return max(self.classes, key=lambda label: (scores[label], label))

    def tag(self, tokens):
        prev, prev2 = self.START
        context = self.START + [self.normalize(w) for w in tokens] + self.END
        out = []
        for i, word in enumerate(tokens):
            tag = self.tagdict.get(word)
            if not tag:
                tag = self.predict(self._features(i, word, context, prev, prev2))
            out.append((word, tag))
            prev2 = prev
            prev = tag
        return out


_RU_MAP = {
    "A": "ADJ", "A-PRO": "PRON", "ADV": "ADV", "ADV-PRO": "PRON", "ANUM": "ADJ", "CONJ": "CONJ",
    "INTJ": "X", "NONLEX": ".", "NUM": "NUM", "PARENTH": "PRT", "PART": "PRT", "PR": "ADP",
    "PRAEDIC": "PRT", "PRAEDIC-PRO": "PRON", "S": "NOUN", "S-PRO": "PRON", "V": "VERB",
    "COM": "X",
}


def pos_tag(tokens, tagset=None, lang="eng"):
    if isinstance(tokens, str):
        raise TypeError("tokens must be a list of strings, not a string")
    if lang not in ("eng", "rus"):
        raise ValueError("Currently, only 'eng' and 'rus' are supported for lang, not %r" % (lang,))
    if tagset not in (None, "universal"):
        raise ValueError("unsupported tagset %r" % (tagset,))
    tokens = list(tokens)
    tagger = PerceptronTagger.load(lang)
    mapping = None
    if tagset == "universal" and lang == "eng":
        fp = os.path.join(data.find("taggers/universal_tagset"), "en-ptb.map")
        if not os.path.exists(fp):
            raise LookupError("universal tagset table en-ptb.map not found")
        mapping = {}
        for line in data.read_lines(fp):
            parts = line.split("\t")
            if len(parts) >= 2:
                mapping[parts[0]] = parts[1]
    tagged = tagger.tag(tokens)
    if tagset == "universal":
        if lang == "eng":
            tagged = [(w, mapping.get(t, "X")) for w, t in tagged]
        else:
            tagged = [(w, _RU_MAP.get(t.partition("=")[0], "X")) for w, t in tagged]
    return tagged
