"""BLEU."""
import math
import sys
from collections import Counter

__all__ = ["bleu", "sentence_bleu", "SmoothingFunction"]


def _ngrams(tokens, n):
    return [tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1)]


def _modified_precision(references, hypothesis, n):
    counts = Counter(_ngrams(hypothesis, n))
    max_counts = {}
    for ref in references:
        rc = Counter(_ngrams(ref, n))
        for g in counts:
            max_counts[g] = max(max_counts.get(g, 0), rc[g])
    num = sum(min(c, max_counts.get(g, 0)) for g, c in counts.items())
    den = max(1, sum(counts.values()))
    return num, den


def _closest_ref_length(references, hyp_len):
    return min((len(r) for r in references), key=lambda l: (abs(l - hyp_len), l))


def _brevity_penalty(ref_len, hyp_len):
    if hyp_len > ref_len:
        return 1
    if hyp_len == 0:
        return 0
    return math.exp(1 - ref_len / hyp_len)


class SmoothingFunction:
    def __init__(self, epsilon=0.1, alpha=5, k=5):
        self.epsilon = epsilon
        self.alpha = alpha
        self.k = k

    def method0(self, p_n, references, hypothesis, hyp_len):
        return [(n / d) if n != 0 else sys.float_info.min for n, d in p_n]

    def method1(self, p_n, references, hypothesis, hyp_len):
        return [((n + self.epsilon) / d) if n == 0 else n / d for n, d in p_n]

    def method2(self, p_n, references, hypothesis, hyp_len):
        return [(n + 1) / (d + 1) if i != 0 else n / d for i, (n, d) in enumerate(p_n)]


def sentence_bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    if isinstance(hypothesis, str) or any(isinstance(r, str) for r in references):
        raise TypeError("references and hypothesis must be lists of tokens")
    weights = list(weights)
    p_n = [_modified_precision(references, hypothesis, i) for i in range(1, len(weights) + 1)]
    hyp_len = len(hypothesis)
    if p_n and p_n[0][0] == 0:
        return 0
    ref_len = _closest_ref_length(references, hyp_len)
    bp = _brevity_penalty(ref_len, hyp_len)
    smooth = smoothing_function or SmoothingFunction().method0
    ps = smooth(p_n, references, hypothesis, hyp_len)
    s = math.fsum(w * math.log(p) for w, p in zip(weights, ps))
    return bp * math.exp(s)


bleu = sentence_bleu
