"""Parsers for context-free grammars."""
from ..grammar import CFG, Nonterminal
from ..tree import Tree
from .generate import generate  # noqa: F401

__all__ = ["ChartParser", "ShiftReduceParser", "RecursiveDescentParser", "generate"]


class ChartParser:
    """Exhaustive parser returning every parse tree."""

    def __init__(self, grammar):
        self._grammar = grammar
        self._prods = {}
        for p in grammar.productions():
            self._prods.setdefault(p.lhs(), []).append(p)

    def grammar(self):
        return self._grammar

    def parse(self, tokens):
        tokens = list(tokens)
        self._grammar.check_coverage(tokens)
        return iter(self._parse_all(tokens))

    def _parse_all(self, tokens):
        n = len(tokens)
        memo = {}
        active = set()

        def parses(sym, i, j):
            key = (sym, i, j)
            if key in memo:
                return memo[key]
            if key in active:
                return []
            active.add(key)
            result = []
            for prod in self._prods.get(sym, []):
                for children in seq(list(prod.rhs()), i, j):
                    result.append(Tree(str(sym), children))
            active.discard(key)
            memo[key] = result
            return result

        def seq(rhs, i, j):
            if not rhs:
                if i == j:
                    yield []
                return
            first, rest = rhs[0], rhs[1:]
            if isinstance(first, Nonterminal):
                for k in range(i, j + 1):
                    for t in parses(first, i, k):
                        for tail in seq(rest, k, j):
                            yield [t] + tail
            else:
                if first == "":
                    for tail in seq(rest, i, j):
                        yield [first] + tail
                elif i < j and tokens[i] == first:
                    for tail in seq(rest, i + 1, j):
                        yield [first] + tail

        return parses(self._grammar.start(), 0, n)


class RecursiveDescentParser(ChartParser):
    pass


class ShiftReduceParser:
    def __init__(self, grammar):
        self._grammar = grammar
        self._prods = [p for p in grammar.productions() if len(p.rhs()) > 0]

    def grammar(self):
        return self._grammar

    def _match(self, rhs, stack_tail):
        if len(rhs) != len(stack_tail):
            return False
        for s, e in zip(rhs, stack_tail):
            if isinstance(s, Nonterminal):
                if not (isinstance(e, Tree) and e.label() == str(s)):
                    return False
            else:
                if isinstance(e, Tree) or e != s:
                    return False
        return True

    def _reduce(self, stack):
        for prod in self._prods:
            k = len(prod.rhs())
            if len(stack) >= k and self._match(prod.rhs(), stack[len(stack) - k:]):
                children = stack[len(stack) - k:]
                del stack[len(stack) - k:]
                stack.append(Tree(str(prod.lhs()), children))
                return True
        return False

    def parse(self, tokens):
        tokens = list(tokens)
        self._grammar.check_coverage(tokens)
        stack = []
        remaining = tokens[:]
        while remaining:
            stack.append(remaining.pop(0))
            while self._reduce(stack):
                pass
        if len(stack) == 1 and isinstance(stack[0], Tree) and stack[0].label() == str(self._grammar.start()):
            return iter([stack[0]])
        return iter([])
