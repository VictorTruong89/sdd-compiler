"""Regular-expression chunking."""
import os
import re

from . import data
from .tree import Tree

__all__ = ["RegexpParser", "ne_chunk"]

ROOT = "S"


def tag_pattern2re_pattern(pattern):
    pattern = re.sub(r"\s", "", pattern)
    pattern = pattern.replace("<", "(?:<(?:").replace(">", ")>)")
    if re.search(r"(?<!\\)[<>](?![^<>]*$)", re.sub(r"\(\?:<\(\?:|\)>\)", "", pattern)) and False:
        raise ValueError("Bad tag pattern")
    pattern = re.sub(r"(?<!\\)\.", r"[^\{\}<>]", pattern)
    try:
        re.compile(pattern)
    except re.error as e:
        raise ValueError("Bad tag pattern %r: %s" % (pattern, e))
    return pattern


class _Rule:
    def __init__(self, kind, pattern):
        self.kind = kind
        self.pattern = pattern
        self.regexp = re.compile(tag_pattern2re_pattern(pattern))

    def apply(self, s):
        if self.kind == "chunk":
            rx = re.compile("(?P<chunk>" + self.regexp.pattern + r")(?=[^\}]*(\{|$))")
            repl = lambda m: ("{" + m.group(0) + "}") if m.group(0) else ""
            s = rx.sub(lambda m: ("{" + m.group("chunk") + "}") if m.group("chunk") else "", s)
        else:
            rx = re.compile("(?P<chink>" + self.regexp.pattern + r")(?=[^\{]*\})")
            s = rx.sub(lambda m: ("}" + m.group("chink") + "{") if m.group("chink") else "", s)
        s = s.replace("{}", "")
        return s


class _Stage:
    def __init__(self, label, rules):
        self.label = label
        self.rules = rules

    def parse(self, tree_or_list, root_label):
        children = list(tree_or_list)
        tags = []
        for ch in children:
            if isinstance(ch, Tree):
                tags.append(str(ch.label()))
            else:
                tags.append(str(ch[1]))
        s = "".join("<%s>" % t for t in tags)
        for r in self.rules:
            s = r.apply(s)
        out = []
        idx = 0
        current = None
        for m in re.finditer(r"\{|\}|<[^<>{}]*>", s):
            tok = m.group(0)
            if tok == "{":
                current = []
            elif tok == "}":
                if current is not None:
                    out.append(Tree(self.label, current))
                current = None
            else:
                item = children[idx]
                idx += 1
                (current if current is not None else out).append(item)
        return Tree(root_label, out)


class RegexpParser:
    def __init__(self, grammar, root_label=ROOT, loop=1):
        self._root = root_label
        self._loop = loop
        if isinstance(grammar, str):
            self._stages = self._read_grammar(grammar)
        elif isinstance(grammar, (list, tuple)) and all(isinstance(s, _Stage) for s in grammar):
            self._stages = list(grammar)
        else:
            raise TypeError("grammar must be a string or a list of chunk-parser stages")

    @staticmethod
    def _read_grammar(text):
        stages = []
        label = None
        rules = []
        for raw in text.split("\n"):
            line = raw.split("#")[0].strip() if not raw.strip().startswith("#") else ""
            if not line:
                continue
            m = re.match(r"^([^:{}<>\s][^:{}<>]*?)\s*:\s*(.*)$", line)
            if m and not line.startswith(("{", "}")):
                if label is not None:
                    stages.append(_Stage(label, rules))
                label, rules = m.group(1).strip(), []
                line = m.group(2).strip()
                if not line:
                    continue
            if label is None:
                raise ValueError("Illegal chunk pattern outside a clause: %r" % line)
            if line.startswith("{") and line.endswith("}"):
                rules.append(_Rule("chunk", line[1:-1]))
            elif line.startswith("}") and line.endswith("{"):
                rules.append(_Rule("chink", line[1:-1]))
            else:
                raise ValueError("Illegal chunk pattern: %r" % line)
        if label is not None:
            stages.append(_Stage(label, rules))
        return stages

    def parse(self, tokens):
        if isinstance(tokens, str):
            raise TypeError("expected a list of tagged tokens")
        tree = Tree(self._root, [tuple(t) for t in tokens])
        for _ in range(self._loop):
            for stage in self._stages:
                tree = stage.parse(tree, self._root)
        return tree


def ne_chunk(tagged_tokens, binary=False):
    model = data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    data.find("corpora/words")
    raise NotImplementedError("named-entity chunking model is present at %s but no NE chunker is implemented" % model)
