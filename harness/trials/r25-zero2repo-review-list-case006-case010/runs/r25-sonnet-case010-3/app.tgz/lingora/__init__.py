"""Lingora Language Toolkit: a pure-Python NLP library."""

__version__ = "0.1.0"

from . import data  # noqa: F401
