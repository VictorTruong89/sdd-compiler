"""Packaged-resource lookup.

``path`` is a mutable list of directories searched for resources.
"""
import os

path = []

_env = os.environ.get("LINGORA_DATA")
if _env:
    path.extend(p for p in _env.split(os.pathsep) if p)
path.extend(
    [
        os.path.join(os.path.expanduser("~"), "lingora_data"),
        "/usr/share/lingora_data",
        "/usr/local/share/lingora_data",
        os.path.join(os.path.expanduser("~"), "nltk_data"),
        "/usr/share/nltk_data",
        "/usr/local/share/nltk_data",
    ]
)


def find(resource):
    """Return the filesystem path of ``resource`` found on ``path``.

    Raises LookupError when it is not visible in any listed directory.
    """
    resource = resource.rstrip("/")
    for d in list(path):
        cand = os.path.join(str(d), *resource.split("/"))
        if os.path.exists(cand):
            return cand
    raise LookupError(
        "Resource %r not found in data.path (%s)" % (resource, ", ".join(map(str, path)))
    )


def read_lines(filepath):
    with open(filepath, encoding="utf-8") as f:
        return f.read().splitlines()
