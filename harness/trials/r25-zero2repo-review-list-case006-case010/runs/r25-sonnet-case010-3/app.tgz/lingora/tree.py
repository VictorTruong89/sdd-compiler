"""Constituent trees."""
import re

__all__ = ["Tree"]


class Tree(list):
    def __init__(self, label, children=None):
        if children is None or isinstance(children, str):
            raise TypeError("children should be a list, not %s" % type(children).__name__)
        list.__init__(self, children)
        self._label = label

    # -- comparison ---------------------------------------------------
    def __eq__(self, other):
        return (
            isinstance(other, Tree)
            and self._label == other._label
            and list.__eq__(self, other)
        )

    def __ne__(self, other):
        return not self == other

    __hash__ = None

    # -- access -------------------------------------------------------
    def label(self):
        return self._label

    def set_label(self, label):
        self._label = label

    def leaves(self):
        out = []
        for child in self:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def height(self):
        h = 0
        for child in self:
            h = max(h, child.height() if isinstance(child, Tree) else 1)
        return h + 1

    def subtrees(self, filter=None):
        if filter is None or filter(self):
            yield self
        for child in self:
            if isinstance(child, Tree):
                yield from child.subtrees(filter)

    def productions(self):
        from .grammar import Nonterminal, Production
        rhs = []
        for child in self:
            rhs.append(Nonterminal(child._label) if isinstance(child, Tree) else child)
        prods = [Production(Nonterminal(self._label), rhs)]
        for child in self:
            if isinstance(child, Tree):
                prods.extend(child.productions())
        return prods

    def copy(self, deep=False):
        if not deep:
            return type(self)(self._label, self)
        return type(self)(self._label, [c.copy(True) if isinstance(c, Tree) else c for c in self])

    # -- text ---------------------------------------------------------
    @classmethod
    def fromstring(cls, s):
        toks = re.findall(r"\(|\)|[^\s()]+", s)
        if not toks:
            raise ValueError("empty tree text")
        pos = 0

        def parse():
            nonlocal pos
            if toks[pos] != "(":
                raise ValueError("expected '(' at token %d" % pos)
            pos += 1
            label = ""
            if pos < len(toks) and toks[pos] not in "()":
                label = toks[pos]
                pos += 1
            children = []
            while True:
                if pos >= len(toks):
                    raise ValueError("unbalanced brackets: missing ')'")
                t = toks[pos]
                if t == ")":
                    pos += 1
                    return cls(label, children)
                if t == "(":
                    children.append(parse())
                else:
                    children.append(t)
                    pos += 1

        tree = parse()
        if pos != len(toks):
            raise ValueError("unexpected text after end of tree")
        return tree

    def pformat(self, margin=70, indent=0):
        flat = self._flat()
        if len(flat) + indent <= margin:
            return flat
        parts = ["(%s" % (self._label,)]
        for child in self:
            parts.append("\n" + " " * (indent + 2))
            if isinstance(child, Tree):
                parts.append(child.pformat(margin, indent + 2))
            else:
                parts.append(str(child) if not isinstance(child, tuple) else "/".join(map(str, child)))
        return "".join(parts) + ")"

    def _flat(self):
        parts = []
        for child in self:
            if isinstance(child, Tree):
                parts.append(child._flat())
            elif isinstance(child, tuple):
                parts.append("/".join(map(str, child)))
            else:
                parts.append(str(child))
        return "(%s%s)" % (self._label, "".join(" " + p for p in parts))

    def pretty_print(self, **kwargs):
        print(self.pformat())

    def __str__(self):
        return self.pformat()

    def __repr__(self):
        return "Tree(%r, [%s])" % (self._label, ", ".join(repr(c) for c in self))
