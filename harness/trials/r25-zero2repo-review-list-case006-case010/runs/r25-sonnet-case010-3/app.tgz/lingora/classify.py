"""Naive Bayes and decision tree classifiers."""
import math
from collections import Counter, defaultdict

__all__ = ["NaiveBayesClassifier", "DecisionTreeClassifier", "accuracy", "DictionaryProbDist"]


class DictionaryProbDist:
    def __init__(self, prob_dict, log=False, normalize=False):
        self._prob = dict(prob_dict)
        self._log = log
        if normalize:
            if log:
                vals = list(self._prob.values())
                m = max(vals) if vals else 0.0
                total = m + math.log(sum(math.exp(v - m) for v in vals)) if vals else 0.0
                self._prob = {k: v - total for k, v in self._prob.items()}
            else:
                total = sum(self._prob.values())
                self._prob = {k: v / total for k, v in self._prob.items()}

    def prob(self, sample):
        v = self._prob.get(sample)
        if v is None:
            return 0.0
        return float(math.exp(v)) if self._log else float(v)

    def logprob(self, sample):
        v = self._prob.get(sample)
        if v is None:
            return -math.inf
        return v if self._log else (math.log(v) if v > 0 else -math.inf)

    def samples(self):
        return list(self._prob.keys())

    def max(self):
        return max(self._prob, key=lambda s: self._prob[s])

    def __repr__(self):
        return "<ProbDist with %d samples>" % len(self._prob)


class NaiveBayesClassifier:
    def __init__(self, label_counts, feature_counts, feature_values, fnames):
        self._label_counts = label_counts
        self._feature_counts = feature_counts  # (label, fname) -> Counter
        self._feature_values = feature_values
        self._fnames = fnames
        self._labels = list(label_counts)

    @classmethod
    def train(cls, labeled_featuresets):
        label_counts = Counter()
        feature_counts = defaultdict(Counter)
        feature_values = defaultdict(set)
        fnames = {}
        for fs, label in labeled_featuresets:
            label_counts[label] += 1
            for fname, fval in fs.items():
                feature_counts[label, fname][fval] += 1
                feature_values[fname].add(fval)
                fnames[fname] = True
        for label in label_counts:
            n = label_counts[label]
            for fname in fnames:
                c = feature_counts[label, fname]
                missing = n - sum(c.values())
                if missing:
                    c[None] += missing
                    feature_values[fname].add(None)
        return cls(label_counts, dict(feature_counts), dict(feature_values), fnames)

    def labels(self):
        return list(self._labels)

    def prob_classify(self, featureset):
        total = sum(self._label_counts.values())
        nl = len(self._label_counts)
        logprob = {}
        for label in self._labels:
            logprob[label] = math.log((self._label_counts[label] + 0.5) / (total + 0.5 * nl))
        for fname, fval in featureset.items():
            if fname not in self._fnames:
                continue
            bins = len(self._feature_values[fname])
            for label in self._labels:
                c = self._feature_counts[label, fname]
                n = sum(c.values())
                try:
                    cnt = c.get(fval, 0)
                except TypeError:
                    cnt = 0
                logprob[label] += math.log((cnt + 0.5) / (n + 0.5 * bins))
        return DictionaryProbDist(logprob, log=True, normalize=True)

    def classify(self, featureset):
        return self.prob_classify(featureset).max()

    def classify_many(self, featuresets):
        return [self.classify(fs) for fs in featuresets]


def _entropy(labels):
    c = Counter(labels)
    n = sum(c.values())
    return -sum((v / n) * math.log2(v / n) for v in c.values()) if n else 0.0


def _majority(labels):
    return Counter(labels).most_common(1)[0][0]


class DecisionTreeClassifier:
    def __init__(self, label, feature_name=None, decisions=None, default=None):
        self._label = label
        self._fname = feature_name
        self._decisions = decisions
        self._default = default

    def classify(self, featureset):
        if self._fname is None:
            return self._label
        fval = featureset.get(self._fname)
        try:
            if fval in self._decisions:
                return self._decisions[fval].classify(featureset)
        except TypeError:
            pass
        if self._default is not None:
            return self._default.classify(featureset)
        return self._label

    def classify_many(self, featuresets):
        return [self.classify(f) for f in featuresets]

    def error(self, labeled):
        errors = sum(1 for fs, l in labeled if self.classify(fs) != l)
        return errors / len(labeled)

    @staticmethod
    def leaf(labeled):
        return DecisionTreeClassifier(_majority([l for _, l in labeled]))

    @staticmethod
    def stump(fname, labeled):
        label = _majority([l for _, l in labeled])
        groups = {}
        for fs, l in labeled:
            groups.setdefault(fs.get(fname), []).append(l)
        decisions = {v: DecisionTreeClassifier(_majority(ls)) for v, ls in groups.items()}
        return DecisionTreeClassifier(label, fname, decisions)

    @staticmethod
    def best_stump(fnames, labeled):
        best = DecisionTreeClassifier.leaf(labeled)
        best_err = best.error(labeled)
        for fname in fnames:
            s = DecisionTreeClassifier.stump(fname, labeled)
            e = s.error(labeled)
            if e < best_err:
                best, best_err = s, e
        return best

    def refine(self, data, entropy_cutoff, depth_cutoff, support_cutoff):
        if len(data) <= support_cutoff or self._fname is None or depth_cutoff <= 0:
            return
        for fval in list(self._decisions):
            sub = [(fs, l) for fs, l in data if fs.get(self._fname) == fval]
            if sub and _entropy([l for _, l in sub]) > entropy_cutoff:
                self._decisions[fval] = DecisionTreeClassifier.train(
                    sub, entropy_cutoff, depth_cutoff - 1, support_cutoff)

    @classmethod
    def train(cls, labeled_featuresets, entropy_cutoff=0.05, depth_cutoff=100, support_cutoff=10):
        labeled_featuresets = list(labeled_featuresets)
        if not labeled_featuresets:
            raise ValueError("cannot train on an empty training set")
        fnames = {}
        for fs, _ in labeled_featuresets:
            for f in fs:
                fnames[f] = True
        tree = cls.best_stump(fnames, labeled_featuresets)
        tree.refine(labeled_featuresets, entropy_cutoff, depth_cutoff - 1, support_cutoff)
        return tree


def accuracy(classifier, gold):
    gold = list(gold)
    if not gold:
        return 0.0
    results = [classifier.classify(fs) for fs, _ in gold]
    return sum(1 for r, (_, l) in zip(results, gold) if r == l) / len(gold)
