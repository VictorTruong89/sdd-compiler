"""Punkt sentence-boundary detection (Kiss & Strunk 2006) with packaged parameters."""
import os
import re

from . import data

_ORTHO_BEG_UC = 2
_ORTHO_MID_UC = 4
_ORTHO_UNK_UC = 8
_ORTHO_UC = 14
_ORTHO_BEG_LC = 16
_ORTHO_MID_LC = 32
_ORTHO_UNK_LC = 64
_ORTHO_LC = 112

_NONWORD = r"(?:[?!)\";}\]\*:@\'\({\[])"
_MULTI = r"(?:\-{2,}|\.{2,}|(?:\.\s){2,}\.)"
_WORDSTART = r"[^\(\"\`{\[:;&\#\*@\)}\]\-,]"
_PERIOD_CONTEXT = re.compile(
    r"[.?!](?=(?P<after_tok>" + _NONWORD + r"|\s+(?P<next_tok>\S+)))"
)
_WORD_TOKENIZE = re.compile(
    "("
    + _MULTI
    + "|(?=" + _WORDSTART + r")\S+?(?=\s|$|" + _NONWORD + "|" + _MULTI
    + r"|,(?=$|\s|(?:" + _NONWORD + "|" + _MULTI + ")))"
    + r"|\S)"
)
_REALIGN = re.compile(r"[\"\')\]}]+?(?:\s+|(?=--)|$)")
_RE_NUMERIC = re.compile(r"^-?[\.,]?\d[\d,\.-]*\.?$")
_RE_INITIAL = re.compile(r"^[^\W\d]\.$")
_RE_ELLIPSIS = re.compile(r"\.\.+$")
_SENT_END = ".?!"


class _Tok:
    __slots__ = ("tok", "type", "period_final", "sentbreak", "abbr", "ellipsis")

    def __init__(self, tok):
        self.tok = tok
        self.type = "##number##" if _RE_NUMERIC.match(tok) else tok.lower()
        self.period_final = tok.endswith(".")
        self.sentbreak = False
        self.abbr = False
        self.ellipsis = False

    @property
    def type_no_period(self):
        if len(self.type) > 1 and self.type[-1] == ".":
            return self.type[:-1]
        return self.type

    @property
    def type_no_sentperiod(self):
        return self.type_no_period if self.sentbreak else self.type

    @property
    def first_upper(self):
        return self.tok[:1].isupper()

    @property
    def first_lower(self):
        return self.tok[:1].islower()

    @property
    def is_initial(self):
        return bool(_RE_INITIAL.match(self.tok))


class PunktParameters:
    def __init__(self):
        self.abbrev_types = set()
        self.collocations = set()
        self.sent_starters = set()
        self.ortho_context = {}

    @classmethod
    def load(cls, directory):
        p = cls()

        def lines(name):
            fp = os.path.join(directory, name)
            if not os.path.exists(fp):
                raise LookupError("Punkt model file missing: %s" % fp)
            return [l for l in data.read_lines(fp) if l != ""]

        p.abbrev_types = set(lines("abbrev_types.txt"))
        p.sent_starters = set(lines("sent_starters.txt"))
        for l in lines("collocations.tab"):
            parts = l.split("\t")
            if len(parts) >= 2:
                p.collocations.add((parts[0], parts[1]))
        for l in lines("ortho_context.tab"):
            parts = l.split("\t")
            if len(parts) >= 2:
                p.ortho_context[parts[0]] = int(parts[1])
        return p


_cache = {}


def load_params(language):
    d = data.find("tokenizers/punkt_tab/%s" % language)
    if not os.path.isdir(d):
        raise LookupError("Punkt model for %r not found" % language)
    key = os.path.abspath(d)
    if key not in _cache:
        _cache[key] = PunktParameters.load(d)
    return _cache[key]


class PunktSentenceTokenizer:
    def __init__(self, params):
        self._p = params

    @classmethod
    def for_language(cls, language="english"):
        return cls(load_params(language))

    # -- heuristics -------------------------------------------------
    def _ortho_heuristic(self, tok):
        if tok.tok in (";", ":", ",", ".", "!", "?"):
            return False
        ortho = self._p.ortho_context.get(tok.type_no_sentperiod, 0)
        if tok.first_upper and (ortho & _ORTHO_LC) and not (ortho & _ORTHO_MID_UC):
            return True
        if tok.first_lower and ((ortho & _ORTHO_UC) or not (ortho & _ORTHO_BEG_LC)):
            return False
        return "unknown"

    def _first_pass(self, t):
        tok = t.tok
        if tok in _SENT_END:
            t.sentbreak = True
        elif _RE_ELLIPSIS.match(tok):
            t.ellipsis = True
        elif t.period_final and not tok.endswith(".."):
            stem = tok[:-1].lower()
            if stem in self._p.abbrev_types or stem.split("-")[-1] in self._p.abbrev_types:
                t.abbr = True
            else:
                t.sentbreak = True

    def _second_pass(self, t1, t2):
        if t2 is None or not t1.period_final:
            return
        typ = t1.type_no_period
        next_typ = t2.type_no_sentperiod
        initial = t1.is_initial
        if (typ, next_typ) in self._p.collocations:
            t1.sentbreak = False
            t1.abbr = True
            return
        if (t1.abbr or t1.ellipsis) and not initial:
            if self._ortho_heuristic(t2) is True:
                t1.sentbreak = True
                return
            if t2.first_upper and next_typ in self._p.sent_starters:
                t1.sentbreak = True
                return
        if initial or typ == "##number##":
            h = self._ortho_heuristic(t2)
            if h is False:
                t1.sentbreak = False
                t1.abbr = True
                return
            if (
                h == "unknown"
                and initial
                and t2.first_upper
                and not (self._p.ortho_context.get(next_typ, 0) & _ORTHO_LC)
            ):
                t1.sentbreak = False
                t1.abbr = True

    def _contains_sentbreak(self, text):
        toks = [_Tok(m.group(0)) for m in _WORD_TOKENIZE.finditer(text)]
        for t in toks:
            self._first_pass(t)
        for i, t in enumerate(toks):
            self._second_pass(t, toks[i + 1] if i + 1 < len(toks) else None)
        found = False
        for t in toks:
            if found:
                return True
            if t.sentbreak:
                found = True
        return False

    # -- splitting --------------------------------------------------
    @staticmethod
    def _last_ws_index(s):
        for i in range(len(s) - 1, -1, -1):
            if s[i].isspace():
                return i
        return None

    def _potential_contexts(self, text):
        prev_slice = (0, 0)
        prev_match = None
        for m in _PERIOD_CONTEXT.finditer(text):
            before = text[prev_slice[1]:m.start()]
            idx = self._last_ws_index(before)
            if idx:
                idx += prev_slice[1] + 1
            else:
                idx = prev_slice[0]
            cur = (idx, m.start())
            if prev_match is not None and prev_slice[1] <= cur[0]:
                yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")
            prev_match = m
            prev_slice = cur
        if prev_match is not None:
            yield prev_match, text[prev_slice[0]:prev_slice[1]] + prev_match.group() + prev_match.group("after_tok")

    def _slices(self, text):
        last = 0
        out = []
        for m, ctx in self._potential_contexts(text):
            if self._contains_sentbreak(ctx):
                out.append((last, m.end()))
                last = m.start("next_tok") if m.group("next_tok") else m.end()
        out.append((last, len(text.rstrip())))
        return out

    def span_tokenize(self, text):
        slices = self._slices(text)
        realign = 0
        n = len(slices)
        res = []
        for i, s1 in enumerate(slices):
            s1 = (s1[0] + realign, s1[1])
            if i + 1 >= n:
                if text[s1[0]:s1[1]]:
                    res.append(s1)
                continue
            s2 = slices[i + 1]
            m = _REALIGN.match(text[s2[0]:s2[1]])
            if m:
                res.append((s1[0], s2[0] + len(m.group(0).rstrip())))
                realign = m.end()
            else:
                realign = 0
                if text[s1[0]:s1[1]]:
                    res.append(s1)
        return res

    def tokenize(self, text):
        return [text[a:b] for a, b in self.span_tokenize(text)]
