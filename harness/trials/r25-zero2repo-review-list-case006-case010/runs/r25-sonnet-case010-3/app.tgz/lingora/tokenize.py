"""Tokenizers."""
import html
import re

__all__ = [
    "RegexpTokenizer", "TreebankWordTokenizer", "NLTKWordTokenizer", "TweetTokenizer",
    "WhitespaceTokenizer", "WordPunctTokenizer", "BlanklineTokenizer",
    "blankline_tokenize", "sent_tokenize", "word_tokenize", "wordpunct_tokenize",
]


class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=True, flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        self._pattern = pattern
        self._gaps = gaps
        self._discard_empty = discard_empty
        self._flags = flags
        self._regexp = re.compile(pattern, flags)

    def tokenize(self, text):
        if self._gaps:
            toks = self._regexp.split(text)
            if self._discard_empty:
                return [t for t in toks if t]
            return toks
        toks = [m.group(0) for m in self._regexp.finditer(text)]
        if self._discard_empty:
            toks = [t for t in toks if t]
        return toks

    def span_tokenize(self, text):
        if self._gaps:
            prev = 0
            spans = []
            for m in self._regexp.finditer(text):
                spans.append((prev, m.start()))
                prev = m.end()
            spans.append((prev, len(text)))
            for s in spans:
                if self._discard_empty and s[0] == s[1]:
                    continue
                yield s
        else:
            for m in self._regexp.finditer(text):
                if self._discard_empty and m.start() == m.end():
                    continue
                yield m.span()

    def __repr__(self):
        return "RegexpTokenizer(pattern=%r, gaps=%r, discard_empty=%r)" % (
            self._pattern, self._gaps, self._discard_empty)


class WhitespaceTokenizer(RegexpTokenizer):
    def __init__(self):
        super().__init__(r"\s+", gaps=True)


class WordPunctTokenizer(RegexpTokenizer):
    def __init__(self):
        super().__init__(r"\w+|[^\w\s]+")


class BlanklineTokenizer(RegexpTokenizer):
    def __init__(self):
        super().__init__(r"\s*\n\s*\n\s*", gaps=True)

    def tokenize(self, text):
        return [t for t in super().tokenize(text) if t.strip()]


_wp = WordPunctTokenizer()


def wordpunct_tokenize(text):
    return _wp.tokenize(text)


def blankline_tokenize(text):
    return BlanklineTokenizer().tokenize(text)


class TreebankWordTokenizer:
    STARTING_QUOTES = [
        (re.compile(r"^\""), r"``"),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.\.\."), r" ... "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r'([^\.])(\.)([\]\)}>"\']*)\s*$'), r"\1 \2\3 "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
    ]
    PARENS_BRACKETS = (re.compile(r"[\]\[\(\)\{\}\<\>]"), r" \g<0> ")
    DOUBLE_DASHES = (re.compile(r"--"), r" -- ")
    ENDING_QUOTES = [
        (re.compile(r'"'), " '' "),
        (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = [
        re.compile(r"(?i)\b(can)(?#X)(not)\b"),
        re.compile(r"(?i)\b(d)(?#X)('ye)\b"),
        re.compile(r"(?i)\b(gim)(?#X)(me)\b"),
        re.compile(r"(?i)\b(gon)(?#X)(na)\b"),
        re.compile(r"(?i)\b(got)(?#X)(ta)\b"),
        re.compile(r"(?i)\b(lem)(?#X)(me)\b"),
        re.compile(r"(?i)\b(more)(?#X)('n)\b"),
        re.compile(r"(?i)\b(wan)(?#X)(na)(?=\s)"),
    ]
    CONTRACTIONS3 = [
        re.compile(r"(?i) ('t)(?#X)(is)\b"),
        re.compile(r"(?i) ('t)(?#X)(was)\b"),
    ]

    def tokenize(self, text):
        for r, s in self.STARTING_QUOTES:
            text = r.sub(s, text)
        for r, s in self.PUNCTUATION:
            text = r.sub(s, text)
        text = self.PARENS_BRACKETS[0].sub(self.PARENS_BRACKETS[1], text)
        text = self.DOUBLE_DASHES[0].sub(self.DOUBLE_DASHES[1], text)
        text = " " + text + " "
        for r, s in self.ENDING_QUOTES:
            text = r.sub(s, text)
        for r in self.CONTRACTIONS2:
            text = r.sub(r" \1 \2 ", text)
        for r in self.CONTRACTIONS3:
            text = r.sub(r" \1 \2 ", text)
        return text.split()

    def span_tokenize(self, text):
        pos = 0
        for tok in self.tokenize(text):
            i = text.find(tok, pos)
            if i < 0:  # quote conversions: locate the original quote
                m = re.compile(r"\"|``|''").search(text, pos)
                i = m.start() if m else pos
                yield (i, i + 1 if text[i:i + 1] == '"' else i + len(tok))
                pos = i + (1 if text[i:i + 1] == '"' else len(tok))
            else:
                yield (i, i + len(tok))
                pos = i + len(tok)


class NLTKWordTokenizer(TreebankWordTokenizer):
    """The recommended word tokenizer: improved Penn Treebank tokenizer."""

    STARTING_QUOTES = [
        (re.compile(r"([«“‘„]|[`]+)"), r" \1 "),
        (re.compile(r"(``)"), r" \1 "),
        (re.compile(r"([ \(\[{<])(\"|\'{2})"), r"\1 `` "),
    ]
    PUNCTUATION = [
        (re.compile(r"([^\.])(\.)([\]\)}>\"\'»”’ ]*)\s*$"), r"\1 \2 \3 "),
        (re.compile(r"([:,])([^\d])"), r" \1 \2"),
        (re.compile(r"([:,])$"), r" \1 "),
        (re.compile(r"\.{2,}"), r" \g<0> "),
        (re.compile(r"[;@#$%&]"), r" \g<0> "),
        (re.compile(r"[?!]"), r" \g<0> "),
        (re.compile(r"([^'])' "), r"\1 ' "),
        (re.compile(r"[*]"), r" \g<0> "),
        (re.compile("[‒-―]"), r" \g<0> "),
    ]
    ENDING_QUOTES = [
        (re.compile(r"([»”’])"), r" \1 "),
        (re.compile(r"''"), " '' "),
        (re.compile(r'"'), " '' "),
        (re.compile(r"(\S)(\'\')"), r"\1 \2 "),
        (re.compile(r"([^' ])('[sS]|'[mM]|'[dD]|') "), r"\1 \2 "),
        (re.compile(r"([^' ])('ll|'LL|'re|'RE|'ve|'VE|n't|N'T) "), r"\1 \2 "),
    ]
    CONTRACTIONS2 = TreebankWordTokenizer.CONTRACTIONS2[1:]
    CONTRACTIONS3 = TreebankWordTokenizer.CONTRACTIONS3


_nltk_wt = NLTKWordTokenizer()


def sent_tokenize(text, language="english"):
    from .punkt import PunktSentenceTokenizer
    return PunktSentenceTokenizer.for_language(language).tokenize(text)


def word_tokenize(text, language="english", preserve_line=False):
    sentences = [text] if preserve_line else sent_tokenize(text, language)
    out = []
    for s in sentences:
        out.extend(_nltk_wt.tokenize(s))
    return out


# ---------------------------------------------------------------- tweets
_EMOTICONS = r"""(?:[<>]?[:;=8][\-o\*\']?[\)\]\(\[dDpP/\:\}\{@\|\\]|[\)\]\(\[dDpP/\:\}\{@\|\\][\-o\*\']?[:;=8][<>]?|<3)"""
_URLS = r"""(?:https?://|www\.)[^\s]*[^\s.,;:!?)\]'"]"""
_PHONE = r"""(?:(?:\+?[01][\-\s.]*)?(?:[\(]?\d{3}[\-\s.\)]*)?\d{3}[\-\s.]*\d{4})"""
_TWEET_RES = [
    _URLS,
    _PHONE,
    _EMOTICONS,
    r"""<[^>\s]+>""",
    r"""[\-]+>|<[\-]+""",
    r"""(?:@[\w_]+)""",
    r"""(?:\#+[\w_]+[\w\'_\-]*[\w_]+)""",
    r"""[\w.+-]+@[\w-]+\.(?:[\w-]\.?)+[\w-]""",
    r"""(?:[^\W\d_](?:[^\W\d_]|['\-_])+[^\W\d_])""",
    r"""(?:[+\-]?\d+[,/.:-]\d+[+\-]?)""",
    r"""(?:[\w_]+)""",
    r"""(?:\.(?:\s*\.){1,})""",
    r"""(?:\S)""",
]
_TWEET_WORD = re.compile("(" + "|".join(_TWEET_RES) + ")", re.I | re.UNICODE)
_TWEET_EMO = re.compile("^" + _EMOTICONS + "$", re.UNICODE)
_HANDLE = re.compile(r"(?<![A-Za-z0-9_])@(?:[A-Za-z0-9_]{15}(?!@)|[A-Za-z0-9_]{1,14}(?![A-Za-z0-9_]*@))")
_REDUCE = re.compile(r"(.)\1{2,}", re.DOTALL)


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self.preserve_case = preserve_case
        self.reduce_len = reduce_len
        self.strip_handles = strip_handles

    def tokenize(self, text):
        text = html.unescape(text)
        if self.strip_handles:
            text = _HANDLE.sub(" ", text)
        if self.reduce_len:
            text = _REDUCE.sub(r"\1\1\1", text)
        # _TWEET_WORD uses re.VERBOSE: whitespace-free patterns only, so safe
        words = _TWEET_WORD.findall(text)
        words = [w[0] if isinstance(w, tuple) else w for w in words]
        if not self.preserve_case:
            words = [w if _TWEET_EMO.match(w) else w.lower() for w in words]
        return words
