"""Context-free grammars."""
import re

__all__ = ["Nonterminal", "Production", "CFG"]


class Nonterminal:
    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __eq__(self, other):
        if isinstance(other, Nonterminal):
            return self._symbol == other._symbol
        return False

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash(("nt", self._symbol))

    def __str__(self):
        return str(self._symbol)

    def __repr__(self):
        return "%s" % (self._symbol,)

    def __lt__(self, other):
        return str(self) < str(other)


class Production:
    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __len__(self):
        return len(self._rhs)

    def is_nonlexical(self):
        return all(isinstance(s, Nonterminal) for s in self._rhs)

    def is_lexical(self):
        return not self.is_nonlexical()

    def __eq__(self, other):
        return isinstance(other, Production) and self._lhs == other._lhs and self._rhs == other._rhs

    def __ne__(self, other):
        return not self == other

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __str__(self):
        parts = [repr(s) if isinstance(s, str) else str(s) for s in self._rhs]
        return "%s -> %s" % (self._lhs, " ".join(parts))

    def __repr__(self):
        return str(self)


_RHS_TOKEN = re.compile(r"\"[^\"]*\"|'[^']*'|\||[^\s|]+")


class CFG:
    def __init__(self, start, productions):
        self._start = start
        self._productions = list(productions)
        self._terminals = set()
        for p in self._productions:
            for s in p.rhs():
                if isinstance(s, str):
                    self._terminals.add(s)

    def start(self):
        return self._start

    def productions(self, lhs=None, rhs=None):
        ps = self._productions
        if lhs is not None:
            if isinstance(lhs, str):
                lhs = Nonterminal(lhs)
            ps = [p for p in ps if p.lhs() == lhs]
        if rhs is not None:
            ps = [p for p in ps if rhs in p.rhs()]
        return list(ps)

    def terminals(self):
        return set(self._terminals)

    def covers(self, token):
        return token in self._terminals

    def check_coverage(self, tokens):
        missing = [t for t in tokens if t not in self._terminals]
        if missing:
            raise ValueError("Grammar does not cover some of the input words: %r."
                             % ", ".join(repr(t) for t in missing))

    @classmethod
    def fromstring(cls, input, encoding=None):
        if isinstance(input, bytes):
            input = input.decode(encoding or "utf-8")
        lines = []
        for raw in input.splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("|") and lines:
                lines[-1] += " " + line
            else:
                lines.append(line)
        prods = []
        for line in lines:
            m = re.match(r"^(\S+?)\s*(?:->|→)\s*(.*)$", line)
            if not m:
                raise ValueError("Unable to parse production: %r" % line)
            lhs = Nonterminal(m.group(1))
            rhs_text = m.group(2)
            alt = []
            alts = []
            for tok in _RHS_TOKEN.findall(rhs_text):
                if tok == "|":
                    alts.append(alt)
                    alt = []
                elif len(tok) >= 2 and tok[0] in "'\"" and tok[-1] == tok[0]:
                    alt.append(tok[1:-1])
                else:
                    alt.append(Nonterminal(tok))
            alts.append(alt)
            for a in alts:
                prods.append(Production(lhs, a))
        if not prods:
            raise ValueError("No productions found")
        return cls(prods[0].lhs(), prods)

    def __str__(self):
        return "Grammar with %d productions (start state = %s)\n" % (
            len(self._productions), self._start) + "\n".join("    " + str(p) for p in self._productions)

    __repr__ = __str__
