"""Stemmers."""
import os
import re

from . import data

__all__ = [
    "PorterStemmer", "LancasterStemmer", "SnowballStemmer", "RegexpStemmer",
    "ARLSTem", "ARLSTem2", "ISRIStemmer", "Cistem", "RSLPStemmer", "WordNetLemmatizer",
]


class StemmerI:
    def stem(self, token):
        raise NotImplementedError


# ------------------------------------------------------------------ Porter
class PorterStemmer(StemmerI):
    ORIGINAL_ALGORITHM = "ORIGINAL_ALGORITHM"
    MARTIN_EXTENSIONS = "MARTIN_EXTENSIONS"
    NLTK_EXTENSIONS = "NLTK_EXTENSIONS"
    LINGORA_EXTENSIONS = NLTK_EXTENSIONS

    def __init__(self, mode=NLTK_EXTENSIONS):
        if mode not in (self.ORIGINAL_ALGORITHM, self.MARTIN_EXTENSIONS, self.NLTK_EXTENSIONS):
            raise ValueError("Mode must be one of ORIGINAL_ALGORITHM, MARTIN_EXTENSIONS, NLTK_EXTENSIONS")
        self.mode = mode
        self.pool = {}
        if mode == self.NLTK_EXTENSIONS:
            irregular = {
                "sky": ["sky", "skies"], "die": ["dying"], "lie": ["lying"], "tie": ["tying"],
                "news": ["news"], "inning": ["innings", "inning"], "outing": ["outings", "outing"],
                "canning": ["cannings", "canning"], "howe": ["howe"], "proceed": ["proceed"],
                "exceed": ["exceed"], "succeed": ["succeed"],
            }
            for stem, words in irregular.items():
                for w in words:
                    self.pool[w] = stem

    vowels = frozenset("aeiou")

    def _is_consonant(self, word, i):
        if word[i] in self.vowels:
            return False
        if word[i] == "y":
            if i == 0:
                return True
            return not self._is_consonant(word, i - 1)
        return True

    def _measure(self, stem):
        cv = "".join("c" if self._is_consonant(stem, i) else "v" for i in range(len(stem)))
        return cv.count("vc")

    def _has_positive_measure(self, stem):
        return self._measure(stem) > 0

    def _contains_vowel(self, stem):
        return any(not self._is_consonant(stem, i) for i in range(len(stem)))

    def _ends_double_consonant(self, word):
        return len(word) >= 2 and word[-1] == word[-2] and self._is_consonant(word, len(word) - 1)

    def _ends_cvc(self, word):
        return (
            len(word) >= 3
            and self._is_consonant(word, len(word) - 3)
            and not self._is_consonant(word, len(word) - 2)
            and self._is_consonant(word, len(word) - 1)
            and word[-1] not in ("w", "x", "y")
        ) or (
            self.mode == self.NLTK_EXTENSIONS
            and len(word) == 2
            and not self._is_consonant(word, 0)
            and self._is_consonant(word, 1)
        )

    @staticmethod
    def _replace_suffix(word, suffix, replacement):
        assert word.endswith(suffix)
        if suffix == "":
            return word + replacement
        return word[: -len(suffix)] + replacement

    def _apply_rule_list(self, word, rules):
        for suffix, replacement, condition in rules:
            if suffix == "*d" and self._ends_double_consonant(word):
                stem = word[:-2]
                if condition is None or condition(stem):
                    return stem + replacement
                return word
            if word.endswith(suffix):
                stem = self._replace_suffix(word, suffix, "")
                if condition is None or condition(stem):
                    return stem + replacement
                return word
        return word

    def _step1a(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("ies") and len(word) == 4:
                return self._replace_suffix(word, "ies", "ie")
        return self._apply_rule_list(
            word, [("sses", "ss", None), ("ies", "i", None), ("ss", "ss", None), ("s", "", None)])

    def _step1b(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("ied"):
                if len(word) == 4:
                    return self._replace_suffix(word, "ied", "ie")
                return self._replace_suffix(word, "ied", "i")
        if word.endswith("eed"):
            stem = self._replace_suffix(word, "eed", "")
            if self._measure(stem) > 0:
                return stem + "ee"
            return word
        inter = None
        for suffix in ("ed", "ing"):
            if word.endswith(suffix):
                cand = self._replace_suffix(word, suffix, "")
                if self._contains_vowel(cand):
                    inter = cand
                    break
        if inter is None:
            return word
        last = inter[-1:]
        return self._apply_rule_list(
            inter,
            [
                ("at", "ate", None), ("bl", "ble", None), ("iz", "ize", None),
                ("*d", last, lambda stem: last not in ("l", "s", "z")),
                ("", "e", lambda stem: self._measure(stem) == 1 and self._ends_cvc(stem)),
            ],
        )

    def _step1c(self, word):
        if self.mode == self.NLTK_EXTENSIONS:
            cond = lambda stem: len(stem) > 1 and self._is_consonant(stem, len(stem) - 1)
        else:
            cond = self._contains_vowel
        return self._apply_rule_list(word, [("y", "i", cond)])

    def _step2(self, word):
        pos = self._has_positive_measure
        if self.mode == self.NLTK_EXTENSIONS:
            if word.endswith("alli") and pos(self._replace_suffix(word, "alli", "")):
                return self._step2(self._replace_suffix(word, "alli", "al"))
        bli = ("bli", "ble", pos) if self.mode != self.ORIGINAL_ALGORITHM else ("abli", "able", pos)
        rules = [
            ("ational", "ate", pos), ("tional", "tion", pos), ("enci", "ence", pos),
            ("anci", "ance", pos), ("izer", "ize", pos), bli, ("alli", "al", pos),
            ("entli", "ent", pos), ("eli", "e", pos), ("ousli", "ous", pos),
            ("ization", "ize", pos), ("ation", "ate", pos), ("ator", "ate", pos),
            ("alism", "al", pos), ("iveness", "ive", pos), ("fulness", "ful", pos),
            ("ousness", "ous", pos), ("aliti", "al", pos), ("iviti", "ive", pos),
            ("biliti", "ble", pos),
        ]
        if self.mode == self.NLTK_EXTENSIONS:
            rules.append(("fulli", "ful", pos))
            rules.append(("logi", "log", lambda stem: self._measure(word[:-3]) > 0))
        elif self.mode == self.MARTIN_EXTENSIONS:
            rules.append(("logi", "log", pos))
        return self._apply_rule_list(word, rules)

    def _step3(self, word):
        pos = self._has_positive_measure
        return self._apply_rule_list(
            word,
            [("icate", "ic", pos), ("ative", "", pos), ("alize", "al", pos), ("iciti", "ic", pos),
             ("ical", "ic", pos), ("ful", "", pos), ("ness", "", pos)],
        )

    def _step4(self, word):
        m1 = lambda stem: self._measure(stem) > 1
        return self._apply_rule_list(
            word,
            [
                ("al", "", m1), ("ance", "", m1), ("ence", "", m1), ("er", "", m1), ("ic", "", m1),
                ("able", "", m1), ("ible", "", m1), ("ant", "", m1), ("ement", "", m1),
                ("ment", "", m1), ("ent", "", m1),
                ("ion", "", lambda stem: self._measure(stem) > 1 and stem[-1:] in ("s", "t")),
                ("ou", "", m1), ("ism", "", m1), ("ate", "", m1), ("iti", "", m1),
                ("ous", "", m1), ("ive", "", m1), ("ize", "", m1),
            ],
        )

    def _step5a(self, word):
        if word.endswith("e"):
            stem = self._replace_suffix(word, "e", "")
            if self._measure(stem) > 1:
                return stem
            if self._measure(stem) == 1 and not self._ends_cvc(stem):
                return stem
        return word

    def _step5b(self, word):
        return self._apply_rule_list(word, [("ll", "l", lambda stem: self._measure(word[:-1]) > 1)])

    def stem(self, word, to_lowercase=True):
        stem = word.lower() if to_lowercase else word
        if self.mode == self.NLTK_EXTENSIONS and stem.lower() in self.pool:
            return self.pool[stem.lower()]
        if self.mode != self.ORIGINAL_ALGORITHM and len(word) <= 2:
            return stem
        stem = self._step1a(stem)
        stem = self._step1b(stem)
        stem = self._step1c(stem)
        stem = self._step2(stem)
        stem = self._step3(stem)
        stem = self._step4(stem)
        stem = self._step5a(stem)
        stem = self._step5b(stem)
        return stem


# --------------------------------------------------------------- Lancaster
_LANCASTER_RULES = """
ai*2. a*1. bb1. city3s. ci2> cn1t> dd1. dei3y> deec2ss. dee1. de2> dooh4> e1> feil1v. fi2> gni3> gai3y. ga2>
gg1. ht*2. hsiug5ct. hsi3> i*1. i1y> ji1d. juf1s. ju1d. jo1d. jeh1r. jrev1t. jsim2t. jn1d. j1s. lbaifi6. lbai4y.
lba3> lbi3. lib2l> lc1. lufi4y. luf3> lu2. lai3> lau3> la2> ll1. mui3. mu*2. msi3> mm1. nois4j> noix4ct. noi3>
nai3> na2> nee0. ne2> nn1. pihs4> pp1. re2> rae0. ra2. ro2> ru2> rr1. rt1> rei3y> sei3y> sis2. si2> ssen4>
ss0. suo3> su*2. s*1> s0. tacilp4y. ta2> tnem4> tne3> tna3> tpir2b. tpro2b. tcud1. tpmus2. tpec2iv. tulo2v.
tsis0. tsi3> tt1. uqi3. ugo1. vis3j> vie0. vi2> ylb1> yli3y> ylp0. yl2> ygo1. yhp1. ymo1. ypo1. yti3> yte3>
ytl2. yrtsi5. yra3> yro3> yfi3. ycn2t> yca3> zi2> zy1s.
""".split()


class LancasterStemmer(StemmerI):
    _valid = re.compile(r"^([a-z]+)(\*?)(\d)([a-z]*)([>\.]?)$")

    def __init__(self, rule_tuple=None, strip_prefix_flag=False):
        self.rule_dictionary = {}
        self._strip_prefix = strip_prefix_flag
        for rule in rule_tuple or _LANCASTER_RULES:
            self.rule_dictionary.setdefault(rule[0], []).append(rule)

    @staticmethod
    def _last_letter(word):
        last = -1
        for i, c in enumerate(word):
            if c.isalpha():
                last = i
            else:
                break
        return last

    @staticmethod
    def _acceptable(word, remove_total):
        if word[0] in "aeiouy":
            return len(word) - remove_total >= 2
        if len(word) - remove_total >= 3:
            return word[1] in "aeiouy" or word[2] in "aeiouy"
        return False

    def stem(self, word):
        word = word.lower()
        if self._strip_prefix:
            for p in ("kilo", "micro", "milli", "intra", "ultra", "mega", "nano", "pico", "pseudo"):
                if word.startswith(p):
                    word = word[len(p):]
                    break
        intact = word
        while True:
            pos = self._last_letter(word)
            if pos < 0 or word[pos] not in self.rule_dictionary:
                break
            applied = False
            stop = False
            for rule in self.rule_dictionary[word[pos]]:
                m = self._valid.match(rule)
                if not m:
                    continue
                ending, intact_flag, remove, append, cont = m.groups()
                remove = int(remove)
                if word.endswith(ending[::-1]):
                    if intact_flag:
                        if word == intact and self._acceptable(word, remove):
                            word = word[: len(word) - remove] + append
                            applied = True
                            stop = cont == "."
                            break
                    elif self._acceptable(word, remove):
                        word = word[: len(word) - remove] + append
                        applied = True
                        stop = cont == "."
                        break
            if not applied or stop:
                break
        return word


# ---------------------------------------------------------------- Snowball
SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian",
    "italian", "norwegian", "porter", "portuguese", "romanian", "russian", "spanish", "swedish",
)

_EN_VOWELS = "aeiouy"
_EN_DOUBLES = ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt")
_EN_LI = "cdeghkmnrt"
_EN_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie", "idly": "idl",
    "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli", "singly": "singl",
    "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas", "cosmos": "cosmos",
    "bias": "bias", "andes": "andes",
}
_EN_EXC2 = {"inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed"}
_EN_STEP2 = [
    ("tional", "tion"), ("enci", "ence"), ("anci", "ance"), ("abli", "able"), ("entli", "ent"),
    ("izer", "ize"), ("ization", "ize"), ("ational", "ate"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("aliti", "al"), ("alli", "al"), ("fulness", "ful"), ("ousli", "ous"),
    ("ousness", "ous"), ("iveness", "ive"), ("iviti", "ive"), ("biliti", "ble"), ("bli", "ble"),
    ("ogi", "og"), ("fulli", "ful"), ("lessli", "less"), ("li", ""),
]
_EN_STEP3 = [
    ("tional", "tion"), ("ational", "ate"), ("alize", "al"), ("icate", "ic"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""), ("ative", ""),
]
_EN_STEP4 = ["al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment", "ent",
             "ism", "ate", "iti", "ous", "ive", "ize", "ion"]


class _EnglishStemmer:
    def _regions(self, w):
        n = len(w)
        r1 = n
        for pref in ("gener", "commun", "arsen"):
            if w.startswith(pref):
                r1 = len(pref)
                break
        else:
            for i in range(1, n):
                if w[i] not in _EN_VOWELS and w[i - 1] in _EN_VOWELS:
                    r1 = i + 1
                    break
        r2 = n
        for i in range(r1 + 1, n):
            if w[i] not in _EN_VOWELS and w[i - 1] in _EN_VOWELS:
                r2 = i + 1
                break
        return r1, r2

    @staticmethod
    def _short_syllable_end(w):
        n = len(w)
        if n == 2:
            return w[0] in _EN_VOWELS and w[1] not in _EN_VOWELS
        if n >= 3:
            return (w[-2] in _EN_VOWELS and w[-1] not in _EN_VOWELS and w[-1] not in "wxY"
                    and w[-3] not in _EN_VOWELS)
        return False

    def _is_short(self, w, r1):
        return r1 >= len(w) and self._short_syllable_end(w)

    def stem(self, word):
        w = word.lower()
        if len(w) <= 2:
            return w
        if w.startswith("'"):
            w = w[1:]
        if w in _EN_EXC1:
            return _EN_EXC1[w]
        if len(w) <= 2:
            return w
        chars = list(w)
        if chars[0] == "y":
            chars[0] = "Y"
        for i in range(1, len(chars)):
            if chars[i] == "y" and chars[i - 1] in _EN_VOWELS:
                chars[i] = "Y"
        w = "".join(chars)
        r1, r2 = self._regions(w)
        # step 0
        for suf in ("'s'", "'s", "'"):
            if w.endswith(suf):
                w = w[: -len(suf)]
                break
        # step 1a
        if w.endswith("sses"):
            w = w[:-2]
        elif w.endswith("ied") or w.endswith("ies"):
            w = w[:-3] + ("i" if len(w) > 4 else "ie")
        elif w.endswith("us") or w.endswith("ss"):
            pass
        elif w.endswith("s"):
            if any(c in _EN_VOWELS for c in w[:-2]):
                w = w[:-1]
        if w in _EN_EXC2:
            return w.replace("Y", "y")
        # step 1b
        done = False
        for suf in ("eedly", "ingly", "edly", "eed", "ing", "ed"):
            if w.endswith(suf):
                if suf in ("eed", "eedly"):
                    if len(w) - len(suf) >= r1:
                        w = w[: -len(suf)] + "ee"
                else:
                    pre = w[: -len(suf)]
                    if any(c in _EN_VOWELS for c in pre):
                        w = pre
                        if w.endswith(("at", "bl", "iz")):
                            w += "e"
                        elif w.endswith(_EN_DOUBLES):
                            w = w[:-1]
                        elif self._is_short(w, r1):
                            w += "e"
                done = True
                break
        # step 1c
        if len(w) > 2 and w[-1] in "yY" and w[-2] not in _EN_VOWELS:
            w = w[:-1] + "i"
        # step 2
        best = None
        for suf, rep in _EN_STEP2:
            if w.endswith(suf) and (best is None or len(suf) > len(best[0])):
                best = (suf, rep)
        if best:
            suf, rep = best
            if len(w) - len(suf) >= r1:
                if suf == "ogi":
                    if w[-4:-3] == "l":
                        w = w[:-3] + "og"
                elif suf == "li":
                    if len(w) > 2 and w[-3] in _EN_LI:
                        w = w[:-2]
                else:
                    w = w[: -len(suf)] + rep
        # step 3
        best = None
        for suf, rep in _EN_STEP3:
            if w.endswith(suf) and (best is None or len(suf) > len(best[0])):
                best = (suf, rep)
        if best:
            suf, rep = best
            if len(w) - len(suf) >= r1:
                if suf == "ative":
                    if len(w) - len(suf) >= r2:
                        w = w[:-5]
                else:
                    w = w[: -len(suf)] + rep
        # step 4
        best = None
        for suf in _EN_STEP4:
            if w.endswith(suf) and (best is None or len(suf) > len(best)):
                best = suf
        if best and len(w) - len(best) >= r2:
            if best == "ion":
                if w[-4:-3] in ("s", "t") and w[-4:-3]:
                    w = w[:-3]
            else:
                w = w[: -len(best)]
        # step 5
        if w.endswith("e"):
            if len(w) - 1 >= r2 or (len(w) - 1 >= r1 and not self._short_syllable_end(w[:-1])):
                w = w[:-1]
        elif w.endswith("ll") and len(w) - 1 >= r2:
            w = w[:-1]
        return w.replace("Y", "y")


class _SnowballPorter:
    def __init__(self):
        self._p = PorterStemmer(PorterStemmer.ORIGINAL_ALGORITHM)

    def stem(self, word):
        return self._p.stem(word.lower())


class SnowballStemmer(StemmerI):
    languages = SNOWBALL_LANGUAGES

    def __init__(self, language, ignore_stopwords=False):
        if language not in self.languages:
            raise ValueError("The language '%s' is not supported." % (language,))
        self.language = language
        self.stopwords = set()
        if ignore_stopwords:
            fp = data.find("corpora/stopwords/%s" % language)
            self.stopwords = set(w.strip() for w in data.read_lines(fp) if w.strip())
        if language == "english":
            self.stemmer = _EnglishStemmer()
        elif language == "porter":
            self.stemmer = _SnowballPorter()
        else:
            self.stemmer = None

    def stem(self, word):
        word = word.lower()
        if word in self.stopwords:
            return word
        if self.stemmer is None:
            raise NotImplementedError(
                "Snowball stemming for %r is not implemented in this build" % self.language)
        return self.stemmer.stem(word)


class RegexpStemmer(StemmerI):
    def __init__(self, regexp, min=0):
        if not hasattr(regexp, "pattern"):
            regexp = re.compile(regexp)
        self._regexp = regexp
        self._min = min

    def stem(self, word):
        if len(word) < self._min:
            return word
        return self._regexp.sub("", word)


# ---------------------------------------------------- other (unspecified)
_AR_DIACRITICS = re.compile("[ً-ْـ]")


class ARLSTem(StemmerI):
    """Light Arabic stemmer (simplified)."""
    _prefixes = ("ال", "وال", "لل", "بال", "كال", "فال")
    _suffixes = ("ها", "ات", "ان", "ين", "ون", "ة", "ه", "ي")

    def stem(self, word):
        w = _AR_DIACRITICS.sub("", word)
        for p in self._prefixes:
            if w.startswith(p) and len(w) - len(p) >= 2:
                w = w[len(p):]
                break
        for s in self._suffixes:
            if w.endswith(s) and len(w) - len(s) >= 2:
                w = w[: -len(s)]
                break
        return w


class ARLSTem2(ARLSTem):
    pass


class ISRIStemmer(ARLSTem):
    pass


class Cistem(StemmerI):
    def stem(self, word):
        w = word.lower()
        for s in ("ern", "em", "er", "nd", "en", "es", "e", "s", "n", "t"):
            if w.endswith(s) and len(w) - len(s) >= 3:
                return w[: -len(s)]
        return w


class RSLPStemmer(StemmerI):
    def __init__(self):
        data.find("stemmers/rslp")

    def stem(self, word):
        return word.lower()


class WordNetLemmatizer:
    def __init__(self):
        self._root = data.find("corpora/wordnet")

    def lemmatize(self, word, pos="n"):
        self._root = data.find("corpora/wordnet")
        # Minimal lemmatizer: returns the word when no exception/morphology data is available.
        return word
