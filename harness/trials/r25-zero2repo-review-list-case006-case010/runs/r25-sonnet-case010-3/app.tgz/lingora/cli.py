"""Command-line group (click-compatible ``main`` entry, no dependency)."""
import sys

__all__ = ["cli"]


class UsageError(Exception):
    pass


class _Group:
    def __init__(self, name="lingora"):
        self.name = name
        self.commands = {}

    def command(self, name):
        def deco(fn):
            self.commands[name] = fn
            return fn
        return deco

    def main(self, args=None, standalone_mode=True, **kwargs):
        args = list(sys.argv[1:] if args is None else args)
        try:
            if not args or args[0] not in self.commands:
                raise UsageError("usage: %s tokenize [options]" % self.name)
            rv = self.commands[args[0]](args[1:])
            code = 0
        except SystemExit as e:
            code = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
            rv = None
        except UsageError as e:
            sys.stderr.write("Error: %s\n" % e)
            code = 2
            rv = None
        except Exception as e:
            sys.stderr.write("Error: %s\n" % e)
            code = 1
            rv = None
        if standalone_mode:
            sys.stdout.flush()
            sys.exit(code)
        if code != 0:
            raise SystemExit(code)
        return rv

    __call__ = main


cli = _Group()


@cli.command("tokenize")
def _tokenize(argv):
    language = "english"
    delimiter = " "
    encoding = "utf-8"
    preserve_line = False
    i = 0
    while i < len(argv):
        a = argv[i]
        if a in ("-l", "--language") and i + 1 < len(argv):
            language = argv[i + 1]; i += 2
        elif a in ("-d", "--delimiter") and i + 1 < len(argv):
            delimiter = argv[i + 1]; i += 2
        elif a in ("-e", "--encoding") and i + 1 < len(argv):
            encoding = argv[i + 1]; i += 2
        elif a in ("-p", "--preserve-line"):
            preserve_line = True; i += 1
        else:
            raise UsageError("unknown option %r" % a)
    from .tokenize import word_tokenize
    from .punkt import load_params
    if not preserve_line:
        load_params(language)  # fail before writing anything
    raw = sys.stdin.buffer.read().decode(encoding)
    out = []
    for line in raw.splitlines():
        toks = word_tokenize(line, language=language, preserve_line=preserve_line)
        out.append(delimiter.join(toks) + "\n")
    sys.stdout.write("".join(out))


if __name__ == "__main__":
    cli.main()
