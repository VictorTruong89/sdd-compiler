"""Exception classes and their exit-status classes. # spec: FP-13, N-000788..N-000796, N-000920..N-000922"""

import sys


class OptlynError(Exception):
    """Base for Optlyn-signalled errors that are not usage errors. Exit status 1. # spec: FP-13"""

    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def show(self, file=None):
        from .termui import echo

        echo(f"Error: {self.format_message()}", file=file or sys.stderr, err=True)


class UsageError(OptlynError):
    """Incorrect usage. Exit status 2. # spec: FP-13"""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self, file=None):
        from .termui import echo

        err = file or sys.stderr
        if self.ctx is not None:
            echo(self.ctx.get_usage(), file=err, err=True)
            hint = self.ctx.help_option_names[0] if self.ctx.help_option_names else "--help"
            echo(f"Try '{self.ctx.command_path} {hint}' for help.", file=err, err=True)
            echo("", file=err, err=True)
        echo(f"Error: {self.format_message()}", file=err, err=True)


class BadParameter(UsageError):
    """A value was refused. Raised from callbacks, types and conversion functions. # spec: N-000920..N-000922"""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx=ctx)
        self.param = param
        self.param_hint = param_hint

    def _param_label(self):
        if self.param_hint:
            return self.param_hint
        if self.param is None:
            return None
        return self.param.label()

    def format_message(self):
        label = self._param_label()
        if label:
            return f"Invalid value for {label}: {self.message}"
        return f"Invalid value: {self.message}"


class MissingParameter(BadParameter):
    """A required parameter was not supplied. # spec: FP-03, FP-04"""

    def format_message(self):
        label = self._param_label()
        return f"Missing {self.param.kind_word() if self.param else 'parameter'} {label}."


class NoSuchOption(UsageError):
    """An unknown option. # spec: FP-03"""

    def __init__(self, option_name, message=None, ctx=None):
        super().__init__(message or f"No such option: {option_name}", ctx=ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """A usage problem with an option, such as a missing value. # spec: FP-03"""


class NoArgsIsHelp(UsageError):
    """Help shown because no arguments were given. Usage class (exit 2). # spec: FP-02"""

    def __init__(self, ctx):
        super().__init__("", ctx=ctx)

    def show(self, file=None):
        from .termui import echo

        echo(self.ctx.get_help(), file=file or sys.stderr, err=True)


class MissingCommand(UsageError):
    """A group was invoked without a subcommand name. # spec: FP-06"""

    def __init__(self, ctx):
        super().__init__("Missing command.", ctx=ctx)


class NoSuchCommand(UsageError):
    """An unknown subcommand name. # spec: FP-06"""

    def __init__(self, name, ctx=None):
        super().__init__(f"No such command {name!r}.", ctx=ctx)
        self.name = name


class FileError(OptlynError):
    """A file could not be opened at first I/O. General error class (exit 1). # spec: FP-09"""

    def __init__(self, filename, detail=""):
        super().__init__(f"Could not open file {filename!r}: {detail}".rstrip(": "))
        self.filename = filename


class Abort(RuntimeError):
    """Abort the program. Abort class (exit 1). # spec: FP-13"""

    exit_code = 1


class Exit(RuntimeError):
    """Author clean stop with a status. # spec: FP-13"""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code
