"""Shell completion. # spec: FP-12, N-000983..N-001005"""

import os
import sys

from .context import Context
from .parameters import Argument, Option
from .termui import echo

SHELLS = ("bash", "zsh", "fish", "powershell")
PATH_DIR = "__optlyn_path_dir__"
PATH_FILE = "__optlyn_path_file__"


def complete_var_name(prog_name):
    """Environment variable that selects completion mode. # spec: N-000983, N-000984"""
    return "_" + prog_name.replace("-", "_").replace(".", "_").upper() + "_COMPLETE"


def _source_script(shell, prog_name, var):
    name = prog_name
    func = "_" + name.replace("-", "_").replace(".", "_") + "_completion"
    if shell == "bash":
        return (
            f"{func}() {{\n"
            f"    local IFS=$'\\n'\n"
            f"    COMPREPLY=( $( env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD {var}=bash_complete {name} ) )\n"
            f"    return 0\n"
            f"}}\n"
            f"complete -o default -F {func} {name}\n"
        )
    if shell == "zsh":
        return (
            f"#compdef {name}\n"
            f"{func}() {{\n"
            f"    local -a completions\n"
            f"    completions=( ${{(f)\"$( env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {name} )\"}} )\n"
            f"    _describe '{name}' completions\n"
            f"}}\n"
            f"compdef {func} {name}\n"
        )
    if shell == "fish":
        return (
            f"function {func}\n"
            f"    set -l tokens (commandline -opc) (commandline -ct)\n"
            f"    env COMP_WORDS=\"$tokens\" COMP_CWORD=(commandline -ct) {var}=fish_complete {name}\n"
            f"end\n"
            f"complete -c {name} -f -a '({func})'\n"
        )
    return (
        f"Register-ArgumentCompleter -Native -CommandName '{name}' -ScriptBlock {{\n"
        f"    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString()\n"
        f"    $env:COMP_CWORD = $wordToComplete\n"
        f"    $env:{var} = 'powershell_complete'\n"
        f"    & {name} | ForEach-Object {{ [System.Management.Automation.CompletionResult]::new($_, $_, 'ParameterValue', $_) }}\n"
        f"}}\n"
    )


def _words_and_index(shell):
    words = os.environ.get("COMP_WORDS", "").split(" ")
    raw_index = os.environ.get("COMP_CWORD", "")
    if shell == "fish":
        incomplete = raw_index
        return words[1:], incomplete
    try:
        index = int(raw_index)
    except ValueError:
        index = len(words) - 1
    incomplete = words[index] if 0 <= index < len(words) else ""
    return words[1:index] if index >= 1 else [], incomplete


def _visible_option_names(cmd, ctx):
    names = []
    for param in cmd.get_params(ctx):
        if isinstance(param, Option) and not param.hidden:
            names.extend(param.opts)
            names.extend(param.secondary_opts)
    return names


def _descend(cli, ctx, tokens):
    """Walk groups along already-typed tokens. Returns (command, its context). # spec: FP-12"""
    cmd = cli
    for tok in tokens:
        if not hasattr(cmd, "get_command") or tok.startswith("-"):
            continue
        child = cmd.get_command(ctx, tok)
        if child is not None and not child.hidden:
            cmd = child
            ctx = Context(child, info_name=tok, parent=ctx)
    return cmd, ctx


def _item(value, help_text=None, kind="plain"):
    return {"value": value, "help": help_text, "type": kind}


def _param_items(param, ctx, incomplete):
    """Completions for one parameter's value. # spec: FP-12, N-001000..N-001005"""
    func = getattr(param, "shell_complete_func", None)
    if func is not None:
        raw = func(ctx, param, incomplete)
    else:
        raw = param.type.shell_complete(ctx, param, incomplete)
    if raw is None:
        return []
    items = []
    for entry in raw:
        if isinstance(entry, str):
            items.append(_item(entry))
        else:
            items.append(_item(entry.value, getattr(entry, "help", None), getattr(entry, "type", "plain") or "plain"))
    return items


def _path_request(param, incomplete):
    """A request for shell path completion, carrying the incomplete token. # spec: FP-12"""
    dirs_only = getattr(param.type, "dir_okay", True) and not getattr(param.type, "file_okay", True)
    kind = PATH_DIR if dirs_only else PATH_FILE
    return [_item(incomplete, None, kind)]


def suggestions(cli, prog_name, args, incomplete, ctx_settings=None):
    """Compute suggestions for the current word. # spec: FP-12"""
    root_ctx = Context(cli, info_name=prog_name, **(ctx_settings or {}))
    path_tokens = []
    pending_param = None
    cmd = cli
    ctx = root_ctx
    for tok in args:
        if pending_param is not None:
            pending_param = None
            continue
        if tok.startswith("-"):
            for param in cmd.get_params(ctx):
                if isinstance(param, Option) and tok in param.opts and param.takes_value:
                    pending_param = param
                    break
            continue
        path_tokens.append(tok)
    cmd, ctx = _descend(cli, root_ctx, path_tokens)

    if pending_param is not None:
        return _param_items_or_paths(pending_param, ctx, incomplete)

    if incomplete.startswith("-"):
        items = []
        for name in _visible_option_names(cmd, ctx):
            if name.startswith(incomplete) and name not in ("",):
                items.append(_item(name))
        return items

    if hasattr(cmd, "list_commands") and getattr(cmd, "commands", None) is not None and hasattr(cmd, "get_command"):
        items = []
        for name in cmd.list_commands(ctx):
            child = cmd.get_command(ctx, name)
            if child is None or child.hidden or not name.startswith(incomplete):
                continue
            items.append(_item(name, child.get_short_help_str(45)))
        return items

    items = []
    for param in cmd.get_params(ctx):
        if isinstance(param, Argument) and not param.hidden:
            items.extend(_param_items_or_paths(param, ctx, incomplete))
            break
    return [i for i in items if i["value"].startswith(incomplete) or i["type"] != "plain"]


def _param_items_or_paths(param, ctx, incomplete):
    from .types import File, Path

    if param.shell_complete_func is None and isinstance(param.type, (File, Path)):
        return _path_request(param, incomplete)
    return _param_items(param, ctx, incomplete)


def _emit(lines, shell):
    for item in lines:
        value = item["value"]
        help_text = item.get("help")
        if item["type"] in (PATH_DIR, PATH_FILE):
            echo(f"{item['type']} {value}", nl=True)
        elif help_text and shell in ("zsh", "fish"):
            echo(f"{value}\t{help_text}")
        else:
            echo(value)


def handle_complete(cli, prog_name, instruction, args, extra):
    """Source or complete mode. Always exits. # spec: FP-12, N-000989..N-000998"""
    if "_" not in instruction:
        sys.exit(1)
    shell, _, action = instruction.rpartition("_")
    if shell not in SHELLS or action not in ("source", "complete"):
        sys.exit(1)
    var = complete_var_name(prog_name)
    if action == "source":
        echo(_source_script(shell, prog_name, var), nl=False)
        sys.exit(0)
    words, incomplete = _words_and_index(shell)
    _emit(suggestions(cli, prog_name, words, incomplete, extra), shell)
    sys.exit(0)
