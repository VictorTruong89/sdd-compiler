"""Token parsing and value resolution. # spec: FP-01, FP-03, FP-04, FP-07, FP-08"""

from .context import ParameterSource
from .exceptions import BadOptionUsage, BadParameter, MissingParameter, NoSuchOption
from .parameters import _BARE, Argument, Option, option_prefixes


class _Literal(str):
    """A token that followed ``--`` and is therefore never option-shaped. # spec: FP-04"""


class OptionParser:
    """Parses the tokens of one command invocation. # spec: FP-03"""

    def __init__(self, params, ctx, interspersed, ignore_unknown):
        self.ctx = ctx
        self.params = params
        self.interspersed = interspersed
        self.ignore_unknown = ignore_unknown
        self.hits = {}
        self.order = []
        self.opt_map = {}
        opts = []
        for param in params:
            if not isinstance(param, Option):
                continue
            for name in param.opts:
                self.opt_map[self._norm(name)] = (param, False)
                opts.append(name)
            for name in param.secondary_opts:
                self.opt_map[self._norm(name)] = (param, True)
                opts.append(name)
        self.prefixes = option_prefixes(opts)

    # --- helpers ---------------------------------------------------------

    def _norm(self, token):
        func = self.ctx.token_normalize_func
        return func(token) if func is not None else token

    def _is_option_like(self, token):
        return len(token) > 1 and token[0] in self.prefixes

    def _record(self, param, value):
        key = id(param)
        if key not in self.hits:
            self.hits[key] = []
            self.order.append(param)
        self.hits[key].append(value)

    def _take(self, param, args, start, label, off=False):
        """Record the value(s) for one occurrence; return how many following tokens were used."""
        if param.is_flag:
            self._record(param, False if off else param.flag_value)
            return 0
        if param.count:
            self._record(param, 1)
            return 0
        if param.optional_value:
            if start < len(args) and not self._is_option_like(args[start]):
                self._record(param, args[start])
                return 1
            self._record(param, _BARE)
            return 0
        arity = param.nargs
        if start + arity > len(args):
            raise BadOptionUsage(f"Option '{label}' requires an argument.", ctx=self.ctx)
        values = args[start:start + arity]
        self._record(param, values[0] if arity == 1 and not param._tuple_type() else tuple(values))
        return arity

    # --- parsing ---------------------------------------------------------

    def parse(self, args):
        """Return the leftover positional tokens. # spec: FP-03, FP-06"""
        positionals = []
        i = 0
        while i < len(args):
            tok = args[i]
            if tok == "--":
                positionals.extend(_Literal(t) for t in args[i + 1:])
                break
            if self._is_option_like(tok):
                used, extra = self._consume(args, i)
                if used:
                    if extra is not None:
                        positionals.append(extra)
                    i += used
                    continue
                if self.ignore_unknown:
                    positionals.append(tok)
                    i += 1
                    continue
                raise NoSuchOption(tok.split("=", 1)[0], ctx=self.ctx)
            positionals.append(tok)
            if not self.interspersed:
                positionals.extend(args[i + 1:])
                break
            i += 1
        return positionals

    def _consume(self, args, i):
        """Consume an option token at args[i]. Returns (tokens used, leftover token or None). # spec: FP-03"""
        tok = args[i]
        key = self._norm(tok)
        if key in self.opt_map:
            param, off = self.opt_map[key]
            return 1 + self._take(param, args, i + 1, tok, off), None
        if "=" in tok:
            name, _, value = tok.partition("=")
            nkey = self._norm(name)
            if nkey in self.opt_map:
                param, off = self.opt_map[nkey]
                if param.is_flag or param.count:
                    raise BadOptionUsage(f"Option '{name}' does not take a value.", ctx=self.ctx)
                self._record(param, value)
                return 1, None
        pfx = tok[0]
        if len(tok) > 1 and tok[1] in self.prefixes:
            return 0, None  # long form that matched nothing
        j = 1
        leftover = None
        used = 1
        while j < len(tok):
            name = pfx + tok[j]
            nkey = self._norm(name)
            if nkey not in self.opt_map:
                if j == 1:
                    return 0, None
                if self.ignore_unknown:
                    leftover = pfx + tok[j:]
                    break
                raise NoSuchOption(name, ctx=self.ctx)
            param, off = self.opt_map[nkey]
            if param.is_flag or param.count:
                self._take(param, args, i + 1, name, off)
                j += 1
                continue
            rest = tok[j + 1:]
            if rest:
                self._record(param, rest)
            else:
                used += self._take(param, args, i + 1, name, off)
            break
        return used, leftover


# --- value resolution ----------------------------------------------------

def assign_arguments(params, parser, leftover):
    """Bind positional tokens to declared arguments in order. Returns unbound tokens. # spec: FP-04"""
    arguments = [p for p in params if isinstance(p, Argument)]
    rest = list(leftover)
    for idx, arg in enumerate(arguments):
        if arg.nargs == -1:
            reserve = sum(a.nargs for a in arguments[idx + 1:] if a.nargs != -1)
            take = max(0, len(rest) - reserve)
            if take:
                parser.hits[id(arg)] = [tuple(rest[:take])]
                parser.order.append(arg)
                rest = rest[take:]
            continue
        if not rest:
            continue
        if len(rest) < arg.nargs:
            raise BadParameter(
                f"Argument {arg.name.upper()!r} takes {arg.nargs} values.",
                ctx=parser.ctx,
                param=arg,
            )
        values = rest[:arg.nargs]
        parser.hits[id(arg)] = [values[0] if arg.nargs == 1 and not arg._tuple_type() else tuple(values)]
        parser.order.append(arg)
        rest = rest[arg.nargs:]
    return rest


def _processing_order(params, parser):
    invoked = {id(p): i for i, p in enumerate(parser.order)}
    indexed = list(enumerate(params))
    indexed.sort(key=lambda pair: (
        not pair[1].is_eager,
        invoked.get(id(pair[1]), float("inf")),
        pair[0],
    ))
    return [p for _, p in indexed]


def process_params(ctx, params, parser):
    """Resolve every parameter, run callbacks, and bind exposed values. # spec: FP-03, FP-07"""
    for param in _processing_order(params, parser):
        value, source = resolve_value(param, ctx, parser)
        if param.callback is not None:
            value = param.callback(ctx, param, value)
        ctx._sources[param.name] = source
        if param.expose_value:
            ctx.params[param.name] = value


def _warn_deprecated(param, ctx):
    from .termui import echo

    note = param.deprecated if isinstance(param.deprecated, str) else ""
    kind = "option" if isinstance(param, Option) else "argument"
    label = param.label().strip("'") if isinstance(param, Option) else f"'{param.name}'"
    echo(
        f"DeprecationWarning: The {kind} {label} is deprecated. {note}".rstrip() + "\n",
        err=True,
        nl=False,
    )


def resolve_value(param, ctx, parser):
    """Return (value, source) for one parameter. # spec: FP-03, FP-07, FP-08"""
    occ = parser.hits.get(id(param))
    if occ:
        if param.deprecated:
            _warn_deprecated(param, ctx)
        if isinstance(param, Option) and param.prompt and not param.prompt_required and occ[-1] is _BARE:
            return _prompt(param, ctx, param.default), ParameterSource.PROMPT
        value = param.value_from_occurrences(occ, ctx)
        return _finish(param, value, ctx), ParameterSource.COMMANDLINE

    found, value = param.value_from_env(ctx)
    if found:
        return _finish(param, value, ctx), ParameterSource.ENVIRONMENT

    dm_present = ctx.default_map is not None and param.name in ctx.default_map
    dm_value = ctx.default_map.get(param.name) if dm_present else None

    if isinstance(param, Option) and param.prompt and param.prompt_required:
        prompt_default = dm_value if dm_value is not None else param.default
        return _prompt(param, ctx, prompt_default), ParameterSource.PROMPT

    if dm_value is not None:
        return _finish(param, _convert_default_map(param, dm_value, ctx), ctx), ParameterSource.DEFAULT_MAP

    value = param.get_default(ctx)
    return _finish(param, value, ctx), ParameterSource.DEFAULT


def _convert_default_map(param, value, ctx):
    if isinstance(value, str):
        if param.multiple and param._per_occurrence_arity() == 1:
            raise BadParameter(f"{param.label()} needs an iterable (sequence) default.", ctx=ctx, param=param)
        if param._per_occurrence_arity() != 1 or param._tuple_type():
            return param._occurrences_from_pieces(param._split_text(value), ctx)
        return param.type(value, param, ctx)
    return param._convert_default(value, ctx)


def _finish(param, value, ctx):
    """Apply the required check. Missing values have already been resolved to their empty form."""
    if value is None or ((param.multiple or param.nargs == -1) and value == ()):
        if param.required:
            raise MissingParameter(f"Missing {param.kind_word()}.", ctx=ctx, param=param)
    return value


def _prompt(param, ctx, default):
    from .termui import confirm, prompt

    if param.is_flag:
        return confirm(param.prompt_text(), default=bool(default))
    value = prompt(
        param.prompt_text(),
        default=default,
        hide_input=param.hide_input,
        confirmation_prompt=param.confirmation_prompt,
        type=param.type,
        param=param,
        ctx=ctx,
    )
    return value
