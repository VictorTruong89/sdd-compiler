"""In-process runner. # spec: FP-14, N-001006..N-001012"""

import contextlib
import io
import os
import shlex
import shutil
import sys
import tempfile


class _Sink:
    """Shared record of everything written, in write order. # spec: FP-14"""

    def __init__(self):
        self.combined = bytearray()
        self.stdout = bytearray()
        self.stderr = bytearray()


class _ByteSink(io.RawIOBase):
    def __init__(self, sink, name):
        self._sink = sink
        self._name = name

    def writable(self):
        return True

    def write(self, data):
        data = bytes(data)
        target = self._sink.stdout if self._name == "stdout" else self._sink.stderr
        target.extend(data)
        self._sink.combined.extend(data)
        return len(data)

    def flush(self):
        pass


class _TextSink(io.TextIOBase):
    def __init__(self, sink, name, charset):
        self._sink = sink
        self._name = name
        self._charset = charset
        self.buffer = _ByteSink(sink, name)

    @property
    def encoding(self):
        return self._charset

    def writable(self):
        return True

    def isatty(self):
        return False

    def write(self, text):
        data = text.encode(self._charset, "replace")
        self.buffer.write(data)
        return len(text)

    def flush(self):
        pass


class _Input(io.TextIOWrapper):
    """Standard input fed from invoke(input=...). # spec: FP-14"""

    def __init__(self, data, charset, echo_sink=None):
        super().__init__(io.BytesIO(data), encoding=charset, newline=None)
        self._echo_sink = echo_sink
        self.echoes_reads = echo_sink is not None

    def readline(self, *args):
        line = super().readline(*args)
        if self._echo_sink is not None and line:
            self._echo_sink.write(line.rstrip("\n"))
            self._echo_sink.write("\n")
        return line

    def isatty(self):
        return False


class Result:
    """Outcome of an invocation. # spec: FP-14, N-001007..N-001011"""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, exit_code, exception, exc_info=None):
        self.runner = runner
        self.stdout_bytes = bytes(stdout_bytes)
        self.stderr_bytes = bytes(stderr_bytes)
        self.output_bytes = bytes(output_bytes)
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invoke commands in-process. # spec: FP-14, N-001006"""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        if isinstance(input, str):
            data = input.encode(self.charset)
        elif input is None:
            data = b""
        else:
            data = bytes(input)
        sink = _Sink()
        if self.capture == "fd":
            yield from self._fd_isolation(data, env, sink)
            return
        out = _TextSink(sink, "stdout", self.charset)
        err = _TextSink(sink, "stderr", self.charset)
        stdin = _Input(data, self.charset, echo_sink=out if self.echo_stdin else None)
        saved = (sys.stdin, sys.stdout, sys.stderr)
        saved_env = self._apply_env(env)
        sys.stdin, sys.stdout, sys.stderr = stdin, out, err
        try:
            yield sink
        finally:
            sys.stdin, sys.stdout, sys.stderr = saved
            self._restore_env(saved_env)

    def _fd_isolation(self, data, env, sink):
        out_tmp = tempfile.TemporaryFile()
        err_tmp = tempfile.TemporaryFile()
        in_tmp = tempfile.TemporaryFile()
        in_tmp.write(data)
        in_tmp.seek(0)
        saved_fds = (os.dup(0), os.dup(1), os.dup(2))
        saved_py = (sys.stdin, sys.stdout, sys.stderr)
        saved_env = self._apply_env(env)
        try:
            os.dup2(in_tmp.fileno(), 0)
            os.dup2(out_tmp.fileno(), 1)
            os.dup2(err_tmp.fileno(), 2)
            sys.stdin = io.TextIOWrapper(os.fdopen(os.dup(0), "rb"), encoding=self.charset)
            sys.stdout = io.TextIOWrapper(os.fdopen(os.dup(1), "wb"), encoding=self.charset, line_buffering=True)
            sys.stderr = io.TextIOWrapper(os.fdopen(os.dup(2), "wb"), encoding=self.charset, line_buffering=True)
            yield sink
        finally:
            for stream in (sys.stdout, sys.stderr):
                try:
                    stream.flush()
                except Exception:
                    pass
            sys.stdin, sys.stdout, sys.stderr = saved_py
            os.dup2(saved_fds[0], 0)
            os.dup2(saved_fds[1], 1)
            os.dup2(saved_fds[2], 2)
            for fd in saved_fds:
                os.close(fd)
            out_tmp.seek(0)
            err_tmp.seek(0)
            sink.stdout.extend(out_tmp.read())
            sink.stderr.extend(err_tmp.read())
            sink.combined.extend(sink.stdout + sink.stderr)
            for f in (out_tmp, err_tmp, in_tmp):
                f.close()
            self._restore_env(saved_env)

    def _apply_env(self, env):
        merged = dict(self.env)
        merged.update(env or {})
        saved = {}
        for key, value in merged.items():
            saved[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        return saved

    def _restore_env(self, saved):
        for key, value in saved.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        """Run cli with args and capture the outcome. # spec: FP-14, N-001006..N-001011"""
        if args is None:
            args = []
        elif isinstance(args, str):
            args = shlex.split(args)
        args = list(args)
        catch = self.catch_exceptions if catch_exceptions is None else catch_exceptions
        standalone = extra.pop("standalone_mode", True)
        prog_name = extra.pop("prog_name", None) or cli.name or "root"
        extra.setdefault("color", color)
        exit_code = 0
        exception = None
        exc_info = None
        with self.isolation(input=input, env=env, color=color) as sink:
            try:
                cli.main(args=args, prog_name=prog_name, standalone_mode=standalone, **extra)
            except SystemExit as e:
                code = e.code
                if code is None:
                    exit_code = 0
                elif isinstance(code, int):
                    exit_code = code
                else:
                    sys.stdout.write(str(code) + "\n")
                    exit_code = 1
            except Exception as e:
                if not catch:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
        return Result(
            self,
            sink.stdout,
            sink.stderr,
            sink.combined,
            exit_code,
            exception,
            exc_info,
        )

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Run inside a fresh empty working directory. # spec: FP-14, N-001012"""
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(path, ignore_errors=True)
