"""Terminal helpers. # spec: FP-08, FP-11, N-000963..N-000982"""

import contextlib
import io
import os
import shlex
import subprocess
import sys
import tempfile
import time

from .context import get_current_context
from .exceptions import Abort, BadParameter
from .types import convert_type
from .utils import get_app_dir as _get_app_dir
from .utils import is_tty, strip_ansi, write_text

_COLORS = {
    "black": 30,
    "red": 31,
    "green": 32,
    "yellow": 33,
    "blue": 34,
    "magenta": 35,
    "cyan": 36,
    "white": 37,
    "bright_black": 90,
    "bright_red": 91,
    "bright_green": 92,
    "bright_yellow": 93,
    "bright_blue": 94,
    "bright_magenta": 95,
    "bright_cyan": 96,
    "bright_white": 97,
    "reset": 39,
}

_STYLE_CODES = {
    "bold": 1,
    "dim": 2,
    "italic": 3,
    "underline": 4,
    "blink": 5,
    "reverse": 7,
    "strikethrough": 9,
    "overline": 53,
}


def _current_color_flag():
    ctx = get_current_context(silent=True)
    if ctx is None:
        return None
    return ctx.color


def _is_interactive(stream=None):
    return is_tty(sys.stdin) or is_tty(sys.stdout)


def _color_code(color, background=False):
    base = 40 if background else 30
    if isinstance(color, bool):
        raise TypeError("Invalid color.")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise TypeError(f"Invalid color {color!r}.")
        return f"{'48' if background else '38'};5;{color}"
    if isinstance(color, (tuple, list)):
        if len(color) != 3 or not all(isinstance(c, int) and 0 <= c <= 255 for c in color):
            raise TypeError(f"Invalid color {color!r}.")
        return f"{'48' if background else '38'};2;{color[0]};{color[1]};{color[2]}"
    if isinstance(color, str) and color in _COLORS:
        code = _COLORS[color]
        if color == "reset":
            return "49" if background else "39"
        if background:
            code += 10
        return str(code)
    raise TypeError(f"Unknown color {color!r}.")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
):
    """Wrap text in ANSI SGR sequences. # spec: N-000965, FP-11"""
    codes = []
    if fg is not None:
        codes.append(_color_code(fg))
    if bg is not None:
        codes.append(_color_code(bg, background=True))
    switches = {
        "bold": bold,
        "dim": dim,
        "underline": underline,
        "overline": overline,
        "italic": italic,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for name, flag in switches.items():
        if flag is not None:
            codes.append(str(_STYLE_CODES[name]) if flag else str(_STYLE_CODES[name] + 20))
    if not codes:
        return text
    prefix = f"\033[{';'.join(codes)}m"
    return prefix + text + ("\033[0m" if reset else "")


def unstyle(text):
    """Remove ANSI styles. # spec: FP-11"""
    return strip_ansi(text)


def _resolve_strip(stream, color):
    if color is None:
        color = _current_color_flag()
    if color is True:
        return False
    if color is False:
        return True
    return not is_tty(stream)


def _to_text(message):
    if message is None:
        return ""
    if isinstance(message, bytes):
        return message.decode("utf-8", "replace")
    return str(message)


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes. # spec: FP-11, N-000966"""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if isinstance(message, bytes):
        buf = getattr(file, "buffer", None)
        if buf is not None:
            file.flush()
            buf.write(message + (b"\n" if nl else b""))
            buf.flush()
        else:
            file.write(message.decode("utf-8", "replace") + ("\n" if nl else ""))
        return
    text = _to_text(message)
    if _resolve_strip(file, color):
        text = strip_ansi(text)
    if nl:
        text += "\n"
    write_text(file, text)
    file.flush()


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    """Style then echo. # spec: FP-11"""
    if message is not None:
        message = style(_to_text(message), **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def echo_via_pager(text_or_generator, color=None):
    """Page text. # spec: FP-11, N-000980, N-000981"""
    if callable(text_or_generator):
        chunks = text_or_generator()
    else:
        chunks = text_or_generator
    if isinstance(chunks, str):
        chunks = [chunks]
    chunks = [_to_text(c) for c in chunks]
    pager = os.environ.get("PAGER")
    if _is_interactive() and pager and is_tty(sys.stdout):
        proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE, text=True)
        try:
            for chunk in chunks:
                proc.stdin.write(chunk)
                proc.stdin.flush()
        finally:
            try:
                proc.stdin.close()
            except Exception:
                pass
            proc.wait()
        return
    for chunk in chunks:
        echo(chunk, nl=False, color=color)


@contextlib.contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream whose contents are paged on exit. # spec: FP-11"""
    buf = io.StringIO()
    try:
        yield buf
    finally:
        echo_via_pager(buf.getvalue(), color=color)


class ProgressBar:
    """Simple progress bar. # spec: FP-11"""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, file=None, **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label
        self.file = file or sys.stdout
        self.pos = 0
        self.start = time.time()
        self.hidden = hidden
        self.tty = is_tty(self.file) and not hidden
        if not self.hidden and not self.tty and self.label:
            echo(self.label, file=self.file)

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps):
        self.pos += n_steps
        if self.tty:
            if self.length:
                pct = min(100, int(self.pos * 100 / self.length))
                elapsed = time.time() - self.start
                remaining = ""
                if self.pos:
                    eta = elapsed / self.pos * max(self.length - self.pos, 0)
                    remaining = f" eta {int(eta)}s"
                line = f"\r{self.label or ''} [{'#' * (pct // 4):<25}] {pct}%{remaining}"
            else:
                line = f"\r{self.label or ''} {self.pos}"
            self.file.write(line)
            self.file.flush()

    def finish(self):
        if self.tty:
            self.file.write("\n")
            self.file.flush()


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    """Progress bar context manager. # spec: FP-11, N-000978"""
    bar = ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)
    try:
        yield bar
    finally:
        bar.finish()


def _read_line(hide_input):
    stream = sys.stdin
    line = stream.readline()
    if line == "":
        raise EOFError()
    line = line.rstrip("\r\n")
    if not hide_input and not is_tty(stream) and not getattr(stream, "echoes_reads", False):
        # Visible typed input is echoed into captured output when not on a terminal.
        echo(line, file=sys.stdout)
    return line


def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    value_proc=None,
    prompt_suffix=": ",
    show_default=True,
    err=False,
    show_choices=True,
    param=None,
    ctx=None,
):
    """Ask for a value. # spec: FP-08, N-000977"""
    ptype = convert_type(type, default)
    if default is not None and show_default:
        shown = default() if callable(default) else default
        prompt_text = f"{text} [{shown}]{prompt_suffix}"
    else:
        prompt_text = f"{text}{prompt_suffix}"
    out = sys.stderr if err else sys.stdout
    if ctx is None:
        ctx = get_current_context(silent=True)
    while True:
        write_text(out, prompt_text)
        out.flush()
        try:
            value = _read_line(hide_input)
            if value == "" and default is not None:
                value = default() if callable(default) else default
            elif value == "":
                continue
            if confirmation_prompt:
                write_text(out, "Repeat for confirmation" + prompt_suffix)
                out.flush()
                second = _read_line(hide_input)
                if second != value:
                    echo("Error: the two entered values do not match", err=True)
                    continue
            if value_proc is not None:
                return value_proc(value)
            return ptype(value, param, ctx)
        except BadParameter as e:
            echo(f"Error: {e.format_message()}", err=True)
        except EOFError:
            raise Abort()
        except KeyboardInterrupt:
            raise Abort()


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Yes/no question. # spec: FP-08"""
    if default is True:
        shown = "[Y/n]"
    elif default is False:
        shown = "[y/N]"
    else:
        shown = "[y/n]"
    out = sys.stderr if err else sys.stdout
    while True:
        write_text(out, f"{text} {shown}{prompt_suffix}")
        out.flush()
        try:
            value = _read_line(False).strip().lower()
        except (EOFError, KeyboardInterrupt):
            raise Abort()
        if value in ("y", "yes"):
            rv = True
        elif value in ("n", "no"):
            rv = False
        elif value == "" and default is not None:
            rv = default
        else:
            continue
        break
    if not rv and abort:
        raise Abort()
    return rv


def _open_terminal():
    try:
        return open("/dev/tty", "rb", buffering=0)
    except OSError:
        return None


def getchar(echo=False):
    """Read one character from the terminal. # spec: FP-11"""
    tty = _open_terminal()
    if tty is None:
        ch = sys.stdin.read(1)
        if ch == "":
            raise EOFError()
    else:
        try:
            ch = tty.read(1).decode("utf-8", "replace")
        finally:
            tty.close()
        if ch == "":
            raise EOFError()
    if echo:
        sys.stdout.write(ch)
        sys.stdout.flush()
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04":
        raise EOFError()
    return ch


def pause(info=None, err=False):
    """Wait for a key when interactive. # spec: FP-11"""
    if not _is_interactive():
        return
    if info is None:
        info = "Press any key to continue..."
    echo(info, err=err, nl=False)
    try:
        getchar()
    except (EOFError, KeyboardInterrupt):
        pass
    echo("", err=err)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor on text or a file. # spec: FP-11, N-000971"""
    editor_cmd = editor or (env or {}).get("EDITOR") or os.environ.get("VISUAL") or os.environ.get("EDITOR")
    if not editor_cmd:
        editor_cmd = "notepad" if os.name == "nt" else "vi"
    if filename is not None:
        subprocess.call(shlex.split(editor_cmd) + [os.fspath(filename)])
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        original = (text or "").replace("\r\n", "\n")
        with os.fdopen(fd, "w", encoding="utf-8", newline="\n") as f:
            f.write(original)
        subprocess.call(shlex.split(editor_cmd) + [path])
        with open(path, encoding="utf-8", newline="") as f:
            result = f.read().replace("\r\n", "\n")
    finally:
        os.remove(path)
    if require_save and result == original:
        return None
    return result


def launch(url, wait=False, locate=False):
    """Open a URL or file with the default application. # spec: FP-11"""
    if sys.platform == "darwin":
        args = ["open"]
    elif os.name == "nt":
        args = ["cmd", "/c", "start", ""]
    else:
        args = ["xdg-open"]
    if locate and sys.platform == "darwin":
        args.append("-R")
    args.append(os.fspath(url) if not isinstance(url, str) else url)
    try:
        if wait:
            return subprocess.call(args)
        subprocess.Popen(args)
        return 0
    except OSError:
        return 1


def clear():
    """Clear the terminal screen when connected to one. # spec: FP-11"""
    if is_tty(sys.stdout):
        sys.stdout.write("\033[2J\033[H")
        sys.stdout.flush()


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Per-user config directory. # spec: FP-11"""
    return _get_app_dir(app_name, roaming=roaming, force_posix=force_posix)
