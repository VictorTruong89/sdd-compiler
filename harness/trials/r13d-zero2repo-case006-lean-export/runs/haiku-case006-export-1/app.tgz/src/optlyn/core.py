"""Commands, groups and program entry. # spec: FP-01, FP-02, FP-06, FP-10, FP-13, N-000834..N-000867"""

import os
import shutil
import sys

from .context import CHAIN_SUBCOMMAND, Context
from .exceptions import (
    Abort,
    Exit,
    MissingCommand,
    NoArgsIsHelp,
    NoSuchCommand,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import HelpFormatter, ellipsize, first_sentence
from .parameters import Argument, Option
from .parser import _Literal, OptionParser, assign_arguments, process_params
from .termui import echo


def _derive_name(func):
    """Name from a function: lowercase, underscores to dashes, command suffix stripped. # spec: FP-01"""
    name = func.__name__.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _help_callback(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


def _make_help_option(names):
    return Option(
        list(names),
        is_flag=True,
        is_eager=True,
        expose_value=False,
        help="Show this message and exit.",
        callback=_help_callback,
    )


class Command:
    """A leaf command. # spec: FP-01, N-000834..N-000849"""

    allow_extra_args = False
    allow_interspersed_args = True
    ignore_unknown_options = False

    def __init__(
        self,
        name=None,
        context_settings=None,
        callback=None,
        params=None,
        help=None,
        epilog=None,
        short_help=None,
        options_metavar="[OPTIONS]",
        add_help_option=True,
        no_args_is_help=False,
        hidden=False,
        deprecated=False,
        **extra,
    ):
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated
        self.extra = extra

    # --- invocation ------------------------------------------------------

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        """Run as a program. # spec: FP-01, FP-13, FP-12, N-000842..N-000848"""
        if args is None:
            args = sys.argv[1:]
        if prog_name is None:
            prog_name = _detect_prog_name()
        from . import shell_completion

        var = complete_var or shell_completion.complete_var_name(prog_name)
        if var in os.environ:
            shell_completion.handle_complete(self, prog_name, os.environ[var], args, extra)
            return None

        ctx = None
        try:
            ctx = self.make_context(prog_name, list(args), **extra)
            try:
                rv = self.invoke(ctx)
                if not standalone_mode:
                    return rv
            finally:
                ctx.close()
            raise Exit(0)
        except Exit as e:
            if standalone_mode:
                sys.exit(e.exit_code)
            return None
        except (EOFError, KeyboardInterrupt):
            if not standalone_mode:
                raise Abort()
            echo("", err=True)
            echo("Aborted!", err=True)
            sys.exit(1)
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", err=True)
            sys.exit(1)
        except OptlynError as e:
            if not standalone_mode:
                raise
            e.show()
            sys.exit(e.exit_code)

    def make_context(self, info_name, args, parent=None, chained=False, **extra):
        """Build and parse the context for one invocation. # spec: FP-07"""
        for key, value in self.context_settings.items():
            extra.setdefault(key, value)
        ctx = Context(self, info_name=info_name, parent=parent, **extra)
        if parent is not None:
            if ctx.auto_envvar_prefix is None and parent.auto_envvar_prefix is not None:
                ctx.auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{info_name}"
            if ctx.default_map is None and isinstance(parent.default_map, dict):
                child_map = parent.default_map.get(info_name)
                if isinstance(child_map, dict):
                    ctx.default_map = child_map
        ctx.chained = chained
        with ctx:
            self.parse_args(ctx, list(args))
        return ctx

    def invoke(self, ctx):
        """Run the callback of a leaf command. # spec: FP-01"""
        if self.deprecated:
            _warn_command_deprecated(self)
        if self.callback is None:
            return None
        with ctx:
            return self.callback(**ctx.params)

    # --- parsing ---------------------------------------------------------

    def get_params(self, ctx):
        params = list(self.params)
        if self.add_help_option:
            declared = {n for p in params for n in p.opts + p.secondary_opts}
            names = [n for n in ctx.help_option_names if n not in declared]
            if names:
                params.append(_make_help_option(names))
        return params

    def _effective(self, ctx, attr, default):
        value = getattr(ctx, attr)
        return default if value is None else value

    def parse_args(self, ctx, args):
        """Parse, resolve values and run callbacks. # spec: FP-03, FP-04, FP-13"""
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelp(ctx)
        params = self.get_params(ctx)
        ctx._all_params = params
        interspersed = self._effective(ctx, "allow_interspersed_args", self.allow_interspersed_args)
        ignore_unknown = self._effective(ctx, "ignore_unknown_options", self.ignore_unknown_options)
        allow_extra = self._effective(ctx, "allow_extra_args", self.allow_extra_args)
        parser = OptionParser(params, ctx, interspersed, ignore_unknown)
        ctx._parser = parser
        leftover = parser.parse(args)
        leftover = self._take_arguments(ctx, params, parser, leftover)
        process_params(ctx, params, parser)
        self._check_extra(ctx, leftover, allow_extra, parser.prefixes, ignore_unknown)
        ctx.args = leftover
        return leftover

    def _take_arguments(self, ctx, params, parser, leftover):
        return assign_arguments(params, parser, leftover)

    def _check_extra(self, ctx, leftover, allow_extra, prefixes, ignore_unknown):
        """Leftover tokens: option-shaped ones are usage errors; others need allow_extra_args. # spec: FP-01"""
        if not leftover or ctx.chained:
            return
        if not ignore_unknown:
            for tok in leftover:
                if not isinstance(tok, _Literal) and len(tok) > 1 and tok[0] in prefixes:
                    raise NoSuchOption(tok.split("=", 1)[0], ctx=ctx)
        if allow_extra:
            return
        raise UsageError(f"Got unexpected extra argument(s) ({' '.join(repr(t) for t in leftover)}).", ctx=ctx)

    # --- help ------------------------------------------------------------

    def get_usage(self, ctx):
        pieces = self.collect_usage_pieces(ctx)
        return f"Usage: {' '.join([ctx.command_path] + pieces)}".rstrip()

    def collect_usage_pieces(self, ctx):
        pieces = []
        params = self.get_params(ctx)
        if any(not p.hidden for p in params if isinstance(p, Option)) and self.options_metavar:
            pieces.append(self.options_metavar)
        for arg in params:
            if isinstance(arg, Argument) and not arg.hidden:
                pieces.append(_argument_usage(arg))
        return pieces

    def _width(self, ctx):
        if ctx.terminal_width:
            return ctx.terminal_width
        return min(shutil.get_terminal_size((80, 24)).columns, ctx.max_content_width)

    def get_help(self, ctx):
        """The full help page. # spec: FP-02, N-000812..N-000833"""
        fmt = HelpFormatter(width=self._width(ctx))
        fmt.write_usage(ctx.command_path, " ".join(self.collect_usage_pieces(ctx)), prefix="Usage: ")
        fmt.write("\n")
        description = self.help or ""
        description = description.split("\f", 1)[0]
        description = _strip_backspace_lines(description)
        if self.deprecated:
            fmt.write("(Deprecated)\n\n" if not description else "(Deprecated) ")
        if description:
            fmt.write_text(description)
        self._write_argument_section(ctx, fmt)
        self._write_option_section(ctx, fmt)
        self._write_command_section(ctx, fmt)
        if self.epilog:
            fmt.write_text(self.epilog)
        return fmt.getvalue().rstrip("\n")

    def get_short_help_str(self, limit=45):
        text = self.short_help if self.short_help else first_sentence(self.help or "")
        return ellipsize(text.split("\f", 1)[0], limit)

    def _write_argument_section(self, ctx, fmt):
        rows = []
        for arg in self.get_params(ctx):
            if isinstance(arg, Argument) and not arg.hidden and arg.help:
                rows.append((arg.get_metavar(ctx), arg.help))
        if rows:
            with fmt.section("Positional arguments"):
                fmt.write_dl(rows)

    def _write_option_section(self, ctx, fmt):
        rows = []
        for opt in self.get_params(ctx):
            if isinstance(opt, Option) and not opt.hidden:
                rows.append(_option_row(opt, ctx))
        if rows:
            with fmt.section("Options"):
                fmt.write_dl(rows)

    def _write_command_section(self, ctx, fmt):
        pass


def _strip_backspace_lines(text):
    lines = text.split("\n")
    out = []
    for line in lines:
        if line.strip() == "\b":
            continue
        out.append(line)
    return "\n".join(out)


def _argument_usage(arg):
    metavar = arg.get_metavar()
    if arg.nargs == -1:
        return f"[{metavar}]..." if not arg.required else f"{metavar}..."
    if arg.nargs != 1:
        metavar = " ".join([metavar] * arg.nargs)
    return metavar if arg.required else f"[{metavar}]"


def _option_row(opt, ctx):
    names = []
    if opt.secondary_opts:
        names.append("/".join(opt.opts) + "/" + "/".join(opt.secondary_opts))
    else:
        names.append(", ".join(opt.opts))
    first = names[0]
    if not opt.is_flag and not opt.count:
        first = f"{first} {opt.get_metavar(ctx)}"
    extras = []
    show_default = opt.show_default if opt.show_default is not None else ctx.show_default
    if show_default:
        if isinstance(show_default, str):
            extras.append(f"[default: {show_default}]")
        elif opt.default is not None and not (opt.is_flag and opt.default is False):
            default = opt.default() if callable(opt.default) else opt.default
            if isinstance(default, (list, tuple)):
                text = ", ".join(str(d) for d in default)
            else:
                text = str(default)
            extras.append(f"[default: {text}]")
    if opt.show_envvar and opt.envvar:
        names_env = [opt.envvar] if isinstance(opt.envvar, str) else list(opt.envvar)
        extras.append(f"[env var: {', '.join(names_env)}]")
    if opt.deprecated:
        extras.append("(DEPRECATED)")
    text = " ".join(part for part in [opt.help or "", *extras] if part)
    return (first, text)


def _warn_command_deprecated(cmd):
    note = cmd.deprecated if isinstance(cmd.deprecated, str) else ""
    echo(f"DeprecationWarning: The command {cmd.name!r} is deprecated. {note}".rstrip() + "\n", err=True, nl=False)


def _detect_prog_name():
    if sys.argv and sys.argv[0]:
        return os.path.basename(sys.argv[0])
    return "main"


class Group(Command):
    """Dispatches to named subcommands. # spec: FP-06, FP-10, N-000850..N-000865"""

    allow_interspersed_args = False

    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        **kwargs,
    ):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name=name, no_args_is_help=no_args_is_help, **kwargs)
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback
        self.commands = {}
        if isinstance(commands, dict):
            for cmd_name, cmd in commands.items():
                self.add_command(cmd, cmd_name)
        elif commands:
            for cmd in commands:
                self.add_command(cmd)

    # --- registration ----------------------------------------------------

    def add_command(self, cmd, name=None):
        """Register a subcommand. # spec: N-000857..N-000859"""
        if self.chain and isinstance(cmd, Group):
            raise RuntimeError("Cannot attach a group beneath a chaining group.")
        name = name or cmd.name
        if not name:
            raise TypeError("A command needs a name to be registered.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        """Decorator that attaches a leaf command. # spec: N-000860, N-000861"""
        from .decorators import command as command_decorator

        return self._child_decorator(command_decorator, args, kwargs)

    def group(self, *args, **kwargs):
        """Decorator that attaches a nested group. # spec: N-000860, N-000861"""
        from .decorators import group as group_decorator

        return self._child_decorator(group_decorator, args, kwargs)

    def _child_decorator(self, factory, args, kwargs):
        if args and callable(args[0]) and not isinstance(args[0], str):
            cmd = factory(**kwargs)(args[0])
            self.add_command(cmd)
            return cmd

        def decorator(f):
            cmd = factory(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        """Decorator for the result callback. # spec: N-000862, N-000863"""

        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    def list_commands(self, ctx):
        """Names of subcommands. Override point. # spec: N-000864"""
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        """Look up a subcommand by name. Override point. # spec: N-000865"""
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        func = ctx.token_normalize_func
        if func is not None:
            wanted = func(cmd_name)
            for name in self.list_commands(ctx):
                if func(name) == wanted:
                    return self.get_command(ctx, name)
        return None

    def resolve_command(self, ctx, name):
        cmd = self.get_command(ctx, name)
        return cmd

    # --- parsing ---------------------------------------------------------

    def _take_arguments(self, ctx, params, parser, leftover):
        return assign_arguments(params, parser, leftover)

    def _check_extra(self, ctx, leftover, allow_extra):
        return None

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelp(ctx)
        params = self.get_params(ctx)
        ctx._all_params = params
        interspersed = self._effective(ctx, "allow_interspersed_args", self.allow_interspersed_args)
        ignore_unknown = self._effective(ctx, "ignore_unknown_options", self.ignore_unknown_options)
        parser = OptionParser(params, ctx, interspersed, ignore_unknown)
        ctx._parser = parser
        leftover = parser.parse(args)
        leftover = self._take_arguments(ctx, params, parser, leftover)
        process_params(ctx, params, parser)
        ctx.protected_args = leftover
        ctx.args = []
        return leftover

    # --- invocation ------------------------------------------------------

    def _call_group_callback(self, ctx):
        if self.callback is None:
            return None
        with ctx:
            return self.callback(**ctx.params)

    def _run_result_callback(self, ctx, value):
        with ctx:
            return self._result_callback(value, **ctx.params)

    def invoke(self, ctx):
        """Dispatch to the named subcommand. # spec: FP-06, FP-10"""
        if self.deprecated:
            _warn_command_deprecated(self)
        if self.chain:
            return self._invoke_chain(ctx)
        protected = ctx.protected_args
        if not protected:
            if not self.invoke_without_command:
                raise MissingCommand(ctx)
            ctx.invoked_subcommand = None
            rv = self._call_group_callback(ctx)
            if self._result_callback is not None:
                return self._run_result_callback(ctx, rv)
            return rv
        name = protected[0]
        cmd = self.resolve_command(ctx, name)
        if cmd is None:
            raise NoSuchCommand(name, ctx=ctx)
        ctx.invoked_subcommand = name
        rv = self._call_group_callback(ctx)
        sub_ctx = cmd.make_context(name, protected[1:], parent=ctx)
        value = sub_ctx.command.invoke(sub_ctx)
        if self._result_callback is not None:
            return self._run_result_callback(ctx, value)
        return value

    def _invoke_chain(self, ctx):
        protected = ctx.protected_args
        if not protected and not self.invoke_without_command:
            raise MissingCommand(ctx)
        ctx.invoked_subcommand = CHAIN_SUBCOMMAND if protected else None
        self._call_group_callback(ctx)
        results = []
        rest = list(protected)
        while rest:
            name = rest[0]
            cmd = self.resolve_command(ctx, name)
            if cmd is None:
                raise NoSuchCommand(name, ctx=ctx)
            sub_ctx = cmd.make_context(name, rest[1:], parent=ctx, chained=True)
            results.append(sub_ctx.command.invoke(sub_ctx))
            rest = list(sub_ctx.args)
            sub_ctx.close()
        if self._result_callback is not None:
            self._run_result_callback(ctx, results)
        return results

    # --- help ------------------------------------------------------------

    def collect_usage_pieces(self, ctx):
        pieces = super().collect_usage_pieces(ctx)
        metavar = self.subcommand_metavar
        if self.chain:
            pieces.append(metavar or "COMMAND [ARGS]...")
            pieces.append("[COMMAND [ARGS]...]...")
        elif self.invoke_without_command:
            pieces.append(metavar or "[COMMAND] [ARGS]...")
        else:
            pieces.append(metavar or "COMMAND [ARGS]...")
        return pieces

    def _write_command_section(self, ctx, fmt):
        rows = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            rows.append((name, cmd.get_short_help_str(max(10, fmt.width - 30))))
        if rows:
            with fmt.section("Commands"):
                fmt.write_dl(rows)


class CommandCollection(Group):
    """Union of subcommands from several groups. # spec: N-000866, N-000867"""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name=name, **kwargs)
        self.sources = list(sources) if sources is not None else []

    def list_commands(self, ctx):
        names = set(self.commands)
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        if cmd_name in self.commands:
            return self.commands[cmd_name]
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None
