"""Help-page formatting. # spec: FP-02, N-000812..N-000833, N-000963"""

import textwrap
from contextlib import contextmanager

from .utils import strip_ansi


def wrap_text(text, width=78, initial_indent="", subsequent_indent="", preserve_paragraphs=False):
    """Wrap text to width. Never fails. # spec: FP-11, FP-02"""
    if not text:
        return ""
    width = max(10, int(width))
    paragraphs = _split_paragraphs(text)
    out = []
    for i, (kind, body) in enumerate(paragraphs):
        if kind == "raw":
            out.append("\n".join(body))
            continue
        joined = " ".join(line.strip() for line in body if line.strip())
        indent_first = initial_indent if i == 0 else subsequent_indent
        if not joined:
            out.append("")
            continue
        out.append(
            textwrap.fill(
                joined,
                width=width,
                initial_indent=indent_first,
                subsequent_indent=subsequent_indent,
                break_long_words=False,
                break_on_hyphens=False,
            )
        )
    return "\n\n".join(out)


def _split_paragraphs(text):
    """Split into paragraphs. A paragraph whose first line is a lone backspace is kept raw. # spec: FP-02"""
    result = []
    current = []
    for line in text.splitlines():
        if line.strip() == "":
            if current:
                result.append(current)
                current = []
            continue
        current.append(line)
    if current:
        result.append(current)
    out = []
    for para in result:
        if para[0].strip() == "\b":
            body = [ln for ln in para[1:]]
            out.append(("raw", [ln.rstrip() for ln in body]))
        else:
            out.append(("wrap", para))
    return out


def ellipsize(text, width):
    if len(text) <= width:
        return text
    if width <= 3:
        return "." * width
    return text[: width - 3].rstrip() + "..."


def first_sentence(text):
    """First sentence of a docstring-like text. # spec: FP-02"""
    if not text:
        return ""
    flat = " ".join(text.split())
    for sep in (". ", ".\n"):
        idx = flat.find(sep)
        if idx != -1:
            return flat[: idx + 1]
    return flat.rstrip(".") + ("." if flat.endswith(".") else "")


class HelpFormatter:
    """Builds help pages in a fixed layout. # spec: N-000812..N-000829"""

    def __init__(self, width=78, max_width=80, indent_increment=2):
        self.width = min(width, max_width) if width else max_width
        self.indent_increment = indent_increment
        self.buffer = []
        self.indent = 0

    def write(self, text):
        self.buffer.append(text)

    def write_usage(self, prog, args="", prefix="Usage: "):
        usage_prefix = f"{prefix}{prog} "
        text = f"{usage_prefix}{args}".rstrip()
        self.write(text + "\n")

    def write_text(self, text):
        if not text:
            return
        self.write(wrap_text(text, self.width, initial_indent="", subsequent_indent="") + "\n\n")

    @contextmanager
    def section(self, name):
        self.write(f"{name}:\n")
        self.indent += self.indent_increment
        try:
            yield self
        finally:
            self.indent -= self.indent_increment
        self.write("\n")

    def write_dl(self, rows, col_max=30, col_spacer=2):
        if not rows:
            return
        first_col = min(max(len(a) for a, _ in rows), col_max) + col_spacer
        pad = " " * self.indent
        second_width = max(10, self.width - first_col - self.indent)
        for first, second in rows:
            if not second:
                self.write(f"{pad}{first}\n")
                continue
            if len(first) <= first_col - col_spacer:
                head = f"{pad}{first.ljust(first_col)}"
                lead_len = len(head)
            else:
                self.write(f"{pad}{first}\n")
                head = " " * (self.indent + first_col)
                lead_len = len(head)
            body = wrap_text(second, second_width)
            lines = body.split("\n")
            self.write(f"{head}{lines[0]}\n")
            for ln in lines[1:]:
                self.write(" " * lead_len + ln + "\n")

    def getvalue(self):
        return "".join(self.buffer)


def strip_for_plain(text):
    return strip_ansi(text)
