"""Options, arguments and value resolution. # spec: FP-03, FP-04, FP-07, FP-08, N-000868..N-000910"""

import os
import re

from .context import ParameterSource
from .exceptions import BadParameter, MissingParameter
from .types import BOOL, INT, STRING, Tuple, convert_type

_BARE = object()  # an optional-value option given with no value token

_TRUE = {"true", "1", "yes", "on", "t", "y"}
_FALSE = {"false", "0", "no", "off", "f", "n"}


class Parameter:
    """Base class for options and arguments. # spec: N-000908..N-000910"""

    param_type_name = "parameter"

    def __init__(
        self,
        param_decls=None,
        type=None,
        required=False,
        default=None,
        callback=None,
        nargs=None,
        multiple=False,
        metavar=None,
        expose_value=True,
        is_eager=False,
        envvar=None,
        shell_complete=None,
        deprecated=False,
        help=None,
        hidden=False,
        allow_from_autoenv=True,
    ):
        self.name = None
        self.opts = []
        self.secondary_opts = []
        self.type = convert_type(type, default)
        self.required = required
        self.default = default
        self.callback = callback
        self.nargs = nargs
        self.multiple = multiple
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.envvar = envvar
        self.shell_complete_func = shell_complete
        self.deprecated = deprecated
        self.help = help
        self.hidden = hidden
        self.allow_from_autoenv = allow_from_autoenv

    # --- helpers ---------------------------------------------------------

    def label(self):
        return f"'{self.name}'"

    def kind_word(self):
        return "parameter"

    def get_metavar(self, ctx=None):
        if self.metavar is not None:
            return self.metavar
        return None

    def is_variadic(self):
        return self.nargs == -1

    def _tuple_type(self):
        return isinstance(self.type, Tuple)

    def _per_occurrence_arity(self):
        if self._tuple_type():
            return len(self.type.types)
        return self.nargs if self.nargs is not None else 1

    # --- conversion ------------------------------------------------------

    def _convert_occurrence(self, raw, ctx):
        """Convert one occurrence (a token or a tuple of tokens). # spec: FP-03"""
        if self._tuple_type():
            return self.type(tuple(raw) if not isinstance(raw, str) else (raw,), self, ctx)
        if isinstance(raw, tuple) or (isinstance(raw, list) and self._per_occurrence_arity() != 1):
            return tuple(self.type(item, self, ctx) for item in raw)
        return self.type(raw, self, ctx)

    def _convert_default(self, value, ctx):
        """Convert a declared or default-map value. # spec: FP-03, FP-07"""
        if value is None:
            return None
        if self.multiple:
            if isinstance(value, (str, bytes)) or not isinstance(value, (list, tuple)):
                raise BadParameter(
                    f"{self.label()} needs an iterable (sequence) default.", ctx=ctx, param=self
                )
            return tuple(self._convert_occurrence(v, ctx) for v in value)
        if self._per_occurrence_arity() != 1 and not isinstance(value, (str, bytes)):
            return self._convert_occurrence(tuple(value), ctx)
        return self.type(value, self, ctx)

    def _split_text(self, text):
        return self.type.split_envvar_value(text) if hasattr(self.type, "split_envvar_value") else text.split()

    def _occurrences_from_pieces(self, pieces, ctx):
        """Turn split environment or default-map pieces into the delivered value. # spec: FP-03"""
        if self._tuple_type() or not self.multiple:
            return self._convert_occurrence(tuple(pieces) if self._per_occurrence_arity() != 1 else pieces[0], ctx)
        arity = self._per_occurrence_arity()
        if arity != 1:
            groups = [tuple(pieces[i:i + arity]) for i in range(0, len(pieces), arity)]
            return tuple(self._convert_occurrence(g, ctx) for g in groups)
        return tuple(self._convert_occurrence(p, ctx) for p in pieces)

    def get_default(self, ctx=None):
        """The declared default, called if callable, and converted. # spec: FP-03"""
        value = self.default() if callable(self.default) else self.default
        if value is None and (self.multiple or self.nargs == -1):
            return ()
        if value is None:
            return None
        return self._convert_default(value, ctx)

    def __repr__(self):
        return f"<{self.__class__.__name__} {self.name}>"


class Option(Parameter):
    """A named parameter. # spec: FP-03, N-000868..N-000907"""

    param_type_name = "option"

    def __init__(self, param_decls=None, show_default=None, prompt=False, confirmation_prompt=False,
                 prompt_required=True, hide_input=False, is_flag=None, flag_value=None, count=False,
                 allow_from_autoenv=True, show_envvar=False, show_choices=True, **attrs):
        self.show_default = show_default
        self.prompt = prompt
        self.confirmation_prompt = confirmation_prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.count = count
        self.show_envvar = show_envvar
        self.show_choices = show_choices
        self.flag_value_given = flag_value is not None

        decls = list(param_decls or [])
        primary, secondary, dest = _split_opt_decls(decls)
        attrs.setdefault("allow_from_autoenv", allow_from_autoenv)
        super().__init__(param_decls=decls, **attrs)
        self.opts = primary
        self.secondary_opts = secondary
        self.name = dest or _infer_dest(primary, secondary)
        if self.name is None:
            raise TypeError("Could not determine a name for the option.")

        if is_flag is None:
            is_flag = flag_value is not None or bool(secondary)
        if count:
            is_flag = False
        self.is_flag = bool(is_flag)
        self.flag_value = flag_value
        if self.is_flag:
            if self.flag_value is None:
                self.flag_value = True
            if self.type is STRING or self.type is None:
                self.type = BOOL
            if self.default is None and not self.multiple:
                self.default = False
        if count:
            self.type = INT
            if self.default is None:
                self.default = 0
        self.optional_value = (not self.is_flag) and flag_value is not None and not count

        if self.multiple and self.is_flag:
            raise TypeError("A flag cannot be repeatable.")
        if self.nargs is not None and (not isinstance(self.nargs, int) or self.nargs < 1):
            raise TypeError("nargs must be a positive integer.")
        if self.deprecated and self.required:
            raise TypeError("A deprecated option cannot be required.")
        if self.deprecated and self.prompt:
            raise TypeError("A deprecated option cannot use a prompt.")

        if self._tuple_type():
            self.nargs = len(self.type.types)
        elif self.nargs is None:
            self.nargs = 1

    def label(self):
        return "'" + " / ".join(self.opts + self.secondary_opts) + "'"

    def kind_word(self):
        return "option"

    @property
    def takes_value(self):
        return not self.is_flag and not self.count

    def get_metavar(self, ctx=None):
        if self.metavar is not None:
            return self.metavar
        if self.is_flag or self.count:
            return None
        return self.type.get_metavar(self) or self.type.name.upper()

    def get_default_envvar_names(self, ctx):
        names = []
        if self.envvar:
            names.extend([self.envvar] if isinstance(self.envvar, str) else list(self.envvar))
        if self.allow_from_autoenv and ctx is not None and ctx.auto_envvar_prefix:
            names.append(f"{ctx.auto_envvar_prefix}_{self.name}".upper().replace("-", "_"))
        return names

    # --- value resolution -----------------------------------------------

    def value_from_occurrences(self, occ, ctx):
        """Build the value from command-line occurrences. # spec: FP-03"""
        if self.count:
            return len(occ)
        last = occ[-1]
        if self.is_flag:
            return last
        if last is _BARE:
            return self.flag_value
        if self.multiple:
            return tuple(self._convert_occurrence(r, ctx) for r in occ)
        return self._convert_occurrence(last, ctx)

    def value_from_env(self, ctx):
        """Return (found, value) from the environment. # spec: FP-03, FP-07"""
        for name in self.get_default_envvar_names(ctx):
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            if self.is_flag:
                value = self._flag_from_env(raw, name)
                if value is None:
                    continue
                return True, value
            if self.multiple or self._per_occurrence_arity() != 1:
                pieces = self._split_text(raw)
                return True, self._occurrences_from_pieces(pieces, ctx)
            return True, self._convert_occurrence(raw, ctx)
        return False, None

    def _flag_from_env(self, raw, name):
        text = raw.strip().lower()
        if self.flag_value_given and not isinstance(self.flag_value, bool) and raw == str(self.flag_value):
            return self.flag_value
        if text == "":
            return None
        if text in _TRUE:
            return self.flag_value if self.flag_value is not None else True
        if text in _FALSE:
            return False
        if isinstance(self.flag_value, bool) or self.flag_value is None:
            raise BadParameter(f"{raw!r} is not a valid boolean.", param=self)
        return None

    def prompt_text(self):
        if isinstance(self.prompt, str):
            return self.prompt
        return self.name.replace("_", " ").capitalize()


class Argument(Parameter):
    """A positional parameter. # spec: FP-04, N-000897..N-000899"""

    param_type_name = "argument"

    def __init__(self, param_decls=None, required=None, **attrs):
        decls = list(param_decls or [])
        if len(decls) != 1:
            raise TypeError("An argument takes exactly one destination name.")
        dest = decls[0].replace("-", "_").lower()
        nargs = attrs.pop("nargs", None)
        if nargs is None:
            nargs = 1
        if nargs != -1 and (not isinstance(nargs, int) or nargs < 1):
            raise TypeError("nargs must be a positive integer or -1.")
        if isinstance(attrs.get("type"), Tuple):
            nargs = len(attrs["type"].types)
        if required is None:
            required = (attrs.get("default") is None) and nargs != -1
        super().__init__(param_decls=decls, required=required, nargs=nargs, **attrs)
        self.name = dest
        if self.deprecated and self.required:
            raise TypeError("A deprecated argument cannot be required.")

    def label(self):
        return f"'{self.name}'"

    def kind_word(self):
        return "argument"

    def get_metavar(self, ctx=None):
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()

    def value_from_env(self, ctx):
        for name in self.envvar_names():
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            if self.nargs != 1 or self.multiple:
                pieces = self._split_text(raw)
                return True, tuple(self._convert_occurrence(p, ctx) for p in pieces)
            return True, self._convert_occurrence(raw, ctx)
        return False, None

    def envvar_names(self):
        if not self.envvar:
            return []
        return [self.envvar] if isinstance(self.envvar, str) else list(self.envvar)

    def value_from_occurrences(self, occ, ctx):
        if self.nargs == -1:
            return tuple(self._convert_occurrence(r, ctx) for r in occ[-1])
        return self._convert_occurrence(occ[-1], ctx)


_PREFIX_RE = re.compile(r"^[^A-Za-z0-9_]+")


def _split_opt_decls(decls):
    """Split declarations into (primary flags, secondary flags, destination). # spec: N-000868..N-000870"""
    primary, secondary, dest = [], [], None
    for decl in decls:
        if decl.isidentifier():
            dest = decl
            continue
        if decl and not decl[0].isalnum() and decl[0] != "_" and "/" in decl[1:]:
            first, second = decl.split("/", 1)
            primary.append(first)
            secondary.append(second)
            continue
        if decl and not decl[0].isalnum() and decl[0] != "_":
            primary.append(decl)
            continue
        if decl.isidentifier():
            dest = decl
            continue
        raise TypeError(f"Invalid option declaration {decl!r}.")
    return primary, secondary, dest


def _infer_dest(primary, secondary):
    """Destination from flag names: first long name, otherwise first short name. # spec: FP-03"""
    for names in (primary, secondary):
        for name in names:
            if len(name) > 2 and name[0] == name[1] and name[0] in "-+/":
                return name.lstrip("-+/").replace("-", "_")
    for name in primary:
        return name.lstrip("-+/").replace("-", "_")
    return None


def option_prefixes(opts):
    """Prefix characters used by a set of option names. # spec: N-000870"""
    chars = {"-"}
    for name in opts:
        if name and not name[0].isalnum() and name[0] != "_":
            chars.add(name[0])
    return chars
