"""Stream, styling, and filesystem helpers. # spec: FP-09, FP-11, N-000963..N-000979"""

import io
import os
import re
import sys
import tempfile

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")


def strip_ansi(text):
    """Remove ANSI escape sequences. # spec: N-000969"""
    return _ansi_re.sub("", text)


def is_tty(stream):
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def is_ascii_encoding(stream):
    enc = getattr(stream, "encoding", None) or "ascii"
    try:
        return enc.lower().replace("_", "-") in ("ascii", "us-ascii", "ansi-x3.4-1968")
    except Exception:
        return False


def write_text(stream, text):
    """Write text, falling back to UTF-8 bytes on an ASCII-only stream. # spec: FP-11"""
    if is_ascii_encoding(stream):
        buf = getattr(stream, "buffer", None)
        if buf is not None:
            stream.flush()
            buf.write(text.encode("utf-8"))
            buf.flush()
            return
    try:
        stream.write(text)
    except UnicodeEncodeError:
        stream.write(text.encode("utf-8", "replace").decode("utf-8"))


class _DashStream:
    """Wraps a standard stream so closing the file does not close the process stream."""

    def __init__(self, stream):
        self._stream = stream

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def close(self):
        try:
            self._stream.flush()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def __iter__(self):
        return iter(self._stream)


def _std_stream(mode):
    if "r" in mode:
        stream = sys.stdin
    else:
        stream = sys.stdout
    if "b" in mode:
        return _DashStream(getattr(stream, "buffer", stream))
    return _DashStream(stream)


def open_stream(filename, mode="r", encoding=None, errors="strict", atomic=False, lazy=False):
    """Open a file or a standard stream. Returns (file, should_close). # spec: FP-09"""
    filename = os.fspath(filename) if not isinstance(filename, str) else filename
    if filename == "-":
        return _std_stream(mode), False
    if lazy:
        return LazyFile(filename, mode, encoding, errors, atomic), True
    return _open(filename, mode, encoding, errors, atomic), True


def _open(filename, mode, encoding, errors, atomic):
    if "w" in mode and atomic:
        return AtomicFile(filename, mode, encoding, errors)
    if "b" in mode:
        return open(filename, mode)
    return open(filename, mode, encoding=encoding, errors=errors)


class AtomicFile:
    """Writes to a sibling temp file and replaces the target on close. # spec: FP-09"""

    def __init__(self, filename, mode, encoding, errors):
        self._target = filename
        directory = os.path.dirname(os.path.abspath(filename))
        fd, self._tmp = tempfile.mkstemp(dir=directory, prefix=".__atomic-write")
        os.close(fd)
        if "b" in mode:
            self._f = open(self._tmp, mode)
        else:
            self._f = open(self._tmp, mode, encoding=encoding, errors=errors)
        self.name = filename
        self.mode = mode
        self._closed = False

    def __getattr__(self, name):
        return getattr(self._f, name)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def close(self):
        if self._closed:
            return
        self._closed = True
        self._f.close()
        os.replace(self._tmp, self._target)


class LazyFile:
    """Opens its target on first I/O. # spec: FP-09"""

    def __init__(self, filename, mode, encoding, errors, atomic):
        self.name = filename
        self.mode = mode
        self._args = (filename, mode, encoding, errors, atomic)
        self._f = None
        self._closed = False

    def _ensure(self):
        if self._f is None:
            if self._closed:
                raise ValueError("I/O operation on closed file.")
            try:
                self._f = _open(*self._args)
            except OSError as e:
                from .exceptions import FileError

                raise FileError(self.name, e.strerror or str(e)) from e
        return self._f

    def __getattr__(self, name):
        return getattr(self._ensure(), name)

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def close(self):
        self._closed = True
        if self._f is not None:
            self._f.close()

    def __iter__(self):
        return iter(self._ensure())


def format_filename(filename, shorten=False):
    """Printable form of a filename. # spec: FP-09, N-000...
    """
    if isinstance(filename, bytes):
        text = os.fsdecode(filename)
    else:
        text = os.fspath(filename)
    if shorten:
        text = os.path.basename(text)
    return text.encode("utf-8", "surrogateescape").decode("utf-8", "replace")


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Per-user config directory. # spec: FP-11"""
    if force_posix or sys.platform not in ("darwin", "win32"):
        if force_posix:
            return os.path.join(os.path.expanduser("~"), "." + _unix_folder(app_name))
        config = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
        return os.path.join(config, _unix_folder(app_name))
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~"), "Library", "Application Support", app_name)
    base = os.environ.get("APPDATA") or os.path.expanduser("~")
    return os.path.join(base, app_name)


def _unix_folder(app_name):
    return re.sub(r"\s+", "-", app_name.lower())
