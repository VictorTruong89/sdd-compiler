"""Parameter types. # spec: N-000923..N-000931, FP-05, FP-09"""

import datetime as _dt
import enum
import os
import pathlib
import sys
import uuid as _uuid

from .exceptions import BadParameter


class ParamType:
    """Base class for parameter types. # spec: N-000923..N-000931"""

    name = "text"
    envvar_list_splitter = None

    def __call__(self, value, param=None, ctx=None):
        if value is not None:
            return self.convert(value, param, ctx)
        return None

    def convert(self, value, param=None, ctx=None):
        return value

    def get_metavar(self, param=None):
        return None

    def get_missing_message(self, param=None):
        return None

    def split_envvar_value(self, rv):
        if self.envvar_list_splitter is not None:
            return rv.split(self.envvar_list_splitter)
        return rv.split()

    def shell_complete(self, ctx, param, incomplete):
        return []

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self):
        return self.name.upper()


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class _IntParamType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 0 if str(value).strip()[:2].lower() in ("0x", "0o", "0b") else 10)
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class _FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


class _BoolParamType(ParamType):
    name = "boolean"

    _true = {"1", "true", "t", "yes", "y", "on"}
    _false = {"0", "false", "f", "no", "n", "off"}

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in self._true:
            return True
        if text in self._false:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class _UuidParamType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _uuid.UUID):
            return value
        try:
            return _uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


STRING = _StringType()
INT = _IntParamType()
FLOAT = _FloatParamType()
BOOL = _BoolParamType()
UUID = _UuidParamType()
UNPROCESSED = _UnprocessedType()


class Choice(ParamType):
    """Closed list of choices. # spec: N-000923..N-000931, FP-05"""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._enum = choices
        else:
            self.choices = list(choices)
            self._enum = None
        self.case_sensitive = case_sensitive

    def _token(self, choice):
        if isinstance(choice, enum.Enum):
            token = choice.name
        else:
            token = str(choice)
        return token if self.case_sensitive else token.casefold()

    def _normalize(self, value):
        return str(value) if self.case_sensitive else str(value).casefold()

    def get_metavar(self, param=None):
        return "[" + "|".join(str(self._token_raw(c)) for c in self.choices) + "]"

    def _token_raw(self, choice):
        return choice.name if isinstance(choice, enum.Enum) else choice

    def convert(self, value, param=None, ctx=None):
        normed = str(value) if self.case_sensitive else str(value).casefold()
        for choice in self.choices:
            if self._token(choice) == normed:
                return choice
        if isinstance(value, enum.Enum) and value in self.choices:
            return value
        choices_str = ", ".join(repr(self._token_raw(c)) for c in self.choices)
        self.fail(f"{value!r} is not one of {choices_str}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        results = []
        for choice in self.choices:
            token = str(self._token_raw(choice))
            cmp_token = token if self.case_sensitive else token.casefold()
            cmp_inc = incomplete if self.case_sensitive else incomplete.casefold()
            if cmp_token.startswith(cmp_inc):
                results.append(token)
        return results

    def __repr__(self):
        return f"Choice({list(self.choices)})"


_DEFAULT_DATETIME_FORMATS = [
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
]


class DateTime(ParamType):
    """Date-time parsing. # spec: N-000923..N-000931, FP-05"""

    name = "datetime"

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(_DEFAULT_DATETIME_FORMATS)

    def get_metavar(self, param=None):
        return "[" + "|".join(self.formats) + "]"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value).strip(), fmt)
            except ValueError:
                continue
        formats_str = ", ".join(repr(f) for f in self.formats)
        self.fail(f"{value!r} does not match the formats {formats_str}.", param, ctx)


class _NumberRange(ParamType):
    _base = None
    _type_name = "number"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp
        self._check_bounds()

    def _check_bounds(self):
        if self.min is not None and self.max is not None and self.min > self.max:
            raise ValueError("min bound must not be greater than max bound.")

    def _range_text(self):
        lo = ""
        hi = ""
        if self.min is not None:
            lo = f"{'>' if self.min_open else '>='} {self.min}"
        if self.max is not None:
            hi = f"{'<' if self.max_open else '<='} {self.max}"
        return " and ".join(x for x in (lo, hi) if x)

    def get_metavar(self, param=None):
        return self._type_name.upper()

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            value = int(value)
        try:
            rv = self._base(value)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid {self._type_name}.", param, ctx)
        if self.min is not None:
            if rv < self.min or (self.min_open and rv == self.min):
                if self.clamp:
                    return self._clamp_low()
                self.fail(f"{rv} is not in the range {self._range_text()}.", param, ctx)
        if self.max is not None:
            if rv > self.max or (self.max_open and rv == self.max):
                if self.clamp:
                    return self._clamp_high()
                self.fail(f"{rv} is not in the range {self._range_text()}.", param, ctx)
        return rv

    def _clamp_low(self):
        return self.min

    def _clamp_high(self):
        return self.max


class IntRange(_NumberRange):
    """Integer range. # spec: N-000923..N-000931, FP-05"""

    name = "integer range"
    _base = staticmethod(lambda v: int(v))
    _type_name = "integer"

    def _check_bounds(self):
        super()._check_bounds()

    def _clamp_low(self):
        return self.min + 1 if self.min_open else self.min

    def _clamp_high(self):
        return self.max - 1 if self.max_open else self.max


class FloatRange(_NumberRange):
    """Float range. # spec: N-000923..N-000931, FP-05"""

    name = "float range"
    _base = staticmethod(lambda v: float(v))
    _type_name = "float"

    def _check_bounds(self):
        super()._check_bounds()
        if self.clamp and (self.min_open or self.max_open):
            raise ValueError("Clamping is not supported for open bounds.")


class Tuple(ParamType):
    """Fixed-length tuple of types. # spec: N-000923..N-000931, FP-03"""

    name = "tuple"

    def __init__(self, types):
        self.types = [convert_type(t) for t in types]

    def get_metavar(self, param=None):
        return " ".join(t.name.upper() for t in self.types)

    def convert(self, value, param=None, ctx=None):
        if len(value) != len(self.types):
            self.fail(f"{len(value)} values are required, but {len(self.types)} were given.", param, ctx)
        return tuple(t(v, param, ctx) for t, v in zip(self.types, value))


class File(ParamType):
    """Open file type. # spec: N-000923..N-000931, FP-09"""

    name = "filename"
    envvar_list_splitter = os.path.pathsep

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"Unsupported file mode {mode!r}.")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def _is_lazy(self):
        if self.lazy is None:
            return "w" in self.mode
        return self.lazy

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        from .utils import open_stream

        lazy = self._is_lazy()
        try:
            f, should_close = open_stream(
                value,
                self.mode,
                self.encoding,
                self.errors,
                atomic=self.atomic,
                lazy=lazy,
            )
        except OSError as e:
            self.fail(f"'{value}': {e.strerror or e}", param, ctx)
        if ctx is not None and should_close:
            ctx.call_on_close(f.close)
        return f


class Path(ParamType):
    """Path type. # spec: N-000923..N-000931, FP-09"""

    name = "path"
    envvar_list_splitter = os.path.pathsep

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param=None, ctx=None):
        rv = value
        is_dash = self.allow_dash and rv in (b"-", "-")
        if not is_dash:
            if self.resolve_path:
                rv = os.path.realpath(rv)
            try:
                st = os.stat(rv)
            except OSError:
                if not self.exists:
                    return self._coerce(rv)
                self.fail(f"{value!r} does not exist.", param, ctx)
            if not self.file_okay and not os.path.isdir(rv):
                self.fail(f"{value!r} is a file.", param, ctx)
            if not self.dir_okay and os.path.isdir(rv):
                self.fail(f"{value!r} is a directory.", param, ctx)
            if self.readable and not os.access(rv, os.R_OK):
                self.fail(f"{value!r} is not readable.", param, ctx)
            if self.writable and not os.access(rv, os.W_OK):
                self.fail(f"{value!r} is not writable.", param, ctx)
            if self.executable and not os.access(rv, os.X_OK):
                self.fail(f"{value!r} is not executable.", param, ctx)
            del st
        return self._coerce(rv)

    def _coerce(self, rv):
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        if self.path_type is None or self.path_type is str:
            return rv if isinstance(rv, str) else os.fsdecode(rv)
        return self.path_type(rv)


def convert_type(ty, default=None):
    """Turn a type spec into a ParamType. # spec: N-000872, FP-05"""
    if isinstance(ty, ParamType):
        return ty
    if isinstance(ty, (tuple, list)):
        return Tuple(ty)
    if ty is None and default is not None:
        if isinstance(default, (tuple, list)):
            return _guess_from_value(default[0] if default else None)
        return _guess_from_value(default)
    if ty is None:
        return STRING
    if ty is str:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if ty is _uuid.UUID:
        return UUID
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    if callable(ty):
        return _FuncType(ty)
    raise TypeError(f"Unknown type {ty!r}.")


def _guess_from_value(value):
    if isinstance(value, bool):
        return BOOL
    if isinstance(value, int):
        return INT
    if isinstance(value, float):
        return FLOAT
    if isinstance(value, _uuid.UUID):
        return UUID
    return STRING


class _FuncType(ParamType):
    """Adapter for a plain conversion function. # spec: FP-05"""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text") or "text"

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except ValueError:
            self.fail(f"{value!r} is not a valid value.", param, ctx)
        except BadParameter:
            raise
