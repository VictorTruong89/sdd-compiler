"""Invocation context. # spec: FP-07, N-000932..N-000962, N-000061..N-000063"""

import enum
import shutil
import threading

from .exceptions import Abort, Exit

_local = threading.local()


class ParameterSource(enum.Enum):
    """Where a parameter's value came from. # spec: FP-07"""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


class _ChainSubcommand:
    """Marker for invoked_subcommand on a chaining group. # spec: N-000950"""

    def __repr__(self):
        return "<chain subcommands>"


CHAIN_SUBCOMMAND = _ChainSubcommand()

_INHERITED = (
    "terminal_width",
    "max_content_width",
    "help_option_names",
    "token_normalize_func",
    "color",
    "show_default",
)


def _stack():
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def get_current_context(silent=False):
    """Return the context current on this thread. # spec: N-000960..N-000962"""
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active Optlyn context.")


class Context:
    """One per invocation. # spec: N-000932..N-000956"""

    def __init__(
        self,
        command,
        parent=None,
        info_name=None,
        obj=None,
        auto_envvar_prefix=None,
        default_map=None,
        terminal_width=None,
        max_content_width=None,
        help_option_names=None,
        token_normalize_func=None,
        color=None,
        show_default=None,
        allow_extra_args=None,
        allow_interspersed_args=None,
        ignore_unknown_options=None,
        **extra,
    ):
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.auto_envvar_prefix = auto_envvar_prefix
        self.default_map = default_map
        self.terminal_width = terminal_width
        self.max_content_width = max_content_width
        self.help_option_names = help_option_names
        self.token_normalize_func = token_normalize_func
        self.color = color
        self.show_default = show_default
        self.allow_extra_args = allow_extra_args
        self.allow_interspersed_args = allow_interspersed_args
        self.ignore_unknown_options = ignore_unknown_options
        self.extra = extra
        if parent is not None:
            for key in _INHERITED:
                if getattr(self, key) is None:
                    setattr(self, key, getattr(parent, key))
        if self.max_content_width is None:
            self.max_content_width = 80
        if self.help_option_names is None:
            self.help_option_names = ["--help"]
        if self.show_default is None:
            self.show_default = False
        self.params = {}
        self.args = []
        self.protected_args = []
        self.invoked_subcommand = None
        self.resilient_parsing = False
        self._sources = {}
        self._close_callbacks = []
        self._all_params = []
        self._parser = None
        self.chained = False
        if parent is not None:
            # Resources of a child stay open until the invocation ends. # spec: FP-07
            parent._close_callbacks.append(self.close)

    # --- structure -------------------------------------------------------

    @property
    def command_path(self):
        names = []
        node = self
        while node is not None:
            if node.info_name:
                names.append(node.info_name)
            node = node.parent
        return " ".join(reversed(names))

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    def get_usage(self):
        return self.command.get_usage(self)

    def get_help(self):
        return self.command.get_help(self)

    def get_parameter_source(self, name):
        """Which source supplied a parameter; None when not declared. # spec: FP-07"""
        if name not in self._sources:
            return None
        return self._sources[name]

    def lookup_default(self, name, call=True):
        if self.default_map is None or name not in self.default_map:
            return None
        value = self.default_map[name]
        return value() if call and callable(value) else value

    # --- resources ------------------------------------------------------

    def call_on_close(self, f):
        self._close_callbacks.append(f)
        return f

    def with_resource(self, cm):
        value = cm.__enter__()
        self.call_on_close(lambda: cm.__exit__(None, None, None))
        return value

    def close(self):
        while self._close_callbacks:
            f = self._close_callbacks.pop()
            f()

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    # --- invocation -----------------------------------------------------

    def invoke(self, other_cmd, **kwargs):
        """Run another command, or call a callback, with explicit values. # spec: FP-07"""
        from .core import Command

        if isinstance(other_cmd, Command):
            ctx = Context(other_cmd, info_name=other_cmd.name, parent=self)
            for param in other_cmd.get_params(ctx):
                if param.name not in kwargs and param.expose_value:
                    kwargs[param.name] = param.get_default(ctx)
            with ctx:
                return other_cmd.callback(**kwargs) if other_cmd.callback else None
        with self:
            return other_cmd(**kwargs)

    def forward(self, cmd, **kwargs):
        merged = dict(self.params)
        merged.update(kwargs)
        return self.invoke(cmd, **merged)

    # --- context manager ------------------------------------------------

    def __enter__(self):
        _stack().append(self)
        return self

    def __exit__(self, exc_type, exc_value, tb):
        stack = _stack()
        if stack and stack[-1] is self:
            stack.pop()
        return False
