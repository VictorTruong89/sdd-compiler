"""Declaration decorators. # spec: FP-01, FP-02, FP-03, FP-04, FP-07, FP-08, N-000834..N-000922"""

import inspect
import sys
from functools import update_wrapper
from importlib import metadata

from .context import get_current_context
from .core import Command, CommandCollection, Group, _derive_name, _help_callback
from .parameters import Argument, Option
from .termui import confirm, echo


def _param_memo(f, param):
    if isinstance(f, Command):
        f.params.append(param)
        return
    params = f.__dict__.setdefault("__optlyn_params__", [])
    params.append(param)


def _pop_params(f):
    """Move declarations attached to f onto a new command. Declarations apply in source order. # spec: FP-01"""
    params = f.__dict__.pop("__optlyn_params__", [])
    return list(reversed(params))


def command(name=None, cls=None, **attrs):
    """Declare a leaf command. # spec: N-000834..N-000841"""
    if callable(name) and not isinstance(name, str):
        return command()(name)
    if cls is None:
        cls = Command

    def decorator(f):
        params = _pop_params(f)
        cmd_name = name if name is not None else _derive_name(f)
        attrs.setdefault("help", inspect.getdoc(f))
        return cls(name=cmd_name, callback=f, params=params, **attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Declare a group. # spec: N-000850..N-000852"""
    if callable(name) and not isinstance(name, str):
        return group()(name)
    if cls is None:
        cls = Group

    def decorator(f):
        params = _pop_params(f)
        grp_name = name if name is not None else _derive_name(f)
        attrs.setdefault("help", inspect.getdoc(f))
        return cls(name=grp_name, callback=f, params=params, **attrs)

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option. # spec: N-000868..N-000896"""
    if cls is None:
        cls = Option

    def decorator(f):
        _param_memo(f, cls(list(param_decls), **attrs))
        return f

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach an argument. # spec: N-000897..N-000899"""
    if cls is None:
        cls = Argument

    def decorator(f):
        _param_memo(f, cls(list(param_decls), **attrs))
        return f

    return decorator


def help_option(*param_decls, **kwargs):
    """Attach an extra eager help flag. # spec: N-000911, N-000916"""
    decls = list(param_decls) or ["--help"]
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _help_callback)
    return option(*decls, **kwargs)


def _caller_package(depth=2):
    frame = sys._getframe(depth)
    module = frame.f_globals.get("__name__", "__main__")
    return module.partition(".")[0]


def _detect_version(package_name):
    """Version of an installed distribution, or of the one providing an import name. # spec: FP-02"""
    try:
        return metadata.version(package_name)
    except metadata.PackageNotFoundError:
        pass
    for dist in metadata.packages_distributions().get(package_name, []):
        try:
            return metadata.version(dist)
        except metadata.PackageNotFoundError:
            continue
    raise RuntimeError(f"{package_name!r} is not an installed distribution.")


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """Attach the ready-made eager version flag. # spec: N-000911, N-000917, N-000918"""
    decls = list(param_decls) or ["--version"]
    if version is None and package_name is None:
        package_name = _caller_package(2)

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        ver = version if version is not None else _detect_version(package_name)
        prog = prog_name or ctx.find_root().info_name
        text = (message or "%(prog)s, version %(version)s") % {
            "prog": prog,
            "package": package_name,
            "version": ver,
        }
        echo(text, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*decls, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    """Eager version flag whose whole identity is the callback's string. # spec: N-000919"""
    decls = list(param_decls) or ["--version"]

    def print_version(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=True)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = print_version
    return option(*decls, **kwargs)


def password_option(*param_decls, **kwargs):
    """Prompting, hidden, confirmed option. # spec: N-000912, FP-08"""
    decls = list(param_decls) or ["--password"]
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("help", "Password.")
    return option(*decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    """Yes flag that asks when omitted and aborts when declined. # spec: N-000915, FP-08"""
    decls = list(param_decls) or ["--yes"]
    question = kwargs.pop("prompt", None) or "Do you want to continue?"

    def callback(ctx, param, value):
        if not value and not ctx.resilient_parsing:
            confirm(question, default=False, abort=True)
        return value

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs["callback"] = callback
    return option(*decls, **kwargs)


def pass_context(f):
    """Pass the current context as the first argument. # spec: N-000957"""

    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    return update_wrapper(new_func, f)


def pass_obj(f):
    """Pass the current context's object as the first argument. # spec: N-000958"""

    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    return update_wrapper(new_func, f)


def make_pass_decorator(object_type, ensure=False):
    """Pass the nearest object of a type. # spec: N-000959"""

    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(f"Managed to invoke callback without a context object of type {object_type.__name__!r} existing.")
            return f(obj, *args, **kwargs)

        return update_wrapper(new_func, f)

    return decorator
