"""Behavioural checks for the core Optlyn surface. Run with PYTHONPATH=src."""

import os

import optlyn as o
from optlyn.testing import CliRunner


def _runner():
    return CliRunner()


def test_command_name_derivation_strips_suffix():
    @o.command()
    def hello_world_cmd():
        pass

    assert hello_world_cmd.name == "hello-world"


def test_option_and_argument_are_delivered():
    @o.command()
    @o.option("--count", "-c", default=1, type=int)
    @o.option("--shout/--no-shout", default=False)
    @o.argument("name", required=False)
    def hello(count, shout, name):
        o.echo(f"{count}|{shout}|{name}")

    res = _runner().invoke(hello, ["-c", "2", "--shout", "Bob"])
    assert res.exit_code == 0
    assert res.output == "2|True|Bob\n"


def test_help_exits_zero_and_does_not_run_callback():
    ran = []

    @o.command()
    def cmd():
        """Say hi."""
        ran.append(True)

    res = _runner().invoke(cmd, ["--help"])
    assert res.exit_code == 0
    assert "Usage: cmd" in res.output
    assert ran == []


def test_unknown_option_is_usage_error():
    @o.command()
    def cmd():
        pass

    res = _runner().invoke(cmd, ["--bogus"])
    assert res.exit_code == 2
    assert "No such option" in res.output


def test_group_without_subcommand_is_usage_error_with_help():
    @o.group()
    def grp():
        pass

    res = _runner().invoke(grp, [])
    assert res.exit_code == 2
    assert "Usage: grp" in res.output


def test_group_callback_runs_before_child():
    order = []

    @o.group()
    def grp():
        order.append("group")

    @grp.command()
    def child():
        order.append("child")

    res = _runner().invoke(grp, ["child"])
    assert res.exit_code == 0
    assert order == ["group", "child"]


def test_choice_delivers_original_member():
    import enum

    class Color(enum.Enum):
        RED = 1

    @o.command()
    @o.argument("c", type=o.Choice(Color))
    def cmd(c):
        o.echo(repr(c))

    res = _runner().invoke(cmd, ["RED"])
    assert res.output == "<Color.RED: 1>\n"


def test_env_prefix_and_default_map():
    @o.command(context_settings={"auto_envvar_prefix": "APP"})
    @o.option("--level", type=int, default=0)
    def cmd(level):
        o.echo(level)

    assert _runner().invoke(cmd, [], env={"APP_LEVEL": "4"}).output == "4\n"
    assert _runner().invoke(cmd, [], default_map={"level": 9}).output == "9\n"


def test_prompt_reads_input_and_echoes_when_not_terminal():
    @o.command()
    @o.option("--name", prompt=True)
    def cmd(name):
        o.echo(f"hi {name}")

    res = _runner().invoke(cmd, [], input="Joe\n")
    assert res.exit_code == 0
    assert res.output.endswith("hi Joe\n")


def test_abort_exit_status_is_one():
    @o.command()
    def cmd():
        raise o.Abort()

    res = _runner().invoke(cmd, [])
    assert res.exit_code == 1
    assert "Aborted!" in res.output


def test_stacked_short_flags_and_double_dash():
    @o.command()
    @o.option("-v", count=True)
    @o.option("-a", is_flag=True)
    @o.argument("rest", nargs=-1)
    def cmd(v, a, rest):
        o.echo(f"{v}|{a}|{rest}")

    res = _runner().invoke(cmd, ["-vva", "--", "-x"])
    assert res.output == "2|True|('-x',)\n"


def test_chaining_group_returns_results():
    @o.group(chain=True)
    def ch():
        pass

    @ch.result_callback()
    def done(results):
        o.echo(f"results={results}")

    @ch.command()
    @o.argument("n", type=int)
    def double(n):
        return n * 2

    res = _runner().invoke(ch, ["double", "3", "double", "4"])
    assert res.output == "results=[6, 8]\n"


def test_custom_version_prints_exact_string():
    @o.command()
    @o.custom_version_option(lambda ctx: "custom 2.0")
    def cmd():
        pass

    assert _runner().invoke(cmd, ["--version"]).output == "custom 2.0\n"


def test_isolated_filesystem_is_entered_and_left():
    cwd = os.getcwd()
    with _runner().isolated_filesystem() as path:
        assert os.getcwd() == os.path.realpath(path) or os.getcwd() == path
    assert os.getcwd() == cwd


def test_echo_strips_styles_when_not_terminal():
    @o.command()
    def cmd():
        o.echo(o.style("plain", fg="red"))

    assert _runner().invoke(cmd, []).output == "plain\n"


def test_shell_completion_lists_subcommands():
    @o.group()
    def tool():
        pass

    @tool.command()
    def run():
        pass

    @tool.command(hidden=True)
    def secret():
        pass

    from optlyn.shell_completion import suggestions

    values = [i["value"] for i in suggestions(tool, "tool", [], "")]
    assert "run" in values
    assert "secret" not in values
