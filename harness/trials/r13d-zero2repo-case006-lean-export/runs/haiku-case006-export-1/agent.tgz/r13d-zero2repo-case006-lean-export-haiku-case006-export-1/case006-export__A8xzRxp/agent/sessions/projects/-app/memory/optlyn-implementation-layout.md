---
name: optlyn-implementation-layout
description: "Where the Optlyn library lives in /app, how its modules divide, and what is verified. Read before editing /app/src/optlyn."
metadata:
  node_type: memory
  type: project
  originSessionId: 29701fb0-9a56-4369-8cce-e40973b62932
  modified: 2026-10-16T12:03:26.431Z
---

Optlyn (a composable CLI library, Click-shaped API) is implemented under `/app/src/optlyn`, with tests in `/app/tests/test_optlyn_basics.py` (16 pass, run with `PYTHONPATH=src`).

Module split: `exceptions.py` (exit classes), `types.py` (ParamType and built-ins), `parameters.py` (Option/Argument declaration), `parser.py` (token parsing and value resolution), `context.py` (Context, thread-local current context), `core.py` (Command/Group/CommandCollection, main, help), `decorators.py`, `termui.py`, `utils.py`, `formatting.py`, `testing.py` (CliRunner), `shell_completion.py`.

**Why:** the spec in `/app/spec` has 1012 checklist ids with no acceptance-criteria labels, and the checklist must stay untouched. Ids are referenced only as `# spec:` comments, so there is no per-id tick-off.

**How to apply:** when changing behaviour, check the matching FP pack in `spec/packs/` first. Known thin spots: pager stream chunking, progress bar styling, path-completion script bodies, and `Context.params` during shell completion (not parsed).
