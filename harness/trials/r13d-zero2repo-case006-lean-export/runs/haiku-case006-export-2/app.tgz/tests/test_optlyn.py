import pytest

import optlyn
from optlyn import (
    Choice,
    IntRange,
    argument,
    command,
    confirmation_option,
    custom_version_option,
    group,
    option,
    password_option,
    style,
    unstyle,
)
from optlyn.testing import CliRunner


@command()
@option("--count", "-c", type=int, default=1)
@option("--tag", multiple=True)
@option("--pair", nargs=2, type=int)
@option("--verbose", "-v", is_flag=True)
@argument("name")
def greet(count, tag, pair, verbose, name):
    """Greet NAME."""
    optlyn.echo(f"{name} {count} {tag} {pair} {verbose}")


@group()
@option("--debug/--no-debug", default=False)
def cli(debug):
    """Top level."""
    optlyn.echo(f"debug={debug}")


@cli.command("say")
@argument("word", required=False, default="hi")
def say(word):
    optlyn.echo(word)


cli.add_command(greet)


def test_leaf_options_and_arguments():
    res = CliRunner().invoke(greet, ["-c", "3", "--tag", "a", "--tag", "b", "--pair", "1", "2", "-v", "bob"])
    assert res.exit_code == 0, res.output
    assert res.output == "bob 3 ('a', 'b') (1, 2) True\n"


def test_short_stack_and_equals_form():
    res = CliRunner().invoke(greet, ["-vc5", "--count=7", "x"])
    assert res.exit_code == 0, res.output
    assert res.output == "x 7 () None True\n"


def test_group_dispatch_runs_group_callback_first():
    res = CliRunner().invoke(cli, ["--debug", "say", "yo"], prog_name="t")
    assert res.exit_code == 0, res.output
    assert res.output == "debug=True\nyo\n"


def test_optional_argument_default():
    res = CliRunner().invoke(cli, ["--no-debug", "say"])
    assert res.output == "debug=False\nhi\n"


def test_help_exits_zero_and_skips_callback():
    res = CliRunner().invoke(greet, ["--help"], prog_name="t")
    assert res.exit_code == 0
    assert "Greet NAME." in res.output
    assert "Usage: t [OPTIONS]" in res.output


def test_missing_required_argument_is_usage_error():
    res = CliRunner().invoke(greet, [], prog_name="t")
    assert res.exit_code == 2
    assert "NAME" in res.output


def test_unknown_option_is_usage_error():
    res = CliRunner().invoke(greet, ["--nope", "x"])
    assert res.exit_code == 2


def test_no_such_subcommand():
    res = CliRunner().invoke(cli, ["zzz"])
    assert res.exit_code == 2


def test_missing_subcommand_is_usage_error_with_help():
    res = CliRunner().invoke(cli, [], prog_name="t")
    assert res.exit_code == 2


def test_envvar_and_default_map():
    @command()
    @option("--level", type=int, envvar="LVL_TEST", default=0)
    @option("--name", default="n")
    def tool(level, name):
        optlyn.echo(f"{level} {name}")

    res = CliRunner().invoke(tool, [], env={"LVL_TEST": "4"})
    assert res.output == "4 n\n"
    res = CliRunner().invoke(tool, [], default_map={"level": 9, "name": "dm"})
    assert res.output == "9 dm\n"
    res = CliRunner().invoke(tool, ["--level", "1"], env={"LVL_TEST": "4"})
    assert res.output == "1 n\n"


def test_auto_envvar_prefix():
    @command()
    @option("--port", type=int, default=1)
    def serve(port):
        optlyn.echo(str(port))

    res = CliRunner().invoke(serve, [], auto_envvar_prefix="MYAPP", env={"MYAPP_PORT": "8080"})
    assert res.output == "8080\n"


def test_choice_and_range_errors():
    @command()
    @option("--mode", type=Choice(["fast", "slow"], case_sensitive=False))
    @option("--n", type=IntRange(1, 5))
    def run(mode, n):
        optlyn.echo(f"{mode} {n}")

    res = CliRunner().invoke(run, ["--mode", "FAST", "--n", "3"])
    assert res.output == "fast 3\n"
    res = CliRunner().invoke(run, ["--n", "9"])
    assert res.exit_code == 2


def test_required_option_missing():
    @command()
    @option("--key", required=True)
    def k(key):
        pass

    res = CliRunner().invoke(k, [])
    assert res.exit_code == 2
    assert "--key" in res.output


def test_prompt_reads_input_and_echoes():
    @command()
    @option("--name", prompt="Name")
    def p(name):
        optlyn.echo(f"got {name}")

    res = CliRunner().invoke(p, [], input="ann\n")
    assert res.exit_code == 0, res.output
    assert "got ann" in res.output


def test_confirmation_option_declined_aborts():
    ran = []

    @command()
    @confirmation_option("--yes")
    def drop():
        ran.append(1)

    res = CliRunner().invoke(drop, [], input="n\n")
    assert res.exit_code == 1
    assert ran == []
    res = CliRunner().invoke(drop, ["--yes"])
    assert res.exit_code == 0
    assert ran == [1]


def test_password_option_confirms():
    @command()
    @password_option()
    def pw(password):
        optlyn.echo(f"pw={password}")

    res = CliRunner().invoke(pw, [], input="s3\ns3\n")
    assert res.exit_code == 0, res.output
    assert "pw=s3" in res.output
    assert "s3\n" not in res.stdout.replace("pw=s3", "")


def test_custom_version_option():
    @command()
    @custom_version_option(lambda ctx: "v9.9")
    def v():
        pass

    res = CliRunner().invoke(v, ["--version"])
    assert res.exit_code == 0
    assert res.output == "v9.9\n"


def test_chain_group_and_result_callback():
    @group(chain=True)
    def pipe():
        pass

    @pipe.result_callback()
    def done(results):
        optlyn.echo(f"results={results}")

    @pipe.command()
    def a():
        return 1

    @pipe.command()
    def b():
        return 2

    res = CliRunner().invoke(pipe, ["a", "b"])
    assert res.output == "results=[1, 2]\n"


def test_chaining_group_refuses_nested_group():
    @group(chain=True)
    def pipe():
        pass

    with pytest.raises(TypeError):
        pipe.add_command(group()(lambda: None))


def test_standalone_off_returns_value():
    @command()
    def f():
        return 42

    assert f.main([], standalone_mode=False) == 42


def test_deprecated_command_still_runs():
    @command(deprecated="use other")
    def old():
        optlyn.echo("ran")

    res = CliRunner().invoke(old, [])
    assert res.exit_code == 0
    assert "ran" in res.output
    assert "deprecated" in res.output


def test_help_option_names_from_context():
    res = CliRunner().invoke(greet, ["-h"], help_option_names=["-h"])
    assert res.exit_code == 0
    assert "Greet NAME." in res.output


def test_styles_stripped_when_not_tty():
    @command()
    def s():
        optlyn.echo(style("hi", fg="red", bold=True))

    res = CliRunner().invoke(s, [])
    assert res.output == "hi\n"
    assert unstyle(style("x", fg="green")) == "x"


def test_invalid_color_raises():
    with pytest.raises(TypeError):
        style("x", fg="nope")


def test_path_and_file_types(tmp_path):
    @command()
    @argument("src", type=optlyn.Path(exists=True))
    @option("--out", type=optlyn.File("w"), default="-")
    def cp(src, out):
        out.write(f"{src}\n")

    runner = CliRunner()
    with runner.isolated_filesystem():
        with open("in.txt", "w") as f:
            f.write("x")
        res = runner.invoke(cp, ["in.txt", "--out", "out.txt"])
        assert res.exit_code == 0, res.output
        with open("out.txt") as f:
            assert f.read() == "in.txt\n"
        res = runner.invoke(cp, ["missing.txt"])
        assert res.exit_code == 2


def test_bash_source_script_and_complete():
    from optlyn.completion import suggest

    res = CliRunner().invoke(greet, [], env={"_T_COMPLETE": "bash_source"}, prog_name="t")
    assert "complete" in res.output
    items = suggest(cli, ["say"], "")
    assert items == []
    names = [i.value for i in suggest(cli, [], "s")]
    assert names == ["say"]
    opts = [i.value for i in suggest(greet, [], "--c")]
    assert "--count" in opts
