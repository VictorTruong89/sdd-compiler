"""File, stream, and filesystem helpers."""

import io
import os
import sys
import tempfile
import contextlib


class LazyFile:
    """A file that opens on first I/O (lazy write mode)."""

    def __init__(self, filename, mode, encoding=None, errors="strict", atomic=False):
        self.name = filename
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.atomic = atomic
        self._f = None
        self._tmp = None

    def _open(self):
        if self._f is not None:
            return self._f
        try:
            if self.atomic:
                d = os.path.dirname(os.path.abspath(self.name))
                fd, self._tmp = tempfile.mkstemp(dir=d, prefix=".optlyn-")
                os.close(fd)
                target = self._tmp
            else:
                target = self.name
            if "b" in self.mode:
                self._f = open(target, self.mode)
            else:
                self._f = open(target, self.mode, encoding=self.encoding, errors=self.errors)
        except OSError as e:
            raise OpenError(self.name, e) from e
        return self._f

    def write(self, data):
        return self._open().write(data)

    def read(self, *args):
        return self._open().read(*args)

    def flush(self):
        if self._f is not None:
            self._f.flush()

    def close(self):
        if self._f is not None:
            self._f.close()
            if self._tmp is not None:
                os.replace(self._tmp, self.name)
                self._tmp = None
            self._f = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


class OpenError(OSError):
    """A file failed to open at first I/O (general error class)."""

    def __init__(self, filename, cause):
        super().__init__(str(cause))
        self.filename = filename
        self.cause = cause


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open a file, or a standard stream for '-'."""
    if filename == "-":
        if "w" in mode:
            stream = sys.stdout.buffer if "b" in mode else sys.stdout
        else:
            stream = sys.stdin.buffer if "b" in mode else sys.stdin
        return _NoCloseWrapper(stream)
    if "w" in mode and (lazy or atomic):
        f = LazyFile(filename, mode, encoding, errors, atomic)
        if not lazy:
            f._open()
        return f
    return _open_now(filename, mode, encoding, errors, atomic)


def _open_now(filename, mode, encoding, errors, atomic):
    try:
        if "b" in mode:
            return open(filename, mode)
        return open(filename, mode, encoding=encoding, errors=errors)
    except OSError as e:
        raise OpenError(filename, e) from e


class _NoCloseWrapper(io.IOBase):
    """Wrap a standard stream so that closing the wrapper leaves it open."""

    def __init__(self, stream):
        self._s = stream

    def __getattr__(self, name):
        return getattr(self._s, name)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def format_filename(filename, shorten=False):
    if isinstance(filename, bytes):
        filename = filename.decode("utf-8", "replace")
    else:
        filename = os.fspath(filename)
    if shorten:
        filename = os.path.basename(filename)
    return filename.encode("utf-8", "surrogateescape").decode("utf-8", "replace")


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Per-user config directory for ``app_name`` (FP-11)."""
    home = os.path.expanduser("~")
    unix_name = "-".join(app_name.lower().split())
    if force_posix:
        return os.path.join(home, "." + unix_name)
    if sys.platform == "darwin":
        return os.path.join(home, "Library", "Application Support", app_name)
    if sys.platform == "win32":
        base = os.environ.get("APPDATA") or home
        return os.path.join(base, app_name)
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.join(home, ".config")
    return os.path.join(base, unix_name)


@contextlib.contextmanager
def _chdir(path):
    old = os.getcwd()
    os.chdir(path)
    try:
        yield path
    finally:
        os.chdir(old)
