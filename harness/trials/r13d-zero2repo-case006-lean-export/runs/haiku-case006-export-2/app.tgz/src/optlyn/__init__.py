"""Optlyn: composable command line interfaces.

Public names are listed in spec/packs/05 (Interface Contract section 1).
"""

from .context import Context, get_current_context, make_pass_decorator, pass_context, pass_obj
from .core import Command, CommandCollection, Group
from .decorators import (
    argument,
    command,
    confirmation_option,
    custom_version_option,
    group,
    help_option,
    option,
    password_option,
    version_option,
)
from .exceptions import Exit
from .params import Argument, Option, Parameter
from .termui import (
    clear,
    confirm,
    echo,
    echo_via_pager,
    edit,
    format_filename,
    get_app_dir,
    get_pager_file,
    getchar,
    launch,
    pause,
    progressbar,
    prompt,
    secho,
    style,
    unstyle,
)
from .types import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Abort,
    BadParameter,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)
from .utils import open_file

__all__ = [
    # declaration
    "command", "group", "option", "argument", "help_option", "version_option",
    "custom_version_option", "password_option", "confirmation_option",
    "pass_context", "pass_obj", "make_pass_decorator",
    # classes
    "Command", "Group", "CommandCollection", "Context", "Option", "Parameter",
    "Argument", "ParamType", "BadParameter", "Abort", "Exit",
    # types
    "STRING", "INT", "FLOAT", "BOOL", "UUID", "UNPROCESSED",
    "Choice", "DateTime", "IntRange", "FloatRange", "Tuple", "File", "Path",
    # terminal helpers
    "echo", "secho", "style", "unstyle", "echo_via_pager", "get_pager_file",
    "progressbar", "prompt", "confirm", "getchar", "pause", "edit", "launch",
    "clear", "get_app_dir", "get_current_context", "format_filename", "open_file",
]
