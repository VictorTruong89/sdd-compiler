"""The per-invocation Context (section 6 of the Interface Contract, FP-07)."""

import contextlib
import threading

from .exceptions import Exit
from .types import Abort

_local = threading.local()

# spec: N-000947 — the five distinct value sources (FP-07, FP-03)
SOURCE_PROMPT = "prompt"
SOURCE_COMMANDLINE = "commandline"
SOURCE_ENVIRONMENT = "environment"
SOURCE_DEFAULT_MAP = "default_map"
SOURCE_DEFAULT = "default"

_SETTING_DEFAULTS = {
    "auto_envvar_prefix": None,
    "default_map": None,
    "terminal_width": None,
    "max_content_width": 80,
    "help_option_names": None,
    "token_normalize_func": None,
    "color": None,
    "show_default": False,
    "allow_extra_args": False,
    "ignore_unknown_options": False,
    "allow_interspersed_args": True,
}


def _stack():
    if not hasattr(_local, "stack"):
        _local.stack = []
    return _local.stack


class Context:
    """State for one invocation of a command."""

    def __init__(self, command, parent=None, info_name=None, obj=None, **settings):
        self.command = command
        self.parent = parent
        self.info_name = info_name
        self.obj = obj if obj is not None else (parent.obj if parent is not None else None)
        self.params = {}
        self._kwargs = {}  # values delivered to the callback, keyed by destination
        self._sources = {}
        self._resources = []
        self.invoked_subcommand = None
        self.protected_args = []
        self.args = []
        self._exit_stack = None
        # Settings inherit from the parent, then from the command's context_settings.
        for key, default in _SETTING_DEFAULTS.items():
            if key in settings:
                value = settings.pop(key)
            elif parent is not None:
                value = getattr(parent, key)
            else:
                value = default
            setattr(self, key, value)
        if self.help_option_names is None:
            self.help_option_names = ["--help"]
        if self.max_content_width is None:
            self.max_content_width = 80
        self.extra = settings
        if self.color is None and parent is not None:
            self.color = parent.color
        if command is not None:
            for key, value in (command.context_settings or {}).items():
                if key not in settings and key in _SETTING_DEFAULTS:
                    setattr(self, key, value)

    # Settings helpers -----------------------------------------------------

    @property
    def width(self):
        if self.terminal_width is not None:
            return self.terminal_width
        import shutil

        return min(shutil.get_terminal_size((80, 24)).columns, self.max_content_width) - 2

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        found = self.find_object(object_type)
        if found is None:
            found = object_type()
            self.obj = found
        return found

    # Sources --------------------------------------------------------------

    def set_source(self, name, source):
        self._sources[name] = source

    def get_parameter_source(self, name):
        """Return the source of a declared parameter's value, or None."""
        if self.command is None or not any(p.name == name for p in self.command.params):
            return None
        return self._sources.get(name)

    # Resources and lifecycle ---------------------------------------------

    def with_resource(self, cm):
        """Enter ``cm`` for the lifetime of the invocation and return its value."""
        if self._exit_stack is None:
            self._exit_stack = contextlib.ExitStack()
        return self._exit_stack.enter_context(cm)

    def call_on_close(self, f):
        if self._exit_stack is None:
            self._exit_stack = contextlib.ExitStack()
        self._exit_stack.callback(f)

    def close(self):
        if self._exit_stack is not None:
            stack, self._exit_stack = self._exit_stack, None
            stack.close()

    def exit(self, code=0):
        raise Exit(code)

    def abort(self):
        raise Abort()

    def get_help(self):
        return self.command.get_help(self)

    def get_usage(self):
        return self.command.get_usage(self)

    def invoke(self, other_cmd, **kwargs):
        """Run another command with exactly the given values."""
        return _run_child(self, other_cmd, kwargs, forward=False)

    def forward(self, other_cmd, **kwargs):
        """Run another command with this command's values plus ``kwargs``."""
        merged = dict(self.params)
        merged.update(kwargs)
        return _run_child(self, other_cmd, merged, forward=True)

    # Thread-local current-context protocol ------------------------------

    def __enter__(self):
        _stack().append(self)
        return self

    def __exit__(self, exc_type, exc, tb):
        _stack().pop()
        return False


def _run_child(parent, cmd, values, forward):
    ctx = Context(cmd, parent=parent, info_name=cmd.name, obj=parent.obj)
    ctx.params = dict(values)
    with ctx:
        return cmd.callback(**values) if cmd.callback else None


def get_current_context(silent=False):
    """Return the context current on this thread (FP-07)."""
    stack = _stack()
    if stack:
        return stack[-1]
    if silent:
        return None
    raise RuntimeError("There is no active click context.")


def pass_context(f):
    def new_func(*args, **kwargs):
        return f(get_current_context(), *args, **kwargs)

    new_func.__name__ = getattr(f, "__name__", "new_func")
    new_func.__doc__ = f.__doc__
    return new_func


def pass_obj(f):
    def new_func(*args, **kwargs):
        return f(get_current_context().obj, *args, **kwargs)

    new_func.__name__ = getattr(f, "__name__", "new_func")
    new_func.__doc__ = f.__doc__
    return new_func


def make_pass_decorator(object_type, ensure=False):
    def decorator(f):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            return f(obj, *args, **kwargs)

        new_func.__name__ = getattr(f, "__name__", "new_func")
        new_func.__doc__ = f.__doc__
        return new_func

    return decorator
