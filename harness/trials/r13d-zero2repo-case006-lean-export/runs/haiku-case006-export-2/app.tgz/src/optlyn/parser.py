"""Command-line token scanning (FP-03, FP-04, FP-06)."""

from .exceptions import BadOptionUsage, NoSuchOption
from .params import Argument, Option


class ParseResult:
    """What the scanner produced for one command."""

    def __init__(self):
        self.cmdline = {}  # destination -> list of raw values, in command-line order
        self.order = {}  # destination -> index of first occurrence
        self.leftover = []  # tokens the command did not consume (subcommand path)


def _normalizer(ctx):
    func = ctx.token_normalize_func
    return func if func is not None else (lambda s: s)


def _option_map(ctx, command):
    """Map every accepted flag name to ``(param, on)``."""
    norm = _normalizer(ctx)
    mapping = {}
    for p in command.params:
        if not isinstance(p, Option):
            continue
        names = ctx.help_option_names if getattr(p, "is_auto_help", False) else p.opts
        for n in names:
            mapping[norm(n)] = (p, True)
        for n in p.secondary_opts:
            mapping[norm(n)] = (p, False)
    return mapping


def _is_optlike(tok, prefixes):
    return len(tok) > 1 and tok[0] in prefixes


class _Scanner:
    def __init__(self, ctx, command, args, stop_at):
        self.ctx = ctx
        self.command = command
        self.args = args
        self.norm = _normalizer(ctx)
        self.mapping = _option_map(ctx, command)
        self.prefixes = {"-"} | {k[0] for k in self.mapping if k}
        self.result = ParseResult()
        self.index = 0
        self.stop_at = stop_at  # called with (positionals_so_far) -> bool
        self.positional = []

    def _record(self, dest, value):
        self.result.cmdline.setdefault(dest, []).append(value)
        self.result.order.setdefault(dest, len(self.result.order))

    def _take(self, param, attached, i):
        """Consume a value (or several) for ``param``; return the new index."""
        n = param.nargs
        tokens = [] if attached is None else [attached]
        j = i + 1
        while len(tokens) < n and j < len(self.args):
            tokens.append(self.args[j])
            j += 1
        if len(tokens) < n:
            raise BadOptionUsage(
                f"Option '{param.human_name}' requires an argument.", ctx=self.ctx
            )
        self._record(param.name, tokens[0] if n == 1 else tuple(tokens))
        return j

    def _consume_flag(self, param, on, attached, name):
        """Record a flag or counting occurrence. Returns None for value-taking options."""
        if not (param.count or param.is_flag):
            return None
        if attached is not None:
            raise BadOptionUsage(f"Option '{name}' does not take a value.", ctx=self.ctx)
        if param.count:
            self._record(param.name, 1)
        else:
            flag = param.flag_value if on else (not param.flag_value)
            self._record(param.name, flag)
        return True

    def _unknown(self, name):
        if self.ctx.ignore_unknown_options:
            return False
        raise NoSuchOption(name, ctx=self.ctx)

    def _consume_long(self, tok, i):
        name, eq, attached = tok.partition("=")
        key = self.norm(name)
        if key not in self.mapping:
            self._unknown(name)
            self.positional.append(tok)
            return i + 1
        param, on = self.mapping[key]
        if self._consume_flag(param, on, attached if eq else None, name):
            return i + 1
        return self._take(param, attached if eq else None, i)

    def _consume_short(self, tok, i):
        if tok in self.mapping or self.norm(tok) in self.mapping:
            param, on = self.mapping.get(tok) or self.mapping[self.norm(tok)]
            if self._consume_flag(param, on, None, tok):
                return i + 1
            return self._take(param, None, i)
        prefix, chars = tok[0], tok[1:]
        for k, c in enumerate(chars):
            key = prefix + c
            if self.norm(key) not in self.mapping:
                if self.ctx.ignore_unknown_options:
                    self.positional.append(prefix + chars[k:])
                    return i + 1
                raise NoSuchOption(key, ctx=self.ctx)
            param, on = self.mapping[self.norm(key)]
            if self._consume_flag(param, on, None, key):
                continue
            remainder = chars[k + 1:]
            return self._take(param, remainder or None, i)
        return i + 1

    def run(self):
        i = 0
        ended = False
        while i < len(self.args):
            tok = self.args[i]
            if not ended and tok == "--":
                ended = True
                i += 1
                continue
            if not ended and _is_optlike(tok, self.prefixes):
                if tok.startswith("--"):
                    i = self._consume_long(tok, i)
                else:
                    i = self._consume_short(tok, i)
                continue
            if self.stop_at(self.positional):
                break
            self.positional.append(tok)
            i += 1
            if not ended and not self.ctx.allow_interspersed_args and not self.command.is_group:
                ended = True
        self.result.leftover = self.args[i:]
        return self.result


def _assign_arguments(ctx, command, positional, result):
    """Bind positional tokens to declared arguments in order (FP-04)."""
    arguments = [p for p in command.params if isinstance(p, Argument)]
    pos = 0
    for k, arg in enumerate(arguments):
        later_fixed = sum(a.nargs for a in arguments[k + 1:] if not a.is_variadic)
        if arg.is_variadic:
            tokens = positional[pos:len(positional) - later_fixed] if later_fixed else positional[pos:]
            pos += len(tokens)
            if tokens:
                result.cmdline[arg.name] = list(tokens)
                result.order.setdefault(arg.name, len(result.order))
            continue
        tokens = positional[pos:pos + arg.nargs]
        pos += len(tokens)
        if len(tokens) < arg.nargs:
            # Too few tokens: leave it absent so resolution reports it after eager flags.
            continue
        value = tokens[0] if arg.nargs == 1 else tuple(tokens)
        result.cmdline[arg.name] = [value]
        result.order.setdefault(arg.name, len(result.order))
    return positional[pos:]


def parse_tokens(ctx, command, args):
    """Scan ``args`` for ``command``. Returns ``(ParseResult, extra_tokens)``.

    ``extra_tokens`` are positional tokens nobody consumed. For groups they
    start with the subcommand name.
    """
    arguments = [p for p in command.params if isinstance(p, Argument)]
    needed = sum(a.nargs for a in arguments if not a.is_variadic)
    has_variadic = any(a.is_variadic for a in arguments)

    def stop_at(positional):
        if not command.is_group:
            return False
        if has_variadic:
            return False
        return len(positional) >= needed

    scanner = _Scanner(ctx, command, list(args), stop_at)
    result = scanner.run()
    if command.is_group:
        positional = scanner.positional
        leftover = _assign_arguments_group(ctx, command, positional, result)
        return result, leftover + result.leftover
    extra = _assign_arguments(ctx, command, scanner.positional, result)
    return result, extra + result.leftover


def _assign_arguments_group(ctx, command, positional, result):
    """Group arguments are bound, then the remaining tokens go to the subcommand."""
    arguments = [p for p in command.params if isinstance(p, Argument)]
    pos = 0
    for arg in arguments:
        if arg.is_variadic:
            tokens = positional[pos:]
            pos = len(positional)
            if tokens:
                result.cmdline[arg.name] = list(tokens)
                result.order.setdefault(arg.name, len(result.order))
            continue
        tokens = positional[pos:pos + arg.nargs]
        pos += len(tokens)
        if len(tokens) == arg.nargs and tokens:
            value = tokens[0] if arg.nargs == 1 else tuple(tokens)
            result.cmdline[arg.name] = [value]
            result.order.setdefault(arg.name, len(result.order))
    return positional[pos:]
