"""In-process runner: ``optlyn.testing.CliRunner`` (FP-14, section 9)."""

import contextlib
import io
import os
import shutil
import sys
import tempfile


class Result:
    """The outcome of a ``CliRunner.invoke`` call."""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_text, exit_code, exception, return_value=None):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_text = output_text
        self.exit_code = exit_code
        self.exception = exception
        self.return_value = return_value

    @property
    def output(self):
        return self.output_text

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class _Capture(io.TextIOWrapper):
    """A text stream that records its writes in a shared, write-ordered list."""

    def __init__(self, buffer, combined, encoding):
        super().__init__(buffer, encoding=encoding, errors="strict", write_through=True)
        self._combined = combined

    def write(self, s):
        self._combined.append(s)
        return super().write(s)


class CliRunner:
    """Invoke a command in-process with captured streams."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextlib.contextmanager
    def isolation(self, input=None, env=None, color=False):
        """Swap the interpreter streams and environment for one invocation."""
        if isinstance(input, str):
            input_bytes = input.encode(self.charset)
        else:
            input_bytes = input or b""
        combined = []
        out_buf = io.BytesIO()
        err_buf = io.BytesIO()
        old_stdin, old_stdout, old_stderr = sys.stdin, sys.stdout, sys.stderr
        stdin_text = io.TextIOWrapper(io.BytesIO(input_bytes), encoding=self.charset)
        stdout = _Capture(out_buf, combined, self.charset)
        stderr = _Capture(err_buf, combined, self.charset)
        if self.capture == "fd":
            stdout, stderr, restore_fd = self._fd_streams()
        else:
            restore_fd = None
        env_changes = dict(self.env)
        env_changes.update(env or {})
        saved_env = {}
        for key, value in env_changes.items():
            saved_env[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        sys.stdin, sys.stdout, sys.stderr = stdin_text, stdout, stderr
        try:
            yield (out_buf, err_buf, combined, stdout, stderr)
        finally:
            sys.stdin, sys.stdout, sys.stderr = old_stdin, old_stdout, old_stderr
            for key, value in saved_env.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value
            if restore_fd is not None:
                restore_fd()

    def _fd_streams(self):
        """Capture OS-level descriptors 1 and 2 as well as interpreter writes (FP-14)."""
        out_f = tempfile.TemporaryFile()
        err_f = tempfile.TemporaryFile()
        saved1, saved2 = os.dup(1), os.dup(2)
        sys.stdout.flush()
        sys.stderr.flush()
        os.dup2(out_f.fileno(), 1)
        os.dup2(err_f.fileno(), 2)
        stdout = io.TextIOWrapper(out_f, encoding=self.charset, write_through=True)
        stderr = io.TextIOWrapper(err_f, encoding=self.charset, write_through=True)

        def restore():
            stdout.flush()
            stderr.flush()
            os.dup2(saved1, 1)
            os.dup2(saved2, 2)
            os.close(saved1)
            os.close(saved2)
            out_f.seek(0)
            err_f.seek(0)
            self._fd_result = (out_f.read(), err_f.read())
            stdout.detach()
            stderr.detach()
            out_f.close()
            err_f.close()

        return stdout, stderr, restore

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        """Run ``cli`` with ``args`` and return a :class:`Result`."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        if isinstance(args, str):
            args = args.split()
        args = list(args or [])
        prog_name = extra.pop("prog_name", "cli")
        standalone = extra.pop("standalone_mode", True)
        extra.setdefault("color", color)

        exit_code = 0
        exception = None
        return_value = None
        with self.isolation(input=input, env=env, color=color) as (out_buf, err_buf, combined, stdout, stderr):
            try:
                return_value = cli.main(
                    args=args,
                    prog_name=prog_name,
                    standalone_mode=standalone,
                    **extra,
                )
            except SystemExit as e:
                exit_code = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
            except Exception as e:  # noqa: BLE001 - reported on the result
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
            stdout.flush()
            stderr.flush()
            if self.capture != "fd":
                stdout_bytes = out_buf.getvalue()
                stderr_bytes = err_buf.getvalue()
                output_text = "".join(combined)
        # Descriptor capture is only complete once the isolation block has restored them.
        if self.capture == "fd":
            out_text, err_text = getattr(self, "_fd_result", ("", ""))
            stdout_bytes = out_text.encode(self.charset)
            stderr_bytes = err_text.encode(self.charset)
            output_text = out_text + err_text
        return Result(self, stdout_bytes, stderr_bytes, output_text, exit_code, exception, return_value)

    @contextlib.contextmanager
    def isolated_filesystem(self, temp_dir=None):
        """Run inside a new empty directory; yield its path (FP-14)."""
        cwd = os.getcwd()
        path = tempfile.mkdtemp(dir=temp_dir)
        os.chdir(path)
        try:
            yield path
        finally:
            os.chdir(cwd)
            if temp_dir is None:
                shutil.rmtree(path, ignore_errors=True)
