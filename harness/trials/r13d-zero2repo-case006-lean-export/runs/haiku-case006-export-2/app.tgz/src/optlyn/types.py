"""Parameter types and conversion."""

import datetime as _dt
import enum
import os
import pathlib
import uuid


class BadParameter(Exception):
    """Raised to refuse a value (usage error)."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message)
        self.message = message
        self.ctx = ctx
        self.param = param
        self.param_hint = param_hint


class Abort(RuntimeError):
    """Abort the program (abort exit class)."""


class ParamType:
    """Base class for parameter types."""

    name = "text"
    is_composite = False

    def convert(self, value, param=None, ctx=None):
        return value

    def get_metavar(self, param=None):
        return None

    def get_missing_message(self, param=None):
        return None

    def shell_complete(self, ctx, param, incomplete):
        return []

    def split_envvar_value(self, rv):
        return rv.split()

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)


class _StringType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bytes):
            value = value.decode("utf-8", "replace")
        return str(value)


class _UnprocessedType(ParamType):
    name = "text"

    def convert(self, value, param=None, ctx=None):
        return value


class _IntType(ParamType):
    name = "integer"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        try:
            return int(str(value).strip(), 10)
        except ValueError:
            self.fail(f"{value!r} is not a valid integer.", param, ctx)


class _FloatType(ParamType):
    name = "float"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (ValueError, TypeError):
            self.fail(f"{value!r} is not a valid float.", param, ctx)


_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}


class _BoolType(ParamType):
    name = "boolean"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class _UUIDType(ParamType):
    name = "uuid"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


STRING = _StringType()
INT = _IntType()
FLOAT = _FloatType()
BOOL = _BoolType()
UUID = _UUIDType()
UNPROCESSED = _UnprocessedType()


class Choice(ParamType):
    """A closed list of allowed values, or an enum class."""

    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        self.choices = list(choices)
        self.case_sensitive = case_sensitive

    def _key(self, value):
        if isinstance(value, enum.Enum):
            value = value.name
        value = str(value)
        return value if self.case_sensitive else value.casefold()

    def get_metavar(self, param=None):
        return "[" + "|".join(self._key(c) for c in self.choices) + "]"

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, enum.Enum) and value in self.choices:
            return value
        normed = self._key(value)
        for choice in self.choices:
            if self._key(choice) == normed:
                return choice
        options = ", ".join(repr(str(self._key(c))) for c in self.choices)
        self.fail(f"{value!r} is not {options}.", param, ctx)

    def shell_complete(self, ctx, param, incomplete):
        from .completion import CompletionItem

        out = []
        for choice in self.choices:
            text = self._key(choice)
            if text.startswith(incomplete if self.case_sensitive else incomplete.casefold()):
                out.append(CompletionItem(text))
        return out


class DateTime(ParamType):
    name = "datetime"

    DEFAULT_FORMATS = ["%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"]

    def __init__(self, formats=None):
        self.formats = list(formats) if formats is not None else list(self.DEFAULT_FORMATS)

    def convert(self, value, param=None, ctx=None):
        if isinstance(value, _dt.datetime):
            return value
        for fmt in self.formats:
            try:
                return _dt.datetime.strptime(str(value), fmt)
            except ValueError:
                continue
        self.fail(f"{value!r} does not match the formats {', '.join(self.formats)}.", param, ctx)


class _Range(ParamType):
    base = None

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp
        self._validate()

    def _validate(self):
        if self.clamp and (self.min_open or self.max_open):
            raise ValueError("clamp is only allowed with closed bounds")

    def get_metavar(self, param=None):
        if self.min is None and self.max is None:
            return self.name.upper()
        lo = "" if self.min is None else ("(" if self.min_open else "[") + str(self.min)
        hi = "" if self.max is None else str(self.max) + (")" if self.max_open else "]")
        return f"{lo}..{hi}"

    def convert(self, value, param=None, ctx=None):
        value = self.base().convert(value, param, ctx)
        if self.min is not None:
            if value < self.min or (self.min_open and value == self.min):
                if self.clamp:
                    return self._clamp_low()
                self.fail(f"{value} is not in the range {self._desc()}.", param, ctx)
        if self.max is not None:
            if value > self.max or (self.max_open and value == self.max):
                if self.clamp:
                    return self._clamp_high()
                self.fail(f"{value} is not in the range {self._desc()}.", param, ctx)
        return value

    def _desc(self):
        lo = "-inf" if self.min is None else str(self.min)
        hi = "inf" if self.max is None else str(self.max)
        return f"{'(' if self.min_open else '['}{lo}, {hi}{')' if self.max_open else ']'}"

    def _clamp_low(self):
        return self.min

    def _clamp_high(self):
        return self.max


class IntRange(_Range):
    name = "integer range"
    base = _IntType

    def _clamp_low(self):
        return self.min + 1 if self.min_open else self.min

    def _clamp_high(self):
        return self.max - 1 if self.max_open else self.max


class FloatRange(_Range):
    name = "float range"
    base = _FloatType

    def _validate(self):
        if self.clamp and (self.min_open or self.max_open):
            raise ValueError("clamp is only allowed when both bounds are closed")


class Tuple(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [_to_type(t) for t in types]

    def convert(self, value, param=None, ctx=None):
        if not isinstance(value, (tuple, list)):
            value = tuple(value)
        if len(value) != len(self.types):
            self.fail(f"{len(self.types)} values are required, got {len(value)}.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))


class File(ParamType):
    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        if mode not in ("r", "w", "rb", "wb"):
            raise ValueError(f"unsupported mode {mode!r}")
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param=None, ctx=None):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        from .utils import open_file

        lazy = self.lazy
        if lazy is None:
            lazy = "w" in self.mode
        try:
            return open_file(
                value, self.mode, self.encoding, self.errors, lazy=lazy, atomic=self.atomic
            )
        except OSError as e:
            self.fail(f"Could not open file {value!r}: {e.strerror or e}.", param, ctx)


class Path(ParamType):
    name = "path"

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def convert(self, value, param=None, ctx=None):
        rv = value
        is_dash = self.file_okay and self.allow_dash and rv in (b"-", "-")
        if not is_dash:
            if self.resolve_path:
                rv = os.path.realpath(rv)
            try:
                st = os.stat(rv)
            except OSError:
                if not self.exists:
                    return self._result(rv)
                self.fail(f"{value!r} does not exist.", param, ctx)
            if not self.file_okay and not stat_is_dir(st):
                self.fail(f"{value!r} is a file.", param, ctx)
            if not self.dir_okay and stat_is_dir(st):
                self.fail(f"{value!r} is a directory.", param, ctx)
            if self.readable and not os.access(rv, os.R_OK):
                self.fail(f"{value!r} is not readable.", param, ctx)
            if self.writable and not os.access(rv, os.W_OK):
                self.fail(f"{value!r} is not writable.", param, ctx)
            if self.executable and not os.access(rv, os.X_OK):
                self.fail(f"{value!r} is not executable.", param, ctx)
        return self._result(rv)

    def _result(self, rv):
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return rv


def stat_is_dir(st):
    import stat as _stat

    return _stat.S_ISDIR(st.st_mode)


def _to_type(ty):
    """Turn a conversion function, type instance, or Python type into a ParamType."""
    if isinstance(ty, ParamType):
        return ty
    if ty is None:
        return STRING
    if ty is str:
        return STRING
    if ty is int:
        return INT
    if ty is float:
        return FLOAT
    if ty is bool:
        return BOOL
    if isinstance(ty, type) and issubclass(ty, ParamType):
        return ty()
    return FuncParamType(ty)


class FuncParamType(ParamType):
    """Wraps a conversion function f(token) -> value that refuses with ValueError."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text")

    def convert(self, value, param=None, ctx=None):
        try:
            return self.func(value)
        except BadParameter:
            raise
        except ValueError:
            self.fail(f"{value!r} is not a valid value.", param, ctx)


def to_type(ty):
    return _to_type(ty)


def infer_type(default):
    """Infer a parameter type from a declared default (FP-05)."""
    if default is None or callable(default):
        return None
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, (list, tuple)) and default:
        return infer_type(default[0])
    return None
