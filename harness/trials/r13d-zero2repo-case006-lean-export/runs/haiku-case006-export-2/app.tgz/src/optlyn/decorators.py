"""Declaration decorators and ready-made options (Interface Contract sections 3 and 4)."""

import importlib.metadata

from .core import Command, Group, _print_help_callback
from .exceptions import Exit
from .params import Argument, Option
from .termui import confirm, echo

_SUFFIXES = ("_command", "_cmd", "_group", "_grp")


def _derive_name(func_name):
    """Function name -> command name: lowercase, underscores to dashes, suffix stripped (FP-01)."""
    name = func_name.lower().replace("_", "-")
    for suffix in _SUFFIXES:
        if name.endswith(suffix.replace("_", "-")):
            return name[: -len(suffix)]
    return name


def _attach(func, param):
    """Attach a parameter declaration to ``func``, keeping top-to-bottom order."""
    if not hasattr(func, "__optlyn_params__"):
        func.__optlyn_params__ = []
    func.__optlyn_params__.insert(0, param)
    return func


def _take_params(func):
    """Move the declarations on ``func`` onto a new command and clear them from it."""
    params = list(getattr(func, "__optlyn_params__", []))
    func.__optlyn_params__ = []
    return params


def command(name=None, cls=None, **attrs):
    """Turn a function into a Command. Used as ``@command()`` or ``@command``."""
    if callable(name) and not attrs and cls is None:
        return command()(name)

    def decorator(f):
        cmd_cls = cls or Command
        cmd_name = name if name is not None else _derive_name(f.__name__)
        return cmd_cls(cmd_name, callback=f, params=_take_params(f), **attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a Group. Used as ``@group()`` or ``@group``."""
    if callable(name) and not attrs and cls is None:
        return group()(name)

    def decorator(f):
        grp_cls = cls or Group
        grp_name = name if name is not None else _derive_name(f.__name__)
        return grp_cls(grp_name, callback=f, params=_take_params(f), **attrs)

    return decorator


def option(*param_decls, cls=None, **attrs):
    """Attach an option to a command function."""

    def decorator(f):
        opt_cls = cls or Option
        return _attach(f, opt_cls(list(param_decls), **attrs))

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to a command function."""

    def decorator(f):
        arg_cls = cls or Argument
        return _attach(f, arg_cls(list(param_decls), **attrs))

    return decorator


def help_option(*param_decls, **kwargs):
    """An extra eager help flag. It prints help and exits (FP-02)."""
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs["is_flag"] = True
    kwargs["flag_value"] = True
    kwargs["default"] = False
    kwargs["callback"] = _print_help_callback

    def decorator(f):
        return _attach(f, Option(list(param_decls) or ["--help"], **kwargs))

    return decorator


def _version_text(ctx, version, package_name, prog_name, message):
    prog = prog_name or ctx.find_root().info_name
    ver = version if version is not None else _detect_version(package_name)
    if message is None:
        return f"{prog}, version {ver}"
    return message % {"prog": prog, "package": package_name, "version": ver}


def _detect_version(package_name):
    """Version of the installed distribution named ``package_name`` (FP-02)."""
    if package_name is None:
        return "unknown"
    try:
        return importlib.metadata.version(package_name)
    except importlib.metadata.PackageNotFoundError:
        pass
    # Not a distribution name: find the distribution that provides this import name.
    for dist_name, providers in importlib.metadata.packages_distributions().items():
        if package_name in providers:
            return importlib.metadata.version(providers[0])
    return "unknown"


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """An eager version flag that prints the identity and exits (FP-02)."""
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["is_flag"] = True
    kwargs["flag_value"] = True
    kwargs["default"] = False

    def callback(ctx, param, value):
        if not value:
            return value
        echo(_version_text(ctx, version, package_name, prog_name, message), color=ctx.color)
        raise Exit(0)

    kwargs["callback"] = callback

    def decorator(f):
        return _attach(f, Option(list(param_decls) or ["--version"], **kwargs))

    return decorator


def custom_version_option(callback_fn, *param_decls, **kwargs):
    """An eager version flag whose whole identity is ``callback_fn(ctx)`` (FP-02)."""
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["is_flag"] = True
    kwargs["flag_value"] = True
    kwargs["default"] = False

    def callback(ctx, param, value):
        if not value:
            return value
        echo(callback_fn(ctx), color=ctx.color)
        raise Exit(0)

    kwargs["callback"] = callback

    def decorator(f):
        return _attach(f, Option(list(param_decls) or ["--version"], **kwargs))

    return decorator


def password_option(*param_decls, **kwargs):
    """A prompting, hidden, confirmed option (FP-08)."""
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    kwargs.setdefault("help", "The password to use.")

    def decorator(f):
        return _attach(f, Option(list(param_decls) or ["--password"], **kwargs))

    return decorator


def confirmation_option(*param_decls, **kwargs):
    """A yes flag that asks when omitted and aborts when declined (FP-08)."""
    prompt_text = kwargs.pop("prompt", "Do you want to continue?")
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs["is_flag"] = True
    kwargs["flag_value"] = True
    kwargs["default"] = False

    def callback(ctx, param, value):
        if value:
            return value
        # Declined confirmation raises Abort; a yes answer lets the command run.
        confirm(prompt_text, default=False, abort=True)
        return True

    kwargs["callback"] = callback

    def decorator(f):
        return _attach(f, Option(list(param_decls) or ["--yes"], **kwargs))

    return decorator
