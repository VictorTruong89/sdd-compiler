"""Exception classes for usage failures, exits, and aborts (FP-13)."""


class OptlynError(Exception):
    """A general error signalled by the library (exit status 1)."""

    exit_code = 1

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.message = message
        self.ctx = ctx

    def show(self, file=None):
        from .termui import echo

        echo(f"Error: {self.message}", err=True)


class UsageError(OptlynError):
    """Incorrect usage (exit status 2)."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message, ctx)
        self.show_usage = False

    def show(self, file=None):
        from .termui import echo

        if self.ctx is not None and self.show_usage:
            echo(self.ctx.get_usage(), err=True)
        echo(f"Error: {self.message}", err=True)


class BadOptionUsage(UsageError):
    """Unknown option or option used incorrectly."""


class BadArgumentUsage(UsageError):
    """Argument used incorrectly."""


class NoSuchOption(UsageError):
    """An option that is not declared."""

    def __init__(self, option_name, message=None, possibilities=None, ctx=None):
        if message is None:
            message = f"No such option: {option_name}"
        super().__init__(message, ctx)
        self.option_name = option_name
        self.possibilities = possibilities or []


class MissingParameter(UsageError):
    """A required parameter was not supplied."""

    def __init__(self, message=None, ctx=None, param=None, param_hint=None):
        super().__init__(message or "Missing parameter", ctx)
        self.param = param
        self.param_hint = param_hint


class NoArgsIsHelpError(UsageError):
    """Help shown as a usage failure (missing subcommand, no args)."""


class Exit(RuntimeError):
    """An author-requested clean stop, or an intentional help/version exit."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code


class FileError(OptlynError):
    """A file failed to open at first I/O (general error class)."""
