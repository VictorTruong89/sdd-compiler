"""Text wrapping and help-page layout helpers."""

import re
import textwrap

_ANSI_RE = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")


def strip_ansi(text):
    return _ANSI_RE.sub("", text)


def wrap_text(
    text,
    width=78,
    initial_indent="",
    subsequent_indent="",
    preserve_paragraphs=False,
):
    """Rewrap ``text`` to ``width`` columns (FP-02).

    A paragraph whose first line is only a backspace is kept with its line
    breaks, and the backspace line itself is stripped.
    """
    if not text:
        return ""
    if not preserve_paragraphs:
        return textwrap.fill(
            " ".join(text.split()),
            width=width,
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
        )
    out = []
    for para in re.split(r"\n\s*\n", text):
        lines = para.split("\n")
        if lines and lines[0].strip() == "\b":
            body = [ln for ln in lines[1:]]
            out.append("\n".join(initial_indent + ln if i == 0 else subsequent_indent + ln
                                 for i, ln in enumerate(body)))
        else:
            out.append(
                textwrap.fill(
                    " ".join(para.split()),
                    width=width,
                    initial_indent=initial_indent,
                    subsequent_indent=subsequent_indent,
                )
            )
    return "\n\n".join(out)


def first_sentence(text):
    text = " ".join((text or "").split())
    m = re.match(r"(.*?[.!?])(\s|$)", text)
    return m.group(1) if m else text


def ellipsize(text, width):
    if len(text) <= width:
        return text
    return text[: max(0, width - 3)].rstrip() + "..."


class HelpFormatter:
    """Builds a help page: usage, description, sections, epilog."""

    def __init__(self, width=80, max_width=80, indent=2):
        self.width = min(width, max_width) if width is None else width
        self.indent = indent
        self.buf = []

    def write(self, text=""):
        self.buf.append(text)

    def write_usage(self, prog, args, options_placeholder="[OPTIONS]"):
        parts = [prog]
        if options_placeholder:
            parts.append(options_placeholder)
        parts.extend(args)
        self.write(f"Usage: {' '.join(parts)}")
        self.write()

    def write_text(self, text):
        self.write(wrap_text(text, width=self.width))
        self.write()

    def write_section(self, title, rows):
        if not rows:
            return
        self.write(f"{title}:")
        col = max(len(r[0]) for r in rows) + 2
        for name, help_text in rows:
            if help_text:
                wrapped = wrap_text(
                    help_text,
                    width=self.width,
                    initial_indent="",
                    subsequent_indent=" " * col,
                )
                self.write(f"{' ' * self.indent}{name.ljust(col)}{wrapped}".rstrip())
            else:
                self.write(f"{' ' * self.indent}{name}")
        self.write()

    def getvalue(self):
        return "\n".join(self.buf).rstrip("\n") + "\n"
