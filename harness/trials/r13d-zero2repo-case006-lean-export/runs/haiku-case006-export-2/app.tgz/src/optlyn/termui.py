"""Terminal helpers: echo, styling, prompts, pager, progress, editor, launch."""

import contextlib
import io
import os
import shlex
import subprocess
import sys
import tempfile
import time
import webbrowser

from .formatting import strip_ansi
from .types import BadParameter, STRING, Abort, to_type, infer_type
from .utils import format_filename as _format_filename  # noqa: F401
from .utils import get_app_dir as _get_app_dir
from .utils import open_file as _open_file

_NAMED = {
    "black": 30, "red": 31, "green": 32, "yellow": 33,
    "blue": 34, "magenta": 35, "cyan": 36, "white": 37,
    "bright_black": 90, "bright_red": 91, "bright_green": 92, "bright_yellow": 93,
    "bright_blue": 94, "bright_magenta": 95, "bright_cyan": 96, "bright_white": 97,
    "reset": 39,
}

_SWITCHES = {
    "bold": (1, 22), "dim": (2, 22), "underline": (4, 24), "overline": (53, 55),
    "italic": (3, 23), "blink": (5, 25), "reverse": (7, 27), "strikethrough": (9, 29),
}


def _color_code(color, base):
    """Return the SGR parameter string for a color, or raise ValueError."""
    if isinstance(color, str):
        if color not in _NAMED:
            raise TypeError(f"unknown color {color!r}")
        code = _NAMED[color]
        if color == "reset":
            return "0"
        return str(code + (10 if base == "bg" else 0))
    if isinstance(color, bool):
        raise TypeError("invalid color")
    if isinstance(color, int):
        if not 0 <= color <= 255:
            raise TypeError("color index must be 0-255")
        return f"{38 if base == 'fg' else 48};5;{color}"
    if isinstance(color, (tuple, list)) and len(color) == 3:
        if not all(isinstance(c, int) and 0 <= c <= 255 for c in color):
            raise TypeError("RGB values must be 0-255")
        return f"{38 if base == 'fg' else 48};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"invalid color {color!r}")


def style(
    text, fg=None, bg=None, bold=None, dim=None, underline=None, overline=None,
    italic=None, blink=None, reverse=None, strikethrough=None, reset=True,
):
    """Wrap ``text`` in ANSI SGR sequences."""
    codes = []
    if fg is not None:
        codes.append(_color_code(fg, "fg"))
    if bg is not None:
        codes.append(_color_code(bg, "bg"))
    flags = {
        "bold": bold, "dim": dim, "underline": underline, "overline": overline,
        "italic": italic, "blink": blink, "reverse": reverse, "strikethrough": strikethrough,
    }
    for name, on in flags.items():
        if on is not None:
            on_code, off_code = _SWITCHES[name]
            codes.append(str(on_code if on else off_code))
    if not codes:
        return text
    prefix = f"\033[{';'.join(codes)}m"
    suffix = "\033[0m" if reset else ""
    return f"{prefix}{text}{suffix}"


def unstyle(text):
    return strip_ansi(text)


def _current_color():
    from .context import get_current_context

    ctx = get_current_context(silent=True)
    return ctx.color if ctx is not None else None


def _should_strip(stream, color):
    if color is True:
        return False
    if color is False:
        return True
    return not _is_tty(stream)


def _is_tty(stream):
    try:
        return bool(stream.isatty())
    except (AttributeError, ValueError):
        return False


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write text or bytes to stdout, stderr, or ``file``."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if message is None:
        message = ""
    if isinstance(message, bytes):
        target = getattr(file, "buffer", file)
        target.write(message + (b"\n" if nl else b""))
        target.flush()
        return
    if color is None:
        color = _current_color()
    if _should_strip(file, color):
        message = strip_ansi(message)
    if nl:
        message += "\n"
    try:
        file.write(message)
    except UnicodeEncodeError:
        # ASCII-only stream: fall back to UTF-8 bytes instead of failing (FP-11).
        target = getattr(file, "buffer", None)
        if target is not None:
            file.flush()
            target.write(message.encode("utf-8"))
        else:
            file.write(message.encode("utf-8", "replace").decode("ascii", "replace"))
    file.flush()


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None:
        message = style(message, **styles)
    return echo(message, file=file, nl=nl, err=err, color=color)


def get_pager_file(color=None):
    """Context manager yielding a writable text stream (pager or stdout)."""
    return _pager_stream(color)


@contextlib.contextmanager
def _pager_stream(color):
    buf = io.StringIO()
    yield buf
    _write_pager(buf.getvalue(), color)


def _write_pager(text, color):
    if not sys.stdout.isatty() or not sys.stdin.isatty():
        echo(text, nl=False, color=color)
        return
    pager = os.environ.get("PAGER")
    if not pager:
        echo(text, nl=False, color=color)
        return
    if _should_strip(sys.stdout, color):
        text = strip_ansi(text)
    proc = subprocess.Popen(shlex.split(pager), stdin=subprocess.PIPE)
    try:
        proc.communicate(text.encode("utf-8", "replace"))
    except BrokenPipeError:
        pass


def echo_via_pager(text_or_generator, color=None):
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        text = text_or_generator
    else:
        text = "".join(text_or_generator)
    _write_pager(text, color)


class ProgressBar:
    """Iterable progress bar (FP-11)."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, **options):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label
        self.hidden = hidden
        self.pos = 0
        self.start = time.time()
        self.tty = (not hidden) and _is_tty(sys.stdout)
        if label and not hidden and not self.tty:
            echo(label, nl=False)

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps):
        self.pos += n_steps
        if self.tty:
            total = self.length or 0
            pct = f"{int(100 * self.pos / total)}%" if total else ""
            elapsed = time.time() - self.start
            eta = ""
            if total and self.pos:
                eta = f" eta {int(elapsed * (total - self.pos) / self.pos)}s"
            echo(f"\r{self.label or ''} {self.pos}/{total or '?'} {pct}{eta}", nl=False)

    def finish(self):
        if self.tty:
            echo()


@contextlib.contextmanager
def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    bar = ProgressBar(iterable, length, label, hidden, **options)
    try:
        yield bar
    finally:
        bar.finish()


def getchar(echo_char=False):
    """Read one character from the controlling terminal (FP-11)."""
    try:
        import termios
        import tty

        fd = os.open("/dev/tty", os.O_RDONLY)
        try:
            old = termios.tcgetattr(fd)
            try:
                tty.setraw(fd)
                ch = os.read(fd, 1).decode("utf-8", "replace")
            finally:
                termios.tcsetattr(fd, termios.TCSADRAIN, old)
        finally:
            os.close(fd)
    except (ImportError, OSError):
        ch = sys.stdin.read(1)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch == "\x04" or ch == "":
        raise EOFError()
    if echo_char:
        echo(ch, nl=False)
    return ch


def pause(info=None, err=False):
    if not _is_tty(sys.stdin) or not _is_tty(sys.stdout):
        return
    echo(info or "Press any key to continue...", err=err, nl=False)
    try:
        getchar()
    except (KeyboardInterrupt, EOFError):
        pass
    echo(err=err)


def clear():
    if _is_tty(sys.stdout):
        echo("\033[2J\033[H", nl=False)


def prompt(
    text, default=None, hide_input=False, confirmation_prompt=False, type=None,
    value_proc=None, prompt_suffix=": ", show_default=True, err=False,
):
    """Ask for a value and return it converted (FP-08)."""
    ptype = to_type(type) if type is not None else (
        to_type(infer_type(default)) if default is not None and infer_type(default) else STRING
    )
    suffix = ""
    if default is not None and show_default and not hide_input:
        suffix = f" [{default}]"
    while True:
        value = _read_line(f"{text}{suffix}{prompt_suffix}", hide_input, err)
        if value == "" and default is not None:
            value = default
        if confirmation_prompt:
            again = _read_line("Repeat for confirmation: ", hide_input, err)
            if again != value:
                echo("Error: the two entered values do not match", err=True)
                continue
        try:
            return ptype.convert(value)
        except BadParameter as e:
            echo(f"Error: {e.message}", err=True)


def _read_line(message, hide_input, err):
    echo(message, nl=False, err=err)
    line = sys.stdin.readline()
    if line == "":
        # End of file during a prompt is an abort (FP-08).
        echo(err=err)
        raise EOFError()
    line = line.rstrip("\r\n")
    # Hidden input is not echoed; visible input is echoed when it was not typed on a terminal.
    if not hide_input and not _is_tty(sys.stdin):
        echo(line, err=err)
    elif hide_input:
        echo(err=err)
    return line


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question and return a bool (FP-08)."""
    hint = " [Y/n]" if default else " [y/N]"
    while True:
        value = _read_line(f"{text}{hint if show_default else ''}{prompt_suffix}", False, err)
        answer = value.strip().lower()
        if answer == "":
            result = default
            break
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
    if not result and abort:
        raise Abort()
    return result


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Run an editor on text or a file (FP-11)."""
    editor = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    cmd = shlex.split(editor)
    if filename is not None:
        path = filename
        if text is not None:
            with _open_file(path, "w", encoding="utf-8") as f:
                f.write(text)
        subprocess.call(cmd + [path], env=env)
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text or "")
        mtime = os.path.getmtime(path)
        subprocess.call(cmd + [path], env=env)
        with open(path, encoding="utf-8") as f:
            result = f.read()
        if require_save and os.path.getmtime(path) == mtime:
            return None
        return result
    finally:
        os.remove(path)


def launch(url, wait=False, locate=False):
    """Open ``url`` with the default application (FP-11)."""
    if sys.platform.startswith("linux"):
        cmd = ["xdg-open", url]
    elif sys.platform == "darwin":
        cmd = ["open", url]
    else:
        return 0 if webbrowser.open(url) else 1
    proc = subprocess.Popen(cmd)
    if wait:
        return proc.wait()
    return 0


def get_app_dir(app_name, roaming=True, force_posix=False):
    return _get_app_dir(app_name, roaming, force_posix)


def format_filename(filename, shorten=False):
    return _format_filename(filename, shorten)
