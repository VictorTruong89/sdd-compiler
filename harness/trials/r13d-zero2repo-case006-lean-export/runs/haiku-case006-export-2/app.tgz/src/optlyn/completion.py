"""Shell completion: registration scripts and suggestions (FP-12, section 8)."""

import os
import re

from .context import Context
from .params import Argument, Option

SHELLS = ("bash", "zsh", "fish", "powershell")


class CompletionItem:
    """A suggestion with optional help text and a kind."""

    def __init__(self, value, help=None, type="plain"):
        self.value = value
        self.help = help
        self.type = type


def default_complete_var(prog_name):
    """``_<PROG>_COMPLETE`` for the program name (section 8)."""
    return "_" + re.sub(r"[-.\s]", "_", prog_name).upper() + "_COMPLETE"


def maybe_complete(cmd, args, prog_name, complete_var=None):
    """Handle completion mode. Returns True when the invocation was a completion request."""
    var = complete_var or default_complete_var(prog_name)
    value = os.environ.get(var)
    if not value:
        return False
    shell, _, instruction = value.rpartition("_")
    if shell not in SHELLS or instruction not in ("source", "complete"):
        # An unrecognized instruction neither prints nor runs the callback (FP-12).
        return True
    from .termui import echo

    if instruction == "source":
        echo(_source_script(shell, var, prog_name), nl=False)
        return True

    words = os.environ.get("COMP_WORDS", "").split(" ")
    if shell == "fish":
        # fish gives the incomplete token itself in COMP_CWORD (section 8).
        incomplete = os.environ.get("COMP_CWORD", "")
        tokens = words[1:]
        if tokens and tokens[-1] == incomplete:
            tokens.pop()
    else:
        cword = int(os.environ.get("COMP_CWORD", str(len(words) - 1)) or 0)
        incomplete = words[cword] if cword < len(words) else ""
        tokens = words[1:cword]
    for item in suggest(cmd, tokens, incomplete):
        if item.type == "plain":
            line = f"plain,{item.value}"
            if shell in ("zsh", "fish") and item.help:
                line += f"\t{item.help}"
        else:
            line = f"{item.type},"
        echo(line, nl=True)
    return True


def suggest(cmd, tokens, incomplete):
    """Suggestions for ``incomplete`` after ``tokens`` (words after the program name)."""
    from .core import Group

    node = cmd
    expecting = None  # option waiting for a value
    i = 0
    while i < len(tokens):
        tok = tokens[i]
        i += 1
        if expecting is not None:
            expecting = None
            continue
        if tok.startswith("-") and len(tok) > 1 and tok != "--":
            param = _find_option(node, tok)
            if param is not None and not param.is_flag and not param.count:
                expecting = param
            continue
        if isinstance(node, Group):
            sub = node.get_command(_root_ctx(cmd), tok)
            if sub is not None:
                node = sub
                continue
        break

    if expecting is not None:
        return _value_suggestions(cmd, expecting, incomplete)

    if incomplete.startswith("-"):
        out = []
        for p in node.params:
            if isinstance(p, Option) and not p.hidden:
                for name in list(p.opts) + list(p.secondary_opts):
                    if name.startswith(incomplete):
                        out.append(CompletionItem(name, help=p.help))
        return out

    if isinstance(node, Group):
        out = []
        ctx = _root_ctx(cmd)
        for name in node.list_commands(ctx):
            sub = node.get_command(ctx, name)
            if sub is None or sub.hidden or not name.startswith(incomplete):
                continue
            out.append(CompletionItem(name, help=sub.short_help))
        return out

    return _argument_suggestions(node, incomplete)


def _root_ctx(cmd):
    return Context(cmd, info_name=cmd.name)


def _find_option(node, tok):
    for p in node.params:
        if isinstance(p, Option) and (tok in p.opts or tok in p.secondary_opts):
            return p
    return None


def _value_suggestions(cmd, param, incomplete):
    if param.shell_complete is not None:
        return _normalize(param.shell_complete(_root_ctx(cmd), param, incomplete))
    return _normalize(param.type.shell_complete(_root_ctx(cmd), param, incomplete))


def _argument_suggestions(node, incomplete):
    for p in node.params:
        if isinstance(p, Argument) and not p.hidden:
            if p.shell_complete is not None:
                return _normalize(p.shell_complete(_root_ctx(node), p, incomplete))
            return _normalize(p.type.shell_complete(_root_ctx(node), p, incomplete))
    return []


def _normalize(items):
    """Accept strings or objects with value/help/type (section 8)."""
    out = []
    for item in items or []:
        if isinstance(item, str):
            out.append(CompletionItem(item))
        else:
            out.append(CompletionItem(item.value, help=getattr(item, "help", None),
                                      type=getattr(item, "type", "plain")))
    return out


def _source_script(shell, var, prog):
    if shell == "bash":
        func = f"_{prog.replace('-', '_')}_completion"
        return (
            f"{func}() {{\n"
            "    local IFS=$'\\n'\n"
            "    local response\n"
            f"    response=$(env COMP_WORDS=\"${{COMP_WORDS[*]}}\" COMP_CWORD=$COMP_CWORD {var}=bash_complete {prog})\n"
            "    for completion in $response; do\n"
            "        IFS=',' read -r type value <<< \"$completion\"\n"
            "        if [[ $type == 'dir' ]]; then COMPREPLY=(); compopt -o dirnames\n"
            "        elif [[ $type == 'file' ]]; then COMPREPLY=(); compopt -o default\n"
            "        elif [[ $type == 'plain' ]]; then COMPREPLY+=($value)\n"
            "        fi\n"
            "    done\n"
            "    return 0\n"
            "}\n"
            f"complete -o nosort -F {func} {prog}\n"
        )
    if shell == "zsh":
        func = f"_{prog.replace('-', '_')}_completion"
        return (
            f"{func}() {{\n"
            "    local -a completions\n"
            f"    completions=(\"${{(@f)$(env COMP_WORDS=\"${{words[*]}}\" COMP_CWORD=$((CURRENT-1)) {var}=zsh_complete {prog})}}\")\n"
            "    _describe 'values' completions\n"
            "}\n"
            f"compdef {func} {prog}\n"
        )
    if shell == "fish":
        return (
            f"complete --command {prog} --no-files --arguments "
            f"'(env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) {var}=fish_complete {prog})'\n"
        )
    return (
        f"Register-ArgumentCompleter -Native -CommandName {prog} -ScriptBlock {{\n"
        "    param($wordToComplete, $commandAst, $cursorPosition)\n"
        f"    $env:COMP_WORDS = $commandAst.ToString(); $env:COMP_CWORD = $wordToComplete\n"
        f"    $env:{var} = 'powershell_complete'\n"
        f"    & {prog} | ForEach-Object {{ $_ }}\n"
        f"    Remove-Item Env:{var}\n"
        "}\n"
    )
