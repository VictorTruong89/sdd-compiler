"""Command, Group, CommandCollection, and the invocation flow (FP-01, FP-06, FP-13)."""

import inspect
import os
import sys

from .context import (
    SOURCE_COMMANDLINE,
    SOURCE_DEFAULT,
    SOURCE_ENVIRONMENT,
    SOURCE_PROMPT,
    Context,
)
from .exceptions import (
    Exit,
    MissingParameter,
    NoArgsIsHelpError,
    OptlynError,
    UsageError,
)
from .formatting import HelpFormatter, first_sentence
from .params import Argument, Option
from .parser import parse_tokens
from .types import Abort, BadParameter, File

# spec: N-000899 — argument and option destinations are the parameter name
_SUFFIXES = ("_command", "_cmd", "_group", "_grp")

CHAIN_MARKER = type("ChainMarker", (), {"__repr__": lambda self: "<chain>"})()


def _echo(*args, **kwargs):
    from .termui import echo

    return echo(*args, **kwargs)


def _doc_text(doc):
    if not doc:
        return None
    doc = inspect.cleandoc(doc)
    if "\f" in doc:
        doc = doc.split("\f", 1)[0]
    return doc


def _command_path(ctx):
    names = []
    node = ctx
    while node is not None:
        names.append(node.info_name or "")
        node = node.parent
    return " ".join(reversed([n for n in names if n]))


class Command:
    """A leaf command: parameters plus a callback."""

    is_group = False

    def __init__(
        self,
        name,
        callback=None,
        params=None,
        help=None,
        short_help=None,
        epilog=None,
        options_metavar="[OPTIONS]",
        context_settings=None,
        add_help_option=True,
        no_args_is_help=False,
        deprecated=False,
        hidden=False,
        **extra,
    ):
        self.name = name
        self.callback = callback
        self.params = list(params or [])
        self.help = _doc_text(help) if help is not None else _doc_text(getattr(callback, "__doc__", None))
        self.short_help = short_help
        self.epilog = epilog
        self.options_metavar = options_metavar
        self.context_settings = dict(context_settings or {})
        self.no_args_is_help = no_args_is_help
        self.deprecated = deprecated
        self.hidden = hidden
        self.extra = extra
        if add_help_option:
            self._add_auto_help()

    def _add_auto_help(self):
        """Attach the automatic help flag, unless an author option takes all its names (FP-02)."""
        default_names = {"--help"}
        for p in self.params:
            if isinstance(p, Option) and default_names <= set(p.opts):
                return
        self.params.append(_auto_help_option())

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    # Entry point -----------------------------------------------------------

    def main(self, args=None, prog_name=None, complete_var=None, standalone_mode=True, **extra):
        if args is None:
            args = sys.argv[1:]
        args = list(args)
        if prog_name is None:
            prog_name = os.path.basename(sys.argv[0]) if sys.argv and sys.argv[0] else "app"

        from .completion import maybe_complete

        if maybe_complete(self, args, prog_name, complete_var):
            if standalone_mode:
                sys.exit(0)
            return None

        if not standalone_mode:
            # Failures propagate to the caller; a clean stop simply ends the call.
            ctx = self.make_context(prog_name, args, **extra)
            try:
                return self.invoke(ctx)
            except Exit:
                return None

        try:
            ctx = self.make_context(prog_name, args, **extra)
            self.invoke(ctx)
        except Exit as e:
            sys.exit(e.exit_code)
        except UsageError as e:
            e.show()
            sys.exit(2)
        except (Abort, KeyboardInterrupt, EOFError):
            _echo("Aborted!", err=True)
            sys.exit(1)
        except OptlynError as e:
            e.show()
            sys.exit(1)
        sys.exit(0)

    # Context construction --------------------------------------------------

    def make_context(self, info_name, args, parent=None, leftover_ok=False, **extra):
        ctx = Context(self, parent=parent, info_name=info_name, **extra)
        if parent is not None and "default_map" not in extra:
            dm = parent.default_map
            ctx.default_map = dm.get(info_name) if isinstance(dm, dict) else None
        with ctx:
            if self.no_args_is_help and not args and not self.is_group:
                _echo(self.get_help(ctx), err=True)
                raise NoArgsIsHelpError("Missing argument.", ctx=ctx)
            rest = self.parse_args(ctx, args)
            if self.is_group:
                ctx.protected_args = rest
            elif rest:
                if ctx.allow_extra_args or leftover_ok:
                    ctx.args = rest
                else:
                    raise UsageError(
                        f"Got unexpected extra argument{'s' if len(rest) > 1 else ''} "
                        f"({' '.join(rest)})",
                        ctx=ctx,
                    )
        return ctx

    # Parsing ---------------------------------------------------------------

    def parse_args(self, ctx, args):
        """Parse tokens, resolve every parameter, and return the leftover tokens."""
        result, leftover = parse_tokens(ctx, self, args)
        self._resolve_params(ctx, result)
        return leftover

    def _resolve_params(self, ctx, result):
        eager = [p for p in self.params if p.is_eager]
        eager_given = sorted(
            (p for p in eager if p.name in result.cmdline),
            key=lambda p: result.order[p.name],
        )
        eager_rest = [p for p in eager if p not in eager_given]
        others = [p for p in self.params if not p.is_eager]
        for p in eager_given + eager_rest + others:
            self._process_param(ctx, p, result.cmdline.get(p.name))

    def _process_param(self, ctx, p, cmdline_values):
        if isinstance(p, Option) and getattr(p, "is_auto_help", False):
            names = ctx.help_option_names
            p.opts = list(names)
        value, source = p.resolve(ctx, cmdline_values)

        # Prompt when omitted (FP-08): a required option always asks, otherwise
        # only when prompt_required allows it. Command line and environment skip it.
        if isinstance(p, Option) and p.prompt and source not in (SOURCE_COMMANDLINE, SOURCE_ENVIRONMENT) and (
            p.required or p.prompt_required
        ):
            from .termui import prompt

            text = p.prompt if isinstance(p.prompt, str) else p.name.replace("_", " ").capitalize()
            value = prompt(
                text,
                default=None if value in (None, ()) else value,
                hide_input=p.hide_input,
                confirmation_prompt=p.confirmation_prompt,
                type=p.type,
            )
            source = SOURCE_PROMPT

        if p.required and source == SOURCE_DEFAULT and (value is None or value == ()):
            raise MissingParameter(_missing_text(p), ctx=ctx, param=p)

        if p.deprecated and cmdline_values is not None:
            note = p.deprecated if isinstance(p.deprecated, str) else ""
            _echo(
                f"DeprecationWarning: The {_param_kind(p)} '{p.human_name}' is deprecated. {note}".rstrip(),
                err=True,
            )

        try:
            converted = p.process(ctx, value, source)
        except BadParameter as e:
            raise UsageError(f"Invalid value for '{p.human_name}': {e.message}", ctx=ctx) from e

        if isinstance(p.type, File) and hasattr(converted, "close"):
            ctx.call_on_close(converted.close)
        if p.expose_value:
            ctx.params[p.name] = converted
            ctx._kwargs[p.name] = converted

    # Invocation ------------------------------------------------------------

    def invoke(self, ctx):
        """Run this command's callback in ``ctx``."""
        try:
            if self.deprecated:
                note = self.deprecated if isinstance(self.deprecated, str) else ""
                _echo(
                    f"DeprecationWarning: The command '{self.name}' is deprecated. {note}".rstrip(),
                    err=True,
                )
            with ctx:
                return self.callback(**ctx._kwargs) if self.callback is not None else None
        finally:
            ctx.close()

    # Help ------------------------------------------------------------------

    def get_usage(self, ctx):
        return self._usage_line(ctx)

    def _usage_line(self, ctx):
        parts = [_command_path(ctx)]
        if self.options_metavar and any(isinstance(p, Option) and not p.hidden for p in self.params):
            parts.append(self.options_metavar)
        for p in self.params:
            if isinstance(p, Argument) and not p.hidden:
                parts.append(_argument_placeholder(p))
        if self.is_group:
            parts.append(self._subcommand_placeholder())
        return "Usage: " + " ".join(parts)

    def _subcommand_placeholder(self):
        return "COMMAND [ARGS]..."

    def get_help(self, ctx):
        fmt = HelpFormatter(width=ctx.width, max_width=ctx.max_content_width)
        fmt.write(self._usage_line(ctx))
        fmt.write()
        if self.help:
            fmt.write_text(self.help)
        args_rows = [
            (_argument_placeholder(p, brackets=False), p.help)
            for p in self.params
            if isinstance(p, Argument) and p.help and not p.hidden
        ]
        fmt.write_section("Positional arguments", args_rows)
        opt_rows = []
        for p in self.params:
            if isinstance(p, Option) and not p.hidden:
                opt_rows.append((_option_names(p), _option_help(ctx, p)))
        fmt.write_section("Options", opt_rows)
        if self.is_group:
            cmd_rows = []
            for name in self.list_commands(ctx):
                sub = self.get_command(ctx, name)
                if sub is None or sub.hidden:
                    continue
                cmd_rows.append((name, sub.short_help or first_sentence(sub.help or "")))
            fmt.write_section("Commands", cmd_rows)
        if self.epilog:
            fmt.write_text(self.epilog)
        return fmt.getvalue()


class Group(Command):
    """A command that dispatches to named subcommands (FP-06)."""

    is_group = True

    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        **kwargs,
    ):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name, no_args_is_help=False, **kwargs)
        self.invoke_without_command = invoke_without_command
        self.no_args_is_help_policy = no_args_is_help
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self.result_callback_func = result_callback
        self.commands = {}
        for cmd in commands or []:
            self.add_command(cmd)

    def make_context(self, info_name, args, parent=None, leftover_ok=False, **extra):
        if self.no_args_is_help_policy and not args:
            ctx = Context(self, parent=parent, info_name=info_name, **extra)
            _echo(self.get_help(ctx), err=True)
            raise NoArgsIsHelpError("Missing command.", ctx=ctx)
        return super().make_context(info_name, args, parent=parent, leftover_ok=leftover_ok, **extra)

    # Subcommand registration -----------------------------------------------

    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise TypeError("cannot attach a group beneath a chaining group")
        key = name or cmd.name
        self.commands[key] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as _command

        def decorator(f):
            cmd = _command(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def group(self, *args, **kwargs):
        from .decorators import group as _group

        def decorator(f):
            cmd = _group(*args, **kwargs)(f)
            self.add_command(cmd)
            return cmd

        return decorator

    def result_callback(self):
        """Decorator registering the function that receives subcommand return values (FP-10)."""

        def decorator(func):
            self.result_callback_func = func
            return func

        return decorator

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        norm = ctx.token_normalize_func or (lambda s: s)
        for key, cmd in self.commands.items():
            if key == cmd_name or norm(key) == norm(cmd_name):
                return cmd
        return None

    def _subcommand_placeholder(self):
        if self.subcommand_metavar:
            return self.subcommand_metavar
        return "COMMAND [ARGS]..."

    # Invocation ------------------------------------------------------------

    def invoke(self, ctx):
        if self.chain:
            return self._invoke_chain(ctx)
        rest = ctx.protected_args
        try:
            if not rest:
                if not self.invoke_without_command:
                    raise UsageError("Missing command.", ctx=ctx)
                ctx.invoked_subcommand = None
                with ctx:
                    rv = self.callback(**ctx._kwargs) if self.callback is not None else None
                if self.result_callback_func is not None:
                    with ctx:
                        return self.result_callback_func(rv, **ctx.params)
                return rv

            name, sub_args = rest[0], rest[1:]
            sub = self.get_command(ctx, name)
            if sub is None:
                raise UsageError(f"No such command '{name}'.", ctx=ctx)
            ctx.invoked_subcommand = name
            with ctx:
                if self.callback is not None:
                    self.callback(**ctx._kwargs)
            child = sub.make_context(name, sub_args, parent=ctx)
            rv = sub.invoke(child)
            if self.result_callback_func is not None:
                with ctx:
                    return self.result_callback_func(rv, **ctx.params)
            return rv
        finally:
            ctx.close()

    def _invoke_chain(self, ctx):
        try:
            ctx.invoked_subcommand = CHAIN_MARKER
            with ctx:
                if self.callback is not None:
                    self.callback(**ctx._kwargs)
            results = []
            rest = ctx.protected_args
            while rest:
                name = rest[0]
                sub = self.get_command(ctx, name)
                if sub is None:
                    raise UsageError(f"No such command '{name}'.", ctx=ctx)
                child = sub.make_context(name, rest[1:], parent=ctx, leftover_ok=True)
                results.append(sub.invoke(child))
                rest = child.args
            if self.result_callback_func is not None:
                with ctx:
                    return self.result_callback_func(results, **ctx.params)
            return results
        finally:
            ctx.close()


class CommandCollection(Group):
    """A group that presents subcommands from several source groups (FP-06)."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set()
        for src in self.sources:
            names.update(src.list_commands(ctx))
        names.update(self.commands)
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        cmd = super().get_command(ctx, cmd_name)
        if cmd is not None:
            return cmd
        for src in self.sources:
            cmd = src.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return None


# Help helpers -----------------------------------------------------------------


def _param_kind(p):
    return "option" if isinstance(p, Option) else "argument"


def _missing_text(p):
    if isinstance(p, Option):
        return f"Missing option '{p.human_name}'."
    return f"Missing argument '{p.name.upper()}'."


def _argument_placeholder(p, brackets=True):
    text = p.get_metavar()
    if p.is_variadic:
        text += "..."
    if brackets and not p.required:
        return f"[{text}]"
    return text


def _option_names(p):
    label = ", ".join(p.opts) if p.opts else p.name
    if p.secondary_opts:
        label = "/".join(p.opts) + ", " + "/".join(p.secondary_opts)
    metavar = p.get_metavar()
    if metavar:
        label += f" {metavar}"
    return label


def _option_help(ctx, p):
    parts = []
    if p.help:
        parts.append(p.help)
    show = p.show_default if p.show_default is not None else ctx.show_default
    if show and p.default is not None and not (p.is_flag and not p.default):
        if isinstance(show, str):
            parts.append(f"[default: {show}]")
        else:
            default = p.default() if callable(p.default) else p.default
            parts.append(f"[default: {default}]")
    if p.show_envvar and p.envvar:
        parts.append(f"[env var: {', '.join(p.envvar)}]")
    return " ".join(parts)


def _auto_help_option():
    """The automatic help flag. It reads the names from the invocation context (FP-02)."""
    p = Option(["--help"], is_flag=True, flag_value=True, is_eager=True, expose_value=False,
               help="Show this message and exit.", default=False)
    p.is_auto_help = True
    p.callback = _print_help_callback
    return p


def _print_help_callback(ctx, param, value):
    if not value:
        return value
    _echo(ctx.get_help(), color=ctx.color)
    raise Exit(0)
