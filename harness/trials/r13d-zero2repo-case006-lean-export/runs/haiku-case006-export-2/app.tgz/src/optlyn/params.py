"""Parameter objects: options and arguments, conversion, and value sources."""

import os
import re

from .context import (
    SOURCE_COMMANDLINE,
    SOURCE_DEFAULT,
    SOURCE_DEFAULT_MAP,
    SOURCE_ENVIRONMENT,
)
from .types import BOOL, INT, STRING, BadParameter, Tuple, infer_type, to_type

_TRUE = {"1", "true", "t", "yes", "y", "on"}
_FALSE = {"0", "false", "f", "no", "n", "off"}
_IDENT = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_PREFIXES = "-/+"
_MISSING = object()


class Parameter:
    """Base class for declared parameters."""

    param_type_name = "parameter"
    is_flag = False

    def __init__(
        self,
        param_decls=None,
        type=None,
        required=False,
        default=None,
        callback=None,
        nargs=None,
        multiple=False,
        envvar=None,
        expose_value=True,
        is_eager=False,
        metavar=None,
        shell_complete=None,
        deprecated=False,
        hidden=False,
        help=None,
        allow_from_autoenv=True,
        show_default=None,
        show_envvar=False,
    ):
        if type is None and default is not None and not callable(default):
            type = infer_type(default)
        self.type = to_type(type) if type is not None else STRING
        self.required = required
        self.default = default
        self.callback = callback
        self.nargs = nargs if nargs is not None else 1
        self.multiple = multiple
        self.envvar = [envvar] if isinstance(envvar, str) else (list(envvar) if envvar else [])
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.metavar = metavar
        self.shell_complete = shell_complete
        self.deprecated = deprecated
        self.hidden = hidden
        self.help = help
        self.allow_from_autoenv = allow_from_autoenv
        self.show_default = show_default
        self.show_envvar = show_envvar
        if isinstance(self.type, Tuple) and self.nargs == 1:
            self.nargs = len(self.type.types)
        if self.nargs != -1 and self.nargs < 1:
            raise ValueError("nargs must be a positive integer or -1")
        if self.deprecated and self.required:
            raise ValueError(f"deprecated {self.param_type_name} cannot be required")
        if self.multiple and self.default is not None and not callable(self.default):
            if isinstance(self.default, (str, bytes)) or not isinstance(self.default, (list, tuple)):
                raise ValueError("a repeatable default must be a sequence")

    # Shape -----------------------------------------------------------------

    @property
    def is_variadic(self):
        return self.nargs == -1

    @property
    def per_value_is_sequence(self):
        """True when each occurrence takes several tokens or a Tuple type."""
        return self.nargs != 1 or self.type.is_composite

    @property
    def human_name(self):
        return self.name

    def get_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return None

    # Conversion ------------------------------------------------------------

    def type_cast_value(self, ctx, value):
        """Convert ``value`` to the delivered shape (FP-03, section 4)."""
        if value is None:
            return () if (self.multiple or self.is_variadic) else None
        if self.multiple or self.is_variadic:
            if isinstance(value, (str, bytes)) or not isinstance(value, (list, tuple)):
                raise BadParameter(
                    f"{self.human_name} needs an iterable (sequence) default.", ctx=ctx, param=self
                )
            return tuple(self._convert_occurrence(ctx, v) for v in value)
        return self._convert_occurrence(ctx, value)

    def _convert_occurrence(self, ctx, value):
        if self.type.is_composite or self.nargs == 1:
            return self.type.convert(value, self, ctx)
        if isinstance(value, (str, bytes)) or not isinstance(value, (list, tuple)):
            value = tuple(value) if not isinstance(value, (str, bytes)) else (value,)
        if len(value) != self.nargs:
            raise BadParameter(f"{self.human_name} takes {self.nargs} values.", ctx=ctx, param=self)
        return tuple(self.type.convert(v, self, ctx) for v in value)

    def split_envvar(self, raw):
        if self.multiple or self.per_value_is_sequence:
            return self.type.split_envvar_value(raw)
        return raw

    # Value sources ---------------------------------------------------------

    def _default_value(self):
        return self.default() if callable(self.default) else self.default

    def _env_names(self, ctx):
        names = list(self.envvar)
        prefix = ctx.auto_envvar_prefix
        if prefix and self.allow_from_autoenv and not isinstance(self, Argument):
            parts = [prefix] + _subcommand_path(ctx) + [self.name]
            names.append("_".join(p.replace("-", "_").upper() for p in parts if p))
        return names

    def _read_environment(self, ctx):
        for name in self._env_names(ctx):
            raw = os.environ.get(name)
            if raw is None or raw == "":
                continue
            return self._from_env_value(ctx, raw)
        return _MISSING

    def _from_env_value(self, ctx, raw):
        return self.split_envvar(raw)

    def resolve(self, ctx, cmdline_values):
        """Return ``(value, source)`` for this parameter (FP-03 precedence).

        ``cmdline_values`` is the list of raw command-line values, or None when
        the parameter was not given on the command line.
        """
        if cmdline_values is not None:
            return self._collect_cmdline(cmdline_values), SOURCE_COMMANDLINE

        env_value = self._read_environment(ctx)
        if env_value is not _MISSING:
            return env_value, SOURCE_ENVIRONMENT

        dm_value = _lookup_default_map(ctx, self)
        if dm_value is not _MISSING:
            # A string is split only for multi-token or Tuple parameters (FP-07).
            if isinstance(dm_value, str) and self.per_value_is_sequence:
                dm_value = self.split_envvar(dm_value)
            return dm_value, SOURCE_DEFAULT_MAP

        return self._default_value(), SOURCE_DEFAULT

    def _collect_cmdline(self, values):
        if getattr(self, "count", False):
            return len(values)
        if self.multiple or self.is_variadic:
            return tuple(values)
        return values[-1] if values else None

    def process(self, ctx, value, source):
        """Convert, record the source, and run the parameter callback."""
        ctx.set_source(self.name, source)
        converted = self.type_cast_value(ctx, value)
        if self.callback is not None:
            converted = self.callback(ctx, self, converted)
        return converted


def _lookup_default_map(ctx, param):
    dm = ctx.default_map
    if not dm or param.name not in dm:
        return _MISSING
    return dm[param.name]


def _subcommand_path(ctx):
    """Names of the subcommands below the top-level command (FP-07)."""
    names = []
    node = ctx
    while node is not None and node.parent is not None:
        names.append(node.info_name)
        node = node.parent
    names.reverse()
    return names[1:]


class Option(Parameter):
    """A named parameter introduced by a prefix character."""

    param_type_name = "option"

    def __init__(self, param_decls=None, is_flag=None, flag_value=None, count=False,
                 prompt=False, prompt_required=True, hide_input=False,
                 confirmation_prompt=False, **attrs):
        decls = param_decls or []
        self.opts, self.secondary_opts, dest = _split_option_decls(decls)
        self.name = dest
        if count:
            is_flag = False
            attrs.setdefault("type", INT)
            attrs.setdefault("default", 0)
        if is_flag is None:
            is_flag = isinstance(attrs.get("default"), bool) and attrs.get("type") is None
            if not self.opts and not count:
                is_flag = False
        if self.secondary_opts and is_flag is None:
            is_flag = True
        self.is_flag = bool(is_flag or self.secondary_opts)
        self.count = count
        if self.is_flag and attrs.get("type") is None:
            attrs["type"] = BOOL
        if self.is_flag and attrs.get("default") is None:
            attrs["default"] = False
        if flag_value is None:
            flag_value = not bool(attrs.get("default")) if self.is_flag else None
        self.flag_value = flag_value
        self.prompt = prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.confirmation_prompt = confirmation_prompt
        super().__init__(None, **attrs)
        if self.is_flag and self.prompt:
            raise ValueError("a flag cannot be prompted")
        if self.deprecated and self.prompt:
            raise ValueError("deprecated option cannot use a prompt")

    @property
    def human_name(self):
        return "/".join(self.opts) or self.name

    def get_metavar(self):
        if self.metavar is not None:
            return self.metavar
        if self.is_flag or self.count:
            return None
        return self.type.get_metavar(self) or self.type.name.upper()

    def _convert_occurrence(self, ctx, value):
        # Flag values come from the parser already in their final form.
        if self.is_flag or self.count:
            return value
        return super()._convert_occurrence(ctx, value)

    def _from_env_value(self, ctx, raw):
        if not self.is_flag:
            return self.split_envvar(raw)
        text = raw.strip().lower()
        if text in _TRUE:
            return True
        if text in _FALSE or text == "":
            return False
        if self.flag_value is not None and raw == str(self.flag_value):
            return self.flag_value
        raise BadParameter(f"{raw!r} is not a valid boolean.", ctx=ctx, param=self)


def _split_option_decls(decls):
    """Split declarations into (flag names, off-flag names, destination)."""
    opts, secondary, dest = [], [], None
    for decl in decls:
        if decl and decl[0] in _PREFIXES:
            if "/" in decl[1:]:
                on, off = decl.split("/", 1)
                opts.append(on)
                secondary.append(off)
            else:
                opts.append(decl)
        else:
            if dest is not None:
                raise ValueError(f"name defined twice: {dest!r} and {decl!r}")
            dest = decl
    if dest is None:
        if not opts:
            raise TypeError("an option needs a name or flag declaration")
        dest = _derive_dest(opts)
    return opts, secondary, dest.replace("-", "_")


def _derive_dest(opts):
    """Destination from flag names: identifier first, then long, then short (FP-03)."""
    for o in opts:
        candidate = o.lstrip(_PREFIXES).replace("-", "_")
        if _IDENT.match(candidate):
            return candidate
    for o in opts:
        if o.startswith("--"):
            return o[2:].replace("-", "_")
    return opts[0].lstrip(_PREFIXES).replace("-", "_")


class Argument(Parameter):
    """A positional parameter."""

    param_type_name = "argument"

    def __init__(self, param_decls=None, required=None, **attrs):
        if not param_decls or len(param_decls) != 1:
            raise TypeError("an argument takes exactly one destination name")
        self.name = param_decls[0].replace("-", "_")
        self.opts = []
        self.secondary_opts = []
        if required is None:
            # An argument with neither a default nor an optional marking is required.
            required = attrs.get("default") is None
        super().__init__(None, required=required, **attrs)
        if self.deprecated and self.required:
            raise ValueError("deprecated argument cannot be required")

    @property
    def human_name(self):
        return self.name.upper()

    def get_metavar(self):
        if self.metavar is not None:
            return self.metavar
        return self.name.upper()
