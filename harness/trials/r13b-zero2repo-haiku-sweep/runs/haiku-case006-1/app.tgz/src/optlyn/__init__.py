"""Optlyn: a command line interface composition kit.

Declare commands, groups, options, and arguments with decorators; Optlyn parses
the argument list, converts values, generates help, and dispatches to callbacks.
"""

from .core import (
    Argument,
    Command,
    CommandCollection,
    Context,
    Group,
    Option,
    Parameter,
)
from .decorators import (
    argument,
    command,
    confirmation_option,
    custom_version_option,
    get_current_context,
    group,
    help_option,
    make_pass_decorator,
    option,
    pass_context,
    pass_obj,
    password_option,
    version_option,
)
from .exceptions import Abort, BadParameter, Exit, UsageError
from .paramtypes import (
    BOOL,
    FLOAT,
    INT,
    STRING,
    UNPROCESSED,
    UUID,
    Choice,
    DateTime,
    File,
    FloatRange,
    IntRange,
    ParamType,
    Path,
    Tuple,
)
from .termui import (
    clear,
    confirm,
    echo_via_pager,
    edit,
    getchar,
    get_pager_file,
    launch,
    pause,
    progressbar,
    prompt,
)
from .utils import echo, format_filename, get_app_dir, open_file, secho, style, unstyle

__version__ = "0.1.0"

__all__ = [
    # Declaration
    "command",
    "group",
    "option",
    "argument",
    "help_option",
    "version_option",
    "custom_version_option",
    "password_option",
    "confirmation_option",
    "pass_context",
    "pass_obj",
    "make_pass_decorator",
    # Classes
    "Command",
    "Group",
    "CommandCollection",
    "Context",
    "Option",
    "Parameter",
    "Argument",
    "ParamType",
    "BadParameter",
    "Abort",
    "UsageError",
    "Exit",
    # Types
    "STRING",
    "INT",
    "FLOAT",
    "BOOL",
    "UUID",
    "UNPROCESSED",
    "Choice",
    "DateTime",
    "IntRange",
    "FloatRange",
    "Tuple",
    "File",
    "Path",
    # Terminal helpers
    "echo",
    "secho",
    "style",
    "unstyle",
    "echo_via_pager",
    "get_pager_file",
    "progressbar",
    "prompt",
    "confirm",
    "getchar",
    "pause",
    "edit",
    "launch",
    "clear",
    "get_app_dir",
    "get_current_context",
    "format_filename",
    "open_file",
]
