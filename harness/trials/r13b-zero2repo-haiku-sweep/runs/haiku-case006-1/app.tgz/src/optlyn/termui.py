"""Interactive terminal helpers: prompts, pager, progress bar, editor, and launch."""

import os
import shlex
import subprocess
import sys
import tempfile
import time
from contextlib import contextmanager

from . import utils as _utils
from .exceptions import Abort, BadParameter
from .paramtypes import convert_type
from .utils import _NonClosing, echo, isatty, peek_context


def _interactive():
    return isatty(sys.stdin) or isatty(sys.stdout)


def _read_hidden_line():
    """Read a line from a terminal without echoing it."""
    import termios

    fd = sys.stdin.fileno()
    old = termios.tcgetattr(fd)
    new = termios.tcgetattr(fd)
    new[3] &= ~termios.ECHO
    termios.tcsetattr(fd, termios.TCSADRAIN, new)
    try:
        return sys.stdin.readline()
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)
        echo()


def _prompt_line(text, hide_input=False, err=False):
    """Print ``text``, read one line, and raise Abort at end of input."""
    echo(text, nl=False, err=err)
    stream = sys.stdin
    tty = isatty(stream)
    if hide_input and tty:
        line = _read_hidden_line()
    else:
        line = stream.readline()
    if not line:
        echo(err=err)
        raise Abort()
    line = line.rstrip("\r\n")
    if not tty and not getattr(stream, "echoes_input", False):
        if hide_input:
            echo(err=err)
        else:
            echo(line, err=err)
    return line


def prompt(
    text,
    default=None,
    hide_input=False,
    confirmation_prompt=False,
    type=None,
    value_proc=None,
    prompt_suffix=": ",
    show_default=True,
    err=False,
    show_choices=True,
):
    """Ask for a value, convert it with ``type``, and return it."""
    ptype = convert_type(type, default)
    ctx = peek_context()
    suffix = prompt_suffix
    if show_default and default is not None and not hide_input:
        shown = default
        if not isinstance(shown, str):
            shown = str(shown)
        text = f"{text} [{shown}]"
    while True:
        value = _prompt_line(f"{text}{suffix}", hide_input, err)
        if not value:
            if default is not None:
                return ptype.convert(default, None, ctx)
            continue
        try:
            result = ptype.convert(value, None, ctx)
        except BadParameter as e:
            echo(f"Error: {e.format_message()}", err=True)
            continue
        if value_proc is not None:
            result = value_proc(result)
        if confirmation_prompt:
            second = _prompt_line("Repeat for confirmation" + suffix, hide_input, err)
            if second != value:
                echo("Error: The two entered values do not match.", err=True)
                continue
        return result


def confirm(text, default=False, abort=False, prompt_suffix=": ", show_default=True, err=False):
    """Ask a yes/no question and return a boolean."""
    if default is None:
        hint = "[y/n]"
    elif default:
        hint = "[Y/n]"
    else:
        hint = "[y/N]"
    while True:
        answer = _prompt_line(f"{text} {hint}{prompt_suffix}", False, err).strip().lower()
        if answer in ("y", "yes"):
            result = True
            break
        if answer in ("n", "no"):
            result = False
            break
        if answer == "" and default is not None:
            result = bool(default)
            break
        echo("Error: invalid input", err=True)
    if abort and not result:
        raise Abort()
    return result


def _read_raw_char(fd):
    """Read one byte from a terminal in raw mode, restoring the mode afterwards."""
    try:
        import termios
        import tty
    except ImportError:
        return os.read(fd, 1).decode("utf-8", "replace")
    old = termios.tcgetattr(fd)
    try:
        tty.setraw(fd)
        return os.read(fd, 1).decode("utf-8", "replace")
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old)


def getchar(echo=False):
    """Read one character from the terminal, even when stdin is a pipe."""
    try:
        fd = os.open("/dev/tty", os.O_RDONLY)
    except OSError:
        fd = None
    try:
        if fd is None:
            ch = sys.stdin.read(1)
        else:
            ch = _read_raw_char(fd)
    finally:
        if fd is not None:
            os.close(fd)
    if ch == "\x03":
        raise KeyboardInterrupt()
    if ch in ("\x04", ""):
        raise EOFError()
    if echo:
        _utils.echo(ch, nl=False)
    return ch


def pause(info=None, err=False):
    """Wait for a key press when running interactively; otherwise return immediately."""
    if not _interactive():
        return
    echo(info if info is not None else "Press any key to continue...", err=err, nl=False)
    try:
        getchar()
    finally:
        echo(err=err)


def edit(text=None, editor=None, env=None, require_save=True, extension=".txt", filename=None):
    """Open an editor on text or a file. Returns the saved text, or None."""
    editor = editor or os.environ.get("VISUAL") or os.environ.get("EDITOR") or "vi"
    command = shlex.split(editor) if isinstance(editor, str) else list(editor)
    if filename is not None:
        subprocess.call(command + [os.fspath(filename)], env=env)
        return None
    fd, path = tempfile.mkstemp(suffix=extension)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as f:
            if text:
                f.write(text)
        before = os.stat(path).st_mtime_ns
        subprocess.call(command + [path], env=env)
        with open(path, encoding="utf-8", newline="") as f:
            result = f.read()
        if require_save and os.stat(path).st_mtime_ns == before:
            return None
        return result.replace("\r\n", "\n")
    finally:
        try:
            os.remove(path)
        except OSError:
            pass


def launch(url, wait=False, locate=False):
    """Open ``url`` or a file with the default application. Returns the process status."""
    if sys.platform == "darwin":
        command = ["open"]
        if locate:
            command.append("-R")
    elif sys.platform.startswith("win"):
        try:
            os.startfile(os.fspath(url))  # type: ignore[attr-defined]
        except OSError:
            return 1
        return 0
    else:
        command = ["xdg-open"]
    command.append(os.fspath(url))
    try:
        proc = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    except OSError:
        return 127
    if wait:
        return proc.wait()
    return 0


def clear():
    """Clear the terminal screen (no-op when stdout is not a terminal)."""
    if isatty(sys.stdout):
        echo("\033[2J\033[H", nl=False)


class ProgressBar:
    """A progress bar that is also an iterator over the wrapped items."""

    def __init__(self, iterable=None, length=None, label=None, hidden=False, width=36):
        self.iterable = iterable
        if length is None and iterable is not None:
            try:
                length = len(iterable)
            except TypeError:
                length = None
        self.length = length
        self.label = label or ""
        self.hidden = hidden
        self.width = width
        self.pos = 0
        self.start = time.time()
        self.is_tty = (not hidden) and isatty(sys.stdout)

    def __enter__(self):
        if not self.hidden and not self.is_tty and self.label:
            echo(self.label)
        return self

    def __exit__(self, *exc):
        if self.is_tty:
            echo()
        return False

    def __iter__(self):
        if self.iterable is None:
            return
        for item in self.iterable:
            yield item
            self.update(1)

    def update(self, n_steps):
        self.pos += n_steps
        if self.is_tty:
            self.render()

    def render(self):
        if self.length:
            done = min(self.pos / self.length, 1.0)
            filled = int(self.width * done)
            bar = "#" * filled + "-" * (self.width - filled)
            elapsed = time.time() - self.start
            remaining = (elapsed / self.pos * (self.length - self.pos)) if self.pos else 0
            eta = f"  eta {int(remaining)}s"
            line = f"{self.label} [{bar}] {self.pos}/{self.length}{eta}"
        else:
            line = f"{self.label} {self.pos}"
        echo(f"\r{line}", nl=False)


def progressbar(iterable=None, length=None, label=None, hidden=False, **options):
    return ProgressBar(iterable=iterable, length=length, label=label, hidden=hidden, **options)


def _pager_command():
    return os.environ.get("PAGER") or "less"


def echo_via_pager(text_or_generator, color=None):
    """Write text through the pager when interactive; otherwise to stdout."""
    if callable(text_or_generator):
        text_or_generator = text_or_generator()
    if isinstance(text_or_generator, str):
        chunks = [text_or_generator]
    else:
        chunks = iter(text_or_generator)
    if not _interactive():
        for chunk in chunks:
            echo(chunk, nl=False, color=color)
        return
    proc = subprocess.Popen(shlex.split(_pager_command()), stdin=subprocess.PIPE)
    try:
        for chunk in chunks:
            proc.stdin.write(str(chunk).encode("utf-8"))
            proc.stdin.flush()
    finally:
        try:
            proc.stdin.close()
        except OSError:
            pass
        proc.wait()


@contextmanager
def get_pager_file(color=None):
    """Yield a writable text stream routed through the pager when interactive."""
    if not _interactive():
        yield _NonClosing(sys.stdout)
        return
    proc = subprocess.Popen(shlex.split(_pager_command()), stdin=subprocess.PIPE)
    stream = proc.stdin
    try:
        yield _PagerWriter(stream)
    finally:
        try:
            stream.close()
        except OSError:
            pass
        proc.wait()


class _PagerWriter:
    def __init__(self, binary):
        self._binary = binary

    def write(self, text):
        self._binary.write(str(text).encode("utf-8"))
        self._binary.flush()
        return len(text)

    def flush(self):
        self._binary.flush()


__all__ = [
    "prompt",
    "confirm",
    "getchar",
    "pause",
    "edit",
    "launch",
    "clear",
    "progressbar",
    "echo_via_pager",
    "get_pager_file",
]
