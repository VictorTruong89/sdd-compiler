"""In-process runner that invokes a command with tokens and captures its output."""

import io
import os
import shutil
import sys
import tempfile
from contextlib import contextmanager


class _OrderedBuffer(io.BytesIO):
    """A binary buffer that also records every write into a shared, ordered log."""

    def __init__(self, log, name):
        super().__init__()
        self._log = log
        self._name = name

    def write(self, data):
        data = bytes(data)
        self._log.append((self._name, data))
        return super().write(data)


class _InputStream(io.TextIOWrapper):
    """Standard input for the runner; optionally echoes every line it reads."""

    def __init__(self, data, charset, echo_target=None):
        super().__init__(io.BytesIO(data), encoding=charset)
        self._echo_target = echo_target
        self.echoes_input = echo_target is not None

    def readline(self, *args):
        line = super().readline(*args)
        if line and self._echo_target is not None:
            self._echo_target.write(line)
            self._echo_target.flush()
        return line


class Result:
    """The outcome of :meth:`CliRunner.invoke`."""

    def __init__(self, runner, stdout_bytes, stderr_bytes, output_bytes, return_value, exit_code, exception, exc_info):
        self.runner = runner
        self.stdout_bytes = stdout_bytes
        self.stderr_bytes = stderr_bytes
        self.output_bytes = output_bytes
        self.return_value = return_value
        self.exit_code = exit_code
        self.exception = exception
        self.exc_info = exc_info

    @property
    def output(self):
        return self.output_bytes.decode(self.runner.charset, "replace")

    @property
    def stdout(self):
        return self.stdout_bytes.decode(self.runner.charset, "replace")

    @property
    def stderr(self):
        return self.stderr_bytes.decode(self.runner.charset, "replace")

    def __repr__(self):
        return f"<Result exit_code={self.exit_code}>"


class CliRunner:
    """Invokes commands in-process, capturing standard streams and the exit status."""

    def __init__(self, charset="utf-8", env=None, echo_stdin=False, catch_exceptions=True, capture="sys"):
        if capture not in ("sys", "fd"):
            raise ValueError("capture must be 'sys' or 'fd'.")
        self.charset = charset
        self.env = dict(env or {})
        self.echo_stdin = echo_stdin
        self.catch_exceptions = catch_exceptions
        self.capture = capture

    @contextmanager
    def isolation(self, input=None, env=None, color=False):
        data = input.encode(self.charset) if isinstance(input, str) else (input or b"")
        log = []
        if self.capture == "fd":
            yield from self._fd_isolation(data, log, env)
            return

        stdout = io.TextIOWrapper(_OrderedBuffer(log, "stdout"), encoding=self.charset, write_through=True)
        stderr = io.TextIOWrapper(_OrderedBuffer(log, "stderr"), encoding=self.charset, write_through=True)
        stdin = _InputStream(data, self.charset, stdout if self.echo_stdin else None)
        try:
            with self._patched_env(env), self._swap_streams(stdin, stdout, stderr):
                yield None, None, log
        finally:
            for stream in (stdout, stderr, stdin):
                stream.flush()
                stream.detach()

    def _fd_isolation(self, data, log, env):
        out_file = tempfile.TemporaryFile()
        err_file = tempfile.TemporaryFile()
        saved_out = os.dup(1)
        saved_err = os.dup(2)
        stdout = io.TextIOWrapper(out_file, encoding=self.charset, write_through=True)
        stderr = io.TextIOWrapper(err_file, encoding=self.charset, write_through=True)
        stdin = _InputStream(data, self.charset, stdout if self.echo_stdin else None)
        os.dup2(out_file.fileno(), 1)
        os.dup2(err_file.fileno(), 2)
        try:
            with self._patched_env(env), self._swap_streams(stdin, stdout, stderr):
                yield None, None, log
        finally:
            for stream in (stdout, stderr, stdin):
                stream.flush()
            os.dup2(saved_out, 1)
            os.dup2(saved_err, 2)
            os.close(saved_out)
            os.close(saved_err)
            out_file.seek(0)
            err_file.seek(0)
            log.append(("stdout", out_file.read()))
            log.append(("stderr", err_file.read()))
            for stream in (stdout, stderr, stdin):
                stream.detach()
            out_file.close()
            err_file.close()

    @contextmanager
    def _swap_streams(self, stdin, stdout, stderr):
        saved = sys.stdin, sys.stdout, sys.stderr
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        try:
            yield
        finally:
            sys.stdin, sys.stdout, sys.stderr = saved

    @contextmanager
    def _patched_env(self, overrides):
        merged = dict(self.env)
        merged.update(overrides or {})
        saved = {}
        for key, value in merged.items():
            saved[key] = os.environ.get(key)
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = str(value)
        try:
            yield
        finally:
            for key, value in saved.items():
                if value is None:
                    os.environ.pop(key, None)
                else:
                    os.environ[key] = value

    def invoke(self, cli, args=None, input=None, env=None, catch_exceptions=None, color=False, **extra):
        """Run ``cli`` with the token list ``args`` and return a :class:`Result`."""
        if catch_exceptions is None:
            catch_exceptions = self.catch_exceptions
        prog_name = extra.pop("prog_name", None) or "cli"
        standalone_mode = extra.pop("standalone_mode", True)
        extra.setdefault("color", color)
        exception = None
        exit_code = 0
        exc_info = None
        return_value = None
        if args is None:
            args = []
        elif isinstance(args, str):
            args = args.split()

        with self.isolation(input=input, env=env, color=color) as streams:
            _, _, log = streams
            try:
                return_value = cli.main(
                    args=list(args),
                    prog_name=prog_name,
                    standalone_mode=standalone_mode,
                    **extra,
                )
            except SystemExit as e:
                exc_info = sys.exc_info()
                if e.code is None:
                    exit_code = 0
                elif isinstance(e.code, int):
                    exit_code = e.code
                else:
                    sys.stdout.write(str(e.code) + "\n")
                    exit_code = 1
                if exit_code != 0:
                    exception = e
            except Exception as e:
                if not catch_exceptions:
                    raise
                exception = e
                exit_code = 1
                exc_info = sys.exc_info()
            finally:
                sys.stdout.flush()
        out_bytes, err_bytes, combined = _collect(log)
        return Result(self, out_bytes, err_bytes, combined, return_value, exit_code, exception, exc_info)

    def isolated_filesystem(self, temp_dir=None):
        return _isolated_filesystem(temp_dir)


def _collect(log):
    out_bytes = b"".join(chunk for name, chunk in log if name == "stdout")
    err_bytes = b"".join(chunk for name, chunk in log if name == "stderr")
    combined = b"".join(chunk for _, chunk in log)
    return out_bytes, err_bytes, combined


@contextmanager
def _isolated_filesystem(temp_dir=None):
    cwd = os.getcwd()
    path = tempfile.mkdtemp(dir=temp_dir)
    os.chdir(path)
    try:
        yield path
    finally:
        os.chdir(cwd)
        if temp_dir is None:
            shutil.rmtree(path, ignore_errors=True)


__all__ = ["CliRunner", "Result"]
