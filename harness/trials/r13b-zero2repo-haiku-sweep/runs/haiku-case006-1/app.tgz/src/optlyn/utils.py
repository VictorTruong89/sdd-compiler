"""Terminal output, styling, file opening, and filesystem helpers."""

import os
import re
import sys
import tempfile
import threading

from .exceptions import FileError

_ansi_re = re.compile(r"\033\[[;?0-9]*[a-zA-Z]")

_local = threading.local()


def _stack():
    stack = getattr(_local, "stack", None)
    if stack is None:
        stack = _local.stack = []
    return stack


def push_context(ctx):
    _stack().append(ctx)


def pop_context():
    _stack().pop()


def peek_context():
    stack = _stack()
    return stack[-1] if stack else None


def isatty(stream):
    try:
        return bool(stream.isatty())
    except Exception:
        return False


def strip_ansi(text):
    return _ansi_re.sub("", text)


def unstyle(text):
    """Remove ANSI style sequences from ``text``."""
    return strip_ansi(text)


def _write_bytes(file, data):
    buffer = getattr(file, "buffer", None)
    if buffer is None:
        file.write(data.decode("utf-8", "replace"))
    else:
        file.flush()
        buffer.write(data)
    file.flush()


def _write_text(file, text):
    encoding = (getattr(file, "encoding", None) or "").lower()
    if encoding in ("ascii", "us-ascii"):
        # Misconfigured ASCII-only streams still receive the text, as UTF-8.
        _write_bytes(file, text.encode("utf-8"))
        return
    try:
        file.write(text)
    except UnicodeEncodeError:
        _write_bytes(file, text.encode("utf-8"))
    file.flush()


def echo(message=None, file=None, nl=True, err=False, color=None):
    """Write ``message`` to stdout (or stderr), stripping styles when not a terminal."""
    if file is None:
        file = sys.stderr if err else sys.stdout
    if color is None:
        from .core import _current_color  # late import avoids a cycle

        color = _current_color()
    if message is None:
        message = ""
    if isinstance(message, (bytes, bytearray)):
        data = bytes(message)
        if nl:
            data += b"\n"
        _write_bytes(file, data)
        return
    text = str(message)
    if nl:
        text += "\n"
    if color is False or (color is None and not isatty(file)):
        text = strip_ansi(text)
    _write_text(file, text)


_COLORS = {
    "black": 0,
    "red": 1,
    "green": 2,
    "yellow": 3,
    "blue": 4,
    "magenta": 5,
    "cyan": 6,
    "white": 7,
}

_SWITCHES = (
    ("bold", 1, 22),
    ("dim", 2, 22),
    ("italic", 3, 23),
    ("underline", 4, 24),
    ("blink", 5, 25),
    ("reverse", 7, 27),
    ("strikethrough", 9, 29),
    ("overline", 53, 55),
)


def _color_code(color, bg):
    if isinstance(color, str):
        name = color
        bright = False
        if name.startswith("bright_"):
            bright = True
            name = name[len("bright_"):]
        if name == "reset" and not bright:
            return "49" if bg else "39"
        if name in _COLORS:
            base = 40 if bg else 30
            if bright:
                base += 60
            return str(base + _COLORS[name])
        raise TypeError(f"Unknown color {color!r}.")
    if isinstance(color, int) and not isinstance(color, bool) and 0 <= color <= 255:
        return f"{48 if bg else 38};5;{color}"
    if (
        isinstance(color, (tuple, list))
        and len(color) == 3
        and all(isinstance(c, int) and not isinstance(c, bool) and 0 <= c <= 255 for c in color)
    ):
        return f"{48 if bg else 38};2;{color[0]};{color[1]};{color[2]}"
    raise TypeError(f"Invalid color {color!r}.")


def style(
    text,
    fg=None,
    bg=None,
    bold=None,
    dim=None,
    underline=None,
    overline=None,
    italic=None,
    blink=None,
    reverse=None,
    strikethrough=None,
    reset=True,
):
    """Wrap ``text`` in ANSI SGR sequences."""
    bits = []
    if fg is not None:
        bits.append(_color_code(fg, False))
    if bg is not None:
        bits.append(_color_code(bg, True))
    values = {
        "bold": bold,
        "dim": dim,
        "underline": underline,
        "overline": overline,
        "italic": italic,
        "blink": blink,
        "reverse": reverse,
        "strikethrough": strikethrough,
    }
    for key, on_code, off_code in _SWITCHES:
        value = values[key]
        if value is None:
            continue
        bits.append(str(on_code if value else off_code))
    text = str(text)
    if bits:
        text = f"\033[{';'.join(bits)}m{text}"
    if reset:
        text = f"{text}\033[0m"
    return text


def secho(message=None, file=None, nl=True, err=False, color=None, **styles):
    if message is not None:
        message = style(message, **styles)
    echo(message, file=file, nl=nl, err=err, color=color)


class _NonClosing:
    """Proxy over a standard stream whose ``close`` only flushes."""

    def __init__(self, stream):
        self.__dict__["_stream"] = stream

    def __getattr__(self, name):
        return getattr(self._stream, name)

    def __iter__(self):
        return iter(self._stream)

    def close(self):
        try:
            self._stream.flush()
        except Exception:
            pass

    @property
    def closed(self):
        return False

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


class _EncodedStd:
    """Text view over a binary standard stream using an explicit encoding."""

    def __init__(self, buffer, encoding, errors):
        self._buffer = buffer
        self._encoding = encoding
        self._errors = errors

    def write(self, text):
        self._buffer.write(text.encode(self._encoding, self._errors))
        return len(text)

    def read(self, size=-1):
        return self._buffer.read(size).decode(self._encoding, self._errors)

    def readline(self):
        return self._buffer.readline().decode(self._encoding, self._errors)

    def __iter__(self):
        while True:
            line = self.readline()
            if not line:
                return
            yield line

    def flush(self):
        self._buffer.flush()

    def close(self):
        self.flush()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


def _std_stream(mode, encoding, errors):
    writing = any(c in mode for c in "wax+")
    binary = "b" in mode
    stream = sys.stdout if writing else sys.stdin
    if binary:
        return _NonClosing(getattr(stream, "buffer", stream))
    if encoding:
        buffer = getattr(stream, "buffer", None)
        if buffer is not None:
            return _EncodedStd(buffer, encoding, errors or "strict")
    return _NonClosing(stream)


class LazyFile:
    """A file that is opened on first I/O (or immediately when ``eager``)."""

    def __init__(self, filename, mode, encoding=None, errors="strict", atomic=False, eager=True):
        self.__dict__.update(
            name=filename,
            mode=mode,
            encoding=encoding,
            errors=errors,
            atomic=atomic,
            _f=None,
            _tmp=None,
            _closed=False,
        )
        if eager:
            self._open()

    def _open(self):
        if self._f is not None:
            return self._f
        writing = any(c in self.mode for c in "wax+")
        text_encoding = None if "b" in self.mode else self.encoding
        errors = None if "b" in self.mode else self.errors
        if self.atomic and writing:
            target = os.path.abspath(self.name)
            directory = os.path.dirname(target)
            fd, tmp = tempfile.mkstemp(dir=directory, prefix=".__atomic-write")
            self.__dict__["_tmp"] = tmp
            self.__dict__["_f"] = os.fdopen(fd, self.mode, encoding=text_encoding, errors=errors)
        else:
            self.__dict__["_f"] = open(self.name, self.mode, encoding=text_encoding, errors=errors)
        return self._f

    def _io_file(self):
        """Open for I/O; a failure here is a general error, not a usage error."""
        try:
            return self._open()
        except OSError as e:
            raise FileError(self.name, e.strerror or str(e)) from e

    def __getattr__(self, name):
        return getattr(self._io_file(), name)

    def __iter__(self):
        return iter(self._io_file())

    @property
    def closed(self):
        return self._closed

    def close(self):
        if self._closed:
            return
        self.__dict__["_closed"] = True
        if self._f is not None:
            self._f.close()
            if self._tmp is not None:
                os.replace(self._tmp, os.path.abspath(self.name))

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False

    def __del__(self):  # pragma: no cover - best effort cleanup
        try:
            self.close()
        except Exception:
            pass


def open_file(filename, mode="r", encoding=None, errors="strict", lazy=False, atomic=False):
    """Open ``filename`` (``-`` means the standard stream for the mode)."""
    if filename == "-":
        return _std_stream(mode, encoding, errors)
    writing = any(c in mode for c in "wax+")
    if not writing:
        return LazyFile(filename, mode, encoding, errors, atomic=False, eager=not lazy)
    return LazyFile(filename, mode, encoding, errors, atomic=atomic, eager=not lazy)


def format_filename(filename, shorten=False):
    """Return ``filename`` as printable text that always encodes as strict UTF-8."""
    if hasattr(filename, "__fspath__"):
        filename = os.fspath(filename)
    if isinstance(filename, bytes):
        filename = os.fsdecode(filename)
    if shorten:
        filename = os.path.basename(filename)
    out = []
    for ch in filename:
        code = ord(ch)
        if 0xDC80 <= code <= 0xDCFF:
            out.append(f"\\x{code - 0xDC00:02x}")
        elif 0xD800 <= code <= 0xDFFF:
            out.append(f"\\u{code:04x}")
        elif ch == "\\":
            out.append("\\\\")
        else:
            out.append(ch)
    return "".join(out)


def get_app_dir(app_name, roaming=True, force_posix=False):
    """Return the per-user configuration directory for ``app_name``."""
    if force_posix:
        folder = re.sub(r"\s+", "-", app_name.lower())
        return os.path.join(os.path.expanduser("~"), "." + folder)
    if sys.platform == "darwin":
        return os.path.join(os.path.expanduser("~"), "Library", "Application Support", app_name)
    if sys.platform.startswith("win"):
        base = os.environ.get("APPDATA" if roaming else "LOCALAPPDATA")
        if not base:
            base = os.path.join(os.path.expanduser("~"), "AppData", "Roaming" if roaming else "Local")
        return os.path.join(base, app_name)
    folder = re.sub(r"\s+", "-", app_name.lower())
    config_home = os.environ.get("XDG_CONFIG_HOME") or os.path.join(os.path.expanduser("~"), ".config")
    return os.path.join(config_home, folder)


__all__ = [
    "echo",
    "secho",
    "style",
    "unstyle",
    "strip_ansi",
    "open_file",
    "format_filename",
    "get_app_dir",
    "isatty",
]
