"""POSIX-style tokenizing: option matching, value consumption, and positional unpacking."""

from collections import deque

from .exceptions import BadOptionUsage, NoSuchOption

LONG_PREFIXES = ("--", "//", "++")


class Literal(str):
    """A token that came after a ``--`` separator; it is never read as an option."""


class _Missing:
    def __repr__(self):
        return "<missing>"


MISSING = _Missing()


class NeedsValue:
    """Marks a prompting option that was given without a value."""

    def __repr__(self):
        return "<needs value>"


NEEDS_VALUE = NeedsValue()


class OptionParser:
    """Scans a token list and collects option values and leftover positional tokens."""

    def __init__(self, ctx, options, interspersed=True):
        self.ctx = ctx
        self.interspersed = interspersed
        self.ignore_unknown = bool(ctx.ignore_unknown_options)
        self.normalize = ctx.token_normalize_func
        self._names = {}
        self.prefixes = {"-"}
        for opt in options:
            for name in opt.opts:
                self._add(name, opt, True)
            for name in opt.secondary_opts:
                self._add(name, opt, False)

    def _add(self, name, opt, primary):
        self.prefixes.add(name[0])
        self._names.setdefault(self._key(name), (opt, primary))

    def _key(self, name):
        return self.normalize(name) if self.normalize is not None else name

    def _is_option(self, arg):
        return len(arg) > 1 and arg[0] in self.prefixes

    def parse_args(self, args):
        """Return ``(opts, largs, order)``.

        ``opts`` maps destinations to raw values, ``largs`` holds positional tokens
        (literal tokens wrapped in :class:`Literal`), and ``order`` lists the options
        in the order they first appeared.
        """
        opts = {}
        order = []
        largs = []
        rargs = deque(args)
        while rargs:
            arg = rargs.popleft()
            if arg == "--":
                largs.extend(Literal(tok) for tok in rargs)
                rargs.clear()
                break
            if self._is_option(arg):
                leftover = self._process_opt(arg, rargs, opts, order)
                if leftover is not None:
                    largs.append(leftover)
                continue
            largs.append(arg)
            if not self.interspersed:
                largs.extend(rargs)
                rargs.clear()
                break
        return opts, largs, order

    def _process_opt(self, arg, rargs, opts, order):
        key = self._key(arg)
        if key in self._names:
            opt, primary = self._names[key]
            self._take(opt, primary, arg, None, rargs, opts, order)
            return None
        if arg[:2] in LONG_PREFIXES:
            if "=" in arg:
                head, _, value = arg.partition("=")
                head_key = self._key(head)
                if head_key in self._names:
                    opt, primary = self._names[head_key]
                    self._take(opt, primary, head, value, rargs, opts, order)
                    return None
            if self.ignore_unknown:
                return arg
            raise NoSuchOption(arg, ctx=self.ctx)
        prefix = arg[0]
        stack = arg[1:]
        for index, char in enumerate(stack):
            name = prefix + char
            entry = self._names.get(self._key(name))
            if entry is None:
                if self.ignore_unknown:
                    return prefix + stack[index:]
                raise NoSuchOption(name, ctx=self.ctx)
            opt, primary = entry
            rest = stack[index + 1 :]
            if opt.takes_value:
                self._take(opt, primary, name, rest if rest else None, rargs, opts, order)
                return None
            self._take(opt, primary, name, None, rargs, opts, order)
        return None

    def _take(self, opt, primary, name, attached, rargs, opts, order):
        if opt.is_flag:
            if attached is not None:
                raise BadOptionUsage(f"Option {name!r} does not take a value.", ctx=self.ctx)
            value = opt.flag_value if primary else False
            self._store(opt, value, opts, order)
            return
        if opt.count:
            self._store(opt, 1, opts, order)
            return
        if opt.is_optional_value:
            if attached is None and (not rargs or self._is_option(rargs[0])):
                value = NEEDS_VALUE if opt.prompt is not None else opt.flag_value
                self._store(opt, value, opts, order)
                return
            if attached is None:
                attached = rargs.popleft()
            self._store(opt, attached, opts, order)
            return
        values = [] if attached is None else [attached]
        needed = opt.nargs
        while len(values) < needed:
            if not rargs:
                if needed == 1:
                    raise BadOptionUsage(f"Option {name!r} requires an argument.", ctx=self.ctx)
                raise BadOptionUsage(f"Option {name!r} requires {needed} arguments.", ctx=self.ctx)
            values.append(rargs.popleft())
        value = values[0] if needed == 1 else tuple(values)
        self._store(opt, value, opts, order)

    @staticmethod
    def _store(opt, value, opts, order):
        dest = opt.name
        if opt.count:
            opts[dest] = opts.get(dest, 0) + 1
        elif opt.multiple:
            opts.setdefault(dest, []).append(value)
        else:
            opts[dest] = value
        if opt not in order:
            order.append(opt)


def unpack_args(args, nargs_spec):
    """Distribute ``args`` over positional specs (``1``, ``n``, or ``-1`` for variadic).

    Returns ``(values, leftover)``. Unary specs yield a token or ``None``; fixed
    arities yield a tuple of up to ``n`` tokens; the variadic spec yields a list.
    """
    args = list(args)
    count = len(nargs_spec)
    values = [None] * count
    variadic = next((i for i, n in enumerate(nargs_spec) if n == -1), None)
    pos = 0
    front = range(count) if variadic is None else range(variadic)
    for i in front:
        n = nargs_spec[i]
        chunk = args[pos : pos + n]
        pos += len(chunk)
        values[i] = _shape(chunk, n)
    if variadic is None:
        return values, args[pos:]
    end = len(args)
    for i in range(count - 1, variadic, -1):
        n = nargs_spec[i]
        start = max(pos, end - n)
        values[i] = _shape(args[start:end], n)
        end = start
    values[variadic] = args[pos:end]
    return values, []


def _shape(chunk, n):
    if n == 1:
        return chunk[0] if chunk else None
    return tuple(chunk)
