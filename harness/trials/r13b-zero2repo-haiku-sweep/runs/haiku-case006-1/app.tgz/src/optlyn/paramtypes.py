"""Parameter types: conversion, metavars, and completion hooks."""

import datetime
import enum
import os
import pathlib
import re
import stat
import uuid

from .exceptions import BadParameter
from .utils import format_filename, open_file


class CompletionItem:
    """A completion suggestion: a value, optional help, and a kind."""

    def __init__(self, value, help=None, type="plain"):
        self.value = value
        self.help = help
        self.type = type

    def __repr__(self):
        return f"CompletionItem({self.value!r}, {self.help!r}, {self.type!r})"


class ParamType:
    """Base class for parameter types."""

    name = "text"
    is_composite = False

    def __call__(self, value, param=None, ctx=None):
        if value is not None:
            return self.convert(value, param, ctx)
        return None

    def convert(self, value, param, ctx):
        return value

    def get_metavar(self, param):
        return None

    def split_envvar_value(self, rv):
        return rv.split()

    def shell_complete(self, ctx, param, incomplete):
        return []

    def fail(self, message, param=None, ctx=None):
        raise BadParameter(message, ctx=ctx, param=param)

    def __repr__(self):
        return self.name.upper()


class StringParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            return value.decode("utf-8", "replace")
        return str(value)


class UnprocessedParamType(ParamType):
    name = "text"

    def convert(self, value, param, ctx):
        return value


class IntParamType(ParamType):
    name = "integer"
    _pattern = re.compile(r"\s*[+-]?\d+\s*")

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return int(value)
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            if value.is_integer():
                return int(value)
            self.fail(f"{value!r} is not a valid integer.", param, ctx)
        text = str(value)
        if not self._pattern.fullmatch(text):
            self.fail(f"{value!r} is not a valid integer.", param, ctx)
        return int(text)


class FloatParamType(ParamType):
    name = "float"

    def convert(self, value, param, ctx):
        if isinstance(value, float):
            return value
        try:
            return float(value)
        except (TypeError, ValueError):
            self.fail(f"{value!r} is not a valid floating point value.", param, ctx)


class BoolParamType(ParamType):
    name = "boolean"
    _true = frozenset({"1", "true", "t", "yes", "y", "on"})
    _false = frozenset({"0", "false", "f", "no", "n", "off"})

    def convert(self, value, param, ctx):
        if isinstance(value, bool):
            return value
        text = str(value).strip().lower()
        if text in self._true:
            return True
        if text in self._false:
            return False
        self.fail(f"{value!r} is not a valid boolean.", param, ctx)


class UUIDParamType(ParamType):
    name = "uuid"

    def convert(self, value, param, ctx):
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(str(value).strip())
        except ValueError:
            self.fail(f"{value!r} is not a valid UUID.", param, ctx)


class FuncParamType(ParamType):
    """Wraps a plain conversion function that refuses input by raising ``ValueError``."""

    def __init__(self, func):
        self.func = func
        self.name = getattr(func, "__name__", "text") or "text"

    def convert(self, value, param, ctx):
        try:
            return self.func(value)
        except ValueError:
            self.fail(f"{value!r} is not a valid value.", param, ctx)


class Choice(ParamType):
    name = "choice"

    def __init__(self, choices, case_sensitive=True):
        if isinstance(choices, type) and issubclass(choices, enum.Enum):
            self.choices = list(choices)
            self._keys = [member.name for member in choices]
        else:
            self.choices = list(choices)
            self._keys = [str(choice) for choice in self.choices]
        self.case_sensitive = case_sensitive

    def _norm(self, text, ctx):
        func = getattr(ctx, "token_normalize_func", None) if ctx is not None else None
        if func is not None:
            text = func(text)
        if not self.case_sensitive:
            text = text.casefold()
        return text

    def convert(self, value, param, ctx):
        for original in self.choices:
            if value is original:
                return original
        if isinstance(value, enum.Enum) and value in self.choices:
            return value
        if not isinstance(value, str):
            value = str(value)
        target = self._norm(value, ctx)
        for key, original in zip(self._keys, self.choices):
            if self._norm(key, ctx) == target:
                return original
        options = ", ".join(repr(key) for key in self._keys)
        self.fail(f"{value!r} is not {'one of' if len(self._keys) != 1 else 'the choice'} {options}.", param, ctx)

    def get_metavar(self, param):
        return "[" + "|".join(self._keys) + "]"

    def shell_complete(self, ctx, param, incomplete):
        items = []
        for key in self._keys:
            if key.startswith(incomplete) or (
                not self.case_sensitive and key.casefold().startswith(incomplete.casefold())
            ):
                items.append(CompletionItem(key))
        return items


class DateTime(ParamType):
    name = "datetime"
    default_formats = ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S")

    def __init__(self, formats=None):
        self.formats = list(self.default_formats if formats is None else formats)

    def convert(self, value, param, ctx):
        if isinstance(value, datetime.datetime):
            return value
        for fmt in self.formats:
            try:
                return datetime.datetime.strptime(str(value), fmt)
            except ValueError:
                continue
        self.fail(f"{value!r} does not match the formats {', '.join(self.formats)}.", param, ctx)


class IntRange(IntParamType):
    name = "integer range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def _describe(self):
        if self.min is not None and self.max is not None:
            left = "(" if self.min_open else "["
            right = ")" if self.max_open else "]"
            return f"{left}{self.min}, {self.max}{right}"
        if self.min is not None:
            return f"{'>' if self.min_open else '>='} {self.min}"
        return f"{'<' if self.max_open else '<='} {self.max}"

    def convert(self, value, param, ctx):
        rv = IntParamType.convert(self, value, param, ctx)
        if self.min is not None and (rv < self.min or (self.min_open and rv == self.min)):
            if self.clamp:
                return self.min + 1 if self.min_open else self.min
            self.fail(f"{rv} is not in the valid range of {self._describe()}.", param, ctx)
        if self.max is not None and (rv > self.max or (self.max_open and rv == self.max)):
            if self.clamp:
                return self.max - 1 if self.max_open else self.max
            self.fail(f"{rv} is not in the valid range of {self._describe()}.", param, ctx)
        return rv


class FloatRange(FloatParamType):
    name = "float range"

    def __init__(self, min=None, max=None, min_open=False, max_open=False, clamp=False):
        if clamp and (min_open or max_open or min is None or max is None):
            raise TypeError("Clamping is only supported when both bounds are set and closed.")
        self.min = min
        self.max = max
        self.min_open = min_open
        self.max_open = max_open
        self.clamp = clamp

    def convert(self, value, param, ctx):
        rv = FloatParamType.convert(self, value, param, ctx)
        if self.min is not None and (rv < self.min or (self.min_open and rv == self.min)):
            if self.clamp:
                return float(self.min)
            self.fail(f"{rv} is not in the valid range of {self._describe()}.", param, ctx)
        if self.max is not None and (rv > self.max or (self.max_open and rv == self.max)):
            if self.clamp:
                return float(self.max)
            self.fail(f"{rv} is not in the valid range of {self._describe()}.", param, ctx)
        return rv

    def _describe(self):
        if self.min is not None and self.max is not None:
            left = "(" if self.min_open else "["
            right = ")" if self.max_open else "]"
            return f"{left}{self.min}, {self.max}{right}"
        if self.min is not None:
            return f"{'>' if self.min_open else '>='} {self.min}"
        return f"{'<' if self.max_open else '<='} {self.max}"


class Tuple(ParamType):
    name = "tuple"
    is_composite = True

    def __init__(self, types):
        self.types = [convert_type(t) for t in types]
        self.name = " ".join(t.name for t in self.types)

    @property
    def nargs(self):
        return len(self.types)

    def convert(self, value, param, ctx):
        if isinstance(value, str) or len(value) != len(self.types):
            self.fail(f"{len(self.types)} values are required, but {value!r} was given.", param, ctx)
        return tuple(t.convert(v, param, ctx) for t, v in zip(self.types, value))

    def get_metavar(self, param):
        return " ".join((t.get_metavar(param) or t.name.upper()) for t in self.types)


class File(ParamType):
    name = "filename"

    def __init__(self, mode="r", encoding=None, errors="strict", lazy=None, atomic=False):
        self.mode = mode
        self.encoding = encoding
        self.errors = errors
        self.lazy = lazy
        self.atomic = atomic

    def convert(self, value, param, ctx):
        if hasattr(value, "read") or hasattr(value, "write"):
            return value
        filename = os.fspath(value)
        writing = any(c in self.mode for c in "wax+")
        lazy = self.lazy if self.lazy is not None else writing
        try:
            f = open_file(
                filename,
                self.mode,
                self.encoding,
                self.errors,
                lazy=lazy,
                atomic=self.atomic,
            )
        except OSError as e:
            self.fail(f"'{format_filename(filename)}': {e.strerror or e}", param, ctx)
        if ctx is not None:
            ctx.call_on_close(f.close)
        return f

    def shell_complete(self, ctx, param, incomplete):
        return [CompletionItem(incomplete, type="file")]


class Path(ParamType):
    name = "path"

    def __init__(
        self,
        exists=False,
        file_okay=True,
        dir_okay=True,
        writable=False,
        readable=True,
        resolve_path=False,
        allow_dash=False,
        path_type=None,
        executable=False,
    ):
        self.exists = exists
        self.file_okay = file_okay
        self.dir_okay = dir_okay
        self.writable = writable
        self.readable = readable
        self.resolve_path = resolve_path
        self.allow_dash = allow_dash
        self.path_type = path_type
        self.executable = executable

    def convert(self, value, param, ctx):
        if isinstance(value, bytes):
            value = os.fsdecode(value)
        if isinstance(value, pathlib.PurePath):
            value = os.fspath(value)
        if self.allow_dash and value == "-":
            return self._result("-")
        rv = value
        if self.resolve_path:
            rv = os.path.realpath(rv)
        try:
            st = os.stat(rv)
        except OSError:
            if not self.exists:
                return self._result(rv)
            self.fail(f"{format_filename(value)!r} does not exist.", param, ctx)
        if not self.file_okay and stat.S_ISREG(st.st_mode):
            self.fail(f"{format_filename(value)!r} is a file.", param, ctx)
        if not self.dir_okay and stat.S_ISDIR(st.st_mode):
            self.fail(f"{format_filename(value)!r} is a directory.", param, ctx)
        if self.readable and not os.access(rv, os.R_OK):
            self.fail(f"{format_filename(value)!r} is not readable.", param, ctx)
        if self.writable and not os.access(rv, os.W_OK):
            self.fail(f"{format_filename(value)!r} is not writable.", param, ctx)
        if self.executable and not os.access(rv, os.X_OK):
            self.fail(f"{format_filename(value)!r} is not executable.", param, ctx)
        return self._result(rv)

    def _result(self, rv):
        if self.path_type is pathlib.Path:
            return pathlib.Path(rv)
        return rv

    def split_envvar_value(self, rv):
        return rv.split(os.pathsep)

    def shell_complete(self, ctx, param, incomplete):
        kind = "dir" if (self.dir_okay and not self.file_okay) else "file"
        return [CompletionItem(incomplete, type=kind)]


STRING = StringParamType()
INT = IntParamType()
FLOAT = FloatParamType()
BOOL = BoolParamType()
UUID = UUIDParamType()
UNPROCESSED = UnprocessedParamType()

_BUILTIN = {
    str: STRING,
    int: INT,
    float: FLOAT,
    bool: BOOL,
    uuid.UUID: UUID,
}


def convert_type(ty, default=None):
    """Turn an author-supplied type (instance, class, function, or ``None``) into a ParamType."""
    if isinstance(ty, ParamType):
        return ty
    if ty is None:
        return infer_type(default)
    if isinstance(ty, (tuple, list)):
        return Tuple(ty)
    if ty in _BUILTIN:
        return _BUILTIN[ty]
    if callable(ty):
        return FuncParamType(ty)
    raise TypeError(f"Unsupported parameter type {ty!r}.")


def infer_type(default):
    """Infer a ParamType from a default value."""
    if isinstance(default, bool):
        return BOOL
    if isinstance(default, int):
        return INT
    if isinstance(default, float):
        return FLOAT
    if isinstance(default, uuid.UUID):
        return UUID
    if isinstance(default, tuple) and default:
        return Tuple([infer_type(v) for v in default])
    if isinstance(default, (list, tuple)) and default:
        return infer_type(default[0])
    return STRING


__all__ = [
    "ParamType",
    "CompletionItem",
    "STRING",
    "INT",
    "FLOAT",
    "BOOL",
    "UUID",
    "UNPROCESSED",
    "Choice",
    "DateTime",
    "IntRange",
    "FloatRange",
    "Tuple",
    "File",
    "Path",
    "convert_type",
    "infer_type",
]
