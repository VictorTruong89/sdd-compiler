"""Public declaration decorators: commands, groups, options, arguments, and callbacks."""

import importlib.metadata
import inspect
import sys
from functools import update_wrapper

from .core import Argument, Command, Group, Option, _show_help
from .utils import echo, peek_context


def get_current_context(silent=False):
    ctx = peek_context()
    if ctx is None and not silent:
        raise RuntimeError("There is no active Optlyn context.")
    return ctx


def _derive_command_name(func_name):
    name = func_name.lower()
    for suffix in ("_command", "_cmd", "_group", "_grp"):
        if name.endswith(suffix) and len(name) > len(suffix):
            name = name[: -len(suffix)]
            break
    return name.replace("_", "-")


def _pop_params(func):
    params = func.__dict__.pop("__optlyn_params__", [])
    params.reverse()
    return params


def _param_memo(func, param):
    if isinstance(func, Command):
        func.params.append(param)
    else:
        func.__dict__.setdefault("__optlyn_params__", []).append(param)


def command(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Command`."""
    if callable(name) and not isinstance(name, str):
        return command()(name)
    cls = Command if cls is None else cls

    def decorator(func):
        params = _pop_params(func)
        if attrs.get("help") is None:
            attrs["help"] = inspect.getdoc(func)
        cmd_name = name if name is not None else _derive_command_name(func.__name__)
        return cls(name=cmd_name, callback=func, params=params, **attrs)

    return decorator


def group(name=None, cls=None, **attrs):
    """Turn a function into a :class:`Group` (or an instance of ``cls``)."""
    if callable(name) and not isinstance(name, str):
        return group()(name)
    cls = Group if cls is None else cls
    return command(name, cls=cls, **attrs)


def option(*param_decls, cls=None, **attrs):
    """Attach an option to the function (or command) being decorated."""
    cls = Option if cls is None else cls

    def decorator(func):
        _param_memo(func, cls(param_decls, **attrs))
        return func

    return decorator


def argument(*param_decls, cls=None, **attrs):
    """Attach a positional argument to the function (or command) being decorated."""
    cls = Argument if cls is None else cls

    def decorator(func):
        _param_memo(func, cls(param_decls, **attrs))
        return func

    return decorator


def help_option(*param_decls, **kwargs):
    """Attach an extra eager help flag that prints help and exits."""
    if not param_decls:
        param_decls = ("--help",)
    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show this message and exit.")
    kwargs.setdefault("callback", _show_help)
    return option(*param_decls, **kwargs)


def version_option(version=None, *param_decls, package_name=None, prog_name=None, message=None, **kwargs):
    """Attach an eager flag that prints the version and exits."""
    if not param_decls:
        param_decls = ("--version",)
    if version is None and package_name is None:
        package_name = sys._getframe(1).f_globals.get("__name__")
    if message is None:
        message = "%(prog)s, version %(version)s"

    def callback(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        resolved = version if version is not None else _detect_version(package_name)
        prog = prog_name if prog_name is not None else ctx.find_root().info_name
        echo(message % {"prog": prog, "package": package_name, "version": resolved}, color=ctx.color)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = callback
    return option(*param_decls, **kwargs)


def custom_version_option(callback, *param_decls, **kwargs):
    """Attach an eager flag whose printed identity is ``callback(ctx)``."""
    if not param_decls:
        param_decls = ("--version",)

    def handler(ctx, param, value):
        if not value or ctx.resilient_parsing:
            return
        echo(callback(ctx), color=True)
        ctx.exit()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("is_eager", True)
    kwargs.setdefault("help", "Show the version and exit.")
    kwargs["callback"] = handler
    return option(*param_decls, **kwargs)


def password_option(*param_decls, **kwargs):
    """Attach a prompting, hidden, confirmed option."""
    if not param_decls:
        param_decls = ("--password",)
    kwargs.setdefault("prompt", True)
    kwargs.setdefault("hide_input", True)
    kwargs.setdefault("confirmation_prompt", True)
    return option(*param_decls, **kwargs)


def confirmation_option(*param_decls, **kwargs):
    """Attach a confirmation flag that asks when omitted and aborts when declined."""
    if not param_decls:
        param_decls = ("--yes",)
    prompt_text = kwargs.pop("prompt", "Do you want to continue?")

    def callback(ctx, param, value):
        if not value:
            ctx.abort()

    kwargs.setdefault("is_flag", True)
    kwargs.setdefault("expose_value", False)
    kwargs.setdefault("help", "Confirm the action without prompting.")
    kwargs["prompt"] = prompt_text
    kwargs["callback"] = callback
    kwargs["default"] = False
    return option(*param_decls, **kwargs)


def _detect_version(package_name):
    if package_name is None:
        raise RuntimeError("Could not determine the version: no package name was given.")
    try:
        return importlib.metadata.version(package_name)
    except importlib.metadata.PackageNotFoundError:
        pass
    top = package_name.partition(".")[0]
    for dist in importlib.metadata.packages_distributions().get(top, []):
        try:
            return importlib.metadata.version(dist)
        except importlib.metadata.PackageNotFoundError:
            continue
    raise RuntimeError(f"Could not determine the version for {package_name!r}.")


def pass_context(func):
    """Pass the current :class:`Context` as the first argument."""

    def new_func(*args, **kwargs):
        return func(get_current_context(), *args, **kwargs)

    return update_wrapper(new_func, func)


def pass_obj(func):
    """Pass the current context's author object as the first argument."""

    def new_func(*args, **kwargs):
        return func(get_current_context().obj, *args, **kwargs)

    return update_wrapper(new_func, func)


def make_pass_decorator(object_type, ensure=False):
    """Build a decorator that passes the nearest object of ``object_type``."""

    def decorator(func):
        def new_func(*args, **kwargs):
            ctx = get_current_context()
            if ensure:
                obj = ctx.ensure_object(object_type)
            else:
                obj = ctx.find_object(object_type)
            if obj is None:
                raise RuntimeError(f"Managed to invoke callback without a context object of type {object_type.__name__!r}.")
            return ctx.invoke(func, obj, *args, **kwargs)

        return update_wrapper(new_func, func)

    return decorator


__all__ = [
    "command",
    "group",
    "option",
    "argument",
    "help_option",
    "version_option",
    "custom_version_option",
    "password_option",
    "confirmation_option",
    "pass_context",
    "pass_obj",
    "make_pass_decorator",
    "get_current_context",
]
