"""Text wrapping and two-column layout for help pages."""

import re
import textwrap


def wrap_text(text, width=78, initial_indent="", subsequent_indent="", preserve_paragraphs=False):
    """Rewrap ``text`` to ``width`` columns. Accepts any string."""
    width = max(width, len(initial_indent) + 1, len(subsequent_indent) + 1, 10)
    if not preserve_paragraphs:
        return textwrap.fill(
            " ".join(text.split()),
            width=width,
            initial_indent=initial_indent,
            subsequent_indent=subsequent_indent,
        )
    blocks = []
    for para in re.split(r"\n\s*\n", text.strip("\n")):
        lines = para.split("\n")
        if lines and lines[0].strip() == "\b":
            blocks.append("\n".join(initial_indent + line for line in lines[1:]))
        else:
            blocks.append(
                textwrap.fill(
                    " ".join(line.strip() for line in lines),
                    width=width,
                    initial_indent=initial_indent,
                    subsequent_indent=subsequent_indent,
                )
            )
    return "\n\n".join(blocks)


def format_paragraphs(text, width, indent=""):
    """Return the lines of a help text block, honouring form feeds and ``\\b`` blocks."""
    if "\f" in text:
        text = text.split("\f")[0]
    lines = []
    for para in re.split(r"\n\s*\n", text.strip("\n")):
        plain = para.split("\n")
        if plain and plain[0].strip() == "\b":
            lines.extend(indent + line for line in plain[1:])
        else:
            lines.extend(
                textwrap.wrap(
                    " ".join(line.strip() for line in plain),
                    width=max(width - len(indent), 10),
                    initial_indent=indent,
                    subsequent_indent=indent,
                )
                or [indent]
            )
        lines.append("")
    if lines:
        lines.pop()
    return lines


def write_dl(rows, width, indent=2, col_max=30, col_spacing=2):
    """Render ``(first, second)`` rows as an aligned two-column list."""
    if not rows:
        return []
    first_width = min(max(len(first) for first, _ in rows), col_max)
    text_width = max(width - indent - first_width - col_spacing, 10)
    out = []
    pad = " " * indent
    for first, second in rows:
        wrapped = wrap_text(second, width=text_width).splitlines() if second else []
        if not wrapped:
            out.append(pad + first)
            continue
        if len(first) <= first_width:
            out.append(pad + first.ljust(first_width) + " " * col_spacing + wrapped[0])
            rest = wrapped[1:]
        else:
            out.append(pad + first)
            rest = wrapped
        for line in rest:
            out.append(pad + " " * (first_width + col_spacing) + line)
    return out


__all__ = ["wrap_text", "format_paragraphs", "write_dl"]
