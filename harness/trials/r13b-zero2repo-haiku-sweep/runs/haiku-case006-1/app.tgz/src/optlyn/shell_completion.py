"""Shell completion: registration scripts and suggestion streams for bash, zsh, fish, and PowerShell."""

import os

from .core import Argument, Context, Group, Option
from .paramtypes import CompletionItem
from .utils import echo

SHELLS = ("bash", "zsh", "fish", "powershell")


def run_completion(cli, prog_name, complete_var, instruction):
    """Handle a ``<shell>_source`` or ``<shell>_complete`` instruction. Returns an exit status."""
    shell, _, action = instruction.partition("_")
    if shell not in SHELLS or action not in ("source", "complete"):
        return 1
    if action == "source":
        echo(_source_script(shell, prog_name, complete_var))
        return 0
    if shell == "fish":
        raw = os.environ.get("COMP_WORDS", "")
        incomplete = os.environ.get("COMP_CWORD", "")
        words = raw.split()
        prior = words[1:]
        if incomplete and prior and prior[-1] == incomplete and not raw.endswith(" "):
            prior = prior[:-1]
    else:
        words = os.environ.get("COMP_WORDS", "").split()
        try:
            index = int(os.environ.get("COMP_CWORD", str(len(words))))
        except ValueError:
            index = len(words)
        incomplete = words[index] if index < len(words) else ""
        prior = words[1:index]
    for item in collect_items(cli, prog_name, prior, incomplete):
        echo(_format_item(item, shell))
    return 0


def collect_items(cli, prog_name, prior, incomplete):
    """Return completion items for ``incomplete`` after the tokens in ``prior``."""
    ctx = Context(cli, info_name=prog_name, resilient_parsing=True)
    cmd = cli
    args = list(prior)
    while isinstance(cmd, Group):
        index = next((i for i, tok in enumerate(args) if not tok.startswith("-")), None)
        if index is None:
            break
        sub = cmd.get_command(ctx, args[index])
        if sub is None:
            break
        ctx = Context(sub, info_name=args[index], parent=ctx, resilient_parsing=True)
        cmd = sub
        args = args[index + 1 :]

    params = cmd.get_params(ctx)
    options = {}
    for param in params:
        if isinstance(param, Option):
            for name in param.opts + param.secondary_opts:
                options[name] = param

    if args and args[-1] in options and options[args[-1]].takes_value:
        return _param_items(ctx, options[args[-1]], incomplete)

    if incomplete.startswith("-"):
        return _option_items(ctx, cmd, params, incomplete)

    if isinstance(cmd, Group):
        return [
            CompletionItem(name, help=cmd_obj.get_short_help_str())
            for name in cmd.list_commands(ctx)
            if (cmd_obj := cmd.get_command(ctx, name)) is not None
            and not cmd_obj.hidden
            and name.startswith(incomplete)
        ]

    positional = [tok for tok in args if not tok.startswith("-")]
    arguments = [p for p in params if isinstance(p, Argument)]
    index = len(positional)
    if index < len(arguments):
        return _param_items(ctx, arguments[index], incomplete)
    return []


def _option_items(ctx, cmd, params, incomplete):
    items = []
    seen = set()
    candidates = list(params)
    help_option = cmd.get_help_option(ctx)
    if help_option is not None:
        candidates.append(help_option)
    for param in candidates:
        if not isinstance(param, Option) or param.hidden:
            continue
        for name in param.opts + param.secondary_opts:
            if name.startswith(incomplete) and name not in seen:
                seen.add(name)
                items.append(CompletionItem(name, help=param.help))
    return items


def _param_items(ctx, param, incomplete):
    if param.shell_complete is not None:
        raw = param.shell_complete(ctx, param, incomplete)
    else:
        raw = param.type.shell_complete(ctx, param, incomplete)
    items = []
    for entry in raw or []:
        if isinstance(entry, str):
            items.append(CompletionItem(entry))
        elif hasattr(entry, "value"):
            items.append(CompletionItem(entry.value, getattr(entry, "help", None), getattr(entry, "type", None) or "plain"))
    return items


def _format_item(item, shell):
    if item.type == "plain":
        if item.help and shell in ("zsh", "fish"):
            return f"plain,{item.value}\t{item.help}"
        return f"plain,{item.value}"
    return f"{item.type},{item.value}"


def _source_script(shell, prog_name, complete_var):
    fn = prog_name.replace("-", "_").replace(".", "_")
    if shell == "bash":
        return f"""_{fn}_completion() {{
    local IFS=$'\\n'
    local response
    response=$(env COMP_WORDS="${{COMP_WORDS[*]}}" COMP_CWORD=$COMP_CWORD {complete_var}=bash_complete {prog_name})
    for completion in $response; do
        IFS=',' read type value <<< "$completion"
        if [[ $type == 'dir' ]]; then
            COMPREPLY=()
            compopt -o dirnames
        elif [[ $type == 'file' ]]; then
            COMPREPLY=()
            compopt -o default
        elif [[ $type == 'plain' ]]; then
            COMPREPLY+=("$value")
        fi
    done
    return 0
}}

complete -o nosort -F _{fn}_completion {prog_name}
"""
    if shell == "zsh":
        return f"""#compdef {prog_name}

_{fn}_completion() {{
  local -a completions completions_with_descriptions response
  local line type rest value help
  response=("${{(@f)$(env COMP_WORDS="${{words[*]}}" COMP_CWORD=$((CURRENT-1)) {complete_var}=zsh_complete {prog_name})}}")
  for line in "${{response[@]}}"; do
    type="${{line%%,*}}"
    rest="${{line#*,}}"
    if [[ $type == plain ]]; then
      value="${{rest%%$'\\t'*}}"
      help=""
      if [[ "$rest" == *$'\\t'* ]]; then help="${{rest#*$'\\t'}}"; fi
      if [[ -n $help ]]; then
        completions_with_descriptions+=("$value:$help")
      else
        completions+=("$value")
      fi
    elif [[ $type == dir ]]; then
      _path_files -/
    elif [[ $type == file ]]; then
      _path_files
    fi
  done
  if [[ -n $completions_with_descriptions ]]; then
    _describe -V unsorted completions_with_descriptions -U
  fi
  if [[ -n $completions ]]; then
    compadd -U -V unsorted -a completions
  fi
}}

compdef _{fn}_completion {prog_name}
"""
    if shell == "fish":
        return f"""function _{fn}_completion
    set -l response (env COMP_WORDS=(commandline -cp) COMP_CWORD=(commandline -ct) {complete_var}=fish_complete {prog_name})
    for completion in $response
        set -l parts (string split -m1 , -- $completion)
        if test "$parts[1]" = plain
            echo $parts[2]
        else if test "$parts[1]" = dir
            __fish_complete_directories $parts[2]
        else if test "$parts[1]" = file
            __fish_complete_path $parts[2]
        end
    end
end

complete -c {prog_name} -f -a "(_{fn}_completion)"
"""
    return f"""Register-ArgumentCompleter -Native -CommandName '{prog_name}' -ScriptBlock {{
    param($wordToComplete, $commandAst, $cursorPosition)
    $env:COMP_WORDS = $commandAst.ToString()
    $env:COMP_CWORD = $commandAst.CommandElements.Count - [int]([bool]$wordToComplete)
    $env:{complete_var} = 'powershell_complete'
    & '{prog_name}' | ForEach-Object {{
        $type, $value = $_ -split ',', 2
        if ($type -eq 'plain') {{
            [System.Management.Automation.CompletionResult]::new($value, $value, 'ParameterValue', $value)
        }}
    }}
    Remove-Item Env:{complete_var}
}}
"""


__all__ = ["run_completion", "collect_items", "SHELLS"]
