"""Commands, groups, parameters, and the per-invocation context."""

import enum
import os
import shutil
import sys
from contextlib import ExitStack, contextmanager

from .exceptions import (
    Abort,
    BadParameter,
    Exit,
    MissingParameter,
    NoArgsIsHelp,
    NoSuchOption,
    OptlynError,
    UsageError,
)
from .formatting import format_paragraphs, write_dl
from .paramtypes import INT, BoolParamType, Tuple, convert_type, infer_type
from .parser import MISSING, NEEDS_VALUE, Literal, OptionParser, unpack_args
from .termui import confirm, prompt
from .utils import echo, peek_context, pop_context, push_context


class ParameterSource(enum.Enum):
    """Where the value of a parameter came from."""

    COMMANDLINE = "commandline"
    ENVIRONMENT = "environment"
    DEFAULT_MAP = "default_map"
    DEFAULT = "default"
    PROMPT = "prompt"


_RANK = {
    ParameterSource.PROMPT: 5,
    ParameterSource.COMMANDLINE: 4,
    ParameterSource.ENVIRONMENT: 3,
    ParameterSource.DEFAULT_MAP: 2,
    ParameterSource.DEFAULT: 1,
}

_TRUE_TOKENS = frozenset({"true", "1", "yes", "on", "t", "y"})
_FALSE_TOKENS = frozenset({"false", "0", "no", "off", "f", "n"})


def _current_color():
    ctx = peek_context()
    return ctx.color if ctx is not None else None


def _plain(value):
    if isinstance(value, Literal):
        return str(value)
    return value


def _clean_help(text):
    if text is None:
        return None
    return text.split("\f")[0]


def _first_sentence(text):
    import re

    text = " ".join(text.split())
    match = re.match(r"(.*?[.!?])(?=\s|$)", text)
    return match.group(1) if match else text


def _help_width(ctx):
    if ctx.terminal_width is not None:
        return ctx.terminal_width
    detected = shutil.get_terminal_size((80, 24)).columns
    return max(min(detected, ctx.max_content_width) - 2, 10)


def _show_help(ctx, param, value):
    if not value or ctx.resilient_parsing:
        return
    echo(ctx.get_help(), color=ctx.color)
    ctx.exit()


@contextmanager
def augment_usage_errors(ctx, param=None):
    """Attach the context and parameter to usage errors raised inside the block."""
    try:
        yield
    except BadParameter as e:
        if e.ctx is None:
            e.ctx = ctx
        if e.param is None:
            e.param = param
        raise
    except UsageError as e:
        if e.ctx is None:
            e.ctx = ctx
        raise


def _iter_params_for_processing(order, params):
    def sort_key(item):
        try:
            index = order.index(item)
        except ValueError:
            index = float("inf")
        return (not item.is_eager, index)

    return sorted(params, key=sort_key)


class Context:
    """State for one command invocation: parsed values, linkage, and settings."""

    def __init__(
        self,
        command,
        parent=None,
        info_name=None,
        obj=None,
        auto_envvar_prefix=None,
        default_map=None,
        terminal_width=None,
        max_content_width=None,
        allow_extra_args=None,
        allow_interspersed_args=None,
        ignore_unknown_options=None,
        help_option_names=None,
        token_normalize_func=None,
        color=None,
        show_default=None,
        resilient_parsing=False,
    ):
        self.parent = parent
        self.command = command
        self.info_name = info_name
        self.params = {}
        self.args = []
        self.protected_args = []
        self.invoked_subcommand = None
        self.resilient_parsing = resilient_parsing
        self._parameter_source = {}
        self._exit_stack = ExitStack()
        self._depth = 0

        if parent is not None:
            if obj is None:
                obj = parent.obj
            if terminal_width is None:
                terminal_width = parent.terminal_width
            if max_content_width is None:
                max_content_width = parent.max_content_width
            if help_option_names is None:
                help_option_names = parent.help_option_names
            if token_normalize_func is None:
                token_normalize_func = parent.token_normalize_func
            if color is None:
                color = parent.color
            if show_default is None:
                show_default = parent.show_default
            if auto_envvar_prefix is None and parent.auto_envvar_prefix is not None and info_name is not None:
                auto_envvar_prefix = f"{parent.auto_envvar_prefix}_{info_name}"
            if default_map is None and isinstance(parent.default_map, dict) and info_name is not None:
                default_map = parent.default_map.get(info_name)

        self.obj = obj
        self.terminal_width = terminal_width
        self.max_content_width = 80 if max_content_width is None else max_content_width
        self.help_option_names = list(help_option_names) if help_option_names is not None else ["--help"]
        self.token_normalize_func = token_normalize_func
        self.color = color
        self.show_default = show_default
        self.auto_envvar_prefix = auto_envvar_prefix
        self.default_map = default_map
        self.allow_extra_args = command.allow_extra_args if allow_extra_args is None else allow_extra_args
        self.allow_interspersed_args = (
            command.allow_interspersed_args if allow_interspersed_args is None else allow_interspersed_args
        )
        self.ignore_unknown_options = bool(ignore_unknown_options)

    # Context management -------------------------------------------------

    def __enter__(self):
        self._depth += 1
        push_context(self)
        return self

    def __exit__(self, exc_type, exc_value, tb):
        self._depth -= 1
        pop_context()
        if self._depth == 0:
            self.close()
        return False

    @contextmanager
    def _scope(self):
        """Make this context current without closing its resources on exit."""
        push_context(self)
        try:
            yield self
        finally:
            pop_context()

    def close(self):
        self._exit_stack.close()

    def with_resource(self, context_manager):
        return self._exit_stack.enter_context(context_manager)

    def call_on_close(self, func):
        self._exit_stack.callback(func)

    # Navigation -----------------------------------------------------------

    @property
    def command_path(self):
        rv = self.info_name or ""
        if self.parent is not None:
            parent_path = self.parent.command_path
            rv = f"{parent_path} {rv}" if parent_path else rv
        return rv.lstrip()

    def find_root(self):
        node = self
        while node.parent is not None:
            node = node.parent
        return node

    def find_object(self, object_type):
        node = self
        while node is not None:
            if isinstance(node.obj, object_type):
                return node.obj
            node = node.parent
        return None

    def ensure_object(self, object_type):
        rv = self.find_object(object_type)
        if rv is None:
            self.obj = rv = object_type()
        return rv

    def lookup_default(self, name, call=True):
        if not isinstance(self.default_map, dict) or name not in self.default_map:
            return None
        value = self.default_map[name]
        if call and callable(value):
            return value()
        return value

    def get_parameter_source(self, name):
        return self._parameter_source.get(name)

    # Help and control -----------------------------------------------------

    def get_help(self):
        return self.command.get_help(self)

    def get_usage(self):
        return self.command.get_usage(self)

    def fail(self, message):
        raise UsageError(message, ctx=self)

    def abort(self):
        raise Abort()

    def exit(self, code=0):
        raise Exit(code)

    def invoke(self, _callback, /, *args, **kwargs):
        """Call a command (filling declared defaults) or a plain callback."""
        if isinstance(_callback, Command):
            other = _callback
            ctx = Context(other, info_name=other.name, parent=self)
            for param in other.params:
                if param.name not in kwargs and param.expose_value:
                    kwargs[param.name] = param.type_cast_value(ctx, param.get_default(ctx))
            ctx.params.update(kwargs)
            with ctx:
                return other.callback(*args, **kwargs)
        with self:
            return _callback(*args, **kwargs)

    def forward(self, cmd, /, *args, **kwargs):
        kwargs = {**self.params, **kwargs}
        return self.invoke(cmd, *args, **kwargs)


class Parameter:
    """Common machinery for options and arguments."""

    param_kind = "parameter"

    def __init__(
        self,
        param_decls=(),
        *,
        type=None,
        required=False,
        default=None,
        callback=None,
        nargs=None,
        multiple=False,
        metavar=None,
        expose_value=True,
        is_eager=False,
        envvar=None,
        shell_complete=None,
        deprecated=False,
        help=None,
        hidden=False,
        allow_from_autoenv=True,
    ):
        if type is None and default is not None:
            sample = default
            if multiple and isinstance(default, (list, tuple)):
                sample = default[0] if default else None
            type = infer_type(sample)
        self.type = convert_type(type)
        if nargs is None:
            nargs = self.type.nargs if isinstance(self.type, Tuple) else 1
        if nargs == 0 or nargs < -1:
            raise TypeError("nargs must be a positive integer or -1.")
        self.nargs = nargs
        self.multiple = multiple
        self.default = default
        self.required = required
        self.callback = callback
        self.metavar = metavar
        self.expose_value = expose_value
        self.is_eager = is_eager
        self.envvar = envvar
        self.shell_complete = shell_complete
        self.deprecated = deprecated
        self.note = deprecated if isinstance(deprecated, str) else None
        self.help = help
        self.hidden = hidden
        self.allow_from_autoenv = allow_from_autoenv

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"

    # Naming and display -----------------------------------------------------

    def get_error_hint(self, ctx):
        return repr(self.name.upper())

    def make_metavar(self):
        return self.metavar

    def get_help_record(self, ctx):
        return None

    # Value sources ----------------------------------------------------------

    def resolve_envvar_names(self, ctx):
        if self.envvar is None:
            return []
        return [self.envvar] if isinstance(self.envvar, str) else list(self.envvar)

    def _shape_tokens(self, tokens):
        if self.multiple:
            if self.nargs == 1:
                return list(tokens)
            step = self.nargs
            return [tuple(tokens[i : i + step]) for i in range(0, len(tokens), step)]
        if self.nargs == -1:
            return list(tokens)
        return tuple(tokens)

    def _env_value(self, raw, ctx):
        if self.multiple or self.nargs != 1:
            return self._shape_tokens(self.type.split_envvar_value(raw))
        return raw

    def value_from_envvar(self, ctx):
        for name in self.resolve_envvar_names(ctx):
            raw = os.environ.get(name)
            if raw:
                return self._env_value(raw, ctx)
        return None

    def get_default(self, ctx, call=True):
        value = self.default
        if call and callable(value):
            value = value()
        return value

    def _lookup_map(self, ctx):
        if not isinstance(ctx.default_map, dict) or self.name not in ctx.default_map:
            return False, None
        value = ctx.default_map[self.name]
        if callable(value):
            value = value()
        if value is None:
            return False, None
        if isinstance(value, str) and self.nargs != 1:
            value = self._shape_tokens(self.type.split_envvar_value(value))
        return True, value

    def _fallback_value(self, ctx):
        value = self.value_from_envvar(ctx)
        if value is not None:
            return value, ParameterSource.ENVIRONMENT
        found, value = self._lookup_map(ctx)
        if found:
            return value, ParameterSource.DEFAULT_MAP
        return self.get_default(ctx), ParameterSource.DEFAULT

    def consume_value(self, ctx, opts):
        raw = opts.get(self.name, MISSING)
        if raw is MISSING:
            return self._fallback_value(ctx)
        return raw, ParameterSource.COMMANDLINE

    # Conversion -------------------------------------------------------------

    def value_is_missing(self, value):
        if value is None:
            return True
        if (self.multiple or self.nargs == -1) and value == ():
            return True
        return False

    def type_cast_value(self, ctx, value):
        if value is None:
            return () if (self.multiple or self.nargs == -1) else None
        if (self.multiple or self.nargs == -1) and isinstance(value, (str, bytes)):
            raise BadParameter("The default value must be an iterable (sequence), not a string.", ctx, self)

        def unit(item):
            if isinstance(self.type, Tuple):
                return self.type.convert(item, self, ctx)
            if self.nargs not in (1, -1):
                if not isinstance(item, (tuple, list)) or len(item) != self.nargs:
                    raise BadParameter(f"Takes {self.nargs} values.", ctx, self)
                return tuple(self.type.convert(x, self, ctx) for x in item)
            return self.type.convert(item, self, ctx)

        if self.multiple or self.nargs == -1:
            return tuple(unit(item) for item in value)
        return unit(value)

    def process_value(self, ctx, value):
        value = self.type_cast_value(ctx, value)
        if self.required and self.value_is_missing(value):
            raise MissingParameter(ctx=ctx, param=self)
        if self.callback is not None:
            value = self.callback(ctx, self, value)
        return value

    def handle_parse_result(self, ctx, opts):
        with augment_usage_errors(ctx, param=self):
            value, source = self.consume_value(ctx, opts)
            if self.deprecated and source is ParameterSource.COMMANDLINE:
                self._warn_deprecated(ctx)
            value = self.process_value(ctx, value)
        existing = ctx._parameter_source.get(self.name)
        if existing is None or _RANK[source] >= _RANK[existing]:
            ctx._parameter_source[self.name] = source
            if self.expose_value:
                ctx.params[self.name] = value

    def _warn_deprecated(self, ctx):
        kind = self.param_kind
        text = f"DeprecationWarning: The {kind} {self.get_error_hint(ctx)} is deprecated."
        if self.note:
            text += f" {self.note}"
        echo(text, err=True)


class Option(Parameter):
    """A named parameter introduced by a prefix such as ``--`` or ``-``."""

    param_kind = "option"

    def __init__(
        self,
        param_decls=(),
        *,
        show_default=None,
        prompt=False,
        confirmation_prompt=False,
        prompt_required=True,
        hide_input=False,
        is_flag=None,
        flag_value=None,
        multiple=False,
        count=False,
        allow_from_autoenv=True,
        type=None,
        help=None,
        hidden=False,
        show_choices=True,
        show_envvar=False,
        default=None,
        required=False,
        callback=None,
        nargs=None,
        metavar=None,
        expose_value=True,
        is_eager=False,
        envvar=None,
        shell_complete=None,
        deprecated=False,
    ):
        if isinstance(param_decls, str):
            param_decls = (param_decls,)
        opts, secondary, name = _split_option_decls(param_decls)
        if not opts and name is None:
            raise TypeError("An option needs at least one flag name or a destination name.")
        if name is None:
            name = _infer_dest(opts)
        if deprecated and required:
            raise TypeError("A deprecated option cannot be required.")
        if deprecated and prompt:
            raise TypeError("A deprecated option cannot use a prompt.")
        if count and (is_flag or flag_value is not None):
            raise TypeError("A counting option cannot also be a flag.")
        if is_flag is None:
            if flag_value is not None:
                is_flag = True
            else:
                is_flag = bool(secondary)
        if count:
            is_flag = False
            multiple = False
            if type is None:
                type = INT
            if default is None:
                default = 0
        if is_flag:
            if flag_value is None:
                flag_value = True
            if default is None and isinstance(flag_value, bool):
                default = False
            if type is None:
                type = BoolParamType() if isinstance(flag_value, bool) else infer_type(flag_value)
        is_optional_value = (not is_flag) and (not count) and flag_value is not None
        if is_optional_value and nargs not in (None, 1):
            raise TypeError("An option with an optional value takes exactly one value.")

        self.name = name
        self.opts = opts
        self.secondary_opts = secondary
        super().__init__(
            param_decls,
            type=type,
            required=required,
            default=default,
            callback=callback,
            nargs=(1 if (is_flag or count) else nargs),
            multiple=multiple,
            metavar=metavar,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=envvar,
            shell_complete=shell_complete,
            deprecated=deprecated,
            help=help,
            hidden=hidden,
            allow_from_autoenv=allow_from_autoenv,
        )
        self.is_flag = bool(is_flag)
        self.count = bool(count)
        self.flag_value = flag_value
        self.is_optional_value = is_optional_value
        self.is_bool_flag = self.is_flag and isinstance(self.type, BoolParamType)
        self.prompt = prompt if prompt else None
        self.confirmation_prompt = confirmation_prompt
        self.prompt_required = prompt_required
        self.hide_input = hide_input
        self.show_default = show_default
        self.show_choices = show_choices
        self.show_envvar = show_envvar

    @property
    def takes_value(self):
        return not self.is_flag and not self.count

    def get_error_hint(self, ctx):
        return " / ".join(repr(name) for name in self.opts + self.secondary_opts)

    def make_metavar(self):
        if self.metavar is not None:
            return self.metavar
        if self.is_flag or self.count:
            return None
        var = self.type.get_metavar(self) or self.type.name.upper()
        if self.nargs not in (1, -1) and not isinstance(self.type, Tuple):
            var = " ".join([var] * self.nargs)
        return var

    def resolve_envvar_names(self, ctx):
        names = super().resolve_envvar_names(ctx)
        if self.allow_from_autoenv and ctx.auto_envvar_prefix is not None:
            names.append(f"{ctx.auto_envvar_prefix}_{self.name}".upper().replace("-", "_"))
        return names

    def _env_value(self, raw, ctx):
        if not self.is_flag:
            return super()._env_value(raw, ctx)
        text = raw.strip().lower()
        on = self.flag_value
        if isinstance(on, bool):
            if text in _TRUE_TOKENS:
                return True
            if text in _FALSE_TOKENS or text == "":
                return False
            raise BadParameter(f"{raw!r} is not a valid boolean.", ctx, self)
        if raw == str(on) or text == str(on).lower():
            return on
        if text in _TRUE_TOKENS:
            return on
        if text in _FALSE_TOKENS:
            return False
        return None

    def consume_value(self, ctx, opts):
        raw = opts.get(self.name, MISSING)
        force_prompt = raw is NEEDS_VALUE
        if raw is MISSING or force_prompt:
            value, source = self._fallback_value(ctx)
        else:
            value, source = raw, ParameterSource.COMMANDLINE
        if self.prompt is not None and not ctx.resilient_parsing:
            wants_prompt = (force_prompt and source is not ParameterSource.ENVIRONMENT) or (
                source in (ParameterSource.DEFAULT, ParameterSource.DEFAULT_MAP) and self.prompt_required
            )
            if wants_prompt:
                # Only default-tier sources reach this branch, so ``value`` is the default to offer.
                value = self.prompt_for_value(ctx, value)
                if self.multiple and not isinstance(value, (list, tuple)):
                    value = [value]
                source = ParameterSource.PROMPT
        return value, source

    def prompt_for_value(self, ctx, default):
        text = self.prompt if isinstance(self.prompt, str) else self.name.replace("_", " ").capitalize()
        if self.is_bool_flag:
            return confirm(text, default=bool(default))
        return prompt(
            text,
            default=default,
            hide_input=self.hide_input,
            confirmation_prompt=self.confirmation_prompt,
            type=self.type,
        )

    def get_help_record(self, ctx):
        if self.hidden:
            return None
        if self.secondary_opts:
            first = " / ".join(self.opts + self.secondary_opts)
        else:
            first = ", ".join(self.opts)
        metavar = self.make_metavar()
        if metavar:
            first = f"{first} {metavar}"
        extras = []
        show_default = self.show_default if self.show_default is not None else bool(ctx.show_default)
        if show_default:
            if isinstance(show_default, str):
                extras.append(f"default: {show_default}")
            elif self.default is not None and not callable(self.default):
                if not (self.is_flag and not self.default):
                    extras.append(f"default: {self.default}")
        if self.show_envvar:
            names = self.resolve_envvar_names(ctx)
            if names:
                extras.append(f"env var: {', '.join(names)}")
        text = self.help or ""
        if self.deprecated:
            extras.insert(0, "deprecated")
        if extras:
            text = (text + " " if text else "") + " ".join(f"[{e}]" for e in extras)
        return first, text


class Argument(Parameter):
    """A positional parameter."""

    param_kind = "argument"

    def __init__(
        self,
        param_decls,
        *,
        type=None,
        default=None,
        required=None,
        nargs=None,
        envvar=None,
        deprecated=False,
        help=None,
        metavar=None,
        callback=None,
        expose_value=True,
        is_eager=False,
        shell_complete=None,
        hidden=False,
    ):
        if isinstance(param_decls, str):
            param_decls = (param_decls,)
        if len(param_decls) != 1 or not param_decls[0] or param_decls[0][0] in "-/+":
            raise TypeError("An argument takes exactly one destination name.")
        self.name = param_decls[0].replace("-", "_")
        self.opts = []
        self.secondary_opts = []
        if required is None:
            effective_nargs = nargs if nargs is not None else 1
            required = default is None and effective_nargs != -1
        if deprecated and required:
            raise TypeError("A deprecated argument cannot be required.")
        super().__init__(
            param_decls,
            type=type,
            required=required,
            default=default,
            callback=callback,
            nargs=nargs,
            metavar=metavar,
            expose_value=expose_value,
            is_eager=is_eager,
            envvar=envvar,
            shell_complete=shell_complete,
            deprecated=deprecated,
            help=help,
            hidden=hidden,
        )

    def get_error_hint(self, ctx):
        return repr(self.name.upper())

    def make_metavar(self):
        return self.metavar or self.name.upper()

    def get_help_record(self, ctx):
        if self.hidden or not self.help:
            return None
        return self.make_metavar(), self.help


def _split_option_decls(decls):
    opts = []
    secondary = []
    name = None
    for decl in decls:
        if not decl:
            continue
        if decl[0] not in "-/+":
            name = decl.replace("-", "_")
            continue
        split_at = decl.find("/", 1)
        if split_at > 0:
            opts.append(decl[:split_at])
            secondary.append(decl[split_at + 1 :])
        else:
            opts.append(decl)
    return opts, secondary, name


def _infer_dest(opts):
    for name in opts:
        if name[:2] in ("--", "//", "++"):
            return name.lstrip("-/+").replace("-", "_")
    return opts[0].lstrip("-/+").replace("-", "_")


class Command:
    """A leaf command: parses its parameters and runs a callback."""

    allow_extra_args = False
    allow_interspersed_args = True
    context_class = Context

    def __init__(
        self,
        name,
        *,
        context_settings=None,
        callback=None,
        params=None,
        help=None,
        epilog=None,
        short_help=None,
        options_metavar="[OPTIONS]",
        add_help_option=True,
        no_args_is_help=False,
        hidden=False,
        deprecated=False,
    ):
        self.name = name
        self.context_settings = dict(context_settings or {})
        self.callback = callback
        self.params = list(params or [])
        self.help = help
        self.epilog = epilog
        self.short_help = short_help
        self.options_metavar = options_metavar
        self.add_help_option = add_help_option
        self.no_args_is_help = no_args_is_help
        self.hidden = hidden
        self.deprecated = deprecated
        self.note = deprecated if isinstance(deprecated, str) else None

    def __call__(self, *args, **kwargs):
        return self.main(*args, **kwargs)

    def __repr__(self):
        return f"<{type(self).__name__} {self.name}>"

    # Parameters -------------------------------------------------------------

    def arguments(self):
        return [p for p in self.params if isinstance(p, Argument)]

    def get_help_option(self, ctx):
        if not self.add_help_option:
            return None
        declared = set()
        for param in self.params:
            declared.update(param.opts)
            declared.update(param.secondary_opts)
        names = [n for n in ctx.help_option_names if n not in declared]
        if not names:
            return None
        option = Option(
            names,
            is_flag=True,
            flag_value=True,
            default=False,
            expose_value=False,
            is_eager=True,
            help="Show this message and exit.",
            callback=_show_help,
        )
        option.name = "__optlyn_help__"
        return option

    def get_params(self, ctx):
        rv = list(self.params)
        help_option = self.get_help_option(ctx)
        if help_option is not None:
            rv.append(help_option)
        return rv

    # Parsing ----------------------------------------------------------------

    def make_context(self, info_name, args, parent=None, **extra):
        for key, value in self.context_settings.items():
            if key not in extra:
                extra[key] = value
        ctx = self.context_class(self, info_name=info_name, parent=parent, **extra)
        try:
            with ctx._scope():
                self.parse_args(ctx, args)
        except BaseException:
            ctx.close()
            raise
        return ctx

    def parse_args(self, ctx, args):
        if not args and self.no_args_is_help and not ctx.resilient_parsing:
            raise NoArgsIsHelp("No arguments were given.", ctx=ctx)
        params = self.get_params(ctx)
        options = [p for p in params if isinstance(p, Option)]
        arguments = self.arguments()
        parser = OptionParser(ctx, options, interspersed=ctx.allow_interspersed_args)
        opts, largs, order = parser.parse_args(list(args))
        values, leftover = unpack_args(largs, [a.nargs for a in arguments])
        for arg, raw in zip(arguments, values):
            bound = _bind_positional(arg, raw)
            if bound is not None:
                opts[arg.name] = bound
        for param in _iter_params_for_processing(order, params):
            param.handle_parse_result(ctx, opts)
        self._check_leftover(ctx, parser, leftover)

    def _check_leftover(self, ctx, parser, leftover):
        if not ctx.resilient_parsing:
            for tok in leftover:
                if not isinstance(tok, Literal) and parser._is_option(tok) and not ctx.ignore_unknown_options:
                    raise NoSuchOption(tok, ctx=ctx)
            if leftover and not ctx.allow_extra_args:
                names = " ".join(str(t) for t in leftover)
                noun = "argument" if len(leftover) == 1 else "arguments"
                ctx.fail(f"Got unexpected extra {noun} ({names})")
        ctx.args = [_plain(t) for t in leftover]

    # Invocation -------------------------------------------------------------

    def invoke(self, ctx):
        if self.deprecated:
            text = f"DeprecationWarning: The command {self.name!r} is deprecated."
            if self.note:
                text += f" {self.note}"
            echo(text, err=True)
        if self.callback is not None:
            return ctx.invoke(self.callback, **ctx.params)
        return None

    def main(
        self,
        args=None,
        prog_name=None,
        complete_var=None,
        standalone_mode=True,
        **extra,
    ):
        """Run this command as a program. In standalone mode, exits the process."""
        args = list(sys.argv[1:]) if args is None else list(args)
        if prog_name is None:
            prog_name = _default_prog_name()
        if complete_var is None:
            complete_var = "_" + prog_name.upper().replace("-", "_") + "_COMPLETE"
        instruction = os.environ.get(complete_var)
        if instruction:
            from .shell_completion import run_completion

            code = run_completion(self, prog_name, complete_var, instruction)
            if standalone_mode:
                sys.exit(code)
            return code

        try:
            try:
                with self.make_context(prog_name, args, **extra) as ctx:
                    rv = self.invoke(ctx)
                    if not standalone_mode:
                        return rv
                    ctx.exit()
            except (EOFError, KeyboardInterrupt) as e:
                echo(file=sys.stderr)
                raise Abort() from e
            except UsageError as e:
                if not standalone_mode:
                    raise
                e.show()
                sys.exit(e.exit_code)
            except OptlynError as e:
                if not standalone_mode:
                    raise
                e.show()
                sys.exit(e.exit_code)
            except Exit as e:
                if standalone_mode:
                    sys.exit(e.exit_code)
                return e.exit_code
        except Abort:
            if not standalone_mode:
                raise
            echo("Aborted!", file=sys.stderr)
            sys.exit(1)
        return None

    # Help ---------------------------------------------------------------------

    def collect_usage_pieces(self, ctx):
        pieces = [self.options_metavar] if self.options_metavar else []
        for arg in self.arguments():
            pieces.append(_argument_usage(arg))
        return pieces

    def get_usage(self, ctx):
        return "Usage: " + " ".join([ctx.command_path] + self.collect_usage_pieces(ctx))

    def get_short_help_str(self, limit=45):
        if self.short_help:
            text = self.short_help
        elif self.help:
            text = _first_sentence(_clean_help(self.help))
        else:
            text = ""
        if len(text) > limit:
            text = text[: max(limit - 3, 0)].rstrip() + "..."
        return text

    def get_help(self, ctx):
        width = _help_width(ctx)
        sections = [[self.get_usage(ctx)]]
        if self.deprecated:
            sections.append([f"  DEPRECATED: {self.note or 'This command is deprecated.'}"])
        help_text = _clean_help(self.help)
        if help_text:
            sections.append(format_paragraphs(help_text, width, indent="  "))
        arg_rows = [r for r in (a.get_help_record(ctx) for a in self.arguments()) if r]
        if arg_rows:
            sections.append(["Positional arguments:"] + write_dl(arg_rows, width))
        option_rows = []
        for param in self.get_params(ctx):
            if isinstance(param, Option):
                record = param.get_help_record(ctx)
                if record:
                    option_rows.append(record)
        if option_rows:
            sections.append(["Options:"] + write_dl(option_rows, width))
        sections.extend(self.extra_help_sections(ctx, width))
        if self.epilog:
            sections.append(format_paragraphs(self.epilog, width))
        return "\n\n".join("\n".join(section) for section in sections if section) + "\n"

    def extra_help_sections(self, ctx, width):
        return []


def _argument_usage(arg):
    metavar = arg.make_metavar()
    if arg.nargs == -1:
        piece = f"{metavar}..." if arg.required else f"[{metavar}]..."
    else:
        piece = " ".join([metavar] * arg.nargs)
        if not arg.required:
            piece = f"[{piece}]"
    return piece


def _bind_positional(arg, raw):
    if raw is None:
        return None
    if arg.nargs == 1:
        return _plain(raw)
    items = tuple(_plain(item) for item in raw)
    if not items:
        return None
    if arg.nargs == -1:
        return items
    return items


def _default_prog_name():
    if sys.argv and sys.argv[0]:
        return os.path.basename(sys.argv[0])
    return "optlyn"


class Group(Command):
    """A command that dispatches to named subcommands."""

    allow_extra_args = True
    allow_interspersed_args = False

    def __init__(
        self,
        name=None,
        commands=None,
        invoke_without_command=False,
        no_args_is_help=None,
        subcommand_metavar=None,
        chain=False,
        result_callback=None,
        **kwargs,
    ):
        if no_args_is_help is None:
            no_args_is_help = not invoke_without_command
        super().__init__(name, no_args_is_help=no_args_is_help, **kwargs)
        self.commands = {}
        if isinstance(commands, dict):
            self.commands.update(commands)
        elif commands:
            for cmd in commands:
                self.add_command(cmd)
        self.invoke_without_command = invoke_without_command
        self.subcommand_metavar = subcommand_metavar
        self.chain = chain
        self._result_callback = result_callback

    # Registration -----------------------------------------------------------

    def add_command(self, cmd, name=None):
        if self.chain and isinstance(cmd, Group):
            raise RuntimeError("A chained group cannot contain other groups.")
        name = name or cmd.name
        if not name:
            raise TypeError("A command needs a name to be registered.")
        self.commands[name] = cmd

    def command(self, *args, **kwargs):
        from .decorators import command as _command

        if len(args) == 1 and callable(args[0]) and not kwargs:
            return self._register(_command()(args[0]))
        return lambda f: self._register(_command(*args, **kwargs)(f))

    def group(self, *args, **kwargs):
        from .decorators import group as _group

        if len(args) == 1 and callable(args[0]) and not kwargs:
            return self._register(_group()(args[0]))
        return lambda f: self._register(_group(*args, **kwargs)(f))

    def _register(self, cmd):
        self.add_command(cmd)
        return cmd

    def result_callback(self):
        def decorator(f):
            self._result_callback = f
            return f

        return decorator

    # Lookup -----------------------------------------------------------------

    def list_commands(self, ctx):
        return sorted(self.commands)

    def get_command(self, ctx, cmd_name):
        return self.commands.get(cmd_name)

    def resolve_command(self, ctx, args):
        cmd_name = args[0]
        cmd = self.get_command(ctx, cmd_name)
        if cmd is None and ctx.token_normalize_func is not None:
            wanted = ctx.token_normalize_func(cmd_name)
            for name in self.list_commands(ctx):
                if ctx.token_normalize_func(name) == wanted:
                    cmd = self.get_command(ctx, name)
                    cmd_name = name
                    break
        if cmd is None:
            ctx.fail(f"No such command {cmd_name!r}.")
        return cmd_name, cmd, args[1:]

    # Parsing ------------------------------------------------------------------

    def _check_leftover(self, ctx, parser, leftover):
        ctx.protected_args = [_plain(t) for t in leftover[:1]]
        ctx.args = [_plain(t) for t in leftover[1:]]

    def invoke(self, ctx):
        def _process_result(value):
            if self._result_callback is not None:
                value = ctx.invoke(self._result_callback, value, **ctx.params)
            return value

        if not ctx.protected_args:
            if self.invoke_without_command:
                with ctx:
                    rv = Command.invoke(self, ctx)
                    return _process_result([] if self.chain else rv)
            ctx.fail("Missing command.")

        args = [*ctx.protected_args, *ctx.args]
        ctx.args = []
        ctx.protected_args = []

        if not self.chain:
            with ctx:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                ctx.invoked_subcommand = cmd_name
                Command.invoke(self, ctx)
                sub_ctx = cmd.make_context(cmd_name, args, parent=ctx)
                with sub_ctx:
                    return _process_result(sub_ctx.command.invoke(sub_ctx))

        with ctx:
            ctx.invoked_subcommand = "*"
            Command.invoke(self, ctx)
            contexts = []
            while args:
                cmd_name, cmd, args = self.resolve_command(ctx, args)
                sub_ctx = cmd.make_context(
                    cmd_name,
                    args,
                    parent=ctx,
                    allow_extra_args=True,
                    allow_interspersed_args=False,
                )
                contexts.append(sub_ctx)
                args = sub_ctx.args
            results = []
            for sub_ctx in contexts:
                with sub_ctx:
                    results.append(sub_ctx.command.invoke(sub_ctx))
            return _process_result(results)

    # Help ---------------------------------------------------------------------

    def collect_usage_pieces(self, ctx):
        rv = super().collect_usage_pieces(ctx)
        if self.subcommand_metavar is not None:
            rv.append(self.subcommand_metavar)
        elif self.chain:
            rv.append("COMMAND1 [ARGS]... [COMMAND2 [ARGS]...]...")
        elif self.invoke_without_command:
            rv.append("[COMMAND [ARGS]...]")
        else:
            rv.append("COMMAND [ARGS]...")
        return rv

    def extra_help_sections(self, ctx, width):
        rows = []
        visible = []
        for name in self.list_commands(ctx):
            cmd = self.get_command(ctx, name)
            if cmd is None or cmd.hidden:
                continue
            visible.append((name, cmd))
        if not visible:
            return []
        first_width = min(max(len(name) for name, _ in visible), 30)
        limit = max(width - 2 - first_width - 2, 20)
        for name, cmd in visible:
            rows.append((name, cmd.get_short_help_str(limit)))
        return [["Commands:"] + write_dl(rows, width)]


class CommandCollection(Group):
    """A group whose subcommands are the union of several source groups."""

    def __init__(self, name=None, sources=None, **kwargs):
        super().__init__(name, **kwargs)
        self.sources = list(sources or [])

    def list_commands(self, ctx):
        names = set(self.commands)
        for source in self.sources:
            names.update(source.list_commands(ctx))
        return sorted(names)

    def get_command(self, ctx, cmd_name):
        for source in self.sources:
            cmd = source.get_command(ctx, cmd_name)
            if cmd is not None:
                return cmd
        return self.commands.get(cmd_name)


__all__ = [
    "Context",
    "Parameter",
    "Option",
    "Argument",
    "Command",
    "Group",
    "CommandCollection",
    "ParameterSource",
    "augment_usage_errors",
]
