"""Exceptions used for usage failures, aborts, and clean exits."""

class OptlynError(Exception):
    """Base class for errors that are reported to the user and exit the process."""

    exit_code = 1

    def __init__(self, message):
        super().__init__(message)
        self.message = message

    def format_message(self):
        return self.message

    def show(self, file=None):
        from .utils import echo

        echo(f"Error: {self.format_message()}", file=file, err=True)


class UsageError(OptlynError):
    """The command line was used incorrectly (exit status 2)."""

    exit_code = 2

    def __init__(self, message, ctx=None):
        super().__init__(message)
        self.ctx = ctx

    def show(self, file=None):
        from .utils import echo

        ctx = self.ctx
        if ctx is not None:
            echo(ctx.get_usage(), file=file, err=True)
            hint = ctx.help_option_names[0] if ctx.help_option_names else None
            if hint:
                echo(f"Try '{ctx.command_path} {hint}' for help.", file=file, err=True)
            echo(file=file, err=True)
        echo(f"Error: {self.format_message()}", file=file, err=True)


class BadParameter(UsageError):
    """A value for a parameter could not be accepted."""

    def __init__(self, message, ctx=None, param=None, param_hint=None):
        super().__init__(message, ctx)
        self.param = param
        self.param_hint = param_hint

    def format_message(self):
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if hint:
            return f"Invalid value for {hint}: {self.message}"
        return self.message


class MissingParameter(BadParameter):
    """A required parameter was not supplied."""

    def __init__(self, message=None, ctx=None, param=None, param_hint=None):
        super().__init__(message or "", ctx, param, param_hint)

    def format_message(self):
        kind = "argument" if getattr(self.param, "param_kind", "") == "argument" else "option"
        hint = self.param_hint
        if hint is None and self.param is not None:
            hint = self.param.get_error_hint(self.ctx)
        if self.param is None:
            return self.message or "Missing parameter."
        return f"Missing {kind} {hint}."


class NoSuchOption(UsageError):
    """An option name is not known to the command."""

    def __init__(self, option_name, message=None, ctx=None):
        super().__init__(message or f"No such option: {option_name}", ctx)
        self.option_name = option_name


class BadOptionUsage(UsageError):
    """An option was given in a way it does not accept."""


class BadArgumentUsage(UsageError):
    """An argument was given in a way it does not accept."""


class NoArgsIsHelp(UsageError):
    """A command was invoked with no arguments and shows help as a usage failure."""

    def show(self, file=None):
        from .utils import echo

        if self.ctx is not None:
            echo(self.ctx.get_help(), file=file, err=True)


class Abort(RuntimeError):
    """The user aborted, or the author requested an abort (exit status 1)."""


class Exit(RuntimeError):
    """A clean stop requested by the author or by an eager flag."""

    def __init__(self, code=0):
        super().__init__(code)
        self.exit_code = code


class FileError(OptlynError):
    """A file could not be opened at first I/O (general error, exit status 1)."""

    def __init__(self, filename, message):
        super().__init__(f"Could not open file {filename!r}: {message}")
        self.filename = filename


__all__ = [
    "OptlynError",
    "UsageError",
    "BadParameter",
    "MissingParameter",
    "NoSuchOption",
    "BadOptionUsage",
    "BadArgumentUsage",
    "NoArgsIsHelp",
    "Abort",
    "Exit",
    "FileError",
]
