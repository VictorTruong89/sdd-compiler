#!/usr/bin/env node
'use strict';
// Subagent-start hook: gives a delegated agent the same writing contract as the session.

const common = require('./prosecheck-common.js');

function main() {
  common.readStdinJson();
  const { level } = common.readLevel();
  if (level === 'off') return;
  common.emitContext('SubagentStart', common.liveContract(level));
}

try {
  main();
} catch (_) {
  // A hook never fails the host session.
}
process.exitCode = 0;
