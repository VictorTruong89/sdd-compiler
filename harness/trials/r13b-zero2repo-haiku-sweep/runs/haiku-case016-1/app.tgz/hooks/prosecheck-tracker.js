#!/usr/bin/env node
'use strict';
// Prompt-submit hook: the /prosecheck command router, stop phrases, and the ordinary-prompt reminder.

const common = require('./prosecheck-common.js');
const cmd = require('./prosecheck-commands.js');
const stats = require('./prosecheck-stats.js');

const STOP_PHRASES = ['stop prosecheck', 'prosecheck off'];
const COMMAND_RE = /^\/prosecheck(?::prosecheck)?(?=\s|$)/i;

function route(prompt, payload) {
  const text = String(prompt || '').trim();
  const { level } = common.readLevel();
  const typed = /^\/prosecheck:prosecheck/i.test(text) ? '/prosecheck:prosecheck' : '/prosecheck';
  const form = cmd.formOf(typed);

  if (STOP_PHRASES.includes(text.toLowerCase())) {
    common.writeLevel('off');
    return { block: 'prosecheck is off: the contract and the saved-file guard are disabled until you run ' + form + ' on.' };
  }

  if (!COMMAND_RE.test(text)) return null;

  const rest = text.replace(COMMAND_RE, '').trim();
  const space = rest.search(/\s/);
  const sub = (space === -1 ? rest : rest.slice(0, space)).toLowerCase();
  const arg = space === -1 ? '' : rest.slice(space).trim();

  if (!sub || sub === 'help') return { block: cmd.helpReply(level) };

  const setLevel = (word, reply) => {
    const ok = common.writeLevel(word);
    return { block: ok ? reply : 'prosecheck could not store the level; the settings folder is not writable.' };
  };

  switch (sub) {
    case 'lite':
      return setLevel('lite', 'prosecheck set to lite: writing contract on, saved files not scored.');
    case 'full':
      return setLevel('full', 'prosecheck set to full: writing contract on, saved-file guard on at threshold 40.');
    case 'strict':
      return setLevel('strict', 'prosecheck set to strict: writing contract on, saved-file guard at threshold 20, cleanup scrub on.');
    case 'off':
      return setLevel('off', 'prosecheck is off: the contract and the saved-file guard are disabled until you run ' + form + ' on.');
    case 'on':
      return setLevel('full', 'prosecheck is on at full: the writing contract and the saved-file guard are active.');
    case 'status':
      return { block: cmd.statusReply(level) };
    case 'show':
      return { block: cmd.showReply(payload.session_id) };
    case 'check':
      return { block: cmd.checkReply(arg, payload.cwd) };
    case 'doctor':
      return { block: cmd.doctorReply(level, form) };
    case 'stats':
      return { block: stats.computeStats(payload.transcript_path, level) };
    case 'init':
      return { block: cmd.initReply(level, form) };
    default:
      return { block: cmd.unknownReply(sub) };
  }
}

function main() {
  const payload = common.readStdinJson();
  const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
  const result = route(prompt, payload);
  if (result) {
    common.emitBlock(result.block);
    return;
  }
  const { level } = common.readLevel();
  if (level === 'off') return;
  common.emitContext('UserPromptSubmit',
    'prosecheck level: ' + level + '. Prose deliverables follow the writing contract; code, config, and commits are untouched.');
}

try {
  main();
} catch (_) {
  // A hook never fails the host session.
}
process.exitCode = 0;
