'use strict';
// Operator command replies for /prosecheck: help, status, check, doctor, show, init.

const fs = require('fs');
const path = require('path');
const common = require('./prosecheck-common.js');

const KB_PLAIN = common.PLAIN_KB;
const KB_ARCHIVE = common.ARCHIVE_MB * 1024;
const CHECK_LABEL_CAP = 8;

function formOf(typed) {
  return typed === '/prosecheck:prosecheck' ? '/prosecheck:prosecheck' : '/prosecheck';
}

function helpReply(level) {
  return [
    'prosecheck is ' + level + ' (live level).',
    'Code, commits, config, and chat are never touched; this covers prose deliverables only.',
    'For a deep rewrite, ask in plain language with "prosecheck this" or "humanize this".',
    '/prosecheck lite - turns on the writing contract without saved-file scoring (contract and scoring off).',
    '/prosecheck full - contract plus the saved-file guard, threshold 40 (default).',
    '/prosecheck strict - guard threshold 20, plus the cleanup scrub through --clean.',
    '/prosecheck off | on - off stops the tool (disable); on turns it back on at full (re-enable).',
    '/prosecheck check <path> - score one file in report form; it never rewrites the file.',
    '/prosecheck doctor - health check of the install.',
    '/prosecheck stats - session token use and the score of the session prose.',
    '/prosecheck init - export the writing contract to ./AGENTS.md for other agents (contract).',
    '/prosecheck status - one line naming the stored level.',
    "/prosecheck show - list this session's scored files, newest first.",
  ].join('\n');
}

function statusReply(level) {
  return 'prosecheck level: ' + level + '.';
}

function unknownReply(word) {
  return 'unknown subcommand "' + word + '". Valid subcommands: lite, full, strict, off, on, status, show, check, doctor, stats, init, help.';
}

function cleanPathArg(arg) {
  let p = String(arg || '').trim();
  if (p.startsWith('@')) p = p.slice(1);
  const q = p.match(/^(["'])(.*)\1$/);
  if (q) p = q[2];
  return p.trim();
}

// ---------------------------------------------------------------- show

function showReply(sessionId) {
  const file = common.ledgerPath(sessionId);
  let rows = [];
  try {
    const st = fs.statSync(file);
    if (Date.now() - st.mtimeMs <= common.LEDGER_AGE_MS) {
      rows = JSON.parse(fs.readFileSync(file, 'utf8'));
    }
  } catch (_) {
    rows = [];
  }
  if (!Array.isArray(rows) || rows.length === 0) {
    return 'nothing scored yet in this session. Rows appear after prose files, including .docx and .pdf deliverables, are saved.';
  }
  const out = ['Files saved in this session, newest first:'];
  rows.slice().sort((a, b) => b.t - a.t).forEach((r) => {
    let body;
    if (r.kind === 'scored') {
      body = r.phrase + ' (score ' + r.score + '/' + r.band +
        (r.truncated ? ', first ' + common.WINDOW_CHARS + ' characters only' : '') + ')';
      if (r.labels && r.labels.length) {
        body += ' - ' + (r.flagged ? 'flagged' : 'under threshold') + ': ' + r.labels.slice(0, common.LEDGER_LABELS).join('; ');
      }
    } else if (r.kind === 'size') {
      body = 'not scored: over ' + r.limitKb + ' KB';
    } else if (r.kind === 'binary') {
      body = 'not re-scored (binary document)';
    } else {
      body = 'not scored: ' + (r.reason || 'unknown failure');
    }
    out.push(r.base + ' - ' + body);
  });
  return out.join('\n');
}

// ---------------------------------------------------------------- check

function checkReply(arg, cwd) {
  const typed = cleanPathArg(arg);
  if (!typed) {
    return 'check needs a file path: /prosecheck check <path>.';
  }
  const full = path.resolve(cwd || process.cwd(), typed);
  const base = path.basename(full);
  let st;
  try {
    st = fs.statSync(full);
  } catch (_) {
    return 'cannot read ' + typed + '.';
  }
  if (!st.isFile()) return base + ': not a file.';
  const ext = path.extname(full).toLowerCase();
  if (common.BINARY_EXT.includes(ext)) return base + ': no readable text.';
  const archive = common.ZIP_EXT.includes(ext);
  if (!archive && !common.PLAIN_EXT.includes(ext)) return base + ': no readable text.';
  const cap = archive ? common.ARCHIVE_MB * 1024 * 1024 : common.PLAIN_KB * 1024;
  if (st.size > cap) return base + ': over ' + (archive ? KB_ARCHIVE : KB_PLAIN) + ' KB.';

  const run = common.runDetector([full], '', archive ? 15000 : 8000);
  if (!run.launched) return base + ': detector unavailable.';
  if (run.timedOut) return base + ' failed: the detector timed out.';
  if (run.status !== 0) {
    const why = common.lastErrorLine(run.stderr) || run.stderr.trim();
    return base + ' failed' + (why ? ': ' + why : '.');
  }
  if (!run.stdout.trim()) return base + ': no report.';
  const report = common.parseReport(run.stdout);
  if (!report) return 'no report.';
  const m = report._metrics;
  const lines = [
    base + ' - ' + common.hookPhrase(m.ai_tell_band) + ' (score ' + m.ai_tell_score + '/100, band: ' + m.ai_tell_band + ')',
    'confidence: ' + m.confidence + (m.confidence !== 'high' && m.confidence_reason ? ' - ' + m.confidence_reason : ''),
  ];
  if (m.truncated) lines.push('coverage: first ' + common.WINDOW_CHARS + ' characters only');
  const tells = Object.keys(report).filter((k) => k !== '_metrics')
    .map((k) => report[k].label + ' (x' + report[k].count + ')');
  lines.push(tells.length ? 'tells: ' + tells.slice(0, CHECK_LABEL_CAP).join('; ') : 'tells: none');
  lines.push('This is a report only; the file was not changed.');
  return lines.join('\n');
}

// ---------------------------------------------------------------- doctor

function doctorReply(level, form) {
  const sample = 'This is a short sample sentence for the install check. It has two sentences.';
  const checks = [];
  checks.push(level === 'off'
    ? { ok: false, text: 'mode: off (not a fault of the install); run /prosecheck on to turn it back on' }
    : { ok: true, text: 'mode: ' + level });

  const detector = common.detectorPath();
  checks.push(detector
    ? { ok: true, text: 'detector: bundled scripts/detect.py is present' }
    : { ok: false, text: 'detector: bundled scripts/detect.py is missing from the plugin tree' });

  const run = detector ? common.runDetector([], sample, 8000) : { launched: false };
  const report = run.launched && !run.timedOut ? common.parseReport(run.stdout) : null;
  if (!run.launched) {
    checks.push({ ok: false, text: 'python not found: saved files are not re-scored until Python is available, but prose is still shaped by the writing contract' });
  } else if (report && typeof report._metrics.ai_tell_score === 'number') {
    checks.push({ ok: true, text: 'python ran the bundled scanner and returned score ' + report._metrics.ai_tell_score });
  } else {
    checks.push({ ok: false, text: 'python: the bundled scanner returned no numeric score' });
  }

  const writable = common.settingsWritable();
  checks.push(writable
    ? { ok: true, text: 'settings: folder ' + common.configDir() + ' is writable' }
    : { ok: false, text: 'settings: folder ' + common.configDir() + ' is not writable' });

  const modeOk = level !== 'off';
  const others = checks.slice(1);
  const allOk = checks.every((c) => c.ok);
  let closer;
  if (allOk && modeOk) {
    closer = 'Active: plain text up to 512 KB, archives up to 4 MB, and the first ' + common.WINDOW_CHARS +
      ' characters are scored. Run ' + form + ' show to see files that were only partly scanned or skipped.';
  } else if (!others.every((c) => c.ok)) {
    closer = 'Fix the failed checks above, then run /prosecheck doctor again.';
  } else {
    closer = 'The install is healthy. Saving files triggers no scoring while the tool is off; run ' + form +
      ' on to turn it back on so saved prose is scored.';
  }
  const lines = ['prosecheck health check'];
  for (const c of checks) lines.push((c.ok ? '[OK] ' : '[--] ') + c.text);
  lines.push(closer);
  return lines.join('\n');
}

// ---------------------------------------------------------------- init

const CONTRACT_HEADING = '# Writing contract for prose deliverables';

function initReply(level, form) {
  if (level === 'off') {
    return 'prosecheck is switched off, so nothing was written. Run ' + form + ' on to allow the export.';
  }
  const out = [];
  const agents = path.join(process.cwd(), 'AGENTS.md');
  let existing = '';
  let agentsOk = true;
  try {
    existing = fs.existsSync(agents) ? fs.readFileSync(agents, 'utf8') : '';
  } catch (_) {
    out.push('cannot read AGENTS.md; the writing contract was not added.');
    agentsOk = false;
  }
  if (agentsOk) {
    if (existing.includes(common.CONTRACT_MARKER) || existing.includes(CONTRACT_HEADING)) {
      out.push('AGENTS.md already has the writing contract; left unchanged.');
    } else {
      const section = common.CONTRACT_MARKER + '\n' + common.exportContract(level) + '\n' + common.CONTRACT_END + '\n';
      const prefix = existing && !existing.endsWith('\n') ? existing + '\n\n' : existing + (existing ? '\n' : '');
      try {
        fs.writeFileSync(agents, prefix + section);
        out.push('AGENTS.md: wrote the writing contract.');
      } catch (_) {
        out.push('cannot write AGENTS.md; the writing contract was not added.');
      }
    }
  }

  const dest = path.join(process.cwd(), '.cursor', 'rules', 'prosecheck.mdc');
  const src = path.join(common.pluginRoot(), '.cursor', 'rules', 'prosecheck.mdc');
  if (fs.existsSync(dest)) {
    out.push('.cursor/rules/prosecheck.mdc already exists; left unchanged.');
  } else {
    try {
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      fs.copyFileSync(src, dest);
      out.push('.cursor/rules/prosecheck.mdc: copied the Cursor rule.');
    } catch (_) {
      out.push('cannot write .cursor/rules/prosecheck.mdc.');
    }
  }
  return out.join('\n');
}

module.exports = {
  formOf, helpReply, statusReply, unknownReply, cleanPathArg, showReply, checkReply,
  doctorReply, initReply,
};
