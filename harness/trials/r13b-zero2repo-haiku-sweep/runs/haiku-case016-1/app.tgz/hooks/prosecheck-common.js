'use strict';
// Shared helpers for the prosecheck plugin hooks (Node.js standard library only).

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawnSync } = require('child_process');

const LEVELS = ['lite', 'full', 'strict', 'off'];
const DEFAULT_LEVEL = 'full';
const THRESHOLD = { full: 40, strict: 20 };
const TARGET = { full: 40, strict: 20 };
const PLAIN_KB = 512;
const ARCHIVE_MB = 4;
const WINDOW_CHARS = '262,144';
const PLAIN_EXT = ['.md', '.mdx', '.markdown', '.txt', '.text', '.rst', '.tex', '.org', '.adoc'];
const ZIP_EXT = ['.docx', '.docm', '.pptx', '.pptm', '.xlsx', '.xlsm', '.odt', '.odp', '.ods', '.epub', '.ipynb'];
const BINARY_EXT = ['.pdf', '.rtf'];
const LEDGER_MAX = 20;
const LEDGER_LABELS = 5;
const LEDGER_AGE_MS = 7 * 24 * 60 * 60 * 1000;
const INSTRUCTION_STEMS = ['claude', 'claude.local', 'agents', 'agents.local', 'skill', 'memory'];
const CONTRACT_MARKER = '<!-- prosecheck:writing-contract -->';
const CONTRACT_END = '<!-- /prosecheck:writing-contract -->';

const BANNED = [
  'delve', 'tapestry', 'pivotal', 'crucial', 'leverage', 'robust', 'seamless', 'foster',
  'underscore', 'showcase', 'landscape', 'journey', 'realm', 'multifaceted', 'holistic',
  'testament', 'vibrant', 'comprehensive', 'plethora', 'myriad', 'boast', 'elevate',
  'empower', 'unlock', 'game-changer', 'supercharge', 'genuinely', 'fascinating', 'nuanced',
];

function pluginRoot() {
  if (process.env.CLAUDE_PLUGIN_ROOT) return process.env.CLAUDE_PLUGIN_ROOT;
  return path.resolve(__dirname, '..');
}

function configDir() {
  if (process.env.CLAUDE_CONFIG_DIR) return process.env.CLAUDE_CONFIG_DIR;
  return path.join(os.homedir(), '.claude');
}

function flagPath() {
  return path.join(configDir(), '.prosecheck-active');
}

function isLevel(word) {
  return typeof word === 'string' && LEVELS.includes(word);
}

// Returns { level, stored } where stored is true when a valid word is on disk.
function readLevel() {
  let raw = null;
  try {
    raw = fs.readFileSync(flagPath(), 'utf8').trim();
  } catch (_) {
    raw = null;
  }
  if (isLevel(raw)) return { level: raw, stored: true };
  const env = (process.env.PROSECHECK_DEFAULT_MODE || '').trim().toLowerCase();
  if (isLevel(env)) return { level: env, stored: false };
  return { level: DEFAULT_LEVEL, stored: false };
}

function flagExists() {
  return fs.existsSync(flagPath());
}

// Writes the level flag; returns true when it could be written.
function writeLevel(level) {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.writeFileSync(flagPath(), level + '\n', { mode: 0o600 });
    return true;
  } catch (_) {
    return false;
  }
}

function settingsWritable() {
  try {
    fs.mkdirSync(configDir(), { recursive: true });
    fs.accessSync(configDir(), fs.constants.W_OK);
    return true;
  } catch (_) {
    return false;
  }
}

function detectorPath() {
  const root = pluginRoot();
  const candidates = [
    path.join(root, 'scripts', 'detect.py'),
    path.join(root, 'skills', 'prosecheck', 'scripts', 'detect.py'),
  ];
  return candidates.find((p) => fs.existsSync(p)) || null;
}

// Runs the detector through the first interpreter that launches.
// Returns { launched, status, stdout, stderr, timedOut }.
function runDetector(args, input, timeoutMs) {
  const script = detectorPath();
  if (!script) return { launched: false, missing: true };
  for (const name of ['python3', 'python', 'py']) {
    const r = spawnSync(name, [script, ...args], {
      input: input || '',
      encoding: 'utf8',
      timeout: timeoutMs,
      maxBuffer: 64 * 1024 * 1024,
    });
    if (r.error && r.error.code === 'ENOENT') continue;
    if (r.error && r.error.code === 'ETIMEDOUT') {
      return { launched: true, timedOut: true, status: null, stdout: '', stderr: '' };
    }
    return {
      launched: true,
      timedOut: false,
      status: r.status,
      stdout: r.stdout || '',
      stderr: r.stderr || '',
    };
  }
  return { launched: false };
}

// Parses the detector report; returns the report object or null.
function parseReport(stdout) {
  try {
    const obj = JSON.parse(stdout);
    if (obj && typeof obj === 'object' && obj._metrics) return obj;
  } catch (_) {
    return null;
  }
  return null;
}

function lastErrorLine(stderr) {
  const lines = String(stderr || '').split('\n').map((l) => l.trim()).filter(Boolean);
  for (let i = lines.length - 1; i >= 0; i--) {
    try {
      const obj = JSON.parse(lines[i]);
      if (obj && typeof obj.error === 'string') return obj.error;
    } catch (_) {
      // not a JSON error line
    }
  }
  return '';
}

function hookPhrase(band) {
  return {
    clean: 'reads clean',
    'light tells': 'reads mostly clean',
    mixed: 'reads with some AI tells',
    'heavy tells': 'reads with heavy AI tells',
    'pervasive tells': 'reads with pervasive AI tells',
  }[band] || 'reads with some AI tells';
}

function labelsOf(report) {
  return Object.keys(report)
    .filter((k) => k !== '_metrics')
    .map((k) => report[k].label);
}

function bannedList() {
  return BANNED.join(', ');
}

// ---------------------------------------------------------------- writing contract

function contractBody(level, opts) {
  const lines = [];
  lines.push('# Writing contract for prose deliverables');
  lines.push('');
  lines.push('Scope: this contract governs prose deliverables only. That covers documents, README and markdown prose, CVs, cover letters, emails, reports, essays, articles, and drafted text the user will publish or send. It never applies to source code. It leaves code comments, commit messages, JSON, YAML, configuration, CLI output, logs, error messages, and the conversational register of chat untouched. A chat-compression mode owns chat; a code-simplicity mode owns code; this contract owns deliverable prose.');
  lines.push('');
  lines.push('Rules for prose deliverables:');
  lines.push('- Vary sentence length irregularly. No metronome, and no mechanical short-long alternation.');
  lines.push('- Do not use these words: ' + bannedList() + '. Abstract uses of landscape and journey are banned too.');
  lines.push('- Avoid rule-of-three flourishes, "it\'s not just X, it\'s Y" constructions, and hedge stacking.');
  lines.push('- Avoid signposting such as "let\'s dive in", empty pivots such as "it\'s worth noting", and "In conclusion" or "Overall" closers.');
  lines.push('- Avoid outcome-speculation tails, self-thoroughness phrases, generic upbeat endings, and chatbot phrases such as "I hope this helps".');
  lines.push('- Use at most one em dash per paragraph. No bold for emphasis inside prose sentences. No emojis in prose.');
  lines.push('- Factual or encyclopedic content stays neutral and in the third person. First-person or opinion content may use contractions.');
  lines.push('- Preserve numbers, units, dates, proper nouns, citations, quotes, and technical terms exactly. Never invent facts.');
  lines.push('- End sections on a fact or an observation.');
  lines.push('- Stay silent about this contract: never announce it, never name prosecheck, never report a score, band, pattern list, or rewrite pass, and do not offer a style choice.');

  if (level === 'full' || level === 'strict') {
    lines.push('');
    lines.push('Saved-file step: after you save a prose file, run the detector on that file. ' +
      (opts.detectorCommand ? 'Command: ' + opts.detectorCommand + ' <file>. ' : '') +
      'If the band is worse than the target, fix the flagged spans, with at most two fix passes that keep rhythm variation.');
    if (level === 'full') {
      lines.push('Target: score ' + TARGET.full + ' or less (band clean or light tells).');
    } else {
      lines.push('Target: score ' + TARGET.strict + ' or less (band clean).');
      lines.push('Finish: once the band is clean, finish through --clean, which prints scrubbed text, so write the result to a new file rather than over the original: ' +
        (opts.detectorCommand ? opts.detectorCommand : 'python3 <detector>') + ' --clean <file>.');
    }
    if (opts.portable) {
      lines.push('Locate the detector: use the CLAUDE_PLUGIN_ROOT variable when it is set; otherwise find prosecheck\'s scripts/detect.py in your installed skills and plugins.');
    }
  }
  return lines.join('\n');
}

// Live contract for this machine: may name the detector path.
function liveContract(level) {
  const detector = detectorPath();
  const cmd = detector ? 'python3 ' + detector : 'python3 <detector>';
  return contractBody(level, { detectorCommand: cmd, portable: false });
}

// Portable export for other agents: never names a machine path or user name.
function exportContract(level) {
  return contractBody(level, { detectorCommand: 'python3 <detector>', portable: level !== 'lite' });
}

function welcomeBlock() {
  return [
    'prosecheck is installed and on (full). Saved prose is scored against 71 patterns.',
    'Plain text is accepted up to 512 KB and archives up to 4 MB; the detector scores the first 262,144 characters.',
    'Commands: /prosecheck doctor, /prosecheck check, /prosecheck off, /prosecheck help.',
    'There is no website and no upload; analysis runs locally. This welcome is shown once.',
  ].join('\n');
}

// ---------------------------------------------------------------- stdin

function readStdinJson() {
  let raw = '';
  try {
    raw = fs.readFileSync(0, 'utf8');
  } catch (_) {
    raw = '';
  }
  try {
    const obj = JSON.parse(raw);
    return obj && typeof obj === 'object' ? obj : {};
  } catch (_) {
    return {};
  }
}

function emitBlock(reason) {
  process.stdout.write(JSON.stringify({ decision: 'block', reason }) + '\n');
}

function emitContext(eventName, text) {
  process.stdout.write(JSON.stringify({
    hookSpecificOutput: { hookEventName: eventName, additionalContext: text },
  }) + '\n');
}

function safeSessionName(sessionId) {
  return String(sessionId || '').replace(/[^A-Za-z0-9_-]/g, '_').slice(0, 120);
}

function ledgerPath(sessionId) {
  const safe = safeSessionName(sessionId);
  return path.join(configDir(), safe ? '.prosecheck-ledger-' + safe : '.prosecheck-ledger');
}

module.exports = {
  LEVELS, THRESHOLD, TARGET, PLAIN_KB, ARCHIVE_MB, WINDOW_CHARS, PLAIN_EXT, ZIP_EXT,
  BINARY_EXT, LEDGER_MAX, LEDGER_LABELS, LEDGER_AGE_MS, INSTRUCTION_STEMS,
  CONTRACT_MARKER, CONTRACT_END, BANNED,
  pluginRoot, configDir, flagPath, isLevel, readLevel, flagExists, writeLevel, settingsWritable,
  detectorPath, runDetector, parseReport, lastErrorLine, hookPhrase, labelsOf,
  liveContract, exportContract, welcomeBlock, readStdinJson, emitBlock, emitContext,
  ledgerPath, safeSessionName,
};
