#!/usr/bin/env node
'use strict';
// Post-tool-use hook: scores a just-saved prose file and nudges when it is flagged.

const fs = require('fs');
const path = require('path');
const common = require('./prosecheck-common.js');

const MAX_PATHS = 16;
const INSTRUCTION_NAMES = ['claude.md', 'claude.local.md', 'agents.md', 'agents.local.md', 'skill.md', 'memory.md'];
const SKIP_SEGMENTS = ['node_modules', '.git', 'memory'];

// Paths the edit tool names, per the tool's payload shape.
function pathsFromInput(toolName, ti) {
  if (toolName === 'apply_patch') {
    const body = typeof ti.command === 'string' ? ti.command : '';
    const found = [];
    for (const line of body.split(/\r?\n/)) {
      const m = line.match(/^\*\*\* (?:Add File|Update File|Move to):(.*)$/);
      if (m && m[1].trim()) found.push(m[1].trim());
    }
    return [...new Set(found)].slice(0, MAX_PATHS);
  }
  if (toolName === 'NotebookEdit') {
    const p = ti.notebook_path || ti.file_path;
    return typeof p === 'string' && p.trim() ? [p.trim()] : [];
  }
  if (typeof ti.file_path === 'string' && ti.file_path.trim()) return [ti.file_path.trim()];
  return [];
}

function isSkipped(full) {
  const segments = full.split(/[\\/]/);
  if (segments.some((s) => SKIP_SEGMENTS.includes(s))) return true;
  const root = common.pluginRoot();
  if (full === root || full.startsWith(root + path.sep)) return true;
  const name = path.basename(full).toLowerCase();
  if (INSTRUCTION_NAMES.includes(name)) return true;
  const ext = path.extname(name);
  const stem = ext ? name.slice(0, -ext.length) : name;
  const prose = common.PLAIN_EXT.includes(ext) || common.ZIP_EXT.includes(ext);
  if (common.INSTRUCTION_STEMS.includes(stem) && !prose) return true;
  return false;
}

function failureReason(run) {
  if (!run.launched) return run.missing ? 'the bundled detector is missing' : 'Python not found';
  if (run.timedOut) return 'the detector timed out';
  if (run.status !== 0) return common.lastErrorLine(run.stderr) || 'the detector failed';
  if (!run.stdout.trim()) return 'the detector produced no output';
  return 'the detector output was not a structured report';
}

function scoreFile(full, base, ext, cap, archive) {
  const size = fs.statSync(full).size;
  if (size > cap) {
    return { kind: 'size', base, limitKb: archive ? common.ARCHIVE_MB * 1024 : common.PLAIN_KB };
  }
  const run = common.runDetector([full], '', archive ? 15000 : 8000);
  if (!run.launched || run.timedOut || run.status !== 0 || !run.stdout.trim()) {
    return { kind: 'failed', base, reason: failureReason(run) };
  }
  const report = common.parseReport(run.stdout);
  if (!report) return { kind: 'failed', base, reason: failureReason(run) };
  const m = report._metrics;
  if (typeof m.ai_tell_score !== 'number') {
    return { kind: 'failed', base, reason: 'the report had no numeric score' };
  }
  return {
    kind: 'scored',
    base,
    score: m.ai_tell_score,
    band: m.ai_tell_band,
    confidence: m.confidence,
    truncated: Boolean(m.truncated),
    labels: common.labelsOf(report).slice(0, common.LEDGER_LABELS),
  };
}

function appendLedger(sessionId, records) {
  const file = common.ledgerPath(sessionId);
  let rows = [];
  try {
    rows = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (!Array.isArray(rows)) rows = [];
  } catch (_) {
    rows = [];
  }
  rows = rows.concat(records).slice(-common.LEDGER_MAX);
  try {
    fs.mkdirSync(common.configDir(), { recursive: true });
    fs.writeFileSync(file, JSON.stringify(rows, null, 1), { mode: 0o600 });
    fs.chmodSync(file, 0o600);
  } catch (_) {
    // an unwritable ledger does not block the save
  }
}

function main() {
  const payload = common.readStdinJson();
  const toolName = typeof payload.tool_name === 'string' ? payload.tool_name : '';
  const ti = payload.tool_input && typeof payload.tool_input === 'object' ? payload.tool_input : {};
  const { level } = common.readLevel();
  if (level === 'off' || level === 'lite') return;
  const threshold = common.THRESHOLD[level];
  const cwd = typeof payload.cwd === 'string' && payload.cwd ? payload.cwd : process.cwd();

  const records = [];
  const lines = [];
  for (const p of pathsFromInput(toolName, ti)) {
    const full = path.resolve(cwd, p);
    if (isSkipped(full)) continue;
    const base = path.basename(full);
    let st = null;
    try {
      st = fs.statSync(full);
    } catch (_) {
      records.push({ t: Date.now(), base, kind: 'failed', reason: 'the file cannot be read' });
      continue;
    }
    if (!st.isFile()) continue;
    const ext = path.extname(full).toLowerCase();
    if (common.BINARY_EXT.includes(ext)) {
      records.push({ t: Date.now(), base, kind: 'binary' });
      continue;
    }
    const archive = common.ZIP_EXT.includes(ext);
    if (!archive && !common.PLAIN_EXT.includes(ext)) continue;
    const cap = archive ? common.ARCHIVE_MB * 1024 * 1024 : common.PLAIN_KB * 1024;
    const result = scoreFile(full, base, ext, cap, archive);
    const record = Object.assign({ t: Date.now() }, result);
    if (result.kind === 'scored') {
      const phrase = common.hookPhrase(result.band);
      const flagged = result.score > threshold && result.confidence !== 'none';
      record.phrase = phrase;
      record.flagged = flagged;
      if (flagged) {
        const coverage = result.truncated ? ', first ' + common.WINDOW_CHARS + ' characters only' : '';
        lines.push('prosecheck: ' + base + ' ' + phrase + ' (score ' + result.score + ', band ' + result.band +
          coverage + '). Flagged: ' + result.labels.join('; ') + '. Please fix the flagged spans.');
      }
    }
    records.push(record);
  }

  if (records.length) appendLedger(payload.session_id, records);
  if (lines.length) common.emitContext('PostToolUse', lines.join('\n'));
}

try {
  main();
} catch (_) {
  // A hook never fails the host session.
}
process.exitCode = 0;
