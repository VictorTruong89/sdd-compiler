#!/usr/bin/env node
'use strict';
// Session-start hook: places the writing contract in context (and the welcome on first start).

const fs = require('fs');
const path = require('path');
const common = require('./prosecheck-common.js');

function pruneLedgers() {
  let entries = [];
  try {
    entries = fs.readdirSync(common.configDir());
  } catch (_) {
    return;
  }
  const cutoff = Date.now() - common.LEDGER_AGE_MS;
  for (const name of entries) {
    if (name !== '.prosecheck-ledger' && !name.startsWith('.prosecheck-ledger-')) continue;
    const full = path.join(common.configDir(), name);
    try {
      if (fs.statSync(full).mtimeMs < cutoff) fs.unlinkSync(full);
    } catch (_) {
      // ignore unreadable ledgers
    }
  }
}

function main() {
  common.readStdinJson();
  const first = !common.flagExists();
  const { level } = common.readLevel();
  let welcome = false;
  if (first) {
    // A first start writes the default level; the welcome shows only if that write worked.
    welcome = common.writeLevel(level);
  }
  pruneLedgers();
  if (level === 'off') return;
  const parts = [];
  if (welcome) parts.push(common.welcomeBlock());
  parts.push(common.liveContract(level));
  process.stdout.write(parts.join('\n\n') + '\n');
}

try {
  main();
} catch (_) {
  // A hook never fails the host session.
}
process.exitCode = 0;
