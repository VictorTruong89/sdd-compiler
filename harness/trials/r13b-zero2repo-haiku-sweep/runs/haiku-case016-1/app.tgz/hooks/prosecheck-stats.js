#!/usr/bin/env node
'use strict';
// Stats: token use from a session transcript, plus the score of the session's own prose.

const fs = require('fs');
const path = require('path');
const common = require('./prosecheck-common.js');

const PROSE_SLICE = 40000;
const PROSE_MIN = 200;

// Newest .jsonl under the config directory's projects folder, or null.
function newestTranscript() {
  const root = path.join(common.configDir(), 'projects');
  let newest = null;
  const walk = (dir) => {
    let entries = [];
    try {
      entries = fs.readdirSync(dir, { withFileTypes: true });
    } catch (_) {
      return;
    }
    for (const ent of entries) {
      const full = path.join(dir, ent.name);
      if (ent.isDirectory()) {
        walk(full);
      } else if (ent.isFile() && ent.name.endsWith('.jsonl')) {
        try {
          const mtime = fs.statSync(full).mtimeMs;
          if (!newest || mtime > newest.mtime) newest = { file: full, mtime };
        } catch (_) {
          // a file that vanished mid-walk is skipped
        }
      }
    }
  };
  walk(root);
  return newest ? newest.file : null;
}

function assistantRows(text) {
  const rows = [];
  for (const line of text.split('\n')) {
    if (!line.trim()) continue;
    let obj;
    try {
      obj = JSON.parse(line);
    } catch (_) {
      continue;
    }
    if (obj && obj.type === 'assistant' && obj.message && typeof obj.message === 'object') {
      rows.push(obj.message);
    }
  }
  return rows;
}

function proseSlice(texts) {
  let joined = texts.join('\n');
  joined = joined.replace(/```[\s\S]*?```/g, '');
  joined = joined.replace(/~~~[\s\S]*?~~~/g, '');
  return joined.slice(-PROSE_SLICE).trim();
}

function computeStats(transcriptPath, level) {
  const target = transcriptPath || newestTranscript();
  let raw = null;
  if (target) {
    try {
      raw = fs.readFileSync(target, 'utf8');
    } catch (_) {
      raw = null;
    }
  }
  if (raw === null) {
    return 'No readable transcript was found, so there are no session figures.\nlevel: ' + level;
  }
  const seen = new Set();
  let turns = 0;
  let outputTokens = 0;
  let cacheRead = 0;
  const texts = [];
  for (const msg of assistantRows(raw)) {
    const id = typeof msg.id === 'string' ? msg.id : null;
    const usage = msg.usage && typeof msg.usage === 'object' ? msg.usage : {};
    if (Array.isArray(msg.content)) {
      for (const part of msg.content) {
        if (part && part.type === 'text' && typeof part.text === 'string') texts.push(part.text);
      }
    }
    if (id && seen.has(id)) continue;
    if (id) seen.add(id);
    turns += 1;
    outputTokens += Number(usage.output_tokens) || 0;
    cacheRead += Number(usage.cache_read_input_tokens) || 0;
  }
  const lines = [
    'assistant turns: ' + turns,
    'output tokens: ' + outputTokens,
    'cache-read input tokens: ' + cacheRead,
    'level: ' + level,
  ];
  const slice = proseSlice(texts);
  if (slice.length > PROSE_MIN) {
    const run = common.runDetector([], slice, 8000);
    const report = run.launched ? common.parseReport(run.stdout) : null;
    if (report) {
      lines.push('session prose ai_tell_score: ' + report._metrics.ai_tell_score);
    }
  }
  return lines.join('\n');
}

function isStatsCommand(prompt) {
  return /^\/prosecheck(?::prosecheck)?\s+stats\s*$/i.test(String(prompt || '').trim());
}

module.exports = { computeStats, isStatsCommand };

if (require.main === module) {
  try {
    const payload = common.readStdinJson();
    if (isStatsCommand(payload.prompt)) {
      const { level } = common.readLevel();
      common.emitBlock(computeStats(payload.transcript_path, level));
    }
  } catch (_) {
    // A hook never fails the host session.
  }
  process.exitCode = 0;
}
