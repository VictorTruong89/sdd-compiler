"""Decoding and prose extraction for the prosecheck detector (standard library only)."""

import html.parser
import json
import os
import re
import xml.etree.ElementTree as ET
import zipfile

SCAN_WINDOW = 262144
PLAIN_CAP = 512 * 1024
ARCHIVE_CAP = 4 * 1024 * 1024

PLAIN_EXT = {".md", ".mdx", ".markdown", ".txt", ".text", ".rst", ".tex", ".org", ".adoc"}
ZIP_EXT = {".docx", ".docm", ".pptx", ".pptm", ".xlsx", ".xlsm", ".odt", ".odp", ".ods", ".epub"}
NOTEBOOK_EXT = {".ipynb"}
SUPPORTED_EXT = PLAIN_EXT | ZIP_EXT | NOTEBOOK_EXT
BINARY_EXT = {".pdf", ".rtf"}


class ReadError(Exception):
    """The path cannot be read, or it is an archive type whose bytes are not a zip."""


class EmptyInput(Exception):
    """Extracted prose is empty."""


def decode_bytes(data):
    """Return text for a byte buffer, or None when it is not text."""
    if data.startswith((b"\xff\xfe", b"\xfe\xff")):
        try:
            text = data.decode("utf-16")
        except UnicodeDecodeError:
            return None
    else:
        if b"\x00" in data:
            return None
        if data.startswith(b"\xef\xbb\xbf"):
            data = data[3:]
        text = data.decode("utf-8", errors="replace")
    if text.startswith("﻿"):
        text = text[1:]
    return text


def _local(tag):
    return tag.rsplit("}", 1)[-1] if isinstance(tag, str) else ""


def _zip_read(zf, name):
    try:
        return zf.read(name)
    except KeyError:
        return None


def _docx_text(zf):
    xml = _zip_read(zf, "word/document.xml")
    if xml is None:
        return ""
    return _ooxml_paragraphs(xml, para="p", run="t", tab="tab", br="br")


def _ooxml_paragraphs(xml, para, run, tab, br):
    """Paragraph text for WordprocessingML and DrawingML-style markup."""
    try:
        root = ET.fromstring(xml)
    except ET.ParseError:
        return ""
    paras = []
    for p in root.iter():
        if _local(p.tag) != para:
            continue
        pieces = []
        for node in p.iter():
            name = _local(node.tag)
            if name == run and node.text:
                pieces.append(node.text)
            elif name == tab:
                pieces.append("\t")
            elif name == br:
                pieces.append("\n")
        paras.append("".join(pieces))
    return "\n\n".join(p for p in paras if p.strip())


def _pptx_text(zf):
    slides = [n for n in zf.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)]
    slides.sort(key=lambda n: int(re.search(r"(\d+)", os.path.basename(n)).group(1)))
    out = []
    for name in slides:
        text = _ooxml_paragraphs(zf.read(name), para="p", run="t", tab="tab", br="br")
        if text.strip():
            out.append(text)
    return "\n\n".join(out)


def _xlsx_text(zf):
    shared = []
    sst = _zip_read(zf, "xl/sharedStrings.xml")
    if sst is not None:
        try:
            root = ET.fromstring(sst)
        except ET.ParseError:
            root = None
        if root is not None:
            for si in root:
                if _local(si.tag) == "si":
                    shared.append("".join(n.text or "" for n in si.iter() if _local(n.tag) == "t"))
    sheets = [n for n in zf.namelist() if re.match(r"xl/worksheets/sheet\d+\.xml$", n)]
    sheets.sort(key=lambda n: int(re.search(r"(\d+)", os.path.basename(n)).group(1)))
    out = []
    for name in sheets:
        try:
            root = ET.fromstring(zf.read(name))
        except ET.ParseError:
            continue
        for c in root.iter():
            if _local(c.tag) != "c":
                continue
            kind = c.attrib.get("t", "")
            if kind == "s":
                v = next((n.text for n in c if _local(n.tag) == "v"), None)
                if v is not None and v.strip().isdigit() and int(v) < len(shared):
                    out.append(shared[int(v)])
            elif kind == "inlineStr":
                out.append("".join(n.text or "" for n in c.iter() if _local(n.tag) == "t"))
            elif kind == "str":
                v = next((n.text for n in c if _local(n.tag) == "v"), None)
                if v:
                    out.append(v)
            else:
                continue
            out.append("\n")
    return "".join(out).strip("\n")


def _odf_text(zf):
    xml = _zip_read(zf, "content.xml")
    if xml is None:
        return ""
    try:
        root = ET.fromstring(xml)
    except ET.ParseError:
        return ""
    out = []

    def walk(node):
        name = _local(node.tag)
        if name in ("p", "h"):
            out.append("\n")
        if node.text:
            out.append(node.text)
        for child in node:
            cname = _local(child.tag)
            if cname == "s":
                out.append(" " * int(child.attrib.get("{urn:oasis:names:tc:opendocument:xmlns:text:1.0}c", "1")))
            elif cname == "tab":
                out.append("\t")
            elif cname == "line-break":
                out.append("\n")
            else:
                walk(child)
            if child.tail:
                out.append(child.tail)
        if name in ("p", "h"):
            out.append("\n")

    walk(root)
    return "".join(out)


class _EpubHTML(html.parser.HTMLParser):
    SKIP = {"head", "style", "script", "nav", "title"}
    BLOCK = {"p", "div", "br", "li", "h1", "h2", "h3", "h4", "h5", "h6", "tr", "section", "blockquote"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.skip = 0

    def handle_starttag(self, tag, attrs):
        if tag in self.SKIP:
            self.skip += 1
        elif tag in self.BLOCK:
            self.parts.append("\n")

    def handle_endtag(self, tag):
        if tag in self.SKIP:
            self.skip = max(0, self.skip - 1)
        elif tag in self.BLOCK:
            self.parts.append("\n")

    def handle_data(self, data):
        if not self.skip:
            self.parts.append(data)


def _natural_key(name):
    return [int(p) if p.isdigit() else p.lower() for p in re.split(r"(\d+)", name)]


def _epub_text(zf):
    names = [n for n in zf.namelist()
             if n.lower().endswith((".xhtml", ".html", ".htm"))]
    names.sort(key=_natural_key)
    out = []
    for name in names:
        parser = _EpubHTML()
        parser.feed(zf.read(name).decode("utf-8", errors="replace"))
        text = "".join(parser.parts)
        if text.strip():
            out.append(text)
    return "\n\n".join(out)


def _notebook_text(data):
    try:
        nb = json.loads(decode_bytes(data) or "")
    except (ValueError, TypeError):
        return ""
    if not isinstance(nb, dict) or not isinstance(nb.get("cells"), list):
        return ""
    out = []
    for cell in nb["cells"]:
        if not isinstance(cell, dict) or cell.get("cell_type") != "markdown":
            continue
        src = cell.get("source", "")
        if isinstance(src, list) and all(isinstance(s, str) for s in src):
            src = "".join(src)
        if not isinstance(src, str):
            continue
        if src.strip():
            out.append(src)
    return "\n".join(out)


def _archive_text(path, ext):
    try:
        zf = zipfile.ZipFile(path)
    except (zipfile.BadZipFile, OSError):
        raise ReadError("cannot read input: not a readable zip archive")
    with zf:
        try:
            if ext in (".docx", ".docm"):
                return _docx_text(zf)
            if ext in (".pptx", ".pptm"):
                return _pptx_text(zf)
            if ext in (".xlsx", ".xlsm"):
                return _xlsx_text(zf)
            if ext in (".odt", ".odp", ".ods"):
                return _odf_text(zf)
            if ext == ".epub":
                return _epub_text(zf)
        except (zipfile.BadZipFile, KeyError, RuntimeError, OSError):
            raise ReadError("cannot read input: archive member unreadable")
    return ""


def clean_edges(text):
    """Drop leading and trailing whitespace and collapse runs of blank lines to one."""
    return re.sub(r"\n{3,}", "\n\n", text).strip()


def extract_path(path):
    """Return extracted prose for a file path, or raise ReadError."""
    ext = os.path.splitext(path)[1].lower()
    if os.path.isdir(path):
        raise ReadError("cannot read input: " + path + " is a directory")
    try:
        size = os.path.getsize(path)
    except OSError as exc:
        raise ReadError("cannot read input: " + str(exc))
    if ext in ZIP_EXT | NOTEBOOK_EXT and size > ARCHIVE_CAP:
        raise ReadError("cannot read input: file over archive cap")
    if ext in ZIP_EXT:
        return clean_edges(_archive_text(path, ext))
    try:
        with open(path, "rb") as fh:
            data = fh.read()
    except OSError as exc:
        raise ReadError("cannot read input: " + str(exc))
    if ext in NOTEBOOK_EXT:
        return clean_edges(_notebook_text(data))
    if ext in BINARY_EXT:
        return ""
    text = decode_bytes(data)
    if text is None:
        return ""
    return text
