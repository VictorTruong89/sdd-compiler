"""Markdown masking and structural helpers for the prosecheck detector."""

import re
import statistics

_WORD_RE = re.compile(r"(?:[^\W_]|['’-])+")
_FENCE_RE = re.compile(r"^ {0,3}(`{3,}|~{3,})")
_BADGE_LINE_RE = re.compile(r"^\s*(\[!\[[^\]]*\]\([^)]*\)\]\([^)]*\)\s*)+$")
_HR_RE = re.compile(r"^ {0,3}([-*_])( *\1){2,} *$")


def words(text):
    """Words are runs of letters, digits, apostrophes, and hyphens."""
    return [w for w in _WORD_RE.findall(text) if any(c.isalnum() for c in w)]


def _blank(chars):
    return "".join("\n" if c == "\n" else " " for c in chars)


def mask_markdown(text):
    """Blank out spans that generate no findings; the result keeps the same length."""
    chars = list(text)
    lines = text.split("\n")
    offsets = []
    pos = 0
    for line in lines:
        offsets.append(pos)
        pos += len(line) + 1

    def blank_range(start, end):
        chars[start:end] = list(_blank(text[start:end]))

    # YAML front matter at the very start of the text.
    if lines and lines[0].strip() == "---":
        for k in range(1, len(lines)):
            if lines[k].strip() in ("---", "..."):
                blank_range(0, offsets[k] + len(lines[k]))
                break

    in_fence = None
    indented_prev_blank = True
    in_indented_code = False
    quote_run = []
    for k, line in enumerate(lines):
        start = offsets[k]
        end = start + len(line)
        if in_fence:
            blank_range(start, end)
            m = re.match(r"^ {0,3}(`{3,}|~{3,})\s*$", line)
            if m and m.group(1)[0] == in_fence[0] and len(m.group(1)) >= len(in_fence):
                in_fence = None
            continue
        m = _FENCE_RE.match(line)
        if m:
            in_fence = m.group(1)
            blank_range(start, end)
            in_indented_code = False
            continue
        is_blank = line.strip() == ""
        if re.match(r"^( {4,}|\t)", line) and (indented_prev_blank or in_indented_code) and not is_blank:
            blank_range(start, end)
            in_indented_code = True
            indented_prev_blank = False
            continue
        in_indented_code = False
        indented_prev_blank = is_blank
        if line.lstrip().startswith(">"):
            quote_run.append((start, end))
        else:
            if len(quote_run) >= 2:
                for qs, qe in quote_run:
                    blank_range(qs, qe)
            quote_run = []
        if line.count("|") >= 2 and line.lstrip().startswith("|") or re.match(r"^\s*\|?[\s:-]*\|[\s:|-]*$", line) and "-" in line:
            blank_range(start, end)
            continue
        if _BADGE_LINE_RE.match(line):
            blank_range(start, end)
            continue
    if len(quote_run) >= 2:
        for qs, qe in quote_run:
            blank_range(qs, qe)

    masked = "".join(chars)
    # Inline code spans.
    masked = re.sub(r"(`+)(.+?)\1", lambda m: _blank(m.group(0)), masked)
    return masked


def lines_of(masked):
    return masked.split("\n")


def paragraphs(masked):
    """Blank-line separated paragraphs as (start, end) offsets into the masked text."""
    result = []
    pos = 0
    cur_start = None
    for line in masked.split("\n"):
        end = pos + len(line)
        if line.strip():
            if cur_start is None:
                cur_start = pos
            cur_end = end
        else:
            if cur_start is not None:
                result.append((cur_start, cur_end))
                cur_start = None
        pos = end + 1
    if cur_start is not None:
        result.append((cur_start, cur_end))
    return result


_SENT_RE = re.compile(r"[^.!?\n]+(?:[.!?]+|$)")


def sentences(masked):
    """Sentence spans (start, end) in the masked text; line breaks also end sentences."""
    out = []
    for m in _SENT_RE.finditer(masked):
        if m.group(0).strip():
            out.append((m.start(), m.end()))
    return out


def _cv(values):
    if len(values) < 2:
        return None
    mean = statistics.fmean(values)
    if mean == 0:
        return None
    return statistics.pstdev(values) / mean


def sentence_word_counts(masked):
    return [len(words(masked[s:e])) for s, e in sentences(masked)]


def monotony_fires(masked):
    counts = [c for c in sentence_word_counts(masked) if c > 0]
    if len(counts) < 3:
        return False
    cv = _cv(counts)
    return cv is not None and cv < 0.35


def uniform_paragraphs_fire(masked):
    counts = [len(words(masked[s:e])) for s, e in paragraphs(masked)]
    counts = [c for c in counts if c > 0]
    if len(counts) < 4:
        return False
    cv = _cv(counts)
    return cv is not None and cv < 0.4


def alternation_runs(masked):
    """Count runs of six or more sentences whose lengths alternate strictly, with big jumps."""
    counts = [c for c in sentence_word_counts(masked) if c > 0]
    runs = 0
    run = 1
    prev_sign = 0
    for a, b in zip(counts, counts[1:]):
        diff = b - a
        sign = 1 if diff > 0 else (-1 if diff < 0 else 0)
        if sign and sign != prev_sign and abs(diff) >= 6 and sign != 0:
            run += 1
            if run == 6:
                runs += 1
            prev_sign = sign
        else:
            run = 1
            prev_sign = sign
    return runs


def heading_lines(masked):
    """Return (index, text) for ATX headings; index is the line number."""
    out = []
    for i, line in enumerate(masked.split("\n")):
        m = re.match(r"^ {0,3}#{1,6}\s+(.*?)\s*#*\s*$", line)
        if m:
            out.append((i, m.group(1)))
    return out
