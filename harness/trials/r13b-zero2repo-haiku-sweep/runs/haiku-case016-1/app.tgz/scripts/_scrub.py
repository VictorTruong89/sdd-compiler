"""Character layer for the prosecheck detector: invisible characters, spaces, homoglyphs, cleanup."""

import unicodedata

# Lookalikes of ASCII Latin letters drawn from Cyrillic, Greek, and Armenian.
_LOOKALIKES = {
    "а": "a", "с": "c", "ԁ": "d", "е": "e", "ѕ": "s",
    "һ": "h", "і": "i", "ј": "j", "о": "o", "р": "p",
    "ѵ": "v", "ԝ": "w", "х": "x", "у": "y",
    "ο": "o", "ν": "v", "ρ": "p", "ι": "i",
    "А": "A", "В": "B", "С": "C", "Е": "E", "Н": "H",
    "І": "I", "Ј": "J", "К": "K", "М": "M", "О": "O",
    "Р": "P", "Ѕ": "S", "Т": "T", "Х": "X", "У": "Y",
    "Α": "A", "Β": "B", "Ε": "E", "Ζ": "Z", "Η": "H",
    "Ι": "I", "Κ": "K", "Μ": "M", "Ν": "N", "Ο": "O",
    "Ρ": "P", "Τ": "T", "Υ": "Y", "Χ": "X",
}

_SCRIPT_KEEP_ZWSP = [(0x0E00, 0x0EFF), (0x1000, 0x109F), (0x1780, 0x17FF),
                     (0x3040, 0x30FF), (0x3400, 0x9FFF), (0xF900, 0xFAFF)]
_RTL = [(0x0590, 0x08FF), (0xFB1D, 0xFDFF), (0xFE70, 0xFEFF)]
_HOLD_BEFORE = set(":;!?»›%€")
_HOLD_AFTER = set("«‹")
_BIDI = set("‎‏‪‫‬‭‮⁦⁧⁨⁩")
_LINE_SEPS = (" ", " ")
_NBSP_LIKE = (" ", " ")


def _in_ranges(ch, ranges):
    if not ch:
        return False
    cp = ord(ch)
    return any(lo <= cp <= hi for lo, hi in ranges)


def _is_emojiish(ch):
    if not ch:
        return False
    cp = ord(ch)
    return cp >= 0x2000 and (unicodedata.category(ch) in ("So", "Sk") or cp >= 0x1F000 or _in_ranges(ch, [(0x4E00, 0x9FFF)]))


def _is_invisible_default(ch):
    if ch in "\t\n\r":
        return False
    cat = unicodedata.category(ch)
    if cat in ("Cc", "Cf"):
        return True
    cp = ord(ch)
    if 0xFE00 <= cp <= 0xFE0F or 0xE0100 <= cp <= 0xE01EF:
        return True
    if 0xE0000 <= cp <= 0xE0FFF:
        return True
    if cp in (0x034F, 0x115F, 0x1160, 0x3164, 0xFFA0, 0x180B, 0x180C, 0x180D, 0x180F):
        return True
    return False


def invisible_kept(text, i, doc_has_rtl):
    """True when the invisible character at text[i] does a job in its position."""
    ch = text[i]
    cp = ord(ch)
    prev = text[i - 1] if i > 0 else ""
    nxt = text[i + 1] if i + 1 < len(text) else ""
    if cp in (0x200C, 0x200D):
        return any(c and ord(c) > 127 and (c.isalpha() or _is_emojiish(c)) for c in (prev, nxt))
    if 0xFE00 <= cp <= 0xFE0F:
        if _is_emojiish(prev) or _in_ranges(prev, [(0x4E00, 0x9FFF)]):
            return True
        return nxt == "⃣"
    if 0xE0000 <= cp <= 0xE0FFF:
        return prev == "\U0001F3F4" or _in_ranges(prev, [(0xE0020, 0xE007F)]) or _is_emojiish(prev)
    if cp == 0x200B:
        return _in_ranges(prev, _SCRIPT_KEEP_ZWSP) or _in_ranges(nxt, _SCRIPT_KEEP_ZWSP)
    if cp == 0x00AD:
        return prev.isalpha() and nxt.isalpha()
    if ch in _BIDI:
        return doc_has_rtl
    if cp in (0x180B, 0x180C, 0x180D, 0x180F):
        return _in_ranges(prev, [(0x1800, 0x18AF)])
    if cp in (0x17B4, 0x17B5):
        return _in_ranges(prev, [(0x1780, 0x17FF)]) or _in_ranges(nxt, [(0x1780, 0x17FF)])
    return False


def _space_held(text, i):
    prev = text[i - 1] if i > 0 else ""
    nxt = text[i + 1] if i + 1 < len(text) else ""
    return prev.isdigit() or nxt.isdigit() or nxt in _HOLD_BEFORE or prev in _HOLD_AFTER


def is_nonstandard_space(text, i):
    """True when the character at text[i] is a space separator that cleanup normalizes."""
    ch = text[i]
    if ch == " " or unicodedata.category(ch) != "Zs":
        return False
    if ch in _NBSP_LIKE and _space_held(text, i):
        return False
    return True


def _homoglyph_runs(text):
    """Yield (start, end) of letter runs that mix ASCII Latin with lookalikes and nothing else non-ASCII."""
    n = len(text)
    i = 0
    while i < n:
        if not text[i].isalpha():
            i += 1
            continue
        j = i
        while j < n and text[j].isalpha():
            j += 1
        run = text[i:j]
        has_ascii = any(c.isascii() and c.isalpha() for c in run)
        look = [c for c in run if c in _LOOKALIKES]
        others = [c for c in run if not c.isascii() and c not in _LOOKALIKES]
        if has_ascii and look and not others:
            yield i, j
        i = j


def _scan(text):
    doc_has_rtl = any(_in_ranges(c, _RTL) for c in text)
    invisible = []
    spaces = []
    for i, ch in enumerate(text):
        if _is_invisible_default(ch):
            if not invisible_kept(text, i, doc_has_rtl):
                invisible.append(i)
        elif is_nonstandard_space(text, i):
            spaces.append(i)
    homoglyphs = []
    for start, end in _homoglyph_runs(text):
        homoglyphs.extend(k for k in range(start, end) if text[k] in _LOOKALIKES)
    return invisible, spaces, homoglyphs


def layer_findings(window):
    """Return (invisible, nonstandard_spaces, homoglyphs) index lists on the scanned window."""
    return _scan(window)


def trailing_whitespace_hits(window):
    """Count the stray-whitespace sites for finding 68 on the scanned window."""
    hits = 0
    lines = window.split("\n")
    for line in lines[:-1]:
        if line.endswith((" ", "\t")):
            hits += 1
    if lines and lines[-1][-1:] in (" ", "\t"):
        hits += 1
    if window.endswith("\n\n"):
        hits += 1
    if window[:1].isspace():
        hits += 1
    return hits


def scrub(text):
    """Return cleaned text following the cleanup rules of FP-03."""
    crlf = "\r\n" in text
    text = text.replace("\r\n", "\n")
    for sep in _LINE_SEPS:
        text = text.replace(sep, "\n")
    invisible, spaces, homoglyphs = _scan(text)
    drop = set(invisible)
    norm = set(spaces)
    fold = set(homoglyphs)
    out = []
    for i, ch in enumerate(text):
        if i in drop:
            continue
        if i in norm:
            out.append(" ")
        elif i in fold:
            out.append(_LOOKALIKES[ch])
        else:
            out.append(ch)
    cleaned = "".join(out)
    ends_with_newline = cleaned.endswith("\n")
    lines = [line.rstrip(" \t") for line in cleaned.split("\n")]
    while lines and lines[0].strip() == "":
        lines.pop(0)
    body = "\n".join(lines).rstrip(" \t\n")
    if ends_with_newline and body:
        body += "\n"
    if crlf:
        body = body.replace("\n", "\r\n")
    return body
