"""Findings, 0-100 score, bands, confidence, and the report for the prosecheck detector."""

import random
import re

from _extract import SCAN_WINDOW
from _patterns import ADVICE, DECISIVE, NO_DETECTOR, PHRASE_PATTERNS, _custom_findings, _finditer_all, _rhythm_extra
from _scrub import layer_findings, trailing_whitespace_hits
from _structure import mask_markdown, sentences, words

BANDS = [(20, "clean"), (40, "light tells"), (60, "mixed"), (80, "heavy tells"), (100, "pervasive tells")]
PHRASES = {
    "clean": "reads clean",
    "light tells": "reads mostly clean",
    "mixed": "reads with some AI tells",
    "heavy tells": "reads with heavy AI tells",
    "pervasive tells": "reads with pervasive AI tells",
}
SAMPLE_CAP = 3
SAMPLE_WIDTH = 90


def band_for(score):
    for top, name in BANDS:
        if score <= top:
            return name
    return BANDS[-1][1]


def phrase_for(band):
    return PHRASES[band]


def _excerpt(text, start, end):
    lo = max(0, start - 30)
    hi = min(len(text), end + 30)
    snippet = " ".join(text[lo:hi].split())
    if len(snippet) > SAMPLE_WIDTH:
        snippet = snippet[:SAMPLE_WIDTH]
    prefix = "..." if lo > 0 else ""
    suffix = "..." if hi < len(text) else ""
    return prefix + snippet + suffix


def _finding(num, slug, label, spans, original, count=None):
    spans = list(spans)
    samples = []
    for s, e in spans[:SAMPLE_CAP]:
        samples.append(_excerpt(original, s, e))
    return {
        "num": num,
        "key": "%d_%s" % (num, slug),
        "label": label,
        "count": count if count is not None else len(spans),
        "samples": samples,
        "advice": num in ADVICE or slug == "negative_parallelism",
        "decisive": num in DECISIVE,
    }


PARALLELISM_RES = [
    r"\bit(?:’s|'s) not (?:just|merely) (?:about|a|an)\b",
    r"\bnot only\b[^.!?\n]{0,40}?\bbut\b",
    r"\bdoesn(?:’t|'t) just\b[^,.!?\n]{0,40}?\bit\b",
]


def _collect(window):
    """Return the list of finding dicts for the scan window (not yet scored)."""
    masked = mask_markdown(window)
    findings = []
    custom = _custom_findings(masked, window)

    for num in sorted(PHRASE_PATTERNS):
        if num in NO_DETECTOR or num in custom:
            continue
        slug, label, rxs = PHRASE_PATTERNS[num]
        if not rxs:
            continue
        spans = _finditer_all(rxs, masked)
        if spans:
            findings.append(_finding(num, slug, label, spans, window))

    for num, (slug, label, spans) in sorted(custom.items()):
        findings.append(_finding(num, slug, label, spans, window))

    for num, (slug, label, spans) in sorted(_rhythm_extra(masked).items()):
        findings.append(_finding(num, slug, label, spans, window))

    # 63: all-capitals bracketed slot, not followed by a link.
    slot = [m.span() for m in re.finditer(r"\[[A-Z][A-Z \-]{2,}\](?![(\[])", masked)]
    if slot:
        base = [f for f in findings if f["num"] == 63]
        if base:
            base[0]["count"] += len(slot)
            base[0]["samples"] = (base[0]["samples"] + [_excerpt(window, s, e) for s, e in slot])[:SAMPLE_CAP]
        else:
            findings.append(_finding(63, "placeholder_text", "placeholder / template text", slot, window))

    # 17: parallelism form (writing advice) reported beside the tailing-negation form.
    par = []
    for rx in PARALLELISM_RES:
        par.extend(m.span() for m in re.finditer(rx, masked, flags=re.I))
    if par:
        findings.append(_finding(17, "negative_parallelism", "negative parallelism", par, window))

    # Character layer, on the scan window only.
    invisible, spaces, homoglyphs = layer_findings(window)
    if invisible:
        findings.append(_finding(62, "invisible_characters", "invisible or zero-width characters",
                                 [(i, i + 1) for i in invisible], window))
    if homoglyphs:
        findings.append(_finding(66, "homoglyphs", "mixed-script homoglyphs",
                                 [(i, i + 1) for i in homoglyphs], window))
    if spaces:
        findings.append(_finding(67, "nonstandard_spaces", "non-standard spaces",
                                 [(i, i + 1) for i in spaces], window))
    stray = trailing_whitespace_hits(window)
    if stray:
        findings.append(_finding(68, "trailing_whitespace", "trailing or stray whitespace",
                                 [(0, 1)] * stray, window))

    counts = {"invisible": len(invisible), "spaces": len(spaces), "homoglyphs": len(homoglyphs)}
    return findings, counts, masked


def _score(findings, words_in_window, sentence_count):
    """Score the findings by the rules of FP-01."""
    moving = [f for f in findings if not f["advice"]]
    families = {f["num"] for f in moving}
    if not families:
        return 0
    base = 0.0
    for f in moving:
        weight = 22 if f["decisive"] else 14
        base += weight * (1 + 0.15 * min(f["count"] - 1, 4))
    score = min(100, round(base))

    rhythm_only = all(f["num"] in (40, 44) for f in moving)
    if rhythm_only:
        score = min(score, 40)
        if families <= {40}:
            score = min(score, 20)
    if len(families) == 1:
        score = min(score, 40)

    short = words_in_window < 120
    if short:
        in_range = {n for n in families if n <= 39 or 47 <= n <= 51 or n == 69}
        if len(in_range) >= 3:
            score = max(score, 45)
        elif len(in_range) >= 2:
            score = max(score, 25)
    if words_in_window >= 400:
        if len(families) >= 6:
            score = max(score, 45)
        elif len(families) >= 5:
            score = max(score, 25)

    decisive = {f["num"] for f in moving if f["decisive"]}
    confidence = _confidence(words_in_window, families)
    if len(decisive) >= 2:
        score = max(score, 65)
    elif len(decisive) == 1 and confidence != "low" and confidence != "none":
        score = max(score, 45)

    return min(100, max(0, int(score)))


def _confidence(words_in_window, families):
    if words_in_window < 40:
        return "none"
    if words_in_window < 120:
        return "low"
    if words_in_window < 300:
        return "low" if len(families) <= 1 else "moderate"
    return "high"


def _confidence_reason(conf, words_in_window, families):
    if conf == "high":
        return ""
    if conf == "none":
        return "fewer than 40 words, too little text to score"
    if words_in_window < 120:
        return "only %d words; short text is a weak signal" % words_in_window
    if words_in_window < 300 and len(families) <= 1:
        return "only one score-moving family fired in %d words" % words_in_window
    return "%d words; under 300 words is a moderate signal" % words_in_window


def _interval(window, samples_rng):
    """Resampled 5th-95th percentile interval over sentences; None when too few."""
    masked = mask_markdown(window)
    spans = sentences(masked)
    if len(spans) < 4:
        return None, "too few sentences for an interval (need at least four)"
    texts = [window[s:e] for s, e in spans]
    scores = []
    for _ in range(30):
        pick = [texts[samples_rng.randrange(len(texts))] for _ in texts]
        sub = " ".join(pick)
        f, _c, _m = _collect(sub)
        scores.append(_score(f, len(words(sub)), len(texts)))
    scores.sort()
    lo = scores[int(0.05 * (len(scores) - 1))]
    hi = scores[int(0.95 * (len(scores) - 1))]
    return [min(lo, hi), max(lo, hi)], "resampled 5th-95th percentile over sentences, 30 draws, fixed seed"


def analyze(text, ci=False):
    """Return the report object for extracted prose (already non-empty)."""
    truncated = len(text) > SCAN_WINDOW
    window = text[:SCAN_WINDOW]
    findings, counts, _masked = _collect(window)
    wc = len(words(window))
    sentence_count = len(sentences(mask_markdown(window)))
    moving = [f for f in findings if not f["advice"]]
    families = {f["num"] for f in moving}
    score = _score(findings, wc, sentence_count)
    band = band_for(score)
    conf = _confidence(wc, families)

    report = {}
    for f in sorted(findings, key=lambda x: (x["num"], x["key"])):
        report[f["key"]] = {"label": f["label"], "count": f["count"], "samples": f["samples"]}

    metrics = {
        "scanned_chars": len(window),
        "truncated": truncated,
        "ai_tell_score": score,
        "ai_tell_band": band,
        "confidence": conf,
        "confidence_reason": _confidence_reason(conf, wc, families),
        "patterns_flagged": len(findings),
        "invisible_chars": counts["invisible"],
        "nonstandard_spaces": counts["spaces"],
        "homoglyphs": counts["homoglyphs"],
    }
    if ci:
        interval, note = _interval(window, random.Random(20240601))
        metrics["score_ci"] = interval
        metrics["score_ci_note"] = note
    report["_metrics"] = metrics
    return report
