#!/usr/bin/env python3
"""prosecheck detector command line: scores AI-writing patterns in prose (standard library only).

Usage: detect.py [--clean] [--ci] [--] [FILE]
"""

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from _extract import ReadError, decode_bytes, extract_path  # noqa: E402
from _scrub import scrub  # noqa: E402
from _score import analyze  # noqa: E402

USAGE_LINE = "usage: detect.py [--clean] [--ci] [--] [FILE]"
USAGE = """usage: detect.py [--clean] [--ci] [--] [FILE]

Score a prose file, or standard input, for AI-writing patterns.

  --clean       print the scrubbed text instead of the JSON report
  --ci          add a low/high interval on the score (needs four or more sentences)
  --            end option parsing so FILE may begin with a dash
  -h, --help    print this usage message and exit

With no FILE, standard input is read as UTF-8 text.
Only the first of several FILE operands is scanned.
"""


def _error(message, code):
    sys.stderr.write(json.dumps({"error": message}) + "\n")
    return code


def _emit(text):
    sys.stdout.write(text)
    sys.stdout.flush()


def main(argv):
    clean = False
    ci = False
    operands = []
    options_done = False
    for arg in argv:
        if options_done:
            operands.append(arg)
        elif arg == "--":
            options_done = True
        elif arg in ("-h", "--help"):
            _emit(USAGE)
            return 0
        elif arg == "--clean":
            clean = True
        elif arg == "--ci":
            ci = True
        elif arg.startswith("-") and arg != "-":
            return _error("unknown option: %s (see --help)" % arg, 2)
        else:
            operands.append(arg)

    if len(operands) > 1:
        sys.stderr.write("detect.py: scanning only the first file: %s\n" % operands[0])

    try:
        if operands:
            text = extract_path(operands[0])
        else:
            text = decode_bytes(sys.stdin.buffer.read()) or ""
    except ReadError as exc:
        return _error(str(exc), 1)

    if not text.strip():
        return _error("empty input", 1)

    if clean:
        _emit(scrub(text))
        return 0

    report = analyze(text, ci=ci)
    _emit(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    return 0


if __name__ == "__main__":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
        sys.stdin.reconfigure(encoding="utf-8")
    except AttributeError:
        pass
    sys.exit(main(sys.argv[1:]))
