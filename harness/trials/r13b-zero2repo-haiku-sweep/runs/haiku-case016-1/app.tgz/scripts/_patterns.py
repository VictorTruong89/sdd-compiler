"""Catalogue of machine-checked AI-writing patterns for the prosecheck detector."""

import re

from _structure import (alternation_runs, heading_lines, lines_of, monotony_fires,
                        paragraphs, sentences, uniform_paragraphs_fire, words)

# Catalogue numbers with no detector: never reported.
NO_DETECTOR = {7, 9, 28, 29, 43, 45, 49, 52, 53}
# Writing advice: reported, weight zero.
ADVICE = {4, 19, 22, 41, 42, 46, 54, 55, 58, 60, 61, 68}
# Decisive families.
DECISIVE = {62, 63, 64, 65, 66, 13, 47, 50, 48}
# Rhythm kinds (families that count for the rhythm ceiling).
RHYTHM = {40, 41, 44, 55}

AP = "[’']"  # straight or curly apostrophe


def _alt(words_):
    return "|".join(re.escape(w) for w in sorted(words_, key=len, reverse=True))


def _vocab(words_):
    """Whole-word match that also allows simple inflections for listed verbs and nouns."""
    return r"\b(?:" + _alt(words_) + r")(?:s|es|d|ed|ing)?\b"


# Catalogue-number -> (slug, label, [regexes]) for plain phrase matches.
PHRASE_PATTERNS = {
    1: ("ai_vocabulary", "AI vocabulary", [
        _vocab(["additionally", "crucial", "delve", "tapestry", "pivotal", "vibrant", "meticulous",
                "testament", "underscore", "intricate", "intricacies", "interplay", "garner",
                "bolster", "foster", "showcase", "emphasize", "enduring", "enhance", "leverage",
                "utilize", "facilitate", "encompass", "harness", "holistic", "paradigm",
                "transformative", "unprecedented", "myriad", "plethora", "robust", "seamless",
                "navigate", "embark", "craft", "landscape", "journey", "realm", "multifaceted",
                "elevate", "empower", "unlock", "genuinely", "fascinating", "nuanced"]),
        r"\balign with\b",
        r"\bcapture the (?:essence|spirit|imagination|heart|magic)\b",
    ]),
    2: ("model_dialect", "model-dialect vocabulary", [
        _vocab(["genuinely", "fascinating", "nuanced", "thoughtfully", "refreshingly",
                "strikingly", "compellingly", "supercharge", "skyrocket", "turbocharge",
                "revolutionize"]),
        r"\bquietly (?:powerful|profound|radical)\b",
        r"\bdeeply (?:human|personal|felt|unsettling)\b",
        r"\bresonates deeply\b",
        r"\bgame[- ]chang(?:er|ers|ing)\b",
        r"\bdouble down on\b",
        r"\bdive deep(?:er)? into\b",
        r"\bunlock (?:the )?(?:power|potential|value)\b",
        r"\btake\b.{1,60}?\bto the next level\b",
    ]),
    3: ("promotional_language", "promotional language", [
        r"\b(?:nestled|breathtaking|must-visit|stunning|picturesque|charming|idyllic|"
        r"world-class|top-tier|unparalleled|premier|esteemed organization|valuable asset|"
        r"passion for excellence|proven track record|results-oriented|wealth of experience|"
        r"dynamic team|fast-paced environment|deeply passionate|perfectly situated|"
        r"close-knit team|tight-knit team|uniquely positioned to)\b",
        r"\bvibrant community\b",
        r"\brich cultural heritage\b",
        r"\bin the heart of\b",
        r"\bI(?:'| am|’m) excited to (?:apply|bring)\b",
    ]),
    4: ("hyphenated_pairs", "hyphenated word-pair overuse", [
        r"\b(?:cutting-edge|state-of-the-art|best-in-class|next-generation|results-driven|"
        r"forward-thinking|data-driven|innovative-driven|game-changing|high-performing)\b",
    ]),
    5: ("simple_yet", "“simple yet X” cliché", [
        r"\bsimple yet (?:effective|powerful|profound|elegant|transformative|sophisticated|beautiful)\b",
    ]),
    10: ("significance_inflation", "significance inflation", [
        r"\b(?:stands|serves|stood|served) as an? (?:testament|reminder|symbol|beacon|cornerstone|bridge|gateway|hallmark)\b",
        r"\b(?:underscor(?:es|ed|ing)|highlight(?:s|ed|ing)?)\b(?: \w+)? (?:its|the|their|his|her) (?:importance|significance|enduring|central|vital|crucial|pivotal|key)\b",
        r"\breflects a broader (?:trend|shift|pattern)\b",
        r"\bmarks a (?:turning point|milestone|watershed|new chapter|new era)\b",
        r"\bsymboliz(?:es|ed|ing)\b",
        r"\bsets the stage for\b",
        r"\bleft an indelible mark\b",
        r"\bplays a (?:crucial|pivotal|vital|key|central|significant) role\b",
        r"\bhas (?:shaped|sparked)\b",
        r"\bhas come to (?:define|symbolize)\b",
    ]),
    11: ("notability_name_dropping", "notability name-dropping", [
        r"\b(?:featured|profiled|covered|cited|mentioned|highlighted|showcased) (?:in|by) [A-Z]\w+(?:,| and) [A-Z]\w+",
        r"\b\d[\d,.]*\s?[KkMm]?\+? (?:followers|subscribers)\b",
        r"\bstrong (?:online|digital|social media) presence\b",
        r"\bactive (?:online|digital|social media) presence\b",
        r"\bwidely covered\b",
        r"\bindependent coverage\b",
    ]),
    12: ("vague_attributions", "vague attributions", [
        r"\bexperts (?:argue|believe|say|claim|note|suggest)\b",
        r"\bindustry (?:reports|observers|analysts)\b",
        r"\bobservers have (?:cited|noted)\b",
        r"\bsome critics argue\b",
        r"\bresearchers have found\b",
        r"\bstudies suggest\b",
        r"\bit is widely believed\b",
    ]),
    14: ("conservation_padding", "conservation / ecosystem padding", [
        r"\bplays a (?:vital|crucial|key|significant) role in (?:its|the) ecosystem\b",
        r"\bconservation efforts are (?:underway|ongoing|in place)\b",
        r"\bserves as an indicator species\b",
        r"\bcontributes to biodiversity\b",
    ]),
    15: ("false_ranges", "false ranges", [
        r"\bfrom (?:the )?(?:dawn|birth|earliest days|inception|advent|emergence|humble)\b[^.!?\n]{0,120}?\bto (?:the )?(?:modern|present|current|contemporary|digital|future|mighty|vanished|towering)\b",
        r"\bfrom (?:the )?humble\b[^.!?\n]{0,120}?\bto (?:the )?(?:mighty|towering|grand|sprawling)\b",
    ]),
    16: ("ing_tails", "superficial -ing tail clauses", [
        r",\s+(?:highlighting|reflecting|symbolizing|emphasizing|underscoring|showcasing|fostering|"
        r"cultivating|encompassing|signaling|demonstrating|illustrating|representing|suggesting|"
        r"indicating|reinforcing|leveraging|aligning|embodying|exemplifying|epitomizing)\b",
    ]),
    19: ("filler_phrases", "filler phrases", [
        r"\bin order to\b", r"\bdue to the fact that\b", r"\bat this point in time\b",
        r"\bin the event that\b", r"\bhas the ability to\b",
        r"\bit is important to note that\b", r"\bit should be mentioned that\b",
        r"\bneedless to say\b",
    ]),
    20: ("empty_pivots", "empty pivot phrases", [
        r"\bit(?:’s|'s| is) worth (?:noting|mentioning) that\b",
        r"\bit bears (?:noting|mentioning) that\b",
        r"\bone thing to (?:consider|keep in mind) is\b",
        r"\bit is interesting to note that\b",
        r"\ba key consideration is\b",
        r"\ba point to highlight is\b",
    ]),
    21: ("outcome_speculation", "outcome-speculation tails", [
        r",\s+(?:raising questions about|prompting reflection on|sparking debate about|"
        r"with broader implications for|reshaping our understanding of|paving the way for|"
        r"signaling a shift toward)\b",
    ]),
    22: ("persuasive_tropes", "persuasive authority tropes", [
        r"\bhere(?:’s|'s) the thing\b", r"\bmake no mistake\b", r"\bthe truth is\b",
        r"\blet(?:’s|'s) be honest\b", r"\bthe simple fact is\b", r"\bat its core\b",
        r"\bwhat really matters\b", r"\bmore than anything\b", r"\bat the end of the day\b",
        r"\bthe bottom line is\b", r"\bfundamentally,", r"\bthe real question is\b",
        r"\bthe heart of the matter\b", r"\bthe deeper issue\b",
        r"\bwhen you get down to it\b", r"\bwhen all is said and done\b",
        r"\bin reality\b",
    ]),
    23: ("editorial_interjections", "editorial interjections", [
        r"\bit(?:’s|'s| is) important to (?:remember|note|understand|recognize)\b",
        r"\bone must note that\b",
        r"\bit is worth pointing out\b",
        r"\bit cannot be overstated that\b",
        r"\bit must be emphasized that\b",
    ]),
    24: ("self_thoroughness", "self-thoroughness phrases", [
        r"\bthis (?:comprehensive|complete) (?:guide|overview)\b",
        r"\bthis (?:comprehensive|in-depth|complete) (?:analysis|look|examination)\b",
        r"\bthis in-depth (?:analysis|look|examination)\b",
        r"\ba thorough examination of\b",
        r"\beverything you need to know about\b",
    ]),
    26: ("concrete_evidence", "“concrete evidence” defense phrase", [
        r"\bwithout concrete (?:evidence|proof)\b",
        r"\bdo you have concrete evidence\b",
        r"\bI (?:would )?need concrete (?:evidence|examples) to\b",
        r"\babsent concrete proof\b",
        r"\bprovide concrete evidence\b",
    ]),
    27: ("intro_hooks", "compulsive intro hooks", [
        r"\bin today(?:’s|'s) (?:\w+ ){0,2}?(?:world|landscape|environment|market)\b",
        r"\bin a world where\b",
        r"\bin an era of\b",
        r"\bin recent years,",
        r"\bmore than ever before\b",
        r"\bwe live in a (?:time|world) when\b",
        r"\b(?:great|exciting|big) news\b(?=[!:])",
        r"\bever (?:wanted|wondered|dreamed|wished)\b[^.!?\n]{0,200}\?",
        r"\bin an increasingly (?:interconnected|digital|competitive|complex) world\b",
    ]),
    30: ("diff_anchored", "diff-anchored writing", [
        r"\bunlike the (?:previous|prior|old|earlier) (?:version|release|implementation|approach)\b",
        r"\bthe (?:latest |new )?(?:update|release|version|change|patch|design) (?:adds|introduces|brings|delivers|includes|provides|improves)\b",
        r"\b(?:has|have) been (?:updated|refactored|improved|enhanced|changed to)\b",
        r"\bpreviously\b[^.!?\n]{0,200}\bnow\b",
        r"\bwasn(?:’t|'t) |weren(?:’t|'t) there before\b",
        r"\bwe(?:’ve|'ve| have)(?: now)? (?:added|removed|replaced|refactored|migrated)\b",
    ]),
    31: ("signposting", "signposting and announcements", [
        r"\blet(?:’s|'s) (?:dive|delve|explore) (?:into|in)?\b",
        r"\blet(?:’s|'s) (?:break this|break it) down\b",
        r"\bhere(?:’s|'s) what you need to know\b",
        r"\bwithout further ado\b",
        r"\bnow let(?:’s|'s) look at\b",
        r"\bbuckle up\b",
        r"\bstay with me\b",
        r"\bready to dive in\b",
    ]),
    32: ("cataloguing_lead_ins", "cataloguing lead-ins", [
        r"\b(?:used|uses|employs?|employed|relied on|utilizes) (?:several|various|a number of|multiple|different|many|numerous)\b",
        r"\bThese \w+ ?(?:provide|offer|give|reveal|show|allow|enable|help) (?:information|insight|understanding|details|data)\b",
        r"\b(?:is|are|was|were|remains|becomes) (?:the |a )?(?:language|currency|architecture|heartbeat|lifeblood|DNA|backbone|bedrock|engine|scaffolding|connective tissue) of\b",
    ]),
    36: ("formulaic_challenges", "formulaic challenges sections", [
        r"\bdespite (?:these|its|the) (?:challenges|obstacles)\b",
        r"\bchallenges and (?:future )?(?:prospects|outlook|legacy)\b",
        r"\bcontinues to thrive\b",
        r"\btypical of (?:emerging|urban|modern)\b",
        r"\bfaces (?:several|many|numerous) challenges\b",
    ]),
    38: ("compulsive_conclusions", "compulsive conclusion phrases", [
        r"^\s*(?:in conclusion|overall|in summary|to summarize|to conclude|all in all|in essence|ultimately)\b",
    ]),
    39: ("generic_positive_conclusions", "generic positive conclusions", [
        r"\bthe future looks bright\b",
        r"\bexciting times lie ahead\b",
        r"\bjourney toward excellence\b",
        r"\bstep in the right direction\b",
        r"\b(?:outlook|future)(?: for [^.!?\n]+)? (?:is|looks|remains) bright\b",
        r"\bwell[- ]positioned (?:for whatever comes next|for the future|for the road ahead)\b",
    ]),
    47: ("chatbot_artifacts", "chatbot artifacts", [
        r"\bI hope this helps\b",
        r"(?-i:\bCertainly!|\bOf course!)",
        r"\blet me know if you\b",
        r"\bwould you like me to\b",
        r"\bfeel free to (?:ask|reach out)\b",
        r"\bhappy to help[.!]",
        r"\bhere(?: is|’s| is| are|'s) (?:a |an |the )?(?:overview|summary|rundown|recap|brief)\b",
        r"\bhere (?:are|’s a few|'s a few) (?:some|two|three|a few)? ?(?:options|drafts|versions|variations)\b",
        r"\bhere is (?:a )?draft\b",
        r"\bdepending on the (?:vibe|tone|style)\b",
        r"\bI hope this email finds you well\b",
        r"\bas an AI(?: language model| assistant|)\b|\bas an LLM\b|\bas a large language model\b",
        r"\bto (?:answer|address) your question\b",
        r"\bin (?:response|answer) to your question\b",
        r"\byour question (?:about|regarding|concerning)\b",
        r"\bas (?:you )?(?:requested|asked),? here\b",
        r"\bhere is (?:the )?(?:draft|first pass|revised version of|for your)\b",
    ]),
    48: ("sycophantic_tone", "sycophantic tone", [
        r"\byou(?:’re|'re| are) absolutely right\b",
        r"\b(?:great|excellent|good|fantastic|wonderful|brilliant) (?:question|point)[!.,]",
        r"\bwhat a (?:thoughtful|great|wonderful|fantastic) question\b",
        r"\bthat(?:’s|'s| is) a (?:great|wonderful|fantastic|brilliant|excellent) (?:point|question)\b",
    ]),
    50: ("knowledge_cutoff", "knowledge-cutoff disclaimers", [
        r"\bas of my (?:last )?(?:training|knowledge)\b",
        r"\bup to my (?:last )?(?:training|knowledge)\b",
        r"\bwhile specific details are (?:limited|scarce|not extensively documented|not widely documented)\b",
        r"\bbased on (?:the )?available information\b",
        r"\bas of my (?:knowledge )?cutoff\b",
        r"\bmaintains a low profile\b",
        r"\bkeeps (?:his|her|their) personal life private\b",
    ]),
    51: ("copula_avoidance", "copula avoidance", [
        r"\b(?:serves|stands|functions|acts) as\b",
        r"\b(?:represents|marks) (?:a|the)\b",
        r"\bboasts\b",
        r"\bfeatures (?:a|an|the|\d[\d,.]*|several|many|numerous|multiple)\b",
        r"\boffers a\b",
        r"\brefers to\b",
    ]),
    57: ("emojis", "emojis", [
        r"[\U0001F300-\U0001FAFF\U00002600-\U000027BF\U0001F000-\U0001F2FF]",
    ]),
    63: ("placeholder_text", "placeholder / template text", [
        r"\[(?:your|insert|add|enter|placeholder|todo|tbd|tk)\b[^\]\n]*\](?![(\[])",
        r"\{\{[^}\n]*\}\}",
        r"\bx{3,}\b",
        r"\blorem ipsum\b",
    ]),
    64: ("chat_reference_markup", "chat reference-markup leak", [
        r"\bcite(?:turn|start|nav)\w*",
        r"\boai_citation\w*",
        r"\bcontentReference\b",
        r"\bnavlist\b",
        r"【\d+†[^】]*】",
    ]),
    65: ("ai_tracking_params", "AI tracking parameters", [
        r"utm_source=(?:chatgpt\.com|chat\.openai\.com|perplexity\.ai|claude\.ai|gemini\.google\.com|copilot\.microsoft\.com|poe\.com)(?![A-Za-z0-9\-])",
    ]),
    69: ("marketing_slop", "canonical marketing-slop phrases", [
        r"\bunlocking (?:your |the )?full potential\b",
        r"\bnavigating the complexities\b",
        r"\ba testament to the (?:power|importance) of\b",
        r"\bstaying ahead of the curve\b",
        r"\bturning challenges into opportunities\b",
        r"\btaking (?:something|your \w+|\w+) to the next level\b",
        r"\bharnessing the power of\b",
        r"\bpaving the way for\b",
        r"\bsaying goodbye to\b",
        r"\bimagining a world where\b",
    ]),
    13: ("article_title_noun", "article title used as a proper noun", [
        r"\bThe (?:List|Index|Compilation|Collection|Catalogue|Guide|Overview) of [^.!?\n]{2,120}? (?:is|are) (?:a|an|the)\b",
    ]),
    17: ("tailing_negation", "tailing negation", [
        r",\s+no (?:guessing|waste|wasted motion|hassle|fluff|stress|jargon)\b",
    ]),
    18: ("not_x_just_y", "“Not X, just Y” denial", [
        r"\b(?:no|not) \w+, (?:just|only|simply) \w+",
        r"\b(?:not|isn(?:’t|'t)|aren(?:’t|'t)|wasn(?:’t|'t)|weren(?:’t|'t)) (?:just|merely) (?:a |an |the )?\w+(?:,|\s?[–—-])\s*(?:it(?:’s|'s| is| was)|they(?:’re|'re| are| were)|that(?:’s|'s)|but)\b",
    ]),
}

# Hedges in a sentence; checked case-sensitively (lower case only, per the rule).
HEDGE_RE = re.compile(r"\b(?:may|might|could|possibly|potentially|arguably|perhaps|seems? (?:to|like)|appears? to|somewhat|relatively|fairly|kind of|sort of)\b")


def _finditer_all(rx_list, text):
    spans = []
    for rx in rx_list:
        for m in re.finditer(rx, text, flags=re.I | re.M):
            spans.append((m.start(), m.end()))
    return spans


def _custom_findings(masked, original):
    """Return a dict num -> (slug, label, spans) for the pattern families that need code."""
    out = {}
    lines = lines_of(masked)

    # 2: model-dialect vocabulary fires only with two or more hits combined.
    slug, label, rxs = PHRASE_PATTERNS[2]
    spans = _finditer_all(rxs, masked)
    if len(spans) >= 2:
        out[2] = (slug, label, spans)

    # 3: promotional language, plus three or more marketing-imperative sentences.
    slug, label, rxs = PHRASE_PATTERNS[3]
    spans = _finditer_all(rxs, masked)
    imperative = r"^\s*(?:install|join|grab|download|try|discover|experience|escape|transform|reclaim|unlock|elevate|boost|say|imagine|explore|meet|introducing|upgrade|claim|unleash|supercharge|level|stop|start)\b"
    openers = [(s, e) for s, e in sentences(masked) if re.match(imperative, masked[s:e], flags=re.I)]
    if len(openers) >= 3:
        spans.extend(openers)
    if spans:
        out[3] = (slug, label, spans)

    # 6: stacked adjective chains: four or more comma-joined words with an adjectival one.
    chain_re = re.compile(r"\b[A-Za-z][\w-]*(?:,\s+[A-Za-z][\w-]*){2,}(?:,?\s+(?:and|or)\s+[A-Za-z][\w-]*)?\b")
    adj_suffix = re.compile(r"(?:ive|ous|able|ible|ic|ical|ant|ent|ful|less|al|ial|ary|ory|ish)$", re.I)
    stock_adj = {"powerful", "elegant", "robust", "seamless", "innovative", "dynamic", "intuitive",
                 "modern", "bold", "stunning", "vibrant", "sleek", "rich", "crisp", "clean"}
    spans = []
    for m in chain_re.finditer(masked):
        ws = re.findall(r"[A-Za-z][\w-]*", m.group(0))
        if len(ws) >= 4 and any(adj_suffix.search(w) or w.lower() in stock_adj for w in ws[:-1]):
            spans.append((m.start(), m.end()))
    if spans:
        out[6] = ("stacked_adjectives", "stacked adjective chains", spans)

    # 8: synonym cycling: three or more members of one cluster.
    clusters = [
        ["protagonist", "main character", "central figure", "hero", "heroine"],
        ["company", "firm", "organization", "enterprise", "business"],
        ["author", "writer", "novelist", "scribe"],
        ["report", "study", "analysis", "investigation", "examination"],
        ["technology", "tool", "system", "platform", "solution"],
        ["technique", "method", "approach", "strategy", "tactic"],
        ["challenge", "obstacle", "difficulty", "hurdle", "barrier"],
        ["benefit", "advantage", "upside", "strength"],
    ]
    spans = []
    for members in clusters:
        hits = []
        for member in members:
            pat = r"\b" + re.escape(member) + r"s?\b"
            hits.extend(m.span() for m in re.finditer(pat, masked, flags=re.I))
        if len({masked[s:e].lower().rstrip("s") for s, e in hits}) >= 3:
            spans.extend(hits)
    if spans:
        out[8] = ("synonym_cycling", "synonym cycling", spans)

    # 25: short auxiliary question answered at once by a one-word reply.
    qa_re = re.compile(r"\b(?:Is|Are|Can|Could|Do|Does|Did|Will|Would|Should|Has|Have|Was|Were)\b[^.!?\n]{0,60}\?\s+(?:Yes|No|Absolutely|Never|Maybe|Probably|Always)[.!]")
    spans = [m.span() for m in qa_re.finditer(masked)]
    if spans:
        out[25] = ("question_answer_rhetoric", "question-answer rhetorical pattern", spans)

    # 34: mid-essay bullet injection in a document without a heading.
    if not heading_lines(masked):
        bullet_paras = []
        prose_count = 0
        for s, e in paragraphs(masked):
            block = [ln for ln in masked[s:e].split("\n") if ln.strip()]
            if block and all(re.match(r"^\s*(?:[-*+]|\d+[.)])\s+", ln) for ln in block):
                bullet_paras.append((s, e))
            else:
                prose_count += 1
        if bullet_paras and prose_count >= 2:
            out[34] = ("mid_essay_bullets", "mid-essay bullet injection", bullet_paras)

    # 35: fragmented header: short plain line after a heading repeats a heading word.
    spans = []
    for i, text in heading_lines(masked):
        head_words = {w.lower() for w in words(text) if len(w) > 2}
        j = i + 1
        while j < len(lines) and not lines[j].strip():
            j += 1
        if j < len(lines):
            nxt = lines[j].strip()
            if (nxt and not re.match(r"^(?:#|[-*+]\s|\d+[.)]\s|\|)", nxt)
                    and len(words(nxt)) <= 4 and {w.lower() for w in words(nxt)} & head_words):
                spans.append((sum(len(x) + 1 for x in lines[:j]), sum(len(x) + 1 for x in lines[:j]) + len(nxt)))
    if spans:
        out[35] = ("fragmented_headers", "fragmented headers", spans)

    # 37: transition cluster: two or more sentence-opening transitions in one paragraph.
    trans = r"(?:^|(?<=[.!?]\s)|(?<=\n))(?:Additionally|Furthermore|Moreover|However|Nevertheless|Consequently|Subsequently|Notably)\b"
    spans = []
    for s, e in paragraphs(masked):
        hits = [m.span() for m in re.finditer(trans, masked[s:e])]
        if len(hits) >= 2:
            spans.extend((s + a, s + b) for a, b in hits)
    if spans:
        out[37] = ("transition_clusters", "transition cluster overuse", spans)

    # 33: inline-header vertical lists: a line or item opening with a bold run closed by a colon.
    spans = [m.span() for m in re.finditer(
        r"^[ \t]*(?:[-*+][ \t]+|\d+\.[ \t]+)?\*\*[^*\n]+:\*\*|^[ \t]*(?:[-*+][ \t]+)?\*\*[^*\n]+\*\*:",
        masked, flags=re.M)]
    if spans:
        out[33] = ("inline_header_lists", "inline-header vertical list", spans)

    # 40 and 44: rhythm kinds.
    if monotony_fires(masked):
        out[40] = ("sentence_length_monotony", "sentence-length monotony", [(0, min(len(masked), 1))])
    if uniform_paragraphs_fire(masked):
        out[44] = ("uniform_paragraph_length", "uniform paragraph length", [(0, min(len(masked), 1))])

    # 56: boldface spans in prose.
    bold = [m.span() for m in re.finditer(r"\*\*[^*\n]+?\*\*", masked)]
    if bold:
        out[56] = ("boldface_overuse", "boldface overuse", bold)

    # 59: title case in headings.
    small = {"a", "an", "the", "of", "in", "on", "at", "to", "for", "by", "with", "from", "up", "as",
             "off", "and", "but", "or", "nor", "so", "yet"}
    spans = []
    for i, text in heading_lines(masked):
        ws = words(text)
        if len(ws) < 3 or not ws[0][:1].isalpha() or text.isupper():
            continue
        major = [w for w in ws if w.lower() not in small]
        if len(major) >= 2 and all(w[0].isupper() for w in major):
            spans.append((masked.find(text), masked.find(text) + len(text)))
    if spans:
        out[59] = ("title_case_headings", "title case in headings", spans)

    # 70: decorative horizontal rules in a document of a couple of dozen lines or more.
    hr = [i for i, ln in enumerate(lines) if re.match(r"^ {0,3}([-*_])( *\1){2,} *$", ln)]
    if len(hr) >= 3 and len(lines) >= 24:
        out[70] = ("decorative_rules", "decorative horizontal rules", [(0, 1)] * len(hr))

    # 71: degenerate repetition: many six-word runs occur more than once.
    ws = [w.lower() for w in words(masked)]
    if len(ws) >= 12:
        grams = [tuple(ws[i:i + 6]) for i in range(len(ws) - 5)]
        counts = {}
        for g in grams:
            counts[g] = counts.get(g, 0) + 1
        repeated = sum(1 for g in grams if counts[g] > 1)
        if repeated / len(grams) >= 0.2:
            out[71] = ("degenerate_repetition", "degenerate repetition", [(0, 1)])

    return out


def _rhythm_extra(masked):
    """Advice-only rhythm kinds 41, 42, 46, 55, and 58."""
    out = {}
    runs = alternation_runs(masked)
    if runs:
        out[41] = ("mechanical_alternation", "mechanical sentence-length alternation", [(0, 1)] * runs)

    # 42: opener repetition inside one paragraph of at least three sentences.
    spans = []
    for s, e in paragraphs(masked):
        sents = [(a, b) for a, b in sentences(masked[s:e])]
        if len(sents) < 3:
            continue
        openers = {}
        for a, b in sents:
            w = words(masked[s + a:s + b])[:2]
            if len(w) == 2:
                openers.setdefault(tuple(x.lower() for x in w), []).append(s + a)
        for key, pos in openers.items():
            if len(pos) >= 3:
                spans.extend((p, p + 1) for p in pos)
    if spans:
        out[42] = ("opener_repetition", "opener repetition", spans)

    # 46: long document with no semicolon and almost no parentheses.
    word_count = len(words(masked))
    if word_count >= 300 and ";" not in masked and masked.count("(") <= 1:
        out[46] = ("semicolon_underuse", "semicolon and parenthesis underuse", [(0, 1)])

    # 55: first-person writing with most contractable forms written out.
    first = len(re.findall(r"\b(?:I|we|my|our|me|us)\b", masked))
    if word_count and first / word_count >= 0.03:
        written = len(re.findall(r"\b(?:I am|we are|it is|that is|do not|does not|is not|are not|cannot|will not|I will|we will|I have|we have)\b", masked, flags=re.I))
        contracted = len(re.findall(r"\b\w+(?:’|')(?:re|m|s|ve|ll|d|t)\b", masked))
        if written >= 3 and contracted <= written // 4:
            out[55] = ("contraction_absence", "contraction absence", [(0, 1)])

    # 58: two or more em dashes in one paragraph.
    spans = []
    for s, e in paragraphs(masked):
        dashes = [m.start() for m in re.finditer("—", masked[s:e])]
        if len(dashes) >= 2:
            spans.extend((s + d, s + d + 1) for d in dashes)
    if spans:
        out[58] = ("em_dash_overuse", "em-dash overuse", spans)

    # 60: curly quotation marks, any single or double.
    curly = [m.span() for m in re.finditer("[“”‘’]", masked)]
    if curly:
        out[60] = ("curly_quotes", "curly quotation marks", curly)

    # 61: hyphen-for-en-dash between two years.
    spans = []
    for m in re.finditer(r"\b((?:1[89]|20)\d\d)-((?:1[89]|20)\d\d)\b", masked):
        if int(m.group(1)) < int(m.group(2)):
            spans.append(m.span())
    if spans:
        out[61] = ("hyphen_for_en_dash", "hyphen-for-en-dash in numeric ranges", spans)

    # 54: hedge stacking: two or more hedges in one sentence.
    spans = []
    for s, e in sentences(masked):
        hits = [m.span() for m in HEDGE_RE.finditer(masked[s:e])]
        if len(hits) >= 2:
            spans.extend((s + a, s + b) for a, b in hits)
    if spans:
        out[54] = ("hedge_stacking", "hedge stacking", spans)

    return out
