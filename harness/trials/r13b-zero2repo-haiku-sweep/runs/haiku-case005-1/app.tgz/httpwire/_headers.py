"""Ordered header lists with name/value normalization."""

import re

from ._util import LocalProtocolError, TOKEN_RE, to_bytes

MAX_CONTENT_LENGTH_DIGITS = 18

_CONTENT_LENGTH_RE = re.compile(rb"[0-9]+")
_BAD_VALUE_RE = re.compile(rb"[\x00\r\n\x0b\x0c]")
_OWS = b" \t"


class Headers(object):
    """An ordered list of header fields.

    Iterating or indexing yields ``(lowercased_name, value)`` byte pairs.
    ``raw_items()`` yields ``(name, value)`` with each name spelled as the
    caller supplied it.
    """

    __slots__ = ("_items",)

    def __init__(self, headers=()):
        self._items = tuple(_normalize(headers))

    def __iter__(self):
        for _, lower, value in self._items:
            yield (lower, value)

    def __len__(self):
        return len(self._items)

    def __getitem__(self, index):
        if isinstance(index, slice):
            return [(lower, value) for _, lower, value in self._items[index]]
        _, lower, value = self._items[index]
        return (lower, value)

    def raw_items(self):
        return [(raw, value) for raw, _, value in self._items]

    def get_all(self, lower_name):
        """Return the values of every header whose lowercase name matches."""
        return [value for _, lower, value in self._items if lower == lower_name]

    def __eq__(self, other):
        if isinstance(other, Headers):
            return self._items == other._items
        try:
            return list(self) == list(other)
        except TypeError:
            return NotImplemented

    __hash__ = None

    def __repr__(self):
        return "Headers(%r)" % (list(self),)


def _normalize(headers):
    if isinstance(headers, Headers):
        headers = headers.raw_items()
    try:
        iterator = iter(headers)
    except TypeError:
        raise LocalProtocolError("headers must be a sequence of (name, value) pairs")
    triples = []
    for pair in iterator:
        try:
            name, value = pair
        except (TypeError, ValueError):
            raise LocalProtocolError("each header must be a (name, value) pair")
        raw = to_bytes(name, "header name")
        value = to_bytes(value, "header value")
        if not TOKEN_RE.fullmatch(raw):
            raise LocalProtocolError("invalid header name %r" % (raw,))
        if (
            _BAD_VALUE_RE.search(value)
            or value[:1] in (b" ", b"\t")
            or value[-1:] in (b" ", b"\t")
        ):
            raise LocalProtocolError("invalid header value %r" % (value,))
        triples.append([raw, raw.lower(), value])
    return [tuple(t) for t in _merge_framing_headers(triples)]


def _merge_framing_headers(triples):
    """Collapse Content-Length and check Transfer-Encoding."""
    cl_positions = [i for i, t in enumerate(triples) if t[1] == b"content-length"]
    if cl_positions:
        numbers = []
        for i in cl_positions:
            for piece in triples[i][2].split(b","):
                piece = piece.strip(_OWS)
                if (
                    not _CONTENT_LENGTH_RE.fullmatch(piece)
                    or len(piece) > MAX_CONTENT_LENGTH_DIGITS
                ):
                    raise LocalProtocolError("invalid Content-Length %r" % (piece,))
                numbers.append(piece)
        if len(set(int(n) for n in numbers)) > 1:
            raise LocalProtocolError("conflicting Content-Length values")
        merged = [triples[cl_positions[0]][0], b"content-length", numbers[0]]
        result = []
        for i, triple in enumerate(triples):
            if i == cl_positions[0]:
                result.append(merged)
            elif i not in cl_positions:
                result.append(triple)
        triples = result

    te_positions = [i for i, t in enumerate(triples) if t[1] == b"transfer-encoding"]
    if len(te_positions) > 1:
        raise LocalProtocolError("more than one Transfer-Encoding header", 501)
    if te_positions:
        triple = triples[te_positions[0]]
        if triple[2].lower() != b"chunked":
            raise LocalProtocolError(
                "unsupported Transfer-Encoding %r" % (triple[2],), 501
            )
        triple[2] = b"chunked"
    return triples
