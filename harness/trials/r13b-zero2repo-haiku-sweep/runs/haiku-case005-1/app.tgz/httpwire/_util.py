"""Shared sentinels, state values, error classes, and small byte helpers."""

import re


class _Sentinel(object):
    """A named marker object, compared by identity."""

    __slots__ = ("_name",)

    def __init__(self, name):
        self._name = name

    def __repr__(self):
        return self._name


CLIENT = _Sentinel("CLIENT")
SERVER = _Sentinel("SERVER")

IDLE = _Sentinel("IDLE")
SEND_RESPONSE = _Sentinel("SEND_RESPONSE")
SEND_BODY = _Sentinel("SEND_BODY")
DONE = _Sentinel("DONE")
MUST_CLOSE = _Sentinel("MUST_CLOSE")
CLOSED = _Sentinel("CLOSED")
MIGHT_SWITCH_PROTOCOL = _Sentinel("MIGHT_SWITCH_PROTOCOL")
SWITCHED_PROTOCOL = _Sentinel("SWITCHED_PROTOCOL")
ERROR = _Sentinel("ERROR")

NEED_DATA = _Sentinel("NEED_DATA")
PAUSED = _Sentinel("PAUSED")


class ProtocolError(Exception):
    """Common base of the two protocol-error kinds (not exported)."""

    def __init__(self, msg, error_status_hint=400):
        Exception.__init__(self, msg)
        self.error_status_hint = int(error_status_hint)


class LocalProtocolError(ProtocolError):
    """The integrator's own event or send violated HTTP/1.1."""


class RemoteProtocolError(ProtocolError):
    """The peer's bytes violated HTTP/1.1."""


# RFC 7230 tchar: a header name or method must be one or more of these.
TOKEN_RE = re.compile(rb"[!#$%&'*+\-.^_`|~0-9A-Za-z]+")


def to_bytes(value, what):
    """Return ``value`` as ``bytes``: ASCII text or any bytes-like object."""
    if isinstance(value, bytes):
        return value
    if isinstance(value, str):
        try:
            return value.encode("ascii")
        except UnicodeEncodeError:
            raise LocalProtocolError("%s must be ASCII text" % what)
    try:
        return memoryview(value).tobytes()
    except TypeError:
        raise LocalProtocolError("%s must be text or bytes-like" % what)
