"""The HTTP/1.1 connection: state machine, body framing, reader, and writer."""

import re

from ._events import (
    ConnectionClosed,
    Data,
    EndOfMessage,
    InformationalResponse,
    Request,
    Response,
)
from ._util import (
    CLIENT,
    CLOSED,
    DONE,
    ERROR,
    IDLE,
    MIGHT_SWITCH_PROTOCOL,
    MUST_CLOSE,
    NEED_DATA,
    PAUSED,
    SEND_BODY,
    SEND_RESPONSE,
    SERVER,
    SWITCHED_PROTOCOL,
    LocalProtocolError,
    RemoteProtocolError,
)

DEFAULT_MAX_INCOMPLETE_EVENT_SIZE = 16 * 1024
MAX_CHUNK_SIZE_DIGITS = 20

_CHUNK_SIZE_RE = re.compile(rb"([0-9A-Fa-f]+)(?:;.*)?[ \t]*")
_STATUS_LINE_RE = re.compile(rb"HTTP/([0-9]\.[0-9]) ([0-9]{3})(?: (.*))?")
_EVENT_TYPES = (Request, InformationalResponse, Response, Data, EndOfMessage, ConnectionClosed)

_ACCEPT = "accept"
_DENY = "deny"
_CONNECT = "CONNECT"
_UPGRADE = "Upgrade"


def _other(role):
    return SERVER if role is CLIENT else CLIENT


class _Framing(object):
    """How one message body is delimited, for one direction."""

    def __init__(self, mode, remaining=0):
        # mode: "none", "empty", "length", "chunked", or "close"
        self.mode = mode
        self.remaining = remaining
        self.chunk_state = "size"  # "size", "data", "crlf", or "trailers"
        self.chunk_left = 0
        self.chunk_started = False


def _tokens(headers, lower_name):
    tokens = set()
    for name, value in headers:
        if name == lower_name:
            for piece in value.split(b","):
                token = piece.strip(b" \t").lower()
                if token:
                    tokens.add(token)
    return tokens


def _request_framing(headers):
    if headers.get_all(b"transfer-encoding"):
        return _Framing("chunked")
    lengths = headers.get_all(b"content-length")
    if lengths:
        return _Framing("length", int(lengths[0]))
    return _Framing("length", 0)


def _response_framing(method, status, headers):
    if method == b"HEAD" or status in (204, 304):
        return _Framing("empty")
    if headers.get_all(b"transfer-encoding"):
        return _Framing("chunked")
    lengths = headers.get_all(b"content-length")
    if lengths:
        return _Framing("length", int(lengths[0]))
    return _Framing("close")


def _payload_len(data):
    try:
        return memoryview(data).nbytes
    except TypeError:
        pass
    if isinstance(data, str):
        raise LocalProtocolError("data payload must be bytes")
    try:
        return len(data)
    except TypeError:
        raise LocalProtocolError("data payload has no length")


def _join(pieces):
    try:
        return b"".join(pieces)
    except TypeError:
        raise LocalProtocolError("data payload is not bytes-like")


def _header_lines(pairs):
    return b"".join(name + b": " + value + b"\r\n" for name, value in pairs)


def _request_head(event):
    pairs = event.headers.raw_items()
    host = [p for p in pairs if p[0].lower() == b"host"]
    rest = [p for p in pairs if p[0].lower() != b"host"]
    line = event.method + b" " + event.target + b" HTTP/1.1\r\n"
    return line + _header_lines(host + rest) + b"\r\n"


def _status_head(event):
    line = b"HTTP/1.1 %d %s\r\n" % (event.status_code, event.reason)
    return line + _header_lines(event.headers.raw_items()) + b"\r\n"


def _proposals(event):
    proposals = set()
    if event.method == b"CONNECT":
        proposals.add(_CONNECT)
    if event.headers.get_all(b"upgrade"):
        proposals.add(_UPGRADE)
    return proposals


def _parse_header_lines(lines):
    """Turn raw header lines into (name, value) pairs, honoring obs-fold."""
    pairs = []
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if not pairs:
                raise RemoteProtocolError("header continuation line with no header")
            name, value = pairs[-1]
            joined = b" ".join(x for x in (value, line.strip(b" \t")) if x)
            pairs[-1] = (name, joined)
            continue
        name, colon, value = line.partition(b":")
        if not colon:
            raise RemoteProtocolError("header line without a colon")
        pairs.append((name, value.strip(b" \t")))
    return pairs


class Connection(object):
    """One HTTP/1.1 connection in the client or server role.

    The connection never touches a socket. ``send`` encodes events into
    bytes for the caller to write; ``receive_data`` stores bytes read from
    the peer and ``next_event`` parses them back into events.
    """

    def __init__(self, our_role, max_incomplete_event_size=DEFAULT_MAX_INCOMPLETE_EVENT_SIZE):
        if our_role is CLIENT:
            self._our_role = CLIENT
        elif our_role is SERVER:
            self._our_role = SERVER
        else:
            raise ValueError("role must be CLIENT or SERVER, not %r" % (our_role,))
        self._their_role = _other(self._our_role)
        self._states = {CLIENT: IDLE, SERVER: IDLE}
        self._max_incomplete = int(max_incomplete_event_size)
        self._buffer = bytearray()
        self._receive_closed = False
        self._their_http_version = None
        self._keep_alive = True
        self._pending = set()
        self._request_method = None
        self._client_waiting = False
        self._out = None
        self._in = None

    # Attributes

    @property
    def our_role(self):
        return self._our_role

    @property
    def their_role(self):
        return self._their_role

    @property
    def our_state(self):
        return self._states[self._our_role]

    @property
    def their_state(self):
        return self._states[self._their_role]

    @property
    def states(self):
        return {CLIENT: self._states[CLIENT], SERVER: self._states[SERVER]}

    @property
    def their_http_version(self):
        return self._their_http_version

    @property
    def client_is_waiting_for_100_continue(self):
        return bool(self._client_waiting)

    @property
    def they_are_waiting_for_100_continue(self):
        return self._their_role is CLIENT and bool(self._client_waiting)

    @property
    def trailing_data(self):
        return (bytes(self._buffer), self._receive_closed)

    # Sending

    def send(self, event):
        return self._send(event, passthrough=False)

    def send_with_data_passthrough(self, event):
        return self._send(event, passthrough=True)

    def _send(self, event, passthrough):
        our = self._our_role
        if not isinstance(event, _EVENT_TYPES):
            raise LocalProtocolError("send() takes an event object")
        if self._states[our] is ERROR:
            raise LocalProtocolError("this side is in ERROR; send is refused")
        try:
            pieces, sent = self._plan_send(event)
            if not passthrough:
                pieces = _join(pieces)
            self._process(our, sent, True)
        except LocalProtocolError:
            self._mark_error(our)
            raise
        return pieces

    def _plan_send(self, event):
        """Check and encode an event without changing any state."""
        our = self._our_role
        kind = type(event)
        if self._sender_state(our, event) is None:
            raise LocalProtocolError(
                "%s is not allowed while our side is %r" % (kind.__name__, self._states[our])
            )
        if kind is ConnectionClosed:
            return [], event
        if kind is Request:
            if event.http_version != b"1.1":
                raise LocalProtocolError("only HTTP/1.1 requests can be sent")
            return [_request_head(event)], event
        if kind is InformationalResponse:
            if event.http_version != b"1.1":
                raise LocalProtocolError("only HTTP/1.1 responses can be sent")
            return [_status_head(event)], event
        if kind is Response:
            if event.http_version != b"1.1":
                raise LocalProtocolError("only HTTP/1.1 responses can be sent")
            event = self._prepare_response(event)
            return [_status_head(event)], event
        fr = self._out
        if kind is Data:
            size = _payload_len(event.data)
            if fr.mode == "empty":
                if size:
                    raise LocalProtocolError("this message has no body")
                return [], event
            if fr.mode == "length":
                if size > fr.remaining:
                    raise LocalProtocolError("data exceeds the declared Content-Length")
                return [event.data], event
            if fr.mode == "close":
                return [event.data], event
            if size == 0:
                return [], event
            return [b"%x\r\n" % size, event.data, b"\r\n"], event
        # EndOfMessage
        if fr.mode == "length" and fr.remaining != 0:
            raise LocalProtocolError("end of message before the declared Content-Length was sent")
        if fr.mode != "chunked":
            if len(event.headers):
                raise LocalProtocolError("trailing headers need chunked framing")
            return [], event
        return [b"0\r\n" + _header_lines(event.headers.raw_items()) + b"\r\n"], event

    def _prepare_response(self, event):
        """Pick the framing headers for a response and rewrite them if needed."""
        if self._decision(event) is _ACCEPT:
            # An accepted protocol switch carries no body and no framing headers.
            return event
        status = event.status_code
        pairs = event.headers.raw_items()
        peer_11 = self._their_http_version == b"1.1"
        has_te = bool(event.headers.get_all(b"transfer-encoding"))
        has_cl = bool(event.headers.get_all(b"content-length"))
        choice = None
        if status not in (204, 304):
            if has_cl and not has_te:
                choice = "length"
            else:
                choice = "chunked" if peer_11 else "close"
            if choice == "chunked":
                pairs = [p for p in pairs if p[0].lower() != b"content-length"]
                if not has_te:
                    pairs.append((b"Transfer-Encoding", b"chunked"))
            elif choice == "close":
                pairs = [
                    p
                    for p in pairs
                    if p[0].lower() not in (b"content-length", b"transfer-encoding")
                ]
        closing = (
            choice == "close"
            or not self._keep_alive
            or self._states[self._their_role] is ERROR
            or b"close" in _tokens(event.headers, b"connection")
        )
        if closing:
            conn_tokens = []
            for name, value in pairs:
                if name.lower() == b"connection":
                    conn_tokens.extend(value.split(b","))
            conn_tokens = [t.strip(b" \t") for t in conn_tokens]
            conn_tokens = [t for t in conn_tokens if t and t.lower() != b"keep-alive"]
            if b"close" not in [t.lower() for t in conn_tokens]:
                conn_tokens.append(b"close")
            new_pairs = []
            placed = False
            for name, value in pairs:
                if name.lower() == b"connection":
                    if not placed:
                        new_pairs.append((name, b", ".join(conn_tokens)))
                        placed = True
                else:
                    new_pairs.append((name, value))
            if not placed:
                new_pairs.append((b"Connection", b"close"))
            pairs = new_pairs
        return Response(
            status_code=status,
            headers=pairs,
            http_version=event.http_version,
            reason=event.reason,
        )

    # Receiving

    def receive_data(self, data):
        view = memoryview(data)
        if view.nbytes == 0:
            self._receive_closed = True
            return None
        if self._receive_closed:
            raise RuntimeError("received data after the peer closed its side")
        self._buffer += view.tobytes()
        return None

    def next_event(self):
        try:
            return self._next_event()
        except LocalProtocolError as exc:
            self._mark_error(self._their_role)
            raise RemoteProtocolError(str(exc), exc.error_status_hint)
        except RemoteProtocolError:
            self._mark_error(self._their_role)
            raise

    def _next_event(self):
        their = self._their_role
        state = self._states[their]
        buf = self._buffer
        if state is ERROR:
            raise RemoteProtocolError("peer already violated the protocol")
        if state is SWITCHED_PROTOCOL or state is MIGHT_SWITCH_PROTOCOL:
            return PAUSED
        if state is CLOSED:
            return ConnectionClosed()
        if state is DONE and buf:
            return PAUSED
        if state is MUST_CLOSE and buf:
            raise RemoteProtocolError("peer sent data after committing to close")
        if state in (IDLE, DONE, MUST_CLOSE) and not buf:
            if self._receive_closed:
                return self._pull_close()
            return NEED_DATA
        if state is IDLE:
            if their is not CLIENT:
                raise RemoteProtocolError("unexpected data from the server")
            return self._read_request()
        if state is SEND_RESPONSE:
            return self._read_response()
        if state is SEND_BODY:
            return self._read_body()
        raise RemoteProtocolError("unexpected data from the peer")

    def _need_more(self):
        if self._receive_closed:
            raise RemoteProtocolError("peer closed its side in the middle of a message")
        return NEED_DATA

    def _read_head(self):
        """Return (lines, bytes_consumed) for a complete head, or None."""
        buf = self._buffer
        lines = []
        pos = 0
        while True:
            newline = buf.find(b"\n", pos)
            if newline < 0:
                if len(buf) > self._max_incomplete:
                    raise RemoteProtocolError(
                        "incomplete event exceeds the size limit", 431
                    )
                return None
            line = bytes(buf[pos:newline])
            if line.endswith(b"\r"):
                line = line[:-1]
            pos = newline + 1
            if not line:
                return lines, pos
            lines.append(line)

    def _read_request(self):
        buf = self._buffer
        their = self._their_role
        if buf[0] < 33:
            raise RemoteProtocolError("request must start with a method token")
        head = self._read_head()
        if head is None:
            return self._need_more()
        lines, consumed = head
        parts = lines[0].split(b" ")
        if len(parts) != 3 or parts[2] not in (b"HTTP/1.0", b"HTTP/1.1"):
            raise RemoteProtocolError("malformed request line")
        del buf[:consumed]
        event = Request(
            method=parts[0],
            target=parts[1],
            headers=_parse_header_lines(lines[1:]),
            http_version=parts[2][5:],
        )
        self._process(their, event, False)
        return event

    def _read_response(self):
        buf = self._buffer
        their = self._their_role
        if not buf:
            return self._need_more()
        if buf[0] < 33:
            raise RemoteProtocolError("status line must not start with a space or control byte")
        head = self._read_head()
        if head is None:
            return self._need_more()
        lines, consumed = head
        match = _STATUS_LINE_RE.fullmatch(lines[0])
        if match is None or match.group(1) not in (b"1.0", b"1.1"):
            raise RemoteProtocolError("malformed status line")
        code = int(match.group(2))
        del buf[:consumed]
        kwargs = dict(
            status_code=code,
            headers=_parse_header_lines(lines[1:]),
            http_version=match.group(1),
            reason=match.group(3) or b"",
        )
        if code < 200:
            event = InformationalResponse(**kwargs)
        else:
            event = Response(**kwargs)
        self._process(their, event, False)
        return event

    def _read_body(self):
        fr = self._in
        buf = self._buffer
        their = self._their_role
        if fr.mode == "empty" or (fr.mode == "length" and fr.remaining == 0):
            return self._pull_eom()
        if fr.mode == "length":
            if not buf:
                return self._need_more()
            n = min(len(buf), fr.remaining)
            data = bytes(buf[:n])
            del buf[:n]
            event = Data(data=data)
            self._process(their, event, False)
            return event
        if fr.mode == "close":
            if buf:
                data = bytes(buf)
                buf.clear()
                event = Data(data=data)
                self._process(their, event, False)
                return event
            if self._receive_closed:
                return self._pull_eom()
            return NEED_DATA
        if fr.mode == "chunked":
            return self._read_chunk()
        raise RemoteProtocolError("no body framing for this message")

    def _read_chunk(self):
        fr = self._in
        buf = self._buffer
        their = self._their_role
        if fr.chunk_state == "crlf":
            if buf[:2] == b"\r\n":
                del buf[:2]
                fr.chunk_state = "size"
            elif b"\r\n".startswith(bytes(buf)):
                return self._need_more()
            else:
                raise RemoteProtocolError("chunk data is not followed by CRLF")
        if fr.chunk_state == "size":
            newline = buf.find(b"\n")
            if newline < 0:
                if len(buf) > self._max_incomplete:
                    raise RemoteProtocolError("incomplete event exceeds the size limit", 431)
                return self._need_more()
            line = bytes(buf[:newline])
            if line.endswith(b"\r"):
                line = line[:-1]
            match = _CHUNK_SIZE_RE.fullmatch(line)
            if match is None or len(match.group(1)) > MAX_CHUNK_SIZE_DIGITS:
                raise RemoteProtocolError("invalid chunk-size line")
            del buf[:newline + 1]
            size = int(match.group(1), 16)
            if size == 0:
                fr.chunk_state = "trailers"
            else:
                fr.chunk_state = "data"
                fr.chunk_left = size
                fr.chunk_started = False
        if fr.chunk_state == "data":
            if not buf:
                return self._need_more()
            n = min(len(buf), fr.chunk_left)
            data = bytes(buf[:n])
            del buf[:n]
            fr.chunk_left -= n
            start = not fr.chunk_started
            fr.chunk_started = True
            end = fr.chunk_left == 0
            if end:
                fr.chunk_state = "crlf"
            event = Data(data=data, chunk_start=start, chunk_end=end)
            self._process(their, event, False)
            return event
        head = self._read_head()
        if head is None:
            return self._need_more()
        lines, consumed = head
        del buf[:consumed]
        event = EndOfMessage(headers=_parse_header_lines(lines))
        self._process(their, event, False)
        return event

    def _pull_eom(self):
        event = EndOfMessage()
        self._process(self._their_role, event, False)
        return event

    def _pull_close(self):
        event = ConnectionClosed()
        self._process(self._their_role, event, False)
        return event

    # Other operations

    def start_next_cycle(self):
        if self._states[CLIENT] is not DONE or self._states[SERVER] is not DONE:
            raise LocalProtocolError("cannot start the next cycle until both sides are DONE")
        self._states[CLIENT] = IDLE
        self._states[SERVER] = IDLE
        self._out = None
        self._in = None
        self._request_method = None
        self._pending = set()
        self._keep_alive = True
        self._client_waiting = False
        return None

    def send_failed(self):
        self._mark_error(self._our_role)
        return None

    # Shared state machinery

    def _mark_error(self, role):
        self._states[role] = ERROR
        self._apply_state_rules()

    def _decision(self, event):
        """Whether a response accepts or denies a pending protocol switch."""
        kind = type(event)
        if kind is InformationalResponse:
            if event.status_code == 101 and _UPGRADE in self._pending:
                return _ACCEPT
            return None
        if kind is Response and self._pending:
            if _CONNECT in self._pending and 200 <= event.status_code < 300:
                return _ACCEPT
            return _DENY
        return None

    def _sender_state(self, sender, event):
        """New state of the sending side, or None if the event is not allowed."""
        state = self._states[sender]
        kind = type(event)
        if kind is ConnectionClosed:
            if state in (IDLE, DONE, MUST_CLOSE, CLOSED):
                return CLOSED
            return None
        if sender is CLIENT:
            if kind is Request:
                return SEND_BODY if state is IDLE else None
            if kind is Data:
                return SEND_BODY if state is SEND_BODY else None
            if kind is EndOfMessage:
                if state is not SEND_BODY:
                    return None
                return MIGHT_SWITCH_PROTOCOL if self._pending else DONE
            return None
        if kind is InformationalResponse:
            if state is not SEND_RESPONSE:
                return None
            if self._decision(event) is _ACCEPT:
                return SWITCHED_PROTOCOL
            return SEND_RESPONSE
        if kind is Response:
            if state is IDLE:
                return SEND_BODY
            if state is SEND_RESPONSE:
                if self._decision(event) is _ACCEPT:
                    return SWITCHED_PROTOCOL
                return SEND_BODY
            return None
        if kind is Data:
            return SEND_BODY if state is SEND_BODY else None
        if kind is EndOfMessage:
            return DONE if state is SEND_BODY else None
        return None

    def _receiver_state(self, sender, event):
        """New state of the receiving side, or None if it does not change."""
        receiver = _other(sender)
        state = self._states[receiver]
        kind = type(event)
        if kind is Request:
            if receiver is SERVER and state is IDLE:
                return SEND_RESPONSE
            return None
        if receiver is CLIENT and state is MIGHT_SWITCH_PROTOCOL:
            if kind is InformationalResponse:
                return SWITCHED_PROTOCOL if self._decision(event) is _ACCEPT else None
            if kind is Response:
                if self._decision(event) is _ACCEPT:
                    return SWITCHED_PROTOCOL
                return DONE
        return None

    def _process(self, sender, event, is_send):
        """Apply one event (sent or pulled) to the states and bookkeeping."""
        receiver = _other(sender)
        kind = type(event)
        new_sender = self._sender_state(sender, event)
        if new_sender is None:
            raise LocalProtocolError(
                "%s is not allowed while the %s side is %r"
                % (kind.__name__, "sending" if is_send else "peer", self._states[sender])
            )
        new_receiver = self._receiver_state(sender, event)
        decision = self._decision(event)
        framing = None
        if kind is Request:
            framing = _request_framing(event.headers)
            self._request_method = event.method
            self._pending = _proposals(event)
            if event.http_version == b"1.1" and b"100-continue" in _tokens(event.headers, b"expect"):
                self._client_waiting = True
            if event.http_version != b"1.1" or b"close" in _tokens(event.headers, b"connection"):
                self._keep_alive = False
        elif kind is InformationalResponse or kind is Response:
            if sender is SERVER:
                self._client_waiting = False
            if decision is not None:
                self._pending = set()
            if kind is Response:
                framing = _response_framing(self._request_method, event.status_code, event.headers)
                if (
                    event.http_version != b"1.1"
                    or b"close" in _tokens(event.headers, b"connection")
                    or framing.mode == "close"
                ):
                    self._keep_alive = False
        elif kind is Data:
            if sender is CLIENT:
                self._client_waiting = False
            fr = self._out if is_send else self._in
            if fr.mode == "length":
                fr.remaining -= _payload_len(event.data)
        elif kind is EndOfMessage:
            if sender is CLIENT:
                self._client_waiting = False
            framing = _Framing("none")
        if framing is not None:
            if is_send:
                self._out = framing
            else:
                self._in = framing
        if not is_send and kind in (Request, InformationalResponse, Response):
            self._their_http_version = event.http_version
        self._states[sender] = new_sender
        if new_receiver is not None:
            self._states[receiver] = new_receiver
        self._apply_state_rules()

    def _apply_state_rules(self):
        states = self._states
        while True:
            before = dict(states)
            for role in (CLIENT, SERVER):
                other = _other(role)
                state = states[role]
                if state is DONE and not self._keep_alive:
                    states[role] = MUST_CLOSE
                    state = MUST_CLOSE
                if state is DONE and states[other] is ERROR:
                    states[role] = MUST_CLOSE
                    state = MUST_CLOSE
                if states[other] is CLOSED and state in (IDLE, DONE):
                    states[role] = MUST_CLOSE
            if states == before:
                break
