"""The six HTTP event types and their construction-time checks."""

import re

from ._headers import Headers
from ._util import LocalProtocolError, TOKEN_RE, to_bytes

_VERSION_RE = re.compile(rb"[0-9]\.[0-9]")
_TARGET_RE = re.compile(rb"[\x21-\x7e]+")
_BAD_REASON_RE = re.compile(rb"[\x00\r\n]")


def _method(value):
    method = to_bytes(value, "method")
    if not TOKEN_RE.fullmatch(method):
        raise LocalProtocolError("invalid method %r" % (method,))
    return method


def _target(value):
    target = to_bytes(value, "request target")
    if not _TARGET_RE.fullmatch(target):
        raise LocalProtocolError("invalid request target %r" % (target,))
    return target


def _version(value):
    version = to_bytes(value, "HTTP version")
    if not _VERSION_RE.fullmatch(version):
        raise LocalProtocolError("invalid HTTP version %r" % (version,))
    return version


def _reason(value):
    reason = to_bytes(value, "reason phrase")
    if _BAD_REASON_RE.search(reason):
        raise LocalProtocolError("invalid reason phrase %r" % (reason,))
    return reason


def _status(value, low, high):
    if not isinstance(value, int):
        raise LocalProtocolError("status code must be an integer")
    code = int(value)
    if not low <= code <= high:
        raise LocalProtocolError("status code %d is out of range" % code)
    return code


class _Event(object):
    _fields = ()

    def __eq__(self, other):
        if type(other) is not type(self):
            return NotImplemented
        return all(getattr(self, f) == getattr(other, f) for f in self._fields)

    def __ne__(self, other):
        result = self.__eq__(other)
        return result if result is NotImplemented else not result

    __hash__ = None

    def __repr__(self):
        fields = ", ".join("%s=%r" % (f, getattr(self, f)) for f in self._fields)
        return "%s(%s)" % (type(self).__name__, fields)


class Request(_Event):
    _fields = ("method", "target", "headers", "http_version")

    def __init__(self, method, target, headers, http_version=b"1.1"):
        self.method = _method(method)
        self.target = _target(target)
        self.headers = Headers(headers)
        self.http_version = _version(http_version)
        hosts = len(self.headers.get_all(b"host"))
        if hosts > 1:
            raise LocalProtocolError("request has more than one Host header")
        if self.http_version == b"1.1" and hosts != 1:
            raise LocalProtocolError("HTTP/1.1 request needs exactly one Host header")


class InformationalResponse(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _status(status_code, 100, 199)
        self.headers = Headers(headers)
        self.http_version = _version(http_version)
        self.reason = _reason(reason)


class Response(_Event):
    _fields = ("status_code", "headers", "http_version", "reason")

    def __init__(self, status_code, headers, http_version=b"1.1", reason=b""):
        self.status_code = _status(status_code, 200, 999)
        self.headers = Headers(headers)
        self.http_version = _version(http_version)
        self.reason = _reason(reason)


class Data(_Event):
    _fields = ("data", "chunk_start", "chunk_end")

    def __init__(self, data, chunk_start=False, chunk_end=False):
        self.data = data
        self.chunk_start = bool(chunk_start)
        self.chunk_end = bool(chunk_end)


class EndOfMessage(_Event):
    _fields = ("headers",)

    def __init__(self, headers=()):
        self.headers = Headers(headers)


class ConnectionClosed(_Event):
    _fields = ()

    def __init__(self):
        pass
