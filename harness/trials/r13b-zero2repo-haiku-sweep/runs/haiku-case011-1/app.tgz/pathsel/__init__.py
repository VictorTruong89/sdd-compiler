"""PathSel: declarative path expressions evaluated against Python data."""
from .api import Options, ParsedExpression, compile, search
from .errors import (
    EmptyExpressionError,
    ExpressionSyntaxError,
    IncompleteExpressionError,
    InvalidArityError,
    InvalidTypeError,
    PathSelError,
    TokenSyntaxError,
    UnknownFunctionError,
    ZeroSliceStepError,
)
from .functions import Functions, signature

__version__ = '0.1.0'

__all__ = [
    'search',
    'compile',
    'Options',
    'ParsedExpression',
    'Functions',
    'signature',
    'PathSelError',
    'EmptyExpressionError',
    'IncompleteExpressionError',
    'ExpressionSyntaxError',
    'TokenSyntaxError',
    'ZeroSliceStepError',
    'UnknownFunctionError',
    'InvalidArityError',
    'InvalidTypeError',
]
