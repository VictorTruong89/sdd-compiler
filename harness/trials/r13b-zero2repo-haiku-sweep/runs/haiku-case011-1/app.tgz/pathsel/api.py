"""Public entry points: the search entry, the compile entry, and evaluation options."""
from .interpreter import Interpreter
from .parser import parse


class Options(object):
    """Evaluation options: a mapping type for constructed hashes and a custom function provider."""

    def __init__(self, dict_cls=None, custom_functions=None):
        self.dict_cls = dict_cls
        self.custom_functions = custom_functions


class ParsedExpression(object):
    """A compiled expression that can be searched against many documents."""

    def __init__(self, node):
        self._node = node

    def search(self, value, options=None):
        dict_cls = getattr(options, 'dict_cls', None)
        provider = getattr(options, 'custom_functions', None)
        return Interpreter(dict_cls, provider).visit(self._node, value)


def compile(expression):
    """Parse an expression once; the result searches any document."""
    return ParsedExpression(parse(expression))


def search(expression, data, options=None):
    """Evaluate an expression against a document in one shot."""
    return compile(expression).search(data, options)
