"""Built-in language functions and the provider mechanism.

A provider is an instance of ``Functions`` or of a subclass. Each method named
``_func_<name>`` decorated with ``signature`` defines the language function
``<name>``. Built-in names always take precedence over provider names.
"""
import json
import math
import re
from decimal import Decimal

from .errors import InvalidTypeError
from .values import TYPE_CHECKS, is_array, is_number, is_object, is_string, json_equal

_INTEGER_NUMERAL = re.compile(r'-?[0-9]+')
_DECIMAL_NUMERAL = re.compile(r'-?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?')


def signature(*arguments):
    """Declare the argument types of a function implementation.

    Each argument is ``{"types": [...]}``; the last one may add
    ``"variadic": True`` to accept one or more arguments of that type.
    """
    specs = []
    for index, argument in enumerate(arguments):
        types = tuple(argument["types"])
        for type_name in types:
            if type_name not in TYPE_CHECKS:
                raise ValueError("unknown argument type %r" % (type_name,))
        variadic = bool(argument.get("variadic", False))
        if variadic and index != len(arguments) - 1:
            raise ValueError("only the last argument may be variadic")
        specs.append({"types": types, "variadic": variadic})

    def decorate(function):
        function._pathsel_signature = tuple(specs)
        return function

    return decorate


def _all_numbers(items):
    return all(is_number(item) for item in items)


def _all_strings(items):
    return all(is_string(item) for item in items)


def _require_numbers_or_strings(items, name):
    if not (_all_numbers(items) or _all_strings(items)):
        raise InvalidTypeError("%s() requires all numbers or all strings" % name)


def _require_numbers(items, name):
    if not _all_numbers(items):
        raise InvalidTypeError("%s() requires an array of numbers" % name)


def _sort_keys(items, reference, name):
    keys = [reference.evaluate(item) for item in items]
    _require_numbers_or_strings(keys, name)
    return keys


class Functions(object):
    """Provider of the built-in functions; subclass and add ``_func_`` methods to extend."""

    @signature({"types": ["number"]})
    def _func_abs(self, value):
        return abs(value)

    @signature({"types": ["array"]})
    def _func_avg(self, items):
        _require_numbers(items, "avg")
        if not items:
            return None
        return sum(items) / float(len(items))

    @signature({"types": ["number"]})
    def _func_ceil(self, value):
        return math.ceil(value)

    @signature({"types": ["number"]})
    def _func_floor(self, value):
        return math.floor(value)

    @signature({"types": ["array", "string"]}, {"types": ["any"]})
    def _func_contains(self, subject, search):
        if is_array(subject):
            return any(json_equal(item, search) for item in subject)
        if isinstance(search, str):
            return search in subject
        raise InvalidTypeError("contains() on a string requires a string")

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_ends_with(self, subject, suffix):
        return subject.endswith(suffix)

    @signature({"types": ["string"]}, {"types": ["string"]})
    def _func_starts_with(self, subject, prefix):
        return subject.startswith(prefix)

    @signature({"types": ["string", "array", "object"]})
    def _func_length(self, value):
        return len(value)

    @signature({"types": ["array", "string"]})
    def _func_reverse(self, value):
        if is_array(value):
            return list(reversed(value))
        return value[::-1]

    @signature({"types": ["string"]}, {"types": ["array"]})
    def _func_join(self, separator, items):
        if not _all_strings(items):
            raise InvalidTypeError("join() requires an array of strings")
        return separator.join(items)

    @signature({"types": ["object"]})
    def _func_keys(self, value):
        return list(value.keys())

    @signature({"types": ["object"]})
    def _func_values(self, value):
        return list(value.values())

    @signature({"types": ["any"]})
    def _func_type(self, value):
        if value is None:
            return "null"
        if isinstance(value, bool):
            return "boolean"
        if isinstance(value, (int, float, Decimal)):
            return "number"
        if isinstance(value, str):
            return "string"
        if is_array(value):
            return "array"
        return "object"

    @signature({"types": ["any"]})
    def _func_to_array(self, value):
        if is_array(value):
            return value
        return [value]

    @signature({"types": ["any"]})
    def _func_to_string(self, value):
        if isinstance(value, str):
            return value
        try:
            return json.dumps(value, separators=(",", ":"))
        except (TypeError, ValueError):
            return json.dumps(str(value))

    @signature({"types": ["any"]})
    def _func_to_number(self, value):
        if is_number(value):
            return value
        if isinstance(value, str):
            if _INTEGER_NUMERAL.fullmatch(value):
                return int(value)
            if _DECIMAL_NUMERAL.fullmatch(value):
                return float(value)
        return None

    @signature({"types": ["array"]})
    def _func_max(self, items):
        _require_numbers_or_strings(items, "max")
        return max(items) if items else None

    @signature({"types": ["array"]})
    def _func_min(self, items):
        _require_numbers_or_strings(items, "min")
        return min(items) if items else None

    @signature({"types": ["array"]})
    def _func_sort(self, items):
        _require_numbers_or_strings(items, "sort")
        return sorted(items)

    @signature({"types": ["array"]})
    def _func_sum(self, items):
        _require_numbers(items, "sum")
        return sum(items)

    @signature({"types": ["object"], "variadic": True})
    def _func_merge(self, *objects):
        result = {}
        for item in objects:
            result.update(item)
        return result

    @signature({"types": ["any"], "variadic": True})
    def _func_not_null(self, *values):
        for value in values:
            if value is not None:
                return value
        return None

    @signature({"types": ["expref"]}, {"types": ["array"]})
    def _func_map(self, reference, items):
        return [reference.evaluate(item) for item in items]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_sort_by(self, items, reference):
        keys = _sort_keys(items, reference, "sort_by")
        order = sorted(range(len(items)), key=keys.__getitem__)
        return [items[index] for index in order]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_max_by(self, items, reference):
        if not items:
            return None
        keys = _sort_keys(items, reference, "max_by")
        best = 0
        for index in range(1, len(items)):
            if keys[index] > keys[best]:
                best = index
        return items[best]

    @signature({"types": ["array"]}, {"types": ["expref"]})
    def _func_min_by(self, items, reference):
        if not items:
            return None
        keys = _sort_keys(items, reference, "min_by")
        best = 0
        for index in range(1, len(items)):
            if keys[index] < keys[best]:
                best = index
        return items[best]


_PROVIDER = Functions()

BUILTINS = {}
for _attribute in dir(Functions):
    if _attribute.startswith("_func_"):
        BUILTINS[_attribute[len("_func_"):]] = getattr(_PROVIDER, _attribute)
