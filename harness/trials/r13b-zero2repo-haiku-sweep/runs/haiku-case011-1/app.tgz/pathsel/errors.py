"""Failure carriers for PathSel.

Every refusal is a ``ValueError``. The kind of a refusal is carried by the
type of the raised exception.
"""


class PathSelError(ValueError):
    """Base class of every refusal raised by pathsel."""


class EmptyExpressionError(PathSelError):
    """The expression text has zero length."""


class IncompleteExpressionError(PathSelError):
    """The text ended where an operand or a closing token was still required."""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = lex_position


class ExpressionSyntaxError(PathSelError):
    """The text is not a well-formed expression (grammar-level failure)."""

    def __init__(self, message, lex_position):
        super().__init__(message)
        self.lex_position = lex_position


class TokenSyntaxError(ExpressionSyntaxError):
    """A character sequence that cannot be read as a token."""


class ZeroSliceStepError(PathSelError):
    """A slice was written with a step of zero."""


class UnknownFunctionError(PathSelError):
    """A function name is neither built-in nor supplied by the provider."""


class InvalidArityError(PathSelError):
    """A function was called with the wrong number of arguments."""


class InvalidTypeError(PathSelError):
    """A function argument is outside its accepted types."""
