"""Value model shared by the interpreter and the function library.

Arrays are ``list`` or ``tuple``; objects are any ``collections.abc.Mapping``.
Host decimals count as numbers for comparison only (see ``is_comparable_number``).
"""
from collections.abc import Mapping
from decimal import Decimal


def is_array(value):
    return isinstance(value, (list, tuple))


def is_object(value):
    return isinstance(value, Mapping)


def is_string(value):
    return isinstance(value, str)


def is_boolean(value):
    return isinstance(value, bool)


def is_number(value):
    """A JSON number: an integer or floating-point value, not a boolean."""
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def is_comparable_number(value):
    """A number for comparisons, which also admits host decimals."""
    return isinstance(value, (int, float, Decimal)) and not isinstance(value, bool)


def is_false(value):
    """The false-value set: false, null, empty string, empty array, empty object."""
    if value is None or value is False:
        return True
    if isinstance(value, str):
        return len(value) == 0
    if is_array(value) or is_object(value):
        return len(value) == 0
    return False


def json_equal(left, right):
    """Deep JSON equality; a boolean is never equal to a number."""
    if isinstance(left, bool) or isinstance(right, bool):
        return isinstance(left, bool) and isinstance(right, bool) and left == right
    if is_comparable_number(left) or is_comparable_number(right):
        return (is_comparable_number(left) and is_comparable_number(right)
                and bool(left == right))
    if left is None or right is None:
        return left is None and right is None
    if isinstance(left, str) or isinstance(right, str):
        return isinstance(left, str) and isinstance(right, str) and left == right
    if is_array(left) or is_array(right):
        return (is_array(left) and is_array(right) and len(left) == len(right)
                and all(json_equal(a, b) for a, b in zip(left, right)))
    if is_object(left) or is_object(right):
        if not (is_object(left) and is_object(right)) or len(left) != len(right):
            return False
        for key in left:
            if key not in right or not json_equal(left[key], right[key]):
                return False
        return True
    return bool(left == right)


def compare_values(operator, left, right):
    """Evaluate a comparator; ordering yields None unless both sides are numbers or both strings."""
    if operator == 'eq':
        return json_equal(left, right)
    if operator == 'ne':
        return not json_equal(left, right)
    ordered = ((is_comparable_number(left) and is_comparable_number(right))
               or (isinstance(left, str) and isinstance(right, str)))
    if not ordered:
        return None
    if operator == 'lt':
        return left < right
    if operator == 'lte':
        return left <= right
    if operator == 'gt':
        return left > right
    return left >= right


class ExpressionReference(object):
    """A deferred subexpression produced by ``&``; functions apply it later."""

    __slots__ = ('_node', '_interpreter')

    def __init__(self, node, interpreter):
        self._node = node
        self._interpreter = interpreter

    def evaluate(self, value):
        return self._interpreter.visit(self._node, value)


TYPE_CHECKS = {
    'any': lambda value: True,
    'number': is_number,
    'string': is_string,
    'boolean': is_boolean,
    'array': is_array,
    'object': is_object,
    'null': lambda value: value is None,
    'expref': lambda value: isinstance(value, ExpressionReference),
}
