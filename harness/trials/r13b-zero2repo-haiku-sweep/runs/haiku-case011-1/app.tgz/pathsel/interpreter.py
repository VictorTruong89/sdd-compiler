"""Evaluation of parsed PathSel trees against Python data."""
import copy

from .errors import InvalidArityError, InvalidTypeError, UnknownFunctionError
from .functions import BUILTINS
from .values import (
    TYPE_CHECKS,
    ExpressionReference,
    compare_values,
    is_array,
    is_false,
    is_object,
)


def _slice_range(length, start, stop, step):
    """Indices selected by a slice, following the clamping rules of the PRD."""
    if step > 0:
        low, high = 0, length
        begin = 0 if start is None else start
        if begin < 0:
            begin += length
        begin = min(max(begin, low), high)
        end = length if stop is None else stop
        if end < 0:
            end += length
        end = min(max(end, low), high)
    else:
        low, high = -1, length - 1
        begin = length - 1 if start is None else start
        if begin < 0:
            begin += length
        begin = min(max(begin, low), high)
        end = -1 if stop is None else stop
        if stop is not None and end < 0:
            end += length
        end = min(max(end, low), high)
    return range(begin, end, step)


class Interpreter(object):
    """Evaluates nodes; ``dict_cls`` builds multiselect hashes and ``provider`` supplies custom functions."""

    def __init__(self, dict_cls=None, provider=None):
        self._dict_cls = dict_cls
        self._provider = provider

    def visit(self, node, value):
        return getattr(self, '_visit_' + node.kind)(node, value)

    def _visit_identity(self, node, value):
        return value

    def _visit_field(self, node, value):
        if is_object(value):
            return value.get(node.value)
        return None

    def _visit_index(self, node, value):
        if not is_array(value):
            return None
        index = node.value
        if index < 0:
            index += len(value)
        if 0 <= index < len(value):
            return value[index]
        return None

    def _visit_slice(self, node, value):
        if not is_array(value):
            return None
        start, stop, step = node.value
        return [value[index] for index in _slice_range(len(value), start, stop, step)]

    def _visit_literal(self, node, value):
        return copy.deepcopy(node.value)

    def _visit_subexpression(self, node, value):
        left, right = node.children
        return self.visit(right, self.visit(left, value))

    def _visit_pipe(self, node, value):
        return self._visit_subexpression(node, value)

    def _collect(self, node, items):
        results = []
        for item in items:
            result = self.visit(node, item)
            if result is not None:
                results.append(result)
        return results

    def _visit_projection(self, node, value):
        left, right = node.children
        base = self.visit(left, value)
        if not is_array(base):
            return None
        return self._collect(right, base)

    def _visit_value_projection(self, node, value):
        left, right = node.children
        base = self.visit(left, value)
        if not is_object(base):
            return None
        return self._collect(right, list(base.values()))

    def _visit_flatten(self, node, value):
        base = self.visit(node.children[0], value)
        if not is_array(base):
            return None
        flattened = []
        for item in base:
            if is_array(item):
                flattened.extend(item)
            else:
                flattened.append(item)
        return flattened

    def _visit_filter(self, node, value):
        subject, condition = node.children
        base = self.visit(subject, value)
        if not is_array(base):
            return None
        return [item for item in base if not is_false(self.visit(condition, item))]

    def _visit_comparator(self, node, value):
        left, right = node.children
        return compare_values(node.value, self.visit(left, value), self.visit(right, value))

    def _visit_or(self, node, value):
        left = self.visit(node.children[0], value)
        if not is_false(left):
            return left
        return self.visit(node.children[1], value)

    def _visit_and(self, node, value):
        left = self.visit(node.children[0], value)
        if is_false(left):
            return left
        return self.visit(node.children[1], value)

    def _visit_not(self, node, value):
        return is_false(self.visit(node.children[0], value))

    def _visit_multi_list(self, node, value):
        if value is None:
            return None
        return [self.visit(child, value) for child in node.children]

    def _visit_multi_hash(self, node, value):
        if value is None:
            return None
        result = self._dict_cls() if self._dict_cls is not None else {}
        for pair in node.children:
            result[pair.value] = self.visit(pair.children[0], value)
        return result

    def _visit_expref(self, node, value):
        return ExpressionReference(node.children[0], self)

    def _resolve(self, name):
        if name in BUILTINS:
            return BUILTINS[name]
        if self._provider is not None:
            candidate = getattr(self._provider, '_func_' + name, None)
            if candidate is not None and hasattr(candidate, '_pathsel_signature'):
                return candidate
        raise UnknownFunctionError('unknown function %s()' % name)

    def _visit_function(self, node, value):
        function = self._resolve(node.value)
        specs = function._pathsel_signature
        count = len(node.children)
        minimum = len(specs)
        variadic = bool(specs) and specs[-1]['variadic']
        if count < minimum or (count > minimum and not variadic):
            raise InvalidArityError('%s() takes %d argument(s), %d given'
                                    % (node.value, minimum, count))
        arguments = [self.visit(child, value) for child in node.children]
        for index, argument in enumerate(arguments):
            spec = specs[min(index, minimum - 1)]
            if not any(TYPE_CHECKS[type_name](argument) for type_name in spec['types']):
                raise InvalidTypeError('argument %d of %s() has the wrong type'
                                       % (index + 1, node.value))
        return function(*arguments)
