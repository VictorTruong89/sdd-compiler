"""Tokenizer and Pratt parser for PathSel expressions.

Binding powers follow the precedence table of the PRD: pipe < or < and <
comparators < ``!`` < dot < filter < wildcard < index/slice. Projections
collect their right-hand side with the same rule as JMESPath.
"""
import json
import string

from .errors import (
    EmptyExpressionError,
    ExpressionSyntaxError,
    IncompleteExpressionError,
    TokenSyntaxError,
    ZeroSliceStepError,
)

_WHITESPACE = frozenset(' \t\n\r')
_DIGITS = frozenset(string.digits)
_IDENTIFIER_START = frozenset(string.ascii_letters + '_')
_IDENTIFIER_BODY = _IDENTIFIER_START | _DIGITS

_SIMPLE_TOKENS = {
    '.': 'dot', '*': 'star', '[': 'lbracket', ']': 'rbracket', '?': 'question',
    '(': 'lparen', ')': 'rparen', '{': 'lbrace', '}': 'rbrace',
    ',': 'comma', ':': 'colon', '@': 'at',
}
_TWO_CHARACTER_TOKENS = {
    '||': 'or', '&&': 'and', '==': 'eq', '!=': 'ne', '<=': 'lte', '>=': 'gte',
}
_ONE_CHARACTER_TOKENS = {
    '|': 'pipe', '&': 'expref', '!': 'not', '<': 'lt', '>': 'gt',
}
_COMPARATORS = frozenset(['eq', 'ne', 'lt', 'lte', 'gt', 'gte'])

_PROJECTION_STOP = 10
_PIPE = 1
_OR = 2
_AND = 3
_COMPARE = 5
_FLATTEN = 9
_STAR = 20
_FILTER = 21
_DOT = 40
_NOT = 45
_INDEX = 55


class Token(object):
    __slots__ = ('type', 'value', 'position')

    def __init__(self, token_type, value, position):
        self.type = token_type
        self.value = value
        self.position = position


class Node(object):
    """One node of the parsed expression tree."""

    __slots__ = ('kind', 'children', 'value')

    def __init__(self, kind, children=(), value=None):
        self.kind = kind
        self.children = list(children)
        self.value = value


def _scan(text, position, characters):
    end = position
    while end < len(text) and text[end] in characters:
        end += 1
    return end


def _quoted_identifier(text, start):
    end = start + 1
    while True:
        if end >= len(text):
            raise TokenSyntaxError('unterminated quoted identifier', start)
        character = text[end]
        if character == '\\':
            end += 2
            continue
        if character == '"':
            break
        end += 1
    try:
        value = json.loads(text[start:end + 1])
    except ValueError:
        raise TokenSyntaxError('quoted identifier is not a JSON string', start)
    return value, end + 1


def _raw_string(text, start):
    characters = []
    end = start + 1
    while True:
        if end >= len(text):
            raise TokenSyntaxError('unterminated raw string literal', start)
        character = text[end]
        if character == '\\' and end + 1 < len(text):
            following = text[end + 1]
            characters.append("'" if following == "'" else character + following)
            end += 2
            continue
        if character == "'":
            break
        characters.append(character)
        end += 1
    return ''.join(characters), end + 1


def _json_literal(text, start):
    characters = []
    end = start + 1
    while True:
        if end >= len(text):
            raise TokenSyntaxError('unterminated JSON literal', start)
        character = text[end]
        if character == '\\':
            if end + 1 >= len(text):
                raise TokenSyntaxError('unterminated JSON literal', start)
            characters.append(character + text[end + 1])
            end += 2
            continue
        if character == '`':
            break
        characters.append(character)
        end += 1
    lexeme = ''.join(characters).replace('\\`', '`')
    try:
        value = json.loads(lexeme)
    except ValueError:
        try:
            value = json.loads('"%s"' % lexeme.lstrip())
        except ValueError:
            raise TokenSyntaxError('JSON literal is not valid JSON', start)
    return value, end + 1


def tokenize(text):
    """Split expression text into tokens; the list always ends with an eof token."""
    tokens = []
    length = len(text)
    position = 0
    while position < length:
        character = text[position]
        following = text[position + 1] if position + 1 < length else ''
        if character in _WHITESPACE:
            position += 1
        elif character in _IDENTIFIER_START:
            end = _scan(text, position + 1, _IDENTIFIER_BODY)
            tokens.append(Token('unquoted_identifier', text[position:end], position))
            position = end
        elif character in _DIGITS or (character == '-' and following in _DIGITS):
            end = _scan(text, position + 1, _DIGITS)
            tokens.append(Token('number', int(text[position:end]), position))
            position = end
        elif character == '-':
            raise TokenSyntaxError('hyphen begins no token', position)
        elif character == '"':
            value, end = _quoted_identifier(text, position)
            tokens.append(Token('quoted_identifier', value, position))
            position = end
        elif character == "'":
            value, end = _raw_string(text, position)
            tokens.append(Token('raw_string', value, position))
            position = end
        elif character == '`':
            value, end = _json_literal(text, position)
            tokens.append(Token('literal', value, position))
            position = end
        elif character + following in _TWO_CHARACTER_TOKENS:
            tokens.append(Token(_TWO_CHARACTER_TOKENS[character + following], None, position))
            position += 2
        elif character in _ONE_CHARACTER_TOKENS:
            tokens.append(Token(_ONE_CHARACTER_TOKENS[character], None, position))
            position += 1
        elif character in _SIMPLE_TOKENS:
            tokens.append(Token(_SIMPLE_TOKENS[character], None, position))
            position += 1
        else:
            raise TokenSyntaxError('character %r begins no token' % character, position)
    tokens.append(Token('eof', None, length))
    return tokens


def _syntax(token, message=None):
    return ExpressionSyntaxError(message or 'unexpected %s' % token.type, token.position)


def _failure(token):
    """The refusal for a token that cannot continue the expression."""
    if token.type == 'eof':
        return IncompleteExpressionError('expression is incomplete', token.position)
    return _syntax(token)


class _Parser(object):

    def __init__(self, tokens):
        self._tokens = tokens
        self._position = 0

    def parse(self):
        node = self._expression(0)
        token = self._current()
        if token.type != 'eof':
            raise _syntax(token)
        return node

    def _current(self):
        return self._tokens[self._position]

    def _peek_type(self):
        return self._tokens[self._position + 1].type

    def _advance(self):
        token = self._tokens[self._position]
        if token.type != 'eof':
            self._position += 1
        return token

    def _expect(self, token_type):
        token = self._current()
        if token.type != token_type:
            raise _failure(token)
        return self._advance()

    def _left_power(self, position):
        token = self._tokens[position]
        kind = token.type
        if kind == 'dot':
            return _DOT
        if kind == 'pipe':
            return _PIPE
        if kind == 'or':
            return _OR
        if kind == 'and':
            return _AND
        if kind in _COMPARATORS:
            return _COMPARE
        if kind == 'lbracket':
            following = self._tokens[position + 1].type
            if following == 'rbracket':
                return _FLATTEN
            if following == 'question':
                return _FILTER
            return _INDEX
        return 0

    def _expression(self, binding_power):
        left = self._nud(self._advance())
        while binding_power < self._left_power(self._position):
            left = self._led(left)
        return left

    def _nud(self, token):
        kind = token.type
        if kind == 'unquoted_identifier':
            if self._current().type == 'lparen':
                return self._function(token.value)
            return Node('field', value=token.value)
        if kind == 'quoted_identifier':
            if self._current().type == 'lparen':
                raise _syntax(self._current())
            return Node('field', value=token.value)
        if kind in ('literal', 'raw_string'):
            return Node('literal', value=token.value)
        if kind == 'at':
            return Node('identity')
        if kind == 'star':
            return Node('value_projection', [Node('identity'), self._projection_rhs(_STAR)])
        if kind == 'expref':
            return Node('expref', [self._expression(0)])
        if kind == 'not':
            return Node('not', [self._expression(_NOT)])
        if kind == 'lparen':
            node = self._expression(0)
            self._expect('rparen')
            return node
        if kind == 'lbrace':
            return self._multi_hash()
        if kind == 'lbracket':
            return self._bracket(None)
        raise _failure(token)

    def _led(self, left):
        token = self._advance()
        kind = token.type
        if kind == 'dot':
            if self._current().type == 'star':
                self._advance()
                return Node('value_projection', [left, self._projection_rhs(_DOT)])
            return Node('subexpression', [left, self._dot_rhs(_DOT)])
        if kind == 'pipe':
            return Node('pipe', [left, self._expression(_PIPE)])
        if kind == 'or':
            return Node('or', [left, self._expression(_OR)])
        if kind == 'and':
            return Node('and', [left, self._expression(_AND)])
        if kind in _COMPARATORS:
            return Node('comparator', [left, self._expression(_COMPARE)], kind)
        if kind == 'lbracket':
            return self._bracket(left)
        raise _failure(token)

    def _bracket(self, left):
        """Parse what follows a left bracket; ``left`` is None when the bracket starts the expression."""
        subject = Node('identity') if left is None else left
        token = self._current()
        if token.type in ('number', 'colon'):
            node = self._index_or_slice()
            if node.kind == 'slice':
                return Node('projection', [Node('subexpression', [subject, node]),
                                           self._projection_rhs(_STAR)])
            return Node('subexpression', [subject, node])
        if token.type == 'star' and self._peek_type() == 'rbracket':
            self._advance()
            self._advance()
            return Node('projection', [subject, self._projection_rhs(_STAR)])
        if token.type == 'rbracket':
            self._advance()
            return Node('projection', [Node('flatten', [subject]), self._projection_rhs(_FLATTEN)])
        if token.type == 'question':
            self._advance()
            return self._filter(subject)
        if left is None:
            return self._multi_list()
        raise _failure(token)

    def _index_or_slice(self):
        """Read ``n``, or ``start:stop:step`` with each part optional, up to the closing bracket."""
        parts = []
        number = None
        while True:
            token = self._current()
            if token.type == 'number':
                if number is not None:
                    raise _failure(token)
                number = token.value
                self._advance()
            elif token.type == 'colon':
                if len(parts) >= 2:
                    raise _syntax(token, 'slice has more than three parts')
                parts.append(number)
                number = None
                self._advance()
            elif token.type == 'rbracket':
                parts.append(number)
                self._advance()
                break
            else:
                raise _failure(token)
        if len(parts) == 1:
            return Node('index', value=parts[0])
        start, stop, step = (parts + [None, None, None])[:3]
        if step is None:
            step = 1
        if step == 0:
            raise ZeroSliceStepError('slice step cannot be zero')
        return Node('slice', value=(start, stop, step))

    def _filter(self, subject):
        condition = self._expression(0)
        self._expect('rbracket')
        return Node('projection', [Node('filter', [subject, condition]),
                                   self._projection_rhs(_FILTER)])

    def _projection_rhs(self, binding_power):
        if self._left_power(self._position) < _PROJECTION_STOP:
            return Node('identity')
        token = self._current()
        if token.type == 'lbracket':
            return self._expression(binding_power)
        if token.type == 'dot':
            self._advance()
            return self._dot_rhs(binding_power)
        raise _syntax(token)

    def _dot_rhs(self, binding_power):
        token = self._current()
        if token.type in ('unquoted_identifier', 'quoted_identifier', 'star'):
            return self._expression(binding_power)
        if token.type == 'lbracket':
            self._advance()
            return self._multi_list()
        if token.type == 'lbrace':
            self._advance()
            return self._multi_hash()
        raise _syntax(token)

    def _function(self, name):
        self._advance()
        arguments = []
        if self._current().type == 'rparen':
            self._advance()
            return Node('function', arguments, name)
        while True:
            arguments.append(self._expression(0))
            if self._current().type == 'comma':
                self._advance()
                continue
            self._expect('rparen')
            break
        return Node('function', arguments, name)

    def _multi_list(self):
        items = []
        while True:
            items.append(self._expression(0))
            if self._current().type == 'comma':
                self._advance()
                continue
            self._expect('rbracket')
            break
        return Node('multi_list', items)

    def _multi_hash(self):
        pairs = []
        while True:
            token = self._current()
            if token.type not in ('unquoted_identifier', 'quoted_identifier'):
                raise _failure(token)
            self._advance()
            self._expect('colon')
            pairs.append(Node('pair', [self._expression(0)], token.value))
            if self._current().type == 'comma':
                self._advance()
                continue
            self._expect('rbrace')
            break
        return Node('multi_hash', pairs)


def parse(expression):
    """Parse expression text into a tree; raises the refusal kinds of the PRD."""
    if not isinstance(expression, str):
        raise TypeError('expression must be a str')
    if expression == '':
        raise EmptyExpressionError('expression is empty')
    return _Parser(tokenize(expression)).parse()
