"""Shared HOTP/TOTP machinery: secret decoding, digests, truncation, matching."""

import base64
import datetime
import functools
import hashlib
import hmac
import struct
import time
import unicodedata

DEFAULT_DIGITS = 6
DEFAULT_DIGEST = hashlib.sha1
DEFAULT_INTERVAL = 30
DEFAULT_NAME = "Secret"

_MIN_DIGEST_BYTES = 18
_UTC = datetime.timezone.utc
_EPOCH = datetime.datetime(1970, 1, 1, tzinfo=_UTC)
_ONE_MICROSECOND = datetime.timedelta(microseconds=1)


def decode_secret(secret):
    """Decode a base32 secret (any case, padding optional) to key bytes."""
    if not isinstance(secret, str):
        raise TypeError("secret must be a str of base32 text")
    bare = secret.rstrip("=")
    if not bare:
        raise ValueError("secret must not be empty")
    padded = bare + "=" * (-len(bare) % 8)
    return base64.b32decode(padded, casefold=True)


def check_digits(digits):
    if isinstance(digits, bool) or not isinstance(digits, int):
        raise TypeError("digits must be an int")
    if not 1 <= digits <= 10:
        raise ValueError("digits must be between 1 and 10")
    return digits


def resolve_digest(digest):
    """Return (constructor, URI algorithm name) for a fixed-length digest."""
    if isinstance(digest, str):
        digest = functools.partial(hashlib.new, digest)
    if not callable(digest):
        raise TypeError("digest must be a hashlib constructor")
    probe = digest()
    if probe.name.startswith("shake") or probe.digest_size < _MIN_DIGEST_BYTES:
        raise ValueError("digest must have a fixed output of at least 18 bytes")
    return digest, probe.name.upper()


def hotp_code(key, counter, digits, digest):
    """RFC 4226 truncation of HMAC(key, counter), as a zero-padded string."""
    if counter < 0:
        raise ValueError("counter must not be negative")
    mac = hmac.new(key, struct.pack(">Q", counter), digest).digest()
    offset = mac[-1] & 0x0F
    binary = struct.unpack(">I", mac[offset:offset + 4])[0] & 0x7FFFFFFF
    return str(binary % 10 ** digits).zfill(digits)


def candidate_matches(candidate, code):
    """True when candidate is compatibility-equivalent (NFKC) to code."""
    if not isinstance(candidate, str):
        return False
    normal = unicodedata.normalize("NFKC", candidate).encode("utf-8")
    return hmac.compare_digest(normal, unicodedata.normalize("NFKC", code).encode("utf-8"))


def trunc_div(numerator, denominator):
    """Integer division truncated toward zero (not floored)."""
    quotient = abs(numerator) // abs(denominator)
    same_sign = (numerator >= 0) == (denominator > 0)
    return quotient if same_sign else -quotient


def unix_seconds(instant):
    """Whole Unix seconds of an instant, fraction discarded toward zero."""
    if isinstance(instant, datetime.datetime):
        if instant.utcoffset() is None:
            # Naive datetimes are read in the host local timezone.
            instant = instant.astimezone()
        micros = (instant - _EPOCH) // _ONE_MICROSECOND
        return trunc_div(micros, 1000000)
    if isinstance(instant, bool) or not isinstance(instant, (int, float)):
        raise TypeError("instant must be a Unix timestamp or a datetime")
    return int(instant)


def time_step(instant, interval):
    return trunc_div(unix_seconds(instant), interval)


def now_instant():
    return time.time()


class Base:
    """State common to HOTP and TOTP helpers."""

    def __init__(self, secret, digits=DEFAULT_DIGITS, digest=DEFAULT_DIGEST,
                 name=None, issuer=None):
        self._secret = secret
        self._key = decode_secret(secret)
        self._digits = check_digits(digits)
        self._digest, self._algorithm = resolve_digest(digest)
        if name is not None and not isinstance(name, str):
            raise TypeError("name must be a str")
        if issuer is not None and not isinstance(issuer, str):
            raise TypeError("issuer must be a str")
        self._name = name or DEFAULT_NAME
        self._issuer = issuer or None

    def _code(self, counter):
        return hotp_code(self._key, counter, self._digits, self._digest)
