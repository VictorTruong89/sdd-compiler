"""Random shared-secret generation (FP-01)."""

import secrets
import string

_BASE32_ALPHABET = string.ascii_uppercase + "234567"
_HEX_ALPHABET = "0123456789ABCDEF"

_BASE32_MIN = 32  # 160 bits
_HEX_MIN = 40  # 160 bits


def _draw(alphabet, length, minimum):
    if isinstance(length, bool) or not isinstance(length, int):
        raise TypeError("length must be an int")
    if length < minimum:
        raise ValueError("length must be at least %d" % minimum)
    return "".join(secrets.choice(alphabet) for _ in range(length))


def random_base32(length=_BASE32_MIN):
    """Return a random base32 secret of `length` characters (default 32)."""
    return _draw(_BASE32_ALPHABET, length, _BASE32_MIN)


def random_hex(length=_HEX_MIN):
    """Return a random uppercase hex secret of `length` characters (default 40)."""
    return _draw(_HEX_ALPHABET, length, _HEX_MIN)
