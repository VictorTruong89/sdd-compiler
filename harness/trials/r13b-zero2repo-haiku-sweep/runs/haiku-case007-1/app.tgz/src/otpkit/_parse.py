"""otpauth provisioning URI parsing (FP-05)."""

import hashlib
import re
import urllib.parse

from .hotp import HOTP
from .totp import TOTP

_SCHEME = re.compile(r"([A-Za-z][A-Za-z0-9+.\-]*)://")
_INTEGER = re.compile(r"-?[0-9]+")
_ALGORITHMS = {
    "SHA1": hashlib.sha1,
    "SHA256": hashlib.sha256,
    "SHA512": hashlib.sha512,
}


def _integer(text, field):
    if not _INTEGER.fullmatch(text):
        raise ValueError("%s must be an integer" % field)
    return int(text)


def parse_uri(uri):
    """Parse an otpauth totp or hotp URI into a TOTP or HOTP helper."""
    if not isinstance(uri, str):
        raise TypeError("uri must be a str")
    match = _SCHEME.match(uri)
    if not match or match.group(1).lower() != "otpauth":
        raise ValueError("not an otpauth URI")
    body = uri[match.end():]
    body, _, query = body.partition("?")
    kind, _, path = body.partition("/")
    if kind not in ("totp", "hotp"):
        raise ValueError("otpauth type must be totp or hotp")

    # The label splits at its first literal colon, before percent-decoding.
    issuers = []
    if ":" in path:
        raw_issuer, _, raw_account = path.partition(":")
        issuers.append(urllib.parse.unquote(raw_issuer))
    else:
        raw_account = path
    account = urllib.parse.unquote(raw_account)

    fields = {}
    for pair in query.split("&") if query else []:
        if not pair:
            continue
        key, _, value = pair.partition("=")
        key = urllib.parse.unquote_plus(key)
        value = urllib.parse.unquote_plus(value)
        if key == "issuer":
            issuers.append(value)
        elif key in ("secret", "counter", "period", "digits", "algorithm"):
            fields[key] = value  # last occurrence wins

    issuer = None
    for index, value in enumerate(issuers):
        if index == 0:
            issuer = value
        elif value != issuer:
            raise ValueError("conflicting issuer values")

    secret = fields.get("secret")
    if not secret:
        raise ValueError("otpauth URI carries no secret")

    digits = 6
    if "digits" in fields:
        digits = _integer(fields["digits"], "digits")
        if digits not in (6, 7, 8):
            raise ValueError("digits must be 6, 7 or 8")

    algorithm = "SHA1"
    if "algorithm" in fields:
        algorithm = fields["algorithm"]
        if algorithm not in _ALGORITHMS:
            raise ValueError("unsupported algorithm")

    counter = _integer(fields["counter"], "counter") if "counter" in fields else 0
    interval = _integer(fields["period"], "period") if "period" in fields else 30

    common = dict(
        digits=digits,
        digest=_ALGORITHMS[algorithm],
        name=account,
        issuer=issuer or None,
    )
    if kind == "totp":
        return TOTP(secret, interval=interval, **common)
    return HOTP(secret, initial_count=counter, **common)
