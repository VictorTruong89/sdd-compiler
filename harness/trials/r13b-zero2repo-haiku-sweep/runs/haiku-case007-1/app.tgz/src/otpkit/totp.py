"""Time-based one-time passwords (FP-03)."""

from ._core import (
    Base,
    DEFAULT_DIGEST,
    DEFAULT_DIGITS,
    DEFAULT_INTERVAL,
    candidate_matches,
    now_instant,
    time_step,
)
from ._uri import build_uri


class TOTP(Base):
    """Codes indexed by the time-step number of an instant (RFC 6238, T0 = 0)."""

    def __init__(self, secret, digits=DEFAULT_DIGITS, digest=DEFAULT_DIGEST,
                 name=None, issuer=None, interval=DEFAULT_INTERVAL):
        super().__init__(secret, digits=digits, digest=digest, name=name, issuer=issuer)
        if isinstance(interval, bool) or not isinstance(interval, int):
            raise TypeError("interval must be an int")
        if interval < 1:
            raise ValueError("interval must be at least 1 second")
        self._interval = interval

    def _step(self, instant):
        if instant is None:
            instant = now_instant()
        return time_step(instant, self._interval)

    def _code_at_step(self, step):
        if step < 0:
            raise ValueError("time-step number must not be negative")
        return self._code(step)

    def now(self):
        """Return the code for the current clock."""
        return self.at(now_instant())

    def at(self, instant, offset=0):
        """Return the code for `instant` shifted by `offset` whole time steps."""
        return self._code_at_step(self._step(instant) + offset)

    def verify_and_get_timecode(self, candidate, instant=None, valid_window=0):
        """Return the matching time-step number, or False when not accepted."""
        if isinstance(valid_window, bool) or not isinstance(valid_window, int):
            raise TypeError("valid_window must be an int")
        if valid_window < 0:
            raise ValueError("valid_window must not be negative")
        center = self._step(instant)
        for step in range(max(center - valid_window, 0), center + valid_window + 1):
            if candidate_matches(candidate, self._code(step)):
                return step
        return False

    def verify(self, candidate, instant=None, valid_window=0):
        """Return True when candidate is accepted within the acceptance window."""
        return self.verify_and_get_timecode(candidate, instant, valid_window) is not False

    def provisioning_uri(self, name=None, issuer_name=None, **extra):
        """Build a totp otpauth URI, optionally overriding name and issuer."""
        return build_uri(
            "totp",
            self._secret,
            name or self._name,
            issuer_name or self._issuer,
            self._digits,
            self._algorithm,
            interval=self._interval,
            extra=list(extra.items()),
        )
