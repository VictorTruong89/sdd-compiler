"""otpauth provisioning URI building (FP-04)."""

import urllib.parse

from ._core import DEFAULT_DIGITS, DEFAULT_INTERVAL

_LABEL_SAFE = "-._~/"
_QUERY_SAFE = "-._~"


def _quote(text, safe):
    return urllib.parse.quote(text, safe=safe)


def _check_image(value):
    if not isinstance(value, str):
        raise TypeError("image must be a str")
    try:
        parts = urllib.parse.urlsplit(value)
    except ValueError as exc:
        raise ValueError("image must be an https URL") from exc
    if parts.scheme != "https" or not parts.hostname or not parts.path:
        raise ValueError("image must be an https URL with a host and a path")


def build_uri(kind, secret, name, issuer, digits, algorithm,
              counter=None, interval=DEFAULT_INTERVAL, extra=()):
    """Assemble an otpauth URI. `counter` is set only for hotp; `extra` is (key, text) pairs."""
    for key, value in extra:
        if not isinstance(value, str):
            raise TypeError("extra field %r must be text" % key)
        if key == "image":
            _check_image(value)

    if issuer:
        label = "%s:%s" % (_quote(issuer, _LABEL_SAFE), _quote(name, _LABEL_SAFE))
    else:
        label = _quote(name, _LABEL_SAFE)

    pairs = ["secret=" + _quote(secret, _QUERY_SAFE)]
    if issuer:
        pairs.append("issuer=" + _quote(issuer, _QUERY_SAFE))
    if counter is not None:
        pairs.append("counter=" + _quote(str(counter), _QUERY_SAFE))
    if algorithm != "SHA1":
        pairs.append("algorithm=" + _quote(algorithm, _QUERY_SAFE))
    if digits != DEFAULT_DIGITS:
        pairs.append("digits=" + _quote(str(digits), _QUERY_SAFE))
    if kind == "totp" and interval != DEFAULT_INTERVAL:
        pairs.append("period=" + _quote(str(interval), _QUERY_SAFE))
    for key, value in extra:
        pairs.append("%s=%s" % (_quote(key, _QUERY_SAFE), _quote(value, _QUERY_SAFE)))

    return "otpauth://%s/%s?%s" % (kind, label, "&".join(pairs))
