"""HMAC-based one-time passwords (FP-02)."""

from ._core import Base, DEFAULT_DIGEST, DEFAULT_DIGITS, candidate_matches
from ._uri import build_uri


class HOTP(Base):
    """Codes indexed by a counter; the relative count is offset by the starting counter."""

    def __init__(self, secret, digits=DEFAULT_DIGITS, digest=DEFAULT_DIGEST,
                 name=None, issuer=None, initial_count=0):
        super().__init__(secret, digits=digits, digest=digest, name=name, issuer=issuer)
        if isinstance(initial_count, bool) or not isinstance(initial_count, int):
            raise TypeError("initial_count must be an int")
        self._initial_count = initial_count

    def at(self, count):
        """Return the code at relative count `count`."""
        return self._code(self._initial_count + count)

    def verify(self, candidate, count):
        """Return True when candidate matches the code at relative count `count`."""
        counter = self._initial_count + count
        if counter < 0:
            return False
        return candidate_matches(candidate, self._code(counter))

    def provisioning_uri(self, name=None, initial_count=None, issuer_name=None, **extra):
        """Build an hotp otpauth URI, optionally overriding name, counter and issuer."""
        if initial_count is None:
            counter = self._initial_count
        elif isinstance(initial_count, bool) or not isinstance(initial_count, int):
            raise TypeError("initial_count must be an int")
        else:
            counter = initial_count
        return build_uri(
            "hotp",
            self._secret,
            name or self._name,
            issuer_name or self._issuer,
            self._digits,
            self._algorithm,
            counter=counter,
            extra=list(extra.items()),
        )
