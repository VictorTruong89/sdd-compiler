"""Context-free grammars: symbols, productions and the grammar-text reader."""

import re


class Nonterminal:
    """A nonterminal symbol. It compares equal to a string with the same name."""

    def __init__(self, symbol):
        self._symbol = symbol

    def symbol(self):
        return self._symbol

    def __str__(self):
        return self._symbol

    def __repr__(self):
        return f"Nonterminal({self._symbol!r})"

    def __eq__(self, other):
        if isinstance(other, Nonterminal):
            return self._symbol == other._symbol
        if isinstance(other, str):
            return self._symbol == other
        return NotImplemented

    def __hash__(self):
        return hash(self._symbol)


class Production:
    """One alternative: a left-hand nonterminal and a right-hand sequence."""

    def __init__(self, lhs, rhs):
        self._lhs = lhs
        self._rhs = tuple(rhs)

    def lhs(self):
        return self._lhs

    def rhs(self):
        return self._rhs

    def __eq__(self, other):
        if not isinstance(other, Production):
            return NotImplemented
        return self._lhs == other._lhs and self._rhs == other._rhs

    def __hash__(self):
        return hash((self._lhs, self._rhs))

    def __repr__(self):
        return f"Production({self._lhs!r}, {self._rhs!r})"

    def __str__(self):
        parts = [f"'{s}'" if isinstance(s, str) else str(s) for s in self._rhs]
        return f"{self._lhs} -> {' '.join(parts)}".rstrip()


_RHS_TOKEN = re.compile(
    r"""\s*(?:(?P<quoted>'[^']*'|"[^"]*")|(?P<bar>\|)|(?P<symbol>[^\s'"|]+))"""
)


def _parse_rhs(text):
    """Split a right-hand side into alternatives of terminals and nonterminals."""
    alternatives = [[]]
    pos = 0
    while pos < len(text):
        match = _RHS_TOKEN.match(text, pos)
        if match is None:
            if text[pos:].strip() == "":
                break
            raise ValueError(f"cannot read {text[pos:].strip()!r} in production")
        pos = match.end()
        if match.group("bar") is not None:
            alternatives.append([])
        elif match.group("quoted") is not None:
            alternatives[-1].append(match.group("quoted")[1:-1])
        else:
            alternatives[-1].append(Nonterminal(match.group("symbol")))
    return alternatives


class CFG:
    """A context-free grammar. The start symbol is the first production's left side."""

    def __init__(self, start, productions):
        self._start = start if isinstance(start, Nonterminal) else Nonterminal(start)
        self._productions = list(productions)

    @classmethod
    def fromstring(cls, input):
        if not isinstance(input, str):
            raise TypeError("grammar text must be a str")
        productions = []
        for line in input.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            lhs_text, sep, rhs_text = line.partition("->")
            if not sep:
                raise ValueError(f"production has no '->': {line!r}")
            lhs_text = lhs_text.strip()
            if not re.fullmatch(r"[^\s'\"|]+", lhs_text):
                raise ValueError(f"bad left-hand side: {lhs_text!r}")
            lhs = Nonterminal(lhs_text)
            for alternative in _parse_rhs(rhs_text):
                productions.append(Production(lhs, alternative))
        if not productions:
            raise ValueError("grammar has no productions")
        return cls(productions[0].lhs(), productions)

    def start(self):
        return self._start

    def productions(self, lhs=None):
        if lhs is None:
            return list(self._productions)
        return [p for p in self._productions if p.lhs() == lhs]

    def __repr__(self):
        return f"<CFG with {len(self._productions)} productions>"
