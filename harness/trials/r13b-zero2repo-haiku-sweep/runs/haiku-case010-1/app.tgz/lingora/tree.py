"""Constituent trees, built from a label and children or from bracketed text."""

import re


class Tree:
    """A labelled, ordered tree whose children are leaves or subtrees."""

    def __init__(self, label, children):
        if isinstance(children, str) or not isinstance(children, (list, tuple)):
            raise TypeError("Tree children must be a list of children")
        self._label = label
        self._children = list(children)

    @classmethod
    def fromstring(cls, s):
        tokens = re.findall(r"\(|\)|[^\s()]+", s)
        node, end = _read_node(tokens, 0)
        if end != len(tokens):
            raise ValueError("trailing text after the bracketed tree")
        return node

    def label(self):
        return self._label

    def leaves(self):
        out = []
        for child in self._children:
            if isinstance(child, Tree):
                out.extend(child.leaves())
            else:
                out.append(child)
        return out

    def pformat(self):
        return _pformat(self, 0)

    def __len__(self):
        return len(self._children)

    def __getitem__(self, index):
        return self._children[index]

    def __iter__(self):
        return iter(self._children)

    def __eq__(self, other):
        if not isinstance(other, Tree):
            return NotImplemented
        return self._label == other._label and self._children == other._children

    def __hash__(self):
        return hash((self._label, tuple(self._children)))

    def __repr__(self):
        return f"Tree({self._label!r}, {self._children!r})"

    def __str__(self):
        return self.pformat()


def _read_node(tokens, pos):
    if pos >= len(tokens) or tokens[pos] != "(":
        raise ValueError("bracketed tree text must open with '('")
    pos += 1
    if pos >= len(tokens) or tokens[pos] in ("(", ")"):
        raise ValueError("a tree node needs a label")
    label = tokens[pos]
    pos += 1
    children = []
    while True:
        if pos >= len(tokens):
            raise ValueError("unbalanced parentheses in bracketed tree text")
        if tokens[pos] == ")":
            return Tree(label, children), pos + 1
        if tokens[pos] == "(":
            child, pos = _read_node(tokens, pos)
            children.append(child)
        else:
            children.append(tokens[pos])
            pos += 1


def _leaf_text(leaf):
    if isinstance(leaf, tuple) and len(leaf) == 2:
        word, tag = leaf
        return word if tag is None else f"{word}/{tag}"
    return str(leaf)


def _pformat(tree, depth):
    if all(not isinstance(child, Tree) for child in tree._children):
        parts = [str(tree._label)] + [_leaf_text(c) for c in tree._children]
        return "(" + " ".join(parts) + ")"
    pad = "  " * (depth + 1)
    lines = ["(" + str(tree._label)]
    for child in tree._children:
        if isinstance(child, Tree):
            lines.append(pad + _pformat(child, depth + 1))
        else:
            lines.append(pad + _leaf_text(child))
    return "\n".join(lines) + ")"
