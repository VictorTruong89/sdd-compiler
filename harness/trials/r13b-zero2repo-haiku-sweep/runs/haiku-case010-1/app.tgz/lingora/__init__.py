"""Lingora Language Toolkit: a pure-Python natural language processing library.

Importing the package downloads nothing; packaged resources are located on
demand through ``lingora.data.path``.
"""

__version__ = "0.1.0"

from lingora import (  # noqa: E402,F401
    chunk,
    classify,
    cli,
    data,
    grammar,
    metrics,
    parse,
    stem,
    tag,
    tokenize,
    translate,
    tree,
)
