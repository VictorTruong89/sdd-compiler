"""BLEU score over token lists (Papineni et al., 2002)."""

import math
from collections import Counter


def add_one_smoothing(numerators, denominators):
    """Add-one smoothing for the orders above unigrams; a valid ``smoothing_function``."""
    precisions = []
    for order, (num, den) in enumerate(zip(numerators, denominators), start=1):
        if order == 1:
            precisions.append(num / den)
        else:
            precisions.append((num + 1) / (den + 1))
    return precisions


def _ngrams(tokens, n):
    return Counter(tuple(tokens[i:i + n]) for i in range(len(tokens) - n + 1))


def bleu(references, hypothesis, weights=(0.25, 0.25, 0.25, 0.25), smoothing_function=None):
    hyp = list(hypothesis)
    refs = [list(ref) for ref in references]
    if not hyp or not refs:
        return 0.0
    numerators, denominators = [], []
    for n in range(1, len(weights) + 1):
        hyp_counts = _ngrams(hyp, n)
        max_ref = Counter()
        for ref in refs:
            for gram, count in _ngrams(ref, n).items():
                max_ref[gram] = max(max_ref[gram], count)
        numerators.append(sum(min(c, max_ref[g]) for g, c in hyp_counts.items()))
        denominators.append(max(1, len(hyp) - n + 1))

    if smoothing_function is None:
        precisions = [num / den for num, den in zip(numerators, denominators)]
    else:
        precisions = smoothing_function(numerators, denominators)

    log_sum = 0.0
    for weight, p in zip(weights, precisions):
        if weight <= 0:
            continue
        if p <= 0:
            return 0.0
        log_sum += weight * math.log(p)

    c = len(hyp)
    r = min((abs(len(ref) - c), len(ref)) for ref in refs)[1]
    brevity = 1.0 if c > r else math.exp(1 - r / c)
    return brevity * math.exp(log_sum)
