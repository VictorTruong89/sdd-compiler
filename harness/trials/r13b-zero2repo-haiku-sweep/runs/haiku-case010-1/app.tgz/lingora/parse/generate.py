"""Enumerate the sentences a grammar derives."""

import math


def generate(grammar, start=None, depth=None, n=None):
    """Yield sentences (lists of terminal strings) derivable from ``start``.

    Productions are expanded in their written order. ``depth`` bounds how many
    nested expansions a derivation may use; ``n`` caps the number of sentences.
    """
    if n is not None and n <= 0:
        return
    symbol = grammar.start() if start is None else start
    bound = math.inf if depth is None else depth
    count = 0
    for sentence in _generate_all(grammar, (symbol,), bound):
        yield sentence
        count += 1
        if n is not None and count >= n:
            return


def _generate_all(grammar, items, depth):
    if not items:
        yield []
        return
    for first in _generate_one(grammar, items[0], depth):
        for rest in _generate_all(grammar, items[1:], depth):
            yield first + rest


def _generate_one(grammar, item, depth):
    if isinstance(item, str):
        yield [item]
        return
    if depth > 0:
        for prod in grammar.productions(lhs=item):
            yield from _generate_all(grammar, prod.rhs(), depth - 1)
