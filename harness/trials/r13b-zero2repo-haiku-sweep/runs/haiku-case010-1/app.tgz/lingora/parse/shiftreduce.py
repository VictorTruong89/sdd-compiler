"""Single-pass shift-reduce parser without backtracking."""

from lingora.parse.chart import check_tokens
from lingora.tree import Tree

_MAX_STEPS = 100000


class ShiftReduceParser:
    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        tokens = check_tokens(tokens, self._grammar)
        tree = self._run(tokens)
        return iter([tree] if tree is not None else [])

    def _run(self, tokens):
        # Empty productions would reduce forever, so they are never used.
        productions = [p for p in self._grammar.productions() if p.rhs()]
        start = str(self._grammar.start())
        stack = []
        pos = 0
        steps = 0
        while steps < _MAX_STEPS:
            steps += 1
            for prod in productions:
                rhs = prod.rhs()
                k = len(rhs)
                if k <= len(stack) and _matches(stack[-k:], rhs):
                    children = stack[-k:]
                    del stack[-k:]
                    stack.append(Tree(str(prod.lhs()), children))
                    break
            else:
                if pos < len(tokens):
                    stack.append(tokens[pos])
                    pos += 1
                    continue
                break
        if pos == len(tokens) and len(stack) == 1 and isinstance(stack[0], Tree):
            if stack[0].label() == start:
                return stack[0]
        return None


def _matches(items, rhs):
    for item, symbol in zip(items, rhs):
        if isinstance(symbol, str):
            if not (isinstance(item, str) and item == symbol):
                return False
        elif not (isinstance(item, Tree) and item.label() == str(symbol)):
            return False
    return True
