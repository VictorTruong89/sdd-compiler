"""Exhaustive chart parser.

Spans are filled bottom-up by span length. Within one span a fixpoint loop
adds trees until nothing new appears. A tree may not contain a same-span node
with its own label, which rules out infinite unit cycles.
"""

from lingora.grammar import Nonterminal
from lingora.tree import Tree


def check_tokens(tokens, grammar):
    """Refuse a non-list token sequence and any token no production produces."""
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    terminals = {s for p in grammar.productions() for s in p.rhs() if isinstance(s, str)}
    for token in tokens:
        if not isinstance(token, str):
            raise TypeError("tokens must be str")
        if token not in terminals:
            raise ValueError(f"token {token!r} is produced by no production of the grammar")
    return list(tokens)


class ChartParser:
    def __init__(self, grammar):
        self._grammar = grammar

    def parse(self, tokens):
        tokens = check_tokens(tokens, self._grammar)
        return iter(self._chart_parse(tokens))

    def _chart_parse(self, tokens):
        n = len(tokens)
        productions = self._grammar.productions()
        # (label, i, j) -> {tree: frozenset of same-span labels inside tree}
        chart = {}
        for length in range(n + 1):
            for i in range(n - length + 1):
                j = i + length
                changed = True
                while changed:
                    changed = False
                    for prod in productions:
                        name = str(prod.lhs())
                        for children, same in self._match(prod.rhs(), 0, i, j, tokens, chart, (i, j)):
                            if name in same:
                                continue
                            tree = Tree(name, children)
                            slot = chart.setdefault((name, i, j), {})
                            if tree not in slot:
                                slot[tree] = same | {name}
                                changed = True
        start = str(self._grammar.start())
        return list(chart.get((start, 0, n), {}).keys())

    def _match(self, rhs, k, pos, end, tokens, chart, span):
        """Yield (children, same-span labels) for rhs[k:] covering tokens[pos:end]."""
        if k == len(rhs):
            if pos == end:
                yield [], frozenset()
            return
        symbol = rhs[k]
        if not isinstance(symbol, Nonterminal) and symbol == "":
            yield from self._match(rhs, k + 1, pos, end, tokens, chart, span)
            return
        if isinstance(symbol, str):
            if pos < end and tokens[pos] == symbol:
                for rest, same in self._match(rhs, k + 1, pos + 1, end, tokens, chart, span):
                    yield [symbol] + rest, same
            return
        name = str(symbol)
        for mid in range(pos, end + 1):
            for tree, same_labels in list(chart.get((name, pos, mid), {}).items()):
                if (pos, mid) != span:
                    same_labels = frozenset()
                for rest, rest_same in self._match(rhs, k + 1, mid, end, tokens, chart, span):
                    yield [tree] + rest, same_labels | rest_same
