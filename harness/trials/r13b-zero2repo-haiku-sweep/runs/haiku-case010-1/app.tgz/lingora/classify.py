"""Naive Bayes and decision tree classifiers over dict featuresets (FP-06)."""

import math
from collections import Counter, defaultdict


class ProbDist:
    """A probability distribution over labels."""

    def __init__(self, probs):
        self._probs = dict(probs)

    def prob(self, label):
        return float(self._probs.get(label, 0.0))

    def samples(self):
        return list(self._probs)

    def max(self):
        return max(self._probs, key=lambda label: self._probs[label])


def _require_training(labeled_featuresets):
    labeled = [(dict(fs), label) for fs, label in labeled_featuresets]
    if not labeled:
        raise ValueError("training needs at least one labeled featureset")
    return labeled


class NaiveBayesClassifier:
    def __init__(self, labels, priors, label_counts, value_counts, value_domains):
        self._labels = labels
        self._priors = priors
        self._label_counts = label_counts
        self._value_counts = value_counts
        self._value_domains = value_domains

    @classmethod
    def train(cls, labeled_featuresets):
        labeled = _require_training(labeled_featuresets)
        label_counts = Counter()
        value_counts = defaultdict(Counter)  # (feature name, label) -> Counter of values
        value_domains = defaultdict(set)  # feature name -> values seen in training
        labels = []
        for featureset, label in labeled:
            if label not in label_counts:
                labels.append(label)
            label_counts[label] += 1
            for name, value in featureset.items():
                value_domains[name].add(value)
                value_counts[(name, label)][value] += 1
        total = len(labeled)
        priors = {label: label_counts[label] / total for label in labels}
        return cls(labels, priors, label_counts, value_counts, value_domains)

    def labels(self):
        return list(self._labels)

    def _log_scores(self, featureset):
        scores = {}
        for label in self._labels:
            score = math.log(self._priors[label])
            for name, value in featureset.items():
                if name not in self._value_domains:
                    continue
                count = self._value_counts[(name, label)].get(value, 0)
                # Add-one smoothing: unseen values keep a non-zero probability.
                denominator = self._label_counts[label] + len(self._value_domains[name])
                score += math.log((count + 1) / denominator)
            scores[label] = score
        return scores

    def prob_classify(self, featureset):
        scores = self._log_scores(dict(featureset))
        top = max(scores.values())
        exps = {label: math.exp(score - top) for label, score in scores.items()}
        total = sum(exps.values())
        return ProbDist({label: value / total for label, value in exps.items()})

    def classify(self, featureset):
        scores = self._log_scores(dict(featureset))
        return max(self._labels, key=lambda label: scores[label])


class _Leaf:
    def __init__(self, label):
        self.label = label


class _Split:
    def __init__(self, feature, children, default):
        self.feature = feature
        self.children = children
        self.default = default


def _entropy(labels):
    counts = Counter(labels)
    total = len(labels)
    return -sum(c / total * math.log2(c / total) for c in counts.values())


def _majority(labels):
    counts = Counter(labels)
    best = max(counts.values())
    for label in labels:  # first-seen label wins ties
        if counts[label] == best:
            return label


def _build(data, features):
    labels = [label for _, label in data]
    majority = _majority(labels)
    if len(set(labels)) == 1 or not features:
        return _Leaf(majority)
    base = _entropy(labels)
    best_feature, best_gain = None, 0.0
    for name in features:
        groups = defaultdict(list)
        for featureset, label in data:
            groups[featureset.get(name)].append(label)
        remainder = sum(len(g) / len(data) * _entropy(g) for g in groups.values())
        gain = base - remainder
        if gain > best_gain + 1e-12:
            best_feature, best_gain = name, gain
    if best_feature is None:
        return _Leaf(majority)
    partitions = defaultdict(list)
    for featureset, label in data:
        partitions[featureset.get(best_feature)].append((featureset, label))
    remaining = [f for f in features if f != best_feature]
    children = {value: _build(subset, remaining) for value, subset in partitions.items()}
    return _Split(best_feature, children, majority)


class DecisionTreeClassifier:
    def __init__(self, root):
        self._root = root

    @classmethod
    def train(cls, labeled_featuresets):
        data = _require_training(labeled_featuresets)
        features = sorted({name for featureset, _ in data for name in featureset})
        return cls(_build(data, features))

    def classify(self, featureset):
        node = self._root
        while isinstance(node, _Split):
            value = featureset.get(node.feature)
            if value not in node.children:
                return node.default
            node = node.children[value]
        return node.label


def accuracy(classifier, gold):
    """Fraction of gold (featureset, label) pairs the classifier labels correctly."""
    if not gold:
        return 0.0
    correct = sum(1 for featureset, label in gold if classifier.classify(featureset) == label)
    return correct / len(gold)
