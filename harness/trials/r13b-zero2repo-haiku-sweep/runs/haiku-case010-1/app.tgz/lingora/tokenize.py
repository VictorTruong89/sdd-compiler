"""Word, punctuation, sentence and span tokenizers (FP-01).

The recommended sentence tokenizer reads Punkt parameters from the packaged
model files. Every other tokenizer here needs no downloaded data.
"""

import os
import re
from collections import namedtuple

from lingora import data as _data

_LEAD_PUNCT = "\"'([{<"
_CLOSERS = "\"')]}>»”’"
_SENT_END = ".?!"
_BRACKET_OPEN = "([{<"
_TYPOGRAPHIC_QUOTES = "“”„‟‘’‚‛«»‹›"
_DASHES = "‒–—―*"

_QUOTE_RE = re.compile("[" + re.escape(_TYPOGRAPHIC_QUOTES) + "]")
_DASH_RE = re.compile("[" + re.escape(_DASHES) + "]")

# Contraction splits from the Penn Treebank conventions (FP-01).
_CONTRACTIONS = [
    (re.compile(r"(?i)\b(can)(not)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(d)('ye)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gim)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(gon)(na)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(got)(ta)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(lem)(me)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(more)('n)\b"), r"\1 \2"),
    (re.compile(r"(?i)\b(wan)(na)(?=\s)"), r"\1 \2"),
    (re.compile(r"(?i)(?<=\s)('t)(is)\b"), r"\1 \2"),
    (re.compile(r"(?i)(?<=\s)('t)(was)\b"), r"\1 \2"),
]


def _split_double_quotes(text):
    out = []
    for i, ch in enumerate(text):
        if ch == '"':
            before = text[i - 1] if i else " "
            opening = before.isspace() or before in _BRACKET_OPEN
            out.append(" `` " if opening else " '' ")
        else:
            out.append(ch)
    return "".join(out)


def _penn_split(text, recommended):
    """Split text by the Penn Treebank conventions, plus the recommended extras."""
    text = _split_double_quotes(text)
    if recommended:
        text = _QUOTE_RE.sub(lambda m: f" {m.group(0)} ", text)
        text = _DASH_RE.sub(lambda m: f" {m.group(0)} ", text)
        text = re.sub(r"\.{2,}", lambda m: f" {m.group(0)} ", text)
        text = text.replace("--", " -- ")
    else:
        text = text.replace("...", " ... ")
    text = re.sub(r"([:,])(?!\d)", r" \1 ", text)
    text = re.sub(r"([^.])\.([\]\)}>\"']*)\s*$", r"\1 .\2 ", text)
    text = re.sub(r"[;@#$%&?!]", lambda m: f" {m.group(0)} ", text)
    text = re.sub(r"[][(){}<>]", lambda m: f" {m.group(0)} ", text)
    text = " " + text + " "
    text = re.sub(r"(?i)(?<=\S)(n't)(?=\s)", r" \1", text)
    text = re.sub(r"(?i)(?<=\S)('s|'m|'d|'ll|'re|'ve)(?=\s)", r" \1", text)
    text = re.sub(r"(?<=\w)'(?=\s)", " '", text)
    for pattern, repl in _CONTRACTIONS:
        text = pattern.sub(repl, text)
    return text.split()


def _require_str(text):
    if not isinstance(text, str):
        raise TypeError("text must be a str")


def wordpunct_tokenize(text):
    return WordPunctTokenizer().tokenize(text)


class WordPunctTokenizer:
    _PATTERN = re.compile(r"\w+|[^\w\s]+")

    def tokenize(self, text):
        _require_str(text)
        return self._PATTERN.findall(text)

    def span_tokenize(self, text):
        _require_str(text)
        return [m.span() for m in self._PATTERN.finditer(text)]


class TreebankWordTokenizer:
    def tokenize(self, text):
        _require_str(text)
        return _penn_split(text, recommended=False)


def word_tokenize(text, language="english", preserve_line=False):
    """LINGORA's recommended word tokenizer (an improved Penn Treebank tokenizer)."""
    _require_str(text)
    if preserve_line:
        return _penn_split(text, recommended=True)
    tokens = []
    for sentence in sent_tokenize(text, language=language):
        tokens.extend(_penn_split(sentence, recommended=True))
    return tokens


class WhitespaceTokenizer:
    _PATTERN = re.compile(r"\S+")

    def tokenize(self, text):
        _require_str(text)
        return text.split()

    def span_tokenize(self, text):
        _require_str(text)
        return [m.span() for m in self._PATTERN.finditer(text)]


def blankline_tokenize(text):
    _require_str(text)
    segments = re.split(r"\s*\n[^\S\n]*\n\s*", text)
    return [segment for segment in segments if segment]


class RegexpTokenizer:
    def __init__(self, pattern, gaps=False, discard_empty=True,
                 flags=re.UNICODE | re.MULTILINE | re.DOTALL):
        self._regexp = re.compile(pattern, flags)
        self._gaps = gaps
        self._discard_empty = discard_empty

    def _spans(self, text):
        if self._gaps:
            spans = []
            pos = 0
            for m in self._regexp.finditer(text):
                spans.append((pos, m.start()))
                pos = m.end()
            spans.append((pos, len(text)))
        else:
            spans = [m.span() for m in self._regexp.finditer(text)]
        if self._discard_empty:
            spans = [(s, e) for s, e in spans if e > s]
        return spans

    def tokenize(self, text):
        _require_str(text)
        return [text[s:e] for s, e in self._spans(text)]

    def span_tokenize(self, text):
        _require_str(text)
        return self._spans(text)


_EMOTICON = re.compile(
    r"(?:[<>]?[:;=8][\-o*']?[)\](\[dDpP/:}{@|\\]"
    r"|[)\](\[dDpP/:}{@|\\][\-o*']?[:;=8][<>]?"
    r"|<3)"
)
_TWEET_PATTERN = re.compile(
    "|".join(
        [
            r"[<>]?[:;=8][\-o*']?[)\](\[dDpP/:}{@|\\]",
            r"[)\](\[dDpP/:}{@|\\][\-o*']?[:;=8][<>]?",
            r"<3",
            r"(?:https?://\S+|www\.\S+)",
            r"<[^>\s]+>",
            r"@\w+",
            r"#\w+",
            r"[+-]?\d+(?:[.,]\d+)*",
            r"\w+(?:['’\-]\w+)*",
            r"\.{2,}",
            r"[^\w\s]",
        ]
    )
)
_HANDLE_RE = re.compile(r"(?<!\w)@[A-Za-z0-9_]{1,15}(?![A-Za-z0-9_])")


class TweetTokenizer:
    def __init__(self, preserve_case=True, reduce_len=False, strip_handles=False):
        self._preserve_case = preserve_case
        self._reduce_len = reduce_len
        self._strip_handles = strip_handles

    def tokenize(self, text):
        _require_str(text)
        if self._strip_handles:
            text = _HANDLE_RE.sub(" ", text)
        if self._reduce_len:
            text = re.sub(r"(.)\1{2,}", r"\1\1\1", text, flags=re.DOTALL)
        tokens = [m.group(0) for m in _TWEET_PATTERN.finditer(text)]
        if not self._preserve_case:
            tokens = [t if _EMOTICON.fullmatch(t) else t.lower() for t in tokens]
        return tokens


# ---------------------------------------------------------------------------
# Punkt sentence boundary detection.

_PunktParams = namedtuple(
    "_PunktParams", "abbrev_types collocations sent_starters ortho_context"
)
_PUNKT_CACHE = {}


def _read_lines(path):
    with open(path, encoding="utf-8") as handle:
        return [line.rstrip("\r\n") for line in handle if line.rstrip("\r\n")]


def load_punkt(language="english"):
    """Return the Punkt parameters for ``language``; raise if the model is missing."""
    directory = _data.find(f"tokenizers/punkt_tab/{language}")
    if not os.path.isdir(directory):
        raise _data.ResourceNotFound(f"Punkt model for {language!r} is not a directory")
    cached = _PUNKT_CACHE.get(directory)
    if cached is not None:
        return cached
    try:
        abbrev = set(_read_lines(os.path.join(directory, "abbrev_types.txt")))
        starters = set(_read_lines(os.path.join(directory, "sent_starters.txt")))
        collocations = {
            tuple(line.split("\t", 1))
            for line in _read_lines(os.path.join(directory, "collocations.tab"))
        }
        ortho = {}
        for line in _read_lines(os.path.join(directory, "ortho_context.tab")):
            token, _, flags = line.partition("\t")
            ortho[token] = int(flags)
    except OSError as exc:
        raise _data.ResourceNotFound(f"Punkt model for {language!r} is incomplete") from exc
    params = _PunktParams(abbrev, collocations, starters, ortho)
    _PUNKT_CACHE[directory] = params
    return params


_NUMBER_RE = re.compile(r"-?[\d.,]+")


def _leading_word(token):
    match = re.match(r"\w+", token.lstrip(_LEAD_PUNCT))
    return match.group(0) if match else ""


def _is_boundary(core, following, params):
    """Decide whether the sentence-final token ``core`` ends a sentence."""
    if core[-1] in "?!":
        return True
    base = core.lstrip(_LEAD_PUNCT).rstrip(".").lower()
    key = "##number##" if _NUMBER_RE.fullmatch(base) else base
    next_word = _leading_word(following)
    next_lower = next_word.lower()
    if (base, next_lower) in params.collocations:
        return False
    flags = params.ortho_context.get(next_lower, 0)
    first = following.lstrip(_LEAD_PUNCT)[:1]
    is_abbrev = key in params.abbrev_types or (len(base) == 1 and base.isalpha())
    if is_abbrev:
        return first.isupper() and (next_lower in params.sent_starters or bool(flags & 2))
    if first.islower():
        return bool(flags & 16) and not flags & 32
    return True


def _punkt_sentences(text, params):
    spans = [m.span() for m in re.finditer(r"\S+", text)]
    if not spans:
        return []
    words = [text[s:e] for s, e in spans]
    sentences = []
    start = 0
    for idx in range(len(words) - 1):
        core = words[idx].rstrip(_CLOSERS)
        if core and core[-1] in _SENT_END and _is_boundary(core, words[idx + 1], params):
            sentences.append(text[spans[start][0]:spans[idx][1]])
            start = idx + 1
    sentences.append(text[spans[start][0]:spans[-1][1]])
    return sentences


def sent_tokenize(text, language="english"):
    """LINGORA's recommended sentence tokenizer (Punkt, Kiss and Strunk 2006)."""
    _require_str(text)
    return _punkt_sentences(text, load_punkt(language))
