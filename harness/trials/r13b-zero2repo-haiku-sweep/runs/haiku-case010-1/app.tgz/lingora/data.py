"""Packaged-resource finder.

``path`` is the list of directories searched for packaged resources. Callers
may replace its contents in place; calls that need a resource then look only
in the listed directories.
"""

import os


class ResourceNotFound(LookupError):
    """A packaged resource is not visible in any directory on ``path``."""


path = [p for p in os.environ.get("LINGORA_DATA", "").split(os.pathsep) if p]


def find(resource):
    """Return the location of ``resource`` under the first directory holding it."""
    for directory in path:
        candidate = os.path.join(directory, resource)
        if os.path.exists(candidate):
            return candidate
    raise ResourceNotFound(f"packaged resource {resource!r} not found in data.path")
