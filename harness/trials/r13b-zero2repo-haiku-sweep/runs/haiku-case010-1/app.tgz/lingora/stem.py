"""Stemmers (FP-02): Porter, Lancaster, Snowball, and the regular-expression stemmer."""

import re

from lingora import data as _data

# ---------------------------------------------------------------------------
# Porter (Porter 1980) with the LINGORA extensions, and the classic rendering
# used by the Snowball "porter" language.

_PORTER_IRREGULAR = {
    "skis": "ski",
    "dying": "die",
    "lying": "lie",
    "tying": "tie",
    "news": "news",
    "innings": "inning",
    "inning": "inning",
    "outings": "outing",
    "outing": "outing",
    "cannings": "canning",
    "canning": "canning",
}

_VOWELS = "aeiou"


def _is_cons(word, i):
    ch = word[i]
    if ch in _VOWELS:
        return False
    if ch == "y":
        return i == 0 or not _is_cons(word, i - 1)
    return True


def _measure(stem):
    m = 0
    i = 0
    n = len(stem)
    while i < n and _is_cons(stem, i):
        i += 1
    while i < n:
        while i < n and not _is_cons(stem, i):
            i += 1
        if i >= n:
            break
        m += 1
        while i < n and _is_cons(stem, i):
            i += 1
    return m


def _has_vowel(stem):
    return any(not _is_cons(stem, i) for i in range(len(stem)))


def _ends_double_cons(word):
    return len(word) >= 2 and word[-1] == word[-2] and _is_cons(word, len(word) - 1)


def _star_o(stem, ext):
    n = len(stem)
    if ext and n == 2:
        return (not _is_cons(stem, 0)) and _is_cons(stem, 1) and stem[1] not in "wxy"
    if n < 3:
        return False
    return (
        _is_cons(stem, n - 1)
        and not _is_cons(stem, n - 2)
        and _is_cons(stem, n - 3)
        and stem[-1] not in "wxy"
    )


def _step1a(w, ext):
    if w.endswith("sses"):
        return w[:-2]
    if w.endswith("ies"):
        if ext and len(w) == 4:
            return w[:-1]
        return w[:-2]
    if w.endswith("ss"):
        return w
    if w.endswith("s") and _has_vowel(w[:-1]):
        return w[:-1]
    return w


def _step1b(w, ext):
    if ext and w.endswith("ied"):
        return w[:-1] if len(w) == 4 else w[:-2]
    if w.endswith("eed"):
        return w[:-1] if _measure(w[:-3]) > 0 else w
    for suffix in ("ed", "ing"):
        if w.endswith(suffix) and _has_vowel(w[:-len(suffix)]):
            stem = w[:-len(suffix)]
            if stem.endswith(("at", "bl", "iz")):
                return stem + "e"
            if _ends_double_cons(stem) and stem[-1] not in "lsz":
                return stem[:-1]
            if _measure(stem) == 1 and _star_o(stem, ext):
                return stem + "e"
            return stem
    return w


def _step1c(w, ext):
    if not w.endswith("y"):
        return w
    if ext:
        if len(w) >= 3 and _is_cons(w, len(w) - 2):
            return w[:-1] + "i"
        return w
    if _has_vowel(w[:-1]):
        return w[:-1] + "i"
    return w


_STEP2_CLASSIC = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("abli", "able"), ("alli", "al"), ("entli", "ent"), ("eli", "e"),
    ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_STEP2_EXT = [
    ("ational", "ate"), ("tional", "tion"), ("enci", "ence"), ("anci", "ance"),
    ("izer", "ize"), ("bli", "ble"), ("alli", "al"), ("fulli", "ful"), ("entli", "ent"),
    ("eli", "e"), ("ousli", "ous"), ("ization", "ize"), ("ation", "ate"), ("ator", "ate"),
    ("alism", "al"), ("iveness", "ive"), ("fulness", "ful"), ("ousness", "ous"),
    ("aliti", "al"), ("iviti", "ive"), ("biliti", "ble"),
]
_STEP3 = [
    ("icate", "ic"), ("ative", ""), ("alize", "al"), ("iciti", "ic"),
    ("ical", "ic"), ("ful", ""), ("ness", ""),
]
_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement",
    "ment", "ent", "ion", "ou", "ism", "ate", "iti", "ous", "ive", "ize",
]


def _step2(w, ext):
    if ext and w.endswith("alli") and _measure(w[:-4]) > 0:
        return _step2(w[:-2], ext)
    if ext and w.endswith("logi"):
        return w[:-1] if _measure(w[:-3]) > 0 else w
    for suffix, repl in (_STEP2_EXT if ext else _STEP2_CLASSIC):
        if w.endswith(suffix):
            stem = w[:-len(suffix)]
            return stem + repl if _measure(stem) > 0 else w
    return w


def _step3(w):
    for suffix, repl in _STEP3:
        if w.endswith(suffix):
            stem = w[:-len(suffix)]
            return stem + repl if _measure(stem) > 0 else w
    return w


def _step4(w):
    for suffix in _STEP4:
        if w.endswith(suffix):
            stem = w[:-len(suffix)]
            if suffix == "ion":
                return stem if stem[-1:] in ("s", "t") and _measure(stem) > 1 else w
            return stem if _measure(stem) > 1 else w
    return w


def _step5(w, ext):
    if w.endswith("e"):
        stem = w[:-1]
        m = _measure(stem)
        if m > 1 or (m == 1 and not _star_o(stem, ext)):
            w = stem
    if w.endswith("ll") and _measure(w) > 1:
        w = w[:-1]
    return w


def _porter_stem(word, ext):
    if word in _PORTER_IRREGULAR and ext:
        return _PORTER_IRREGULAR[word]
    if len(word) <= 2:
        return word
    w = _step1a(word, ext)
    w = _step1b(w, ext)
    w = _step1c(w, ext)
    w = _step2(w, ext)
    w = _step3(w)
    w = _step4(w)
    return _step5(w, ext)


class PorterStemmer:
    """Porter stemmer in its default mode (the LINGORA extensions)."""

    def stem(self, word, to_lowercase=True):
        if to_lowercase:
            word = word.lower()
        return _porter_stem(word, ext=True)


# ---------------------------------------------------------------------------
# Porter2 (Snowball "english").

_P2_VOWELS = "aeiouy"
_P2_EXC1 = {
    "skis": "ski", "skies": "sky", "dying": "die", "lying": "lie", "tying": "tie",
    "idly": "idl", "gently": "gentl", "ugly": "ugli", "early": "earli", "only": "onli",
    "singly": "singl", "sky": "sky", "news": "news", "howe": "howe", "atlas": "atlas",
    "cosmos": "cosmos", "bias": "bias", "andes": "andes",
}
_P2_EXC2 = {
    "inning", "outing", "canning", "herring", "earring", "proceed", "exceed", "succeed",
}
_P2_STEP2 = {
    "tional": "tion", "enci": "ence", "anci": "ance", "abli": "able", "entli": "ent",
    "izer": "ize", "ization": "ize", "ational": "ate", "ation": "ate", "ator": "ate",
    "alism": "al", "aliti": "al", "alli": "al", "fulness": "ful", "ousli": "ous",
    "ousness": "ous", "iveness": "ive", "iviti": "ive", "biliti": "ble", "bli": "ble",
    "ogi": "og", "fulli": "ful", "lessli": "less", "li": "",
}
_P2_STEP3 = {
    "tional": "tion", "ational": "ate", "alize": "al", "icate": "ic", "iciti": "ic",
    "ical": "ic", "ful": "", "ness": "",
}
_P2_STEP4 = [
    "al", "ance", "ence", "er", "ic", "able", "ible", "ant", "ement", "ment",
    "ent", "ism", "ate", "iti", "ous", "ive", "ize", "ion",
]


def _p2_has_vowel(s):
    return any(ch in _P2_VOWELS for ch in s)


def _p2_region(w, start):
    for i in range(start + 1, len(w)):
        if w[i] not in _P2_VOWELS and w[i - 1] in _P2_VOWELS:
            return i + 1
    return len(w)


def _p2_r1(w):
    if w.startswith(("gener", "arsen")):
        return 5
    if w.startswith("commun"):
        return 6
    return _p2_region(w, 0)


def _p2_short_syllable(w):
    if len(w) == 2:
        return w[0] in _P2_VOWELS and w[1] not in _P2_VOWELS
    if len(w) >= 3:
        a, b, c = w[-3], w[-2], w[-1]
        return a not in _P2_VOWELS and b in _P2_VOWELS and c not in _P2_VOWELS and c not in "wxY"
    return False


def _p2_strip_suffix(w, suffixes, repl_map):
    """Return (suffix, replacement) for the longest matching suffix, or None."""
    matches = [s for s in suffixes if w.endswith(s)]
    if not matches:
        return None
    suffix = max(matches, key=len)
    return suffix, repl_map.get(suffix, "")


def _porter2(word):
    if word in _P2_EXC1:
        return _P2_EXC1[word]
    if len(word) <= 2:
        return word
    w = word[1:] if word.startswith("'") else word
    chars = list(w)
    if chars and chars[0] == "y":
        chars[0] = "Y"
    for i in range(1, len(chars)):
        if chars[i] == "y" and chars[i - 1] in _P2_VOWELS:
            chars[i] = "Y"
    w = "".join(chars)
    r1 = _p2_r1(w)
    r2 = _p2_region(w, r1)

    for suffix in ("'s'", "'s", "'"):
        if w.endswith(suffix):
            w = w[:-len(suffix)]
            break

    if w.endswith("sses"):
        w = w[:-2]
    elif w.endswith(("ied", "ies")):
        w = w[:-2] if len(w) > 4 else w[:-1]
    elif w.endswith(("us", "ss")):
        pass
    elif w.endswith("s") and _p2_has_vowel(w[:-2]):
        w = w[:-1]

    if w in _P2_EXC2:
        return w.replace("Y", "y")

    if w.endswith(("eed", "eedly")):
        suffix = "eedly" if w.endswith("eedly") else "eed"
        if len(w) - len(suffix) >= r1:
            w = w[:-len(suffix)] + "ee"
    else:
        for suffix in ("ingly", "edly", "ing", "ed"):
            if w.endswith(suffix):
                stem = w[:-len(suffix)]
                if _p2_has_vowel(stem):
                    w = stem
                    if w.endswith(("at", "bl", "iz")):
                        w += "e"
                    elif w[-2:] in ("bb", "dd", "ff", "gg", "mm", "nn", "pp", "rr", "tt"):
                        w = w[:-1]
                    elif _p2_short_syllable(w) and _p2_r1(w) >= len(w):
                        w += "e"
                break

    if len(w) >= 3 and w[-1] in "yY" and w[-2] not in _P2_VOWELS:
        w = w[:-1] + "i"

    hit = _p2_strip_suffix(w, _P2_STEP2, _P2_STEP2)
    if hit is not None:
        suffix, repl = hit
        stem_len = len(w) - len(suffix)
        if stem_len >= r1:
            if suffix == "ogi":
                if stem_len >= 1 and w[stem_len - 1] == "l":
                    w = w[:stem_len] + repl
            elif suffix == "li":
                if stem_len >= 1 and w[stem_len - 1] in "cdeghkmnrt":
                    w = w[:stem_len]
            else:
                w = w[:stem_len] + repl

    hit = _p2_strip_suffix(w, list(_P2_STEP3) + ["ative"], _P2_STEP3)
    if hit is not None:
        suffix, repl = hit
        stem_len = len(w) - len(suffix)
        if suffix == "ative":
            if stem_len >= r2:
                w = w[:stem_len]
        elif stem_len >= r1:
            w = w[:stem_len] + repl

    matches = [s for s in _P2_STEP4 if w.endswith(s)]
    if matches:
        suffix = max(matches, key=len)
        stem_len = len(w) - len(suffix)
        if stem_len >= r2:
            if suffix == "ion":
                if stem_len >= 1 and w[stem_len - 1] in "st":
                    w = w[:stem_len]
            else:
                w = w[:stem_len]

    if w.endswith("e"):
        stem_len = len(w) - 1
        if stem_len >= r2 or (stem_len >= r1 and not _p2_short_syllable(w[:stem_len])):
            w = w[:-1]
    elif w.endswith("l") and len(w) - 1 >= r2 and w[-2:-1] == "l":
        w = w[:-1]

    return w.replace("Y", "y")


# ---------------------------------------------------------------------------
# Lancaster (Paice/Husk).

_LANCASTER_RULES_TEXT = """
ai*2. a*1. bb1. city3s. ci2> cn1t> dd1. dei3y> deec2ss. dee1. de2> dooh4> e1>
earl3> eed3ss. e3> feil1v. fi2> gni3> gai3y. ga2> gg1. ht*2. hsiug5ct. hsi3> i*1.
i1y> ji1d. juf1s. ju1d. jo1d. jeh1r. jrev1t. jsim2t. jn1d. j1s. lbaifi6. lbai4y.
lba3> lbi3. lib2l> lc1. lufi4y. luf3> lu2. lai3> lau3> la2> ll1. mui3. mu*2. msi3>
mm1. nois4j> noix4ct. noi3> nai3> na2> nee0. ne2> nn1. pihs4> pp1. re2> rae0. ra2.
ro2> ru2> rr1. rt1> rei3y> sei3y> sis2. si2> ssen4> ss0. suo3> su*2. s*1> s0.
tacilp4y. ta2> tnem4> tne3> tna3> tpir2b. tpro2b. tcud1. tpmus2. tpec2iv. tulo2v.
tsis0. tsi3> tt1. uqi3. ugo1. vis3j> vie2> yli3y> ylp0. yru3> yhcat2s.
"""

_LANCASTER_RULE_RE = re.compile(r"([a-z]+)(\*?)(\d)([a-z]*)([.>])")


def _parse_lancaster_rules(text):
    rules = []
    for item in text.split():
        match = _LANCASTER_RULE_RE.fullmatch(item)
        if match is None:
            raise ValueError(f"bad Lancaster rule: {item!r}")
        pattern, star, remove, append, cont = match.groups()
        # Rules are written with the ending reversed.
        rules.append((pattern[::-1], bool(star), int(remove), append, cont == "."))
    return rules


_LANCASTER_RULES = _parse_lancaster_rules(_LANCASTER_RULES_TEXT)


class LancasterStemmer:
    """Paice/Husk stemmer with the standard rule table."""

    _MIN_STEM = 2

    def stem(self, word):
        word = word.lower()
        intact = True
        while True:
            for ending, needs_intact, remove, append, terminal in _LANCASTER_RULES:
                if not word.endswith(ending):
                    continue
                if needs_intact and not intact:
                    continue
                stem_len = len(word) - remove
                if stem_len < self._MIN_STEM:
                    continue
                word = word[:stem_len] + append
                intact = False
                if terminal:
                    return word
                break
            else:
                return word


# ---------------------------------------------------------------------------
# Snowball languages.

_SNOWBALL_LANGUAGES = (
    "arabic", "danish", "dutch", "english", "finnish", "french", "german", "hungarian",
    "italian", "norwegian", "porter", "portuguese", "romanian", "russian", "spanish",
    "swedish",
)


def _load_stopwords(language):
    path = _data.find(f"corpora/stopwords/{language}")
    with open(path, encoding="utf-8") as handle:
        return {line.strip().lower() for line in handle if line.strip()}


def _external_snowball(language):
    try:
        import snowballstemmer
    except ImportError as exc:
        raise NotImplementedError(
            f"no Snowball algorithm for {language!r} is built in; "
            "install the snowballstemmer package to use it"
        ) from exc
    return snowballstemmer.stemmer(language).stemWord


class SnowballStemmer:
    def __init__(self, language, ignore_stopwords=False):
        if language not in _SNOWBALL_LANGUAGES:
            raise ValueError(f"unsupported Snowball language: {language!r}")
        self._language = language
        self._stopwords = _load_stopwords(language) if ignore_stopwords else None
        if language == "english":
            self._algorithm = _porter2
        elif language == "porter":
            self._algorithm = lambda w: _porter_stem(w, ext=False)
        else:
            self._algorithm = _external_snowball(language)

    def stem(self, word):
        lowered = word.lower()
        if self._stopwords is not None and lowered in self._stopwords:
            return lowered
        return self._algorithm(lowered)


# ---------------------------------------------------------------------------
# Regular-expression, WordNet and the Arabic stemmers.

class RegexpStemmer:
    def __init__(self, regexp):
        self._regexp = re.compile(regexp)

    def stem(self, word):
        return self._regexp.sub("", word)


class ARLSTem:
    def stem(self, word):
        raise NotImplementedError("ARLSTem stemming is outside this specification")


class ARLSTem2:
    def stem(self, word):
        raise NotImplementedError("ARLSTem2 stemming is outside this specification")


class WordNetLemmatizer:
    def __init__(self):
        _data.find("corpora/wordnet")

    def lemmatize(self, word):
        raise NotImplementedError("WordNet lemmatization is outside this specification")
