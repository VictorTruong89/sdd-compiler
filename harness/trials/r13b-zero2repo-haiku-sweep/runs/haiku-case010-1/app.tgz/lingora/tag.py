"""Part-of-speech taggers (FP-03): sequential taggers and the averaged perceptron."""

import json
import os
import re
from collections import Counter, defaultdict

from lingora import data as _data


def _check_tokens(tokens):
    if isinstance(tokens, str) or not isinstance(tokens, (list, tuple)):
        raise TypeError("tokens must be a list of str")
    for token in tokens:
        if not isinstance(token, str):
            raise TypeError("tokens must be str")
    return list(tokens)


class _SequentialTagger:
    """Assigns tags to tokens; consults the backoff tagger for untagged tokens."""

    def __init__(self, backoff=None):
        self._backoff = backoff

    def _raw_tags(self, tokens):
        raise NotImplementedError

    def tag(self, tokens):
        tokens = _check_tokens(tokens)
        tags = self._raw_tags(tokens)
        if self._backoff is not None:
            missing = [i for i, t in enumerate(tags) if t is None]
            if missing:
                backed = self._backoff.tag([tokens[i] for i in missing])
                for i, (_, tag) in zip(missing, backed):
                    tags[i] = tag
        return list(zip(tokens, tags))


class DefaultTagger(_SequentialTagger):
    def __init__(self, tag, backoff=None):
        super().__init__(backoff)
        self._tag = tag

    def _raw_tags(self, tokens):
        return [self._tag] * len(tokens)


class UnigramTagger(_SequentialTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(backoff)
        counts = defaultdict(Counter)
        for sentence in train or []:
            for token, tag in sentence:
                counts[token][tag] += 1
        self._model = {token: c.most_common(1)[0][0] for token, c in counts.items()}

    def _raw_tags(self, tokens):
        return [self._model.get(token) for token in tokens]


class NgramTagger(_SequentialTagger):
    """Tags a token from its word and the previous ``n - 1`` tags."""

    def __init__(self, n, train=None, backoff=None):
        super().__init__(backoff)
        self._n = n
        counts = defaultdict(Counter)
        for sentence in train or []:
            tags = [tag for _, tag in sentence]
            for i, (token, tag) in enumerate(sentence):
                counts[(self._history(tags, i), token)][tag] += 1
        self._model = {key: c.most_common(1)[0][0] for key, c in counts.items()}

    def _history(self, tags, i):
        history = tuple(tags[max(0, i - self._n + 1):i])
        return (None,) * (self._n - 1 - len(history)) + history

    def _raw_tags(self, tokens):
        tags = []
        for i, token in enumerate(tokens):
            tags.append(self._model.get((self._history(tags, i), token)))
        return tags


class BigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(2, train, backoff)


class TrigramTagger(NgramTagger):
    def __init__(self, train=None, backoff=None):
        super().__init__(3, train, backoff)


class AffixTagger(_SequentialTagger):
    def __init__(self, train=None, affix_length=-3, backoff=None):
        super().__init__(backoff)
        self._affix_length = affix_length
        counts = defaultdict(Counter)
        for sentence in train or []:
            for token, tag in sentence:
                affix = self._affix(token)
                if affix is not None:
                    counts[affix][tag] += 1
        self._model = {affix: c.most_common(1)[0][0] for affix, c in counts.items()}

    def _affix(self, token):
        size = abs(self._affix_length)
        if len(token) < size:
            return None
        return token[-size:] if self._affix_length < 0 else token[:size]

    def _raw_tags(self, tokens):
        return [self._model.get(self._affix(token)) for token in tokens]


class RegexpTagger(_SequentialTagger):
    def __init__(self, regexps, backoff=None):
        super().__init__(backoff)
        self._rules = [(re.compile(pattern), tag) for pattern, tag in regexps]

    def _raw_tags(self, tokens):
        tags = []
        for token in tokens:
            for pattern, tag in self._rules:
                if pattern.match(token):
                    tags.append(tag)
                    break
            else:
                tags.append(None)
        return tags


# ---------------------------------------------------------------------------
# Averaged perceptron tagger (textblob-aptagger algorithm), read from packaged files.

_START = ["-START-", "-START2-"]
_END = ["-END-", "-END2-"]


def _normalize(word):
    if "-" in word and word[0] != "-":
        return "!HYPHEN"
    if word.isdigit() and len(word) == 4:
        return "!YEAR"
    if word and word[0].isdigit():
        return "!DIGITS"
    return word.lower()


class _AveragedPerceptron:
    def __init__(self, weights, classes):
        self.weights = weights
        self.classes = classes

    def predict(self, features):
        scores = defaultdict(float)
        for feature, value in features.items():
            if value == 0 or feature not in self.weights:
                continue
            for label, weight in self.weights[feature].items():
                scores[label] += value * weight
        return max(self.classes, key=lambda label: (scores[label], label))


class _PerceptronTagger:
    def __init__(self, weights, tagdict, classes):
        self._model = _AveragedPerceptron(weights, classes)
        self._tagdict = tagdict

    def tag(self, tokens):
        prev, prev2 = _START
        context = _START + [_normalize(w) for w in tokens] + _END
        output = []
        for i, word in enumerate(tokens):
            tag = self._tagdict.get(word)
            if not tag:
                features = _features(i, word, context, prev, prev2)
                tag = self._model.predict(features)
            output.append(tag)
            prev2, prev = prev, tag
        return output


def _features(i, word, context, prev, prev2):
    i += len(_START)
    features = defaultdict(int)

    def add(name, *args):
        features[" ".join((name,) + tuple(args))] += 1

    add("bias")
    add("i suffix", word[-3:])
    add("i pref1", word[:1])
    add("i-1 tag", prev)
    add("i-2 tag", prev2)
    add("i tag+i-2 tag", prev, prev2)
    add("i word", context[i])
    add("i-1 tag+i word", prev, context[i])
    add("i-1 word", context[i - 1])
    add("i-1 suffix", context[i - 1][-3:])
    add("i-2 word", context[i - 2])
    add("i+1 word", context[i + 1])
    add("i+1 suffix", context[i + 1][-3:])
    add("i+2 word", context[i + 2])
    return features


_RECOMMENDED_CACHE = {}
_EN_MAP_CACHE = {}

_RUS_TO_UNIVERSAL = {
    "S": "NOUN", "V": "VERB", "A": "ADJ", "ANUM": "ADJ", "ADV": "ADV", "PR": "ADP",
    "CONJ": "CONJ", "PART": "PRT", "NUM": "NUM", "APRO": "DET", "SPRO": "PRON",
    "PRO": "PRON", "INTJ": "INTJ",
}


def _read_json(path):
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


def _recommended(lang):
    if lang in _RECOMMENDED_CACHE:
        return _RECOMMENDED_CACHE[lang]
    directory = _data.find(f"taggers/averaged_perceptron_tagger_{lang}")
    base = os.path.join(directory, f"averaged_perceptron_tagger_{lang}")
    try:
        weights = _read_json(base + ".weights.json")
        tagdict = _read_json(base + ".tagdict.json")
        classes = _read_json(base + ".classes.json")
    except OSError as exc:
        raise _data.ResourceNotFound(f"averaged perceptron tagger for {lang!r} is incomplete") from exc
    tagger = _PerceptronTagger(weights, tagdict, classes)
    _RECOMMENDED_CACHE[lang] = tagger
    return tagger


def _english_universal_map():
    if "map" not in _EN_MAP_CACHE:
        path = os.path.join(_data.find("taggers/universal_tagset"), "en-ptb.map")
        mapping = {}
        with open(path, encoding="utf-8") as handle:
            for line in handle:
                line = line.rstrip("\r\n")
                if line:
                    tag, _, universal = line.partition("\t")
                    mapping[tag] = universal
        _EN_MAP_CACHE["map"] = mapping
    return _EN_MAP_CACHE["map"]


def _to_universal(lang, tag, english_map):
    if tag is None:
        return None
    if lang == "eng":
        return english_map.get(tag, "X")
    # Russian: map by the part-of-speech category before any "=" and ",".
    category = tag.split("=", 1)[0].split(",", 1)[0]
    return _RUS_TO_UNIVERSAL.get(category, "X")


def pos_tag(tokens, tagset=None, lang="eng"):
    """Tag a token list with the recommended English or Russian tagger."""
    tokens = _check_tokens(tokens)
    if lang not in ("eng", "rus"):
        raise ValueError(f"the recommended tagger does not support {lang!r}")
    if tagset not in (None, "universal"):
        raise ValueError(f"unknown tagset {tagset!r}")
    tags = _recommended(lang).tag(tokens)
    if tagset == "universal":
        english_map = _english_universal_map() if lang == "eng" else None
        tags = [_to_universal(lang, tag, english_map) for tag in tags]
    return list(zip(tokens, tags))
