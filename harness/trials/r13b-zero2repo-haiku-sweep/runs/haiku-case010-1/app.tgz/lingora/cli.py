"""Command line: ``lingora tokenize`` applies the recommended word tokenizer per line."""

import sys

from lingora import data as _data
from lingora.tokenize import load_punkt, word_tokenize

_USAGE = "usage: lingora [-l LANGUAGE] [-d DELIMITER] tokenize"


class _UsageError(Exception):
    pass


def _tokenize(language, delimiter):
    # Load the model before writing anything, so a missing model yields no output.
    load_punkt(language)
    for line in sys.stdin:
        tokens = word_tokenize(line.rstrip("\r\n"), language=language)
        sys.stdout.write(delimiter.join(tokens) + "\n")
    return 0


class _Group:
    """The ``lingora`` command group."""

    commands = ("tokenize",)

    def main(self, args=None, standalone_mode=True):
        if args is None:
            args = sys.argv[1:]
        code = self._run(list(args))
        if standalone_mode:
            sys.exit(code)
        return code

    def _run(self, args):
        language = "english"
        delimiter = " "
        command = None
        try:
            i = 0
            while i < len(args):
                arg = args[i]
                name, eq, value = arg.partition("=")
                if name in ("-l", "--language", "-d", "--delimiter"):
                    if not eq:
                        i += 1
                        if i >= len(args):
                            raise _UsageError(f"option {arg} needs a value")
                        value = args[i]
                    if name in ("-l", "--language"):
                        language = value
                    else:
                        delimiter = value
                elif arg.startswith("-"):
                    raise _UsageError(f"no such option: {arg}")
                else:
                    command = arg
                    break
                i += 1
            if command not in self.commands:
                raise _UsageError(f"expected one of: {', '.join(self.commands)}")
            return _tokenize(language, delimiter)
        except _UsageError as exc:
            sys.stderr.write(f"{_USAGE}\nlingora: {exc}\n")
            return 2
        except _data.ResourceNotFound as exc:
            sys.stderr.write(f"lingora: {exc}\n")
            return 1
        except Exception as exc:  # any other failure is a non-zero exit, not a crash
            sys.stderr.write(f"lingora: {exc}\n")
            return 1


cli = _Group()


def main():
    """Console-script entry point."""
    cli.main()
