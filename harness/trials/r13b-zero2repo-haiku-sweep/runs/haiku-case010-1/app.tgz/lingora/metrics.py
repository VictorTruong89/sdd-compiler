"""Scoring entries: edit distance, Jaccard distance, accuracy, precision, recall, F-measure."""


def _require_sets(reference, test):
    if not isinstance(reference, (set, frozenset)) or not isinstance(test, (set, frozenset)):
        raise TypeError("precision, recall and f_measure take sets")


def accuracy(reference, test):
    if len(reference) != len(test):
        raise ValueError("accuracy needs two lists of equal length")
    if not reference:
        return 0.0
    return sum(1 for r, t in zip(reference, test) if r == t) / len(reference)


def edit_distance(s1, s2, substitution_cost=1, transpositions=False):
    if not isinstance(s1, str) or not isinstance(s2, str):
        raise TypeError("edit_distance takes two str arguments")
    if transpositions:
        return _damerau_levenshtein(s1, s2, substitution_cost)
    m, n = len(s1), len(s2)
    prev = list(range(n + 1))
    for i in range(1, m + 1):
        cur = [i] + [0] * n
        for j in range(1, n + 1):
            sub = 0 if s1[i - 1] == s2[j - 1] else substitution_cost
            cur[j] = min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + sub)
        prev = cur
    return prev[n]


def _damerau_levenshtein(a, b, substitution_cost):
    """Unrestricted Damerau-Levenshtein distance (Lowrance and Wagner, 1975)."""
    la, lb = len(a), len(b)
    maxdist = la + lb
    d = [[maxdist] * (lb + 2) for _ in range(la + 2)]
    for i in range(la + 1):
        d[i + 1][1] = i
    for j in range(lb + 1):
        d[1][j + 1] = j
    last_row = {}
    for i in range(1, la + 1):
        last_match_col = 0
        for j in range(1, lb + 1):
            i1 = last_row.get(b[j - 1], 0)
            j1 = last_match_col
            if a[i - 1] == b[j - 1]:
                cost = 0
                last_match_col = j
            else:
                cost = substitution_cost
            d[i + 1][j + 1] = min(
                d[i][j] + cost,
                d[i + 1][j] + 1,
                d[i][j + 1] + 1,
                d[i1][j1] + (i - i1 - 1) + 1 + (j - j1 - 1),
            )
        last_row[a[i - 1]] = i
    return d[la + 1][lb + 1]


def jaccard_distance(label1, label2):
    if not isinstance(label1, (set, frozenset)) or not isinstance(label2, (set, frozenset)):
        raise TypeError("jaccard_distance takes two sets")
    union = label1 | label2
    if not union:
        return 0.0
    return len(label1 ^ label2) / len(union)


def precision(reference, test):
    _require_sets(reference, test)
    if not test:
        return None
    return len(reference & test) / len(test)


def recall(reference, test):
    _require_sets(reference, test)
    if not reference:
        return None
    return len(reference & test) / len(reference)


def f_measure(reference, test, alpha=0.5):
    _require_sets(reference, test)
    p = precision(reference, test)
    r = recall(reference, test)
    if p is None or r is None:
        return None
    if p == 0 or r == 0:
        return 0.0
    return 1 / (alpha / p + (1 - alpha) / r)
