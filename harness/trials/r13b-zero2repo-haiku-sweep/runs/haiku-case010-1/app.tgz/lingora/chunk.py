"""Chunk parsing with chunk grammars (FP-04).

A grammar is a set of clauses. Each clause has a label and chunk ({...}) or
chink (}...{) rules. Rules of one clause apply in order; later clauses see the
earlier clauses' chunks as single units tagged with their label.
"""

import re

from lingora import data as _data
from lingora.tree import Tree

SENTENCE_LABEL = "S"

_QUANT_RE = re.compile(r"\{\d*,?\d*\}")
_ELEMENT_RE = re.compile(r"<([^<>]*)>(\?|\*|\+|\{\d*,?\d*\})?")
_HEADER_RE = re.compile(r"\s*([^\s:{}<>]+)\s*:(.*)$")


def _dot_to_class(content):
    out = []
    i = 0
    while i < len(content):
        ch = content[i]
        if ch == "\\" and i + 1 < len(content):
            out.append(content[i:i + 2])
            i += 2
            continue
        out.append("[^<>]" if ch == "." else ch)
        i += 1
    return "".join(out)


def _compile_tag_pattern(pattern):
    compact = re.sub(r"\s+", "", pattern)
    pos = 0
    parts = []
    while pos < len(compact):
        match = _ELEMENT_RE.match(compact, pos)
        if match is None:
            raise ValueError(f"bad tag pattern: {pattern!r}")
        content, quant = match.group(1), match.group(2) or ""
        parts.append("(?:<(?:" + _dot_to_class(content) + ")>)" + quant)
        pos = match.end()
    return "".join(parts)


def _unit_tag(unit):
    if isinstance(unit, Tree):
        return unit.label()
    return str(unit[1])


def _find_matches(regex, tags):
    """Return (start, end) unit-index spans of non-overlapping, non-empty matches."""
    text = "".join("<%s>" % tag for tag in tags)
    offsets = [0]
    for tag in tags:
        offsets.append(offsets[-1] + len(tag) + 2)
    index = {offset: i for i, offset in enumerate(offsets)}
    spans = []
    for match in re.finditer(regex, text):
        if match.start() == match.end():
            continue
        spans.append((index[match.start()], index[match.end()]))
    return spans


class ChunkRule:
    """A chunk rule: every match becomes one chunk with ``label``."""

    def __init__(self, label, tag_pattern):
        self.label = label
        self.clause = object()
        self._regex = _compile_tag_pattern(tag_pattern)

    def apply(self, root, fresh):
        new = []
        i = 0
        while i < len(root):
            if id(root[i]) in fresh:
                new.append(root[i])
                i += 1
                continue
            j = i
            while j < len(root) and id(root[j]) not in fresh:
                j += 1
            run = root[i:j]
            pos = 0
            for start, end in _find_matches(self._regex, [_unit_tag(u) for u in run]):
                new.extend(run[pos:start])
                chunk = Tree(self.label, run[start:end])
                fresh.add(id(chunk))
                new.append(chunk)
                pos = end
            new.extend(run[pos:])
            i = j
        return new


class ChinkRule:
    """A chink rule: matching tokens are removed from chunks built in this clause."""

    def __init__(self, label, tag_pattern):
        self.label = label
        self.clause = object()
        self._regex = _compile_tag_pattern(tag_pattern)

    def apply(self, root, fresh):
        new = []
        for unit in root:
            if not (isinstance(unit, Tree) and id(unit) in fresh):
                new.append(unit)
                continue
            children = list(unit)
            spans = _find_matches(self._regex, [_unit_tag(c) for c in children])
            if not spans:
                new.append(unit)
                continue
            pos = 0
            for start, end in spans:
                if start > pos:
                    piece = Tree(unit.label(), children[pos:start])
                    fresh.add(id(piece))
                    new.append(piece)
                new.extend(children[start:end])
                pos = end
            if pos < len(children):
                piece = Tree(unit.label(), children[pos:])
                fresh.add(id(piece))
                new.append(piece)
        return new


def _split_rules(text):
    """Split a clause body into ('chunk' | 'chink', pattern) pieces."""
    masked = _QUANT_RE.sub(lambda m: m.group(0).replace("{", "\x01").replace("}", "\x02"), text)
    pieces = []
    leftover = masked
    for match in re.finditer(r"\{[^{}]*\}|\}[^{}]*\{", masked):
        piece = match.group(0).replace("\x01", "{").replace("\x02", "}")
        if piece.startswith("{"):
            pieces.append(("chunk", piece[1:-1]))
        else:
            pieces.append(("chink", piece[1:-1]))
        leftover = leftover.replace(match.group(0), "", 1)
    if leftover.strip():
        raise ValueError(f"cannot read chunk rule near {leftover.strip()!r}")
    return pieces


def _compile_grammar(text):
    rules = []
    clause_label = None
    clause = None
    for line in text.splitlines():
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        header = _HEADER_RE.match(line)
        if header:
            clause_label = header.group(1)
            clause = object()
            body = header.group(2)
        else:
            if clause_label is None:
                raise ValueError("chunk rules must follow a clause label")
            body = line
        for kind, pattern in _split_rules(body):
            rule = ChunkRule(clause_label, pattern) if kind == "chunk" else ChinkRule(clause_label, pattern)
            rule.clause = clause
            rules.append(rule)
    return rules


class RegexpParser:
    def __init__(self, grammar):
        if isinstance(grammar, str):
            self._rules = _compile_grammar(grammar)
        elif isinstance(grammar, list) and all(isinstance(s, (ChunkRule, ChinkRule)) for s in grammar):
            self._rules = list(grammar)
        else:
            raise TypeError("grammar must be text or a list of chunk-parser stages")

    def parse(self, tagged):
        if isinstance(tagged, str) or not isinstance(tagged, (list, tuple)):
            raise TypeError("tagged must be a list of (token, tag) pairs")
        root = [tuple(pair) for pair in tagged]
        fresh = set()
        current_clause = None
        for rule in self._rules:
            if rule.clause is not current_clause:
                current_clause = rule.clause
                fresh = set()
            root = rule.apply(root, fresh)
        return Tree(SENTENCE_LABEL, root)


def ne_chunk(tagged_tokens):
    """Named-entity chunking; needs the packaged model and English wordlist."""
    if isinstance(tagged_tokens, str) or not isinstance(tagged_tokens, (list, tuple)):
        raise TypeError("tagged_tokens must be a list of (token, tag) pairs")
    _data.find("chunkers/maxent_ne_chunker_tab/english_ace_multiclass")
    _data.find("corpora/words")
    raise NotImplementedError("named-entity decoding is outside this specification")
