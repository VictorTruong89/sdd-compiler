"""Read, write and delete one binding in a file (PRD FP-06)."""

from __future__ import annotations

import os
import re

from envfile._parser import parse
from envfile._source import is_source_file, logger, read_text, write_text

QUOTE_MODES = ("always", "never", "auto")

_PLAIN_VALUE = re.compile(r"[^\W_]+")


def get_key(envfile_path, key_to_get: str, encoding: str = "utf-8"):
    """Return the parsed value of ``key_to_get``, or None for a no-value or missing name."""
    path = os.fspath(envfile_path)
    if not is_source_file(path):
        logger.warning("configuration file not found: %s", path)
        logger.warning("key not found: %s", key_to_get)
        return None
    value = None
    found = False
    for binding in parse(read_text(path, encoding)):
        if binding.name == key_to_get:
            found, value = True, binding.value
    if not found:
        logger.warning("key not found: %s", key_to_get)
    return value


def set_key(
    envfile_path,
    key_to_set: str,
    value_to_set: str,
    quote_mode: str = "always",
    export: bool = False,
    encoding: str = "utf-8",
    follow_symlinks: bool = False,
) -> bool:
    """Write one binding, replacing its lines or appending one. Return True on success."""
    if quote_mode not in QUOTE_MODES:
        raise ValueError(f"quote_mode must be one of {', '.join(QUOTE_MODES)}, not {quote_mode!r}")
    path = os.fspath(envfile_path)
    text = read_text(path, encoding) if os.path.exists(path) else ""
    line = _format_line(key_to_set, value_to_set, quote_mode, export)
    write_text(path, _replace(text, key_to_set, line), encoding, follow_symlinks)
    return True


def unset_key(
    envfile_path,
    key_to_unset: str,
    quote_mode: str = "always",
    encoding: str = "utf-8",
    follow_symlinks: bool = False,
) -> bool:
    """Remove every line binding ``key_to_unset``. Return True when a line was removed."""
    path = os.fspath(envfile_path)
    if not os.path.exists(path):
        logger.warning("path does not exist: %s", path)
        return False
    text = read_text(path, encoding)
    bindings = [binding for binding in parse(text) if binding.name == key_to_unset]
    if not bindings:
        logger.warning("key not removed: %s", key_to_unset)
        return False
    write_text(path, _splice(text, bindings, ""), encoding, follow_symlinks)
    return True


def _format_line(name: str, value: str, quote_mode: str, export: bool) -> str:
    if quote_mode == "never" or (quote_mode == "auto" and _PLAIN_VALUE.fullmatch(value)):
        stored = value
    else:
        stored = "'" + _escape_single_quoted(value) + "'"
    return ("export " if export else "") + f"{name}={stored}"


def _escape_single_quoted(value: str) -> str:
    """Escape quotes as FP-06 requires; a backslash is doubled only where it would otherwise escape."""
    pieces = []
    for index, char in enumerate(value):
        if char == "\\" and value[index + 1 : index + 2] in ("", "\\", "'"):
            pieces.append("\\\\")
        elif char == "'":
            pieces.append("\\'")
        else:
            pieces.append(char)
    return "".join(pieces)


def _replace(text: str, name: str, line: str) -> str:
    bindings = [binding for binding in parse(text) if binding.name == name]
    if not bindings:
        separator = "" if not text or text.endswith(("\r", "\n")) else "\n"
        return text + separator + line + "\n"
    return _splice(text, bindings, line + "\n")


def _splice(text: str, bindings, replacement: str) -> str:
    """Replace the line span of each binding with ``replacement``; keep all other text."""
    pieces = []
    pos = 0
    for binding in bindings:
        pieces.append(text[pos : binding.start])
        pieces.append(replacement)
        pos = binding.end
    pieces.append(text[pos:])
    return "".join(pieces)
