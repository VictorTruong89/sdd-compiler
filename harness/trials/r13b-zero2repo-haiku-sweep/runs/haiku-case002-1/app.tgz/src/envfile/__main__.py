"""Entry point for `python -m envfile` and the `envfile` command."""

import sys


def run() -> None:
    try:
        import click  # noqa: F401  (provided by the `cli` extra)
    except ImportError:
        sys.stderr.write(
            "envfile: python-envfile was not installed with the 'cli' extra; "
            "install python-envfile[cli] to use this command\n"
        )
        sys.exit(1)
    from envfile.cli import main

    main(prog_name="envfile")


if __name__ == "__main__":
    run()
