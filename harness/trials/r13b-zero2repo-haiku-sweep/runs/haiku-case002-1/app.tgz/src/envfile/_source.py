"""File access shared by the entries: source checks, reads, writes and the diagnostic logger."""

from __future__ import annotations

import logging
import os
import stat

logger = logging.getLogger("envfile")

DISABLE_VARIABLE = "PYTHON_ENVFILE_DISABLED"


def is_source_file(path: str) -> bool:
    """True when ``path`` names an existing regular file or Unix FIFO (PRD FP-02)."""
    try:
        mode = os.stat(path).st_mode
    except (OSError, ValueError):
        return False
    return stat.S_ISREG(mode) or stat.S_ISFIFO(mode)


def read_text(path: str, encoding: str) -> str:
    with open(path, "rb") as handle:
        return handle.read().decode(encoding)


def write_text(path: str, text: str, encoding: str, follow_symlinks: bool) -> None:
    """Store ``text`` at ``path`` (PRD FP-06 symbolic-link and permission rules)."""
    # Encode before touching the file so an encoding error cannot truncate it.
    data = text.encode(encoding)
    if os.path.islink(path) and not follow_symlinks:
        os.unlink(path)
        _create(path, data)
    elif os.path.exists(path):
        with open(path, "wb") as handle:
            handle.write(data)
    else:
        _create(path, data)


def _create(path: str, data: bytes) -> None:
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "wb") as handle:
        handle.write(data)
