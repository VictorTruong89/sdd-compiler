"""The `.env` text format (PRD FP-01) and variable expansion (PRD FP-05)."""

from __future__ import annotations

import os
import re
from dataclasses import dataclass

_BLANK = " \t"
_LINE_BREAKS = "\r\n"
_BOM = "\ufeff"

_DOUBLE_ESCAPES = {
    "\\": "\\",
    "'": "'",
    '"': '"',
    "a": "\a",
    "b": "\b",
    "f": "\f",
    "n": "\n",
    "r": "\r",
    "t": "\t",
    "v": "\v",
}
_SINGLE_ESCAPES = {"\\": "\\", "'": "'"}

_COMMENT = re.compile(r"[ \t]#")
_REFERENCE = re.compile(r"\$\{([^}:]+)(?::-([^}]*))?\}")


@dataclass(frozen=True)
class Binding:
    """One recognized binding.

    ``value`` is ``None`` for a name with no value. ``start`` is the index of the
    first character of the line that holds the binding; ``end`` is the index just
    past the line break that ends it (or the end of the text).
    """

    name: str
    value: str | None
    start: int
    end: int


def parse(text: str) -> list[Binding]:
    """Return the recognized bindings of ``text`` in source order."""
    floor = 1 if text.startswith(_BOM) else 0
    bindings = []
    pos = floor
    while True:
        while pos < len(text) and text[pos] in _BLANK + _LINE_BREAKS:
            pos += 1
        if pos >= len(text):
            break
        if text[pos] == "#":
            pos = _line_end(text, pos)
            continue
        parsed = _parse_binding(text, pos)
        if parsed is None:
            pos = _line_end(text, pos)
            continue
        name, value, stop = parsed
        end = stop + _break_length(text, stop)
        bindings.append(Binding(name, value, max(_line_start(text, pos), floor), end))
        pos = end
    return bindings


def resolve(bindings: list[Binding], override_first: bool, interpolate: bool) -> dict:
    """Return name -> value (``None`` for no value), with expansion applied when asked.

    Later bindings of a name replace earlier ones, keeping the first position.
    """
    earlier: dict = {}
    resolved: dict = {}
    for binding in bindings:
        value = binding.value
        if value is not None and interpolate:
            value = _expand(value, earlier, override_first)
        earlier[binding.name] = value
        resolved[binding.name] = value
    return resolved


def _parse_binding(text: str, pos: int):
    """Parse the binding starting at ``pos``. Return (name, value, stop) or None if invalid.

    ``stop`` is the index of the line break (or comment) that ends the binding.
    """
    if text.startswith("export", pos) and text[pos + 6 : pos + 7] in (" ", "\t"):
        named = _parse_name(text, _skip_blanks(text, pos + 6))
        if named is not None:
            return _parse_value(text, *named)
    named = _parse_name(text, pos)
    if named is None:
        return None
    return _parse_value(text, *named)


def _parse_name(text: str, pos: int):
    """Return (name, index after the name), or None when no name starts at ``pos``."""
    if text.startswith("'", pos):
        close = text.find("'", pos + 1)
        if close == -1:
            return None
        name = text[pos + 1 : close]
        if not name or any(char in _LINE_BREAKS for char in name):
            return None
        return name, close + 1
    stop = pos
    while stop < len(text) and text[stop] not in "=#" + _BLANK + _LINE_BREAKS:
        stop += 1
    if stop == pos:
        return None
    return text[pos:stop], stop


def _parse_value(text: str, name: str, pos: int):
    """Parse what follows a name. Return (name, value, stop) or None if invalid."""
    stop = _skip_blanks(text, pos)
    if _at_line_end(text, stop):
        return name, None, stop
    if text[stop] == "#":
        return name, None, _line_end(text, stop)
    if text[stop] != "=":
        return None
    stop = _skip_blanks(text, stop + 1)
    if _at_line_end(text, stop):
        return name, "", stop
    if text[stop] in "'\"":
        return _parse_quoted(text, name, stop)
    end = _line_end(text, stop)
    raw = text[stop:end]
    comment = _COMMENT.search(raw)
    if comment is not None:
        raw = raw[: comment.start()]
    return name, raw.rstrip(_BLANK), end


def _parse_quoted(text: str, name: str, pos: int):
    """Parse a quoted value opening at ``pos``. Return (name, value, stop) or None if invalid."""
    quote = text[pos]
    scan = pos + 1
    while scan < len(text):
        char = text[scan]
        if char == "\\":
            scan += 2
        elif char == quote:
            break
        else:
            scan += 1
    else:
        return None
    table = _DOUBLE_ESCAPES if quote == '"' else _SINGLE_ESCAPES
    value = _decode(text[pos + 1 : scan], table)
    stop = _skip_blanks(text, scan + 1)
    if _at_line_end(text, stop):
        return name, value, stop
    if text[stop] == "#":
        return name, value, _line_end(text, stop)
    return None


def _decode(raw: str, table: dict) -> str:
    pieces = []
    index = 0
    while index < len(raw):
        char = raw[index]
        if char == "\\" and index + 1 < len(raw) and raw[index + 1] in table:
            pieces.append(table[raw[index + 1]])
            index += 2
        else:
            pieces.append(char)
            index += 1
    return "".join(pieces)


def _expand(value: str, earlier: dict, override_first: bool) -> str:
    def lookup_earlier(name):
        if name not in earlier:
            return False, None
        return True, "" if earlier[name] is None else earlier[name]

    def lookup_env(name):
        if name not in os.environ:
            return False, None
        return True, os.environ[name]

    def replace(match):
        name, default = match.group(1), match.group(2)
        lookups = (lookup_earlier, lookup_env) if override_first else (lookup_env, lookup_earlier)
        for lookup in lookups:
            found, found_value = lookup(name)
            if found:
                return found_value
        return "" if default is None else default

    return _REFERENCE.sub(replace, value)


def _skip_blanks(text: str, pos: int) -> int:
    while pos < len(text) and text[pos] in _BLANK:
        pos += 1
    return pos


def _line_end(text: str, pos: int) -> int:
    while pos < len(text) and text[pos] not in _LINE_BREAKS:
        pos += 1
    return pos


def _line_start(text: str, pos: int) -> int:
    while pos > 0 and text[pos - 1] not in _LINE_BREAKS:
        pos -= 1
    return pos


def _break_length(text: str, pos: int) -> int:
    if text.startswith("\r\n", pos):
        return 2
    if pos < len(text) and text[pos] in _LINE_BREAKS:
        return 1
    return 0


def _at_line_end(text: str, pos: int) -> bool:
    return pos >= len(text) or text[pos] in _LINE_BREAKS
