"""Locate a `.env` file by walking ancestor directories (PRD FP-02)."""

from __future__ import annotations

import inspect
import os
import sys

from envfile._source import is_source_file

_PACKAGE_DIR = os.path.dirname(os.path.abspath(__file__))


def find_envfile(filename: str = ".env", raise_error_if_not_found: bool = False, usecwd: bool = False) -> str:
    """Return the path of the nearest ``filename`` walking up from the start directory, or ``""``."""
    start = _start_directory(usecwd)
    directory = start
    while True:
        candidate = os.path.join(directory, filename)
        if is_source_file(candidate):
            return candidate
        parent = os.path.dirname(directory)
        if parent == directory:
            break
        directory = parent
    if raise_error_if_not_found:
        raise FileNotFoundError(f"no {filename} found from {start} up to the filesystem root")
    return ""


def _start_directory(usecwd: bool) -> str:
    if usecwd or not _is_script_session():
        return os.getcwd()
    caller = inspect.currentframe().f_back
    while caller is not None:
        filename = caller.f_code.co_filename
        if not _inside_package(filename) and os.path.isfile(filename):
            return os.path.dirname(os.path.abspath(filename))
        caller = caller.f_back
    return os.getcwd()


def _is_script_session() -> bool:
    if getattr(sys, "frozen", False) or sys.flags.interactive or sys.gettrace() is not None:
        return False
    main = sys.modules.get("__main__")
    return getattr(main, "__file__", None) is not None


def _inside_package(filename: str) -> bool:
    return os.path.abspath(filename).startswith(_PACKAGE_DIR + os.sep)
