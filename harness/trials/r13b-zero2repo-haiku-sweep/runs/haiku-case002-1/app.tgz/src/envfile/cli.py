"""The `envfile` command-line program (PRD FP-07, FP-08). Requires the `cli` extra."""

from __future__ import annotations

import json
import os
import shlex
import shutil
import subprocess
import sys

import click

from envfile._keys import QUOTE_MODES, set_key, unset_key
from envfile._load import envfile_values
from envfile._source import is_source_file
from envfile.version import __version__

LIST_FORMATS = ("simple", "json", "shell", "export")


@click.group(context_settings={"help_option_names": ["-h", "--help"]})
@click.option("--file", "-f", "envfile_path", default=".env", show_default=True, help="The .env file to use.")
@click.option(
    "--quote",
    "-q",
    "quote_mode",
    type=click.Choice(QUOTE_MODES),
    default="always",
    show_default=True,
    help="How set writes the value.",
)
@click.option(
    "--export",
    "-e",
    "export",
    type=click.BOOL,
    default=False,
    show_default=True,
    help="Whether set writes the export directive.",
)
@click.version_option(__version__, "--version", message="envfile %(version)s")
@click.pass_context
def main(ctx, envfile_path, quote_mode, export):
    """Read, set, unset and run with the bindings of a .env file."""
    ctx.obj = {"path": envfile_path, "quote": quote_mode, "export": export}


@main.command("list")
@click.option(
    "--format",
    "output_format",
    type=click.Choice(LIST_FORMATS),
    default="simple",
    show_default=True,
    help="How to print the bindings.",
)
@click.pass_obj
def list_command(obj, output_format):
    """List every binding of the file in sorted name order."""
    values = _read_values(obj["path"])
    if output_format == "json":
        click.echo(json.dumps({name: values[name] for name in sorted(values)}, indent=2))
        return
    for name in sorted(values):
        value = values[name]
        if value is None:
            continue
        if output_format == "simple":
            click.echo(f"{name}={value}")
        else:
            line = f"{name}={shlex.quote(value)}"
            click.echo(f"export {line}" if output_format == "export" else line)


@main.command("get")
@click.argument("name")
@click.pass_obj
def get_command(obj, name):
    """Print the value of NAME."""
    value = _read_values(obj["path"]).get(name)
    if not value:
        sys.exit(1)
    click.echo(value)


@main.command("set")
@click.argument("name")
@click.argument("value")
@click.pass_obj
def set_command(obj, name, value):
    """Write NAME=VALUE to the file."""
    try:
        set_key(obj["path"], name, value, quote_mode=obj["quote"], export=obj["export"])
    except OSError as exc:
        click.echo(f"envfile: could not write {obj['path']}: {exc.strerror}", err=True)
        sys.exit(1)
    click.echo(f"{name}={value}")


@main.command("unset")
@click.argument("name")
@click.pass_obj
def unset_command(obj, name):
    """Remove NAME from the file."""
    if not unset_key(obj["path"], name, quote_mode=obj["quote"]):
        sys.exit(1)
    click.echo(f"Removed {name}")


@main.command(
    "run",
    context_settings={"ignore_unknown_options": True, "allow_interspersed_args": False},
)
@click.option("--override/--no-override", default=True, show_default=True, help="Whether file values replace inherited ones.")
@click.argument("command", nargs=-1, type=click.UNPROCESSED)
@click.pass_obj
def run_command(obj, override, command):
    """Run COMMAND with the file's bindings in its environment."""
    path = obj["path"]
    if not os.path.isfile(path):
        raise click.UsageError(f"invalid --file, not an existing regular file: {path}")
    if not command:
        click.echo("envfile: no command given to run")
        sys.exit(1)
    child_env = dict(os.environ)
    for name, value in envfile_values(path).items():
        if value is not None and (override or name not in child_env):
            child_env[name] = value
    program = shutil.which(command[0], path=os.pathsep.join(os.get_exec_path(child_env)))
    if program is None:
        click.echo(f"envfile: command not found: {command[0]}", err=True)
        sys.exit(1)
    try:
        completed = subprocess.run(list(command), executable=program, env=child_env)
    except OSError as exc:
        click.echo(f"envfile: could not run {command[0]}: {exc.strerror}", err=True)
        sys.exit(1)
    returncode = completed.returncode
    sys.exit(returncode if returncode >= 0 else 128 - returncode)


def _read_values(path: str):
    if not is_source_file(path):
        click.echo(f"envfile: could not open env file: {path}", err=True)
        sys.exit(2)
    try:
        return envfile_values(path)
    except (OSError, UnicodeDecodeError):
        click.echo(f"envfile: could not open env file: {path}", err=True)
        sys.exit(2)
