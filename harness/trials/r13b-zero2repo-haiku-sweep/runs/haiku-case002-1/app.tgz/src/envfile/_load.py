"""Values mapping (PRD FP-04) and load into the process environment (PRD FP-03)."""

from __future__ import annotations

import os

from envfile._locate import find_envfile
from envfile._parser import parse, resolve
from envfile._source import DISABLE_VARIABLE, is_source_file, logger, read_text

_DISABLED_WORDS = frozenset({"1", "true", "t", "yes", "y"})


def envfile_values(
    envfile_path=None,
    stream=None,
    verbose: bool = False,
    interpolate: bool = True,
    encoding: str = "utf-8",
) -> dict:
    """Parse one source into a mapping without touching the process environment."""
    text = _source_text(envfile_path, stream, verbose, encoding)
    return resolve(parse(text), override_first=True, interpolate=interpolate)


def load_envfile(
    envfile_path=None,
    stream=None,
    verbose: bool = False,
    override: bool = False,
    interpolate: bool = True,
    encoding: str = "utf-8",
) -> bool:
    """Write the source's recognized values into ``os.environ``. Return True on success."""
    if os.environ.get(DISABLE_VARIABLE, "").casefold() in _DISABLED_WORDS:
        return False
    text = _source_text(envfile_path, stream, verbose, encoding)
    values = resolve(parse(text), override_first=override, interpolate=interpolate)
    for name, value in values.items():
        if value is None or (not override and name in os.environ):
            continue
        try:
            os.environ[name] = value
        except (ValueError, OSError):
            logger.warning("cannot set environment variable %s", name)
    return len(values) > 0


def _source_text(envfile_path, stream, verbose: bool, encoding: str) -> str:
    path = None if envfile_path is None else os.fspath(envfile_path)
    text = _select(path, stream, encoding)
    if text is None:
        if verbose:
            logger.warning("configuration file not found: %s", path or ".env")
        return ""
    return text


def _select(path, stream, encoding: str):
    """Return the text of the selected source, or None when no source is selected (PRD FP-03)."""
    if path is not None and is_source_file(path):
        return read_text(path, encoding)
    if stream is not None:
        return stream.read()
    if path is not None:
        return None
    found = find_envfile()
    if found:
        return read_text(found, encoding)
    return None
