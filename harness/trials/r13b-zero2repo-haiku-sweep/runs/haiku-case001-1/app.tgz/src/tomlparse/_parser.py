"""Recursive-descent TOML v1.1.0 parser.

The parser works on the text by index. Containers are plain ``dict`` and
``list`` objects; a side table records each container's TOML kind so that
table headers and dotted keys can be checked for conflicts.
"""

import datetime
import re
import string
import sys

from ._errors import TOMLDecodeError

# Deep nesting (470 arrays, 310 inline tables) needs more frames than the
# default limit allows.
_RECURSION_LIMIT = 4000

_HEX = frozenset(string.hexdigits)
_SIMPLE_ESCAPES = {
    'b': '\b',
    't': '\t',
    'n': '\n',
    'f': '\f',
    'r': '\r',
    'e': '\x1b',
    '"': '"',
    '\\': '\\',
}
_ESCAPE_DIGITS = {'x': 2, 'u': 4, 'U': 8}
_SPECIAL_FLOATS = frozenset(['inf', '+inf', '-inf', 'nan', '+nan', '-nan'])

_BARE_KEY = re.compile(r'[A-Za-z0-9_-]+')
_BASIC_RUN = re.compile(r'[^"\\\x00-\x08\x0a-\x1f\x7f]+')
_LITERAL_RUN = re.compile(r"[^'\x00-\x08\x0a-\x1f\x7f]+")
_ML_BASIC_RUN = re.compile(r'[^"\\\r\x00-\x08\x0b-\x1f\x7f]+')
_ML_LITERAL_RUN = re.compile(r"[^'\r\x00-\x08\x0b-\x1f\x7f]+")
_BARE_VALUE = re.compile(r'[0-9A-Za-z_+\-.]+')
_DATETIME = re.compile(
    r'([0-9]{4})-([0-9]{2})-([0-9]{2})'
    r'(?:[Tt ]([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?'
    r'([Zz]|[+-][0-9]{2}:[0-9]{2})?)?')
_TIME = re.compile(r'([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.([0-9]+))?)?')
_INT_DEC = re.compile(r'[+-]?(?:0|[1-9](?:_?[0-9])*)')
_INT_PREFIXED = re.compile(
    r'0(?:x[0-9A-Fa-f](?:_?[0-9A-Fa-f])*'
    r'|o[0-7](?:_?[0-7])*'
    r'|b[01](?:_?[01])*)')
_FLOAT = re.compile(
    r'[+-]?(?:0|[1-9](?:_?[0-9])*)'
    r'(?:\.[0-9](?:_?[0-9])*(?:[eE][+-]?[0-9](?:_?[0-9])*)?'
    r'|[eE][+-]?[0-9](?:_?[0-9])*)')


def parse_document(text, parse_float):
    """Parse ``text`` and return the document mapping."""
    old_limit = sys.getrecursionlimit()
    if old_limit < _RECURSION_LIMIT:
        sys.setrecursionlimit(_RECURSION_LIMIT)
        try:
            return _Parser(text, parse_float).parse()
        finally:
            sys.setrecursionlimit(old_limit)
    return _Parser(text, parse_float).parse()


class _Parser(object):

    def __init__(self, text, parse_float):
        self.s = text
        self.n = len(text)
        self.i = 0
        self.parse_float = parse_float
        # id(container) -> kind. Kinds: 'table' (defined by a header),
        # 'implicit' (super-table created by a header), 'dotted' (created by
        # dotted keys), 'inline' (frozen inline table), 'elem' (element of an
        # array of tables), 'aot' (array of tables). Static arrays have no kind.
        self.kinds = {}

    # ----- helpers -------------------------------------------------------

    def _err(self, msg, pos):
        return TOMLDecodeError(msg, self.s, pos)

    def _new_dict(self, kind):
        table = {}
        self.kinds[id(table)] = kind
        return table

    def _set_kind(self, obj, kind):
        self.kinds[id(obj)] = kind

    def _kind_of(self, obj):
        return self.kinds.get(id(obj))

    def _skip_ws(self):
        s = self.s
        i = self.i
        while i < self.n and s[i] in ' \t':
            i += 1
        self.i = i

    def _skip_ws_nl(self):
        s = self.s
        while self.i < self.n:
            c = s[self.i]
            if c in ' \t\n':
                self.i += 1
            elif c == '\r' and s.startswith('\n', self.i + 1):
                self.i += 2
            elif c == '#':
                self._skip_comment()
            else:
                break

    def _skip_comment(self):
        s = self.s
        i = self.i + 1
        while i < self.n:
            c = s[i]
            if c == '\n' or (c == '\r' and s.startswith('\n', i + 1)):
                break
            if (c < ' ' and c != '\t') or c == '\x7f':
                raise self._err('control character in comment', i)
            i += 1
        self.i = i

    def _end_of_line(self):
        self._skip_ws()
        if self.i < self.n and self.s[self.i] == '#':
            self._skip_comment()
        if self.i >= self.n:
            return
        if self.s[self.i] == '\n':
            self.i += 1
        elif self.s.startswith('\r\n', self.i):
            self.i += 2
        else:
            raise self._err('expected end of line', self.i)

    # ----- document structure --------------------------------------------

    def parse(self):
        root = self._new_dict('table')
        scope = root
        while True:
            self._skip_ws_nl()
            if self.i >= self.n:
                break
            if self.s[self.i] == '[':
                scope = self._header(root)
            else:
                self._keyval(scope)
            self._end_of_line()
        return root

    def _header(self, root):
        start = self.i
        is_aot = self.s.startswith('[[', start)
        self.i += 2 if is_aot else 1
        self._skip_ws()
        parts = self._dotted_key()
        if is_aot:
            if not self.s.startswith(']]', self.i):
                raise self._err("expected ']]'", self.i)
            self.i += 2
            return self._header_aot(root, parts, start)
        if self.i >= self.n or self.s[self.i] != ']':
            raise self._err("expected ']'", self.i)
        self.i += 1
        return self._header_table(root, parts, start)

    def _header_walk(self, root, parts, start):
        """Return the table that holds the last part, creating parents."""
        cur = root
        for key in parts[:-1]:
            if key not in cur:
                child = self._new_dict('implicit')
                cur[key] = child
                cur = child
                continue
            value = cur[key]
            if isinstance(value, list) and self._kind_of(value) == 'aot':
                cur = value[-1]
            elif isinstance(value, dict) and self._kind_of(value) in (
                    'table', 'implicit', 'dotted', 'elem'):
                cur = value
            else:
                raise self._err('table header conflicts with a value', start)
        return cur

    def _header_table(self, root, parts, start):
        cur = self._header_walk(root, parts, start)
        key = parts[-1]
        if key in cur:
            value = cur[key]
            if isinstance(value, dict) and self._kind_of(value) == 'implicit':
                self._set_kind(value, 'table')
                return value
            raise self._err('table is already defined', start)
        table = self._new_dict('table')
        cur[key] = table
        return table

    def _header_aot(self, root, parts, start):
        cur = self._header_walk(root, parts, start)
        key = parts[-1]
        if key in cur:
            value = cur[key]
            if isinstance(value, list) and self._kind_of(value) == 'aot':
                elem = self._new_dict('elem')
                value.append(elem)
                return elem
            raise self._err('array of tables conflicts with a value', start)
        elem = self._new_dict('elem')
        array = [elem]
        self._set_kind(array, 'aot')
        cur[key] = array
        return elem

    def _keyval(self, scope):
        start = self.i
        parts = self._dotted_key()
        if self.i >= self.n or self.s[self.i] != '=':
            raise self._err("expected '='", self.i)
        self.i += 1
        self._skip_ws()
        owner = self._dotted_owner(scope, parts, start)
        value = self._value()
        key = parts[-1]
        if key in owner:
            raise self._err('duplicate key', start)
        owner[key] = value

    def _dotted_owner(self, scope, parts, start):
        """Return the table that holds the last part of a dotted key."""
        cur = scope
        for key in parts[:-1]:
            if key not in cur:
                child = self._new_dict('dotted')
                cur[key] = child
                cur = child
                continue
            value = cur[key]
            if isinstance(value, dict) and self._kind_of(value) in (
                    'dotted', 'implicit'):
                self._set_kind(value, 'dotted')
                cur = value
            else:
                raise self._err('dotted key conflicts with an existing value',
                                start)
        return cur

    # ----- keys ----------------------------------------------------------

    def _dotted_key(self):
        parts = [self._simple_key()]
        self._skip_ws()
        while self.i < self.n and self.s[self.i] == '.':
            self.i += 1
            self._skip_ws()
            parts.append(self._simple_key())
            self._skip_ws()
        return parts

    def _simple_key(self):
        i = self.i
        if i >= self.n:
            raise self._err('expected a key', i)
        c = self.s[i]
        if c == '"':
            if self.s.startswith('"""', i):
                raise self._err('multiline string is not a valid key', i)
            return self._basic_string()
        if c == "'":
            if self.s.startswith("'''", i):
                raise self._err('multiline string is not a valid key', i)
            return self._literal_string()
        m = _BARE_KEY.match(self.s, i)
        if not m:
            raise self._err('expected a key', i)
        self.i = m.end()
        return m.group()

    # ----- values --------------------------------------------------------

    def _value(self):
        s = self.s
        i = self.i
        if i >= self.n:
            raise self._err('expected a value', i)
        c = s[i]
        if c == '"':
            if s.startswith('"""', i):
                return self._ml_basic_string()
            return self._basic_string()
        if c == "'":
            if s.startswith("'''", i):
                return self._ml_literal_string()
            return self._literal_string()
        if c == '[':
            return self._array()
        if c == '{':
            return self._inline_table()
        return self._scalar()

    def _array(self):
        self.i += 1
        items = []
        self._skip_ws_nl()
        if self.i < self.n and self.s[self.i] == ']':
            self.i += 1
            return items
        while True:
            items.append(self._value())
            self._skip_ws_nl()
            if self.i >= self.n:
                raise self._err('unterminated array', self.n)
            c = self.s[self.i]
            if c == ']':
                self.i += 1
                return items
            if c != ',':
                raise self._err("expected ',' or ']'", self.i)
            self.i += 1
            self._skip_ws_nl()
            if self.i < self.n and self.s[self.i] == ']':
                self.i += 1
                return items

    def _inline_table(self):
        self.i += 1
        table = self._new_dict('inline')
        self._skip_ws_nl()
        if self.i < self.n and self.s[self.i] == '}':
            self.i += 1
            return table
        while True:
            self._keyval(table)
            self._skip_ws_nl()
            if self.i >= self.n:
                raise self._err('unterminated inline table', self.n)
            c = self.s[self.i]
            if c == '}':
                self.i += 1
                return table
            if c != ',':
                raise self._err("expected ',' or '}'", self.i)
            self.i += 1
            self._skip_ws_nl()
            if self.i < self.n and self.s[self.i] == '}':
                self.i += 1
                return table

    def _scalar(self):
        s = self.s
        i = self.i
        m = _DATETIME.match(s, i)
        if m:
            self.i = m.end()
            return self._datetime(m, i)
        m = _TIME.match(s, i)
        if m:
            self.i = m.end()
            return self._time(m, i)
        m = _BARE_VALUE.match(s, i)
        if not m:
            raise self._err('expected a value', i)
        token = m.group()
        self.i = m.end()
        if token == 'true':
            return True
        if token == 'false':
            return False
        if token in _SPECIAL_FLOATS:
            return self._float(token)
        if _INT_DEC.fullmatch(token):
            return int(token.replace('_', ''))
        if _INT_PREFIXED.fullmatch(token):
            base = {'x': 16, 'o': 8, 'b': 2}[token[1]]
            return int(token[2:].replace('_', ''), base)
        if _FLOAT.fullmatch(token):
            return self._float(token)
        raise self._err('invalid value', i)

    def _float(self, token):
        if self.parse_float is float:
            return float(token.replace('_', ''))
        value = self.parse_float(token)
        if isinstance(value, (dict, list)):
            raise ValueError('parse_float returned a dict or list')
        return value

    def _datetime(self, m, start):
        year, month, day = int(m.group(1)), int(m.group(2)), int(m.group(3))
        try:
            date = datetime.date(year, month, day)
        except ValueError:
            raise self._err('invalid date', start)
        if m.group(4) is None:
            return date
        hour, minute, second, micro = self._clock(
            m.group(4), m.group(5), m.group(6), m.group(7), start)
        tzinfo = self._offset(m.group(8), start)
        return datetime.datetime(year, month, day, hour, minute, second,
                                 micro, tzinfo=tzinfo)

    def _time(self, m, start):
        hour, minute, second, micro = self._clock(
            m.group(1), m.group(2), m.group(3), m.group(4), start)
        return datetime.time(hour, minute, second, micro)

    def _clock(self, hour_text, minute_text, second_text, frac, start):
        hour = int(hour_text)
        minute = int(minute_text)
        second = int(second_text) if second_text is not None else 0
        if hour > 23 or minute > 59 or second > 59:
            raise self._err('invalid time', start)
        micro = int((frac or '')[:6].ljust(6, '0'))
        return hour, minute, second, micro

    def _offset(self, text, start):
        if text is None:
            return None
        if text in ('Z', 'z'):
            return datetime.timezone.utc
        hours = int(text[1:3])
        minutes = int(text[4:6])
        if hours > 23 or minutes > 59:
            raise self._err('invalid UTC offset', start)
        sign = -1 if text[0] == '-' else 1
        return datetime.timezone(
            sign * datetime.timedelta(hours=hours, minutes=minutes))

    # ----- strings -------------------------------------------------------

    def _basic_string(self):
        s = self.s
        i = self.i + 1
        buf = []
        while True:
            m = _BASIC_RUN.match(s, i)
            if m:
                buf.append(m.group())
                i = m.end()
            if i >= self.n:
                raise self._err('unterminated string', self.n)
            c = s[i]
            if c == '"':
                self.i = i + 1
                return ''.join(buf)
            if c != '\\':
                raise self._err('invalid character in string', i)
            text, i = self._escape(i)
            buf.append(text)

    def _escape(self, i):
        """Decode the escape at ``i``; return (text, index after it)."""
        s = self.s
        nxt = s[i + 1:i + 2]
        if nxt in _SIMPLE_ESCAPES:
            return _SIMPLE_ESCAPES[nxt], i + 2
        if nxt in _ESCAPE_DIGITS:
            width = _ESCAPE_DIGITS[nxt]
            digits = s[i + 2:i + 2 + width]
            if len(digits) == width and all(c in _HEX for c in digits):
                code = int(digits, 16)
                if code > 0x10FFFF or 0xD800 <= code <= 0xDFFF:
                    raise self._err('escape is not a Unicode scalar value', i)
                return chr(code), i + 2 + width
        raise self._err('invalid escape sequence', i)

    def _literal_string(self):
        s = self.s
        i = self.i + 1
        buf = []
        while True:
            m = _LITERAL_RUN.match(s, i)
            if m:
                buf.append(m.group())
                i = m.end()
            if i >= self.n:
                raise self._err('unterminated string', self.n)
            if s[i] == "'":
                self.i = i + 1
                return ''.join(buf)
            raise self._err('invalid character in string', i)

    def _skip_line_ending_whitespace(self, i):
        """Skip spaces, tabs and line endings after a line-ending backslash."""
        s = self.s
        while i < self.n:
            c = s[i]
            if c in ' \t\n':
                i += 1
            elif c == '\r' and s.startswith('\n', i + 1):
                i += 2
            else:
                break
        return i

    def _ml_basic_string(self):
        s = self.s
        i = self.i + 3
        if s.startswith('\r\n', i):
            i += 2
        elif s.startswith('\n', i):
            i += 1
        buf = []
        while True:
            m = _ML_BASIC_RUN.match(s, i)
            if m:
                buf.append(m.group())
                i = m.end()
            if i >= self.n:
                raise self._err('unterminated string', self.n)
            c = s[i]
            if c == '"':
                if s.startswith('"""', i):
                    j = i
                    while j < self.n and s[j] == '"':
                        j += 1
                    if j - i > 5:
                        raise self._err('too many quotes in string', i)
                    buf.append('"' * (j - i - 3))
                    self.i = j
                    return ''.join(buf)
                buf.append('"')
                i += 1
            elif c == '\\':
                k = i + 1
                while k < self.n and s[k] in ' \t':
                    k += 1
                if k < self.n and (s[k] == '\n' or s.startswith('\r\n', k)):
                    i = self._skip_line_ending_whitespace(k)
                elif k > i + 1:
                    raise self._err('invalid escape sequence', i)
                else:
                    text, i = self._escape(i)
                    buf.append(text)
            elif c == '\r':
                if not s.startswith('\r\n', i):
                    raise self._err('bare carriage return in string', i)
                buf.append('\n')
                i += 2
            else:
                raise self._err('invalid character in string', i)

    def _ml_literal_string(self):
        s = self.s
        i = self.i + 3
        if s.startswith('\r\n', i):
            i += 2
        elif s.startswith('\n', i):
            i += 1
        buf = []
        while True:
            m = _ML_LITERAL_RUN.match(s, i)
            if m:
                buf.append(m.group())
                i = m.end()
            if i >= self.n:
                raise self._err('unterminated string', self.n)
            c = s[i]
            if c == "'":
                if s.startswith("'''", i):
                    j = i
                    while j < self.n and s[j] == "'":
                        j += 1
                    if j - i > 5:
                        raise self._err('too many quotes in string', i)
                    buf.append("'" * (j - i - 3))
                    self.i = j
                    return ''.join(buf)
                buf.append("'")
                i += 1
            elif s.startswith('\r\n', i):
                buf.append('\n')
                i += 2
            else:
                raise self._err('invalid character in string', i)
