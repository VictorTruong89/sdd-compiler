"""Tomlparse: a pure-Python parser for TOML v1.1.0.

Entries:

* ``loads(s, *, parse_float=float)`` parses a text string.
* ``load(fp, *, parse_float=float)`` parses a binary file object (UTF-8).
* ``TOMLDecodeError`` is raised for invalid TOML.
"""

import io

from ._errors import TOMLDecodeError
from ._parser import parse_document

__version__ = '2.4.0'
__all__ = ['loads', 'load', 'TOMLDecodeError']


def loads(s, *, parse_float=float):
    """Parse the TOML document ``s`` (a ``str``) into a ``dict``."""
    if not isinstance(s, str):
        raise TypeError('loads() expects a str, not %s' % type(s).__name__)
    return parse_document(s, parse_float)


def load(fp, *, parse_float=float):
    """Parse TOML from the binary file object ``fp`` into a ``dict``."""
    if isinstance(fp, io.TextIOBase):
        raise TypeError('load() needs a file opened in binary mode')
    data = fp.read()
    if not isinstance(data, (bytes, bytearray)):
        raise TypeError('load() needs a file opened in binary mode')
    return parse_document(data.decode('utf-8'), parse_float)
