"""The parse-failure exception for Tomlparse."""


class TOMLDecodeError(ValueError):
    """A document is not valid TOML v1.1.0.

    ``msg`` is the unformatted reason, ``doc`` the document text and ``pos``
    a 0-based character offset into ``doc``. ``lineno`` and ``colno`` are
    1-based and derived from ``pos``.
    """

    def __init__(self, msg, doc, pos):
        super().__init__(msg, doc, pos)
        self.msg = msg
        self.doc = doc
        self.pos = pos
        self.lineno = doc.count('\n', 0, pos) + 1
        self.colno = pos - doc.rfind('\n', 0, pos)

    def __str__(self):
        if self.pos >= len(self.doc):
            return '%s (at end of document)' % self.msg
        return '%s (line %d column %d, char %d)' % (
            self.msg, self.lineno, self.colno, self.pos)
